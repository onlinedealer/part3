export class ScheduleRunsModel {
  duration: string;
  errorMessage: string;
  id: string;
  runDateTime: number;
  status: string;
}
