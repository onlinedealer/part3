import { RouteTransformerDirective } from './route-transformer.directive';

describe('RouteTransformerDirective', () => {
  it('should create an instance', () => {
    const directive = new RouteTransformerDirective({} as any, {} as any);
    expect(directive).toBeTruthy();
  });
});
