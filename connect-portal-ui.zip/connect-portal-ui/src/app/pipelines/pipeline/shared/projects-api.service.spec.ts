import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { of } from 'rxjs';
import { environment } from 'src/environments/environment';
import { DebugResponse } from './debug-response';
import { Project } from './project';
import { ProjectsApiService } from './projects-api.service';

describe('ProjectsApiService', () => {
  let service: ProjectsApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  const mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [{ provide: FeatureFlagService, useValue: mockFeatureFlagService }]
    });
    service = TestBed.inject(ProjectsApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get the default (first) project', () => {
    spyOn(service, 'getFirst').and.returnValue(of({ name: 'abcd' } as Project));
    service.getDefaultProject();
    expect(service.getFirst).toHaveBeenCalled();
  });

  describe('async commit and validate', () => {
    it('should validate a project', () => {
      const expectedRequestMethod = 'PUT';
      const expectedEndpointUrl = `${service.serviceURL}/637211a266cf4b39d8212b51/validate`;

      const mockSuccessResponse = {
        projectId: '637211a266cf4b39d8212b51',
        validateStatus: {
          status: 'COMPLETED',
          lastUpdatedOn: 'Nov 14, 2022, 3:19:33 PM',
          completePercentage: 100,
          projectValidation: {
            severityLevel: 'VALID',
            message: '\nValidating: Project\nOk\n',
            warning: 0,
            incomplete: 0,
            error: 0,
            fatal: 0,
            total: 1
          }
        },
        commitStatus: {
          status: 'OPEN',
          isCommitted: false,
          projectValidation: {
            warning: 0,
            incomplete: 0,
            error: 0,
            fatal: 0,
            total: 0
          }
        }
      };

      service.validate('637211a266cf4b39d8212b51').then((response) => {
        expect(response.validateStatus.status).toBe('COMPLETED');
      });

      const req = httpMock.expectOne(expectedEndpointUrl);
      expect(req.request.method).toBe(expectedRequestMethod);
      req.flush(mockSuccessResponse);

      httpMock.verify();
    });

    it('should get the status', () => {
      const expectedRequestMethod = 'GET';
      const expectedEndpointUrl = `${service.serviceURL}/637211a266cf4b39d8212b51/status`;

      const mockSuccessResponse = {
        projectId: '637211a266cf4b39d8212b51',
        validateStatus: {
          status: 'COMPLETED',
          lastUpdatedOn: 'Nov 14, 2022, 3:19:33 PM',
          completePercentage: 100,
          projectValidation: {
            severityLevel: 'VALID',
            message: '\nValidating: Project\nOk\n',
            warning: 0,
            incomplete: 0,
            error: 0,
            fatal: 0,
            total: 1
          }
        },
        commitStatus: {
          status: 'OPEN',
          isCommitted: false,
          projectValidation: {
            warning: 0,
            incomplete: 0,
            error: 0,
            fatal: 0,
            total: 0
          }
        }
      };

      service.status('637211a266cf4b39d8212b51').then((response) => {
        expect(response.validateStatus.status).toBe('COMPLETED');
      });

      const req = httpMock.expectOne(expectedEndpointUrl);
      expect(req.request.method).toBe(expectedRequestMethod);
      req.flush(mockSuccessResponse);

      httpMock.verify();
    });
  });

  describe('committing a project', () => {
    it('should work for a valid project', () => {
      const expectedRequestMethod = 'PUT';
      const expectedEndpointUrl = `${service.serviceURL}/1/commit`;

      const mockSuccessResponse = {
        committed: true
      };

      service.commit('1', false, 'INCREMENTAL_COMMIT').subscribe((response) => {
        expect(response.isCommited).toBe(true);
      });

      const req = httpMock.expectOne(expectedEndpointUrl);
      expect(req.request.method).toBe(expectedRequestMethod);
      req.flush(mockSuccessResponse);

      httpMock.verify();
    });

    it('should support the forced parameter', () => {
      const expectedRequestMethod = 'PUT';
      const expectedEndpointUrl = `${service.serviceURL}/1/commit?forced=true`;

      const mockSuccessResponse = {
        committed: true
      };

      service.commit('1', true).subscribe((response) => {
        expect(response.isCommited).toBe(true);
      });

      const req = httpMock.expectOne(expectedEndpointUrl);
      expect(req.request.method).toBe(expectedRequestMethod);
      req.flush(mockSuccessResponse);

      httpMock.verify();
    });

    it('should return validation error for an invalid project', () => {
      const expectedRequestMethod = 'PUT';
      const expectedEndpointUrl = `${service.serviceURL}/1/commit`;

      const mockFailedResponse = {
        committed: false,
        projectValidation: {
          error: 1,
          fatal: 0,
          incomplete: 0,
          message: 'error',
          severityLevel: '',
          total: 1,
          warning: 0
        }
      };

      service.commit('1').subscribe((response) => {
        expect(response.isCommited).toBe(false);
        expect(response.validationResponse.message).toBe('error');
      });

      const req = httpMock.expectOne(expectedEndpointUrl);
      expect(req.request.method).toBe(expectedRequestMethod);
      req.flush(mockFailedResponse);

      httpMock.verify();
    });
  });

  it('should call download Jcl API', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = `${service.serviceURL}/1/jcl`;
    let returnedData;
    const mockApiResponse: ArrayBuffer = new ArrayBuffer(8);
    service.downloadJcl('1').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
  });

  it('should call export project API', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = `${service.serviceURL}/exportRP?ids=1&filename=abcd&exportUsernames=false`;
    let returnedData;
    const mockApiResponse: ArrayBuffer = new ArrayBuffer(8);
    service.exportProject('1', 'abcd', false).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
  });

  it('should startall projects', () => {
    const responseData = [];
    const projectId = '61f7d56a8a96704256f9d84a';
    const url = `${environment.connectApiBaseURL}/cdc/monitoring/${projectId}/servers/startall`;

    service.start(projectId).subscribe((response) => {
      expect(response).toEqual(responseData);
    });
    const req = httpMock.expectOne(url);
    expect(req.request.method).toEqual('PUT');
    req.flush(responseData);
    httpMock.verify();
  });

  it('should stopall projects', () => {
    const responseData = [];
    const projectId = '61f7d56a8a96704256f9d84a';
    const url = `${environment.connectApiBaseURL}/cdc/monitoring/${projectId}/servers/stopall`;

    service.stop(projectId).subscribe((response) => {
      expect(response).toEqual(responseData);
    });
    const req = httpMock.expectOne(url);
    expect(req.request.method).toEqual('PUT');
    req.flush(responseData);
  });

  it('should call export all projects API', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = `${service.serviceURL}/exportRP/all?filename=abcd&exportUsernames=false`;
    let returnedData;
    const mockApiResponse: ArrayBuffer = new ArrayBuffer(8);
    service.exportAllProjects('abcd', false).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
  });

  describe('debugging a project', () => {
    it('should support setting parameter', () => {
      const expectedRequestMethod = 'PUT';
      const expectedEndpointUrl = `${service.serviceURL}/1/debug?setting=enable_sql_debug`;

      const mockSuccessResponse: DebugResponse = {
        engine: { sqlDebug: 'ON', level: 'DEBUG' }
      };

      service.debugProject('1', 'enable_sql_debug').subscribe((response) => {
        expect(response.engine.sqlDebug).toEqual('ON');
      });

      const req = httpMock.expectOne(expectedEndpointUrl);
      expect(req.request.method).toBe(expectedRequestMethod);
      req.flush(mockSuccessResponse);

      httpMock.verify();
    });

    it('should support setting parameter with runtime engine', () => {
      const expectedRequestMethod = 'PUT';
      const expectedEndpointUrl = `${service.serviceURL}/1/debug?setting=enable_sql_debug&host_label=runtime`;

      const mockSuccessResponse: DebugResponse = {
        engine: { sqlDebug: 'ON', level: 'DEBUG' }
      };

      service.debugSingleServer('1', 'enable_sql_debug', 'runtime').subscribe((response) => {
        expect(response.engine.sqlDebug).toEqual('ON');
      });

      const req = httpMock.expectOne(expectedEndpointUrl);
      expect(req.request.method).toBe(expectedRequestMethod);
      req.flush(mockSuccessResponse);

      httpMock.verify();
    });
  });
});
