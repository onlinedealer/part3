export class WarningAlertModel {
  minimum: number;
  maximum: number;
}
