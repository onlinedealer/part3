import { Component, OnInit, ViewChild } from '@angular/core';
import { Table } from 'primeng/table';
import { ProfileService } from '../profile.service';
import { ProfileListModel } from './profile-list.model';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import {
  SecondaryNavItemsService,
  ServerSentEventsService,
  SharedConstants,
  ConnectionModel,
  ConnectionService
} from 'discovery-shared';
import { ProfileRunStatusModel } from 'discovery-core';
import { Router } from '@angular/router';
import { ConfirmationService, MenuItem } from 'primeng/api';
import { TranslocoService } from '@ngneat/transloco';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { ScheduleSidebarConfigModel } from 'shared/schedule/schedule-detail/schedule-sidebar-config.model';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

@Component({
  selector: 'discovery-profile-listing',
  templateUrl: './profile-listing.component.html',
  styleUrls: ['./profile-listing.component.css'],
  providers: [ConfirmationService]
})
export class ProfileListingComponent implements OnInit {
  /**
   *
   */
  @ViewChild('profileTable') profileTable: Table;

  /**
   *
   */
  profileList: ProfileListModel[];

  /**
   *
   */
  data: any;

  /**
   *
   */
  basicOptions: any;

  /**
   *
   */
  activityValues: any = [0, 100];

  /**
   *
   */
  completenessFilterValue: any;

  /**
   *
   */
  baseUrl: string;
  items: MenuItem[];
  connectionList: ConnectionModel[];
  sidebarVisible: boolean;
  connectionType: string;
  configureViewType: string;
  fetchConnectionsInProgress: boolean;
  fetchProfilesInProgress: boolean;
  scheduleType: ScheduleSidebarConfigModel;

  /**
   * menu items for secondary navigation left sliding menu
   */
  navItems: MenuItem[];
  activeNavItem: MenuItem;

  isScheduleSidebarVisible: boolean;

  get scheduleFeatureFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.SCHEDULER);
  }
  /**
   *
   * @param profileService
   * @param toastrService
   * @param translateService
   * @param sseService
   * @param dialogService
   * @param router
   */
  constructor(
    private profileService: ProfileService,
    private toastrService: ToastrService,
    private translocoService: TranslocoService,
    private sseService: ServerSentEventsService,
    private confirmationService: ConfirmationService,
    private router: Router,
    private connectionService: ConnectionService,
    private launchDarklyService: LaunchDarklyService,
    private navItemService: SecondaryNavItemsService,
    public httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('configapi', 'profiling', 'api/v1/');
    this.profileList = [];
    this.connectionList = [];
  }

  ngOnInit(): void {
    this.loadConnectionList();
    this.loadProfileList();
    this.navItems = this.navItemService.getNavItems();
    this.activeNavItem = this.navItemService.getActiveNav('data-profile');
  }

  /**
   *
   * @param $event
   * @param contains
   */
  filterGlobal($event: Event, contains: string) {
    this.profileTable.filterGlobal(($event.target as HTMLInputElement).value, contains);
  }

  /**
   *
   * @param $event
   */
  handleChange($event: any) {
    this.completenessFilterValue = $event.values;
  }

  runProfile(id: string, name: string) {
    const profileModel: ProfileListModel = this.profileList.find((value) => value.id === id);
    profileModel.status = SharedConstants.STATUS.PROCESSING;
    this.profileService.runProfile(id).subscribe(
      (response: any) => {
        profileModel.status = SharedConstants.STATUS.INPROGRESS;
        profileModel.message = SharedConstants.STATUS.INPROGRESS;
        profileModel.completenessPercentage = null;
        profileModel.recordsCount = null;
        profileModel.duration = null;
        profileModel.lastRun = null;
        profileModel.lastRunId = response.runId;
        this.checkProfileRunStatus(profileModel.lastRunId, profileModel);
      },
      (httpErrorResponse: HttpErrorResponse) => {
        if (httpErrorResponse.status === 400 || httpErrorResponse.status === 404 || httpErrorResponse.status === 423) {
          profileModel.status = SharedConstants.STATUS.ERROR;
          profileModel.message = httpErrorResponse.error.message;
        }
        if (httpErrorResponse.status === 403) {
          profileModel.status = SharedConstants.STATUS.ERROR;
          profileModel.message = this.translocoService.translate('discoveryProfiling.listing.unauthorized');
        }
        if (httpErrorResponse.status === 404) {
          this.toastrService.error(this.translocoService.translate('discoveryProfiling.listing.profileNotFound'));
        } else if (httpErrorResponse.status === 423) {
          this.toastrService.error(this.translocoService.translate('discoveryProfiling.listing.profileAlreadyRunning'));
        } else if (httpErrorResponse.status !== 403) {
          profileModel.status = SharedConstants.STATUS.SUCCESS;
          this.toastrService.error(
            this.translocoService.translate('discoveryProfiling.listing.profileRunFail', {
              serverMessage:
                httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                  ? httpErrorResponse.error.message
                  : ''
            })
          );
        }
      }
    );
  }

  deleteProfile(profile: ProfileListModel) {
    this.confirmationService.confirm({
      message: this.translocoService.translate('discoveryProfiling.listing.deleteMessage', {
        profileName: profile.name
      }),
      header: this.translocoService.translate('discoveryProfiling.listing.deleteTitle'),
      icon: 'pi pi-info-circle',
      accept: () => {
        this.profileService.deleteProfile(profile.id).subscribe(
          (response) => {
            this.loadProfileList();
          },
          (httpErrorResponse: HttpErrorResponse) => {
            let errorMsg = httpErrorResponse?.error?.message;
            if (httpErrorResponse.status === 423) {
              errorMsg = this.translocoService.translate('discoveryProfiling.listing.profileAlreadyRunning');
            } else if (httpErrorResponse.status === 404) {
              errorMsg = this.translocoService.translate('discoveryProfiling.listing.profileNotFound');
            } else if (httpErrorResponse.status === 403) {
              errorMsg = this.translocoService.translate('discoveryProfiling.listing.unauthorized');
              this.toastrService.error(errorMsg);
            }
            if (httpErrorResponse.status !== 403) {
              this.toastrService.error(errorMsg);
            }
          }
        );
      },
      reject: () => {
        console.log('Delete Cancel');
      }
    });
  }

  editProfile(profileId: string, isEditAllowed: boolean) {
    if (isEditAllowed) {
      this.router.navigateByUrl('/data-observability/data-profiling/edit/' + profileId);
    } else {
      this.toastrService.error(this.translocoService.translate('discoveryProfiling.listing.editNotAllowedError'));
    }
  }

  stopRunningProfile(runId: string) {
    const profileModel: ProfileListModel = this.profileList.find((value) => value.lastRunId === runId);
    profileModel.status = SharedConstants.STATUS.CANCEL_INITIATED;
    this.profileService.stopRunProfile(runId).subscribe(
      (response) => {
        // this is intentional
      },
      (httpErrorResponse: HttpErrorResponse) => {
        profileModel.status = SharedConstants.STATUS.INPROGRESS;
        if (httpErrorResponse.status === 400 || httpErrorResponse.status === 404 || httpErrorResponse.status === 423) {
          profileModel.status = SharedConstants.STATUS.ERROR;
          profileModel.message = httpErrorResponse.error.message;
        }
        if (httpErrorResponse.status === 404) {
          this.toastrService.error(this.translocoService.translate('discoveryProfiling.listing.profileNotFound'));
        } else if (httpErrorResponse.status === 423) {
          this.toastrService.error(
            this.translocoService.translate('discoveryProfiling.listing.profileAlreadyStopping')
          );
        } else if (httpErrorResponse.status !== 403) {
          this.toastrService.error(
            this.translocoService.translate('discoveryProfiling.listing.profileStopFail', {
              serverMessage:
                httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                  ? httpErrorResponse.error.message
                  : ''
            })
          );
        }
      }
    );
  }

  onContextMenu(rowData: ProfileListModel) {
    this.items = [
      {
        label: this.translocoService.translate('discoveryProfiling.listing.runProfile'),
        command: (click) => this.runProfile(rowData.id, rowData.name),
        disabled:
          rowData.status === SharedConstants.STATUS.INPROGRESS ||
          rowData.status === SharedConstants.STATUS.CANCEL_INITIATED ||
          rowData.status === SharedConstants.STATUS.PROCESSING
      },
      {
        label: this.translocoService.translate('discoveryProfiling.listing.stopProfile'),
        command: (click) => this.stopRunningProfile(rowData.lastRunId),
        disabled:
          rowData.status !== SharedConstants.STATUS.INPROGRESS ||
          rowData.status === SharedConstants.STATUS.CANCEL_INITIATED
      },
      {
        label: this.translocoService.translate('discoveryProfiling.listing.editMenu'),
        command: (click) => this.editProfile(rowData.id, rowData.status !== 'INPROGRESS'),
        disabled:
          rowData.status === SharedConstants.STATUS.INPROGRESS ||
          rowData.status === SharedConstants.STATUS.CANCEL_INITIATED ||
          rowData.status === SharedConstants.STATUS.PROCESSING
      },

      {
        label: this.translocoService.translate('discoveryProfiling.listing.duplicateMenu'),
        command: (click) => this.router.navigate([`/data-observability/data-profiling/copy/${rowData.id}`])
      },
      {
        label: this.translocoService.translate('discoveryProfiling.listing.deleteMenu'),
        command: (click) => this.deleteProfile(rowData),
        disabled:
          rowData.status === SharedConstants.STATUS.INPROGRESS ||
          rowData.status === SharedConstants.STATUS.CANCEL_INITIATED ||
          rowData.status === SharedConstants.STATUS.PROCESSING
      }
    ];
  }
  showScheduleSidebarEvent(rowData) {
    this.isScheduleSidebarVisible = true;
    this.scheduleType = {
      viewType: rowData.scheduleStatus,
      id: rowData.id,
      editEnabled:
        rowData.status === SharedConstants.STATUS.INPROGRESS ||
        rowData.status === SharedConstants.STATUS.CANCEL_INITIATED ||
        rowData.status === SharedConstants.STATUS.PROCESSING
          ? true
          : false,
      source: SharedConstants.SCHEDULER_SOURCE.PROFILING
    };
  }
  loadConnectionList() {
    this.fetchConnectionsInProgress = true;
    this.connectionService.getConnectionList().subscribe(
      (connectionModels: ConnectionModel[]) => {
        this.fetchConnectionsInProgress = false;
        this.connectionList = connectionModels;
      },
      (error) => {
        this.fetchConnectionsInProgress = false;
        console.log(error);
      }
    );
  }
  createConnection(connectionType?: string) {
    if (connectionType) {
      this.connectionType = connectionType;
    }
    this.showConnectionConfigureSidebar(SharedConstants.connectionConfigureModes.ADD);
  }

  showConnectionConfigureSidebar(viewType: string) {
    this.sidebarVisible = true;
    this.configureViewType = viewType;
  }

  loadProfileList() {
    this.fetchProfilesInProgress = true;
    this.profileService.getProfileList().subscribe(
      (profile: ProfileListModel[]) => {
        this.fetchProfilesInProgress = false;
        this.profileList = profile;
        this.profileList
          .filter(
            (profileModel) =>
              profileModel.status === SharedConstants.STATUS.INPROGRESS ||
              profileModel.status === SharedConstants.STATUS.CANCEL_INITIATED
          )
          .forEach((profileModel) => {
            profileModel.message = SharedConstants.STATUS.INPROGRESS;
            this.checkProfileRunStatus(profileModel.lastRunId, profileModel);
          });
      },
      (error) => {
        this.fetchProfilesInProgress = false;
        this.profileList = [];
        console.log(error);
      }
    );
  }

  private checkProfileRunStatus(id: string, profileModel: ProfileListModel) {
    const url = this.baseUrl + 'profile/runStatus?runId=' + id;
    this.sseService.getServerSentEvent(url).subscribe((data) => {
      const statusResponse: ProfileRunStatusModel = data;
      if (
        !(
          profileModel.status === SharedConstants.STATUS.CANCEL_INITIATED &&
          statusResponse.status === SharedConstants.STATUS.INPROGRESS
        )
      ) {
        profileModel.status = statusResponse.status;
      }
      if (
        statusResponse.status === SharedConstants.STATUS.SUCCESS ||
        statusResponse.status === SharedConstants.STATUS.ERROR
      ) {
        this.sseService.closeSSEConnection(url);
        profileModel.completenessPercentage = statusResponse.completenessPercentage;
        profileModel.recordsCount = statusResponse.recordsCount;
        profileModel.duration = statusResponse.duration;
        profileModel.lastRun = statusResponse.lastRun;
        profileModel.message = statusResponse.message;
        const getMatchedProfileID = this.profileList
          .map(function (eachProfile) {
            return eachProfile.id;
          })
          .indexOf(profileModel.id);
        this.profileList[getMatchedProfileID].status = SharedConstants.STATUS.SUCCESS;
        this.profileList[getMatchedProfileID].message = statusResponse.message;
        this.profileList[getMatchedProfileID].duration = statusResponse.duration;
      } else if (
        statusResponse.status === SharedConstants.STATUS.NEW ||
        statusResponse.status === SharedConstants.STATUS.CANCELLED
      ) {
        this.sseService.closeSSEConnection(url);
      } else {
        if (statusResponse.tables) {
          let message: string = '';
          statusResponse.tables.forEach((table) => (message += table.name + ': ' + table.status + '\n'));
          profileModel.message = message;
        }
      }
    });
  }
}
