(function() {
    'use strict';
    /* Domain List */
    codeathonApp.controller("domainCtrl", ['$scope', '$ajaxFactory', 'uiRouters', '$location', domainCtrl]);

    function domainCtrl($scope, $ajaxFactory, uiRouters, $location) {
        $scope.domainDataSource = [];
        $scope.itemData = {};
        $scope.isEditOrAddPage = false;
        $scope.isAddPage = false;
        $scope.domainName = "";
        $scope.description = "";
        $scope.buttonText = "";
        $scope.headerText = "";
        var userId = ""
        var domainId = "";
        var url = "";

        // redirecting to /login page
        if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        }
        
        $scope.editItem = function(item) {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = false;
            $scope.itemData = item;
            $scope.domainName = item.domainName;
            $scope.description = item.description;
            $scope.buttonText = "Update";
            $scope.headerText = "Edit";
            domainId = item.id;
        };

        $scope.addItem = function() {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = true;
            $scope.domainName = "";
            $scope.description = "";
            $scope.buttonText = "Add";
            $scope.headerText = "Create";
        };

        $scope.removeItem = function(domainId) {
            indicatorStart("Deleting Domain..");

            url = "/delete/domain/" + domainId + "/user/" + userId + "/";
            //var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'POST', {});

            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/domain/data.json', 'POST', {});

            promise.then(function(d) {
                $scope.domainDataSource = d;
                console.log('Delete Success');
				$scope.fetchDataSource();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.saveData = function(e) {
            if (Codeathon.utils.isNullOrEmpty($scope.domainName) || Codeathon.utils.isNullOrEmpty($scope.description)) {
                alert("All Fields Required");
                return;
            } else {
                var obj = {}
                obj.domainName = $scope.domainName;
                obj.description = $scope.description;

                // if isAddPage true : Adding New domain
                // if isAddPage False : Editing domain
                if ($scope.isAddPage) {
                    indicatorStart("Adding Domain..");
                    alert("Adding Domain..");
                    url = uiRouters.filepath + '/domain/data.json';
                  //  url = uiRouters.urlpath + "/add/new/domain/user/"+userId+"/";

                } else {
                    indicatorStart("Updating Domain..");
                   url = uiRouters.filepath + '/domain/data.json';
                   //   url = uiRouters.urlpath+"/modify/domain/"+domainId+"/user/"+userId+"/";

                }
                var promise = $ajaxFactory.getDataFromServer(url, 'POST', obj);

                promise.then(function(d) {
                    $scope.domainDataSource = d;
                    $scope.isEditOrAddPage = false;
                    $scope.isAddPage = false;
                    console.log('Success');

                    var obj = {};
                    obj.message = "Domain";
                    obj.content = "Success";
                    obj.eventObj = e;
                    $scope.$emit('openPopupEvent', obj);
					$scope.fetchDataSource();
                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
                promise.finally(function(d) {
                    console.log('finally block executed', d);
                    indicatorStop();
                });

            }

        }
        $scope.cancel = function() {
            $scope.isEditOrAddPage = false;
            $scope.isAddPage = false;
        }

        $scope.fetchDataSource = function() {

            var url = "/get/list/of/domain/for/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/domain/data.json', 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.domainDataSource = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        }
        $scope.fetchDataSource();
    }

})();
