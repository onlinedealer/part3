import { Mocks, Spies } from 'discovery-test';
import { of, throwError } from 'rxjs';
import { ProfilingRuleTreeNodeModel } from './profiling-rule-tree-node.model';
import { ProfilingRulesComponent } from './profiling-rules.component';

describe('ProfilingRulesComponent', () => {
  let component: ProfilingRulesComponent;

  beforeEach(() => {
    component = new ProfilingRulesComponent(
      Spies.ProfileService,
      {} as any,
      Spies.ToastrService,
      Spies.TranslateService
    );
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('test ngOnInit', () => {
    const rulesListDefaultOnlyMap = new Map<string, Map<string, any>>();

    const mockRuleListJson = Mocks.MockRulesListDefaultOnly;

    for (const ruleId in mockRuleListJson) {
      if (mockRuleListJson.hasOwnProperty(ruleId)) {
        const rulesOptionsMap = new Map<string, any>();

        for (const optionId in mockRuleListJson[ruleId]) {
          if (mockRuleListJson[ruleId].hasOwnProperty(optionId)) {
            rulesOptionsMap.set(optionId, mockRuleListJson[ruleId][optionId]);
          }
        }

        rulesListDefaultOnlyMap.set(ruleId, rulesOptionsMap);
      }
    }

    Spies.ProfileService.getRulesList.and.returnValue(of(Mocks.MockProfileRuleModels));
    spyOn(component.selectedRulesListChange, 'emit');
    component.ngOnInit();
    expect(component.loadInProgress).toBe(false);
    expect(component.selectedRulesListChange.emit).toHaveBeenCalled();
  });

  it('test ngOnInit rule loading failed', () => {
    Spies.ProfileService.getRulesList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.ngOnInit();
    expect(component.loadInProgress).toBe(false);
    expect(Spies.ToastrService.error).toHaveBeenCalled();
  });

  it('test Only Character Category Group selected', () => {
    const rulesListCharCategoryAsMap = new Map<string, Map<string, any>>();

    const mockRulesListJson = Mocks.MockRulesListCharCategory;

    for (const ruleId in mockRulesListJson) {
      if (mockRulesListJson.hasOwnProperty(ruleId)) {
        const rulesOptionsMap = new Map<string, any>();

        for (const optionId in mockRulesListJson[ruleId]) {
          if (mockRulesListJson[ruleId].hasOwnProperty(optionId)) {
            rulesOptionsMap.set(optionId, mockRulesListJson[ruleId][optionId]);
          }
        }

        rulesListCharCategoryAsMap.set(ruleId, rulesOptionsMap);
      }
    }

    const defaultRuleModel = Mocks.MockProfileRuleModels[0];
    const semanticRuleModel = Mocks.MockProfileRuleModels[1];
    const charCategoryRuleModel = Mocks.MockProfileRuleModels[2];

    const defaultTreeNode = new ProfilingRuleTreeNodeModel(defaultRuleModel, 0);
    const semanticTreeNode = new ProfilingRuleTreeNodeModel(semanticRuleModel, 1);
    const charCategoryTreeNode = new ProfilingRuleTreeNodeModel(charCategoryRuleModel, 2);

    component.ruleTreeNodes = [];
    component.ruleTreeNodes.push(defaultTreeNode);
    component.ruleTreeNodes.push(semanticTreeNode);
    component.ruleTreeNodes.push(charCategoryTreeNode);

    charCategoryTreeNode.data.selected = true;
    spyOn(component.selectedRulesListChange, 'emit');
    component.nodeClicked(charCategoryTreeNode, 0);
    expect(component.selectedRulesListChange.emit).toHaveBeenCalled();
  });

  it('test complete Semantic group selected', () => {
    const rulesListSemanticAsMap = new Map<string, Map<string, any>>();

    const mockRulesListJson = Mocks.MockRulesListSemantic;

    for (const ruleId in mockRulesListJson) {
      if (mockRulesListJson.hasOwnProperty(ruleId)) {
        const rulesOptionsMap = new Map<string, any>();

        for (const optionId in mockRulesListJson[ruleId]) {
          if (mockRulesListJson[ruleId].hasOwnProperty(optionId)) {
            rulesOptionsMap.set(optionId, mockRulesListJson[ruleId][optionId]);
          }
        }

        rulesListSemanticAsMap.set(ruleId, rulesOptionsMap);
      }
    }

    const defaultRuleModel = Mocks.MockProfileRuleModels[0];
    const semanticRuleModel = Mocks.MockProfileRuleModels[1];
    const charCategoryRuleModel = Mocks.MockProfileRuleModels[2];

    const defaultTreeNode = new ProfilingRuleTreeNodeModel(defaultRuleModel, 0);
    const semanticTreeNode = new ProfilingRuleTreeNodeModel(semanticRuleModel, 1);
    const charCategoryTreeNode = new ProfilingRuleTreeNodeModel(charCategoryRuleModel, 2);

    component.ruleTreeNodes = [];
    component.ruleTreeNodes.push(defaultTreeNode);
    component.ruleTreeNodes.push(semanticTreeNode);
    component.ruleTreeNodes.push(charCategoryTreeNode);

    semanticTreeNode.data.selected = true;
    spyOn(component.selectedRulesListChange, 'emit');
    component.nodeClicked(semanticTreeNode, 0);
    expect(component.selectedRulesListChange.emit).toHaveBeenCalled();
  });

  it('test partial Demographic types selected', () => {
    const rulesListDemographicAsMap = new Map<string, Map<string, any>>();

    const mockRulesListJson = Mocks.MockRulesListPartialDemographics;

    for (const ruleId in mockRulesListJson) {
      if (mockRulesListJson.hasOwnProperty(ruleId)) {
        const rulesOptionsMap = new Map<string, any>();

        for (const optionId in mockRulesListJson[ruleId]) {
          if (mockRulesListJson[ruleId].hasOwnProperty(optionId)) {
            rulesOptionsMap.set(optionId, mockRulesListJson[ruleId][optionId]);
          }
        }

        rulesListDemographicAsMap.set(ruleId, rulesOptionsMap);
      }
    }

    const defaultRuleModel = Mocks.MockProfileRuleModels[0];
    const semanticRuleModel = Mocks.MockProfileRuleModels[1];
    const charCategoryRuleModel = Mocks.MockProfileRuleModels[2];

    const defaultTreeNode = new ProfilingRuleTreeNodeModel(defaultRuleModel, 0);
    const semanticTreeNode = new ProfilingRuleTreeNodeModel(semanticRuleModel, 1);
    const charCategoryTreeNode = new ProfilingRuleTreeNodeModel(charCategoryRuleModel, 2);

    component.ruleTreeNodes = [];
    component.ruleTreeNodes.push(defaultTreeNode);
    component.ruleTreeNodes.push(semanticTreeNode);
    component.ruleTreeNodes.push(charCategoryTreeNode);

    let demographicTreeNode: ProfilingRuleTreeNodeModel;
    semanticTreeNode.children.forEach((childRuleTreeNode) => {
      if (childRuleTreeNode.data.id === 'DEMOGRAPHIC_ANALYSIS_RULE') {
        demographicTreeNode = childRuleTreeNode;
        childRuleTreeNode.children.forEach((demographicType) => {
          if (
            demographicType.data.id === 'TITLE' ||
            demographicType.data.id === 'FIRSTNAME' ||
            demographicType.data.id === 'LASTNAME'
          ) {
            demographicType.data.selected = true;
          }
        });
      }
    });

    spyOn(component.selectedRulesListChange, 'emit');
    component.nodeClicked(demographicTreeNode.children[0], 2);
    expect(component.selectedRulesListChange.emit).toHaveBeenCalled();
  });

  it('test all unselected after unselecting a level-1 node', () => {
    const rulesListDefaultAsMap = new Map<string, Map<string, any>>();

    const mockRulesListJson = Mocks.MockRulesListDefaultOnly;

    for (const ruleId in mockRulesListJson) {
      if (mockRulesListJson.hasOwnProperty(ruleId)) {
        const rulesOptionsMap = new Map<string, any>();

        for (const optionId in mockRulesListJson[ruleId]) {
          if (mockRulesListJson[ruleId].hasOwnProperty(optionId)) {
            rulesOptionsMap.set(optionId, mockRulesListJson[ruleId][optionId]);
          }
        }

        rulesListDefaultAsMap.set(ruleId, rulesOptionsMap);
      }
    }

    const defaultRuleModel = Mocks.MockProfileRuleModels[0];
    const semanticRuleModel = Mocks.MockProfileRuleModels[1];
    const charCategoryRuleModel = Mocks.MockProfileRuleModels[2];

    const defaultTreeNode = new ProfilingRuleTreeNodeModel(defaultRuleModel, 0);
    const semanticTreeNode = new ProfilingRuleTreeNodeModel(semanticRuleModel, 1);
    const charCategoryTreeNode = new ProfilingRuleTreeNodeModel(charCategoryRuleModel, 2);

    component.ruleTreeNodes = [];
    component.ruleTreeNodes.push(defaultTreeNode);
    component.ruleTreeNodes.push(semanticTreeNode);
    component.ruleTreeNodes.push(charCategoryTreeNode);

    spyOn(component.selectedRulesListChange, 'emit');
    component.nodeClicked(semanticTreeNode.children[0], 1);
    expect(component.selectedRulesListChange.emit).toHaveBeenCalled();
  });

  it('should test ngOnInit with ruleTreeNodes values', () => {
    const rulesConfig = Mocks.MockProfileRuleModels;
    Spies.ProfileService.getRulesList.and.returnValue(of(rulesConfig));
    spyOn(component.selectedRulesListChange, 'emit');
    component.ngOnInit();
    expect(component.ruleTreeNodes.length).toEqual(3);
    expect(component.ruleTreeNodes[0].data['id']).toEqual('DEFAULT_ANALYSIS_RULE');
    expect(component.ruleTreeNodes[2].data['id']).toEqual('CHARACTER_ANALYSIS_RULE');
    for (const [index, profileRule] of rulesConfig.entries()) {
      expect(component.ruleTreeNodes[index]).toEqual(new ProfilingRuleTreeNodeModel(profileRule, index));
    }
    expect(component['profileConfigureModel']).toBeUndefined();
  });

  it('should check load profile settings on loadProfileSettings', () => {
    const treeNode: ProfilingRuleTreeNodeModel[] = [];
    const rulesConfig = Mocks.MockProfileRuleModels;
    for (const [index, profileRule] of rulesConfig.entries()) {
      treeNode.push(new ProfilingRuleTreeNodeModel(profileRule, index));
    }
    component.ruleTreeNodes = treeNode;
    component.loadProfileSettings(Mocks.MockProfiles[0]);
    expect(component.ruleTreeNodes.length).toEqual(3);
    expect(component['profileConfigureModel']).toBeDefined();
  });

  it('should check configure rule on configureRule', () => {
    component.configureRule(new ProfilingRuleTreeNodeModel(Mocks.MockProfileRuleModels[0], 1));
    expect(component.showRuleSettingsSideBar).toBeTrue();
    expect(component.ruleModelForConfiguration).toBeDefined();
    expect(component.ruleModelForConfiguration.nodeType).toEqual('RULE');
    expect(component.ruleModelForConfiguration.selected).toBeTrue();
  });
});
