import { Injectable } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { MenuItem } from 'primeng/api';
import { SharedConstants } from './shared.constant';

@Injectable({
  providedIn: 'root'
})
export class SecondaryNavItemsService {
  navItems: MenuItem[];
  dataCatalogFlag: boolean;

  constructor(private translocoService: TranslocoService, private launchDarklyService: LaunchDarklyService) {
    this.navItems = [];
    this.dataCatalogFlag = true;
    if (this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.ALERT)) {
      this.navItems.push({
        id: 'data-alerts',
        label: this.translocoService.translate('discoveryShared.common.data-alerts'),
        icon: 'png-alert-critical-outlined png-icon-sm product-icon',
        routerLink: ['/data-observability/data-alerts']
      });
    }
    if (this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.OBSERVER)) {
      this.navItems.push({
        id: 'data-observe',
        label: this.translocoService.translate('discoveryShared.common.data-observe'),
        icon: 'png-view-observe png-icon-sm product-icon',
        routerLink: ['/data-observability/observers']
      });
    }
    this.navItems.push({
      id: 'data-profile',
      label: this.translocoService.translate('discoveryShared.common.data-profiles'),
      icon: 'png-chart-line-v1 png-icon-sm product-icon',
      routerLink: ['/data-observability/data-profiling']
    });
    if (!this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.CATALOG)) {
      this.navItems.push({
        id: 'data-connection',
        label: this.translocoService.translate('discoveryShared.common.data-connections'),
        icon: 'png-icon-sm png-connections',
        routerLink: ['/data-observability/data-connection']
      });
    }
    if (this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.CATALOG)) {
      this.navItems.push({
        id: 'do-data-connection',
        label: this.translocoService.translate('discoveryShared.common.data-shared-connections'),
        icon: 'png-icon-sm png-connections',
        routerLink: ['/data-observability/catalogs-connections']
      });
    }
    if (this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.CATALOG)) {
      this.navItems.push({
        id: 'do-data-catalogs',
        label: this.translocoService.translate('discoveryShared.common.dataCatalog'),
        icon: 'png-icon-sm png-catalog',
        routerLink: ['/data-observability/catalogs-datasets']
      });
    }
  }

  getNavItems(): MenuItem[] {
    return this.navItems;
  }

  getActiveNav(id: string): MenuItem {
    let activeMenu: MenuItem;
    for (var menuItem of this.navItems) {
      if (menuItem.id === id) {
        activeMenu = menuItem;
      }
    }
    return activeMenu;
  }
}
