import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber, isString } from "lodash";
import { OnDemandReadingRequestResult } from "../../../models/ondemandreading.model";

export class ODRReadingSimpleSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" }> = new BehaviorSubject({
        active: "",
        direction: "asc"
    } as any);

    odrReadingTableObj: OnDemandReadingRequestResult[] = [];

    public setODRReadingTable(odrReadingTableObj: OnDemandReadingRequestResult[]) {
        this.odrReadingTableObj = odrReadingTableObj;
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedODRReadingTable(): Observable<OnDemandReadingRequestResult[]> {
        return this.sortingSubject.asObservable().pipe(map(() => [...this.odrReadingTableObj].sort(this.ODRReadingComparator)));
    }

    public onSortChange(event: { active: string; direction: "asc" | "desc" }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    ODRReadingComparator = (r1: any, r2: any): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "value":
                return this.sortByNumberOverString(
                    r1.value.toString().split(" ")[0],
                    r2.value.toString().split(" ")[0],
                    directionMultiplier
                );
            case "name":
                return this.sortByString(((r1.name).replace(/\s/g, "")), ((r2.name).replace(/\s/g, "")), directionMultiplier);
            case "status":
                return this.sortByNumber(r1.status, r2.status, directionMultiplier);
            case "valueEndTime":
                return this.sortByDateEndTime(r1, r2, directionMultiplier);
            case "valueStartTime":
                return this.sortByDateStartTime(r1, r2, directionMultiplier);
            case "cumulativeValue":
                return this.sortByNumberOverString(
                    r1.cumulativeValue.toString().split(" ")[0],
                    r2.cumulativeValue.toString().split(" ")[0],
                    directionMultiplier
                );
            default:
                return 0;
        }
    };

    sortByDateEndTime(r1: any, r2: any, directionMultiplier: number) {
        if (isNumber(r1.valueEndTime) && isNumber(r2.valueEndTime)) {
            return r1.valueEndTime > r2.valueEndTime ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(r1.valueEndTime) && isNil(r2.valueEndTime)) {
            return this.sortByString(((r1.name).replace(/\s/g, "")), ((r2.name).replace(/\s/g, "")), 1);
        }

        if (isNil(r1.valueEndTime)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.valueEndTime)) {
            return directionMultiplier;
        }

        return 0;
    }

    sortByDateStartTime(r1: any, r2: any, directionMultiplier: number) {
        if (isNumber(r1.valueStartTime) && isNumber(r2.valueStartTime)) {
            return r1.valueStartTime > r2.valueStartTime ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(r1.valueStartTime) && isNil(r2.valueStartTime)) {
            return this.sortByString(((r1.name).replace(/\s/g, "")), ((r2.name).replace(/\s/g, "")), 1);
        }

        if (isNil(r1.valueStartTime)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.valueStartTime)) {
            return directionMultiplier;
        }

        return 0;
    }

    sortByNumberOverString(value1: string | undefined, value2: string | undefined, directionMultiplier: number) {
        if (!isNaN(Number(value1)) && !isNaN(Number(value2))) {
            return Number(value1) > Number(value2) ? directionMultiplier : -1 * directionMultiplier;
        }
        if (!isNaN(Number(value1)) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && !isNaN(Number(value2))) {
            return directionMultiplier;
        }

        if (!isNaN(Number(value2)) || isNil(value2)) {
            return directionMultiplier;
        }

        if (!isNaN(Number(value1)) || isNil(value1)) {
            return -1 * directionMultiplier;
        }
        if (isString(value1) && isString(value2)) {
            return this.sortByString(value1, value2, directionMultiplier);
        }
        return value1.toUpperCase() < value2.toUpperCase() ? directionMultiplier : -1 * directionMultiplier;
    }

    sortByString(value1: string | undefined, value2: string | undefined, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }
        return directionMultiplier;
    }

    sortByNumber(value1: any, value2: any, directionMultiplier: number) {
        if (isNumber(value1) && isNumber(value2)) {
            return value1 > value2 ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNumber(value1) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && isNumber(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value1) || isNil(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value2) || isNil(value1)) {
            return -1 * directionMultiplier;
        }
        return 0;
    }
}
