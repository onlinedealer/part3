import { TestBed } from '@angular/core/testing';
import { LoadedPipelineValidationService } from './loaded-pipeline-validation.service';
import { Pipeline } from './pipeline';

describe('PipelineValidationService', () => {
  let service: LoadedPipelineValidationService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LoadedPipelineValidationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('isGeneralStepValid()', () => {
    it('should always return value', () => {
      // ... as pipeline cannot be saved without a valid General step
      expect(service.isGeneralStepValid()).toBeTruthy();
    });
  });

  describe('isConnectionsStepValid()', () => {
    it('should return invalid if source is not defined', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        target: {
          dataConnection: {}
        }
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isConnectionsStepValid()).toBeFalsy();
    });
    it('should return invalid if target is not defined', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        source: {
          dataConnection: {}
        }
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isConnectionsStepValid()).toBeFalsy();
    });
    it('should return valid if source and target are defined', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        source: {
          dataConnection: {}
        },
        target: {
          dataConnection: {}
        }
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isConnectionsStepValid()).toBeTruthy();
    });
  });

  describe('isDataStepValid()', () => {
    it('it should return invalid if no tables have been saved', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        source: {
          selectedTables: []
        }
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isDataStepValid()).toBeFalsy();
    });
    it('it should return invalid if source has not been defined', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION'
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isDataStepValid()).toBeFalsy();
    });
    it('it should return invalid if selectedTables has not been defined', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        source: {}
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isDataStepValid()).toBeFalsy();
    });
    it('it should return valid if tables have been saved', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        source: {
          selectedTables: [{ key: 'key' }]
        }
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isDataStepValid()).toBeTruthy();
    });
  });

  describe('isMappingStepValid', () => {
    it('it should return invalid if selectedTables has not been defined', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        tableMapping: []
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isMappingStepValid()).toBeFalsy();
    });
    it('it should return valid if tables have been saved', () => {
      const pipeline = {
        name: 'pipeline name',
        description: '',
        dataFlowType: 'REPLICATION',
        tableMapping: [
          {
            id: 'mapping_30vnpl009jgz',
            key: 'HR||COUNTRIES',
            value: 'COUNTRIES',
            hasCustomColMappings: false,
            type: 'TARGET_DOES_NOT_EXIST'
          }
        ]
      } as Pipeline;
      service.setPipeline(pipeline);

      expect(service.isMappingStepValid()).toBeTruthy();
    });
  });
});
