import { BehaviorSubject, Observable, combineLatest } from "rxjs";
import { DeviceTransformerFactor } from "../../../models/meterconnection.model";
import { map } from "rxjs/operators";
import { isNil, isNumber, isString } from "lodash";

export class SSTransformerSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: string }> = new BehaviorSubject({
        active: "factor",
        direction: "asc"
    });

    public setTransformerFactors(factors$: Observable<DeviceTransformerFactor[]>) {
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedTransformerFactorsData(
        factors$: Observable<DeviceTransformerFactor[]>
    ): Observable<DeviceTransformerFactor[]> {
        return combineLatest([this.sortingSubject.asObservable(), factors$]).pipe(
            map(([sortingValues, factors]) => (sortingValues.direction === "" ? factors : [...factors].sort(this.factorsComparator)))
        );
    }

    public onSortEvent(event: { active: string; direction: string }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    factorsComparator = (factors1: any, factors2: any): any => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "factor":
                return this.sortByNumber(parseInt(factors1.factor, 10), parseInt(factors2.factor, 10), directionMultiplier);
            case "kind":
                return this.sortByString(factors1.kind, factors2.kind, directionMultiplier);
            case "usage":
                return this.sortByString(factors1.usage, factors2.usage, directionMultiplier);
            case "validFrom":
                return this.validFromSortin(factors1, factors2, directionMultiplier);
            case "validUntil":
                return this.validUntillSorting(factors1, factors2, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByString(value1: string | null | undefined, value2: string | null | undefined, directionMultiplier: number) {
        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }
        return directionMultiplier;
    }

    sortByNumber(value1: number, value2: number, directionMultiplier: number) {
        if (isNumber(value1) && isNumber(value2)) {
            return value1 > value2 ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNumber(value1) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && isNumber(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value1) || isNil(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value2) || isNil(value1)) {
            return -1 * directionMultiplier;
        }
        return 0;
    }

    validFromSortin(factorsDate1: any, factorsDate2: any, directionMultiplier: number) {
        if (isNumber(factorsDate1.validFrom) && isNumber(factorsDate2.validFrom)) {
            return factorsDate1.validFrom > factorsDate2.validFrom ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(factorsDate1.validFrom) && isNil(factorsDate2.validFrom)) {
            return;
        }

        if (isNil(factorsDate1.validFrom)) {
            return -1 * directionMultiplier;
        }

        if (isNil(factorsDate2.validFrom)) {
            return directionMultiplier;
        }
        return 0;
    }

    validUntillSorting(factorsDate1: any, factorsDate2: any, directionMultiplier: number) {
        if (isNumber(factorsDate1.validUntil) && isNumber(factorsDate2.validUntil)) {
            return factorsDate1.validUntil > factorsDate2.validUntil ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(factorsDate1.validUntil) && isNil(factorsDate2.validUntil)) {
            return;
        }

        if (isNil(factorsDate1.validUntil)) {
            return -1 * directionMultiplier;
        }

        if (isNil(factorsDate2.validUntil)) {
            return directionMultiplier;
        }
        return 0;
    }
}
