import { ActivatedRouteSnapshot, RouterStateSnapshot, Params, UrlSegment } from "@angular/router";
import { createFeatureSelector, ActionReducerMap } from "@ngrx/store";

import * as fromRouter from "@ngrx/router-store";
import * as fromUI from "./ui.reducer";
import * as fromSecurity from "./security.reducer";
import * as fromConfigurations from "./configurations.reducer";
import * as fromUserSettings from "./user-settings.reducer";
import * as fromNetworkSpecificConfig from "./network-specific-config.reducer";
import * as fromEnvironmentIndicator from "./environment-indicator.reducer";

export interface RouterStateUrl {
    url: string;
    segments: string[];
    lastSegment: string;
    queryParams: Params;
    params: Params;
}

export interface State {
    router: fromRouter.RouterReducerState<RouterStateUrl>;
    ui: fromUI.UiState;
    security: fromSecurity.SecurityState;
    configurations: fromConfigurations.ConfigurationsState;
    userSettings: fromUserSettings.UserSettingsState;
    networkSpecificConfig: fromNetworkSpecificConfig.NetworkSpecificConfigurationState;
    environmentIndicator: fromEnvironmentIndicator.EnvironmentIndicatorState;
}

export const reducers: ActionReducerMap<State> = {
    router: fromRouter.routerReducer,
    ui: fromUI.reducer,
    security: fromSecurity.reducer,
    configurations: fromConfigurations.reducer,
    userSettings: fromUserSettings.reducer,
    networkSpecificConfig: fromNetworkSpecificConfig.reducer,
    environmentIndicator: fromEnvironmentIndicator.reducer
};

export const getRouterState = createFeatureSelector<fromRouter.RouterReducerState<RouterStateUrl>>("router");

export const getUIState = createFeatureSelector<fromUI.UiState>("ui");

export const getSecurityState = createFeatureSelector<fromSecurity.SecurityState>("security");

export const getConfigurationsState = createFeatureSelector<fromConfigurations.ConfigurationsState>("configurations");

export const getUserSettingsState = createFeatureSelector<fromUserSettings.UserSettingsState>("userSettings");

export const getNetworkSpecificConfigState = createFeatureSelector<fromNetworkSpecificConfig.NetworkSpecificConfigurationState>(
    "networkSpecificConfig"
);

export const getEnvironmentIndicatorState =
createFeatureSelector<fromEnvironmentIndicator.EnvironmentIndicatorState>(
    "environmentIndicator"
);

export class CustomSerializer implements fromRouter.RouterStateSerializer<RouterStateUrl> {
    serialize(routerState: RouterStateSnapshot): RouterStateUrl {
        const { url } = routerState;
        const { queryParams } = routerState.root;

        let state: ActivatedRouteSnapshot = routerState.root;
        let params = {};
        const segments = [];
        let lastSegment = "";

        while (state.firstChild) {
            state = state.firstChild;
            params = {
                ...params,
                ...state.params
            };

            if (state.url[0] && state.url[0].path && state.url[0].path.length > 0) {
                const segment = state.url[0].path;
                segments.push(segment);
                lastSegment = segment;
            }
        }

        return { url, segments, lastSegment, queryParams, params };
    }
}
