(function () {
    'use strict';

    angular.module('arm').controller('calculatorController', ['$scope', '$state','$timeout','$q','$ionicPopover','$ionicModal', calculatorController]);

    function calculatorController($scope, $state, $timeout, $q,$ionicPopover,$ionicModal) {
		$scope.title= "DBR Calculator";
		
		//
		$scope.objCalculate= {salary:'',emi:'',ccLimit:''};		
		
		$scope.counter = 1;
		$scope.EMIrows = [];
		$scope.addEMIRow = function($index) {	
			var obj=new Object();
			obj.id=$scope.counter;
			obj.value='';
			$scope.EMIrows.push(obj);
			$scope.counter++;			
		}		  

		//DBR = sum of liabilities (5% of credit cards + EMI) divided by Salary
		$scope.DBR = 0;
		$scope.onCalc = function() {
			var totalEMI=0;
			for(var i=0; i<$scope.EMIrows.length; i++) {
				 totalEMI+= parseInt($scope.EMIrows[i].value);
			}
			if ($scope.objCalculate.salary<=0) {
				$scope.objCalculate.salary ='';
				return;
			} else {
				$scope.DBR = (($scope.objCalculate.ccLimit+totalEMI)*.05+$scope.objCalculate.emi)/$scope.objCalculate.salary;
			}			
		};
		$scope.onClear = function() {
			$scope.objCalculate.DBR = 0;
			$scope.objCalculate.ccLimit = '';
			$scope.objCalculate.emi = '';
			$scope.objCalculate.salary = '';
			for(var i=0; i<$scope.EMIrows.length; i++) {
				 $scope.EMIrows[i].value = '';
			}			
		};
		
		$scope.removeEMIRow = function(index){
			//console.log(index);
			$scope.EMIrows.splice(index, 1);
		}; 
		  
		//
		$scope.objCalculate= {Turnover:'',priAmount:'',prRate:'',tenure: ''};	
		
		$scope.formResult = function () {
			$scope.resultshow= true;
		};
		$scope.clearForm = function() {
			$scope.objCalculate.Turnover = null;
			$scope.objCalculate.priAmount = null;
			$scope.objCalculate.prRate = null;
			$scope.objCalculate.tenure = null;
			$scope.resultshow = false;
		}
		
		//
	};
})();



