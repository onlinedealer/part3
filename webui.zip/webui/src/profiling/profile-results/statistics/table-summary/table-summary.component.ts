import { Component, Input } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ProfileResultsService } from 'profiling/profile-results/profile-results.service';
import { TreePath } from 'profiling/profile-results/tree-path.model';

@Component({
  selector: 'discovery-table-summary',
  templateUrl: './table-summary.component.html',
  styleUrls: ['./table-summary.component.css']
})
export class TableSummaryComponent {
  _treePath: TreePath;
  data: any[];
  cols: any[];
  defaultSort: string;
  get treePath(): TreePath {
    return this._treePath;
  }
  @Input()
  set treePath(val: TreePath) {
    this._treePath = val;
    this.loadData();
  }
  constructor(
    private profileResultsService: ProfileResultsService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}

  loadData(): void {
    const { headers, data } = this.profileResultsService.getTableSummary(this.treePath);
    this.cols = headers;
    this.data = data;
  }

  tableRowClick(rowData) {
    this.router.navigate([], {
      relativeTo: this.activatedRoute,
      queryParams: {
        runId: this.treePath.runId,
        tableName: this.treePath.tableName.name,
        columnName: rowData.column
      }
    });
  }
}
