var widget = angular.module('app', ['ui.router', 'ui.bootstrap']);

(function() {
    'use strict';

    widget.config(function($stateProvider, $urlRouterProvider, uiRouters) {
        $urlRouterProvider.otherwise('/');

        $stateProvider
            .state("home", {
                url: "/",
                templateUrl: uiRouters.directivesHtmlPath + '/home.html',
                controller: 'homeCtrl'
            }).state("details", {
                url: "/details/{id}",
                params: {
                    obj: null
                },
                templateUrl: uiRouters.directivesHtmlPath + '/home.html',
                controller: 'homeCtrl'
            }).state("edit", {
                url: "/addOrEdit",
                params: {
                    obj: null
                },
                templateUrl: uiRouters.directivesHtmlPath + '/edit.html',
                controller: 'editCtrl'
            }).state("add", {
                url: "/add",
                templateUrl: uiRouters.directivesHtmlPath + '/add.html',
                controller: 'addCtrl'
            });
    });
    widget.run(['$rootScope', myRunFn]);

    function myRunFn($rootScope) {
        localStorage.clear();
    }

})();