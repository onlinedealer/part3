import { noop } from '../noop.model';
import { DialogService } from './dialog.service';

describe('DialogService', () => {
  let service: DialogService;
  let modal: any;

  beforeEach(() => {
    modal = jasmine.createSpyObj('NgbModal', ['open']);
    modal.open.and.returnValue({
      componentInstance: {},
      result: { then: noop }
    });
    service = new DialogService(modal);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('can show ok dialog', () => {
    service.ok('title', 'message');
    expect(modal.open).toHaveBeenCalled();
  });
});
