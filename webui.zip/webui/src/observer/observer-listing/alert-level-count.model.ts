export class AlertLevelCountModel {
  warningCount: number;
  criticalCount: number;
  noAlertsCount: number;
}
