import { TestBed, inject } from '@angular/core/testing';

import { GetDigitalProfileService } from './get-digital-profile.service';

describe('GetDigitalProfileService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [GetDigitalProfileService]
    });
  });

  it('should be created', inject([GetDigitalProfileService], (service: GetDigitalProfileService) => {
    expect(service).toBeTruthy();
  }));
});
