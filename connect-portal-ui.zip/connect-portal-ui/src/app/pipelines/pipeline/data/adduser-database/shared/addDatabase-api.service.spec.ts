import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AddDatabase } from './addDatabase';
import { AddDatabaseApiService } from './addDatabase-api.service';

describe('AddDatabaseService', () => {
  let add: AddDatabaseApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  const mockAddDatabase: AddDatabase = {
    dataConnectionId: '1',
    userDataBaseNames: ['AUDSYS', 'DBTESTER'],
    adminUserId: 'sa',
    adminUserPassword: '***'
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    add = TestBed.inject(AddDatabaseApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(add).toBeTruthy();
  });

  it('should send details for prepareUserdatabase', () => {
    let actualResponse;
    add.add(mockAddDatabase).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne('/api/v1/metadata/prepareDatabases');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(mockAddDatabase);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });
});
