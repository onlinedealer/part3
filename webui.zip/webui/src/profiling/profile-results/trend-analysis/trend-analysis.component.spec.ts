import { TrendAnalysisComponent } from './trend-analysis.component';
import { Mocks, Spies } from 'discovery-test';
import { of, throwError } from 'rxjs';
import { ProfileMetadataModel } from '../profile-metadata.model';
import { TreePath } from '../tree-path.model';
import { TreeTableModel } from '../tree-table.model';

describe('TrendAnalysisComponent', () => {
  let component: TrendAnalysisComponent;

  beforeEach(() => {
    Spies.init();
    component = new TrendAnalysisComponent(Spies.eventBusService, Spies.ProfileResultsService, Spies.ToastrService);
    component.treePath = new TreePath();
    component.treePath.treeData = new TreeTableModel();
    component.profileMetadata = {
      source: 'snowflake',
      sourceType: 'DBMS',
      host: 'syncsort_partner.us-east-1.snowflakecomputing.com',
      db: 'PROFILE_SAMPLE_DATA',
      schema: 'PUBLIC'
    } as ProfileMetadataModel;
    component.graphTimeframe = 'week';
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load trends on loadData', () => {
    component.statistic = 'Complete';
    const response = [
      {
        startTime: '2022-08-08T06:43:53.764Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T11:14:45.386Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T12:15:54.707Z',
        value: '0.0'
      }
    ];
    Spies.ProfileResultsService.getTrendsHistory.and.returnValue(of(response));
    component.ngOnInit();
    expect(component.trendData.length).toBe(3);
  });

  it('should check loadData on api response failure', () => {
    component.statistic = 'Complete';
    Spies.ProfileResultsService.getTrendsHistory.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.loadData();
    expect(Spies.ToastrService.error).toHaveBeenCalled;
  });

  it('should check emptyTrends', () => {
    component.statistic = 'Complete';
    component.trendData = [
      {
        startTime: '2022-08-08T06:43:53.764Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T11:14:45.386Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T12:15:54.707Z',
        value: '0.0'
      }
    ];
    component.emptyTrends();
    expect(component.trendData.length).toBe(0);
  });

  it('should check updateTrends', () => {
    component.statistic = 'Complete';
    Spies.ProfileResultsService.getTrendsHistory.and.returnValue(of([]));
    const event = { target: { value: 'month' } };
    component.updateTrends(event);
    expect(component.graphTimeframe).toBe('month');
  });
});
