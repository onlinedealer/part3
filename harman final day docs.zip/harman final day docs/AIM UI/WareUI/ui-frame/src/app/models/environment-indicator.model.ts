export interface EnvironmentIndicator {
    text: string;
    textColor: string;
    textBoxColor: string;
}
