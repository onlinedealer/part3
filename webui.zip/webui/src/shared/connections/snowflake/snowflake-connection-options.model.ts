export enum SnowflakeConnectionOptionsModel {
  account = 'account',
  schema = 'schema',
  db = 'db',
  warehouse = 'warehouse',
  role = 'role',
  password = 'password',
  user = 'user'
}
