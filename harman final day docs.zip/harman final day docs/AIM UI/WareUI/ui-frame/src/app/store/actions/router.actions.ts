import { createAction, props } from "@ngrx/store";
import { NavigationExtras } from "@angular/router";

export const Navigate = createAction("[Router] Navigate", props<{ commands: any[]; query?: object; extras?: NavigationExtras }>());
export const NavigateURL = createAction("[Router] Navigate to URL", props<{ url: string }>());
export const Back = createAction("[Router] Back");
export const Forward = createAction("[Router] Forward");
export const NoOperation = createAction("[Router] No Operation");
