var fileuploader = angular.module('app', ['ngRoute', 'ui.bootstrap', 'ngAnimate', 'pdf', 'ngTable', 'bootstrapLightbox']);

(function() {
    'use strict';
    fileuploader.config(['$httpProvider', function($httpProvider) {
        //initialize get if not there
        if (!$httpProvider.defaults.headers.get) {
            $httpProvider.defaults.headers.get = {};
        }

        // Answer edited to include suggestions from comments
        // because previous version of code introduced browser-related errors

        //disable IE ajax request caching
        $httpProvider.defaults.headers.get['If-Modified-Since'] = '0';
        // extra
        $httpProvider.defaults.headers.get['Cache-Control'] = 'no-cache';
        $httpProvider.defaults.headers.get['Pragma'] = 'no-cache';
    }]);
    fileuploader.config(['$routeProvider', 'uiRouters', myConfigFn]);

    function myConfigFn($routeProvider, uiRouters) {

        $routeProvider.
        when(uiRouters.login, {
            templateUrl: uiRouters.directivesHtmlPath + '/login.html',
            controller: 'loginCtrl'
        }).
        when(uiRouters.home, {
            templateUrl: uiRouters.directivesHtmlPath + '/home.html',
            controller: 'homeCtrl'
        }).
        when(uiRouters.dashboard, {
            templateUrl: uiRouters.directivesHtmlPath + '/dashboard.html',
            controller: 'dashboardCtrl'
        }).
        otherwise({
            redirectTo: uiRouters.login
        });
    }

    fileuploader.run(['$rootScope', '$log', '$ajaxFactory', 'uiRouters', myRunFn]);

    function myRunFn($rootScope, $log, $ajaxFactory, uiRouters) {
        $log.debug('Uploader app started.');
        $rootScope.selectedId = -1;
        $rootScope.dropdownselect1 = "";
        $rootScope.globalId = "";
    }

})();