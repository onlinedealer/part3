export interface MeasuredQuantity {
    measuredQuantityId: number;
    name: string;
    identifier: string;
    description: string;
}

export interface MeasuredAttribute {
    measuredAttributeId: number;
    defaultForProfile?: boolean;
    identifier?: string;
    name: string;
    description: string;
    measuredQuantity: MeasuredQuantity;
}
