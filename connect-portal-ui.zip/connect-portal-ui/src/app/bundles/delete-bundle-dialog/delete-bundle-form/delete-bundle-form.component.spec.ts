import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { DeleteBundleFormComponent } from './delete-bundle-form.component';

describe('DeleteBundleComponent', () => {
  let component: DeleteBundleFormComponent;
  let fixture: ComponentFixture<DeleteBundleFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [DeleteBundleFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteBundleFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return appropriate verb', () => {
    component.bundlesCount = 1;
    expect(component.pluralOrSingularVerb).toBe('bundles.STOP_BUNDLE.BUNDLE');
    component.bundlesCount = 10;
    expect(component.pluralOrSingularVerb).toBe('bundles.STOP_BUNDLE.BUNDLES');
  });
});
