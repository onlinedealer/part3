/*
    profileDataSelectedDates$: Observable<any> = this.store.select(fromProfileData.getSelectedProfileDataFirstAndLastDatesWithOutFilter);

    meteringType!: string;
    meteringPreviousDate!: any;
    metering!: MeteringVO;
    showMeteringsAsTable = true;
    showMeteringsAsChart = false;
    showMeteringsAsSummary = false;
    meteringDataSub!: Subscription;
    detailsExpanded = false;
    exportCsvData: any;
    summaryViewTableHeader: any;
    summaryViewTableValues: any;
    summaryViewTableLabels: any;
    summaryViewHeader: any;
    summaryViewValues: any;
    summaryViewSubscription!: Subscription;
    noDataToExport = false;

    observedPeriod!: string;
    additionalMeteringIds!: number[];
    from!: number;
    until!: number;

    perioidLabel$: Observable<string>;
    selectedMeteringName!: string | undefined;
    meteringArrayData: any;

    onChangeDates(event: DatesParams): void {
        if (!event) {
            return;
        }
        if (event.interval) {
            this.store.dispatch(ChartActions.changeChartObservedPeriod({ observedPeriod: event.interval }));
        }
        this.loadNewData(event);
    }

    loadNewData(params: DatesParams): void {
        this.from = params.from;
        this.until = params.until;
        const combinedIds = [this.metering.id, ...this.additionalMeteringIds];
        if (this.metering.periodLength === "PERIODIC") {
            this.meteringType = "PERIODIC";
            this.store.dispatch(
                new periodicDataAction.LoadPeriodicData({
                    meteringId: this.metering.id,
                    from: params.from,
                    until: params.until
                })
            );
        } else {
            this.meteringType = "PROFILE";
            this.store.dispatch(
                new profileDataAction.LoadProfileData({
                    profileMeteringId: combinedIds,
                    from: params.from,
                    until: params.until
                })
            );
            this.store.dispatch(chartActions.fetchChartData({ meteringIds: combinedIds, from: params.from, until: params.until }));
        }
    }

    onPeriodChange(period: PeriodTypes) {
        this.store.dispatch(chartActions.changeChartPerioid({ period }));
    }

}
*/
