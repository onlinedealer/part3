import { Account } from '@precisely/prism-ng/cloud';
import { AuthenticationService } from './authentication.service';
import { of } from 'rxjs';
import { Spies } from 'discovery-test';

describe('AuthenticationService', () => {
  let service: AuthenticationService;
  let oidc: any;
  let accounts: any;
  let account: Account;

  beforeEach(() => {
    Spies.init();
    account = {
      id: '1',
      accountName: 'test account',
      companyName: 'some company',
      owner: 'foo@bar.com',
      linkedAccountId: 'abc'
    };
    oidc = jasmine.createSpyObj('OpenIdConnectService', [
      'getCurrentWorkspaceId',
      'getFullName',
      'getClientRoles',
      'getToken',
      'logoff',
      'getEmail'
    ]);
    oidc.getFullName.and.returnValue('Test User');
    oidc.getClientRoles.and.returnValue(['admin']);
    oidc.getCurrentWorkspaceId.and.returnValue('dummyId');
    oidc.getEmail.and.returnValue('test@mail.com');
    oidc.logoff.and.returnValue();
    accounts = jasmine.createSpyObj('AccountsService', ['getAccount']);
    accounts.getAccount.and.returnValue(of(account));
    service = new AuthenticationService(oidc);
  });

  it('should be created', () => {
    expect(service).toBeDefined();
  });

  it('get user info', () => {
    expect(service.fullName()).toBe('Test User');
    expect(service.getRoles()[0]).toBe('admin');
  });

  it('should check get account id and get role function', () => {
    expect(service.getRoles().length).toBe(1);
    expect(service.getAccountId()).toBe('dummyId');
    expect(oidc.getClientRoles.calls.count()).toBe(1);
  });

  it('should check logout function call', () => {
    service.logout();
    expect(oidc.logoff.calls.count()).toBe(1);
  });
  it('should check logout function call', () => {
    const user_email = service.getEmail();
    expect(user_email).toBe('test@mail.com');
  });
});
