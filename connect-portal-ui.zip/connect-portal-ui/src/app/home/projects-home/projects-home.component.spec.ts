import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProgressIndicatorStateService } from '@shared/components/progress-indicator/progress-indicator-state.service';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { ProjectSidebarComponent } from 'src/app/projects/project-sidebar/project-sidebar.component';

import { ProjectsHomeComponent } from './projects-home.component';

describe('ProjectsHomeComponent', () => {
  let component: ProjectsHomeComponent;
  let fixture: ComponentFixture<ProjectsHomeComponent>;
  let progressIndicatorStateService: ProgressIndicatorStateService;

  @Component({
    selector: 'p-connect-project-sidebar',
    template: '',
    providers: [
      {
        provide: ProjectSidebarComponent,
        useClass: MockProjectSidebarComponent
      }
    ]
  })
  class MockProjectSidebarComponent {
    open() {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      providers: [ProgressIndicatorStateService],
      declarations: [ProjectsHomeComponent, MockProjectSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectsHomeComponent);
    progressIndicatorStateService = TestBed.inject(ProgressIndicatorStateService);
    spyOn(progressIndicatorStateService, 'setIsValid').and.returnValue();
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open project sidebar when add project button is clicked', () => {
    spyOn(component.projectSidebarComponent, 'open').and.returnValue();
    component.openProjectSidebar();
    expect(component.projectSidebarComponent.open).toHaveBeenCalled();
  });

  it('should set step to valid when project has been added', () => {
    component.projectSavedEvent();
    expect(progressIndicatorStateService.setIsValid).toHaveBeenCalled();
  });
});
