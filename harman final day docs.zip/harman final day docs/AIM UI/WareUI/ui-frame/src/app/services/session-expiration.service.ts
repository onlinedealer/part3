import { Injectable } from "@angular/core";
import { LocalStorageService } from "./local-storage.service";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { State } from "../store/reducers";
import { Store } from "@ngrx/store";
import { Subscription } from "rxjs";
import { TimeoutDialogComponent } from "../components/timeout-dialog/timeout-dialog.component";
import * as SecurityActions from "../store/actions/security.actions";

@Injectable({
    providedIn: "root"
})
export class SessionExpirationService {
    dialogRef!: MatDialogRef<TimeoutDialogComponent>;
    dialogCloseSubscription!: Subscription;

    constructor(private store: Store<State>, public dialog: MatDialog, private localStorageService: LocalStorageService) {}

    showSessionExpiratingDialog() {
        this.dialogRef = this.dialog.open(TimeoutDialogComponent, {
            autoFocus: true,
            disableClose: true,
            hasBackdrop: true,
            restoreFocus: true,
            width: "600px"
        });

        this.dialogCloseSubscription = this.dialogRef.afterClosed().subscribe(result => this.closeDialogWithAction(result));
    }

    closeDialogWithAction(result: string) {
        if (result === "signOut") {
            this.localStorageService.removeLocalStorageItem("localUserSettings");
            this.store.dispatch(SecurityActions.Logout());
        }

        this.store.dispatch(SecurityActions.ClosedTimeoutDialog());

        this.localStorageService.writeDialogClosedEventToLocalStorage();

        if (this.dialogCloseSubscription) {
            this.dialogCloseSubscription.unsubscribe();
        }
    }

    closeDialogIfOpen() {
        if (this.dialogRef) {
            this.dialogRef.close();
        }
    }
}
