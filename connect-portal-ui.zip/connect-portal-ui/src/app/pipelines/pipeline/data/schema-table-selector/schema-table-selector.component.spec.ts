import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, Input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { of, throwError } from 'rxjs';
import { Connection } from '../../../../connections/shared/connection';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { DatasourceEntitySelectorComponent } from './datasource-entity-selector/datasource-entity-selector.component';
import { EntityCardComponent } from './datasource-entity-selector/entity-card/entity-card.component';
import { EntityDataModel } from './datasource-entity-selector/entity-card/entity-data-model';
import { FilterComponent } from '../../../../shared/components/filter/filter.component';
import { ProgressSpinnerComponent } from '../../../../shared/components/progress-spinner/progress-spinner.component';
import { MetadataApiService } from './metadata-api.service';
import { SchemaModel, TableModel } from './schema-table-selector';
import { SchemaTableSelectorComponent } from './schema-table-selector.component';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { Pipeline, PIPELINE_ENTITY_TYPE, SelectedTables } from '../../shared/pipeline';
import { DropdownOptionsModel } from './datasource-entity-selector/dropdown-options.model';
import { ServiceInjector } from '../../../../shared/services/service.injector';
import { FeatureFlagService } from '../../../../shared/services/feature-flag.service';
import { CatalogMetadataApiService } from './catalog-metadata-api.service';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogSchema } from 'src/app/connections/catalogs/shared/catalog-schema';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { SavedSchema } from './saved-schema';
import { CatalogService } from 'dqcore-catalog';
import {
  CatalogServiceStub,
  scheduledPiplelineMock,
  schemaResponse,
  tablesResponse,
  selectedSchema
} from '../../../../../../testing/catalog-service-stub';

@Component({
  selector: 'p-connect-entity-card',
  template: '',
  providers: [{ provide: EntityCardComponent, useClass: MockEntityCardComponent }]
})
class MockEntityCardComponent {
  @Input() headerText: string;
  @Input() showFilter = true;
  @Input() filterPlaceHolder: string;
  @Input() allowSelection = true;
  @Input() cardDataModel: EntityDataModel;
  @Input() apiData = [];
  @Input() isLoading = false;
  @Input() filterFields: string[];
  @Input() selectedData: any;
  @Input() emptyMessage: string;
  @Input() noResultsFoundMessage: string;
  @Input() errorMessage: string;
  @Input() dropdownModel: DropdownOptionsModel;
}

describe('SchemaTableSelectorComponent', () => {
  let component: SchemaTableSelectorComponent;
  let fixture: ComponentFixture<SchemaTableSelectorComponent>;
  let metadataApiService: MetadataApiService;
  let pipelineEntityService: PipelineEntityService;
  let catalogService: CatalogService;
  let catalogMetadataApiService: CatalogMetadataApiService;
  let featureFlagService: FeatureFlagService;
  let catalogApiService: CatalogApiService;

  const mockLaunchDarklyService = jasmine.createSpyObj({
    dispose: () => of(),
    identify: () => of(),
    variation: () => {}
  });

  const mockPipeline = {
    projectId: 'abcd',
    dataFlowType: 'SYNCHRONIZE',
    source: {
      dataConnection: { id: 'abcd', connectionType: 'ORACLE' }
    },
    id: 'mockPipeline'
  } as Pipeline;
  const mockPipelineIBMi = {
    projectId: 'efgh',
    id: 'mockPipelineIBMi',
    dataFlowType: 'SYNCHRONIZE',
    source: {
      dataConnection: { id: 'efgh', connectionType: 'DB2I' }
    },
    properties: [{ key: 'IBMI_JOURNAL_NAME', value: 'journal1' }]
  } as Pipeline;
  const mockSchemas = [
    { name: 'Corrina', tableCount: 0, children: [] },
    { name: 'Lane', tableCount: 0, children: [] }
  ];
  const mockTables = [
    { name: 'Table1', journal: 'journal1' },
    { name: 'Table2', journal: 'journal2' }
  ];
  const mockColumns = [
    { name: 'Keylex', dataType: 'long', isPrimaryKey: false },
    { name: 'Cardguard', dataType: 'double', isPrimaryKey: false }
  ];

  const mockJournals: string[] = ['journal1', 'journal2'];
  const mockDefaultLogReader = {
    name: 'LGNAME1',
    journalName: 'journal1',
    parameters: [
      {
        key: 'REP_CLEAR_PF_MEMBER',
        value: 'Y'
      },
      {
        key: 'DEDICATED_QUEUE',
        value: 'Y'
      },
      {
        key: 'COMMIT_WAIT_TIME',
        value: '2'
      },
      {
        key: 'READER_WAIT_TIME',
        value: '1'
      },
      {
        key: 'UPDATE_STATS_FREQ',
        value: '60'
      },
      {
        key: 'MESSAGE_CHECK_FREQ',
        value: '20'
      },
      {
        key: 'SUBS_BIN_0',
        value: ''
      },
      {
        key: 'DEL_JRN_RCV',
        value: 'Y'
      },
      {
        key: 'KEEP_UNSAVED_JRN_RCV',
        value: 'Y'
      },
      {
        key: 'KEEP_JRN_RCV',
        value: '2'
      },
      {
        key: 'TRACING_TABLE',
        value: '3'
      },
      {
        key: 'TRACING_CONSOLE',
        value: '0'
      },
      {
        key: 'TRACING_LOG_FILE',
        value: '4'
      },
      {
        key: 'TRACING_MAX_NB_LOG_CREATED',
        value: '10'
      },
      {
        key: 'TRACING_LOG_INTERVAL',
        value: '3'
      },
      {
        key: 'TRACING_LOG_SIZE',
        value: '10'
      },
      {
        key: 'TRACING_SQL_BASE_TBL_REF',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_SHADOW_TBL_REF',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_CONFLICT_DET_AND_RES',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_FROM_MESS_SYSTEM',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_ALL_OTHER_QUERIES',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_ROLLBACK_AND_COMMIT',
        value: 'N'
      },
      {
        key: 'TRACING_INC_MESS_NB',
        value: 'Y'
      },
      {
        key: 'TRACING_MONITOR_STATS',
        value: 'Y'
      }
    ]
  };

  let getSchemasSpy;
  let getTablesSpy;
  let getColumnsSpy;
  class mockInjector {
    get() {
      return metadataApiService;
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [
        DatasourceEntitySelectorComponent,
        FilterComponent,
        MockEntityCardComponent,
        ProgressSpinnerComponent,
        SchemaTableSelectorComponent
      ],
      imports: [getTranslocoModule(), HttpClientTestingModule, ProgressSpinnerModule],
      providers: [{ provide: LaunchDarklyService, useValue: mockLaunchDarklyService }]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    ServiceInjector.injector = new mockInjector();
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    metadataApiService = TestBed.inject(MetadataApiService);
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockPipeline);
    catalogMetadataApiService = TestBed.inject(CatalogMetadataApiService);
    catalogApiService = TestBed.inject(CatalogApiService);
    featureFlagService = TestBed.inject(FeatureFlagService);
    fixture = TestBed.createComponent(SchemaTableSelectorComponent);
    getSchemasSpy = spyOn(metadataApiService, 'getSchemas').and.returnValue(of(mockSchemas));
    getTablesSpy = spyOn(metadataApiService, 'getTables').and.returnValue(of(mockTables));
    getColumnsSpy = spyOn(metadataApiService, 'getColumns').and.returnValue(of(mockColumns));
    spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(false);
    component = fixture.componentInstance;
    component.sourceDataConnection = { id: 'aaaa' } as Connection;
    component.projectId = 'abcd';
    fixture.detectChanges();
    component.loadSchemaData();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load the schema data on initialization', (done) => {
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.schemaData.length > 0).toBeTrue();
      done();
    });
  });

  it('should select the schema specified', (done) => {
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.schemaConfiguration.rowSelect(component.schemaData[0]);
      expect(component.selectedSchema).toBe(component.schemaData[0]);
      done();
    });
  });

  it('should load the tables when schema is selected', (done) => {
    component.schemaConfiguration.rowSelect(new SchemaModel(mockSchemas[1] as any));
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.tableData.length > 0).toBeTrue();
      done();
    });
  });

  it('should sort pipelines from worst to best by default', () => {
    jasmine.getEnv().allowRespy(true);

    let mock1Children = [
      {
        selected: true,
        children: [],
        name: 'NEWTABLE'
      }
    ];
    let mock1Children1 = [
      {
        selected: true,
        children: [],
        name: 'NEWTABLE'
      },
      {
        selected: true,
        children: [],
        name: 'NEWTABLE'
      }
    ];

    let mockSchema1 = [
      { name: 'Lucifer', children: mock1Children },
      { name: 'Chloe', children: mock1Children1 },
      { name: 'Dan', children: [] }
    ];
    mockSchema1 = component.defaultSortSchemaList(mockSchema1);
    expect(mockSchema1[0].name).toBe('Chloe');
    expect(mockSchema1[1].name).toBe('Lucifer');
    expect(mockSchema1[2].name).toBe('Dan');
  });

  it('should load the columns when table is selected', (done) => {
    component.selectedSchema = mockSchemas[0] as any;
    component.tableConfiguration.rowSelect(new TableModel(mockTables[0] as any));
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.columnData.length > 0).toBeTrue();
      done();
    });
  });

  it('should update the selected table count', (done) => {
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.tableConfiguration.rowCheck([component.tableData[0]]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.schemaData[0].children[0].selected).toBeTrue();
        done();
      });
    });
  });

  it('should not load the tables if already available', (done) => {
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    getTablesSpy.calls.reset();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.schemaConfiguration.rowSelect(component.schemaData[0]);
      expect(getTablesSpy).not.toHaveBeenCalled();
      done();
    });
  });

  it('should not load the columns if already available', (done) => {
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.tableConfiguration.rowSelect(component.tableData[0]);
      getColumnsSpy.calls.reset();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        component.tableConfiguration.rowSelect(component.tableData[0]);
        expect(getColumnsSpy).not.toHaveBeenCalled();
        done();
      });
    });
  });

  it('should return the table selection count under schemas', (done) => {
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.tableConfiguration.rowCheck([component.tableData[0]]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.schemaData[0].tableSelectionCount).toBe('1');
        done();
      });
    });
  });

  it('should emit statusChanged when we transition from none to at least one table checked', (done) => {
    spyOn(component.statusChanged, 'emit').and.stub();
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // check the first table - status should change
      component.tableConfiguration.rowCheck([component.tableData[0]]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.statusChanged.emit).toHaveBeenCalled();
        done();
      });
    });
  });

  it('should emit statusChanged when we transition from at least one table checked to none', (done) => {
    spyOn(component.statusChanged, 'emit').and.stub();
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // check the first table
      component.tableConfiguration.rowCheck([component.tableData[0]]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        // uncheck the first table - status should change
        component.tableConfiguration.rowCheck([component.tableData[0]]);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          expect(component.statusChanged.emit).toHaveBeenCalled();
          done();
        });
      });
    });
  });

  it('should not emit statusChanged when status does not change', (done) => {
    const spy = spyOn(component.statusChanged, 'emit').and.stub();
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // check the first table
      component.tableConfiguration.rowCheck([component.tableData[0]]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        // reset the spy as if it has never been called so we can check whether
        // it was called when we select another table
        spy.calls.reset();
        // check the second table - status should not change
        component.tableConfiguration.rowCheck([component.tableData[0], component.tableData[1]]);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          expect(component.statusChanged.emit).not.toHaveBeenCalled();
          done();
        });
      });
    });
  });

  it('should update pipeline entity when a table is checked', (done) => {
    spyOn(pipelineEntityService, 'patchPipeline').and.stub();
    const selectedSchema = component.schemaData[0];
    component.schemaConfiguration.rowSelect(selectedSchema);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // check the first table and verify that the pipeline entity is updated correctly
      const checkedTable = component.tableData[0];
      component.tableConfiguration.rowCheck([checkedTable]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith(
          jasmine.objectContaining({
            source: {
              dataConnection: {
                id: component.sourceDataConnection.id,
                connectionType: 'ORACLE'
              },
              selectedTables: [
                {
                  key: selectedSchema.name,
                  value: {
                    tableExtractType: 'INCLUDE',
                    tableAndKeys: [{ tableName: checkedTable.name, keys: [] }]
                  }
                }
              ]
            }
          })
        );
        done();
      });
    });
  });

  it('should update pipeline entity when tables from different schemas are checked', (done) => {
    spyOn(pipelineEntityService, 'patchPipeline').and.stub();
    // select the first schema
    const selectedSchema1 = component.schemaData[0];
    component.schemaConfiguration.rowSelect(selectedSchema1);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      // check the first table and verify that the pipeline entity is updated correctly
      const checkedTable1 = component.tableData[0];
      component.tableConfiguration.rowCheck([checkedTable1]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith(
          jasmine.objectContaining({
            source: {
              dataConnection: {
                id: component.sourceDataConnection.id,
                connectionType: 'ORACLE'
              },
              selectedTables: [
                {
                  key: selectedSchema1.name,
                  value: {
                    tableExtractType: 'INCLUDE',
                    tableAndKeys: [{ tableName: checkedTable1.name, keys: [] }]
                  }
                }
              ]
            }
          })
        );
        // select the second schema
        const selectedSchema2 = component.schemaData[1];
        component.schemaConfiguration.rowSelect(selectedSchema2);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          // check the second table and verify that the pipeline entity is updated correctly
          const checkedTable2 = component.tableData[1];
          component.tableConfiguration.rowCheck([checkedTable2]);
          fixture.detectChanges();
          fixture.whenStable().then(() => {
            expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith(
              jasmine.objectContaining({
                source: {
                  dataConnection: {
                    id: component.sourceDataConnection.id,
                    connectionType: 'ORACLE'
                  },
                  selectedTables: [
                    {
                      key: selectedSchema1.name,
                      value: {
                        tableExtractType: 'INCLUDE',
                        tableAndKeys: [{ tableName: checkedTable1.name, keys: [] }]
                      }
                    },
                    {
                      key: selectedSchema2.name,
                      value: {
                        tableExtractType: 'INCLUDE',
                        tableAndKeys: [{ tableName: checkedTable2.name, keys: [] }]
                      }
                    }
                  ]
                }
              })
            );
            done();
          });
        });
      });
    });
  });

  it('should be able to handle schema errors', () => {
    const errorMessage = 'schema error';
    spyOn(metadataApiService, 'getSchemas').and.returnValue(throwError({ error: { message: errorMessage } }));
    component.loadSchemaData();
    expect(component.schemaErrorMessage).toBe(errorMessage);
  });

  it('should be able to handle table errors', () => {
    const errorMessage = 'table error';
    spyOn(metadataApiService, 'getTables').and.returnValue(throwError({ error: { message: errorMessage } }));
    component.loadTableData(component.schemaData[0]);
    expect(component.tableErrorMessage).toBe(errorMessage);
  });

  it('should be able to handle column errors', () => {
    const errorMessage = 'column error';
    component.selectedSchema = mockSchemas[0] as any;
    spyOn(metadataApiService, 'getColumns').and.returnValue(throwError({ error: { message: errorMessage } }));
    component.loadColumnData(mockTables[0] as any);
    expect(component.columnErrorMessage).toBe(errorMessage);
  });

  it('should clear the selected tables when we switch schemas', (done) => {
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.tableConfiguration.rowCheck([component.tableData[0]]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.selectedSchema.tableSelectionCount).toBe('1');
        component.schemaConfiguration.rowSelect(component.schemaData[1]);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          expect(component.selectedSchema.tableSelectionCount).toBe('0');
          done();
        });
      });
    });
  });

  describe('DB2 IBMi Source Data Connection', () => {
    beforeEach(() => {
      jasmine.getEnv().allowRespy(true);
      pipelineEntityService = TestBed.inject(PipelineEntityService);
      metadataApiService = TestBed.inject(MetadataApiService);
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockPipelineIBMi);
      spyOn(metadataApiService, 'getJournals').and.returnValue(of(mockJournals));
      fixture = TestBed.createComponent(SchemaTableSelectorComponent);
      component = fixture.componentInstance;
      component.sourceDataConnection = { id: 'aaaa', connectionType: 'DB2I' } as Connection;
      component.projectId = 'efgh';
      fixture.detectChanges();
      component.loadSchemaData();
    });

    it('should disable the dropdown when there is no schema and log reader selected', () => {
      component.selectedLogReader = null;
      component.selectedSchema = null;
      expect(component.tableConfiguration.dropdownOptions.disabled).toBe(true);
    });

    it('should keep the selected journal if we are switching to autogenerate and there are tables selected', (done) => {
      component.schemaConfiguration.rowSelect(component.schemaData[0]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        component.tableConfiguration.rowCheck([component.tableData[0]]);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          component.selectedLogReader = null;
          expect(component.tableConfiguration.dropdownOptions.disabled).toBe(true);
          expect(component.tableConfiguration.dropdownOptions.selectedOption).toBe(component.tableData[0].journal);
          done();
        });
      });
    });

    it('should switch journal and disable the dropdown if we are switching to a log reader', (done) => {
      component.schemaConfiguration.rowSelect(component.schemaData[0]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        component.tableConfiguration.rowCheck([component.tableData[1]]);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          component.selectedLogReader = mockDefaultLogReader;
          fixture.detectChanges();
          fixture.whenStable().then(() => {
            expect(component.tableConfiguration.dropdownOptions.disabled).toBe(true);
            expect(component.tableConfiguration.dropdownOptions.selectedOption).toBe(mockDefaultLogReader.journalName);
            done();
          });
        });
      });
    });

    it('should switch to All journals and enable the dropdown if we are switching to Autogenerate and there are no tables selected', (done) => {
      component.schemaConfiguration.rowSelect(component.schemaData[0]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        component.selectedLogReader = null;
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          expect(component.tableConfiguration.dropdownOptions.disabled).toBe(false);
          expect(component.tableConfiguration.dropdownOptions.selectedOption).toBe('All journals');
          done();
        });
      });
    });

    it('should switch to All journals and enable the dropdown if we deselect the last selected table and Autogenerate is selected', (done) => {
      component.schemaConfiguration.rowSelect(component.schemaData[0]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        component.tableConfiguration.rowCheck([component.tableData[1]]);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          component.tableConfiguration.rowCheck([]);
          fixture.detectChanges();
          fixture.whenStable().then(() => {
            expect(component.tableConfiguration.dropdownOptions.disabled).toBe(false);
            expect(component.tableConfiguration.dropdownOptions.selectedOption).toBe('All journals');
            done();
          });
        });
      });
    });

    it('should test the custom filter function', () => {
      expect(component.journaledCustomfilter('', undefined)).toBe(false);
      expect(component.journaledCustomfilter('', null)).toBe(false);
      expect(component.journaledCustomfilter(null, 'filter')).toBe(false);
      expect(component.journaledCustomfilter('value', '')).toBe(true);
      expect(component.journaledCustomfilter('journal1', 'journal1')).toBe(true);
      expect(component.journaledCustomfilter('journal1', 'journal2')).toBe(false);
    });
  });

  /** Excluding for now as this test as inconsistent results */
  xit('should clear the loaded columns when we switch schemas', (done) => {
    component.schemaConfiguration.rowSelect(component.schemaData[0]);
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      component.tableConfiguration.rowSelect([component.tableData[0]]);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.columnData.length).toBe(2);
        component.schemaConfiguration.rowSelect(component.schemaData[1]);
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          expect(component.columnData.length).toBe(0);
          done();
        });
      });
    });
  });

  describe('Schedule Connection', () => {
    beforeEach(() => {
      jasmine.getEnv().allowRespy(true);
      pipelineEntityService = TestBed.inject(PipelineEntityService);
      pipelineEntityService.pipelineEntityType = PIPELINE_ENTITY_TYPE.SCHEDULED;
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(scheduledPiplelineMock);
      const schemas = [
        { schema: 'Corrina', status: 'inprogress' } as CatalogSchema,
        { schema: 'Lane', status: 'inprogress' } as CatalogSchema
      ];
      const mockCatalogStatusReponse = {
        status: 'complete',
        schemas: schemas
      } as CatalogStatus;
      spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatusReponse));
      fixture = TestBed.createComponent(SchemaTableSelectorComponent);
      component = fixture.componentInstance;
      component.projectId = 'priject123';
      component.sourceDataConnection = {
        id: '11508c69-21f8-4f2c-b9eb-39b853c34fee',
        connectionType: 'ORACLE',
        database: 'host.docker.internal',
        dateCreated: '2022-11-03T09:57:24.341Z',
        description: '',
        name: 'OracleMax',
        namenode: '',
        owner: 'nsotgui@mailinator.com'
      };
      fixture.detectChanges();
    });

    it('should load the list of schemas for a source connection of a scheduled pipeline', () => {
      component.catalogService = new CatalogServiceStub();
      spyOn(component.catalogService, 'browseAssets').and.returnValue(of(schemaResponse));
      component.sourceDataConnection.parentAssetId = 'a9508c69-35f8-4f2c-b9eb-39b853c34fee';
      component.loadSchemaData();
      expect(component.schemaData.length).toBe(1);
      expect(component.schemaData[0].selected).toBe(true);
      expect(component.schemaData[0].name).toBe('schema-1');
      expect(component.schemaData[0].tableCount).toBe(0);
      expect(component.schemaLoading).toBe(false);
      expect(component.catalogService.browseAssets).toHaveBeenCalled();
    });

    it('should not load the list of schemas for a source connection of a scheduled pipeline if parent asset id is not passed', () => {
      component.catalogService = new CatalogServiceStub();
      spyOn(component.catalogService, 'browseAssets').and.returnValue(of(schemaResponse));
      component.sourceDataConnection.parentAssetId = null;
      component.loadSchemaData();
      expect(component.schemaData.length).toBe(0);
      expect(component.schemaLoading).toBe(false);
      expect(component.catalogService.browseAssets).not.toHaveBeenCalled();
    });

    it('should load the tables names of the selected schema', () => {
      component.catalogService = new CatalogServiceStub();
      spyOn(component.catalogService, 'browseAssets').and.returnValue(of(tablesResponse));
      component.loadTableData(selectedSchema);
      expect(component.tableData.length).toBe(10);
      expect(component.tableData[0].name).toBe('custom_fields');
      expect(component.tableData[1].name).toBe('projects');
      expect(component.tableData[2].name).toBe('sections');
      expect(component.tableData[3].name).toBe('stories');
      expect(component.tableData[4].name).toBe('tags');
      expect(component.tableData[5].name).toBe('tasks');
      expect(component.tableData[6].name).toBe('team_memberships');
      expect(component.tableData[7].name).toBe('teams');
      expect(component.tableData[8].name).toBe('users');
      expect(component.tableData[9].name).toBe('workspaces');
      expect(component.tableLoading).toBe(false);
      expect(component.columnLoading).toBe(false);
    });

    it('should populate the request payload for selected tables upon table selection change', () => {
      component.catalogService = new CatalogServiceStub();
      spyOn(component.catalogService, 'browseAssets').and.returnValue(of(tablesResponse));
      spyOn(pipelineEntityService, 'patchPipeline').and.stub();
      component.selectedSchema = component.selectedSchema = mockSchemas[0] as any;
      const checkedTable = new TableModel();
      checkedTable.id = '08302650-56e9-474f-94dd-5a093626ec24';
      checkedTable.name = 'team_memberships';
      checkedTable.selected = false;
      checkedTable.children = [];
      component.tableSelectionChanged([checkedTable]);

      expect(pipelineEntityService.patchPipeline).toHaveBeenCalled();
    });
  });

  describe('scalable commit', () => {
    const pipeline = {
      projectId: 'abcd',
      dataFlowType: 'SYNCHRONIZE',
      source: {
        dataConnection: { id: 'abcd', connectionType: 'ORACLE' },
        selectedTables: [
          {
            key: 'test1',
            value: {
              tableExtractType: 'INCLUDE',
              tableAndKeys: [
                {
                  tableName: 'table1',
                  keys: []
                },
                {
                  tableName: 'table2',
                  keys: []
                }
              ]
            }
          },
          {
            key: 'MISSING_SCHEMA',
            value: {
              tableExtractType: 'INCLUDE',
              tableAndKeys: []
            }
          }
        ]
      },
      id: 'mockPipeline'
    } as Pipeline;

    beforeEach(() => {
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      spyOn(ServiceInjector.injector, 'get').and.returnValue(catalogMetadataApiService);
    });

    it('should select child items if schema is selected ', () => {
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockPipeline);
      const mockCatalogStatusReponse = { status: 'complete', schemas: [{ schema: 'test1' } as CatalogSchema] } as CatalogStatus;
      spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatusReponse));
      const mockSchemaResponse = [{ name: 'test1' }];
      spyOn(metadataApiService, 'getSchemas').and.returnValue(of(mockSchemaResponse));
      component.savedSchemas = [{ name: 'test1', tables: ['table1'] } as SavedSchema];
      component.loadSchemaData();
      expect(component.schemaData[0].children[0].selected).toBe(true);
    });

    it('should handle missing schemas in catalog', () => {
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
      const mockCatalogStatusReponse = {
        status: 'complete',
        schemas: [{ schema: 'test1', tablesStatus: [{ table: 'table1' }] } as CatalogSchema]
      } as CatalogStatus;
      spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatusReponse));
      const mockSchemaResponse = [{ name: 'test1' }];
      spyOn(metadataApiService, 'getSchemas').and.returnValue(of(mockSchemaResponse));
      component.savedSchemas = [{ name: 'test1', tables: ['table1'] } as SavedSchema];
      spyOn(component.hasMissingDatasetsOrSchemas, 'emit').and.stub();
      component.loadSchemaData();
      expect(component.hasMissingDatasetsOrSchemas.emit).toHaveBeenCalledWith(true);
    });

    it('should handle missing table data', () => {
      component.savedSchemas = [{ name: 'test1', tables: ['table1'] } as SavedSchema];
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
      const mockTableResponse = [{ name: 'table1' }];
      spyOn(metadataApiService, 'getTables').and.returnValue(of(mockTableResponse));
      spyOn(component.hasMissingDatasetsOrSchemas, 'emit').and.stub();
      component.loadTableData(new SchemaModel({ name: 'test1' } as SchemaModel));
      expect(component.hasMissingDatasetsOrSchemas.emit).toHaveBeenCalledWith(true);
    });

    it('should get the correct metadata service', () => {
      component.ngOnInit();
      expect(ServiceInjector.injector.get).toHaveBeenCalled();
    });

    it('should fetch catalogstatus', (done) => {
      const mockCatalogStatusReponse = { status: 'complete', schemas: [{ schema: 'test1' } as CatalogSchema] } as CatalogStatus;
      spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatusReponse));
      component.loadSchemaData();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(catalogApiService.status).toHaveBeenCalled();
        expect(component.catalogStatus).toEqual(mockCatalogStatusReponse);
        done();
      });
    });

    it('should expect each schema data to hold last updated date', (done) => {
      const schemas = [
        { schema: 'Corrina', lastUpdated: '29/06/2022, 09:39:47' } as CatalogSchema,
        { schema: 'Lane', lastUpdated: '28/06/2022, 13:02:28' } as CatalogSchema
      ];
      const mockCatalogStatusReponse = {
        status: 'complete',
        schemas: schemas
      } as CatalogStatus;
      spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatusReponse));
      component.loadSchemaData();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        component.schemaData.forEach((schema) => expect(schema.lastCataloged).toBeTruthy());
        done();
      });
    });
    it('should expect schema to display not cataloged when cataloging is not complete', (done) => {
      const schemas = [
        { schema: 'Corrina', status: 'inprogress' } as CatalogSchema,
        { schema: 'Lane', status: 'inprogress' } as CatalogSchema
      ];
      const mockCatalogStatusReponse = {
        status: 'complete',
        schemas: schemas
      } as CatalogStatus;
      spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatusReponse));
      component.loadSchemaData();
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        component.schemaData.forEach((schema) => expect(schema.lastCataloged).toEqual('connections.CATALOG_STATUS.NOT_CATALOGED.TEXT'));
        done();
      });
    });
  });
});
