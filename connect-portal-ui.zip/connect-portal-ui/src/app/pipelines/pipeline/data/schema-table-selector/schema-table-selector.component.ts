import { HttpHeaders } from '@angular/common/http';
import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SortMeta } from 'primeng/api';
import { forkJoin, Observable, of } from 'rxjs';
import { catchError, first, map, mergeMap } from 'rxjs/operators';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';
import { Connection } from '../../../../connections/shared/connection';
import { BaseComponent } from '../../../../core/base.component';
import { DatasourceEntitySelectorModel } from './datasource-entity-selector/datasource-entity-selector.model';
import { EntityCardHeaderModel } from './datasource-entity-selector/entity-card-header.model';
import { FeatureFlagService } from '../../../../shared/services/feature-flag.service';
import { ServiceInjector } from '../../../../shared/services/service.injector';
import { PIPELINE_ENTITY_TYPE, SelectedTables } from '../../shared/pipeline';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { LogReader } from '../shared/logreader';
import { CatalogMetadataApiService } from './catalog-metadata-api.service';
import { MetadataApiService } from './metadata-api.service';
import { SavedSchema, ScheduledConnectionSchema, SchemaConnectionRoot } from './saved-schema';
import { ColumnModel, SchemaModel, TableModel } from './schema-table-selector';
import { CatalogService } from 'dqcore-catalog';

@Component({
  selector: 'p-connect-schema-table-selector',
  templateUrl: './schema-table-selector.component.html'
})
export class SchemaTableSelectorComponent extends BaseComponent implements OnInit {
  @Output() statusChanged = new EventEmitter<any>();
  @Output() hasMissingDatasetsOrSchemas = new EventEmitter<boolean>();

  @Input() savedSchemas: SavedSchema[] = [];

  @Input()
  set selectedLogReader(logReader: LogReader) {
    this.logReader = logReader;
    if (this.areLogReadersRequired()) {
      // disable the dropdown the first time we select a schema and no logreader have been selected
      if (!this.selectedSchema && !logReader) {
        this.tableConfiguration.dropdownOptions.disabled = true;
      } else if (logReader || this.getAllSelectedTables().length === 0) {
        // switch the selected journal and enable the dropdown depending on whether or not there was a logreader selected
        const previouslySelectedJournal = this.tableConfiguration.dropdownOptions.selectedOption;
        const selectedJournal = logReader ? logReader.journalName : this.journalFirstOption;
        this.tableConfiguration.dropdownOptions.selectedOption = selectedJournal;
        // clear the selected tables if we are switching to a different journal that it's not 'All journals'
        if (
          selectedJournal !== this.journalFirstOption &&
          previouslySelectedJournal !== this.journalFirstOption &&
          selectedJournal !== previouslySelectedJournal
        ) {
          this.clearAllSelectedTables();
        }
        this.tableConfiguration.dropdownOptions.disabled = logReader ? true : false;
      }
      const filterValue =
        this.tableConfiguration.dropdownOptions.selectedOption !== this.journalFirstOption
          ? this.tableConfiguration.dropdownOptions.selectedOption
          : '';
      this.tableConfiguration.dropdownOptions.filter = {
        [this.journalColumnName]: { value: filterValue, matchMode: this.journaledFilterName }
      };
    }
  }

  get selectedLogReader(): LogReader {
    return this.logReader;
  }

  private logReader: LogReader = null;
  schemaData: SchemaModel[] = [];
  tableData: TableModel[] = [];
  columnData: ColumnModel[] = [];
  checkedTables: TableModel[] = [];
  schemaErrorMessage: string;
  tableErrorMessage: string;
  columnErrorMessage: string;

  private journalColumnName = 'journal';
  private journaledFilterName = 'journaled';
  private journalFirstOption = 'All journals';

  schemaConfiguration: DatasourceEntitySelectorModel = {
    data: this.schemaData,
    filterPlaceholder: 'pipelines.STAGES.DATA.SCHEMAS.FILTER',
    id: 'data-schema-selector',
    headers: [
      {
        fieldName: 'name',
        displayName: 'pipelines.STAGES.DATA.SCHEMAS.COLUMN_SCHEMA',
        sort: true
      },
      {
        fieldName: 'tableSelectionCount',
        displayName: 'pipelines.STAGES.DATA.SCHEMAS.COLUMN_TABLE_COUNT',
        sort: true
      },
      {
        fieldName: 'lastCataloged',
        displayName: 'pipelines.STAGES.DATA.COLUMNS.LAST_CATALOGED',
        sort: true,
        hasIcon: true
      }
    ],
    filterFields: ['name'],
    loadingFlag: () => this.schemaLoading,
    showFilter: true,
    showCheckBox: false,
    rowSelect: (schema: object) => this.schemaSelected(schema as SchemaModel),
    rowHover: true,
    scrollHeight: '250px',
    noOfRows: 5,
    scrollable: true,
    virtualScroll: true,
    virtualRowHeight: 30,
    keyField: 'name',
    enableSelection: true,
    cardHeader: 'pipelines.STAGES.DATA.SCHEMAS.HEADING',
    emptyMessage: 'data.MESSAGES.NO_SCHEMA_AVAILABLE',
    noResultsFoundMessage: 'data.MESSAGES.NO_RESULTS_FOUND',
    errorMessage: () => this.schemaErrorMessage
  };

  regularTableColumnHeaders: EntityCardHeaderModel[] = [
    {
      fieldName: 'name',
      displayName: 'pipelines.STAGES.DATA.TABLES.COLUMN_TABLE',
      sort: true,
      hasIcon: true
    }
  ];

  db2iTableColumnHeaders: EntityCardHeaderModel[] = [
    {
      fieldName: 'name',
      displayName: 'pipelines.STAGES.DATA.TABLES.COLUMN_TABLE',
      sort: true
    },
    {
      fieldName: this.journalColumnName,
      displayName: 'pipelines.STAGES.DATA.TABLES.COLUMN_JOURNAL',
      sort: true
    }
  ];

  regularTableSortMetaList: SortMeta[] = [
    { field: 'selected', order: -1 },
    { field: 'name', order: 1 }
  ];

  db2iTableSortMetaList: SortMeta[] = [
    { field: 'selected', order: -1 },
    { field: 'name', order: 1 },
    { field: this.journalColumnName, order: 1 }
  ];

  regularTableFilterFields = ['name'];
  db2iTableFilterFields = ['name', this.journalColumnName];

  tableConfiguration: DatasourceEntitySelectorModel = {
    data: this.tableData,
    filterPlaceholder: 'pipelines.STAGES.DATA.TABLES.FILTER',
    id: 'data-table-selector',
    headers: this.regularTableColumnHeaders,
    filterFields: this.regularTableFilterFields,
    loadingFlag: () => {
      return this.tableLoading;
    },
    showFilter: true,
    rowSelect: (table: object) => this.tableSelected(table as TableModel),
    showCheckBox: true,
    selectedData: this.checkedTables,
    showSelectAllCheckBox: true,
    rowCheck: (checkedRows: object[]) => this.tableSelectionChanged(checkedRows as TableModel[]),
    rowHover: true,
    scrollHeight: '250px',
    noOfRows: 5,
    scrollable: true,
    virtualScroll: true,
    virtualRowHeight: 30,
    keyField: 'name',
    cardHeader: 'pipelines.STAGES.DATA.TABLES.HEADING',
    emptyMessage: 'data.MESSAGES.NO_TABLES_AVAILABLE',
    noResultsFoundMessage: 'data.MESSAGES.NO_RESULTS_FOUND',
    errorMessage: () => this.tableErrorMessage
  };

  columnConfiguration: DatasourceEntitySelectorModel = {
    data: this.columnData,
    filterPlaceholder: 'pipelines.STAGES.DATA.COLUMNS.FILTER',
    id: 'data-column-selector',
    headers: [
      {
        fieldName: 'name',
        displayName: 'pipelines.STAGES.DATA.COLUMNS.COLUMN_NAME',
        sort: false
      },
      {
        fieldName: 'dataType',
        displayName: 'pipelines.STAGES.DATA.COLUMNS.DATA_TYPE',
        sort: false
      }
    ],
    sortMetaList: [{ field: 'name', order: 1 }],
    filterFields: ['name', 'dataType'],
    loadingFlag: () => {
      return this.columnLoading;
    },
    showFilter: true,
    showCheckBox: false,
    rowHover: false,
    scrollHeight: '250px',
    noOfRows: 5,
    scrollable: true,
    virtualScroll: true,
    virtualRowHeight: 30,
    keyField: 'name',
    enableSelection: false,
    cardHeader: 'pipelines.STAGES.DATA.COLUMNS.HEADING',
    emptyMessage: 'data.MESSAGES.NO_TABLE_HIGHLIGHTED',
    noResultsFoundMessage: 'data.MESSAGES.NO_RESULTS_FOUND',
    errorMessage: () => this.columnErrorMessage
  };

  schemaLoading = false;
  tableLoading = false;
  columnLoading = false;
  selectedSchema: SchemaModel;
  selectedTable: TableModel;
  skipHeader = new HttpHeaders().set(InterceptorSkipHeader, '');
  journals: string[] = [];
  projectId: string;
  sourceDataConnection: Connection;
  pipelineType: string;
  catalogService: any;
  catalogStatus: CatalogStatus;
  private metadataApiService: any;

  constructor(
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly catalogApiService: CatalogApiService,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {
    super();
  }

  ngOnInit(): void {
    this.metadataApiService = ServiceInjector.injector.get(CatalogMetadataApiService);
    this.catalogService = ServiceInjector.injector.get(CatalogService);
    const pipeline = this.pipelineEntityService.getPipeline();
    if (pipeline.id) {
      this.sourceDataConnection = pipeline.source.dataConnection;
      this.updateSchemaCardForConnectionType();
      this.projectId = pipeline.projectId;
      this.pipelineType = pipeline.dataFlowType;
      this.updateTableConfiguration();
    }
  }

  /**
   * @internal
   * Update the card strings according to the connection type.
   */
  private updateSchemaCardForConnectionType() {
    let type = this.sourceDataConnection.connectionType;
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.schemaConfiguration.headers[0].displayName = 'Schemas';
    } else {
      this.schemaConfiguration.headers[0].displayName = `connections.STRUCTURE_TYPE.PLURAL.${type}`;
    }
  }

  private getCatalogStatus() {
    this.catalogApiService
      .status(this.sourceDataConnection.id, true)
      .pipe(catchError(() => of(null)))
      .subscribe({
        next: (catalogStatus: CatalogStatus) => {
          this.catalogStatus = catalogStatus;
          this.changeDetectorRef.markForCheck();
        }
      });
  }

  private updateTableConfiguration(): void {
    if (this.areLogReadersRequired()) {
      this.tableConfiguration.headers = this.db2iTableColumnHeaders;
      this.tableConfiguration.filterFields = this.db2iTableFilterFields;
      this.tableConfiguration.dropdownOptions = {
        options: this.journals,
        selectedOption: '',
        ignoredOption: this.journalFirstOption,
        disabled: true,
        filter: { [this.journalColumnName]: { value: '', matchMode: this.journaledFilterName } },
        customFilter: { name: this.journaledFilterName, filter: this.journaledCustomfilter }
      };
      if (this.sourceDataConnection.connectionType === 'DB2I') {
        this.getJournals();
      }
    } else {
      this.tableConfiguration.headers = this.regularTableColumnHeaders;
      this.tableConfiguration.filterFields = this.regularTableFilterFields;
    }
  }

  getJournals(): void {
    this.journals.length = 0;
    this.metadataApiService
      .getJournals(this.sourceDataConnection.id, this.projectId, this.skipHeader)
      .pipe(first())
      .subscribe({
        next: (journals: string[]) => {
          this.journals = journals;
          this.journals.unshift(this.journalFirstOption);
          this.tableConfiguration.dropdownOptions.options = this.journals;
          this.loadProperties();

          this.changeDetectorRef.markForCheck();
        },
        error: (errorResponse) => {
          this.tableErrorMessage = errorResponse.error.message;
        }
      });
  }

  loadSchemaData() {
    this.getCatalogStatus();
    this.schemaLoading = true;
    this.columnLoading = true;
    this.tableLoading = true;
    this.schemaErrorMessage = '';
    this.tableErrorMessage = '';
    this.columnErrorMessage = '';
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      if (this.sourceDataConnection.parentAssetId) {
        this.loadScheduledConnectionSchemaDetails()
          .pipe(first())
          .subscribe({
            error: (error) => {
              this.schemaErrorMessage = error.message;
            }
          })
          .add(() => {
            this.stopSpinner();
          });
      } else {
        this.stopSpinner();
      }
    } else {
      this.loadDataConnectionSchemaDetails();
    }
  }
  /**
   * It sorts the schema list of the source connection
   * @param arr
   */
  defaultSortSchemaList(arr) {
    arr.sort((schema1, schema2) => {
      if (schema1.children.length != schema2.children.length) {
        return schema1.children.length > schema2.children.length ? -1 : 1;
      }

      return schema1.name > schema2.name ? 1 : -1;
    });
    return arr;
  }

  /**
   * It sorts the table list fo the selected scehma
   * @param arr
   */
  defaultSortTableList(arr) {
    arr.sort((table1, table2) => {
      if (table1.selected > table2.selected) return -1;
      if (table1.selected < table2.selected) return 1;

      if (table1.name > table2.name) return 1;
      if (table1.name < table2.name) return -1;
    });
  }

  loadTableData(selectedSchema: SchemaModel) {
    this.tableLoading = true;
    this.tableData.length = 0;
    this.tableErrorMessage = '';
    this.columnErrorMessage = '';

    // we need to do this in order to force the column table to refresh, otherwise the previous
    // columns will still display even though we cleared the columnData array
    this.columnLoading = true;
    this.columnData.length = 0;
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.loadScheduledConnectionTables(selectedSchema);
    } else {
      this.loadDataConnectionTables(selectedSchema);
    }
  }

  loadColumnData(selectedTable: TableModel) {
    if (this.pipelineEntityService.pipelineEntityType !== PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.columnLoading = true;
      this.columnData.length = 0;
      this.columnErrorMessage = '';
      this.loadDataConnectionColumns(selectedTable);
    }
  }

  schemaSelected(schemaModel: SchemaModel) {
    // only enable the dropdown if it's the first time we are selecting a schema and there is no logreader selected
    if (!this.selectedSchema && !this.selectedLogReader && this.tableConfiguration.dropdownOptions) {
      this.tableConfiguration.dropdownOptions.disabled = false;
    }
    this.selectedSchema = schemaModel;
    this.selectedTable = undefined;
    this.tableData.length = 0;
    this.columnData.length = 0;
    this.checkedTables.length = 0;
    if (!this.selectedSchema.hasBeenCached) {
      this.loadTableData(this.selectedSchema);
      this.selectedSchema.hasBeenCached = true;
    } else {
      this.tableLoading = true;
      // we need to do this in order to force the column table to refresh, otherwise the previous
      // columns will still display even though we cleared the columnData array
      this.columnLoading = true;
      this.tableData.push(...this.selectedSchema.children);
      this.checkedTables.push(...this.selectedSchema.children.filter((table) => table.selected));
      setTimeout(() => {
        this.tableLoading = false;
        this.columnLoading = false;

        this.changeDetectorRef.markForCheck();
      }, 0);
    }
  }

  tableSelected(tableModel: TableModel) {
    this.selectedTable = tableModel;
    this.columnData.length = 0;
    if (!this.selectedTable.children || this.selectedTable.children.length === 0) {
      this.loadColumnData(this.selectedTable);
    } else {
      this.columnLoading = true;
      this.columnData.push(...this.selectedTable.children);
      setTimeout(() => {
        this.columnLoading = false;
        this.changeDetectorRef.markForCheck();
      }, 0);
    }
  }

  tableSelectionChanged(checkedTables: TableModel[]) {
    // currently we need to have at least one table selected for the form to be valid
    const oldStatus: boolean = this.getAllSelectedTables().length > 0;
    this.checkedTables = checkedTables;
    const newStatus: boolean = this.checkedTables.length > 0;

    for (const table of this.selectedSchema.children) {
      table.selected = this.checkedTables.indexOf(table) >= 0;
    }

    if (!oldStatus && newStatus) {
      // first table selected
      let selectedJournal = '';
      if (this.areLogReadersRequired()) {
        selectedJournal = checkedTables[0].journal;
        // if it's Autogenerate and it's the first table selected
        // select the journal associated with the first table selected
        this.setDropdownOptions(selectedJournal, true);
      }
      this.statusChanged.emit({ status: newStatus, journal: selectedJournal });
    } else if (oldStatus && !this.getAllSelectedTables().length) {
      // last table unselected
      if (this.areLogReadersRequired()) {
        // if it's Autogenerate and it's the last table selected select 'All journals'
        this.setDropdownOptions('', false);
      }
      this.statusChanged.emit({ status: newStatus, journal: '' });
    }
    this.patchPipeline();
  }

  get pipelineSourceDataObject() {
    const selectedTables: SelectedTables[] = [];

    for (const schema of this.schemaData) {
      if (parseInt(schema.tableSelectionCount, 10) > 0) {
        const selectedTablesArray = schema.children.filter((table) => table.selected);

        selectedTables.push({
          key: schema.name,
          value: {
            tableExtractType: 'INCLUDE',
            tableAndKeys: selectedTablesArray.map((table) => {
              return { tableName: table.name, keys: [] };
            })
          }
        });
      }
    }
    return {
      source: {
        dataConnection: this.sourceDataConnection,
        selectedTables
      }
    };
  }

  journaledCustomfilter(value, filter: string): boolean {
    if (filter === undefined || filter === null || !value) {
      return false;
    }

    return filter === '' || value.toString() === filter.toString();
  }

  private patchPipeline(): void {
    this.pipelineEntityService.patchPipeline(this.pipelineSourceDataObject);
  }

  private areLogReadersRequired(): boolean {
    return this.sourceDataConnection && this.sourceDataConnection.connectionType === 'DB2I' && this.pipelineType !== 'COPY';
  }

  private setDropdownOptions(selectedOption: any, disabled: boolean): void {
    if (!this.selectedLogReader) {
      this.tableConfiguration.dropdownOptions.selectedOption = selectedOption ? selectedOption : this.journalFirstOption;
      this.tableLoading = true;
      this.tableConfiguration.dropdownOptions.filter = {
        [this.journalColumnName]: { value: selectedOption, matchMode: this.journaledFilterName }
      };
      this.tableConfiguration.dropdownOptions.disabled = disabled;
      // after triggering the filtering a timeout is needed to avoid weird browser
      // console logs if data isn't fully loaded into datatable yet before filtering
      setTimeout(() => {
        this.tableLoading = false;
        this.changeDetectorRef.markForCheck();
      }, 800);
    }
  }

  private getAllSelectedTables(): TableModel[] {
    const selectedTables: TableModel[] = [];

    for (const schema of this.schemaData) {
      if (parseInt(schema.tableSelectionCount, 10) > 0) {
        selectedTables.push(...schema.children.filter((table) => table.selected));
      }
    }
    return selectedTables;
  }

  private clearAllSelectedTables(): void {
    // clear the current checked tables, otherwise they will display
    // if we switch back even though they were cleared in the schema data
    this.checkedTables.length = 0;
    for (const schema of this.schemaData) {
      for (const table of schema.children) {
        table.selected = false;
      }
    }
  }

  private loadProperties(): void {
    if (this.sourceDataConnection.connectionType === 'DB2I' && !this.selectedLogReader) {
      const properties = this.pipelineEntityService.getPipeline().properties;

      if (properties.length) {
        const journalName = this.getParameterValue(properties, 'IBMI_JOURNAL_NAME');
        this.tableConfiguration.dropdownOptions.selectedOption = journalName ? journalName : this.journalFirstOption;
        if (journalName) {
          this.statusChanged.emit({ status: this.savedSchemas.length > 0, journal: journalName, isLoading: true });
        }
      }
    }
  }
  /**
   * @internal
   * It loads the schema of data connection
   */
  private loadDataConnectionSchemaDetails(): void {
    const pipeline = this.pipelineEntityService.getPipeline();
    this.metadataApiService
      .getSchemas(this.sourceDataConnection.id, this.projectId, this.skipHeader)
      .pipe(first())
      .subscribe({
        next: (data: SchemaModel[]) => {
          const appendIcon = {
            iconClassList: ['png-icon-sm', 'png-alert-attention-solid', 'text-warning'],
            iconTooltip: 'pipelines.STAGES.DATA.SCHEMAS.MISSING_SCHEMA_ERROR'
          };

          for (const schema of data) {
            // set the previously saved tables as selected so the count includes them as selected
            const matchingPreSelectedSchema = this.savedSchemas.find((savedSchema) => savedSchema.name === schema.name);
            if (matchingPreSelectedSchema) {
              schema.children = [];
              matchingPreSelectedSchema.tables.forEach((tableName) => {
                const selectedTable = new TableModel();
                selectedTable.name = tableName;
                selectedTable.selected = true;
                schema.children.push(selectedTable);
              });
            }
            const formattedCatalogDate = this.transformCataLogStatus(schema);
            this.schemaData.push(new SchemaModel(schema, formattedCatalogDate));
          }

          // apply default sort to schema list
          this.schemaData = this.defaultSortSchemaList(this.schemaData);

          for (const item in pipeline.source.selectedTables) {
            const schema = this.schemaData.find((schema) => schema.name === pipeline.source.selectedTables[item].key);
            if (!schema) {
              const missingSchema = new SchemaModel();
              missingSchema.name = pipeline.source.selectedTables[item].key;
              missingSchema.selected = true;
              missingSchema.children = [];

              this.schemaData.push(new SchemaModel(missingSchema, `connections.CATALOG_STATUS.NOT_CATALOGED.TEXT`, appendIcon));

              this.hasMissingDatasetsOrSchemas.emit(true);
            } else {
              // see if there are any tables that are missing from the catalog for the schema
              const missingTables = pipeline.source.selectedTables[item].value.tableAndKeys
                .filter((table) => {
                  const catalogStatusSchemas = this.catalogStatus.schemas.find((s) => s.schema === schema.name);
                  return !catalogStatusSchemas.tablesStatus.find((tableStatus) => tableStatus.table === table.tableName);
                })
                .map((table) => table.tableName);

              if (missingTables.length > 0) {
                schema.appendIcon = appendIcon;
                schema.selected = true;

                this.hasMissingDatasetsOrSchemas.emit(true);
              }
            }
          }

          this.changeDetectorRef.markForCheck();
        },
        error: (errorResponse) => {
          this.schemaErrorMessage = errorResponse.error.message;
        }
      })
      .add(() => {
        this.schemaLoading = false;
        this.columnLoading = false;
        this.tableLoading = false;
      });
  }
  /**
   * @internal
   * It loads the tables of the selected schema of the data connection
   * @param selectedSchema {{SchemaModel}}
   */
  private loadDataConnectionTables(selectedSchema: SchemaModel): void {
    let pipeline = this.pipelineEntityService.getPipeline();
    this.metadataApiService
      .getTables(this.sourceDataConnection.id, this.projectId, selectedSchema.name, this.skipHeader)
      .pipe(first())
      .subscribe(
        (data: TableModel[]) => {
          for (const table of data) {
            // If table has been previously saved, set it as checked/selected
            this.tableData.push(
              new TableModel({
                ...table,
                selected: this.savedSchemas.some((schema) => schema.name === selectedSchema.name && schema.tables.includes(table.name))
              })
            );
          }

          selectedSchema.children.length = 0;
          selectedSchema.children.push(...this.tableData);
          this.checkedTables.push(...selectedSchema.children.filter((table) => table.selected));

          // handle tables that are in pipeline that no longer exist in the catalog
          const selectedTables =
            pipeline.source.selectedTables?.find((schema) => schema.key === selectedSchema.name)?.value.tableAndKeys || [];
          selectedTables.forEach((tableAndKey) => {
            const table = this.tableData.find((table) => table.name === tableAndKey.tableName);
            if (!table) {
              const missingTable = new TableModel();
              missingTable.name = tableAndKey.tableName;
              missingTable.selected = true;
              missingTable.children = [];

              const appendIcon = {
                iconClassList: ['png-icon-sm', 'png-alert-attention-solid', 'text-warning'],
                iconTooltip: 'pipelines.STAGES.DATA.TABLES.MISSING_TABLES_ERROR'
              };

              this.tableData.push(new TableModel(missingTable, appendIcon));

              this.hasMissingDatasetsOrSchemas.emit(true);
            }
          });

          // apply default sort to table list
          if (!this.areLogReadersRequired()) {
            this.defaultSortTableList(this.tableData);
          } else {
            this.tableData.sort((table1, table2) => {
              if (table1.selected > table2.selected) return -1;
              if (table1.selected < table2.selected) return 1;

              if (table1.name > table2.name) return 1;
              if (table1.name < table2.name) return -1;

              if (table1[this.journalColumnName] > table2[this.journalColumnName]) return 1;
              if (table1[this.journalColumnName] < table2[this.journalColumnName]) return -1;
            });
          }

          this.changeDetectorRef.markForCheck();
        },
        (errorResponse: any) => {
          this.tableErrorMessage = errorResponse.error.message;
        }
      )
      .add(() => {
        this.tableLoading = false;
        this.columnLoading = false;
      });
  }

  /**
   * It loads the columns of the selected table of the data connection
   * @param selectedTable {{TableModel}}
   */
  private loadDataConnectionColumns(selectedTable: TableModel): void {
    this.metadataApiService
      .getColumns(this.sourceDataConnection.id, this.projectId, this.selectedSchema.name, selectedTable.name, this.skipHeader)
      .pipe(first())
      .subscribe(
        (data: ColumnModel[]) => {
          this.columnData.push(...data);
          selectedTable.children.length = 0;
          selectedTable.children.push(...data);

          this.changeDetectorRef.markForCheck();
        },
        (errorResponse: any) => {
          this.columnErrorMessage = errorResponse.error.message;
        }
      )
      .add(() => {
        this.columnLoading = false;
      });
  }
  /**
   * @internal
   * It loads the schema of connection of scheduled pipeline
   */
  private loadScheduledConnectionSchemaDetails(): Observable<any> {
    const parentConnectionData = {
      id: this.sourceDataConnection.parentAssetId,
      type: '[Host]'
    };
    return this.catalogService.browseAssets(parentConnectionData).pipe(
      map((schemaResponse: ScheduledConnectionSchema[]) => {
        for (let i = 0; i < schemaResponse.length; i++) {
          const connectionSchemaDetails = {
            name: schemaResponse[i].name,
            id: schemaResponse[i].id,
            tables: []
          };
          this.savedSchemas.push(connectionSchemaDetails);
          const schema = new SchemaModel();
          schema.name = connectionSchemaDetails.name;
          schema.id = connectionSchemaDetails.id;
          schema.tableCount = connectionSchemaDetails.tables.length;
          schema.selected = true;
          schema.children = [];
          schema.hasBeenCached = false;
          const formattedCatalogDate = this.transformCataLogStatus(schema);
          this.schemaData.push(new SchemaModel(schema, formattedCatalogDate));
        }
        this.schemaData = this.defaultSortSchemaList(this.schemaData);
      }),
      catchError((error) => {
        this.schemaErrorMessage = error.message;
        throw error;
      })
    );
  }
  /**
   * @internal
   * It loads the table sof the selected schema of the schudled pipeline
   * @param selectedSchema {{SchemaModel}}
   */
  private loadScheduledConnectionTables(selectedSchema: SchemaModel): any {
    const schemaTablesPayloadReq = {
      id: selectedSchema.id,
      type: '[Host].[Schema]'
    };
    this.catalogService
      .browseAssets(schemaTablesPayloadReq)
      .pipe(first())
      .subscribe({
        next: (tablesResponse: ScheduledConnectionSchema[]) => {
          tablesResponse.forEach((table) => {
            const selectedTable = new TableModel();
            selectedTable.name = table.name;
            selectedTable.id = table.id;
            selectedTable.selected = false;
            selectedSchema.children.push(selectedTable);
            this.tableData.push(selectedTable);
          });
          this.defaultSortTableList(this.tableData);
          this.checkedTables.push(...selectedSchema.children.filter((table) => table.selected));
        },
        error: (error) => {
          this.tableErrorMessage = error.message;
        }
      })
      .add(() => {
        this.columnLoading = false;
        this.tableLoading = false;
      });
  }
  /**
   * @internal
   * It checks for catalog status and tranforms it in data format if found
   * @param schema {{SchemaModel}}
   * @returns string
   */
  private transformCataLogStatus(schema: SchemaModel): string {
    let lastCatalogedDate: string;
    if (this.catalogStatus) {
      lastCatalogedDate = this.catalogStatus.schemas.find((s) => s.schema === schema.name)?.lastUpdated;
    }
    const timestamp = lastCatalogedDate ? new Date(lastCatalogedDate).toLocaleDateString() : 'NOT_CATALOGED';
    if (timestamp === 'NOT_CATALOGED') {
      return `connections.CATALOG_STATUS.${timestamp}.TEXT`;
    } else {
      const [day, month, year] = timestamp.split('/');
      const formattedCatalogDate = `${year}/${month}/${day}`;
      return formattedCatalogDate;
    }
  }

  private stopSpinner(): void {
    this.schemaLoading = false;
    this.columnLoading = false;
    this.tableLoading = false;
  }
}
