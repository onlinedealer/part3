import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber, isArray, isString } from "lodash";
import { MeteringVO } from "../../../models/view-objects/metering-vo.model";
import { SorterService } from "../../../../Shared/services/sorter.service";

export class MeteringsSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" | "" }> = new BehaviorSubject({
        active: "name",
        direction: ""
    } as any);

    meterings: MeteringVO[] = [];

    constructor(private sorter: SorterService) {}
    public setMeterings(meterings: MeteringVO[]) {
        if (isArray(meterings)) {
            this.meterings = meterings;
            this.sortingSubject.next(this.sortingSubject.value);
        }
    }

    public getSortedMeterings(): Observable<MeteringVO[]> {
        return this.sortingSubject.asObservable().pipe(
            map(sortingValues => {
                if (sortingValues.direction === "") {
                    return this.sorter.sortByMeteringType(this.meterings, false);
                }
                if (sortingValues.active === "name") {
                    return this.sorter.sortByName(this.meterings, false, sortingValues.direction);
                }
                return [...this.meterings].sort(this.sortedMeteringComparator);
            })
        );
    }

    public onSortEvent(event: { active: string; direction: "asc" | "desc" }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    defaultMeteringComparator(m1: MeteringVO, m2: MeteringVO): number {
        if (m1.type === "profile" && m2.type === "periodic") {
            return -1;
        }

        if (m2.type === "profile" && m1.type === "periodic") {
            return 1;
        }

        if (m1.name.trim().toUpperCase() > m2.name.trim().toUpperCase()) {
            return 1;
        }

        return -1;
    }

    sortedMeteringComparator = (m1: MeteringVO, m2: MeteringVO): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;
        switch (this.sortingSubject.value.active) {
            case "name":
                return this.sortByString(m1.name, m2.name, directionMultiplier);
            case "periodLength":
                return this.sortByNumberOverString(m1.periodLength, m2.periodLength, directionMultiplier);
            case "obis":
                return this.sortByString(m1.obis, m2.obis, directionMultiplier);
            case "unit":
                return this.sortByString(m1.unit, m2.unit, directionMultiplier);
            case "loadedUntil":
                return this.sortByNumberOverString(m1.loadedUntil, m2.loadedUntil, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByString(value1: string, value2: string, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }

        return directionMultiplier;
    }

    sortByNumberOverString(value1: number | string | null, value2: number | string | null, directionMultiplier: number) {
        if (isNumber(value1) && isNumber(value2)) {
            return value1 > value2 ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNumber(value1) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && isNumber(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value1) || isNil(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value2) || isNil(value1)) {
            return -1 * directionMultiplier;
        }

        return value1.toUpperCase() < value2.toUpperCase() ? directionMultiplier : -1 * directionMultiplier;
    }
}
