import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import Stepper from '@material-ui/core/Stepper'
import Step from '@material-ui/core/Step'
import StepLabel from '@material-ui/core/StepLabel'
import Button from '@material-ui/core/Button'
import Typography from '@material-ui/core/Typography'
import CreateCollectionStep1 from './CreateCollectionStep1'
import CreateCollectionStep2 from './CreateCollectionStep2'
import CircularProgress from '@material-ui/core/CircularProgress'

const styles = theme => ({
  root: {
    width: '90%',
  },
  stepPadding: {
    padding: '10px 0px',
  },
  button: {
    marginRight: theme.spacing.unit,
    float: 'right',
  },
  instructions: {
    marginTop: theme.spacing.unit,
    marginBottom: theme.spacing.unit,
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  createButtonStyle: {
    position: 'relative',
    color: '#fff',
    // float: 'right',
    background: '#1976d2',
    marginLeft: 10,
    fontWeight: 300,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    padding: 0,
    // float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
})

class CreateCollection extends React.Component {
  state = {
    activeStep: 0,
    step1FormData: {
      group_type: 'collection',
      group_name: '',
      item_type: '',
      tcins: [],
      collection_end_date: '',
    },
    step2FormData: [],
    RequiredMTAs: [],
  };

  componentWillReceiveProps (nextProps) {
    if (nextProps.requestType) {
      if (nextProps.requestType === 'ADD' && nextProps.recentAddedGroup) {
        this.props.closeDrawer()
        setTimeout(function () {
          window.location.replace('group-details/' + nextProps.recentAddedGroup)
        }, 3000)
        // this.props.clearActionTypes()
        // this.props.toggleSnackBar({})
      }
    }
  }

  componentWillMount () {
    if (this.props.collectionItemTypes.length === 0) {
      this.props.getCollectionItemTypes()
    }
  }

  getSteps = () => {
    return ['Group Details', 'MTAs']
  }

  getStepContent = (step) => {
    switch (step) {
      case 0:
        return <CreateCollectionStep1 onGroupDetails={this.onGroupDetails} collectionItemTypes={this.props.collectionItemTypes} step1FormData={this.state.step1FormData} />
      case 1:
        return <CreateCollectionStep2 onMTAs={this.onMTAs} collectionMTAs={this.props.collectionMTAs} step2FormData={this.state.step2FormData} RequiredMTAs={this.state.RequiredMTAs} />
      default:
        return 'Unknown step'
    }
  }

  onGroupDetails = (step1Data) => {
    this.setState({ step1FormData: step1Data })
  }

  onMTAs = (step2Data) => {
    this.setState({ step2FormData: step2Data })
  }

  isStepOptional = step => {
    return step === 1
  };

  validateRequiredMTAs = () => {
    let isRequiredMTAs = []
    this.props.collectionMTAs.required_collection_mta_info.map((option) => {
      const selCount = _.findIndex(this.state.step2FormData, (n) => { return n.id === option.id })
      if (selCount === -1) {
        isRequiredMTAs.push(option.id)
      } else {
        if (option.uda_has_uom) {
          const selObj = _.find(this.state.step2FormData, (n) => { return n.id === option.id })
          if (selObj.attribute_uom_value === '') {
            isRequiredMTAs.push(option.id)
          }
        }
      }
    })
    return isRequiredMTAs
  }

  handleNext = () => {
    const { activeStep } = this.state
    let payload = {}
    const step1FormData = { ...this.state.step1FormData }
    payload.group_name = step1FormData.group_name
    this.props.groupTypes.map((grpType) => {
      if (grpType.name === step1FormData.group_type) {
        payload.group_type_id = grpType.id
        payload.group_type = grpType.name
      }
    })
    const selItem = _.find(this.props.collectionItemTypes, { 'item_type_id': step1FormData.item_type })
    payload.item_type_id = step1FormData.item_type
    payload.item_type = selItem.item_type_name
    payload.collection_end_date = parseInt(step1FormData.collection_end_date)
    let tcinData = []
    let count = 0
    step1FormData.tcins.map((tcin) => {
      count++
      tcinData.push({ tcin, action: 'CREATED', sort_order: count })
    })
    payload.tcin_data = tcinData
    payload.first_page_collection_request = (activeStep === 0)
    payload.collection_themes = this.state.step2FormData
    payload.items = this.props.recentAddedInfo.items
    payload.department_id = this.props.recentAddedInfo.department_id
    payload.department_name = this.props.recentAddedInfo.department_name
    if (activeStep === 0) {
      this.props.addGroup(payload, this.props.auth.memberOf, this.props.auth.lanId)
    } else {
      const RequiredMTAs = this.validateRequiredMTAs()
      if (RequiredMTAs.length === 0) {
        this.props.addGroup(payload, this.props.auth.memberOf, this.props.auth.lanId)
      } else {
        this.setState({ RequiredMTAs: RequiredMTAs })
      }
    }

    setTimeout(() => {
      if (this.props.errorTcins.length === 0 && activeStep < 1) {
        this.setState({
          activeStep: activeStep + 1,
        })
      }
    }, 2000)
  };

  handleBack = () => {
    this.setState(state => ({
      activeStep: state.activeStep - 1,
    }))
  };

  handleReset = () => {
    this.setState({
      activeStep: 0,
    })
  };

  render () {
    const { classes, loadingBtnStatus, closeDrawer } = this.props
    const steps = this.getSteps()
    const { activeStep, step1FormData } = this.state
    let isDisabled = !!((!step1FormData.group_type || !step1FormData.item_type || !step1FormData.group_name || step1FormData.tcins.length <= 1))
    isDisabled = (loadingBtnStatus.status && loadingBtnStatus.btnName === 'Create Group') ? true : isDisabled
    return (
      <div className={classes.root}>
        <Stepper activeStep={activeStep} className={classes.stepPadding}>
          {steps.map((label, index) => {
            const props = {}
            const labelProps = {}
            return (
              <Step key={label} {...props}>
                <StepLabel {...labelProps}>{label}</StepLabel>
              </Step>
            )
          })}
        </Stepper>
        <div>
          {activeStep === steps.length ? (
            <div>
              <Typography className={classes.instructions}>
                All steps completed - you&quot;re finished
              </Typography>
              <Button onClick={this.closeDrawer} className={classes.cancelButtonStyle}>
                Close
              </Button>
            </div>
          ) : (
            <div>
              <Typography className={classes.instructions}>{this.getStepContent(activeStep)}</Typography>
              <div>
                <Button color="primary" className={classes.cancelButtonStyle} onClick={closeDrawer}>
                        Cancel
                </Button>
                {activeStep === 1 &&
                <Button
                  disabled={activeStep === 0}
                  onClick={this.handleBack}
                  className={classes.cancelButtonStyle}
                >
                        Back
                </Button>
                }
                <Button
                  variant="contained"
                  color="primary"
                  onClick={this.handleNext}
                  className={classes.createButtonStyle}
                  disabled={isDisabled}
                >
                  {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Create Group') &&
                  <CircularProgress
                    className={classes.progress}
                    size={25}
                  />
                  }
                  {activeStep === steps.length - 1 ? 'Create Group' : 'Next'}
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    )
  }
}

CreateCollection.propTypes = {
  classes: PropTypes.object,
}

export default withStyles(styles)(CreateCollection)
