import { Injectable } from "@angular/core";
import { Subject } from "rxjs";
import { FilterItem, FilterData } from "../../Shared/models/filter-item-type.model";
import { FilterTypes } from "../../Shared/models/filter-types.model";

@Injectable({
    providedIn: "root"
})
export class FilterService {
    constructor() {}

    filterChange: Subject<{ entityName: string; details: FilterItem }> = new Subject();

    // Invokes when clear all filter button is clicked
    clearAllFilters: Subject<{ entityName: string }> = new Subject();

    getDefaultDataForFilter(): FilterData {
        return {
            Basic: {
                name: FilterTypes.Basic,
                categories: [
                    {
                        name: "TaskName",
                        items: []
                    },
                    {
                        name: "Status",
                        items: []
                    }
                ]
            },
            Advance: {
                name: FilterTypes.Advance,
                categories: [
                    {
                        name: "AdvanceFilter"
                    }
                ]
            }
        };
    }
}
