(function(){
'use strict';
angular.module('arm').factory('messageService', ['utility', '$rootScope','MASTER_TABLE','$filter','sqliteService','GENERAL_CONFIG','serviceApi', 'SERVICE_TYPE', messageService]);
    function messageService(utility,$rootScope,MASTER_TABLE,$filter,sqliteService,GENERAL_CONFIG,serviceApi, SERVICE_TYPE){

    var factoryFunctionArr = [];

    factoryFunctionArr.models = function()
        {
            return{
                
                ParticipantModel:
                {
                    'IsGroup': false,
                    'Id': 0,
                    'Name': '',
                    'ImgSrc': ''
                 },
                 ConversationModel:
                 {
                    'DeviceObjID': utility.generateUUID(),
                    'Participant1ID': 0,
                    'Participant2ID': 0,
                    'Messages': [],
                    'ImgSrc': ''
                 },
                 MessageModel:
                 {
                    'MsgIndex': 0,
                    'DeviceObjID': utility.generateUUID(),
                    'InternalMessageID': 0,
                    'ConversationDeviceObjID': '',
                    'IsGroup': false,
                    'SendByID': 0,
                    'SendByName': '',
                    'SendToID': 0,
                    'SendToName': '',
                    'Description': '',
                    'SystemDateTime': ''
                 }
                };
        };

        var conversations = null; var selectedConversation = null;
        factoryFunctionArr.setConversationList = function(list)
        {
            conversations = list;
        };

        factoryFunctionArr.getConversationList = function()
        {
            if (conversations == null) 
                conversations = [];      
            return conversations;
        };

        factoryFunctionArr.setSelectedConversation = function(conversation)
        {
            selectedConversation = conversation;
        };

        factoryFunctionArr.getSelectedConversation = function()
        {     
            return selectedConversation;
        };

        factoryFunctionArr.clearStorage = function()
        {
            conversations = null;
            selectedConversation = null;
        };

        factoryFunctionArr.getExistedConversation = function(participant)
        {
            var loggedInUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            return sqliteService.query("SELECT * FROM MsgConversations WHERE (Participant1ID = " + participant.Id +" AND Participant2ID = " + loggedInUser.UserID +") OR (Participant1ID = " + loggedInUser.UserID +" AND Participant2ID = " + participant.Id +")").then(function (result) {
                 return result;
                });
        };
                    
        factoryFunctionArr.insertConversation = function(conversation)
        {
            var loggedInUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            return sqliteService.query("INSERT INTO MsgConversations(DeviceObjID,Participant1ID,Participant2ID,"+
                "LoggedInUserID) VALUES ('" +  conversation.DeviceObjID +"'," +  conversation.Participant1ID +"," + 
                conversation.Participant2ID +"," + loggedInUser.UserID +")").then(function (result) {
                 return result;
                });
        };
        return factoryFunctionArr;
        
        }
})();
