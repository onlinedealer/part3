import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { AuthenticationService, Helper, SharedConstants as ProfilingConstants } from 'discovery-shared';
import { Observable } from 'rxjs';
import { HistoryDataModel } from 'shared/history-table/history-data-model';
import { ProfileMetadataModel } from './profile-metadata.model';
import { ProfileResultsColumnModel } from './profile-results-column.model';
import { ProfileResultsTableModel } from './profile-results-table.model';
import { ProfileResultsModel } from './profile-results.model';
import { TreePath } from './tree-path.model';

@Injectable({
  providedIn: 'root'
})
export class ProfileResultsService {
  /**
   *
   */
  baseUrl: string;
  metricsUrl: string;

  /**
   *
   */
  statsUrl: string = 'profile/statistics/';
  summaryHeaders: any = [];
  summaryData: any = [];

  private _profileId: string;
  private _runId: string;

  constructor(
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    private translocoService: TranslocoService,
    private httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('configapi', 'profiling', 'api/v1/');
    this.metricsUrl = httpUtil.getAssetUrl('obsmetrics', 'profiling', 'api/v1/');
  }

  get profileId(): string {
    return this._profileId;
  }

  set profileId(val: string) {
    this._profileId = val;
  }

  get runId(): string {
    return this._runId;
  }

  set runId(val: string) {
    this._runId = val;
  }

  getProfileStatsById(profileId: string, runId: string): Observable<ProfileResultsModel> {
    const requestParams = {
      runId: runId
    };
    return this.httpClient.get(this.baseUrl + this.statsUrl + profileId, {
      headers: this.authenticationService.getHttpHeaders(),
      params: requestParams
    }) as Observable<ProfileResultsModel>;
  }

  getTableStats(
    runId: string,
    profileMetadata: ProfileMetadataModel,
    tableName: string
  ): Observable<ProfileResultsTableModel> {
    const requestParams = {
      source: profileMetadata.source,
      sourceType: profileMetadata.sourceType,
      host: profileMetadata.host,
      db: profileMetadata.db,
      schema: profileMetadata.schema,
      table: tableName
    };
    return this.httpClient.get(this.metricsUrl + 'dataprofiles/table/' + runId, {
      headers: this.authenticationService.getHttpHeaders(),
      params: this.getHTTPParams(requestParams)
    }) as Observable<ProfileResultsTableModel>;
  }

  getColumnStats(
    runId: string,
    profileMetaData: ProfileMetadataModel,
    tableName: string,
    columnName: string
  ): Observable<ProfileResultsColumnModel> {
    const requestParams = {
      source: profileMetaData.source,
      sourceType: profileMetaData.sourceType,
      host: profileMetaData.host,
      db: profileMetaData.db,
      schema: profileMetaData.schema,
      table: tableName,
      column: columnName
    };
    return this.httpClient.get(this.metricsUrl + 'dataprofiles/column/' + runId, {
      headers: this.authenticationService.getHttpHeaders(),
      params: this.getHTTPParams(requestParams)
    }) as Observable<ProfileResultsColumnModel>;
  }

  getProfileHistory(profileId: string): Observable<HistoryDataModel> {
    return this.httpClient.get(this.baseUrl + 'runtime/profile/run/history/' + profileId, {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<HistoryDataModel>;
  }

  getTableSummary(treePath: TreePath) {
    this.summaryData = [];
    this.summaryHeaders = [];
    this.summaryHeaders = this.getTableSummaryHeader();
    const filteredSuccessData = treePath.treeData.data.columns.filter((column) => column['status'] === 'SUCCESS');
    const maxPopularity = filteredSuccessData.length ? this.getMaxPopularity(filteredSuccessData) : 0;
    if (maxPopularity < 0) {
      const index = this.summaryHeaders.findIndex((head) => head.type === 'popularity');
      this.summaryHeaders.splice(index, 1);
    }

    for (const col of filteredSuccessData) {
      const totalRows = treePath.treeData.data.totalRows;
      this.summaryData.push({
        column: col.name,
        nullCount: this.getNullCountStats(col),
        type: col.type,
        semanticType: this.getSemanticType(col),
        completeness: this.getCompletenessStats(col, totalRows),
        uniqueness: this.getUniquenessStats(col, totalRows),
        stats: this.getStats(col),
        popularity: this.getPopularityStats(col),
        popularityPercentage: this.getPopularityPercentage(col, maxPopularity)
      });
    }
    return {
      headers: this.summaryHeaders,
      data: this.summaryData
    };
  }

  getTrendsHistory(assetPath: string, metricName: string, from?: Date) {
    const params = {
      assetPath: assetPath,
      metricName: metricName
    };
    if (from) {
      params['fromDate'] =
        from.getFullYear() + '-' + ('0' + (from.getMonth() + 1)).slice(-2) + '-' + ('0' + from.getDate()).slice(-2);
    }
    return this.httpClient.post(this.metricsUrl + 'dataprofiles/trends/', params, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  private getHTTPParams(params): HttpParams {
    return new HttpParams().appendAll(params);
  }

  private getTableSummaryHeader() {
    return [
      {
        field: 'column',
        header: this.translocoService.translate('discoveryProfiling.results.columnName'),
        width: '8rem',
        type: 'text',
        children: [],
        sort: true
      },
      {
        field: 'type',
        header: this.translocoService.translate('discoveryProfiling.results.dataTypeColumn'),
        width: '7rem',
        children: [],
        type: 'text',
        sort: true
      },
      {
        field: 'completeness',
        header: this.translocoService.translate('discoveryProfiling.results.completenessColumn'),
        type: 'progressBar',
        width: '7rem',
        children: [],
        sort: true
      },
      {
        field: 'uniqueness',
        header: this.translocoService.translate('discoveryProfiling.results.uniquenessColumn'),
        type: 'progressBar',
        width: '7rem',
        children: [],
        sort: true
      },
      {
        field: 'popularity',
        header: this.translocoService.translate('discoveryProfiling.results.popularityColumn'),
        type: 'popularity',
        width: '18rem',
        children: [],
        sort: true
      },
      {
        field: 'nullCount',
        header: this.translocoService.translate('discoveryProfiling.results.nullCountColumn'),
        width: '7rem',
        children: [],
        type: 'text',
        sort: true
      },
      {
        field: 'semanticType',
        header: this.translocoService.translate('discoveryProfiling.results.semanticType'),
        width: '8rem',
        sort: true,
        type: 'text',
        children: []
      },
      {
        field: 'stats',
        header: this.translocoService.translate('discoveryProfiling.results.statsColumn'),
        type: 'stats',
        width: '15rem',
        children: [
          this.createChild('min', 'discoveryProfiling.results.min', 'assets/images/minimum.svg'),
          this.createChild('max', 'discoveryProfiling.results.max', 'assets/images/maximum.svg'),
          this.createChild('avg', 'discoveryProfiling.results.average', 'assets/images/average.svg'),
          this.createChild('variance', 'discoveryProfiling.results.variance', 'assets/images/variance.svg'),
          this.createChild('stddev', 'discoveryProfiling.results.deviation', 'assets/images/deviation.svg')
        ],
        sort: false
      }
    ];
  }

  private createChild(field: string, label: string, asset: string): { field: string; label: string; imageURL: string } {
    return {
      field: field,
      label: this.translocoService.translate(label),
      imageURL: this.httpUtil.getAssetUrl('portal', 'profiling', asset)
    };
  }

  private getStats(col: ProfileResultsColumnModel) {
    const lengthStats = col.statistics.filter((stat) => stat.type === ProfilingConstants.STATS.STRINGLENGTHSTAT);
    const minmaxStats = col.statistics.filter((stat) => stat.type === ProfilingConstants.STATS.NUMERICALMINMAX);
    const analysisStats = col.statistics.filter((stat) => stat.type === ProfilingConstants.STATS.NUMERICALSTAT);
    const stats = {};
    stats['min'] = minmaxStats[0]?.min ? minmaxStats[0]?.min : lengthStats[0]?.minLength;
    stats['max'] = minmaxStats[0]?.max ? minmaxStats[0]?.max : lengthStats[0]?.maxLength;
    stats['avg'] = Number(analysisStats[0]?.avg?.toFixed(2));
    stats['stddev'] = Number(analysisStats[0]?.stddev?.toFixed(2));
    stats['variance'] = Number(analysisStats[0]?.variance?.toFixed(2));
    return stats;
  }

  private getPopularityStats(col: ProfileResultsColumnModel): number {
    const popularityStat = Helper.getFilteredAuthorizedPopularity(col);
    return popularityStat[0]?.popularityCount;
  }

  private getPopularityPercentage(col: ProfileResultsColumnModel, maxPop: number): string {
    if (maxPop > 0) {
      const popularityStat = Helper.getFilteredAuthorizedPopularity(col);
      return ((popularityStat[0]?.popularityCount / maxPop) * 100).toFixed(0) + '%';
    } else {
      return '0%';
    }
  }

  private getMaxPopularity(colArray: ProfileResultsColumnModel[]) {
    let popularityArray = colArray
      .map((col) => {
        return col.statistics.find(
          (stats) => stats.type === ProfilingConstants.STATS.POPULARITY && stats.isAuthorizedForPopularity
        );
      })
      .filter((item) => item !== undefined);
    return popularityArray.length > 0 ? Math.max(...popularityArray.map((item) => item.popularityCount)) : -1;
  }

  private getUniquenessStats(col: ProfileResultsColumnModel, totalRows: number): number {
    const uniquenessStat = col.statistics.filter((stats) => stats.type === ProfilingConstants.STATS.UNIQUENESS);
    return Number(((uniquenessStat[0]?.uniqueCount / totalRows) * 100).toFixed(2));
  }
  private getCompletenessStats(col: ProfileResultsColumnModel, totalRows: number): number {
    const completnessStat = col.statistics.filter((stats) => stats.type === ProfilingConstants.STATS.COMPLETENESS);
    return Number(((completnessStat[0]?.completeCount / totalRows) * 100).toFixed(2));
  }
  private getNullCountStats(col: ProfileResultsColumnModel): number {
    const completnessStat = col.statistics.filter((stats) => stats.type === ProfilingConstants.STATS.COMPLETENESS);
    return completnessStat[0]?.nullCount;
  }
  private getSemanticType(col: ProfileResultsColumnModel): string {
    const semanticTypeStat = col.statistics.filter((stats) => stats.type === ProfilingConstants.STATS.SEMANTIC);
    return semanticTypeStat[0]?.semanticType;
  }
}
