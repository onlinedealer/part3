import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { MockSidebarComponent } from '../../shared/components/sidebar/mock-sidebar.component.spec';
import { MetabaseDetailsSidebarComponent } from './metabase-details-sidebar.component';
import { MetabaseDetailsFormComponent } from './metabase-details-form/metabase-details-form.component';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { ProjectsApiService } from 'src/app/pipelines/pipeline/shared/projects-api.service';
import { of } from 'rxjs';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { Metabase } from '../shared/metabase.model';

describe('MetabaseDetailsSidebarComponent', () => {
  let component: MetabaseDetailsSidebarComponent;
  let fixture: ComponentFixture<MetabaseDetailsSidebarComponent>;
  let projectsApiService: ProjectsApiService;
  let metabasesApiService: MetabasesApiService;

  @Component({
    selector: 'p-connect-metabase-details-form',
    template: '',
    providers: [
      {
        provide: MetabaseDetailsFormComponent,
        useClass: MockMetabaseDetailsFormComponent
      }
    ]
  })
  class MockMetabaseDetailsFormComponent {
    open(selectedMetabase) {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      declarations: [MockSidebarComponent, MetabaseDetailsSidebarComponent, MockMetabaseDetailsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MetabaseDetailsSidebarComponent);
    projectsApiService = TestBed.inject(ProjectsApiService);
    metabasesApiService = TestBed.inject(MetabasesApiService);
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(metabasesApiService, 'getAll').and.returnValue(of([{} as Metabase]));
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the sidebar', () => {
    spyOn(component.metabaseDetailsFormComponent, 'open').and.returnValue();
    spyOn(component.sidebarComponent, 'open').and.returnValue();
    component.open({});
    expect(component.metabaseDetailsFormComponent.open).toHaveBeenCalled();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should close the sidebar', () => {
    spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.closeButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });
});
