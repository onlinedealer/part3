import { ChangeDetectorRef, Component, Input, OnInit, ViewChild } from '@angular/core';
import { Connection } from '../../../connections/shared/connection';
import { Pipeline, PIPELINE_ENTITY_TYPE, TableMapping } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { FeatureFlagService } from '../../../shared/services/feature-flag.service';
import { TableConfiguration, TableMessage, TableMessageType } from '../../../shared/components/generic-table/generic-table';
import { catchError, first, map } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { PipelineMappingService } from './pipeline-mapping.service';
import { DataTableComponent } from './../../pipeline/mapping/data-table/data-table.component';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { CatalogMetadataApiService } from '../data/schema-table-selector/catalog-metadata-api.service';
import { ConnectionsApiService } from 'src/app/connections/shared/connections-api.service';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { HttpErrorResponse } from '@angular/common/http';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { MAPPING_CONST } from './shared/mapping_constants';
import { BaseComponent } from 'src/app/core/base.component';
import { Router } from '@angular/router';

@Component({
  selector: 'p-connect-pipeline-mapping',
  templateUrl: './pipeline-mapping.component.html',
  styleUrls: ['./pipeline-mapping.component.scss']
})
export class PipelineMappingComponent extends BaseComponent implements OnInit {
  @ViewChild(DataTableComponent) dataTableComponent: DataTableComponent;
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @Input() selectedDatabase: any[];

  /* unique object is used to remove dupicates from slected database list*/
  unique: any[];
  isAdduserdatabaseVisible = false;
  sourceDataConnection: Connection;
  targetDataConnection: Connection;
  schemaRegistryConnection: Connection;
  checkedItems;
  fields = [{ header: 'id', name: 'id', isKey: true }];
  pipeline: Pipeline;
  targetColumnField = [];
  topics = [];
  subjects = [];
  tableData = [];
  enableBtn = true;
  tableMappingLoadingSpinner = true;
  isSchemaRegistryThere: boolean;
  tableMapping: TableMapping[];
  showMissingCatalogMetadataWarning: boolean;
  catalogStatus: CatalogStatus;
  createTopic: boolean = false;
  createSubject: boolean = false;

  constructor(
    public router: Router,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly mappingService: PipelineMappingService,
    private readonly progressIndicatorState: ProgressIndicatorStateService,
    private readonly catalogMetadataApiService: CatalogMetadataApiService,
    private readonly connectionsService: ConnectionsApiService,
    private readonly catalogApiService: CatalogApiService,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly progressIndicatorStateService: ProgressIndicatorStateService
  ) {
    super(router);
  }

  emptyTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'pipelines.STAGES.MAPPING.TABLE.TABLE_MESSAGES.HEAD',
    messageCaption: 'pipelines.STAGES.MAPPING.TABLE.TABLE_MESSAGES.CAPTION'
  };

  filterTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'pipelines.STAGES.MAPPING.TABLE.TABLE_MESSAGES.HEAD',
    messageCaption: 'pipelines.STAGES.MAPPING.TABLE.TABLE_MESSAGES.CAPTION'
  };

  errorTableMessage: TableMessage = {
    messageType: TableMessageType.ALERT,
    messageHead: 'pipelines.STAGES.MAPPING.TABLE.TABLE_MESSAGES.HEAD',
    messageCaption: 'pipelines.STAGES.MAPPING.TABLE.TABLE_MESSAGES.CAPTION'
  };

  tableConfiguration: TableConfiguration = {
    isLoading: false,
    isFilterShown: false,
    visibleRows: 25,
    fields: this.fields,
    rowAction: {
      fieldIndex: 0,
      menuItems: []
    },
    tableMessages: {
      emptyTableMessage: this.emptyTableMessage,
      filterTableMessage: this.filterTableMessage,
      errorTableMessage: this.errorTableMessage
    },
    rowSelectionChangedEvent: (checkedItems: object[]) => {
      this.checkedItems = checkedItems;
      this.mappingService.checkIfButtonDisabled(checkedItems);
    }
  };

  readonly PIPELINE_TYPE = PIPELINE_ENTITY_TYPE;

  get pipelineEntityType(): string {
    return this.pipelineEntityService.pipelineEntityType;
  }

  getAllSelectedData() {
    this.dataTableComponent.emitSelectedData();
  }

  enableOverviewButtons(data) {
    this.enableBtn = data;
  }

  resetSideBarBtnClick(event) {
    this.checkedItems?.forEach((row) => {
      const topic = this.topics.find((ele) => ele === row['table'].trim());
      this.setTopicSubject(row, 'topic', topic);
      if (this.isSchemaRegistryThere) {
        const subject = this.subjects.find((ele) => ele === row['topic'].name.trim());
        this.setTopicSubject(row, 'subject', subject, this.subjects);
      }
    });
    this.dataTableComponent.resetSelectedSourceData();
    this.enableBtn = true;
    this.patchPipeline();
  }

  ngOnInit(): void {
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.progressIndicatorStateService.setIsValid(3, true);
      return;
    }
    this.mappingService.refreshTableMappingGrid.subscribe(() => {
      this.getExistingKafkaTopics();
    });

    this.pipeline = this.pipelineEntityService.getPipeline();
    this.tableMapping = this.pipeline.tableMapping;

    this.sourceDataConnection = this.pipeline.source.dataConnection;
    this.targetDataConnection = this.pipeline.target.dataConnection;
    this.schemaRegistryConnection = this.pipeline.target.dataConnection;
    // setting the value of checkbox if already in pipeline
    this.createTopic = this.pipeline?.createTopic;
    this.createSubject = this.pipeline?.createSubject;

    // setting source connection
    const sourceColumns = this.mappingService.getColumnHeaders(this.sourceDataConnection.connectionType);

    // checking if schema registry is there
    this.isSchemaRegistryThere = this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID)
      ? true
      : false;
    // setting target connection as per schema registry
    const targetConnection = this.setTargetAsperFeatureFlagAndSchemaRegistry();

    const targetColumns = this.mappingService.getColumnHeaders(targetConnection);

    // add table columns as per source
    this.setTableSourceColumns(sourceColumns);

    // setting table index for arrow icon
    this.tableConfiguration.rowAction.fieldIndex = this.fields.length - 1;

    // add table columns as per target
    this.setTableTargetColumns(targetColumns);

    // get selected Tables from data Tab
    this.getSelectedTables();
  }

  get schemaRegistryFeature() {
    return this.featureFlagService.isFeatureEnabled('CDCKafkaSchemaRegistryTemp20220628');
  }

  get isCreateTopicsSubjectsFeatureEnabled() {
    return this.featureFlagService.isFeatureEnabled('CDCKafkaSRCreateTopicsAndSubjectsTemp20220705');
  }
  /**
   * get selected tables from data tab through an API
   * @returns
   */
  async getSelectedTables() {
    await this.getCatalogStatus();

    this.tableMappingLoadingSpinner = true;
    this.progressIndicatorState.setIsValid(3, !this.tableMappingLoadingSpinner);
    const targetConnection = this.isSchemaRegistryThere ? MAPPING_CONST.SCHEMAREGISTRY : this.targetDataConnection.connectionType;
    this.mappingService
      .getSelectedTables(this.pipeline.id, this.sourceDataConnection.connectionType, targetConnection, this.pipeline.tableMapping)
      .subscribe((data: any) => {
        this.handleSelectedTableData(data);
        this.tableData = data;
        this.tableMappingLoadingSpinner = false;
        this.progressIndicatorState.setIsValid(3, !this.tableMappingLoadingSpinner);
        this.changeDetectorRef.markForCheck();
        this.selectedDatabase = this.removeDuplicateDatabase();
        this.isAdduserdatabaseVisible = true;
      })
      .add(() => {
        this.getExistingKafkaTopics();
      });
  }
  /* this function is used to remove DuplicatedDatabase from selected databases*/
  private removeDuplicateDatabase() {
    const copyofDatabase = [];
    this.tableData.forEach((element) => {
      copyofDatabase.push(element.database);
    });
    this.unique = Array.from(new Set(copyofDatabase));
    return this.unique;
  }

  handleSelectedTableData(data) {
    data.forEach((ele) => {
      let matchingCatalogSchema;
      let matchingTables;
      ({ matchingCatalogSchema, matchingTables } = this.handleSelectedTableDatawithCatalog(matchingCatalogSchema, ele, matchingTables));
      ele.hasSchema = matchingCatalogSchema ? true : false;
      ele.hasTable = matchingTables ? true : false;
    });
  }

  /*this function is used to match the catalogged data with the selected table data from source to map page */
  private handleSelectedTableDatawithCatalog(matchingCatalogSchema: any, ele: any, matchingTables: any) {
    if (this.sourceDataConnection.connectionType === MAPPING_CONST.SQLSERVER) {
      matchingCatalogSchema = this.catalogStatus?.schemas.find((catalogedSchema) => catalogedSchema.schema === ele.database?.trim());
      matchingTables = matchingCatalogSchema
        ? matchingCatalogSchema.tablesStatus.find((tableStatus) => tableStatus.table.split('.')[1] === ele.table.trim())
        : null;
    } else {
      matchingCatalogSchema =
        this.sourceDataConnection.connectionType === 'DB2' || this.sourceDataConnection.connectionType === 'DB2I'
          ? this.catalogStatus?.schemas.find((catalogedSchema) => catalogedSchema.schema === ele.library?.trim())
          : this.catalogStatus?.schemas.find((catalogedSchema) => catalogedSchema.schema === ele.schema?.trim());
      matchingTables = matchingCatalogSchema
        ? matchingCatalogSchema.tablesStatus.find((tableStatus) => tableStatus.table === ele.table.trim())
        : null;
    }
    return { matchingCatalogSchema, matchingTables };
  }

  /**
   *  Get the connection type of target
   * @returns
   */

  setTargetAsperFeatureFlagAndSchemaRegistry() {
    // check for feature flag and if schemaRegistry is added
    if (this.isSchemaRegistryThere && this.schemaRegistryFeature) {
      this.getSchemaRegistryDataConnections();
      return MAPPING_CONST.SCHEMAREGISTRY;
    } else {
      // else return plain kafka targetConnection
      return this.targetDataConnection.connectionType;
    }
  }

  /**
   * get the schemaRegistry conn details if present
   * @returns
   */
  async getSchemaRegistryDataConnections() {
    this.connectionsService
      .getAll()
      ?.pipe(first())
      .subscribe((connections) => {
        const schemaRegistryId = this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID).value;
        const schemaRegistry = connections.filter((connection) => connection.id === schemaRegistryId)[0];
        this.schemaRegistryConnection = schemaRegistry;
      });
  }

  /**
   * set source columns of Table as per source connection
   * @param sourceColumns selected source columns
   * @returns
   */

  setTableSourceColumns(sourceColumns) {
    sourceColumns.map((row, i) => {
      if (Object.prototype.hasOwnProperty.call(sourceColumns, i)) {
        this.fields.push(row);
      }
    });
  }

  /**
   * set target columns of Table as per selected target connection
   * @param targetColumns selected target columns
   * @returns
   */

  setTableTargetColumns(targetColumns) {
    targetColumns.map((row, i) => {
      if (Object.prototype.hasOwnProperty.call(targetColumns, i)) {
        this.fields.push(row);
        this.targetColumnField.push(row.name);
      }
    });
  }

  /**
   * form tableMapping payload
   * @param mappings table grid data
   * @returns
   */

  formMappingDataArr(mappings) {
    const sourceColumnName = this.fields[1].name;
    const mappingArr = [];
    mappings.map((row) => {
      const objKey =
        this.sourceDataConnection.connectionType === 'SQLSERVER'
          ? row[sourceColumnName] + '||' + row.owner + '.' + row.table.trim()
          : row[sourceColumnName] + '||' + row.table.trim();
      mappingArr.push({
        id: row.id,
        key: objKey,
        value: this.getValueofPayload(row),
        hasCustomColMappings: row.hasCustomColMappings ? true : false,
        type: this.getTypeofTargetforPayload(row),
        schemaVersion: row.schemaVersion ? row.schemaVersion : null
      });
    });
    return mappingArr;
  }

  /**
   * called from formMappingDataArr to generate type obj
   * @param row table row
   * @returns
   */

  getTypeofTargetforPayload(row) {
    if (this.isSchemaRegistryThere) {
      return this.handleSubjectandTargetType(row);
    } else {
      if (
        row.topic.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
        row.topic.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION
      ) {
        return MAPPING_CONST.MAPPING_STATUS_TARGET_DOES_NOT_EXIST;
      } else if (row.topic.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE) {
        return MAPPING_CONST.MAPPING_STATUS_TARGET_EXISTS_WITHOUT_MATCH;
      } else {
        return MAPPING_CONST.MAPPING_STATUS_TARGET_EXISTS_WITH_MATCH;
      }
    }
  }

  /**
   * called from getTypeofTargetforPayload to generate subject
   * payload type
   * @param row table row
   * @returns
   */

  handleSubjectandTargetType(row) {
    const subjectMappingIcon = row.subject?.mappingIcon;
    const topicMappingIcon = row.topic.mappingIcon;
    switch (true) {
      case (subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
        subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED ||
        subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION) &&
        (topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
          topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION ||
          topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED):
        return MAPPING_CONST.MAPPING_STATUS_BOTH_TARGET_AND_SUBJECT_DOES_NOT_EXIST;

      case subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE &&
        topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE:
        return MAPPING_CONST.MAPPING_STATUS_BOTH_TARGET_AND_SUBJECT_EXISTS_WITHOUT_MATCH;

      case subjectMappingIcon === '' && topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE:
        return MAPPING_CONST.MAPPING_STATUS_TARGET_EXISTS_WITHOUT_MATCH_AND_SUBJECT_EXISTS_WITH_MATCH;

      case subjectMappingIcon === '' &&
        (topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION || topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION):
        return MAPPING_CONST.MAPPING_STATUS_TARGET_DOES_NOT_EXIST_AND_SUBJECT_EXISTS_WITH_MATCH;

      case subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE && topicMappingIcon === '':
        return MAPPING_CONST.MAPPING_STATUS_TARGET_EXISTS_WITH_MATCH_AND_SUBJECT_EXISTS_WITHOUT_MATCH;

      case (subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
        subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION) &&
        topicMappingIcon === '':
        return MAPPING_CONST.MAPPING_STATUS_TARGET_EXISTS_WITH_MATCH_AND_SUBJECT_DOES_NOT_EXIST;

      case subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE &&
        (topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
          topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION ||
          topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED):
        return MAPPING_CONST.MAPPING_STATUS_TARGET_DOES_NOT_EXIST_AND_SUBJECT_EXISTS_WITHOUT_MATCH;

      case (subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
        subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED ||
        subjectMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION) &&
        topicMappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE:
        return MAPPING_CONST.MAPPING_STATUS_TARGET_EXISTS_WITHOUT_MATCH_AND_SUBJECT_DOES_NOT_EXIST;

      default:
        return MAPPING_CONST.MAPPING_STATUS_BOTH_TARGET_AND_SUBJECT_EXISTS_WITH_MATCH;
    }
  }

  /**
   * called from formMappingDataArr to generate value obj
   * @param row table row
   * @returns
   */

  getValueofPayload(row) {
    if (this.isSchemaRegistryThere) {
      if (row.topic.name !== '' && row.subject.name !== '') {
        return row.topic.name.match(MAPPING_CONST.REGEX_TARGET_NAME) ? '' : row.topic.name + '||' + row.subject.name;
      } else if (row.topic.name !== '') {
        return row.topic.name + '||';
      } else if (row.subject.name !== '') {
        return '||' + row.subject.name;
      } else {
        return '';
      }
    } else {
      return row.topic.name.match(MAPPING_CONST.REGEX_TARGET_NAME) ? '' : row.topic.name;
    }
  }

  /**
   * get kafka topics through API
   * @returns
   */

  getExistingKafkaTopics() {
    this.showMissingCatalogMetadataWarning = false;
    this.tableMappingLoadingSpinner = true;
    this.progressIndicatorState.setIsValid(3, !this.tableMappingLoadingSpinner);
    let getTopicsRequest$: Observable<any>;
    getTopicsRequest$ = this.catalogMetadataApiService.getTopics(this.pipeline.target.dataConnection.id);
    getTopicsRequest$
      .pipe(first())
      .subscribe(
        (topics: { name: string }[]) => {
          this.topics = topics.map((topic) => topic.name);
          this.tableMappingLoadingSpinner = false;
          this.progressIndicatorState.setIsValid(3, !this.tableMappingLoadingSpinner);
          this.changeDetectorRef.markForCheck();
        },
        (errorResponse: HttpErrorResponse) => {
          this.showMissingCatalogMetadataWarning = true;
          this.tableMappingLoadingSpinner = false;
          this.sidebarComponent?.parseHttpClientResponseMessage('error', errorResponse);
        }
      )
      .add(() => {
        if (this.isSchemaRegistryThere) {
          this.getSubjects(this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID).value);
        } else {
          this.defaultMapping(this.topics);
        }
      });
  }
  /**
   * Default mapping when user lands on mapping page
   * @param topics kafka topics
   * @returns
   */

  defaultMapping(topics: any[], subjects?: any[]) {
    for (const row of this.tableData) {
      let topic: any;
      if (row.topic.name !== '') {
        topic = row.topic.name;
      } else {
        topic = topics.find((ele) => ele === row.table.trim());
      }
      this.setTopicDetails(row, topic, subjects);
    }
    this.patchPipeline();
  }

  /**
   * called from defaultMapping to set Target details
   * @param row table row
   * @param topic topic name
   * @param subjects optional paramneter- all cataloged subjects
   * @returns
   */

  setTopicDetails(row, topic: string, subjects?: any[]) {
    this.setTopicSubject(row, 'topic', topic);

    // Only call this getSubjectDetails when target has 2 columns
    if (this.isSchemaRegistryThere) {
      this.getSubjectDetails(row, subjects);
    }
  }

  /**
   * Common function for setting the topics as well as subjects details
   * @param row table row
   * @param targetName target key name
   * @param target target- topic or subject
   * @param totalSubjects optional paramneter- all cataloged subjects
   * @returns
   */

  setTopicSubject(row, targetName: string, target: string, totalSubjects?: any[]) {
    if (!target) {
      row[targetName].mappingIcon = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NA, '').icon;
      row[targetName].iconTooltip = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NA, MAPPING_CONST.DATASET).tooltip;
      row.placeholder = row.table.trim();
      row[targetName].name = '';
    } else {
      row[targetName].name = target;
      const targetFound =
        targetName === 'topic' ? this.topics.find((ele) => ele === row.topic.name) : totalSubjects?.find((ele) => ele === row.subject.name);
      this.setMappingIcon(row, target, targetFound, targetName === 'topic' ? MAPPING_CONST.TOPIC : MAPPING_CONST.SUBJECT);
      row.isButtonEnabled = true;
    }
  }

  /**
   * called from setTopicDetails to set Target mapping icons
   * @param row table row
   * @param target target name
   * @param targetFound target string that is found
   * @param targetColumn target column name
   * @returns
   */

  setMappingIcon(row, targetName: string, targetFound: string, targetColumn: string) {
    const checkingColumn = targetColumn === MAPPING_CONST.TOPIC ? row.table.trim() : row.topic.name;
    if (checkingColumn !== targetName) {
      if (targetFound !== targetName) {
        row[targetColumn].mappingIcon = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NEW).icon;
        row[targetColumn].iconTooltip = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NEW, targetColumn).tooltip;
      } else {
        const tooltipInput1 = targetColumn === MAPPING_CONST.TOPIC ? MAPPING_CONST.SOURCE : MAPPING_CONST.DATASET;
        const tooltipInput2 = targetColumn === MAPPING_CONST.TOPIC ? MAPPING_CONST.TARGET : MAPPING_CONST.SUBJECT;
        row[targetColumn].mappingIcon = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_MISMATCH).icon;
        row[targetColumn].iconTooltip = this.mappingService.getMappingIcon(
          MAPPING_CONST.MAPPING_ICON_MISMATCH,
          tooltipInput1,
          tooltipInput2
        ).tooltip;
      }
    } else {
      if (!targetFound) {
        row[targetColumn].mappingIcon = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NEW).icon;
        row[targetColumn].iconTooltip = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NEW, targetColumn).tooltip;
      } else {
        row[targetColumn].mappingIcon = '';
        row[targetColumn].iconTooltip = '';
      }
    }
  }

  /**
   * getSubjects through an API
   * @param schemRegistryConnId schema registry connection id
   * @returns
   */

  getSubjects(schemRegistryConnId: string) {
    let getSubjectRequest$: Observable<any>;
    this.tableMappingLoadingSpinner = true;
    getSubjectRequest$ = this.mappingService.getSubjectsFromCatalog(schemRegistryConnId);
    getSubjectRequest$.pipe(first()).subscribe({
      next: (response: any) => {
        this.tableMappingLoadingSpinner = false;
        this.subjects = response.subjects ? response.subjects.map((ele) => ele.name) : response.map((ele) => ele.name);
        this.defaultMapping(this.topics, this.subjects);
      },
      error: (errorResponse: HttpErrorResponse) => {
        this.tableMappingLoadingSpinner = false;
        this.sidebarComponent?.parseHttpClientResponseMessage('error', errorResponse);
      }
    });
  }

  /**
   * compare subject details with row
   * @param row table mapping grid row
   * @returns
   */

  getSubjectDetails(row, subjects: any[]) {
    let subject: string;
    if (row.subject.name !== '') {
      subject = row.subject?.name;
    } else {
      subject = subjects?.find((sub) => sub === row.table.trim());
    }
    this.setTopicSubject(row, 'subject', subject, subjects);
  }

  private async getCatalogStatus() {
    return await this.catalogApiService
      .status(this.sourceDataConnection.id, true)
      .pipe(
        catchError(() => {
          this.catalogStatus = null;
          return of(null);
        }),
        map((catalogStatus: CatalogStatus) => {
          this.catalogStatus = catalogStatus;
        })
      )
      .toPromise();
  }

  /**
   * Handle Topic Chechbox Change
   * @param checkboxSelection topic checkbox true/false
   * @returns
   */
  onTopicCheckBoxChange(checkboxSelection: boolean) {
    this.createTopic = checkboxSelection;
    this.tableData.forEach((row) => {
      this.applyTargetNameByCheckbox(row, checkboxSelection, MAPPING_CONST.TOPIC);
    });
    this.patchPipeline();
  }

  /**
   * Handle Subject Chechbox Change
   * @param checkboxSelection subject checkbox true/false
   * @returns
   */
  onSubjectCheckBoxChange(checkboxSelection: boolean) {
    this.createSubject = checkboxSelection;
    this.tableData.forEach((row) => {
      this.applyTargetNameByCheckbox(row, checkboxSelection, MAPPING_CONST.SUBJECT);
    });
    this.patchPipeline();
  }

  /**
   * apply target name as per checkbox action
   * @param row table mapping row
   * @param checkboxSelection true/false checkbox
   * @param targetName target key name
   * @returns
   */

  applyTargetNameByCheckbox(row, checkboxSelection: boolean, targetName: string) {
    if (checkboxSelection && row[targetName]?.mappingIcon === MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED) {
      const targetMatchFound =
        targetName === MAPPING_CONST.TOPIC
          ? this.topics.find((ele) => ele === row.table.trim())
          : this.subjects.find((ele) => ele === row.topic.name);
      if (targetMatchFound) {
        row[targetName].mappingIcon = '';
        row[targetName].iconTooltip = '';
        row[targetName].name = targetMatchFound;
        row.isButtonEnabled = targetName === MAPPING_CONST.TOPIC ? true : row.isButtonEnabled;
      } else {
        row[targetName].name = row.table.trim();
        row[targetName].mappingIcon = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NEW_BY_SELECTION).icon;
        row[targetName].iconTooltip = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NEW_BY_SELECTION, targetName).tooltip;
        row.isButtonEnabled = targetName === MAPPING_CONST.TOPIC ? true : row.isButtonEnabled;
      }
    } else if (row[targetName]?.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION) {
      row[targetName].name = '';
      row[targetName].mappingIcon = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NA).icon;
      row[targetName].iconTooltip = this.mappingService.getMappingIcon(MAPPING_CONST.MAPPING_ICON_NA, targetName).tooltip;
      row.isButtonEnabled = targetName === MAPPING_CONST.TOPIC ? false : row.isButtonEnabled;
    }
  }

  tableMappingUpdateChange(event) {
    this.getSubjects(this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID).value);
    this.tableData.forEach((object) => {
      this.setTopicSubject(object, 'subject', object?.subject.name, this.subjects); // set icon and tooltip
      if (object.subject.name.endsWith(event.subject.name)) {
        // set the version
        object.schemaVersion = event.version;
        this.patchPipeline();
      }
    });
  }

  /**
   * getter for table mapping data obj
   * @returns
   */

  get pipelineMappingDataObject() {
    return {
      tableMapping: this.formMappingDataArr(this.tableData),
      createTopic: this.createTopic,
      createSubject: this.createSubject
    };
  }
  public patchPipeline = () => {
    this.pipelineEntityService.patchPipeline(this.pipelineMappingDataObject);
  };

  addUserDBCancelButtonClicked($event): void {
    this.isAdduserdatabaseVisible = !$event;
    if ($event === true) {
      this.navigateTo(`/pipelines/${this.pipeline.id}/edit/data`);
      this.progressIndicatorStateService.setActiveStepIndex(1);
    }
  }
}
