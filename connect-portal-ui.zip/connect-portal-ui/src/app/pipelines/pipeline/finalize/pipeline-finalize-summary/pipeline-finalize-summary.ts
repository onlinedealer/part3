export interface PipelineFinalizeSummary {
  name?: string;
  description?: string;
  selectedSourceData?: { noOfTables: number; noOfSchemasOrLibraries: number };
  sourceConnectionName?: string;
  sourceConnectionType?: string;
  targetConnectionName?: string;
  targetConnectionType?: string;
  pipelineEntityType?: string;
  projectName?: string;
}
