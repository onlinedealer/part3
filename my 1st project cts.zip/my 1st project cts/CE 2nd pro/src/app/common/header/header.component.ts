import { Component, OnInit } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  imagesPaths:any;

  constructor() { }

  ngOnInit() {
    this.imagesPaths = ImagePaths;
  }

}
