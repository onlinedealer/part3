import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentBillingComponent } from './payment-billing.component';


describe('PaymentBillingComponent', () => {
  let component: PaymentBillingComponent;
  let fixture: ComponentFixture<PaymentBillingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentBillingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentBillingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
