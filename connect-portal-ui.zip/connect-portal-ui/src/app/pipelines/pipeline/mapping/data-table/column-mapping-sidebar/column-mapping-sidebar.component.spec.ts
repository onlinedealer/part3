import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { Observable, of, throwError } from 'rxjs';
import { Connection } from 'src/app/connections/shared/connection';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { Pipeline, TableMapping } from '../../../shared/pipeline';
import { PipelineEntityService } from '../../../shared/pipeline-entity.service';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { ColumnList, ColumnMap } from '../../shared/map-columns';
import { ColumnMappingOverviewComponent } from './column-mapping-overview/column-mapping-overview.component';
import { ColumnMappingSidebarComponent } from './column-mapping-sidebar.component';
import { ColumnMappingTableComponent } from './column-mapping-table/column-mapping-table.component';

describe('ColumnMappingSidebarComponent', () => {
  const mockColumns = [
    { name: 'Keylex', dataType: 'long', isPrimaryKey: false },
    { name: 'Cardguard', dataType: 'double', isPrimaryKey: false }
  ];
  const mockColumnMaps: ColumnMap[] = [
    {
      sourceColumnName: 'sourceColumn1',
      sourceColType: 'type1',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn1',
      targetColType: 'targetType1',
      isExpression: false,
      state: 'SOURCE_COLUMN_SUPPORTED'
    },
    {
      sourceColumnName: 'sourceColumn2',
      sourceColType: 'type2',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn2',
      targetColType: 'targetType2',
      isExpression: false,
      state: 'SOURCE_COLUMN_SUPPORTED'
    }
  ];

  const mockColumnList: ColumnList[] = [
    {
      columnDataType: 'NUMBER',
      columnName: 'ABC',
      isCDCRowMetaDataColumn: false,
      isPrimaryKey: false
    },
    {
      columnDataType: 'VARCHAR',
      columnName: 'METADATA_USER_ID',
      isCDCRowMetaDataColumn: true,
      isPrimaryKey: false
    }
  ];

  const mockDisplayValues: any[] = [
    {
      sourceColumnName: 'sourceColumn1',
      sourceColType: 'type1',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn1',
      targetColType: 'targetType1',
      isExpression: false,
      id: 1
    },
    {
      sourceColumnName: 'sourceColumn2',
      sourceColType: 'type2',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn2',
      targetColType: 'targetType2',
      isExpression: false,
      id: 2
    }
  ];

  const mockTableMapping: TableMapping[] = [
    {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      columnMappings: mockColumnMaps,
      type: 'targetExistsWithMatch'
    }
  ];
  const mockRowData = {
    id: 1,
    subject: {
      name: ''
    }
  };
  let component: ColumnMappingSidebarComponent;
  let fixture: ComponentFixture<ColumnMappingSidebarComponent>;
  let pipelineMappingService: PipelineMappingService;
  let pipelineEntityService: PipelineEntityService;
  let getColumnsSpy;

  @Component({
    selector: 'p-connect-sidebar',
    template: '',
    providers: [
      {
        provide: SidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    open() {}
    close() {}
    parseHttpClientResponseMessage() {}
  }

  @Component({
    selector: 'p-connect-column-mapping-overview',
    template: '',
    providers: [
      {
        provide: ColumnMappingOverviewComponent,
        useClass: MockOverviewComponent
      }
    ]
  })
  class MockOverviewComponent {
    open() {}
  }

  @Component({
    selector: 'p-connect-column-mapping-table',
    template: '',
    providers: [
      {
        provide: ColumnMappingTableComponent,
        useClass: MockTableComponent
      }
    ]
  })
  class MockTableComponent {
    updateDisplayValues() {}
    updateData() {}
    defaultMapping() {}
    checkboxValues: [] = [];
    applyBulkMapping() {}
    applyResetDefault() {}
    updateHasCustomColumnMappings() {}
    validateGrid() {}
    updateAllInputFields() {}
  }

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      declarations: [ColumnMappingSidebarComponent, MockSidebarComponent, MockTableComponent, MockOverviewComponent],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: '' } }],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
    fixture = TestBed.createComponent(ColumnMappingSidebarComponent);
    component = fixture.componentInstance;
    pipelineMappingService = TestBed.inject(PipelineMappingService);
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    const pipelineSpy = spyOn(pipelineEntityService, 'getPipeline').and.returnValue({
      tableMapping: [
        {
          id: 'mapping_1abc',
          key: 'string',
          value: 'string',
          hasCustomColMappings: false,
          type: 'string',
          columnMappings: mockColumnMaps
        },
        {
          id: 'mapping_2cde',
          key: 'string',
          value: 'string',
          hasCustomColMappings: false,
          type: 'string',
          columnMappings: mockColumnMaps
        }
      ]
    } as Pipeline);
    component.tableMapping = [
      {
        id: 'mapping_1abc',
        key: 'string',
        value: 'string',
        hasCustomColMappings: false,
        type: 'string',
        columnMappings: mockColumnMaps
      }
    ];
    component.sourceDataConnection = { id: 'aaaa' } as Connection;
    component.pipeline = {
      id: 123,
      tableMapping: [{ key: 'key', value: 'value', hasCustomColMappings: true, columnMappings: mockColumns }],
      target: {
        parameters: [{ key: 'SCHEMA_REGISTRY_ID', value: 'SCHEMA_REGISTRY_ID' }]
      }
    } as any;
    component.tableMapping = [{ id: 'mapping_1abc', key: 'string', value: 'string', hasCustomColMappings: true, type: 'string' }];
    component.data = mockColumnMaps;
    component.checkedItems = mockColumnMaps;
    component.rowData = mockRowData;
    component.hasCustomColumnMappings = true;
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    component.renderTable = true;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the sidebar', fakeAsync(() => {
    const openSidebar = spyOn(component.sidebarComponent, 'open');
    const rowTopic = { topic: { mappingIcon: '' } };
    component.pipeline = { target: { parameters: [{ key: 'SCHEMA_REGISTRY_ID', value: 'SCHEMAREGISTRY' }] } } as Pipeline;
    component.rowData.id = 'mapping_1abc';
    component.tableMapping = [
      { id: 'mapping_1abc', key: 'key', value: 'value', hasCustomColMappings: true, type: 'TARGET_EXISTS_WITH_MATCH' }
    ];
    component.open(rowTopic);
    tick();
    component.hasCustomColumnMappings = true;

    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(openSidebar).toHaveBeenCalled();
    });
  }));

  it('should open the sidebar if mapping icon is ATTENTION_BLUE', () => {
    component.rowData.id = 'mapping_1abc';
    component.pipeline = { target: { parameters: [{ key: 'SCHEMA_REGISTRY_ID', value: 'SCHEMAREGISTRY' }] } } as Pipeline;
    component.tableMapping = [
      { id: 'mapping_1abc', key: 'key', value: 'value', hasCustomColMappings: true, type: 'TARGET_EXISTS_WITH_MATCH' }
    ];
    const openSidebar = spyOn(component.sidebarComponent, 'open');
    const rowTopic = { topic: { mappingIcon: 'ATTENTION_BLUE' } };
    component.open(rowTopic);
    expect(openSidebar).toHaveBeenCalled();
  });

  it('should receive hasCustomColMappings info from rowData when opening the sidebar', () => {
    const rowID = { id: 'mapping_1abc' };
    component.pipeline = { target: { parameters: [{ key: 'SCHEMA_REGISTRY_ID', value: 'SCHEMAREGISTRY' }] } } as Pipeline;
    component.tableMapping = [
      { id: 'mapping_1abc', key: 'key', value: 'value', hasCustomColMappings: true, type: 'TARGET_EXISTS_WITH_MATCH' }
    ];
    component.open(rowID);
    expect(component.hasCustomColumnMappings).toBeDefined();
  });

  it('should close the sidebar and reset previous state', () => {
    const closeSidebar = spyOn(component.sidebarComponent, 'close');
    component.close();
    expect(component.data.length).toBe(0);
    expect(component.checkedItems.length).toBe(0);
    expect(component.tableComponent.checkedItems.length).toBe(0);
    expect(component.hasCustomColumnMappings).toBeFalse();
    expect(closeSidebar).toHaveBeenCalled();
    expect(component.isReorderEnabled).toBeFalsy();
  });

  it('should call getColumnList API to populate the columnList', () => {
    getColumnsSpy = spyOn(pipelineMappingService, 'getColumns').and.returnValue(of(mockColumnList));
    const rowData = { schema: 'schemaName', table: 'tableName', topic: { name: 'topicName' } };
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    component.getColumnList(rowData);
    expect(getColumnsSpy).toHaveBeenCalled();
  });

  it('should handle error when calling getColumnList API', () => {
    const rowData = { schema: 'schemaName', table: 'tableName', topic: { name: 'topicName' } };
    const errorResponse = { error: { detailedMessage: 'getColumns failed' } };
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(pipelineMappingService, 'getColumns').and.returnValue(throwError(errorResponse));
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    component.getColumnList(rowData);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
  });

  it('should call getColumnMapping API to populate data', () => {
    const getMappingSpy = spyOn(pipelineMappingService, 'getColumnMappings').and.returnValue(of(mockColumns));
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    component.getColumnMapping();
    expect(getMappingSpy).toHaveBeenCalled();
  });
  it('should handle error when calling getColumnMapping API', () => {
    const errorResponse = { error: { detailedMessage: 'getMapping failed' } };
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(pipelineMappingService, 'getColumnMappings').and.returnValue(throwError(errorResponse));
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    component.getColumnMapping();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
  });

  it('should set schemaLibrary depending on connectionType', () => {
    component.sourceDataConnection.connectionType = 'DB2I';
    const rowData = { library: 'sampleLibrary' };
    component.setSchemaLibrary(rowData);
    expect(component.schemaLibrary).toEqual('sampleLibrary');
  });

  it('should call saveColumnMapping API', () => {
    component.pipeline = { id: '' } as any;
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    const saveColumnSpy = spyOn(pipelineMappingService, 'saveColumnMapping').and.returnValue(of(Observable));
    const updatedTableMappingEmitSpy = spyOn(component.updatedTableMapping, 'emit');
    spyOn(component.tableComponent, 'validateGrid').and.returnValue(true);
    component.primaryButtonClicked();
    expect(saveColumnSpy).toHaveBeenCalled();
    expect(updatedTableMappingEmitSpy).toHaveBeenCalled();
  });

  it('should handle error when calling saveColumnMapping API', () => {
    const errorResponse = { error: { detailedMessage: 'saveMapping failed' } };
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(pipelineMappingService, 'saveColumnMapping').and.returnValue(throwError(errorResponse));
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    spyOn(component.tableComponent, 'validateGrid').and.returnValue(true);
    component.primaryButtonClicked();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
  });

  it('should call saveTableMapping API', () => {
    spyOn(pipelineMappingService, 'getColumnMappings').and.returnValue(of(mockColumns));
    const saveTableSpy = spyOn(pipelineMappingService, 'saveTableMapping').and.returnValue(of(Observable));
    const rowData = { schema: 'schemaName', topic: { name: 'topicName' } };
    const updateCheckingDataSpy = spyOn(component.updateCheckingData, 'emit');
    component.saveTableMapping(rowData);
    expect(updateCheckingDataSpy).toHaveBeenCalled();
    expect(saveTableSpy).toHaveBeenCalled();
  });

  it('should handle error for saveTableMapping API', () => {
    const errorResponse = { error: { detailedMessage: 'saveTableMapping failed' } };
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(pipelineMappingService, 'saveTableMapping').and.returnValue(throwError(errorResponse));
    const rowData = {};
    component.saveTableMapping(rowData);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
  });

  it('should change the data when received', () => {
    component.dataChangeEvent(mockColumnMaps);
    expect(component.data).toEqual(mockColumnMaps);
  });

  it('should update customColumnMappings', () => {
    component.rowTableMapping = {
      id: 'mapping_1abc',
      key: 'key',
      value: 'value',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    component.hasCustomColumnMappingsChangeEvent(true);
    expect(component.rowTableMapping.hasCustomColMappings).toBe(true);
  });

  it('should apply bulkMappingObject when received', () => {
    const applyBulkMapping = spyOn(component.tableComponent, 'applyBulkMapping');
    const updateHasCustomColumnMappingsSpy = spyOn(component.tableComponent, 'updateHasCustomColumnMappings');
    component.bulkMappingSaveEvent(mockColumnMaps);
    expect(applyBulkMapping).toHaveBeenCalled();
    expect(updateHasCustomColumnMappingsSpy).toHaveBeenCalled();
  });

  it('should apply bulkMappingObject when received', () => {
    const applyResetDefault = spyOn(component.tableComponent, 'applyResetDefault');
    const updateHasCustomColumnMappingsSpy = spyOn(component.tableComponent, 'updateHasCustomColumnMappings');
    component.resetDataChangeEvent(mockColumnMaps);
    expect(applyResetDefault).toHaveBeenCalled();
    expect(updateHasCustomColumnMappingsSpy).toHaveBeenCalled();
  });

  it('should change the data when received', () => {
    component.updateCheckedItems(mockColumnMaps);
    expect(component.checkedItems).toEqual(mockColumnMaps);
  });

  it('should emit reordering change', () => {
    component.reorderChangeEvent({ checked: true });
    expect(component.isReorderEnabled).toBe(true);
  });

  it('should find the tableMapping of the current row', () => {
    component.rowData = { id: 'mapping_1abc' };
    expect(component.findTableMappingByID().id).toEqual('mapping_1abc');
  });

  it('should make the target available if schema registry exists in kafka', () => {
    component.pipeline = { target: { parameters: [{ key: 'NOT_SCHEMA_REGISTRY', value: 'NOT_SCHEMA_REGISTRY' }] } } as Pipeline;
    component.setTargetEditable();
    expect(component.targetEditable).toBe(true);
  });

  it('should absorb displayValues from table component', () => {
    component.displayValuesChangeEvent([{}]);
    expect(component.displayValues).toEqual([{}]);
  });

  it('should disable primary button from the table component', () => {
    component.primaryButtonDisable(false);
    expect(component.primaryButton.isDisabled).toBe(false);
  });

  it('should display warning for last row being deleted', () => {
    const event = { message: 'warningMessage' };
    const parseSpy = spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage');
    component.deleteErrorMessageEvent(event);
    expect(parseSpy).toHaveBeenCalledWith('warning', event);
  });
  it('should alphabetically sort masterColumnList', () => {
    component.masterColumnList = mockColumnList;
    component.alphabeticalSortColumnList();
    expect(component.masterColumnList[1].displayLabel).toEqual(
      'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ROW_METADATA_FIELDS.METADATA_USER_ID'
    );
  });

  it('should call getVersions API', () => {
    const mockVersionList = [{ version: '1' }, { version: '2' }];
    component.rowTableMapping = {
      type: 'SUBJECT_DOES_EXIST'
    } as TableMapping;
    const getVersionsSpy = spyOn(pipelineMappingService, 'getVersions').and.returnValue(of(mockVersionList));
    component.getVersions();
    expect(getVersionsSpy).toHaveBeenCalled();
    expect(component.versionsList).toEqual([
      { key: '2', value: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_OVERVIEW.DROPDOWN_NEWEST' },
      { key: '1', value: '1' }
    ]);
  });

  it('should handle error in getVersions API', () => {
    const errorResponse = { error: { detailedMessage: 'getVersionsFailed failed' } };
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(pipelineMappingService, 'getVersions').and.returnValue(throwError(errorResponse));
    component.getVersions();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledWith('error', errorResponse);
  });

  it('should call getColumnMapping when version is changed', () => {
    const getMappingSpy = spyOn(pipelineMappingService, 'getColumnMappings').and.returnValue(of(mockColumns));
    component.versionChangeEvent({ value: '5' });
    expect(getMappingSpy).toHaveBeenCalled();
  });

  it('should call getColumnMapping when schema registry exists subject does not exist', () => {
    component.pipeline.target.parameters = [{ key: '', value: '' }];
    const getMappingSpy = spyOn(pipelineMappingService, 'getColumnMappings').and.returnValue(of(mockColumns));
    spyOn(pipelineMappingService, 'getColumns').and.returnValue(of(mockColumnList));
    component.getColumnList('');
    expect(getMappingSpy).toHaveBeenCalled();
  });
});
