import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from "@angular/core";
import { trigger, state, transition, animate, style } from "@angular/animations";
import { TranslationsService } from "../../../../../app/services/translations-service";
import { MatCheckboxChange } from "@angular/material/checkbox";
import { Metering } from "../../../../models/metering.model";
import { FormControl } from "@angular/forms";

@Component({
    selector: "landisgyr-chart-options",
    templateUrl: "./chart-options.component.html",
    styleUrls: ["./chart-options.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush,
    animations: [
        trigger("openClose", [
            state(
                "open",
                style({
                    height: "340px"
                })
            ),
            state(
                "closed",
                style({
                    height: "40px"
                })
            ),
            transition("open => closed", [animate("0.5s ease-out")]),
            transition("closed => open", [animate("0.5s ease-in")])
        ])
    ]
})
export class ChartOptionsComponent {
    @Input()
    chartDataGrouping!: string;

    @Input()
    chartDataAvailableGroupingOptions: string[] = [];

    @Input()
    selectedMeteringPointOtherMeterings!: Metering[];

    @Input()
    selectedMeteringPointsChartDataSelectedMeterings!: { meteringId: number; meteringType: string }[];

    @Input()
    colors!: string[];

    @Output()
    chartDataGroupingSelection = new EventEmitter<string>();

    @Output()
    changeMeteringSelection = new EventEmitter<{ meteringPointId: number; meteringId: number; meteringType: string; selected: boolean }>();

    @Output() animationInProgress: EventEmitter<boolean> = new EventEmitter();
    @Output() animationDone: EventEmitter<boolean> = new EventEmitter();

    selectedMeterings = new FormControl();
    selectedMeteringsChanges$ = this.selectedMeterings.valueChanges;

    isOpen = true;

    array1Lenght!: number;
    array2Lenght!: number;

    constructor(public translations: TranslationsService) {}

    onGroupingSelectionToggleChange(selection: string) {
        this.chartDataGroupingSelection.emit(selection);
    }

    isOptionDisabled(optionValue: string) {
        return this.chartDataAvailableGroupingOptions.includes(optionValue) === false;
    }

    isMeteringOptionChecked(meteringId: number) {
        return (
            this.selectedMeteringPointsChartDataSelectedMeterings.filter(
                (metering) => metering.meteringId === meteringId && metering.meteringType === "profile"
            ).length > 0
        );
    }

    isMeteringOptionDisabled(meteringId: number) {
        return !this.isMeteringOptionChecked(meteringId) && this.selectedMeteringPointsChartDataSelectedMeterings.length > 200;
    }

    onMeteringOptionCheckChange(metering: Metering, event: MatCheckboxChange) {
        this.changeMeteringSelection.emit({
            meteringPointId: metering.meteringPointId,
            meteringId: metering.meteringId,
            meteringType: "profile",
            selected: event.checked
        });
    }

    getMeteringOptionsColumn1() {
        const index = Math.ceil(this.selectedMeteringPointOtherMeterings.length / 3);
        return this.selectedMeteringPointOtherMeterings.slice(0, index);
    }

    getMeteringOptionsColumn2() {
        const index = Math.ceil(this.selectedMeteringPointOtherMeterings.length / 3);
        return this.selectedMeteringPointOtherMeterings.slice(index, index * 2);
    }

    getMeteringOptionsColumn3() {
        const index = Math.ceil(this.selectedMeteringPointOtherMeterings.length / 3);
        return this.selectedMeteringPointOtherMeterings.slice(index * 2);
    }

    getIndexByMeteringName(meteringName: string) {
        return this.selectedMeteringPointOtherMeterings.findIndex((metering) => metering.name === meteringName);
    }

    toggle() {
        this.isOpen = !this.isOpen;
    }
    onAnimationStart() {
        this.animationInProgress.emit(true);
    }
    onAnimationComplition() {
        this.animationDone.emit(this.isOpen);
    }
}
