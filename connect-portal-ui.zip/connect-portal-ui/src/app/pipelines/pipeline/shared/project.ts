import { Pipeline } from './pipeline';

export class Project {
  id: string;
  name: string;
  projectType: string;
  dateCommitted?: string;
  dateEdited?: string;
  description?: string;
}

export enum ProjectType {
  REPLICATION = 'REPLICATION'
}

export class ProjectStats {
  overallStatus?: string;
  runtimeServerStatus?: string;
  replicationStatus?: string;
  captureStatus?: string;
  logReaderStatus?: string;
  pendingRows?: number;
  longestTotalLatency?: string;
  id?: string;
  projectName?: string;
  projectDescription?: string;
  agentName?: string;
  pipelines?: [];
}
