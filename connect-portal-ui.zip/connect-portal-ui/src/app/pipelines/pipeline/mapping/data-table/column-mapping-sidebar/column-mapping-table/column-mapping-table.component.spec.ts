import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { ColumnMap } from '../../../shared/map-columns';
import { ColumnMappingTableComponent } from './column-mapping-table.component';
import * as _ from 'lodash';
import { Renderer2, Type } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
import { of } from 'rxjs/internal/observable/of';
describe('ColumnMappingTableComponent', () => {
  let component: ColumnMappingTableComponent;
  let fixture: ComponentFixture<ColumnMappingTableComponent>;
  let renderer: Renderer2;
  let pipelineMappingService: PipelineMappingService;
  const mockColumnMaps: ColumnMap[] = [
    {
      sourceColumnName: 'sourceColumn1',
      sourceColType: 'type1',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn1',
      targetColType: 'targetType1',
      isExpression: false,
      state: 'SOURCE_COLUMN_SUPPORTED'
    },
    {
      sourceColumnName: 'sourceColumn2',
      sourceColType: 'type2',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn2',
      targetColType: 'targetType2',
      isExpression: false,
      state: 'SOURCE_COLUMN_SUPPORTED'
    }
  ];

  class Table {
    filterGlobal() {}
  }
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      declarations: [ColumnMappingTableComponent],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: '' } }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnMappingTableComponent);
    component = fixture.componentInstance;
    renderer = fixture.componentRef.injector.get<Renderer2>(Renderer2 as Type<Renderer2>);
    const mockColumnMaps: ColumnMap[] = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        state: 'SOURCE_COLUMN_SUPPORTED'
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        isExpression: false,
        state: 'SOURCE_COLUMN_SUPPORTED'
      }
    ];
    component.rowData = { hasCustomColMappings: true };
    component.data = mockColumnMaps;
    component.hasCustomColumnMappings = true;
    component.actionList = ['COPY', 'IGNORE'];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should delete the row when delete button is clicked', () => {
    component.displayValues = mockColumnMaps;
    const updateHasCustomColumnMappingsSpy = spyOn(component, 'updateHasCustomColumnMappings');
    component.deleteRow(component.displayValues[0]);
    expect(component.displayValues).toEqual([
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        isExpression: false,
        state: 'SOURCE_COLUMN_SUPPORTED'
      }
    ]);
    expect(updateHasCustomColumnMappingsSpy).toHaveBeenCalled();
  });

  it('should change the action type to respective dropdown item', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        isExpression: false
      }
    ];
    const updateHasCustomColumnMappingsSpy = spyOn(component, 'updateHasCustomColumnMappings');
    component.actionSelect(component.displayValues[0], { value: 'Copy' });
    expect(component.displayValues[0]).toEqual({
      sourceColumnName: 'sourceColumn1',
      sourceColType: 'type1',
      isKey: false,
      action: 'Copy',
      targetColumnName: 'targetColumn1',
      targetColType: 'targetType1',
      isExpression: false
    });
    expect(updateHasCustomColumnMappingsSpy).toHaveBeenCalled();
  });

  it('should generate unique id for each element in row', () => {
    component.data = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        state: 'SOURCE_COLUMN_SUPPORTED'
      }
    ];
    component.updateDisplayValues(component.data);
    expect(component.displayValues[0]).toEqual({
      sourceColumnName: 'sourceColumn1',
      sourceColType: 'type1',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn1',
      targetColType: 'targetType1',
      id: 1,
      isExpression: false,
      state: 'SOURCE_COLUMN_SUPPORTED'
    });
  });

  it('should map the defaults provided from the columnMappings', () => {
    component.defaultMapping(component.data);
    expect(component.displayValues[0]).toEqual({
      sourceColumnName: 'sourceColumn1',
      sourceColType: 'type1',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn1',
      targetColType: 'targetType1',
      id: 1,
      isExpression: false,
      state: 'SOURCE_COLUMN_SUPPORTED'
    });
  });

  it('should update data having removed id parameter from displayValues', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1,
        state: 'SOURCE_COLUMN_SUPPORTED'
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        isExpression: false,
        id: 2,
        state: 'SOURCE_COLUMN_SUPPORTED'
      }
    ];
    component.updateData();
    expect(component.data[0]).toEqual({
      sourceColumnName: 'sourceColumn1',
      sourceColType: 'type1',
      isKey: false,
      action: '',
      targetColumnName: 'targetColumn1',
      targetColType: 'targetType1',
      isExpression: false,
      state: 'SOURCE_COLUMN_SUPPORTED'
    });
  });

  it('should emit checked items', () => {
    const checkedItemsSpy = spyOn(component.checkedItemsChange, 'emit');
    component.onCheckedOrUnchecked();
    expect(checkedItemsSpy).toHaveBeenCalled();
  });

  it('should handle togglecase', () => {
    const casedTargetColumn = component.applyCasing('TOGGLECASE', 'target');
    expect(casedTargetColumn).toBe('tARGET');
  });

  it('should handle capitalization', () => {
    const casedTargetColumn = component.applyCasing('CAPITALIZE', 'target');
    expect(casedTargetColumn).toBe('Target');
  });

  it('should handle lowercase', () => {
    const casedTargetColumn = component.applyCasing('LOWERCASE', 'TARGET');
    expect(casedTargetColumn).toBe('target');
  });

  it('should handle uppercase', () => {
    const casedTargetColumn = component.applyCasing('UPPERCASE', 'target');
    expect(casedTargetColumn).toBe('TARGET');
  });

  it('should handle sentence casing', () => {
    const casedTargetColumn = component.applyCasing('SENTENCE_CASE', 'target column');
    expect(casedTargetColumn).toBe('Target Column');
  });

  it('should apply bulk change mapping to the checked items', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];
    const bulkMappingObj = { action: 'IGNORE', case: 'UPPERCASE', targetColumnName: [] };
    const checkedItems = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];
    component.applyBulkMapping(bulkMappingObj, checkedItems);
    expect(component.displayValues[0].targetColumnName).toEqual('TARGETCOLUMN1');
    expect(component.displayValues[0].action).toEqual('Ignore');
  });

  it('should apply bulk change mapping to the checked items in the case of action being COPY', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];
    const bulkMappingObj = { action: 'COPY', case: 'UPPERCASE', targetColumnName: [] };
    const checkedItems = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];
    component.applyBulkMapping(bulkMappingObj, checkedItems);
    expect(component.displayValues[0].targetColumnName).toEqual('TARGETCOLUMN1');
    expect(component.displayValues[0].action).toEqual('Copy');
  });

  it('should apply pattern to the targetColumnName', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];
    const bulkMappingObj = { targetColumnName: [{ code: 'abc' }, { code: 'SOURCE_COLUMN' }] };
    const checkedItems = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];
    component.applyPattern(bulkMappingObj, checkedItems);
    expect(component.displayValues[0].targetColumnName).toEqual('abcsourceColumn1');
  });

  it('should deep check object to see if they are equal', () => {
    const obj1 = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        id: 2
      }
    ];
    const obj2 = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        id: 3 // deliberate change to check function
      }
    ];
    const isEqual = _.isEqual(obj1, obj2);
    expect(isEqual).toBe(false);
  });

  it('should update hasCustomColumnMapping', () => {
    component.displayValues = mockColumnMaps;
    component.checkingValues = mockColumnMaps;
    const customMappingEmitSpy = spyOn(component.hasCustomColumnMappingsChange, 'emit');
    component.updateHasCustomColumnMappings();
    expect(customMappingEmitSpy).toHaveBeenCalled();
  });

  it('should apply resetDefault', () => {
    component.displayValues = mockColumnMaps;
    component.checkedItems = [
      {
        sourceColumnName: 'sourceColumn5',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn5',
        targetColType: 'targetType5',
        id: 1,
        isExpression: true
      }
    ];
    const resetData: ColumnMap[] = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        state: 'SOURCE_COLUMN_SUPPORTED'
      }
    ];
    component.applyResetDefault(resetData, component.checkedItems);

    expect(component.checkedItems).toEqual([
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1,
        isExpression: false
      }
    ]);
  });

  it('should add a new mapping to the grid', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];
    const updateHasCustomColumnMappingsSpy = spyOn(component, 'updateHasCustomColumnMappings');
    component.addColumnMapping();
    expect(component.displayValues.length).toBe(2);
    expect(component.displayValues[1].sourceColumnName).toBeNull();
    expect(component.displayValues[1].sourceColType).toBeNull();
    expect(component.displayValues[1].action).toBe('Copy');
    expect(component.displayValues[1].isKey).toBeFalse();
    expect(component.displayValues[1].isExpression).toBeNull();
    expect(component.displayValues[1].targetColumnName).toBeNull();
    expect(component.displayValues[1].targetColType).toBeNull();
  });

  it('should update selected keys', () => {
    component.selectedKeys = null;
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: true,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      }
    ];

    component.updateSelectedKeys();
    expect(component.selectedKeys.length).toBe(1);
  });

  it('should toggle isKey prameter', () => {
    let row = {
      sourceColumnName: 'originalSourceCol',
      sourceColType: null,
      isKey: false,
      action: '',
      targetColumnName: null,
      targetColType: null,
      id: 1
    };
    const updateHasCustomColumnMappingsSpy = spyOn(component, 'updateHasCustomColumnMappings');
    component.selectKey(row);
    expect(row.isKey).toBeTrue();
    expect(updateHasCustomColumnMappingsSpy).toHaveBeenCalled();
  });

  it('should update empty target column name upon selecting a physical source column that exists in the last save of the grid', () => {
    let row = {
      sourceColumnName: 'originalSourceCol',
      sourceColType: null,
      isKey: null,
      isExpression: false,
      action: 'Copy',
      targetColumnName: null,
      targetColType: null,
      id: 1
    };
    component.displayValues = [row];
    component.checkingValues = [
      {
        sourceColumnName: 'originalSourceCol',
        sourceColType: 'VARCHAR',
        isKey: false,
        isExpression: false,
        action: 'Copy',
        targetColumnName: 'targetCol',
        targetColType: 'VARCHAR',
        id: 1
      }
    ];
    const updateHasCustomColumnMappingsSpy = spyOn(component, 'updateHasCustomColumnMappings');
    component.onSourceColumnChange(row);
    expect(component.displayValues[0].sourceColType).toEqual('VARCHAR');
    expect(component.displayValues[0].isExpression).toBeFalse();
    expect(component.displayValues[0].targetColType).toEqual('VARCHAR');
  });

  it('should update physical fields except target field name even when original record is deleted', () => {
    let row = {
      sourceColumnName: 'originalSourceCol',
      sourceColType: null,
      isKey: null,
      action: '',
      targetColumnName: null,
      targetColType: null,
      id: 1
    };
    component.masterColumnList = [
      {
        columnName: 'originalSourceCol',
        columnDataType: 'columnDataType1'
      }
    ];
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        isExpression: false,
        id: 2
      },
      row
    ];
    component.checkingValues = [
      {
        sourceColumnName: 'originalSourceCol1',
        sourceColType: 'type1',
        isKey: true,
        action: '',
        targetColumnName: 'originalTargetCol',
        targetColType: 'targetType1'
      }
    ];
    component.metadataRows = [{ key: 'sv_originalSourceCol', value: 'sv_targetCol', cdcRowMetadataType: 'INCLUDE' }];
    component.onSourceColumnChange(row);
    expect(component.displayValues[2].targetColumnName).toBeNull();
    expect(component.displayValues[2].isExpression).toBeFalse();
  });

  it('should update fields when metadata row exists in the last save of the grid', () => {
    let row = {
      sourceColumnName: 'sv_originalSourceCol',
      sourceColType: null,
      isKey: null,
      isExpression: null,
      action: 'Copy',
      targetColumnName: null,
      targetColType: null,
      id: 1
    };
    component.checkingValues = [
      {
        sourceColumnName: 'sv_originalSourceCol',
        sourceColType: 'VARCHAR',
        isKey: false,
        isExpression: true,
        action: 'Copy',
        targetColumnName: 'sv_targetCol',
        targetColType: 'VARCHAR',
        id: 1
      }
    ];
    component.displayValues = [row];
    component.onSourceColumnChange(row);
    expect(component.displayValues[0].sourceColType).toEqual('VARCHAR');
    expect(component.displayValues[0].isExpression).toBeTrue();
    expect(component.displayValues[0].targetColumnName).toEqual('sv_targetCol');
    expect(component.displayValues[0].targetColType).toEqual('VARCHAR');
  });

  it('should update fields when metadata row does not exist in the last save of the grid', () => {
    let row = {
      sourceColumnName: 'sv_originalSourceCol',
      sourceColType: null,
      isKey: null,
      isExpression: null,
      action: 'Copy',
      targetColumnName: null,
      targetColType: null,
      id: 1
    };
    component.checkingValues = [];
    component.displayValues = [row];
    component.metadataRows = [{ key: 'sv_originalSourceCol', value: 'sv_targetCol', cdcRowMetadataType: 'INCLUDE' }];
    component.masterColumnList = [
      {
        columnName: 'sv_originalSourceCol',
        columnDataType: 'columnDataType1'
      }
    ];
    component.onSourceColumnChange(row);
    expect(component.displayValues[0].sourceColType).toEqual('columnDataType1');
    expect(component.displayValues[0].isExpression).toBeTrue();
    expect(component.displayValues[0].targetColumnName).toEqual('sv_targetCol');
    expect(component.displayValues[0].targetColType).toEqual('columnDataType1');
  });

  it('should detect DIFFERENT source & target column names for non-metadata rows', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: false,
      action: 'Copy',
      targetColumnName: 'COLUMNnew',
      targetColType: 'type1'
    };

    expect(component.areDifferentNames(row)).toBeTrue();
  });

  it('should NOT detect DIFFERENT source & target column names for non-metadata rows when TARGET FIELD IS EMPTY', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: false,
      action: 'Copy',
      targetColumnName: '',
      targetColType: 'type1'
    };
    expect(component.areDifferentNames(row)).toBeFalse();
  });

  it('should detect SAME source & target column names for non-metadata rows', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: false,
      action: 'Copy',
      targetColumnName: 'COLUMN',
      targetColType: 'type1'
    };

    expect(component.areDifferentNames(row)).toBeFalse();
  });

  it('should detect DIFFERENT source & target column names for metadata rows', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: true,
      action: 'Copy',
      targetColumnName: 'COLUMNnew',
      targetColType: 'type1'
    };

    component.metadataRows = [{ key: 'COLUMN', value: 'sv_targetCol', cdcRowMetadataType: 'INCLUDE' }];
    expect(component.areDifferentNames(row)).toBeTrue();
  });

  it('should NOT detect DIFFERENT source & target column names for metadata rows WHEN TARGET FIELD IS EMPTY', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: true,
      action: 'Copy',
      targetColumnName: '',
      targetColType: 'type1'
    };
    component.metadataRows = [{ key: 'COLUMN', value: 'sv_targetCol', cdcRowMetadataType: 'INCLUDE' }];
    expect(component.areDifferentNames(row)).toBeFalse();
  });

  it('should detect SAME source & target column names for metadata rows', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: true,
      action: 'Copy',
      targetColumnName: 'sv_targetCol',
      targetColType: 'type1'
    };

    component.metadataRows = [{ key: 'COLUMN', value: 'sv_targetCol', cdcRowMetadataType: 'INCLUDE' }];
    expect(component.areDifferentNames(row)).toBeFalse();
  });

  it('should detect DIFFERENT source & target column types', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: true,
      action: 'Copy',
      targetColumnName: 'COLUMN',
      targetColType: 'type3'
    };
    expect(component.areDifferentTypes(row)).toBeTrue();
  });

  it('should detect SAME source & target column types', () => {
    let row = {
      sourceColumnName: 'COLUMN',
      sourceColType: 'type1',
      isKey: true,
      isExpression: true,
      action: 'Copy',
      targetColumnName: 'COLUMN2',
      targetColType: 'type1'
    };
    expect(component.areDifferentTypes(row)).toBeFalse();
  });

  it('should search globally', () => {
    component.dt = jasmine.createSpyObj(['filterGlobal']);
    component.searchFilter = 'someString';
    expect(component.dt.filterGlobal).toHaveBeenCalled();
  });

  it('should check if all action values are ignore', () => {
    const ignoreMessageSpy = spyOn(component.errorMessageChange, 'emit');
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: 'Ignore',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: 'Ignore',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType2',
        isExpression: false,
        id: 2
      }
    ];
    const isAllIgnore = component.checkAllIgnore();
    expect(isAllIgnore).toBeTrue();
    const gridValidator = component.validateGrid();
    expect(gridValidator).toBeFalse();
    expect(ignoreMessageSpy).toHaveBeenCalled();
  });

  it('should handle empty field scenario', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: 'Ignore',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: 'Copy',
        targetColumnName: '',
        targetColType: 'targetType2',
        isExpression: false,
        id: 2
      }
    ];
    const validator = component.validateGrid();
    const empty = component.checkEmpty();
    expect(validator).toBeFalse();
    expect(empty).toBeTrue();
  });

  it('should return true if it is neither empty nor marked all as ignore', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: 'Ignore',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: 'Copy',
        targetColumnName: 'targetColumn2',
        targetColType: 'targetType2',
        isExpression: false,
        id: 2
      }
    ];
    const validator = component.validateGrid();
    expect(validator).toBeTrue();
  });

  it('should display validator if two targetColumnName are the same', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType2',
        isExpression: false,
        id: 2
      }
    ];
    const row = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      }
    ];
    const duplicate = component.checkDuplicate();
    const validator = component.targetValidate(row);
    expect(validator).toBe(false);
    expect(duplicate).toBeTrue();
  });

  it('should show error message if there is one last remaining row', () => {
    const errorMessageSpy = spyOn(component.errorMessageChange, 'emit');
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      }
    ];
    const row = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      }
    ];
    component.deleteRow(row);
    expect(component.displayValues.length).toEqual(1);
    expect(errorMessageSpy).toHaveBeenCalled();
  });

  it('should only select rows with non-empty source columns when clicking on tableHeaderCheckbox', () => {
    component.checkedItems = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        id: 1
      },
      {
        sourceColumnName: null,
        sourceColType: null,
        isKey: false,
        action: '',
        targetColumnName: null,
        targetColType: null,
        id: 2
      }
    ];
    component.onCheckedOrUnchecked();
    expect(component.checkedItems[0].id).toEqual(1);
  });

  it('should remove highlight to particular field', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      }
    ];
    const rendererRemoveSpy = spyOn(renderer, 'removeClass');
    const mockHTMlFields = [
      {
        type: 'text',
        disabled: false,
        value: 'value'
      }
    ] as unknown as Partial<HTMLFormElement[]>;
    component.addOrRemoveHighlightingToEmptyFields(mockHTMlFields);
    expect(rendererRemoveSpy).toHaveBeenCalled();
  });
  it('should add highlight to particular field', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      }
    ];
    const rendererAddSpy = spyOn(renderer, 'addClass');
    const mockHTMlFields = [
      {
        type: 'number',
        innerText: ''
      }
    ] as unknown as Partial<HTMLFormElement[]>;
    component.addOrRemoveHighlightingToEmptyFields(mockHTMlFields);
    expect(rendererAddSpy).toHaveBeenCalled();
  });

  it('should return false if duplicate entries are found for target field', () => {
    component.displayValues = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: 'Ignore',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        id: 1
      },
      {
        sourceColumnName: 'sourceColumn2',
        sourceColType: 'type2',
        isKey: false,
        action: 'Copy',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType2',
        isExpression: false,
        id: 2
      }
    ];
    const checkDuplicate = component.checkDuplicate();
    const validator = component.validateGrid();
    expect(checkDuplicate).toBeTrue();
    expect(validator).toBeFalse();
  });

  it('should scroll to invalid row on save click', () => {
    const mockHTMlFields = [
      {
        type: 'text',
        disabled: false,
        value: '',
        scrollIntoView: function () {}
      }
    ] as unknown as Partial<HTMLFormElement[]>;
    const getFormFieldsSpy = spyOn(component, 'getAllFormElements').and.returnValue(mockHTMlFields);
    spyOn(renderer, 'addClass');
    component.handleEmptyFields(true);
    expect(getFormFieldsSpy).toHaveBeenCalled();
  });
});
