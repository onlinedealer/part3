import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from '../../../../../../core/transloco-testing.module';
import { KafkaOptionsComponent } from './kafka-options.component';

describe('KafkaOptionsComponent', () => {
  let component: KafkaOptionsComponent;
  let fixture: ComponentFixture<KafkaOptionsComponent>;
  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [KafkaOptionsComponent],
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule, DropdownModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: '' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KafkaOptionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should validate bundling limit conditionally', () => {
    const bundlingLimit = component.optionsForm.controls.bundlingLimit;
    component.onBundlingChange(false);
    expect(bundlingLimit.validator).toBeFalsy();
    component.onBundlingChange(true);
    expect(bundlingLimit.validator).toBeTruthy();
  });
});
