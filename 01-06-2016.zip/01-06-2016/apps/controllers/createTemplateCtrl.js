(function() {
    'use strict';

    fileuploader.controller("createTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', createTemplateCtrl]);

    function createTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.uploadpreview = "apps/images/income.jpg";
        $scope.rows = [];
        $scope.imageArray = [];
        $scope.tempArray = [];
        $scope.tempTemplateAreaName = [];
        $scope.uploadPreviewTemplate = "";

        $scope.fetchpreviewData = function() {
                var rowData = $rootScope.globalTemplateUpResp;
                var id = rowData.TIFF_ID;
                //var id = rowData.ORIGIONAL_ID;
                
                console.log(id)
                var url = "/ocr/rest/v1/service/get/tiffimageconverted/tiff/file/" + id;
                ///ocr/rest/v1/service/get/tiffimage/tiff/file/
                //var url = "/ocr/rest/v1/service/get/tiffimage/tiff/file/" + id;
                console.log(url)
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                
                $scope.getId = id;
                promise.then(function(data) {
                    console.log(data)
                    var outputimage = data;
                    var output = "data:image/jpg;base64," + outputimage.inputdata;
                    console.log(output)
                    $scope.uploadPreviewTemplate = output;
                    //console.log($scope.uploadPreviewTemplate)
                    //$rootScope.globalImgPreview = $scope.uploadPreviewTemplate;
                    //console.log($scope.uploadPreviewTemplate)
                });

                promise.catch(function(data) {
                    console.log('catch block executed', data);
                    return data;
                });
        };
        $scope.fetchpreviewData();
        

        $scope.addRow = function() {
            if ($scope.templateAreaName == null && $scope.custTemplateName == null) {
                alert("All Fields are Required")
            } else {
                for (var i = 0; i < $scope.tempArray.length; i++) {

                    $scope.imageArray.push($scope.tempArray[i]);
                    $scope.tempTemplateAreaName.push($scope.templateAreaName);
                    console.log($scope.tempTemplateAreaName)
                }
                $scope.tempArray = [];
                $scope.templateAreaName = [];
                var tempAreaName = [];
                tempAreaName = $scope.templateAreaName;
            }
        };

        $scope.saveTemplate = function(totalData) {
            var obj = {};
            obj['templateName'] = $scope.custTemplateName;
            obj['rows'] = $scope.imageArray;
            obj['headers'] = $scope.tempTemplateAreaName;
            console.log(obj)
        };
        $('#target').Jcrop({
            onSelect: showCords,
        });
        function showCords(c) {
            var obj = {};
            obj['x'] = c.x;
            obj['y'] = c.y;
            obj['h'] = c.w;
            obj['w'] = c.h;
            $scope.tempArray.push(obj);
            //console.log(obj)

            $scope.$apply(function() {

            });
        }
    }
})();