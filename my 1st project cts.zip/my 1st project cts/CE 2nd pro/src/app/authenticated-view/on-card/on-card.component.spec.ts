import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OnCardComponent } from './on-card.component';

describe('OnCardComponent', () => {
  let component: OnCardComponent;
  let fixture: ComponentFixture<OnCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OnCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OnCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
