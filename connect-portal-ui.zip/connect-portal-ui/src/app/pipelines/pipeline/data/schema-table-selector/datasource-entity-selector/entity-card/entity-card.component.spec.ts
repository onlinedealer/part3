import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TableModule } from 'primeng/table';
import { getTranslocoModule } from '../../../../../../core/transloco-testing.module';
import { FilterComponent } from '../../../../../../shared/components/filter/filter.component';
import { EntityCardComponent } from './entity-card.component';
import { FilterService } from 'primeng/api';

describe('EntityCardComponent', () => {
  let component: EntityCardComponent;
  let fixture: ComponentFixture<EntityCardComponent>;
  let filterService: FilterService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EntityCardComponent, FilterComponent],
      imports: [TableModule, getTranslocoModule()]
    }).compileComponents();
    fixture = TestBed.createComponent(EntityCardComponent);
    filterService = TestBed.inject(FilterService);
    component = fixture.componentInstance;
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`showFilter has default value`, () => {
    expect(component.showFilter).toEqual(true);
  });

  it(`allowSelection has default value`, () => {
    expect(component.allowSelection).toEqual(true);
  });

  it('should call updateRowStyle method', () => {
    const mockEvent = { type: 'click', target: { classList: [] } };
    const mockRowData = { library: 'sales', selected: 21 };
    spyOn(component, 'updateRowStyle');
    component.rowSelection(mockEvent, mockRowData);
    expect(component.updateRowStyle).toHaveBeenCalled();
  });

  it('should call checkBoxSelection method', () => {
    const mockEvent = { type: 'checkbox' };
    const mockRowData = { tables: 'customers', journal: 'qauser1/qsqcjrn' };
    spyOn(component, 'checkBoxSelection');
    component.rowSelection(mockEvent, mockRowData);
    expect(component.checkBoxSelection).toHaveBeenCalled();
  });

  it('should call checkBoxSelection method for tri-state checkbox', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: true
    };
    const mockEvent = {
      data: {},
      originalEvent: {
        stopPropagation: () => {},
        stopImmediatePropagation: () => {},
        preventDefault: () => {}
      }
    };
    const mockRowData = { tables: 'customers', journal: 'qauser1/qsqcjrn' };
    spyOn(component.dataSelected, 'emit');
    component.checkBoxSelection(mockEvent, mockRowData);
    expect(component.dataSelected.emit).toHaveBeenCalled();
  });

  it('should call updateRowStyle method on row click', () => {
    component.isLoading = true;
    spyOn(component, 'rowSelection');
    component.allowSelection = true;
    component.cardDataModel = {
      headers: [
        { fieldName: 'libraries', displayName: 'Libraries' },
        { fieldName: 'selected', displayName: 'Selected' }
      ],
      keyField: 'libraries',
      rowHover: true,
      scrollHeight: '250px'
    };
    component.apiData = [
      { libraries: 'SALES', selected: 21 },
      { libraries: 'FINANCIAL', selected: 18 }
    ];
    component.isLoading = false;
    component.headerText = 'Sample Header';
    component.showFilter = false;
    const targetElement: HTMLElement = document.querySelector('tbody tr:first-child td:first-child');
    if (targetElement) {
      targetElement.click();
      expect(component.rowSelection).toHaveBeenCalled();
    }
    expect(component.apiData).toBeDefined();
  });

  it('should run updateRowStyle method and emit event', () => {
    const mockTableRow1 = document.createElement('tr');
    const mockTableRow2 = document.createElement('tr');
    const childElement = document.createElement('td');
    mockTableRow1.appendChild(childElement);
    mockTableRow2.appendChild(childElement);
    const mockEvt = {
      target: {
        parentElement: {
          parentElement: {
            querySelectorAll: (inp: string) => {
              return [mockTableRow1, mockTableRow2];
            }
          },
          classList: {
            add: (inp: string) => {},
            remove: (input: string) => {}
          }
        }
      }
    };
    spyOn(component.rowSelected, 'emit');
    const mockRowData = { tables: 'sales', selected: 18 };
    component.updateRowStyle(mockEvt, mockRowData);
    expect(component.rowSelected.emit).toHaveBeenCalled();
  });

  it('should checkbox selection emit appropriate event', () => {
    spyOn(component.dataSelected, 'emit');
    component.cardDataModel = {
      headers: [],
      showTriState: false
    };
    const mockEvent = {
      data: {},
      originalEvent: {
        stopPropagation: () => {},
        stopImmediatePropagation: () => {},
        preventDefault: () => {}
      }
    };
    component.checkBoxSelection(mockEvent);
    expect(component.dataSelected.emit).toHaveBeenCalled();
  });

  it('should checkbox un-select emit appropriate event', () => {
    spyOn(component.dataUnselected, 'emit');
    const mockEvent = {
      data: {},
      originalEvent: {
        stopPropagation: () => {},
        stopImmediatePropagation: () => {},
        preventDefault: () => {}
      }
    };
    component.checkBoxUnselect(mockEvent);
    expect(component.dataUnselected.emit).toHaveBeenCalled();
  });

  it('should checkbox un-select emit appropriate event when original event is missing', () => {
    spyOn(component.dataUnselected, 'emit');
    const mockEvent = {
      data: {},
      stopPropagation: () => {},
      stopImmediatePropagation: () => {},
      preventDefault: () => {}
    };
    component.checkBoxUnselect(mockEvent);
    expect(component.dataUnselected.emit).toHaveBeenCalled();
  });

  it('should filter text not be empty', () => {
    component.dataTable = jasmine.createSpyObj(['filterGlobal']);
    const searchString = 'test1';
    component.filterData(searchString);
    expect(component.dataTable.filterGlobal).toHaveBeenCalled();
  });

  it('should emit select all event', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: false
    };
    spyOn(component.selectAllRows, 'emit');
    const mockEvent = {};
    component.selectAll(mockEvent);
    expect(component.selectAllRows.emit).toHaveBeenCalled();
  });

  it('should change the rowData selected value of tri-state change as per the selection', () => {
    const mockTriStateEvent = true;
    const mockRowData = { selected: false };
    component.triStateChange(mockTriStateEvent, mockRowData);
    expect(mockRowData.selected).toBeTruthy();
  });

  it('should change the no records found message to the one for filtering', () => {
    component.dataTable = jasmine.createSpyObj(['filterGlobal']);
    const searchString = 'test1';
    component.filterData(searchString);
    expect(component.noRecordsFoundMessage).toBe(component.noResultsFoundMessage);
  });

  it('should change the no records found message back to the default when the filter is cleared', () => {
    component.dataTable = jasmine.createSpyObj(['filterGlobal']);
    let searchString = 'test1';
    component.filterData(searchString);
    searchString = '';
    component.filterData(searchString);
    expect(component.noRecordsFoundMessage).toBe(component.emptyMessage);
  });

  it('should set the sort mode to single by default', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: false
    };
    expect(component.sortMode).toBe('single');
  });

  it('should return to sort order of first field', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: false,
      sortMetaList: [
        { field: 'a', order: -1 },
        { field: 'b', order: 1 }
      ]
    };
    expect(component.sortOrder).toBe(-1);
  });

  it('should return the name of first sort field', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: false,
      sortMetaList: [
        { field: 'a', order: -1 },
        { field: 'b', order: 1 }
      ]
    };
    expect(component.sortField).toBe('a');
  });

  it('should return sort order as undefined if no sort field is specified', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: false
    };
    expect(component.sortOrder).toBeUndefined();
  });

  it('should return all schema table columns, including last cataloged column', () => {
    component.cardDataModel = {
      headers: [
        { displayName: 'Libraries', fieldName: 'name', sort: true },
        { displayName: 'Tables selected', fieldName: 'tableSelectionCount', sort: true },
        { displayName: 'Last Cataloged', fieldName: 'lastCataloged', sort: true, isHidden: false }
      ],
      showTriState: false
    };
    expect(component.columnFields.length).toBe(3);
  });

  it('should hide last cataloged column in schemas table if scalable commit ff is disabled', () => {
    component.cardDataModel = {
      headers: [
        { displayName: 'Libraries', fieldName: 'name', sort: true },
        { displayName: 'Tables selected', fieldName: 'tableSelectionCount', sort: true },
        { displayName: 'Last Cataloged', fieldName: 'lastCataloged', sort: true, isHidden: true }
      ],
      showTriState: false
    };
    expect(component.columnFields.length).toBe(2);
  });

  it('should return the sort field  as undefined if no sort field is specified', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: false
    };
    expect(component.sortField).toBeUndefined();
  });

  it('should set the sort mode to multiple when sortMetaList has multiple sort columns', () => {
    component.cardDataModel = {
      headers: [],
      showTriState: false,
      sortMetaList: [
        { field: 'a', order: -1 },
        { field: 'b', order: 1 }
      ]
    };
    expect(component.sortMode).toBe('multiple');
  });

  it('should register the custom filter', () => {
    spyOn(filterService, 'register');
    component.dropdownModel = {
      options: ['journal1', 'journal2'],
      selectedOption: '',
      customFilter: {
        name: 'customFilter',
        filter: (value, filter: string) => {
          if (filter === undefined || filter === null || !value) {
            return false;
          }

          return filter === '' || value.toString() === filter.toString();
        }
      }
    };
    component.ngOnInit();
    expect(filterService.register).toHaveBeenCalled();
  });

  it('should filter the data table based on the dropdown option selected', () => {
    component.dataTable = jasmine.createSpyObj(['filter']);
    component.dropdownModel = {
      options: ['All journals', 'journal1', 'journal2'],
      selectedOption: '',
      ignoredOption: 'All journals',
      filter: { journal: { value: '', matchMode: 'customFilter' } },
      customFilter: {
        name: 'customFilter',
        filter: (value, filter: string) => {
          if (filter === undefined || filter === null || !value) {
            return false;
          }

          return filter === '' || value.toString() === filter.toString();
        }
      }
    };
    component.dataTable.filters = [];
    component.onDropdownChange('journal1');
    expect(component.dataTable.filter).toHaveBeenCalled();
  });

  it('should filter the dropdown items', () => {
    component.dropdownModel = {
      options: ['1journal', '2journal'],
      selectedOption: '',
      customFilter: {
        name: 'customFilter',
        filter: (value, filter: string) => {
          if (filter === undefined || filter === null || !value) {
            return false;
          }

          return filter === '' || value.toString() === filter.toString();
        }
      }
    };
    component.filterItems({ query: '2j' });
    expect(component.filteredItems).toEqual(['2journal']);
  });
});
