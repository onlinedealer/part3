export interface MeteringPointStateInREST {
    commentBy: string;
    commentTime: number;
    comments: string;
    meteringPointStateId: number;
    sourceDescription?: any;
    startTime: number;
    endTime: number;
    stateDescription: string;
    stateType: MeteringPointStateTypeInREST;
    stateValue: string;
}

export interface MeteringPointStateTypeInREST {
    description?: string;
    displaySequenceNo: number;
    identifier: string;
    modifiable: number;
    mpLifeCycleStateIdentifier: string;
    mpLifecycleClassName?: string;
    name: string;
    objectType: number;
    purpose?: any;
    reasonCategoryClassId?: any;
    reasonCategoryClassName?: string;
    reasonCategoryIdentifier?: string;
    stateTypeId: number;
    usage: number;
}

export interface MeteringPointState {
    meteringPointStateId: number;
    comments: MeteringPointStateComment[];
    startTime: number;
    endTime: number;
    duration?: number;
    description?: string;
    value: string;
    typeId: number;
    typeIdentifier: string;
    typeDisplaySequenceNo: number;
    typeModifiable: number;
    typeName: string;
    typeObjectType: number;
    typeUsage: number;
}

export interface MeteringPointStateComment {
    commentedBy: string;
    time: number;
    text: string;
}
