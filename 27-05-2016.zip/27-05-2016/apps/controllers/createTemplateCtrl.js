(function() {
    'use strict';

    fileuploader.controller("createTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', createTemplateCtrl]);

    function createTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.uploadpreview = "apps/images/income.jpg";
        $scope.rows = [];
        $scope.imageArray = [];
        var tarGet = document.getElementById("target");
        var imgW = tarGet.clientWidth;
        var imgH = tarGet.clientHeight;
        var newW = 200;
        var jcrop_api;
        $scope.onClick = function(event) {
            var x = event.x;
            var y = event.y;
            var offsetX = event.offsetX;
            var offsetY = event.offsetY;
            console.log(offsetX, offsetY);
        };

        $scope.addRow = function() {
            var obj = $rootScope.globalDimenData;
            fileuploader.utils.addingObj(obj);
        };

        $('#target').Jcrop({
            onSelect: showCords,
        });

        function showCords(c) {

            $scope.$apply(function() {
                var obj = {};
                obj['startPointX'] = c.x;
                obj['startPointY'] = c.y;
                obj['imageWidth'] = c.w;
                obj['imageHeight'] = c.h;
                $scope.imageArray.push(obj);
                console.log(obj)
            });
        }
    }
})();
