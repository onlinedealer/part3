﻿(function () {
    'use strict';

    angular.module('arm').controller('activityDetailCtrl',
                ['$scope', '$state', '$stateParams', '$ionicModal', '$ionicSideMenuDelegate', 'activityService', 'contactService','utility', 'GENERAL_CONFIG', 'MASTER_TABLE', activityDetailCtrl]);

    function activityDetailCtrl($scope, $state, $stateParams, $ionicModal, $ionicSideMenuDelegate, activityService,contactService, utility, GENERAL_CONFIG, MASTER_TABLE) {
        $scope.isEditButtonFlag = true;
        var activitiesID = $stateParams.activitiesId;

        loadActivityDetails();

        function loadActivityDetails() {
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("deviceready", onDeviceReady, false);
            }
            var fieldSet = [];
            fieldSet = activityService.actGetFieldSet();
            $scope.activityDetails = [];
            $scope.actPartUsrLst = [];
            $scope.actIntUsrLst = [];
            $scope.actAddInfoLst = [];
            $scope.actNotes = [];

            $scope.activityDetails = activityService.getActivity();
            $scope.activityDetails.Notes = [];
            if ($scope.activityDetails.length > 0) {
                $scope.activityDet = $scope.activityDetails[0];                            
            }
            $scope.isEditButtonFlag = utility.allowEditing($scope.activityDetails[0]);
            activityService.sqlGetParAll(activitiesID).then(function (result) {
                $scope.actPartUsrLst = GetParList('CP', result);
                $scope.actIntUsrLst = GetParList('UP', result);
                activityService.setParUser($scope.actPartUsrLst);
                activityService.setParInternal($scope.actIntUsrLst);
            });
            
            activityService.sqlGetNotesAll(activitiesID).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.actNotes.push(result.rows.item(i));                    
                }
                activityService.setNotes($scope.actNotes);
                if ($scope.actNotes.length > 0) {
                    $scope.activityDetails[0].Notes.Description = $scope.actNotes[0]['Description'];
                }
            });
            
            activityService.sqlGetAddFields(activitiesID).then(function (result) {
                for (var i = 0; i < fieldSet.length; i++) {
                    $scope.actAddInfoLst.push({
                        FieldLabel: fieldSet[i].FieldLabel,
                        FieldName: fieldSet[i].FieldName,
                        FieldValue: result.rows.item(0)[fieldSet[i].FieldName],
                        IsVisible: fieldSet[i].IsVisible,
                        IsConfidential: fieldSet[i].IsConfidential,
                        IsMandatory: fieldSet[i].IsMandatory
                    });
                }
                activityService.setFields($scope.actAddInfoLst);
            });

        }

        ///////////////////////////////////model for the location start ////////////////////////////////
        $scope.geoLocationArr = {}
        $ionicModal.fromTemplateUrl('app/views/common/geolocation.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalLocation = modal;
            //$scope.initMap();
        });
        $scope.openAddLocation = function (loc) {
            var locArr=loc.split(' ');            
            $scope.geoLocationArr.lat = locArr[0];
            $scope.geoLocationArr.log = locArr[1];
            $scope.$broadcast('changeText', {});
            $scope.modalLocation.show();
        };
        $scope.closeLocation = function () {
            $scope.modalLocation.hide();
        };

        //save the field data
        $scope.actionLocation = function () {
            //var field = $scope.actModel;           
            $scope.modalLocation.hide();
        };

        //////////////////////////////////////////location END //////////////////////////////////////////////
                
        $scope.selActTypeIndx = -1;

        $scope.fnclickToggle = function ($index, actStageId) {
            if (actStageId > 1) return;
            $scope.selActTypeIndx = $index;
        };

        $scope.fnswitchToggle = function ($index) {
            $scope.selActTypeIndx = -1;
        };

        function GetParList(type, res) {
            var lst = [];
            for (var i = 0; i < res.rows.length; i++) {
                if (type == res.rows.item(i)['Type'])
                    lst.push(res.rows.item(i));
            }
            return lst;
        }

        $scope.toggleGroup = function (group) {
            group.show = !group.show;
        };

        $scope.isGroupShown = function (group) {
            return !group.show;
        };

        $scope.openEditMode = function () {
            $state.go('tab.activityAdd', { actId: activitiesID, editModeFlag: 1, screenType: ''  });
        }

        $scope.groupsAcd = [
                    {
                        title: 'Notes',
                        content: 'activityNote'
                    },
                  {
                      title: 'Additional activity details',
                      content: 'activityAddInfo'
                  },
                  {
                      title: "Activity participant contacts",
                      content: 'activityParUser'
                  },
                    {
                        title: "Activity participant internal",
                        content: 'activityIntUser'

                    }
        ];

        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };

        //////////////////CALL/SMS/EMAIL////////////////////////////////////
        function onDeviceReady() {
            // Register the event listener
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("resume", onEndCallKeyDown, false);
            }
        }

        $scope.count = 0;
        $scope.devID = 0;
        $scope.startDt;
        function onEndCallKeyDown() {
            if ($scope.count >= 1) return;
            if ($scope.type != 'Call') return;
            $scope.count++;
            var endDt = new Date();
            checkTime($scope.startDt, endDt);
        }

        function checkTime(startDt, endDt) {
            var dif = endDt.getTime() - startDt.getTime();
            var difDt = dif / 1000;
            var finalDifDate = Math.abs(difDt);
            if (finalDifDate >= 15) {
                $scope.openHappend('D', $scope.devID, $scope.type);
            }
        }

        $scope.openHappend = function (val, activitiesId, selActType) {
            activityService.setActStatus('C');            
            $state.go('tab.activityHappen', { devObjId: activitiesId, actStatgeType: val, screenType: GENERAL_CONFIG.ScreenType.ActivityDetail, actType: selActType });
            //$state.go('tab.activityHappen', { devObjId: activitiesId, actStatgeType: val, screenType: GENERAL_CONFIG.ScreenType.ContactList, actType: selActType });
            
        };

        $scope.openActivityType = function (type, activitiesID, stageId, ConDevId) {
            if (stageId > GENERAL_CONFIG.ActivityStage.Open) {
                return;
            }
            activityService.sqlGetCommnications(ConDevId).then(function (result) {               
                var comArr = contactService.getAllComData(result);
                $scope.phone = comArr.mobilePhone;
                $scope.email = comArr.email;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                if (type == 1) {
                    $scope.callNumber(activitiesID, stageId);
                }
                else if (type == 3) {//sms
                    $scope.openSMS(activitiesID, stageId);
                }
                else if (type == 4) {//email
                    $scope.openEmail(activitiesID, stageId);
                }
            });

        }
        
        $scope.openSMS = function (activitiesID, stageId) {
            $scope.count = 0;
           
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }
            var message = '';//'hello text';
            //console.log("going to send " + message + " to " + number);

            //simple validation for now
            //if (number === '' || message === '') return;

            var msg = {
                phoneNumber: number,
                textMessage: message
            };
            //CONFIGURATION
            var options = {
                replaceLineBreaks: false, // true to replace \n by a new line, false by default
                android: {
                    intent: 'INTENT'  // send SMS with the native android SMS messaging
                    //intent: '' // send SMS without open any other app
                }
            };

            var success = function (res) {
                var s = res;
                $scope.type = 'SMS';
                $scope.openHappend('D', activitiesID, 'SMS');
                //if(s == 'ok')
                //alert('Message sent successfully');
            };

            var error = function (e) { console.log('Message Failed:' + e); };
            sms.send(number, message, options, success, error);
        }

        $scope.openEmail = function (activitiesID, stageId) {
            $scope.count = 0;
            $scope.type = 'EMAIL';
            cordova.plugins.email.open({
                to: $scope.email,
                cc: '',
                bcc: [''],
                subject: 'Greetings',
                body: 'test mail'
            });
            $scope.openHappend('D', activitiesID, 'Email');
        }

        $scope.callNumber = function (activitiesID, stageId) {            
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }

            window.plugins.CallNumber.callNumber(function () {
                if (window.cordova && ionic.Platform.isAndroid()) {
                    $scope.startDt = new Date();
                    $scope.type = 'Call';
                    $scope.devID = activitiesID;
                    $scope.count = 0;
                }
                else {
                    $scope.openHappend('D', activitiesID, 'Call');
                }
            }, function () {
                console.log("eroor");
                //error logic goes here
            }, number)
        };
          /////////////////CALL/SMS/EMAIL////////END///////////////////////

        $scope.backPage = function () {
            $state.go('tab.activity');
        }
    };

})();