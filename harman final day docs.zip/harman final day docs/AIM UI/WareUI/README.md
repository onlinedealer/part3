#New Ware UI development

