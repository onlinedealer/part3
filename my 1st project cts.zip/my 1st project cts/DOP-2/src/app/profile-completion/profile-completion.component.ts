import { Component, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { AjaxUtilityService } from '../shared/utility/ajax-utility.service';
import { HttpResponse } from '@angular/common/http';
import { ClubGenericErrorComponent } from '../shared/components/club-generic-error/club-generic-error.component';
import { ClubConstantsService } from '../shared/utility/club-constants.service';
import { FormValidationComponent } from '../shared/components/form-validation/form-validation.component';
import { UtagService } from 'utag-module';
import { RouteConfigurations } from '../shared/utility/club-constants.service';
import { Title } from '@angular/platform-browser';

@Component({
  selector: 'app-profile-completion',
  templateUrl: './profile-completion.component.html',
  styleUrls: ['./profile-completion.component.scss']
})
export class ProfileCompletionComponent implements OnInit, AfterViewInit {

  constructor(private fb: FormBuilder,
              private _ajaxUtility: AjaxUtilityService,
              private _router: Router,
              private route: ActivatedRoute,
              private clubContants: ClubConstantsService,
              private _utag: UtagService,
              private _title: Title
            ) {
              _title.setTitle(RouteConfigurations.profileCompletionTitle);
            }

  /*@ViewChild (FormValidationComponent)
  private formValidationComponent: FormValidationComponent;*/

  // Created an instance of the Form group for profile completion form
  profileCompletionFirstForm: FormGroup;

  // Created an instance of the Form group for profile completion form
  profileCompletionSecondForm: FormGroup;

  // Flag to hold the form submit status for first form
  firstFormSubmitted: Boolean;

  // Flag to hold the second form submit information
  secondFormSubmitted: Boolean;

  // This flag checks if the step 2 is active or not
  stepTwoDisplay: Boolean;

  // This holds the new transaction token received
  transactionTokenAfterAuthenticateProfile: String;

  // This holds the authentication validity flag
  authenticationFailure: Boolean;

  // this flag checks whether security question call is completed or not
  secQuestionCallCompleted: Boolean;

  // this is an array of security question list
  secQuesList: Array<Object>;

  // this is the default drop down selection
  defaultSelectedCode: String;

  // This counts the total number of attempts to validate profile
  validateProfileCount; // @TODO - Will this value come from session or service

  // This holds the value of the enrolled user last name
  enrolledUserLastName: String = '';

  // This holds the value of the enrolled user last name
  enrolledUserRegistrationDate: String;

  // This holds the value of the enrolled user last name
  validateEmailTransactionToken: String;

  // This flag holds the value of whether the validateProfile service failed or not
  validateServiceSuccess: Boolean = true;

  /* This flag holds the type of error that validate profile service encounters.
  This is further passed to the generic error message component to show
  the specific error.*/
  errorType: String;

  // This flag holds the profile id value received from the url
  profileId: String;

  // This object holds the type of error that validate profile service has
  profileCompletionErrors: Object = {};

  // This object holds the generic text for club completion component
  profileCompletionGenericContent: Object = {};

  // This flag instructs whether we need to show the block error on top or not for first form
  enableFirstFormValidation: boolean;

  // This flag instructs whether we need to show the block error on top or not for second form
  enableSecondFormValidation: boolean;

  // This flag checks the password comparison status
  passwordsSame = true;

  /* This function creates and intializes the first angular profile form*/
  createProfileCompletionFirstForm() {
    this.profileCompletionFirstForm = this.fb.group({
      profileCompleteEmail: ['', [Validators.required,
                                  Validators.pattern(this.profileCompletionGenericContent['emailPattern'])]],
      profileCompleteZip: ['', [Validators.required,
                                Validators.pattern(this.profileCompletionGenericContent['zipPattern'])]]
    });
  }

  /* This function creates and intializes the second profile creation form */
  createProfileCompletionSecondForm() {
    this.profileCompletionSecondForm = this.fb.group({
      profileCompletePassword: ['', [Validators.required,
                                    Validators.pattern(this.profileCompletionGenericContent['passwordRegexPattern'])]],
      profileCompleteConfPassword: ['', Validators.required],
      profileCompleteSecQues: '',
      profileCompleteSecAns: ['', Validators.required]
    });
  }

  /* This is the second form custom validations */
  customValidationsForSecondForm() {
    const formControls = this.profileCompletionSecondForm.controls;
    const emailAddress = this.profileCompletionFirstForm.get('profileCompleteEmail').value;
    // Check if password is equal to the text password or email
    if (formControls.profileCompletePassword.value !== '' &&
      formControls.profileCompletePassword.value.toUpperCase() === 'PASSWORD') {
      formControls.profileCompletePassword.setErrors({'pattern': 'true'});
    }else if (formControls.profileCompletePassword.value === emailAddress ||
             formControls.profileCompletePassword.value === emailAddress.split('@')[0]){
      formControls.profileCompletePassword.setErrors({'pattern': 'true'});
    }
    // @TODO-Check what to do for pattern
    // End of password custom check

    // Check if confirm password and password are same
    if (formControls.profileCompleteConfPassword.value !== '' &&
        formControls.profileCompleteConfPassword.value !== formControls.profileCompletePassword.value) {
      formControls.profileCompleteConfPassword.setErrors({'pattern': 'true'});
    }
    // End of confirm password custom check

    // Check if security answer matches the password or email or security question
    const secAns  = formControls.profileCompleteSecAns.value;
    const secQuesObj = this.secQuesList.filter(function( obj ) {
      return obj['securityCode'] === formControls.profileCompleteSecQues.value;
    });
    // Return if empty
   if (secAns === secQuesObj[0]['securityDesc']) { // Check for security question
      formControls.profileCompleteSecAns.setErrors({'pattern': 'true'});
    }else if (secAns === formControls.profileCompletePassword.value) { // Check for password
      formControls.profileCompleteSecAns.setErrors({'pattern': 'true'});
     // Placed a check for checking full email and first part of email
    }else if (secAns === emailAddress ||
              secAns === emailAddress.split('@')[0]) { // Check for email
      formControls.profileCompleteSecAns.setErrors({'pattern': 'true'});
      formControls.profileCompleteSecAns.setErrors['errorState'] = true;
    }
  }


  /* This function handles the form submit with a service call to go to step 2 */
  onProfileCompleteFirstStep() {
    this.firstFormSubmitted = true;
    if (this.profileCompletionFirstForm.status.toUpperCase() === 'INVALID') {
      this.assignErrorClasses(this.profileCompletionFirstForm);
      // need to be commented while committing
/*       this.stepTwoDisplay = true;
      this.getSecurityQuestion(); */
      // this.formValidationComponent.placeFocus();
      this.enableFirstFormValidation = true;
    } else {
      this.enableFirstFormValidation = false;
      const authenticateProfileReqObj = {
        'request': {
                        'actionType': 'authenticateProfile',
                        'profileInfo': this.profileId,
                        'email': this.profileCompletionFirstForm.get('profileCompleteEmail').value,
                        'postalCode': this.profileCompletionFirstForm.get('profileCompleteZip').value,
                        'transactionToken': this.validateEmailTransactionToken
                    }
      };
      this._ajaxUtility.sendRequest('authenticateProfile', authenticateProfileReqObj, {})
      .subscribe(
        (data: HttpResponse<any>) => {
          if (data['response']['header']['statusCode'] === '0000') {
            this.transactionTokenAfterAuthenticateProfile = data['response']['details']['transactionToken'];
            this.stepTwoDisplay = true;
            // fire utag
            this._utag.view({
              'page_name':'carepass:pos profile activate 2'
            })
            this.authenticationFailure = false; // Hide authentical failure message
            // Call the security question service
            this.getSecurityQuestion();
          }else if (data['response']['header']['statusCode'] === '9290') { // Show authentication failure message
            this.authenticationFailure = true;
            // check if failure count is coming
            if (data['response']['details']) {
              this.validateProfileCount = data['response']['details']['remainingLockCount'];
            }
            }else if (data['response']['header']['statusCode'] === '9609') {
            // Three attempts reached. Show the account locked error message
            this.authenticationFailure = false; // Hide authentical failure message
            this.errorType = 'accountLocked';
            this.validateServiceSuccess = false;
          } else {
            this.validateServiceSuccess = false;
            this.errorType = 'genericSerice';
          }
        },
        (err) => {
          this.validateServiceSuccess = false;
          this.errorType = 'genericSerice';
        });
    }
  }

  /* This function finally makes the form submit and completes the profile creation */

  onProfileCompleteSecondStep() {
    this.secondFormSubmitted = true;
    this.enableSecondFormValidation = true;
    /* this.changePwdSecQuesValidationForm = {'pwdVisited': false, 'confPwdVisited': false, 'secAnsVisited': false};*/
    this.customValidationsForSecondForm();
    if (this.profileCompletionSecondForm.status.toUpperCase() === 'INVALID') {
      this.assignErrorClasses(this.profileCompletionSecondForm);
    }else {
      this.enableSecondFormValidation = false;
      const changePwdSecQuesAnsObj = {
        'request': {
          'actionType': 'changePasswordAndSecurityQuestion',
          'profileInfo':  this.profileId,
          'newPassword': this.profileCompletionSecondForm.get('profileCompletePassword').value,
          'confirmNewPassword': this.profileCompletionSecondForm.get('profileCompleteConfPassword').value,
          'securityQuesId': this.profileCompletionSecondForm.get('profileCompleteSecQues').value,
          'securityAnswer': this.profileCompletionSecondForm.get('profileCompleteSecAns').value,
          'transactionToken': this.validateEmailTransactionToken
        }
      };
      this._ajaxUtility.sendRequest('authenticateProfile', changePwdSecQuesAnsObj, {})
      .subscribe(
        (data: HttpResponse<any>) => {
          // if  successfully sec ques and answer as well as password set navigate
          // users to dashboard
          if (data['response']['details']['header']['statusCode'] === '0000') {
            this._utag.link({
              "link_name":"custom: carepass:pos profile activate success",
              "flow":"complete"
            })
            this.validateServiceSuccess = true;
            this.errorType = '';
            this._router.navigate(['/' + RouteConfigurations.clubDashboard]);
          }else {
            this.validateServiceSuccess = false;
            this.errorType = 'genericSerice';
          }
        },
        (err) => {
          this.validateServiceSuccess = false;
          this.errorType = 'genericSerice';
        });
    }
  }

  /* This method calles the security questions service and gets list of questions */

  getSecurityQuestion() {
    this._ajaxUtility.sendRequest('getSecurityQuestions', {}, {})
    .subscribe(
      (data: HttpResponse<any>) => {
          if (data['response']['header']['statusCode'] === '0000') {
            this.validateServiceSuccess = true;
            this.errorType = '';
            this.secQuestionCallCompleted = true;
            this.secQuesList = data['response'].details.questions;
            // Assign the default question code here
            this.defaultSelectedCode = this.profileCompletionGenericContent['defaultSecurityCode'];
            // Patch this value in the form so that it appears as the default option
              this.profileCompletionSecondForm.patchValue({
              profileCompleteSecQues: this.defaultSelectedCode
            });
          }else { // Shows generic service error
            this.validateServiceSuccess = false;
            this.errorType = 'genericSerice';
          }
        },
      // Shows generic service error
      (err) => {
        this.validateServiceSuccess = false;
        this.errorType = 'genericSerice';
      }
    );
  }

    /* This function will check form fields for errors and assign a class to them
       but only on submit and not on keypress */
    assignErrorClasses(formObj) {
      for (const controlObjKey in formObj.controls) {
        formObj['controls'][controlObjKey]['visited'] = false;
        if (formObj['controls'][controlObjKey]['errors'] !== null) {
        formObj['controls'][controlObjKey]['custErrors'] = {};
        formObj['controls'][controlObjKey]['errorState'] = true;
            if (formObj['controls'][controlObjKey]['errors']['required']) {
            formObj['controls'][controlObjKey]['custErrors'] = {'emptyError' : true};
            }else {
              if (formObj['controls'][controlObjKey]['errors']['pattern'] || formObj['controls'][controlObjKey]['errors']['email']) {
                formObj['controls'][controlObjKey]['custErrors'] = {'patternError' : true};
            }}
        }else {
          // this.emailZipValidationForm['errorState'] = true;
          formObj['controls'][controlObjKey]['errorState'] = false;
        }
      }
    }


  /* This function is called after DOM is loaded */

  ngOnInit() {

    // Get the constant error and content from the club constants service
    this.profileCompletionErrors = this.clubContants.getClubCompletionErrorMessages();
    this.profileCompletionGenericContent = this.clubContants.getClubCompletionContent();
    // initialize profile attemp count from constants
    this.validateProfileCount = this.profileCompletionGenericContent['noOfAttempts'];

    // Create the respective forms
    this.createProfileCompletionFirstForm();
    this.createProfileCompletionSecondForm();

    // This handles the data from the resolver after the validat profile service is called.
    const emailResolverData = this.route.snapshot.data.enrollmentDetails;
    if (emailResolverData.hasOwnProperty('response')) {
      if (emailResolverData.response.header.statusCode === '0000') {
        this._utag.view({
          'page_name': 'carepass:pos profile activate 1',
          'flow': 'start',
          'flowname': 'activate cvs carepass pos'
        })
        this.validateServiceSuccess = true;
        this.errorType = '';
        this.enrolledUserRegistrationDate = emailResolverData.response.details.registrationDate;
        this.enrolledUserLastName = emailResolverData.response.details.lastName;
        this.validateEmailTransactionToken = emailResolverData.response.details.transactionToken;
        this.profileId = window['location']['href'].split('profid1=')[1];
      }else if (emailResolverData.response.header.statusCode === '9289') { // if  email link expired or profile information not found
        this.validateServiceSuccess = false;
        this.errorType = 'validationLinkExpired';
      }
      // need to be uncommented before committing
      // This happens when account is locked
       // tslint:disable-next-line:one-line
      else if  (emailResolverData.response.header.statusCode === '9609'){
        this.errorType = 'accountLocked';
        this.validateServiceSuccess = false;
      }else {
        this.validateServiceSuccess = false;
        this.errorType = 'genericSerice';
      }
    }
    // if  validate profile failed.
     if (emailResolverData.hasOwnProperty('status')) {
      if (emailResolverData.status === 'Fail') {
        this.validateServiceSuccess = false;
        this.errorType = 'genericSerice';
      }
    }
  }

  ngAfterViewInit() {

  }
}
