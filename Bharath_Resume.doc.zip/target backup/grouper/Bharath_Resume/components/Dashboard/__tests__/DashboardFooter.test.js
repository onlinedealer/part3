import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../store/configureStore'
import DashboardFooter, { DashboardFooter as DashboardFooterComponent } from '../DashboardFooter'

describe('DashboardFooter component', () => {
  let store, wrapper, wrapperBlock
  store = configureStore
  let props = {
    classes: {},
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }
  it('renders', () => {
    const div = document.createElement('div')
    wrapper = mount(
      <Provider store={store}>
        <DashboardFooter />
      </Provider>, div)
    expect(wrapper).toHaveLength(1)
  })

  it('invoking openDrawer ', () => {
    wrapperBlock = shallow(
      <DashboardFooterComponent {...props} />)
    wrapperBlock.instance().openDrawer()
    expect(wrapperBlock.instance().state.drawerOpenStatus).toEqual(true)
  })

  it('invoking closeDrawer ', () => {
    wrapperBlock = shallow(
      <DashboardFooterComponent {...props} />)
    wrapperBlock.instance().closeDrawer()
    expect(wrapperBlock.instance().state.drawerOpenStatus).toEqual(false)
  })
})
