var widget = angular.module('app', ['ui.router', 'ui.bootstrap']);

(function() {
    'use strict';

    widget.config(function($stateProvider, $urlRouterProvider, uiRouters) {
        $urlRouterProvider.otherwise('/home');

        $stateProvider
            .state("home", {
                url: "/home",
                templateUrl: uiRouters.directivesHtmlPath + '/home.html',
                controller: 'homeCtrl'
            }).state("edit", {
                url: "/edit/{id}",
                params: {
                    obj: null
                },
                templateUrl: uiRouters.directivesHtmlPath + '/home.html',
                controller: 'homeCtrl'
            }).state("addOrEdit", {
                url: "/addOrEdit",
                templateUrl: uiRouters.directivesHtmlPath + '/addOrEdit.html',
                controller: 'addOrEditCtrl'
            });
    });
    widget.run(['$rootScope', myRunFn]);

    function myRunFn($rootScope) {
        localStorage.clear();
    }

})();