import { MeteringPointsFeatureComponent } from "./meteringpoints-feature.component";
import { MeteringpointsHeaderContainerComponent } from "./meteringpoints-header/meteringpoints-header-container.component";
import { MeteringpointsSearchContainerComponent } from "./meteringpoints-search/meteringpoints-search.component";
import { MeteringpointsResultsContainerComponent } from "./meteringpoints-results/meteringpoints-results-container.component";
import { MeteringPointSideviewContainerComponent } from "./meteringpoint-sideview/meteringpoint-sideview-container.component";
import { MeteringPointDetailsComponent } from "./meteringpoint-details/meteringpoint-details.component";
import { MeteringPointDevicesComponent } from "./meteringpoint-devices/meteringpoint-devices.component";
import { SetRelayUsageComponent } from "./meteringpoint-devices/set-relay-usage/set-relay-usage.component";
import { MeteringPointEventsComponent } from "./meteringpoint-events/meteringpoint-events.component";
import { MeteringpointPrepaymentComponent } from "./meteringpoint-prepayment/meteringpoint-prepayment.component";
import { MeteringPointMeteringsComponent } from "./meteringpoint-meterings/meteringpoint-meterings.component";
import { OnDemandReadingDialogComponent } from "./ondemandreading-dialog/ondemandreading-dialog.component";
import { SSWrapperComponent } from "./secondary-sideview/ss-wrapper/ss-wrapper.component";
import { SSMeteringPointStatesComponent } from "./secondary-sideview/ss-mpstates/ss-meteringpointstates.component";
import { MeteringPointEventsEventsComponent } from "./meteringpoint-events/events/meteringpoint-events-events.component";
import { MeteringPointEventsPowerQualityComponent } from "./meteringpoint-events/power-quality/meteringpoint-power-quality.component";
import { MeteringLineGraphComponent } from "./metering-line-graph/metering-line-graph.component";
import { SSCustomPropertyComponent } from "./secondary-sideview/ss-custom-property/ss-custom-property.component";
import { SSDeviceCustomPropertyComponent } from "./secondary-sideview/ss-custom-property/ss-device-custom-property.component";
import { SSMeteringToolbarSelectComponent } from "./secondary-sideview/ss-metering/ss-metering-toolbar-select.component";
import { SSMeteringDataTableComponent } from "./secondary-sideview/ss-metering/ss-metering-data-table.component";
import { SSMeteringDataChartComponent } from "./secondary-sideview/ss-metering/ss-metering-data-chart.component";
import { SSMeteringDataSummaryComponent } from "./secondary-sideview/ss-metering/ss-metering-data-summary.component";
import { SSMeteringToolbarComponent } from "./secondary-sideview/ss-metering/ss-metering-toolbar.component";
import { SSMeteringDataTimesSelectorComponent } from "./secondary-sideview/ss-metering/ss-metering-data-times-selector.component";
import { ProductComponentContainerComponent } from "./product-component-container/product-component-container.component";
import { MultiplyMeteringValuesComponent } from "./meteringpoint-meterings/multiply-metering-values/multiply-metering-values.component";
export const containers: any[] = [
    MeteringPointsFeatureComponent,
    MeteringpointsHeaderContainerComponent,
    MeteringpointsSearchContainerComponent,
    MeteringpointsResultsContainerComponent,
    MeteringPointSideviewContainerComponent,
    MeteringPointDetailsComponent,
    MeteringPointDevicesComponent,
    MeteringPointEventsComponent,
    MeteringpointPrepaymentComponent,
    MeteringPointMeteringsComponent,
    MeteringPointEventsEventsComponent,
    MeteringPointEventsPowerQualityComponent,
    OnDemandReadingDialogComponent,
    SSWrapperComponent,
    MeteringLineGraphComponent,
    SSCustomPropertyComponent,
    SSMeteringPointStatesComponent,
    SSDeviceCustomPropertyComponent,
    SSMeteringToolbarComponent,
    SSMeteringToolbarSelectComponent,
    SSMeteringDataTableComponent,
    SSMeteringDataChartComponent,
    SSMeteringDataSummaryComponent,
    SSMeteringDataTimesSelectorComponent,
    ProductComponentContainerComponent,
    SetRelayUsageComponent,
    MultiplyMeteringValuesComponent
];

export * from "./meteringpoints-feature.component";
export * from "./meteringpoints-header/meteringpoints-header-container.component";
export * from "./meteringpoints-results/meteringpoints-results-container.component";
export * from "./meteringpoint-sideview/meteringpoint-sideview-container.component";
export * from "./meteringpoint-details/meteringpoint-details.component";
export * from "./meteringpoint-devices/meteringpoint-devices.component";
export * from "./meteringpoint-devices/set-relay-usage/set-relay-usage.component";
export * from "./meteringpoint-events/meteringpoint-events.component";
export * from "./meteringpoint-prepayment/meteringpoint-prepayment.component";
export * from "./meteringpoint-meterings/meteringpoint-meterings.component";
export * from "./ondemandreading-dialog/ondemandreading-dialog.component";
export * from "./meteringpoint-events/events/meteringpoint-events-events.component";
export * from "./meteringpoint-events/power-quality/meteringpoint-power-quality.component";
export * from "./meteringpoints-search/meteringpoints-search.component";
export * from "./metering-line-graph/metering-line-graph.component";
export * from "./secondary-sideview/ss-mpstates/ss-meteringpointstates.component";
// export * from "./meteringpoint-meterings/multiply-metering-values/multiply-metering-values.component";
