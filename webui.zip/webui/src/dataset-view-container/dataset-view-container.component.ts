import { Component, HostBinding, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { MenuItem } from 'primeng/api';
import { ActivatedRoute } from '@angular/router';
import { SecondaryNavItemsService } from 'discovery-shared';

@Component({
  selector: 'discovery-dataset-view-container',
  templateUrl: './dataset-view-container.component.html'
})
export class DatasetViewContainerComponent implements OnInit {
  @HostBinding('class') hostClasses = ['d-block'];

  navItems: MenuItem[];
  activeItem: MenuItem;
  datasetName: any;

  constructor(
    private translocoService: TranslocoService,
    private navItemsService: SecondaryNavItemsService,
    private activatedRoute: ActivatedRoute
  ) {}

  ngOnInit(): void {
    this.navItems = this.navItemsService.getNavItems();
    this.activeItem = this.navItemsService.getActiveNav('do-data-catalogs');
    this.datasetName = this.activatedRoute.snapshot.params['name'];
  }
}
