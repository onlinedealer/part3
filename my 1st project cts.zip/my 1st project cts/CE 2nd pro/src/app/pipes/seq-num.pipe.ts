import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'seqNum'
})
export class SeqNumPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    return null;
  }

}
