export const statusField = 'status'
export const pageLimit = 50
export const gridColumFit = false
