import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { ISchemas } from 'core/entities/schema.model';
import { ColumnModel, DatasourceEntitySelectorModel, SchemaModel, TableModel } from 'discovery-core';
import { ConnectionModel, ConnectionService, SharedConstants } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/api';
import { ProfileService } from '../../profiling/profile.service';

@Component({
  selector: 'discovery-select-source',
  templateUrl: './select-source.component.html',
  styleUrls: ['./select-source.component.css'],
  providers: [ConfirmationService]
})
export class SelectSourceComponent implements OnInit {
  /**
   *
   */
  @Input() selectedConnectionId: string;
  @Input() connectionIdKeyFlag: boolean;
  @Input('isCatalog') multiSchemaFeatureFlag: boolean = false;
  @Output() selectedConnectionIdChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() selectListTableChange: EventEmitter<TableModel[]> = new EventEmitter<TableModel[]>();
  @Output() disableActionsChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  selectedConnection: ConnectionModel;
  fetchbtnTxt: string;

  /**
   *
   */
  connectionList: ConnectionModel[];
  showError: boolean = false;
  observerNoteMessage: boolean = false;

  /**
   * entity configuration model for schemas
   */
  schemaConfiguration: DatasourceEntitySelectorModel;

  /**
   * entity configuration model for tables
   */
  tableConfiguration: DatasourceEntitySelectorModel;

  /**
   * entity configuration model for columns
   */
  columnConfiguration: DatasourceEntitySelectorModel;

  /**
   * schema data to display
   */
  schemaData: SchemaModel[] = [];

  /**
   * table data to display
   */
  tableData: TableModel[] = [];

  /**
   * column data to display
   */
  columnData: ColumnModel[] = [];

  /**
   * data loading status for schemas
   */
  schemaLoading: boolean;
  checkSelectionMode = false;

  /**
   * Variant checks for beta
   */
  isVariantType: boolean;
  variantTableMap: Record<string, unknown> = {};
  /**
   * isShowColumns set true if columns are visible
   */
  isShowColumns = false;
  /**
   * disableEntityTables set true if column api being called
   */
  disableEntityTables = false;
  /**
   * data loading status for tables
   */
  tableLoading: boolean;

  /**
   * data loading status for columns
   */
  columnLoading: boolean;

  /**
   * currently selected schema
   */
  selectedSchema: SchemaModel;

  /**
   * currently selected table
   */
  selectedTable: TableModel;

  /**
   * currently checked tables
   */
  checkedTables: TableModel[] = [];

  checkedColumns: ColumnModel[] = [];
  sidebarVisible: boolean;
  connectionType: string;
  configureId: string;
  configureViewType: string;
  updateConnectionTimeout: any;
  isLoading = false;

  //end of glob var//
  private profileConfigureModel: any;
  /**
   *
   * @param profileService
   * @param connectionService
   * @param toastrService
   * @param translateService
   */
  constructor(
    private profileService: ProfileService,
    private connectionService: ConnectionService,
    private toastrService: ToastrService,
    private translocoService: TranslocoService,
    private confirmationService: ConfirmationService
  ) {
    this.connectionService.getConnectionList().subscribe((response) => {
      this.connectionList = response;
      this.updateSelectedConnection();
    });
  }

  selectedConnectionChanged() {
    if (this.selectedConnection && this.selectedConnection.id) {
      this.selectedConnectionIdChange.emit(this.selectedConnection.id);
    }
  }

  /**
   *
   */
  ngOnInit(): void {
    this.setFetchButtonText();
    this.initSchemaConfiguration();
    this.initTableConfiguration();
    this.initColumnConfiguration();

    if (this.selectedConnection) {
      this.loadSchema();
    }
  }

  /**
   * To set Fetch button Text
   * For DC connections `Fetch Schema` will be displayed
   * for other connections `Fetch Tables` will be displayed
   */
  setFetchButtonText() {
    if (this.multiSchemaFeatureFlag) {
      this.fetchbtnTxt = this.translocoService.translate('discoveryShared.selectSource.fetchSchemas');
    } else {
      this.fetchbtnTxt = this.translocoService.translate('discoveryShared.selectSource.fetchTables');
    }
  }

  /**
   * On Connection Change make sure everything on page selected or displayed
   * is reset to initial state of page load.
   */
  resetAllSelections() {
    this.showError = false;
    // Reset Schema and selection
    this.selectedSchema = null;
    this.schemaData = [];
    this.schemaConfiguration.data = [];

    // Reset Table and Selections
    this.checkedTables = [];
    this.tableData = [];
    this.selectedTable = null;
    this.tableConfiguration.data = [];

    // Reset Column and selections
    this.checkedColumns = [];
    this.columnData = [];
    this.columnConfiguration.data = [];
  }

  /**
   * Initialize Schema Configuration Object for Entity selector.
   */
  initSchemaConfiguration() {
    this.schemaConfiguration = {
      data: this.schemaData,
      filterPlaceholder: this.translocoService.translate('discoveryShared.selectSource.filterPlaceholder'),
      cardHeader: this.translocoService.translate('discoveryShared.selectSource.selectCardHeaderConnections'),
      headers: [
        {
          fieldName: 'name',
          displayName: this.translocoService.translate('discoveryShared.selectSource.schemaColumnConnections')
        },
        {
          fieldName: 'count',
          displayName: this.translocoService.translate('discoveryShared.selectSource.schemaColumnTablesSelected')
        }
      ],
      noDataMessage: this.translocoService.translate('discoveryShared.selectSource.noDataSchema'),
      filterFields: ['name', 'count'],
      loadingFlag: () => this.schemaLoading,
      showFilter: true,
      showCheckBox: false,
      rowSelect: (schema: SchemaModel) => this.onSchemaSelect(schema),
      rowHover: true,
      scrollHeight: '315px',
      noOfRows: 5,
      scrollable: true,
      virtualScroll: false,
      virtualRowHeight: 30,
      keyField: 'name',
      enableSelection: true
    };
  }

  /**
   * Initialize Table Configuration Object for Entity selector.
   */
  initTableConfiguration() {
    this.tableConfiguration = {
      data: this.tableData,
      filterPlaceholder: this.translocoService.translate('discoveryShared.selectSource.filterPlaceholder'),
      cardHeader: this.translocoService.translate('discoveryShared.selectSource.selectCardHeaderTables'),
      headers: [
        {
          fieldName: 'displayName',
          displayName: this.translocoService.translate('discoveryShared.selectSource.tablesColumnTables')
        },
        {
          fieldName: 'count',
          displayName: this.translocoService.translate('discoveryShared.selectSource.tablesColumnSelected')
        }
      ],
      noDataMessage: this.translocoService.translate('discoveryShared.selectSource.clickSchemaToViewTables'),
      filterFields: ['displayName', 'count'],
      loadingFlag: () => this.tableLoading,
      showFilter: true,
      rowSelect: (table: TableModel) => this.onSelectTable(table),
      showCheckBox: true,
      selectedData: this.checkedTables,
      rowCheck: (checkedRow: TableModel) => this.onTableCheckedUnchecked(checkedRow, true),
      rowUnChecked: (unCheckedRow: TableModel) => this.onTableCheckedUnchecked(unCheckedRow, false),
      rowHover: true,
      scrollHeight: '315px',
      noOfRows: 5,
      scrollable: true,
      virtualScroll: false,
      virtualRowHeight: 30,
      keyField: 'name'
    };
  }

  /**
   * Initialize Column Configuration Object for Entity selector.
   */
  initColumnConfiguration() {
    this.columnConfiguration = {
      data: this.columnData,
      filterPlaceholder: this.translocoService.translate('discoveryShared.selectSource.filterPlaceholder'),
      cardHeader: this.translocoService.translate('discoveryShared.selectSource.selectCardHeaderColumns'),
      headers: [
        {
          fieldName: 'name',
          displayName: this.translocoService.translate('discoveryShared.selectSource.columnTablesColumn')
        },
        {
          fieldName: 'columnDataType',
          displayName: this.translocoService.translate('discoveryShared.selectSource.columnTablesDatatype')
        }
      ],
      noDataMessage: this.translocoService.translate('discoveryShared.selectSource.noDataColumns'),
      filterFields: ['name'],
      loadingFlag: () => this.columnLoading,
      selectedData: this.checkedColumns,
      rowCheck: (checkedRow) => this.onColumnsCheckedUnchecked(checkedRow, true),
      rowUnChecked: (unCheckedRow) => this.onColumnsCheckedUnchecked(unCheckedRow, false),
      rowSelect: (column: ColumnModel) => null,
      selectAllRows: (status: any) => this.onTableCheckedUnchecked(this.selectedTable, status.checked),
      showFilter: true,
      showSelectAllCheckBox: true,
      showCheckBox: true,
      rowHover: true,
      scrollHeight: '315px',
      noOfRows: 5,
      scrollable: true,
      virtualScroll: true,
      virtualRowHeight: 30,
      keyField: 'name',
      enableSelection: false
    };
  }

  /**
   * Load column data for the specified table
   * @param selectedTable table for which columns are to be loaded
   */
  loadColumnData(selectedTable: TableModel, columns?: ColumnModel[]) {
    this.disableEntityTables = true;
    this.disableActionsChange.emit(true);
    if (!this.selectedConnection) {
      this.getSelectedConnectionDetails();
    }
    const connectionId = this.selectedConnection.id;
    this.connectionService
      .getColumnList(
        this.selectedConnection.resourceConnectionType,
        this.selectedConnection.name,
        selectedTable,
        this.multiSchemaFeatureFlag,
        connectionId
      )
      .subscribe(
        (response: ColumnModel[]) => {
          const currentColumnData: ColumnModel[] = [];
          for (const [index, elem] of response.entries()) {
            currentColumnData.push(this.createColumn(elem, index, selectedTable.schema));
          }

          selectedTable.columns.push(...currentColumnData);
          const tableIndex = this.getTableDataIndex(selectedTable);
          this.tableData[tableIndex].columns = [];
          this.tableData[tableIndex].columns.push(...currentColumnData);

          if (columns?.length) {
            this.updateSelectedColumns(this.tableData[tableIndex], columns);
          }

          currentColumnData.every((elem) => elem.rowDisabled === true) &&
            this.disableTableRow(selectedTable, tableIndex);
          this.columnLoading = true;
          this.columnData.length = 0;
          this.genertingColumnData(currentColumnData);
          const checkedCols = this.tableData[tableIndex].columns.filter((column) => column.selected === true);
          this.updateCheckedCols(checkedCols, tableIndex);
          this.checkSelectionMode = false;
          this.disableEntityTables = false;
          this.disableActionsChange.emit(false);
          this.selectedNodeChanged();
          setTimeout(() => {
            this.columnLoading = false;
          }, 0);
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.columnLoading = false;
          this.checkSelectionMode = false;
          this.isShowColumns = false;
          this.disableEntityTables = false;
          this.disableActionsChange.emit(false);
          this.toastrService.error(
            this.translocoService.translate('discoveryShared.selectSource.fetchColumnsFailed', {
              tableName: selectedTable.name,
              serverMessage:
                httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                  ? httpErrorResponse.error.message
                  : ''
            })
          );
          this.removeCheckedTables(selectedTable);
          const tableIndex = this.getTableDataIndex(selectedTable);
          if (tableIndex && tableIndex > -1) {
            this.tableData[tableIndex].selected = false;
          }
          this.updateCheckedTable(this.checkedTables);
        }
      );
  }

  /**
   *
   * @param schema
   * set Schema Configuration
   * Select Schema if page is opened in edit flow
   */
  setSchemaConfiguration(schema) {
    let allschemas = [];
    if (this.multiSchemaFeatureFlag) {
      schema.forEach((s) => {
        allschemas.push(
          new SchemaModel({
            name: s.value,
            count: 0,
            selected: false,
            connectionId: this.selectedConnectionId,
            children: []
          })
        );
      });
      this.schemaData = allschemas;

      // Edit Observer/Profile
      if (this.profileConfigureModel?.tables?.length) {
        const selectedSchema = this.profileConfigureModel?.tables[0].schema;
        const selectedScehma = this.schemaData.filter((s) => s.name === selectedSchema);
        if (selectedScehma?.length) {
          this.onSchemaSelect(selectedScehma[0]);
        }
      }
    } else {
      /**
       * In case of table instead of schema table data will be passed and we have to create schame name from it
       */
      this.selectedSchema = new SchemaModel({
        name: schema[0].schema,
        count: this.getCounts(0, schema.length),
        selected: false,
        connectionId: this.selectedConnectionId,
        children: []
      });

      // In this case schema is Table: old implementation
      this.schemaData.push(this.selectedSchema);
    }
    this.schemaConfiguration.data = this.schemaData;
  }

  /**
   * Set Schema and table
   * set Schema for old implementation based on feature flag to be false
   *
   */
  setDataSnapshot(data) {
    if (!this.multiSchemaFeatureFlag) {
      this.emptyConfigs();
      this.setSchemaConfiguration(data);
    }
    this.schemaLoading = false;
    this.setTableData(data);
    const schemaIndex = this.getSchemaDataIndex(this.selectedSchema);
    this.selectedSchema.count = this.getCounts(this.checkedTables.length, this.tableData.length);
    this.schemaData[schemaIndex].children = this.tableData;
    this.columnLoading = false;
    this.tableLoading = false;
  }

  setTableData(tables?: TableModel[]) {
    let tableData = [];
    for (const [index, table] of tables.entries()) {
      table.displayName = `${table.name} (${table.type})`;
      const { name, displayName, schema, type } = table;
      tableData.push(
        new TableModel({
          name,
          displayName,
          schema,
          type,
          count: 0,
          selected: false,
          uniqueKey: `${tables[0].schema}-${index}-table`,
          columns: [],
          tooltip: ''
        })
      );
    }

    this.tableConfiguration.data = this.tableData = tableData;
  }

  /**
   *
   * Callback function on if schema is selected
   * If Table for the schema is avalable then load them from memory or make API call to fetch the list of tables
   * If tables already exist for schema then assign them to tableData
   */
  onSchemaSelect(schema: SchemaModel) {
    if (!this.selectedSchema || schema.name !== this.selectedSchema.name) {
      this.selectedSchema = schema;
      if (!schema.children?.length) {
        this.loadTables();
      } else {
        this.resetTablesAndColumns();
        const schemaIndex = this.getSchemaDataIndex(schema);
        const checkedTables = this.schemaData[schemaIndex].children.filter((table) => table.selected === true);
        this.tableData = this.schemaData[schemaIndex].children;
        this.tableConfiguration.data = this.tableData;
        this.updateCheckedTable(checkedTables);
        if (this.tableData?.length) {
          // When Switching to different schema, if tables and columns are available, Always select the first table
          this.onSelectTable(this.tableData[0]);
        }
      }
    }
  }

  /**
   * load the column data for the currently selected table
   * @param tableModel model of selected table
   */
  onSelectTable(tableModel: TableModel) {
    this.columnData.length = 0;
    this.selectedTable = tableModel;
    this.columnConfiguration.noDataMessage = this.translocoService.translate(
      'discoveryShared.selectSource.noMatchesFound'
    );
    if (!this.selectedTable.columns || this.selectedTable.columns.length === 0) {
      this.columnLoading = true;
      this.loadColumnData(this.selectedTable);
    } else {
      this.columnLoading = true;
      this.checkSelectionMode = false;
      const tableIndex = this.getTableDataIndex(tableModel);
      const checkedCols = this.tableData[tableIndex].columns.filter((column) => column.selected === true);
      this.updateCheckedCols(checkedCols, tableIndex);
      this.columnData.push(...this.selectedTable.columns);
      this.columnConfiguration.data = this.columnData;
      setTimeout(() => {
        this.columnLoading = false;
      }, 0);
    }
    this.selectedNodeChanged();
  }

  /**
   *
   * @param checkedTable
   * @param checked
   * Callback function when table is checked or unchecked
   * Based on feature flag update table section values
   * If flag is true and there is no other selected Schema/table/Column when user switched to another Schema
   */
  async onTableCheckedUnchecked(checkedTable: TableModel, checked: boolean) {
    const previousSelectedTable: SchemaModel[] = this.checkIfTableSelected() || [];
    // Need confirmation if schema is changed and table is checked
    if (this.multiSchemaFeatureFlag && previousSelectedTable.length) {
      if (previousSelectedTable[0].children[0].schema !== checkedTable.schema) {
        try {
          await this.onConfirmSchemaChange();
          this.unCheckPreviousSelectedTableAndColumn();
          this.tableSelectionChanged(checkedTable, checked);
        } catch (e) {
          // Rollback selected Table and column event by unchecking and also reset selected Table count
          this.tableConfiguration.selectedData = [];
          this.columnConfiguration.selectedData = [];
          this.tableSelectionChanged(checkedTable, false);
        }
      } else {
        this.tableSelectionChanged(checkedTable, checked);
      }
    } else {
      this.tableSelectionChanged(checkedTable, checked);
    }
  }

  /**
   * update selection data when the user checked a table
   */
  tableSelectionChanged(checkedTable, checked: boolean) {
    this.checkSelectionMode = false;
    if (checked) {
      this.checkSelectionMode = true;
      if (!this.checkedTables.some((elem) => elem.uniqueKey === checkedTable.uniqueKey)) {
        this.checkedTables.push(checkedTable);
      }
    } else {
      this.removeCheckedTables(checkedTable);
    }

    const tableIndex = this.getTableDataIndex(checkedTable);

    this.tableData[tableIndex].selected = checked;
    for (const column of this.tableData[tableIndex].columns) {
      column.selected = column.rowDisabled ? false : checked;
    }

    this.onSelectTable(checkedTable);
    this.updateCheckedTable(this.checkedTables);
    this.selectedNodeChanged();
  }

  /**
   *
   * @returns schema of any table or columns selected
   */
  checkIfTableSelected() {
    return this.schemaData
      .map((schema) => {
        return { ...schema, children: schema.children.filter((table) => table.selected) };
      })
      .filter((schema) => schema.children.length);
  }

  /**
   * UnCheck all Tables and Columns and reset the selected count
   */
  unCheckPreviousSelectedTableAndColumn() {
    this.schemaData.forEach((schema) => {
      schema.children.forEach((table) => {
        table.selected = false;
        table.columns.forEach((column) => (column.selected = false));
        table.count = table.columns.length ? this.getCounts(0, table.columns.length) : 0;
      });
      schema.count = schema.children.length ? this.getCounts(0, schema.children.length) : 0;
    });
  }

  async onColumnsCheckedUnchecked(checkedColumn, checked: boolean) {
    const previousSelectedTable: SchemaModel[] = this.checkIfTableSelected() || [];
    if (this.multiSchemaFeatureFlag && previousSelectedTable.length) {
      if (previousSelectedTable[0].children[0].columns[0].schema !== checkedColumn.schema) {
        try {
          await this.onConfirmSchemaChange();
          this.unCheckPreviousSelectedTableAndColumn();
          this.columnSelectionChanged(checkedColumn, checked);
        } catch (e) {
          // Rollback selected Table and column event by unchecking and also reset selected Table count
          this.columnConfiguration.selectedData = [];
          this.columnSelectionChanged(checkedColumn, false);
        }
      } else {
        this.columnSelectionChanged(checkedColumn, checked);
      }
    } else {
      this.columnSelectionChanged(checkedColumn, checked);
    }
  }

  /**
   * update selection data when the user checked a column table
   */
  columnSelectionChanged(checkedColumn, checked: boolean) {
    if (checked) {
      this.checkedColumns.push(checkedColumn);
    } else {
      for (let index = 0; index < this.checkedColumns.length; index++) {
        if (this.checkedColumns[index] === checkedColumn) {
          this.checkedColumns.splice(index, 1);
        }
      }
    }

    const tableIndex = this.getTableDataIndex(this.selectedTable);

    this.tableData[tableIndex].selected = this.checkedColumns.length ? true : false;

    const checkedTable = this.tableData.filter((table) => table.selected === true);
    this.updateCheckedTable(checkedTable);
    const columnIndex = this.tableData[tableIndex].columns.findIndex(
      (elem) => checkedColumn.uniqueKey === elem.uniqueKey
    );
    this.tableData[tableIndex].columns[columnIndex].selected = this.tableData[tableIndex].columns[columnIndex].observed
      ? false
      : checked;
    this.tableData[tableIndex].count = this.getCounts(
      this.checkedColumns.length,
      this.tableData[tableIndex].columns.length
    );

    const schemaIndex = this.getSchemaDataIndex(this.selectedSchema);
    this.schemaData[schemaIndex].children = this.tableData;

    this.selectedNodeChanged();
  }

  loadSchema() {
    this.resetAllSelections();
    this.isLoading = true;
    this.schemaLoading = true;
    if (this.multiSchemaFeatureFlag) {
      this.showError = false;
      this.schemaLoading = true;
      this.disableActionsChange.emit(true);
      /* Note: Due to prime ng issue of resetting ngModel when updating Options list, 
      we will loose this value so assigning it to variable to reassin it after API response */
      let connection = this.selectedConnection;
      this.connectionService.getGovernSchemaByConnectionId(this.selectedConnection.id).subscribe({
        next: (schemas: ISchemas[]) => {
          this.selectedConnection = connection;
          this.isLoading = false;
          this.schemaLoading = false;
          this.disableActionsChange.emit(false);
          this.setSchemaConfiguration(schemas);
          this.observerNoteMessage = true;
        },
        error: (httpErrorResponse: HttpErrorResponse) => {
          this.isLoading = false;
          this.tableLoading = false;
          this.schemaLoading = false;
          this.disableActionsChange.emit(false);
          console.log(httpErrorResponse);
        }
      });
    } else {
      this.loadTables();
    }
  }

  resetTablesAndColumns() {
    this.checkedTables = [];
    this.columnData.length = 0;
    this.checkedColumns = [];
    this.selectedTable = null;
    this.isShowColumns = false;
  }

  /**
   * Load tables after schema is selected for Data catalog connections
   * or if old imlementation of non Data catalog conection then fetch the
   * tables and create schema from from first tables itself
   */
  loadTables() {
    this.resetTablesAndColumns();
    this.showError = false;
    this.tableLoading = true;
    this.columnLoading = true;

    this.disableActionsChange.emit(true);
    const connectionId = this.selectedSchema?.connectionId || null;
    const schemaName = this.selectedSchema?.name || null;
    this.connectionService
      .getTableList(
        this.selectedConnection.resourceConnectionType,
        this.selectedConnection.name,
        this.multiSchemaFeatureFlag,
        connectionId,
        schemaName
      )
      .subscribe(
        (response) => {
          this.isLoading = false;
          this.disableActionsChange.emit(false);
          if (response && response.length) {
            this.setDataSnapshot(response);
          }
          if (this.profileConfigureModel?.tables) {
            this.updateSelectedTables(this.profileConfigureModel.tables);
          }
          this.observerNoteMessage = true;
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.isLoading = false;
          this.tableLoading = false;
          this.columnLoading = false;
          this.schemaLoading = false;
          this.disableActionsChange.emit(false);
          this.toastrService.error(
            this.translocoService.translate('discoveryShared.selectSource.fetchTablesFailed', {
              serverMessage:
                httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                  ? httpErrorResponse.error.message
                  : ''
            })
          );
        }
      );
  }
  /**
   * validate if any required information is missing
   */
  validate(): Set<string> {
    this.showError = false;
    const errors: Set<string> = new Set<string>();

    if (!this.selectedConnectionId) {
      this.showError = true;
      errors.add('discoveryShared.selectSource.invalidConnection');
    } else if (!this.validateColumnSelection()) {
      this.showError = true;
      errors.add('discoveryShared.selectSource.invalidColumn');
    }
    if (this.isVariantType && Object.values(this.variantTableMap).length) {
      let msg = '';
      if (!Object.values(this.variantTableMap).includes(true)) {
        //Not used for display in UI but used for internal code error
        errors.add('Unsupported');

        msg = 'discoveryProfiling.listing.unsupportedColumnMessageOnlyVariant';
      } else {
        msg = 'discoveryProfiling.listing.unsupportedColumnMessageMixedVariant';
      }
      this.showVariantInfo(msg);
    }

    return errors;
  }
  /**
   * validate if any table and column not selected
   */
  validateColumnSelection(): boolean {
    const totalSelectedColumns = this.tableData
      ? this.tableData.reduce((total, table) => total + table.columns.filter((child) => child.selected).length, 0)
      : 0;
    return totalSelectedColumns > 0;
  }

  loadProfileSettings(profileConfigureModel) {
    this.profileConfigureModel = profileConfigureModel;
    this.updateSelectedConnection();
  }
  /**
   * Show info modal for VARIANT data type
   */
  showVariantInfo(msg: string) {
    this.confirmationService.confirm({
      message: this.translocoService.translate(msg),
      header: this.translocoService.translate('discoveryProfiling.listing.unsupportedColumnTitle'),
      icon: 'pi pi-info-circle',
      accept: () => {
        // this is intentional
      }
    });
  }
  /**
   * update selected table on EDIT mode
   */
  updateSelectedTables(tables: TableModel[]) {
    if (!!tables) {
      this.checkedTables = [];
      for (const table of tables) {
        for (const node of this.tableData) {
          if (node.name === table.name) {
            node.selected = true;
            node.count = table.columns.length;
            this.selectedTable = node;
            this.checkedTables.push(node);
            this.isShowColumns = true;
            this.loadColumnData(node, table.columns);
          }
        }
      }

      this.tableData.sort((a, b) => Number(b.selected) - Number(a.selected));
      this.tableConfiguration.selectedData = this.checkedTables;
      this.selectedSchema.count = this.getCounts(this.checkedTables.length, this.tableData.length);
    }
  }

  createConnection(connectionType?: string) {
    if (connectionType) {
      this.connectionType = connectionType;
    }
    this.showConnectionConfigureSidebar(SharedConstants.connectionConfigureModes.ADD);
  }

  updateConnectionDropdown(connectionId: string) {
    if (connectionId) {
      if (this.updateConnectionTimeout) {
        clearTimeout(this.updateConnectionTimeout);
      }
      this.connectionService.getConnectionList().subscribe((response) => {
        this.connectionList = response;
        this.updateConnectionTimeout = setTimeout(() => {
          this.selectedConnection = this.connectionList.find((connection) => connection.id === connectionId);
          this.selectedConnectionChanged();
        });
      });
    }
  }

  onConfirmSchemaChange() {
    return new Promise((resolve, reject) => {
      return this.confirmationService.confirm({
        message: this.translocoService.translate('discoveryShared.selectSource.differentSchemaSelection'),
        header: this.translocoService.translate('discoveryShared.selectSource.confirmation'),
        icon: 'pi pi-info-circle',
        accept: () => {
          return resolve('accept');
        },
        reject: () => {
          return reject('reject');
        },
        key: 'yescancel'
      });
    });
  }

  /**
   * @private Clear previously loaded config data for old Implemenation of discovery user
   */
  private emptyConfigs() {
    this.schemaData.length = 0;
    this.tableData.length = 0;
    this.tableLoading = true;
    this.columnLoading = true;
    this.checkedTables = [];
    if (this.tableConfiguration) {
      this.tableConfiguration.selectedData = this.checkedTables;
    }
    this.columnData.length = 0;
    this.checkedColumns = [];
    this.selectedTable = null;
    this.isShowColumns = false;
    setTimeout(() => {
      this.tableLoading = false;
      this.columnLoading = false;
    }, 0);
  }
  /**
   * update model on every event of table/column change
   */
  private selectedNodeChanged() {
    this.isVariantType = false;
    this.variantTableMap = {};
    const profileListTable: TableModel[] = [];
    let profileListColumn: ColumnModel[] = [];
    for (const node of this.tableData) {
      if (node.selected) {
        const tableModel: TableModel = new TableModel();
        tableModel.name = node.name;
        tableModel.schema = node.schema;
        tableModel.type = node.type;
        delete tableModel.selected;
        profileListColumn = [];
        for (const col of node.columns) {
          if (col.selected) {
            if (SharedConstants.UNSUPPORTED_DATA_TYPE.includes(col.type?.toUpperCase())) {
              this.isVariantType = true;
            } else {
              const colModel: ColumnModel = new ColumnModel();
              colModel.name = col.name;
              colModel.type = col.type;
              delete colModel.selected;
              profileListColumn.push(colModel);
            }
          }
        }
        tableModel.columns = profileListColumn;
        if (profileListColumn.length) {
          this.variantTableMap[node.name] = true;
          profileListTable.push(tableModel);
        } else {
          this.variantTableMap[node.name] = false;
        }
      }
    }
    this.selectListTableChange.emit(profileListTable);
  }

  private getSelectedConnectionDetails() {
    const connectionId = this.connectionIdKeyFlag
      ? this.profileConfigureModel.connectionId
      : this.profileConfigureModel.connection.id;
    this.selectedConnection = this.connectionList.find((connection) => connection.id === connectionId);
  }
  /**
   * It triggers when connection is changed
   */
  private updateSelectedConnection() {
    // EDIT OBSERVER CASE
    if (!!this.profileConfigureModel && !!this.connectionList && !this.selectedConnection) {
      this.getSelectedConnectionDetails();
      this.selectedConnectionId = this.selectedConnection.id;
      this.loadSchema();
    }
  }

  /**
   * update selected column on EDIT mode
   */
  private updateSelectedColumns(treeValueModel: TableModel, selectedColumns: ColumnModel[]) {
    if (!!selectedColumns) {
      const tableIndex = this.getTableDataIndex(treeValueModel);
      let count = 0;
      for (const column of selectedColumns) {
        for (const selectedNode of this.tableData[tableIndex].columns) {
          if (selectedNode.name === column.name) {
            selectedNode.selected = true;
            /* START-Below lines are used to enable already observed assets in Edit*/
            if (this.connectionIdKeyFlag) {
              selectedNode.observed = false;
              selectedNode.rowDisabled = false;
              selectedNode.checkboxDisabled = false;
              selectedNode.tooltip = '';
            }
            /* END */
            count++;
          }
        }
      }
      this.tableData[tableIndex].columns.sort((a, b) => Number(b.selected) - Number(a.selected));
      this.tableData[tableIndex].count = this.getCounts(count, this.tableData[tableIndex].columns.length);
    }
  }

  /**
   * helper fn to get index in Schema list
   */
  private getSchemaDataIndex = (schema: SchemaModel) => this.schemaData.findIndex((elem) => elem.name === schema.name);
  /**
   * helper fn to get index in tableData list
   */
  private getTableDataIndex = (table: TableModel) =>
    this.tableData.findIndex((elem) => table.uniqueKey === elem.uniqueKey);
  /**
   * update the checked table and re-render the table(2nd table)
   */
  private updateCheckedTable = (checkedTables: TableModel[]) => {
    if (this.selectedSchema) {
      this.selectedSchema.count = this.getCounts(checkedTables.length, this.tableData.length);
    }
    this.checkedTables = [];
    this.checkedTables.push(...checkedTables);
    this.tableConfiguration.selectedData = this.checkedTables;
  };
  /**
   * update the checked columns and re-render the colums(3rd table)
   */
  private updateCheckedCols = (checkedColumns: ColumnModel[], tableIndex: number) => {
    this.checkedColumns = [];
    this.checkedColumns.push(...checkedColumns);
    this.tableData[tableIndex].count = this.getCounts(
      this.checkedColumns.length,
      this.tableData[tableIndex].columns.length
    );
    this.columnConfiguration.selectedData = this.checkedColumns;
    this.columnConfiguration.showSelectAllCheckBox = !this.tableData[tableIndex].columns.some(
      (column) => column.rowDisabled === true
    );
  };
  /**
   * remove the item from checkedTables list to update the unselected node
   */
  private removeCheckedTables = (currentTable: TableModel) => {
    for (let index = 0; index < this.checkedTables.length; index++) {
      if (this.checkedTables[index] === currentTable) {
        this.checkedTables.splice(index, 1);
      }
    }
  };

  /**
   * @private to get the selected/totalCounts for tables
   */
  private getCounts = (selected: number, totalCount: number) => `${selected}/${totalCount}`;

  private showConnectionConfigureSidebar(viewType: string, id?) {
    this.sidebarVisible = true;
    if (id) {
      this.configureId = id;
    }
    this.configureViewType = viewType;
  }

  /**
   * @private to make the table checkbox disable when all columns are disabled
   */
  private disableTableRow(selectedTable: TableModel, tableIndex: number) {
    this.tableData[tableIndex].checkboxDisabled = true;
    this.tableData[tableIndex].selected = false;
    this.tableData[tableIndex].tooltip = this.translocoService.translate('discoveryShared.selectSource.tableObserved');
    this.removeCheckedTables(selectedTable);
    this.updateCheckedTable(this.checkedTables);
  }
  /**
   * @private to create the Column based on checks
   */
  private createColumn(elem, index, schema: string) {
    elem.columnDataType =
      elem.type.toUpperCase() === SharedConstants.DATA_TYPE.VARIANT ? `${elem.type} (Unsupported)` : elem.type;
    const { name, columnDataType, type, observed, observedIn } = elem;
    const columnRowDisabled = this.connectionIdKeyFlag ? observed : false;
    return new ColumnModel({
      name,
      columnDataType,
      type,
      selected: columnRowDisabled ? false : this.checkSelectionMode,
      uniqueKey: `column-${index}-${this.selectedTable.uniqueKey}`,
      schema: schema,
      rowDisabled: columnRowDisabled,
      checkboxDisabled: columnRowDisabled,
      tooltip: columnRowDisabled
        ? this.translocoService.translate('discoveryShared.selectSource.columnObserved', {
            observerName: observedIn
          })
        : ''
    });
  }

  /**
   * @private to create the column data to display on Column Table
   */
  private genertingColumnData(currentColumnData) {
    if (this.isShowColumns) {
      this.columnData.push(...currentColumnData.sort((a, b) => Number(b.selected) - Number(a.selected)));
    } else {
      this.columnData.push(...currentColumnData);
    }
    this.columnConfiguration.data = this.columnData;
  }
}
