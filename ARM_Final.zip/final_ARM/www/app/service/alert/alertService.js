(function() {
	'use strict';

	angular.module('arm').factory('alertService', ['serviceApi', '$filter', 'SERVICE_TYPE', 'localStorageService', 'sqliteService', 'utility','GENERAL_CONFIG','$rootScope', 'noteService', alertService]);

	function alertService(serviceApi, $filter, SERVICE_TYPE, localStorageService, sqliteService, utility, GENERAL_CONFIG,$rootScope,noteService) {
		var serArr = {};

      serArr.alertMod = function() {
      return {
        uiObject : {
          AlertID : null,
          AlertCategoryID: null,
          ModuleID: null,
          EntityID: null,
          Description: '',
          UserID: null,
          AlertDate: '',
          IsRead: false,
          ReadDateTime: '',
          IsDeleted: false,
          CreatedBy: '',
          CreatedOn: '',
          ServerDateTime: ''
        }
      }
    };

    function CheckNull(val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return "NULL";
            }
            return val;
    }

    serArr.prepareAlertsInsertQuery = function(objAlert)
    {

      var queryVal = '';
      for (var i = 0; i < objAlert.length; i++) {
          if(i!=0)
          queryVal += ',';
          queryVal += "(" + objAlert[i].AlertID + "," + objAlert[i].AlertCategoryID + "," + objAlert[i].ModuleID + "," + objAlert[i].EntityID + ",'" + objAlert[i].Description + "',"
            + objAlert[i].UserID + ",'" + objAlert[i].AlertDate + "','" + objAlert[i].IsRead + "','" + objAlert[i].ReadDateTime + "','" + objAlert[i].IsDeleted + "','" + objAlert[i].CreatedBy + "','" + objAlert[i].CreatedOn + "','" + objAlert[i].ServerDateTime + "'," + $rootScope.loggedInUserID + ")";
      }

      var alertsConcatenatedQuery = "INSERT INTO Alerts (AlertID, AlertCategoryID, ModuleID, EntityID, Description, UserID, AlertDate, IsRead, ReadDateTime, IsDeleted, CreatedBy, CreatedOn, ServerDateTime, LoggedInUserID) VALUES" + queryVal;

      return  alertsConcatenatedQuery;
    };

		return serArr;
	}

})();
