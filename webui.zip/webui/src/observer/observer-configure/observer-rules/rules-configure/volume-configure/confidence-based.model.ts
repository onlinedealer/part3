import { WarningAlertModel } from '../warning-alert.model';

export class ConfidenceBasedModel {
  warningAlerts: WarningAlertModel;
  constructor() {
    this.warningAlerts = new WarningAlertModel();
  }
}
