import { DOCUMENT } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { Agent } from '../../agents/shared/agent';
import { AgentsApiService } from '../../agents/shared/agents-api.service';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { ProgressIndicatorStateService } from '../../shared/components/progress-indicator/progress-indicator-state.service';
import { AgentsHomeComponent } from './agents-home.component';

describe('AgentsHomeComponent', () => {
  let component: AgentsHomeComponent;
  let fixture: ComponentFixture<AgentsHomeComponent>;
  let agentsService: AgentsApiService;

  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['initiateProgressSteps', 'setActiveStepByRouterLink', 'setIsValid']
  );

  const mockDocument = { location: { href: 'http://127.0.0.1/data-integration/test' } };

  beforeEach(async () => {
    TestBed.overrideComponent(AgentsHomeComponent, {
      set: {
        providers: [
          { provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService },
          { provide: DOCUMENT, useValue: mockDocument }
        ]
      }
    });

    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [AgentsHomeComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(AgentsHomeComponent);
    agentsService = TestBed.inject(AgentsApiService);
    component = fixture.componentInstance;
    spyOn(agentsService, 'getAll').and.returnValue(of([]));
    jasmine.clock().install();
    fixture.detectChanges();
  });

  afterEach(() => {
    jasmine.clock().uninstall();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get agents list after 2 seconds', () => {
    component.ngOnInit();
    jasmine.clock().tick(2500);
    expect(agentsService.getAll).toHaveBeenCalled();
  });

  it('should get agents list after 2 seconds and set step to valid if we have agents', () => {
    spyOn(agentsService, 'getAll').and.returnValue(of([{} as Agent]));
    component.ngOnInit();
    jasmine.clock().tick(2500);
    expect(agentsService.getAll).toHaveBeenCalled();
    expect(component.isAgentRegistered).toBe(true);
  });

  it('should get agents list after 2 seconds if there is an error', () => {
    spyOn(agentsService, 'getAll').and.returnValue(throwError({}));
    component.ngOnInit();
    jasmine.clock().tick(2500);
    expect(agentsService.getAll).toHaveBeenCalled();
  });
});
