import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';
import { CouponHelperService } from '../../services/coupon-helper.service';

@Component({
  selector: 'app-carepass-percent-off',
  templateUrl: './carepass-percent-off.component.html',
  styleUrls: ['./carepass-percent-off.component.scss']
})
export class CarepassPercentOffComponent implements OnInit {
  @Input() data: any;

  imagesPaths:Object = ImagePaths;

  constructor(public utilityService:UtilityService, public couponHelperService: CouponHelperService) { }

  ngOnInit() {
  }

}
