import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl, ReactiveFormsModule } from '@angular/forms';
import { AjaxUtilityService } from '../shared/utility/ajax-utility.service';
import { HttpResponse } from '@angular/common/http';
import { Router } from '@angular/router';
import { ClubConstantsService, RouteConfigurations } from '../shared/utility/club-constants.service';
import { FormValidationComponent } from '../shared/components/form-validation/form-validation.component';
import { UtagService } from 'utag-module';
import { ClubGenericErrorComponent } from '../shared/components/club-generic-error/club-generic-error.component';
import { CookieUtilityService } from '../shared/utility/cookie-utility.service';
import { Title, Meta } from '@angular/platform-browser';

@Component({
  selector: 'app-carepass-lookup',
  templateUrl: './carepass-lookup.component.html',
  styleUrls: ['./carepass-lookup.component.scss']
})
export class CarepassLookupComponent implements OnInit {

  @ViewChild('formValidationErrorCont') errorBlock: ElementRef;
  @ViewChild('zipNotFoundScreenCont') carepassComingSoon: ElementRef;

  constructor(private fb: FormBuilder,
    private _ajaxUtility: AjaxUtilityService,
    private clubContants: ClubConstantsService,
    private _utag: UtagService,
    private _route: Router,
    private _cookieService: CookieUtilityService,
    private _title: Title,
    private _meta: Meta
  ) {
    _title.setTitle(RouteConfigurations.carepassLookUpTitle);
    _meta.removeTag("name='description'");
    _meta.addTag({ name: 'description', content: RouteConfigurations.carepassLookupDesc });
  }

  // Created an instance of the Form group for profile completion form
  carePassLookUpForm: FormGroup;

  // This gets the generic content from constants file
  genericContent: object;

  // this flag checks whether the carepass form is submitted or not
  carePassLookUpSubmitted: Boolean = false;

  // this flag checks whether the carepass form is submitted or not
  formHasError: Boolean = false;

  // this object holds the error for zip code field
  zipError: object = {'lookUpZipEmpty': 'Enter a valid ZIP code', 'lookUpZipInvalid': 'Enter a valid ZIP code'}

  // this flag checks whether the carepass look up service failed or not
  carePassLookUpServiceError: Boolean = false;

  // this signifies the kind of service error to generic service error component
  errorType: String = '';

  // this checks whether the zip is found or not
  zipNotFound: Boolean = false;

    /* This function creates and intializes the look up form*/
    createLookUpForm() {
      this.carePassLookUpForm = this.fb.group({
        lookUpZip: ['', [Validators.required,
                        Validators.pattern(this.genericContent['zipPattern'])]]
      });
    }

    carepassLookUp() {
      this.carePassLookUpSubmitted = true;
        if (this.carePassLookUpForm.status.toUpperCase() === 'INVALID') {
          this.assignErrorClasses(this.carePassLookUpForm);
          this.formHasError = true;
          this.errorBlock.nativeElement.focus();
        }else {
          this.formHasError = false;
          const carePassLookUpReqObj = {
            'request': {
              'actionType': 'carePassZipCodeValidation',
              'postalCode': this.carePassLookUpForm.get('lookUpZip').value
            }
          };
          this._ajaxUtility.sendRequest('carepassLookUp', carePassLookUpReqObj)
          .subscribe(
            (data: HttpResponse<any>) => {
              if (data['response']['header']['statusCode'] === '0000') {
                if (data['response']['details']['zipCodeValidationStatus'] === true ||
                    data['response']['details']['zipCodeValidationStatus'] === 'true') {
                  // Setting the session storage variable to check if already looked up or not
                  sessionStorage.setItem('carepassLookUpDone', 'true');
                  // Change made - If guest user redirect to account login page
                  // else to carepass/go page.
                  if (!this._cookieService.exists('SCC_COOKIE')) {
                    location.href = '/account/login.jsp?carePass=Y';
                  }else {
                    this._route.navigate(['/go']);
                  }
                } else {
                  this.zipNotFound = true;
                  this.carepassComingSoon.nativeElement.focus();
                  try {
                    const utagObj = {
                      'page_name': 'carepass:coming soon'
                    };
                    setTimeout(() => {
                      this._utag.view(utagObj);
                    }, 2000);
                  } catch (error) {}
                }
              }else {
                this.carePassLookUpServiceError = true;
                this.errorType = 'genericSerice';
              }
            },
            (err) => {
              this.carePassLookUpServiceError = true;
              this.errorType = 'genericSerice';
            });
        }
      }

      /* This function performs simple navigation to the shop component*/

      navigateToShop() {
        location.href = '/shop';
      }

        /* This function will check form fields for errors and assign a class to them
       but only on submit and not on keypress */
      assignErrorClasses(formObj) {
        for (const controlObjKey in formObj.controls) {
          formObj['controls'][controlObjKey]['visited'] = false;
          if (formObj['controls'][controlObjKey]['errors'] !== null) {
          formObj['controls'][controlObjKey]['custErrors'] = {};
          formObj['controls'][controlObjKey]['errorState'] = true;
              if (formObj['controls'][controlObjKey]['errors']['required']) {
              formObj['controls'][controlObjKey]['custErrors'] = {'emptyError' : true};
              }else {
                if (formObj['controls'][controlObjKey]['errors']['pattern'] || formObj['controls'][controlObjKey]['errors']['email']) {
                  formObj['controls'][controlObjKey]['custErrors'] = {'patternError' : true};
              }}
          }else {
            // this.emailZipValidationForm['errorState'] = true;
            formObj['controls'][controlObjKey]['errorState'] = false;
          }
        }
      }

  ngOnInit() {
    this.genericContent = this.clubContants.getLookUpContent();
    this.createLookUpForm();
    try {
      const utagObj = {
        'page_name': 'carepass:is carepass near me'
      };
      setTimeout(() => {
        this._utag.view(utagObj);
      }, 2000);
    } catch (error) {}
  }
}
