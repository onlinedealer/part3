(function() {
	'use strict';

	angular.module('arm').factory('dealService', ['serviceApi', '$filter', 'SERVICE_TYPE', 'localStorageService', 'sqliteService', 'utility','GENERAL_CONFIG','$rootScope', 'noteService', dealService]);

	function dealService(serviceApi, $filter, SERVICE_TYPE, localStorageService, sqliteService, utility, GENERAL_CONFIG,$rootScope,noteService) {
		var serArr = {};

		serArr.dealMod = function() {
			return {
				uiObject : {
					ActualDealCloseDate: null,
                  ActualDealRevenue : 0,
                  ActualDealRevenueConverted : 0,
                  ActualDealRevenueCurrencyConvRate : 0,
                  ActualDealRevenueCurrencyID : 0,
                  ActualDealSize : 0,
                  ActualDealSizeConverted : 0,
                  ActualDealSizeCurrencyConvRate : 0,
                  ActualDealSizeCurrencyID : 0,
                  Attachments: [],
                  CampaignReference: '',
                  CampaignReferenceID: 0,
                  CompanyName : '',
                  ContactID : 0,
                  ContactDeviceObjID: '',
                  ContactName: '',
                  ContactDisplayName: '',
                  ContactOwnerID: null,
                  ContactOwnerName: null,
                  ContactSegmentID : null,
                  ContactSegmentName : null,
                  ContactTierID : null,
                  ContactTierName : null,
                  ContactTypeID: 0,
                  CreatedAt : null,
                  CreatorID : 0,
                  CreatedOn: '',
                  CreatorName: '',
                  DealAttendees: [],
                  DealChecklistMapping: {
                        CustomerTypeID: null,
                        DealChecklistMappingID: 0,
                        DealID: 0,
                        ProductFamilyID: null,
                        ProductID: null,
                        ProductSchemeID: null,
                        ProductTypeID: null
                  },
                  DealCompetitorID: null,
                  DealDocumentMapping: [],
                  DealID : 0,
                  DealSourceID: 0,
                  DealSourceName: '',
                  DealStageID: 0,
                  DealStageName: '',
                  DealStageModelID: null,
                  DealSubject : '',
                  DeviceObjID : utility.generateUUID(),
                  EmployerID: null,
                  EmployerName: null,
                  ExpectedDealCloseDate : '',
                  ExpectedDealRevenue : 0,
                  ExpectedDealRevenueConverted : 0,
                  ExpectedDealRevenueCurrencyConvRate : 0,
                  ExpectedDealRevenueCurrencyID : 0,
                  ExpectedDealSize : 0,
                  ExpectedDealSizeConverted : 0,
                  ExpectedDealSizeCurrencyConvRate : 0,
                  ExpectedDealSizeCurrencyID : 0,
                  Fields: [],
                  IsConfidential : false,
                  IsDeleteRequestRaised: false,
                  ModifiedAt : null,
                  ModifiedBy : 0,
                  ModifiedOn : '',
                  ModuleID: GENERAL_CONFIG.MODULES.Deal,
                  Notes: [],
                  OwnerID : 0,
                  OwnerName: '',
                  ProductFamilyID : 0,
                  ProductFamilyName : '',
                  ProductID : 0,
                  ProductName : '',
                  RepresentativeDeviceObjID : '',
                  RepresentativeID : null,
                  RepresentativeName: null,
                  AddedFromSource : 2,
                  DealChecklistMappingStr : ''
				}
			}
		};

      serArr.dealCloseLostMod = function() {
      return {
        uiObject : {
          DeviceObjID : '',
          DealID : 0,
          ActualDealCloseDate: null,
          ActualDealRevenue: null,
          ActualDealRevenueConverted: null,
          ActualDealRevenueCurrencyConvRate: null,
          ActualDealRevenueCurrencyID: null,
          ActualDealSize: null,
          ActualDealSizeConverted: null,
          ActualDealSizeCurrencyConvRate: null,
          ActualDealSizeCurrencyID: null,
          DealStageID: 0,
          DealStageName: '',
          DealCompetitorID: null,
          Note: null,
          ModifiedAt : null,
          ModifiedBy : 0,
          ModifiedOn : '',
        }
      }
    };

    function CheckNull(val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return "NULL";
            }
            return val;
    }

    function CheckBitVal(val) {
            if (val == true) {
                return 1;
            }
            return 0;
    }

    serArr.syncDealServerRecords = function (sourceArray, desArray, objOverDue, objDevIds) {
        angular.forEach(sourceArray, function (obj, key) {
            if (obj.DeviceObjID != null) {
                if (objDevIds.length > 0) {
                    var exitingList = $filter('filter')(objDevIds, { DeviceObjID: obj.DeviceObjID });
                }else{
                    var exitingList = $filter('filter')(desArray, { DeviceObjID: obj.DeviceObjID });
                }
                if (exitingList.length == 0) {
                    exitingList = serArr.dealMod().uiObject;
                    desArray.push(exitingList);
                    var dealStageModelID = utility.dealStageModelIDCheck(obj.DealStageID);
                    exitingList.Priority = utility.getColorCodeForDeals(obj.ExpectedDealCloseDate, dealStageModelID);
                    if (exitingList.Priority == 1) {
                           objOverDue++;
                    }
                    utility.syncModelWithoutInnerCollection(obj, exitingList);
                    exitingList.ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate(exitingList.ExpectedDealCloseDate).toString();
                    exitingList.OwnerNameToDisplay = utility.getNameByOrOwner(exitingList);
                    exitingList.DealStageModelIDToCheck = dealStageModelID;
                    exitingList.DealStageName = utility.dealStageName(exitingList.DealStageID);
                    obj.DealStageName = utility.dealStageName(exitingList.DealStageID);
                    if (exitingList.ContactTypeID == 1) {
                        exitingList.ContactDisplayName = obj.ContactName;
                        obj.ContactDisplayName = obj.ContactName;
                        if (typeof obj.EmployerName != 'undefined' || obj.EmployerName != null){
                            exitingList.CompanyName = obj.EmployerName;
                            obj.CompanyName = obj.EmployerName;
                        }else{
                            exitingList.CompanyName = '';
                            obj.CompanyName = '';
                        }
                    }else{
                        exitingList.CompanyName = obj.ContactName;
                        obj.CompanyName = obj.ContactName;
                        if (typeof obj.RepresentativeName != 'undefined' || obj.RepresentativeName != null){
                            exitingList.ContactDisplayName = obj.RepresentativeName;
                            obj.ContactDisplayName = obj.RepresentativeName;
                            exitingList.RepresentativeName = obj.RepresentativeName;
                        }else{
                            exitingList.ContactDisplayName = '';
                            obj.ContactDisplayName = '';
                        }
                    }
                    serArr.addDealToSql(obj).then(function (result) { });
                }else{
                    var extDealList = [];
                    if (objDevIds.length > 0) {
                        extDealList = serArr.dealMod().uiObject;
                    }else{
                        extDealList = exitingList[0];
                    }
                    // update the obj in model and SQLight DB
                    var dealStageModelID = utility.dealStageModelIDCheck(obj.DealStageID);
                    extDealList.Priority = utility.getColorCodeForDeals(obj.ExpectedDealCloseDate, dealStageModelID);
                    if (extDealList.Priority == 1) {
                          objOverDue++;
                    }
                    utility.syncModelWithoutInnerCollection(obj,extDealList);
                    extDealList.ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate(extDealList.ExpectedDealCloseDate).toString();
                    extDealList.OwnerNameToDisplay = utility.getNameByOrOwner(extDealList);
                    extDealList.DealStageModelIDToCheck = dealStageModelID;
                    extDealList.DealStageName = utility.dealStageName(extDealList.DealStageID);
                    obj.DealStageName = utility.dealStageName(extDealList.DealStageID);
                    if (extDealList.ContactTypeID == 1) {
                        extDealList.ContactDisplayName = obj.ContactName;
                        obj.ContactDisplayName = obj.ContactName;
                        //tarLst.ContactName = tarLst.contactName;
                        if (typeof obj.EmployerName != 'undefined' || obj.EmployerName != null){
                            extDealList.CompanyName = obj.EmployerName;
                            obj.CompanyName = obj.EmployerName;
                        }else{
                            extDealList.CompanyName = '';
                            obj.CompanyName = '';
                        }
                    }else{
                        extDealList.CompanyName = obj.ContactName;
                        obj.CompanyName = obj.ContactName;
                        if (typeof obj.RepresentativeName != 'undefined' || obj.RepresentativeName != null){
                            extDealList.ContactDisplayName = obj.RepresentativeName;
                            obj.ContactDisplayName = obj.RepresentativeName;
                            extDealList.RepresentativeName = obj.RepresentativeName;
                        }else{
                            extDealList.ContactDisplayName = '';
                            obj.ContactDisplayName = '';
                        }
                    }

                    // Assign the sub child model for Deal Document Mapping
                    if(obj.DealDocumentMapping.length > 0){
                        extDealList.DealDocumentMapping = obj.DealDocumentMapping;
                    }else{
                        extDealList.DealDocumentMapping = [];
                        //contactService.bindCorrespondencesEmptyModel(existedRecord);
                    }
                    // Assign the sub child model for Notes
                    if(obj.Notes.length > 0){
                        extDealList.Notes = obj.Notes;
                    }else{
                        extDealList.Notes = [];
                    }
                    // Assign the sub child model for Deal Attendees
                    if(obj.DealAttendees.length > 0){
                        extDealList.DealAttendees = obj.DealAttendees;
                    }else{
                        extDealList.DealAttendees = [];
                    }
                    // Assign the sub child model for Activity Deal Mappings
                    if(obj.ActivityDealMappings.length > 0){
                        // utility.syncModelWithoutInnerCollection(resFieldsObj,existedRecord[index]);
                        extDealList.ActivityDealMappings = obj.ActivityDealMappings;
                    }else{
                        extDealList.ActivityDealMappings = [];
                    }
                    // Assign the sub child model for Attachments
                    if(obj.Attachments.length > 0){
                        extDealList.Attachments = obj.Attachments;
                    }else{
                        extDealList.Attachments = [];
                    }

                    // Assign the sub child model for Attachments
                    if(obj.Fields.length > 0){
                        if(extDealList.Fields.length > 0){
                            angular.forEach(obj.Fields, function (resFieldsObj, index) {
                                var existedField = $filter('filter')(existedRecord.Fields, {FieldName: obj.FieldName});
                                if(existedField != null || existedField != ""){
                                    utility.syncModelWithCollection(resFieldsObj,existedField);
                                }
                            });
                        }
                    }else{
                        extDealList.Fields = [];
                        //contactService.bindFieldsEmptyModel(existedRecord);
                    }
                    serArr.updateDealToSql(extDealList).then(function (result) {
                    }, function (error) {  });
                } //end
            }
        });
    }

	serArr.addDealToSql = function(objDeal) {

  			var queryBindingsArr = [];
        var dealQuery = serArr.prepareDealInsertQuery(objDeal);
        var dealBindings = '';

        var dynamicFldQueryBidings = utility.prepareDynamicFldQuery(objDeal);
        var dealDynamicFldQuery = dynamicFldQueryBidings.Query
        var dealDynamicFldBindings = dynamicFldQueryBidings.Bindings;

        var participientQuery = serArr.prepareParticipientsInsertQuery(objDeal);
        var participientBinding = '';

        var documentMappingQuery = serArr.prepareDocumentMappingInsertQuery(objDeal);
        var documentMappingBinding = '';

        /*var notesQuery = serArr.prepareNotesInsertQuery(objDeal);
        var notesBinding = '';*/
        angular.forEach(objDeal.Notes, function (obj) {
             queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
        });

        var attachmentsQuery = serArr.prepareAttachmentsInsertQuery(objDeal);
        var attachmentsBinding = '';

        queryBindingsArr.push(
                           {
                                 'Query' : dealQuery,
                                 'Bindings': dealBindings
                                 },
                                 {
                                 'Query' : dealDynamicFldQuery,
                                 'Bindings': dealDynamicFldBindings
                                 }
                                 );

        if(objDeal.DealAttendees.length != 0){
          queryBindingsArr.push(
                           {
                           'Query' : participientQuery,
                           'Bindings': participientBinding
                           }
          );
        }

        if(objDeal.DealDocumentMapping.length != 0){
          queryBindingsArr.push(
                           {
                           'Query' : documentMappingQuery,
                           'Bindings': documentMappingBinding
                           }
                           );
        }

        /*if(objDeal.Notes.length != 0){
          queryBindingsArr.push(
                           {
                           'Query' : notesQuery,
                           'Bindings': notesBinding
                           }
                           );
        }*/

        if(objDeal.Attachments.length != 0){
          queryBindingsArr.push(
                           {
                           'Query' : attachmentsQuery,
                           'Bindings': attachmentsBinding
                           }
                           );
        }

        return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
                    }, function (error) {
                            });

		}

    serArr.updateDealToSql = function(objDeal) {
        var queryBindingsArr = [];
        var dealQuery = serArr.prepareDealUpdateQuery(objDeal);
        var dealBindings = '';

        /* var notesQuery = serArr.prepareNotesInsertQuery(objDeal);
         var notesBinding = ''; */

        angular.forEach(objDeal.Notes, function (obj) {
             queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
        });

        var dealDeleteFieldsQuery = "DELETE FROM DynamicFields WHERE ParentDeviceObjID ='" + objDeal.DeviceObjID + "'";

        queryBindingsArr.push(
                   {
                   'Query' : dealQuery,
                   'Bindings': dealBindings
                   },
                   {
                   'Query' : dealDeleteFieldsQuery,
                   'Bindings': ""
                   }
        );

        // Notes Update Query

        /*if(objDeal.Notes.length != 0){
          queryBindingsArr.push(
                           {
                           'Query' : notesQuery,
                           'Bindings': notesBinding
                           }
                           );
        }*/

        // Dynamic Fields Update Query

        if (objDeal.Fields.length > 0) {
                var dynamicFldQueryBidings = utility.prepareDynamicFldQuery(objDeal);
                var dealDynamicFldQuery = dynamicFldQueryBidings.Query
                var dealDynamicFldBindings = dynamicFldQueryBidings.Bindings;
                queryBindingsArr.push(
                        {
                            'Query': dealDynamicFldQuery,
                            'Bindings': dealDynamicFldBindings
                        });
        }

        // Participients Update Query

            var delIds = '';
            var queryVal = '';
            if (objDeal.DealAttendees.length > 0) {
                for (var i = 0; i < objDeal.DealAttendees.length; i++) {
                    if (objDeal.DealAttendees[i].EntityAttendeeID == null || objDeal.DealAttendees[i].EntityAttendeeID == 0) {
                        if(queryVal!='')
                        queryVal += ',';
                        queryVal += "('" + objDeal.DealAttendees[i].DeviceObjID + "','" + objDeal.DealAttendees[i].AttendeeID + "','" + objDeal.DealAttendees[i].UserName + "','" + objDeal.DealAttendees[i].ParentDeviceObjType + "','" + objDeal.DeviceObjID + "','"
                        + objDeal.DealAttendees[i].Type + "','" + objDeal.DealAttendees[i].AttendeeDeviceObjID + "','" + CheckNull(objDeal.DealAttendees[i].AccessCategoryID) + "',1," + $rootScope.loggedInUserID + ")";
                    }
                    else {
                        delIds += "'" + objDeal.DealAttendees[i].DeviceObjID + "',";
                    }
                }
                if (delIds != '') {
                    delIds = delIds.substring(0, delIds.length - 1);
                    var dealDeleteParQuery = "DELETE FROM Participients WHERE ParentDeviceObjID ='" + objDeal.DeviceObjID + "' AND DeviceObjID NOT IN (" + delIds + ")";
                    queryBindingsArr.push(
                         {
                             'Query': dealDeleteParQuery,
                             'Bindings': ""
                         });
                }
                if (queryVal != '') {
                    var dealUsrQuery = "INSERT INTO Participients (DeviceObjID,AttendeeID,UserName,ParentType,ParentDeviceObjID,Type,AttendeeDeviceObjID,AccessCategoryID,IsChecked,LoggedInUserID) VALUES" + queryVal;
                    queryBindingsArr.push(
                     {
                         'Query': dealUsrQuery,
                         'Bindings': ""
                     });
                }

            }

          // Document Mapping Update Query
          queryBindingsArr.push(serArr.deletePrepareQuery("DealDocumentMapping", objDeal.DealDocumentMapping, objDeal.DeviceObjID));
          angular.forEach(objDeal.DealDocumentMapping, function (obj) {
              queryBindingsArr.push(serArr.prepareDocumentMappingInsertEditQuery(obj));
          });

          // Attachments Delete and Insert Query
          queryBindingsArr.push(serArr.deletePrepareQuery("Attachments", objDeal.Attachments, objDeal.DeviceObjID));
          if(objDeal.Attachments.length > 0){
            var attachmentsQuery = serArr.prepareAttachmentsInsertQuery(objDeal);
            queryBindingsArr.push({'Query': attachmentsQuery,'Bindings': ""});
          }

        return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
                    }, function (error) {
        });

    }

    // Delete Common Function For Update

      serArr.deletePrepareQuery = function (tableName,childObjArray,contactDeviceID) {
         var currModifyArr = [];
         for(var i=0; i< childObjArray.length; i++){
             currModifyArr.push("'" + childObjArray[i].DeviceObjID + "'");
         }
        var deviceObjIdInString = currModifyArr.join(",");
        if(tableName=="DealDocumentMapping"){
            var deleteQuery = "DELETE FROM " + tableName + " WHERE ParentDeviceObjID = '"+ contactDeviceID +"' AND DeviceObjID NOT IN (" +deviceObjIdInString+ ")";
        }
        if(tableName=="Attachments"){
            var deleteQuery = "DELETE FROM " + tableName + " WHERE ParentDeviceObjID = '"+ contactDeviceID +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID;
        }
        return  {'Query':deleteQuery,'Bindings':''};
    }

    // Add Deal Syncing After Response

        serArr.sqlDealSync = function (resObj) {
        var queryArr = [];
        var dealUpdate = "UPDATE Deals SET DealID = " + resObj.DealID + " WHERE DeviceObjID ='" + resObj.DeviceObjID + "'";
        queryArr.push(
                  {
                      'Query': dealUpdate,
                      'Bindings': ""
                  });

        // Update for Notes

        if (resObj.Notes.length > 0) {
                var noteUpdate = "UPDATE Notes SET NoteID = " + resObj.Notes[0].NoteID + "," +
                "EntityID =" + resObj.DealID +
                " WHERE DeviceObjID ='" + resObj.Notes[0].DeviceObjID + "'";
                queryArr.push(
                          {
                              'Query': noteUpdate,
                              'Bindings': ""
                          });
        }

        // Update for Deal Document Mapping

        if (resObj.DealDocumentMapping.length > 0) {
                for(var i=0;i<resObj.DealDocumentMapping.length;i++){
                  var documentMappingUpdate = "UPDATE DealDocumentMapping SET DealDocumentMappingID = " + resObj.DealDocumentMapping[i].DealDocumentMappingID + "," +
                  "DealID =" + resObj.DealID + " WHERE DeviceObjID ='" + resObj.DealDocumentMapping[i].DeviceObjID + "'";
                        queryArr.push(
                          {
                              'Query': documentMappingUpdate,
                              'Bindings': ""
                          });
                }
        }

        // Update for Attachments

        if (resObj.Attachments.length > 0) {
              for(var i=0;i<resObj.Attachments.length;i++){
                var documentAttachmentsUpdate = "UPDATE Attachments SET AttachmentID = " + resObj.Attachments[i].AttachmentID + "," +
                "EntityID =" + resObj.DealID +
                " WHERE DeviceObjID ='" + resObj.Attachments[i].DeviceObjID + "'";
                queryArr.push(
                          {
                              'Query': documentAttachmentsUpdate,
                              'Bindings': ""
                          });
              }
        }

        // Update for Participients

        if (resObj.DealAttendees.length > 0) {
          for (var i = 0; i < resObj.DealAttendees.length; i++) {
              var entId = resObj.DealAttendees[i].EntityAttendeeID;
              var devId = resObj.DealAttendees[i].DeviceObjID
              queryArr.push(
                     {
                         'Query': "UPDATE Participients SET EntityAttendeeID = " + entId + " WHERE DeviceObjID ='" + devId + "'",
                         'Bindings': ""
                     });

          }
        }

        return sqliteService.multipleQueries(queryArr).then(function (result) {
        }, function (error) {
        });
    }



    serArr.prepareDealInsertQuery = function(objDeal)
    {
      var dealQuery = "INSERT INTO Deals (DealID, DeviceObjID, ContactID, ContactDeviceObjID, ContactName, ContactDisplayName, CompanyName, ProductFamilyID, ProductFamilyName, ProductID, ProductName, DealSubject, ExpectedDealSize," +
      "ExpectedDealSizeCurrencyID, ExpectedDealSizeCurrencyConvRate, ExpectedDealSizeConverted, ExpectedDealRevenue, ExpectedDealRevenueCurrencyID, ExpectedDealRevenueCurrencyConvRate,"+
      " ExpectedDealRevenueConverted, ActualDealSize, ActualDealSizeCurrencyID, ActualDealSizeCurrencyConvRate, ActualDealSizeConverted, ActualDealRevenue, ActualDealRevenueCurrencyID,"+
      " ActualDealRevenueCurrencyConvRate, ActualDealRevenueConverted, ExpectedDealCloseDate, RepresentativeID, OwnerID, OwnerName, CreatorID, IsConfidential, CreatedOn,"+
      " CreatedAt, ModifiedBy, ModifiedOn, ModifiedAt, ModuleID, ActualDealCloseDate, CampaignReference, CampaignReferenceID, ContactOwnerID, ContactOwnerName, ContactSegmentID, ContactSegmentName,"+
      " ContactTierID, ContactTierName, ContactTypeID, CreatorName, DealCompetitorID, DealSourceID, DealSourceName, DealStageID, DealStageName, DealStageModelID, EmployerID, EmployerName, IsDeleteRequestRaised, RepresentativeDeviceObjID, RepresentativeName, AddedFromSource,"+
      " DealChecklistMappingStr,LoggedInUserID) VALUES('"+ objDeal.DealID +"','"+ objDeal.DeviceObjID +"','"+ objDeal.ContactID +"','"+ objDeal.ContactDeviceObjID +"','"+ objDeal.ContactName +"','"+ objDeal.ContactDisplayName +"','"+ objDeal.CompanyName +"','"+
      objDeal.ProductFamilyID +"','"+ objDeal.ProductFamilyName +"','"+ objDeal.ProductID +"','"+ objDeal.ProductName +"','"+ objDeal.DealSubject +"','"+ objDeal.ExpectedDealSize +
      "','"+ objDeal.ExpectedDealSizeCurrencyID +"','"+ objDeal.ExpectedDealSizeCurrencyConvRate +"','"+ objDeal.ExpectedDealSizeConverted +"','"+ objDeal.ExpectedDealRevenue +"','"+
      objDeal.ExpectedDealRevenueCurrencyID +"','"+ objDeal.ExpectedDealRevenueCurrencyConvRate +"','"+ objDeal.ExpectedDealRevenueConverted +"','"
      + objDeal.ActualDealSize +"','"+ objDeal.ActualDealSizeCurrencyID +"','"+ objDeal.ActualDealSizeCurrencyConvRate +"','"+ objDeal.ActualDealSizeConverted +"','"+ objDeal.ActualDealRevenue +"','"+
      objDeal.ActualDealRevenueCurrencyID +"','"+ objDeal.ActualDealRevenueCurrencyConvRate +"','"+ objDeal.ActualDealRevenueConverted +"','"+ objDeal.ExpectedDealCloseDate +"','"+
      CheckNull(objDeal.RepresentativeID) +"','"+ objDeal.OwnerID +"','"+ objDeal.OwnerName +"','"+ objDeal.CreatorID +"','"+ objDeal.IsConfidential +"','"+ objDeal.CreatedOn +"','"+
      CheckNull(objDeal.CreatedAt) +"','"+ objDeal.ModifiedBy +"','"+ objDeal.ModifiedOn +"','"+ CheckNull(objDeal.ModifiedAt) +"','"+ objDeal.ModuleID +"','"+ CheckNull(objDeal.ActualDealCloseDate) +"','"+ objDeal.CampaignReference +
      "',"+ CheckNull(objDeal.CampaignReferenceID) +",'"+ CheckNull(objDeal.ContactOwnerID) +"','"+ CheckNull(objDeal.ContactOwnerName) +"','"+ CheckNull(objDeal.ContactSegmentID) +"','"+ CheckNull(objDeal.ContactSegmentName) +"','"+
      CheckNull(objDeal.ContactTierID) +"','"+ CheckNull(objDeal.ContactTierName) +"','"+ objDeal.ContactTypeID +"','"+ objDeal.CreatorName +"','"+ CheckNull(objDeal.DealCompetitorID) +"','"+ objDeal.DealSourceID +"','"+ objDeal.DealSourceName +"','"+
      objDeal.DealStageID +"','"+ objDeal.DealStageName +"','"+ CheckNull(objDeal.DealStageModelID) +"','"+ CheckNull(objDeal.EmployerID) +"','"+ CheckNull(objDeal.EmployerName) +"','"+ objDeal.IsDeleteRequestRaised +"','"+ objDeal.RepresentativeDeviceObjID +"','"+ CheckNull(objDeal.RepresentativeName) +"','"+
      objDeal.AddedFromSource +"','"+ objDeal.DealChecklistMappingStr +"'," + $rootScope.loggedInUserID + ")";

      return dealQuery;
    };

    serArr.prepareDealUpdateQuery = function(objDeal)
    {
      var dealQuery = "UPDATE Deals SET  ContactID =" + objDeal.ContactID + "," + "ContactDeviceObjID ='" + objDeal.ContactDeviceObjID + "'," +
                      "ContactName ='" + objDeal.ContactName + "'," + "ContactDisplayName ='" + objDeal.ContactDisplayName + "'," +
                      "CompanyName ='" + objDeal.CompanyName + "'," + "ProductFamilyID =" + objDeal.ProductFamilyID + "," +
                      "ProductFamilyName ='" + objDeal.ProductFamilyName + "'," + "ProductID =" + objDeal.ProductID + "," +
                      "ProductName ='" + objDeal.ProductName + "'," + "DealSubject ='" + objDeal.DealSubject + "'," +
                      "ExpectedDealSize =" + objDeal.ExpectedDealSize + "," + "ExpectedDealSizeCurrencyID =" + objDeal.ExpectedDealSizeCurrencyID + "," +
                      "ExpectedDealSizeCurrencyConvRate =" + objDeal.ExpectedDealSizeCurrencyConvRate + "," + "ExpectedDealSizeConverted =" + objDeal.ExpectedDealSizeConverted + "," +
                      "ExpectedDealRevenue =" + objDeal.ExpectedDealRevenue + "," + "ExpectedDealRevenueCurrencyID =" + objDeal.ExpectedDealRevenueCurrencyID + "," +
                      "ExpectedDealRevenueCurrencyConvRate =" + objDeal.ExpectedDealRevenueCurrencyConvRate + "," + "ExpectedDealRevenueConverted =" + objDeal.ExpectedDealRevenueConverted + "," +
                      "ActualDealSize =" + objDeal.ActualDealSize + "," + "ActualDealSizeCurrencyID =" + objDeal.ActualDealSizeCurrencyID + "," +
                      "ActualDealSizeCurrencyConvRate =" + objDeal.ActualDealSizeCurrencyConvRate + "," + "ActualDealSizeConverted =" + objDeal.ActualDealSizeConverted + "," +
                      "ActualDealRevenue =" + objDeal.ActualDealRevenue + "," + "ActualDealRevenueCurrencyID =" + objDeal.ActualDealRevenueCurrencyID + "," +
                      "ActualDealRevenueCurrencyConvRate =" + objDeal.ActualDealRevenueCurrencyConvRate + "," + "ActualDealRevenueConverted =" + objDeal.ActualDealRevenueConverted + "," +
                      "ExpectedDealCloseDate ='" + objDeal.ExpectedDealCloseDate + "'," + "RepresentativeID =" + objDeal.RepresentativeID + "," +
                      "OwnerID =" + objDeal.OwnerID + "," + "OwnerName ='" + objDeal.OwnerName + "'," +
                      "CreatorID =" + objDeal.CreatorID + "," + "IsConfidential ='" + objDeal.IsConfidential + "'," +
                      "CreatedOn ='" + objDeal.CreatedOn + "'," +
                      "CreatedAt ='" + objDeal.CreatedAt + "'," + "ModifiedBy =" + objDeal.ModifiedBy + "," +
                      "ModifiedOn ='" + objDeal.ModifiedOn + "'," + "ModifiedAt ='" + objDeal.ModifiedAt + "'," +
                      "ModuleID =" + objDeal.ModuleID + "," + "ActualDealCloseDate ='" + objDeal.ActualDealCloseDate + "'," +
                      "ContactOwnerID =" + objDeal.ContactOwnerID + "," + "ContactOwnerName ='" + objDeal.ContactOwnerName + "'," +
                      "ContactSegmentID =" + objDeal.ContactSegmentID + "," + "ContactSegmentName ='" + objDeal.ContactSegmentName + "'," +
                      "ContactTierID =" + objDeal.ContactTierID + "," + "ContactTierName ='" + objDeal.ContactTierName + "'," +
                      "ContactTypeID =" + objDeal.ContactTypeID + "," + "CreatorName ='" + objDeal.CreatorName + "'," +
                      "DealCompetitorID =" + objDeal.DealCompetitorID + "," + "DealSourceID =" + objDeal.DealSourceID + "," +
                      "DealSourceName ='" + objDeal.DealSourceName + "'," + "DealStageID =" + objDeal.DealStageID + "," +
                      "DealStageName ='" + objDeal.DealStageName + "'," + "DealStageModelID =" + objDeal.DealStageModelID + "," +
                      "EmployerID =" + objDeal.EmployerID + "," + "EmployerName ='" + objDeal.EmployerName + "'," +
                      "IsDeleteRequestRaised ='" + objDeal.IsDeleteRequestRaised + "'," + "RepresentativeDeviceObjID ='" + objDeal.RepresentativeDeviceObjID + "'," +
                      "RepresentativeName ='" + objDeal.RepresentativeName + "'," + "AddedFromSource =" + objDeal.AddedFromSource + "," +
                      "DealChecklistMappingStr ='" + objDeal.DealChecklistMappingStr + "'" +
                       " WHERE DeviceObjID ='" + objDeal.DeviceObjID + "'";

      return dealQuery;
    };

    // Update Deal Stage ID

    serArr.sqlDealStageUpdate = function (objDeal) {

      var dealStageQuery = "UPDATE Deals SET  DealStageID =" + objDeal.DealStageID + "," +
                      "DealStageName ='" + objDeal.DealStageName + "'" +
                       " WHERE DeviceObjID ='" + objDeal.DeviceObjID + "'";

        return sqliteService.query(dealStageQuery
                           ).then(function (result) {
                               //alert('sucess');
                               return result;
                           });

    }

    serArr.prepareParticipientsInsertQuery = function(objDeal)
    {

      var queryVal = '';
      for (var i = 0; i < objDeal.DealAttendees.length; i++) {
          if(i!=0)
          queryVal += ',';
          queryVal += "('" + objDeal.DealAttendees[i].DeviceObjID + "','" + objDeal.DealAttendees[i].AttendeeID + "','" + objDeal.DealAttendees[i].UserName + "','" + objDeal.DealAttendees[i].ParentDeviceObjType + "','" + objDeal.DeviceObjID + "','"
            + objDeal.DealAttendees[i].Type + "','" + objDeal.DealAttendees[i].AttendeeDeviceObjID + "','" + CheckNull(objDeal.DealAttendees[i].AccessCategoryID) + "',1," + $rootScope.loggedInUserID + ")";
      }

      var participientConcatenatedQuery = "INSERT INTO Participients (DeviceObjID,AttendeeID,UserName,ParentType,ParentDeviceObjID,Type,AttendeeDeviceObjID,AccessCategoryID,IsChecked,LoggedInUserID) VALUES" + queryVal;

      return  participientConcatenatedQuery;
    };


    serArr.prepareDocumentMappingInsertQuery = function(objDeal){
      var queryVal = '';
      for (var i = 0; i < objDeal.DealDocumentMapping.length; i++) {
          if(i!=0)
          queryVal += ',';
          queryVal += "('" + objDeal.DealDocumentMapping[i].DealDocumentMappingID + "','" + objDeal.DealDocumentMapping[i].DealID + "','" + objDeal.DealDocumentMapping[i].DeviceObjID + "','" + objDeal.DealDocumentMapping[i].ParentDeviceObjID + "','" + objDeal.DealDocumentMapping[i].DocumentID + "','" + objDeal.DealDocumentMapping[i].DocumentName + "'," + $rootScope.loggedInUserID + ")";
      }

      var documentMappingConcatenatedQuery = "INSERT INTO DealDocumentMapping (DealDocumentMappingID, DealID, DeviceObjID, ParentDeviceObjID, DocumentID, DocumentName,LoggedInUserID) VALUES" + queryVal;

      return  documentMappingConcatenatedQuery;
    };

    serArr.prepareDocumentMappingInsertEditQuery = function(objDealDocumentMapping){

      var documentMappingConcatenatedQuery = "INSERT INTO DealDocumentMapping (DealDocumentMappingID,DealID,DeviceObjID,"+
            "ParentDeviceObjID,DocumentID,DocumentName,LoggedInUserID)" +
            "SELECT '" +  objDealDocumentMapping.DealDocumentMappingID  +"','" +  objDealDocumentMapping.DealID  +"','" +  objDealDocumentMapping.DeviceObjID  + "','" +
            objDealDocumentMapping.ParentDeviceObjID  + "','"+  objDealDocumentMapping.DocumentID  +"','"+
            objDealDocumentMapping.DocumentName  +"', " + $rootScope.loggedInUserID +
            " WHERE NOT EXISTS (SELECT 1 FROM DealDocumentMapping WHERE DeviceObjID ='" + objDealDocumentMapping.DeviceObjID + "' )";

        return  {'Query':documentMappingConcatenatedQuery,'Bindings':''};
    };

    serArr.prepareNotesInsertQuery = function(objDeal){
      var queryVal = '';
      for (var i = 0; i < objDeal.Notes.length; i++) {
          if(i!=0)
          queryVal += ',';
          queryVal += "('" + objDeal.Notes[i].DeviceObjID + "','" + objDeal.Notes[i].EntityID + "','" + objDeal.Notes[i].ModuleID + "','" + objDeal.Notes[i].NoteID + "','" + objDeal.Notes[i].ParentDeviceObjID + "','" + objDeal.Notes[i].Description + "','"
            + objDeal.Notes[i].CreatorID + "','" + objDeal.Notes[i].CreatorName + "','" + objDeal.Notes[i].CreatedOn + "','" + objDeal.Notes[i].CreatedAt + "','" + objDeal.Notes[i].ModifiedBy + "','" + objDeal.Notes[i].ModifiedOn + "','" + objDeal.Notes[i].ModifiedAt + "'," + $rootScope.loggedInUserID + ")";
      }

      var notesConcatenatedQuery = "INSERT INTO Notes (DeviceObjID, EntityID, ModuleID, NoteID, ParentDeviceObjID, Description, CreatorID, CreatorName, CreatedOn, CreatedAt, LoggedInUserID) VALUES" + queryVal;

      return  notesConcatenatedQuery;
    };

    serArr.prepareAttachmentsInsertQuery = function(objDeal){
          var queryVal = '';
          for (var i = 0; i < objDeal.Attachments.length; i++) {
                var syncStatus = 0;
                if (objDeal.Attachments[i].AttachmentID != 0) {
                        syncStatus = 1;
                }
              if(i!=0)
              queryVal += ',';
              queryVal += "(" + objDeal.Attachments[i].AttachmentCategoryID  +"," +  objDeal.Attachments[i].AttachmentID +",'" +  objDeal.Attachments[i].DeviceObjID +"',"+  objDeal.Attachments[i].EntityID +"," + objDeal.Attachments[i].ModuleID +",'" + objDeal.Attachments[i].ParentDeviceObjID +"','" +
                             objDeal.Attachments[i].FileName  +"','" +  objDeal.Attachments[i].MIMEContentType +"','" +  objDeal.Attachments[i].Extension +"'," + objDeal.Attachments[i].DocumentID +",'" + objDeal.Attachments[i].DocumentName +"'," +
                             $rootScope.loggedInUserID  +",'" + objDeal.Attachments[i].ModifiedAt  +"'," + syncStatus +"," + $rootScope.loggedInUserID + ")";
          }

          var attachmentsConcatenatedQuery = "INSERT INTO Attachments (AttachmentCategoryID,AttachmentID,DeviceObjID,EntityID,ModuleID,ParentDeviceObjID,FileName,MIMEContentType,Extension,DocumentID,DocumentName,ModifiedBy,ModifiedAt,SyncStatus,LoggedInUserID) VALUES" + queryVal;

          return  attachmentsConcatenatedQuery;
    };

    serArr.sqlSelectDeals = function(){
        return sqliteService.query("SELECT * FROM Deals WHERE LoggedInUserID="+ $rootScope.loggedInUserID  +" ").then(function(result){
            return result;
        });
    }

      // Adding Product Family

      serArr.sqlProductFamilyAdd = function (objDealProdFamily) {
            var queryArr = [];

            var productFamilyDeleteQuery = "DELETE FROM ProductFamily";

            queryArr.push(
                  {
                      'Query': productFamilyDeleteQuery,
                      'Bindings': ""
                  });

            var queryVal = '';
            for (var i = 0; i < objDealProdFamily.length; i++) {
                if(i!=0)
                queryVal += ',';
                queryVal += "('" + objDealProdFamily[i].ProductFamilyID + "','" + objDealProdFamily[i].Name + "'," + $rootScope.loggedInUserID + ")";
            }

            var productFamilyQuery = "INSERT INTO ProductFamily (ProductFamilyID, Name, LoggedInUserID) VALUES" + queryVal;

            queryArr.push(
                  {
                      'Query': productFamilyQuery,
                      'Bindings': ""
                  });

            return sqliteService.multipleQueries(queryArr).then(function (result) {
            }, function (error) {
            });

        }

        // Adding Products

        serArr.sqlProductsAdd = function (objDealProdFamily) {
            var queryArr = [];

            var productsDeleteQuery = "DELETE FROM Products";

            queryArr.push(
                  {
                      'Query': productsDeleteQuery,
                      'Bindings': ""
                  });

            var queryVal = '';
            for (var i = 0; i < objDealProdFamily.length; i++) {
              for(var j=0;j<objDealProdFamily[i].Products.length;j++){
                if(queryVal!='')
                queryVal += ',';
                queryVal += "('" + objDealProdFamily[i].Products[j].ProductID + "','" + objDealProdFamily[i].Products[j].Name + "','" + objDealProdFamily[i].Products[j].ProductFamilyID + "','" + objDealProdFamily[i].Products[j].ProductFamilyName + "'," + $rootScope.loggedInUserID + ")";
              }
            }

            var productsQuery = "INSERT INTO Products (ProductID, Name, ProductFamilyID, ProductFamilyName, LoggedInUserID) VALUES" + queryVal;

            queryArr.push(
                  {
                      'Query': productsQuery,
                      'Bindings': ""
                  });

            return sqliteService.multipleQueries(queryArr).then(function (result) {
            }, function (error) {
            });

        }

        // Getting All Product Family

        serArr.sqlGetAllProductFamily = function () {
            return sqliteService.query('SELECT * from ProductFamily WHERE LoggedInUserID= '+ $rootScope.loggedInUserID ).then(function (result) {
                return result;
            });
        }

        // Getting Products

        serArr.sqlGetAllProducts = function (productFamily) {
            var returnArr = [productFamily];
            return sqliteService.query('SELECT * from Products WHERE ProductFamilyID="' + productFamily.ProductFamilyID + '" AND LoggedInUserID= '+ $rootScope.loggedInUserID).then(function (result) {
                returnArr.push(result);
                return returnArr;
            });
        }

	    serArr.dealAdd = function(obj) {
            //alert('calling dealCTRL');
            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };

            var finalData = { "Data": [obj] };
            return serviceApi.doPostWithData("dealAddService",
                    SERVICE_TYPE.DEALADD, finalData, headerconfig).then(function (response) {
                        return response;
            });
        }

      serArr.dealCloseLost = function(obj) {
            //alert('calling dealCTRL');
            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };

            var finalData = { "Data": obj };
            return serviceApi.doPostWithData("dealCloseLostService",
                    SERVICE_TYPE.DEALCLOSELOST, finalData, headerconfig).then(function (response) {
                        return response;
            });
       }

      // Update Deal Close

      serArr.dealCloseToSql = function (objDeal) {

        var dealCloseQuery = "UPDATE Deals SET  ActualDealSize =" + objDeal.ActualDealSize + "," + "ActualDealSizeCurrencyID =" + objDeal.ActualDealSizeCurrencyID + "," +
                      "ActualDealSizeCurrencyConvRate =" + objDeal.ActualDealSizeCurrencyConvRate + "," + "ActualDealSizeConverted =" + objDeal.ActualDealSizeConverted + "," +
                      "ActualDealRevenue =" + objDeal.ActualDealRevenue + "," + "ActualDealRevenueCurrencyID =" + objDeal.ActualDealRevenueCurrencyID + "," +
                      "ActualDealRevenueCurrencyConvRate =" + objDeal.ActualDealRevenueCurrencyConvRate + "," + "ActualDealRevenueConverted =" + objDeal.ActualDealRevenueConverted + "," +
                      "ModifiedBy =" + objDeal.ModifiedBy + "," +
                      "ModifiedOn ='" + objDeal.ModifiedOn + "'," + "ModifiedAt ='" + objDeal.ModifiedAt + "'," +
                      "ActualDealCloseDate ='" + objDeal.ActualDealCloseDate + "'," +
                      "DealStageID =" + objDeal.DealStageID + "," +
                      "DealStageName ='" + objDeal.DealStageName + "'" +
                       " WHERE DeviceObjID ='" + objDeal.DeviceObjID + "'";

          return sqliteService.query(dealCloseQuery
                             ).then(function (result) {
                                 //alert('sucess');
                                 return result;
                             });

      }

      // Update Deal Lost

      serArr.dealLostToSql = function (objDeal) {
        var queryArr = [];

        var dealLostQuery = "UPDATE Deals SET ModifiedBy =" + objDeal.ModifiedBy + "," +
                      "ModifiedOn ='" + objDeal.ModifiedOn + "'," + "ModifiedAt ='" + objDeal.ModifiedAt + "'," +
                      "DealStageID =" + objDeal.DealStageID + "," +
                      "DealStageName ='" + objDeal.DealStageName + "'" +
                       " WHERE DeviceObjID ='" + objDeal.DeviceObjID + "'";

        queryArr.push(
                  {
                      'Query': dealLostQuery,
                      'Bindings': ""
                  });

      // Insert into the Note table
      angular.forEach(objDeal.Notes, function (obj) {
           queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
      });

      /*var notesQuery = "INSERT INTO Notes (DeviceObjID, EntityID, ModuleID, NoteID, ParentDeviceObjID, Description, CreatorID, CreatorName, CreatedOn, CreatedAt, ModifiedBy, ModifiedOn, ModifiedAt, LoggedInUserID) VALUES('"+ objDeal.Note.DeviceObjID +"',"+ objDeal.Note.EntityID +","+ objDeal.Note.ModuleID +","+ objDeal.Note.NoteID +",'"+ objDeal.Note.ParentDeviceObjID +"','"+ objDeal.Note.Description +"',"+ objDeal.Note.CreatorID +",'"+
      objDeal.Note.CreatorName +"','"+ objDeal.Note.CreatedOn +"','"+ objDeal.Note.CreatedAt +"',"+ objDeal.Note.ModifiedBy +",'"+ objDeal.Note.ModifiedOn +"','"+ objDeal.Note.ModifiedAt +"'," + $rootScope.loggedInUserID + ")";;

      queryArr.push(
                  {
                      'Query': notesQuery,
                      'Bindings': ""
                  });
       */

        return sqliteService.multipleQueries(queryArr).then(function (result) {
                    }, function (error) {
        });

      }

      serArr.dealLostUpdateNotesToSql = function (response) {

        var noteUpdate = "UPDATE Notes SET NoteID = " + response.Note.NoteID + "," +
                "EntityID =" + response.DealID +
                " WHERE DeviceObjID ='" + response.Note.DeviceObjID + "'";

          return sqliteService.query(noteUpdate
                             ).then(function (result) {
                                 //alert('sucess');
                                 return result;
                             });

      }

		serArr.dealProductFamily = function() {
            var headerconfig = {
                headers:
                          {
                              'ProductDateTime': utility.getDateStringInUTC(new Date())
                          }
            };

            var productFamilyURL = SERVICE_TYPE.PRODUCTFAMILY+'/'+$rootScope.loggedInUserID+'/1/1/NULL/1';

            return serviceApi.doGetWithoutData("LoadProductFamily",
                    productFamilyURL, headerconfig).then(function (response) {
                    	return response;
                    });
        }

    serArr.emailDealDetails = function(dealID) {
            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };

            var emailDealDetailsURL = SERVICE_TYPE.DEALDETAILSEMAIL+'/'+dealID+'/'+$rootScope.loggedInUserID;

            return serviceApi.doGetWithoutData("EmailDealDetails",
                    emailDealDetailsURL, headerconfig).then(function (response) {
                      return response;
                    });
    }

    serArr.dealList = function(fetchType) {
        var serviceType = ''; var RetrievalType = '';
        if(fetchType == "Next"){
             RetrievalType = GENERAL_CONFIG.DataRetrivalType.Next; // Next
             serviceType = GENERAL_CONFIG.WebServiceType.DealListNext; // DealListNext
        }else{
             RetrievalType = GENERAL_CONFIG.DataRetrivalType.Pevious;
             serviceType = GENERAL_CONFIG.WebServiceType.DealListPrev;
        }
        var dealListURL = SERVICE_TYPE.DEALLIST+$rootScope.loggedInUserID+"/"+GENERAL_CONFIG.DataRetrivalType.Chunk+"/"+$rootScope.languageID+"/"+RetrievalType;
        serviceApi.headerConfg['WebServiceType'] = serviceType;
        return serviceApi.doGetWithoutData("dealListService",
            dealListURL, serviceApi.headerConfg).then(function (response) {
            return response;
        });
    }

    serArr.sqlGetPanelData = function(tableName,deviceId){
          return sqliteService.query("SELECT * FROM " + tableName + " WHERE ParentDeviceObjID ='" + deviceId +"'").then(function (result) {
              return result;
          });
    }

    serArr.sqlGetAllDealDeviceObjIds = function(){
        return sqliteService.query("SELECT DeviceObjID FROM Deals WHERE LoggedInUserID="+ $rootScope.loggedInUserID  +" ").then(function(result){
            return result;
        });
    }

    // Get Customer ID from Contacts

    serArr.sqlGetContactCustomerID = function(deviceObjId){
          return sqliteService.query("SELECT CustomerID FROM Contacts WHERE DeviceObjID ='" + deviceObjId +"'").then(function (result) {
              return result;
          });
    }

    serArr.sqlUpdateContactCustomerID = function(customerID, deviceObjId){
          var dealCustomerIDUpdateQuery = "UPDATE Contacts SET CustomerID ='" + customerID + "'" +
                       " WHERE DeviceObjID ='" + deviceObjId + "'";

          return sqliteService.query(dealCustomerIDUpdateQuery).then(function (result) {
              return result;
          });
    }

    // Getting All Attachments

    serArr.getAttachments = function(attachmentID) {
            var headerconfig = {
                headers:
                          {
                              'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                          }
            };

            var getAttachmentsURL = SERVICE_TYPE.GETATTACHMENT+'/'+attachmentID;

            return serviceApi.doGetWithoutData("LoadGetAttachments",
                    getAttachmentsURL, headerconfig).then(function (response) {
                      return response;
                    });
    }

    // Update Attachments File Path

      serArr.sqlUpdateAttachmentPath = function (filePath, attachmentId) {

      var attachmentUpdateQuery = "UPDATE Attachments SET FilePath ='" + filePath + "'" +
                     " WHERE AttachmentID =" + attachmentId;

        return sqliteService.query(attachmentUpdateQuery
                           ).then(function (result) {
                               //alert('sucess');
                               return result;
                           });

    }

    // Set Selected Deal
    var selectedDeal = null;
    serArr.setSelectedDeal = function(deal){
         selectedDeal = deal;
    };

    // Get Selected Deal
    serArr.getSelectedDeal = function(){
         return selectedDeal;
    };

		return serArr;
	}

})();
