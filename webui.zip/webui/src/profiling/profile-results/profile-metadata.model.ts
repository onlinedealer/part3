export class ProfileMetadataModel {
  source: string;
  sourceType: string;
  host: string;
  db: string;
  schema: string;
  constructor() {
    this.source = '';
    this.sourceType = '';
    this.host = '';
    this.db = '';
    this.schema = '';
  }
}
