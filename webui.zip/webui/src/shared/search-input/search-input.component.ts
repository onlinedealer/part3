import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'discovery-search-input',
  templateUrl: './search-input.component.html'
})
export class SearchInputComponent {
  @Input() id: string = 'search-input';
  @Input() showBorder: boolean = true;
  @Input() bgClass: string = '';
  @Input() searchIcon: string = 'png-icon-sm png-search';
  // pbi-icon-mini
  @Input() searchValue: string;
  /**
   * This property is used to disable the input text box, if needed.
   */
  @Input() disabled = false;

  /**
   * This property is used as the placeholder text for the Filter text box.
   */
  @Input() filterPlaceholder: string = 'discoveryShared.common.search';

  /**
   * This event is fired whenever the filter text is modified.
   */
  @Output() filterChange: EventEmitter<string> = new EventEmitter<string>();
}
