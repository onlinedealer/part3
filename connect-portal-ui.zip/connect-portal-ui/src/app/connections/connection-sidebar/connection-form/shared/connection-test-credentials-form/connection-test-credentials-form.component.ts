import { ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup } from '@angular/forms';
import { ConnectionOptions } from 'tls';
import { BaseConnectionForm } from '../../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../../base-connection-form/base-connection-form.component';
import { Connection } from '../../../../shared/connection';

@Component({
  selector: 'p-connect-connection-test-credentials-form',
  templateUrl: './connection-test-credentials-form.component.html'
})
export class ConnectionTestCredentialsFormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy, BaseConnectionForm {
  @Input() formGroup;

  ngOnDestroy(): void {
    this.removeChildFormControls(this.formGroup);
  }

  constructor(private readonly controlContainer: ControlContainer, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }
  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): ConnectionOptions {
    const connection = {} as Connection;
    connection.username = this.formGroup.get('testUser').value;
    connection.password = this.formGroup.get('testPassword').value;
    return connection;
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm(): void {
    this.formGroup = this.controlContainer.control as FormGroup;
    this.formGroup.addControl('testUser', new FormControl(''));
    this.formGroup.addControl('testPassword', new FormControl(''));
  }
}
