import { Component, ViewChild } from '@angular/core';
import { SidebarButton } from '../../../shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { LogReaderDetails } from '../../shared/pipelines-monitoring-status';
import { BaseComponent } from '../../../core/base.component';

@Component({
  selector: 'p-connect-logreader-details-sidebar',
  templateUrl: './logreader-details-sidebar.component.html',
  styleUrls: ['./logreader-details-sidebar.component.scss']
})
export class LogReaderDetailsSidebarComponent extends BaseComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  logReaderDetails: LogReaderDetails;
  cancelButton: SidebarButton = {
    id: 'closeLogReaderDetailsSidebar',
    text: 'pipelines.LOG_READER_DETAILS_SIDEBAR.CLOSE'
  };
  projectName = '';

  open(logReaderDetails: LogReaderDetails, projectName: string) {
    this.logReaderDetails = logReaderDetails;
    this.projectName = projectName;
    this.sidebarComponent.open();
  }

  isDb2I(): boolean {
    return this.logReaderDetails?.dataConnectionType === 'DB2I';
  }
}
