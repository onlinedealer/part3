import { Action, createReducer, on } from "@ngrx/store";
import { UIActions } from "../actions";

export interface UiState {
    windowWidth: number | undefined;
    windowHeight: number | undefined;
    headerTitle: string;
}

export const initialState: UiState = {
    windowWidth: undefined,
    windowHeight: undefined,
    headerTitle: ""
};

const uiReducer = createReducer(
    initialState,

    on(UIActions.WindowInitialized, UIActions.WindowResized, (state, { windowWidth, windowHeight }) => {
        return {
            ...state,
            windowWidth: windowWidth,
            windowHeight: windowHeight
        };
    }),

    on(UIActions.FeatureModuleInitialized, (state, { title }) => ({
        ...state,
        headerTitle: title
    }))
);

export function reducer(state: UiState | undefined, action: Action): UiState {
    return uiReducer(state, action);
}
