import { Spies } from 'discovery-test';
import { MultiSemanticInfoTableComponent } from './multi-semantic-info-table.component';

describe('MultiSemanticInfoTableComponent', () => {
  let component: MultiSemanticInfoTableComponent;

  beforeEach(() => {
    Spies.init();
    component = new MultiSemanticInfoTableComponent(Spies.TranslateService);
    component.cols = [
      {
        field: 'semanticType',
        header: 'Semantic Type',
        type: 'showInfoLink',
        flagKey: 'isShowLink'
      },
      {
        field: 'validity',
        header: 'Validity',
        type: 'progressBar'
      }
    ];
    component.name = 'multipleSemantic';
    component.semanticType = 'multipleSemantic';
    component.statistic = [
      {
        type: 'SemanticStatistics',
        group: 'SEMANTIC_ANALYSIS',
        semanticType: 'LASTNAME',
        validity: {
          type: 'ValidityStatistics',
          validCount: 6,
          invalidCount: 3060007
        }
      },
      {
        type: 'DateSemanticStatistics',
        group: 'SEMANTIC_ANALYSIS',
        semanticType: 'DATE',
        validity: {
          type: 'ValidityStatistics',
          validCount: 3060007,
          invalidCount: 6
        },
        dateFormatFrequency: {
          type: 'FrequencyStatistics',
          frequency: {
            'yyyy-MM-dd': 3060000,
            'MM/dd/yyyy': 7,
            'dd/MM/yyyy': 2
          }
        }
      },
      {
        type: 'ConfidenceStatistics',
        group: 'SEMANTIC_ANALYSIS',
        semanticType: 'DATE',
        validCount: 3060007,
        invalidCount: 6
      }
    ];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with multiple Frequency', () => {
    component.ngOnInit();
    spyOn<any>(component, 'loadMultiSemanticTable');
    component.loadMultiSemanticTable();
    expect(component['loadMultiSemanticTable']).toHaveBeenCalled();
  });
  it('should have exptected table header and values', () => {
    component.ngOnInit();
    expect(component.data.length).toBeGreaterThanOrEqual(1);
    expect(component.defaultSort).toMatch('validity');
    expect(component.cols.length).toBeGreaterThanOrEqual(1);
    expect(component.cols[0].flagKey).toMatch('isShowLink');

    const link = Object.keys(component.statistic[1]).some((key) =>
      component.statistic[1][key] && component.statistic[1][key]['frequency'] ? true : false
    );
    const totalCount =
      component.statistic[1]['validity']['invalidCount'] + component.statistic[1]['validity']['validCount'];
    expect(component.data[1].validity).toEqual((component.statistic[1]['validity']['validCount'] / totalCount) * 100);
    expect(component.data[1].validity).toEqual((component.statistic[1]['validity']['validCount'] / totalCount) * 100);
    expect(component.data[1].confidence).toEqual(
      (component.statistic[2]['validCount'] /
        (component.statistic[2]['validCount'] + component.statistic[2]['invalidCount'])) *
        100
    );
  });

  it('should correctly @Output value', () => {
    spyOn<any>(component, 'onTableRowClick').and.callThrough();
    spyOn(component.tableRowData, 'emit').and.callThrough();
    component.onTableRowClick(component.statistic[0].semanticType, 0);
    expect(component['onTableRowClick']).toHaveBeenCalled();
  });
});
