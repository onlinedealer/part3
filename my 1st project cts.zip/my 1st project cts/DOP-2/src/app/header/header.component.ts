import { Component, OnInit } from '@angular/core';
import {SearchComponent} from './search/search.component';
import {CommonModule} from "@angular/common";

@Component({
  selector: 'cvs-global-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  
  navItems = [    
    {"link": '/google.com', "text": 'Pharmacy'},
    {"link": '/yahoo.com', "text": 'Minute Clinic'},
    {"link": '/asdasd.com', "text": 'Shop'},
    {"link": '/asdasd.com', "text": 'Extracare'},  
    {"link": '/asdasd.com', "text": 'Contact Lenses'},
    {"link": '/asdasd.com', "text": 'Photo'}

  ];
  
  constructor() { }

  ngOnInit() {
  }

}
