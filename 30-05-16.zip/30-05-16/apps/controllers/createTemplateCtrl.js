(function() {
    'use strict';

    fileuploader.controller("createTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', createTemplateCtrl]);

    function createTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.uploadpreview = "apps/images/income.jpg";
        $scope.rows = [];
        $scope.imageArray = [];
        $scope.tempArray = [];
        var tarGet = document.getElementById("target");
        var imgW = tarGet.clientWidth;
        var imgH = tarGet.clientHeight;
        var newW = 200;
        var jcrop_api;
        $scope.onClick = function(event) {
            var x = event.x;
            var y = event.y;
            var offsetX = event.offsetX;
            var offsetY = event.offsetY;
            console.log(offsetX, offsetY);
        };

        $scope.addRow = function() {

            for (var i = 0; i < $scope.tempArray.length; i++) {

                $scope.imageArray.push($scope.tempArray[i]);
            }
            $scope.tempArray = [];

            var tempAreaName = [];
            tempAreaName = $scope.templateAreaName;
            console.log(tempAreaName)

        };

        $scope.saveTemplate = function(totalData) {
            var obj = {};
            obj['custTemplateName'] = $scope.custTemplateName;
            obj['rows'] = $scope.imageArray;
            obj['headers'] = $scope.templateAreaName;
            console.log(obj)

        };

        $('#target').Jcrop({
            onSelect: showCords,
        });

        function showCords(c) {
            var obj = {};
            obj['startPointX'] = c.x;
            obj['startPointY'] = c.y;
            obj['imageWidth'] = c.w;
            obj['imageHeight'] = c.h;
            $scope.tempArray.push(obj);
            console.log(obj)

            $scope.$apply(function() {

            });
        }
    }
})();
