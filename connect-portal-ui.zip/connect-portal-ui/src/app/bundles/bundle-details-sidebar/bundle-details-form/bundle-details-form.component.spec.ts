import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Connection } from 'src/app/connections/shared/connection';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { LogReadersApiService } from 'src/app/pipelines/pipeline/data/shared/logreaders-api.service';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { of } from 'rxjs';

import { BundleDetailsFormComponent } from './bundle-details-form.component';
import { LogReader } from 'src/app/pipelines/pipeline/data/shared/logreader';
import { Bundle, MetadataDetails } from '../../shared/bundles';
import { SidebarManagerService } from '@precisely/prism-ng/sidebar-manager';

describe('BundleDetailsFormComponent', () => {
  let component: BundleDetailsFormComponent;
  let fixture: ComponentFixture<BundleDetailsFormComponent>;
  let logReadersApiService: LogReadersApiService;
  let sidebarManagerService: SidebarManagerService;

  const filesInTheBundle: MetadataDetails[] = [
    {
      fileType: 'AGENT',
      totalSize: 150266,
      directory: './',
      metadataDetailsList: [
        { fileName: 'agent.log', fileSize: 75133, status: 'COMPLETED' },
        { fileName: 'agent.log', fileSize: 75133, status: 'ERROR' }
      ]
    },
    {
      fileType: 'JOB_CONTROLLER',
      totalSize: 82936,
      directory: './',
      metadataDetailsList: [
        { fileName: 'jobcontroller.log', fileSize: 41468, status: 'QUEUED' },
        { fileName: 'jobcontroller.log', fileSize: 41468, status: 'IN_PROGRESS' }
      ]
    },
    {
      fileType: 'LISTENER',
      totalSize: 424988,
      directory: './',
      metadataDetailsList: [
        { fileName: 'LOCALHOST.log', fileSize: 212494, status: 'QUEUED' },
        { fileName: 'LOCALHOST.log', fileSize: 212494, status: 'STOPPED' }
      ]
    },
    {
      fileType: 'KERNEL',
      totalSize: 125120,
      directory: './',
      metadataDetailsList: [
        { fileName: 'LOCALHOST.log', fileSize: 62560, status: 'COMPLETED' },
        { fileName: 'LOCALHOST.log', fileSize: 62560, status: 'COMPLETED' }
      ]
    },
    {
      fileType: 'XML',
      totalSize: 424988,
      directory: './',
      metadataDetailsList: [
        { fileName: 'LOCALHOST.log', fileSize: 212494, status: 'COMPLETED' },
        { fileName: 'LOCALHOST.log', fileSize: 212494, status: 'IN_PROGRESS' }
      ]
    },
    {
      fileType: 'IBMI',
      totalSize: 100000,
      directory: './',
      metadataDetailsList: [
        { fileName: 'test_1.log', fileSize: 50000, status: 'QUEUED' },
        { fileName: 'test_2.log', fileSize: 50000, status: 'ERROR' }
      ]
    }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      declarations: [BundleDetailsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BundleDetailsFormComponent);
    component = fixture.componentInstance;
    logReadersApiService = TestBed.inject(LogReadersApiService);
    sidebarManagerService = TestBed.inject(SidebarManagerService);
    spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of([{ name: 'logReader1' }] as LogReader[]));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return the correct icon based on bundle status', () => {
    expect(component.getBundleStatusIcon('ACTION_REQUIRED')).toContain('png-alert-actionrequired-solid');
    expect(component.getBundleStatusIcon('ERROR')).toContain('png-alert-actionrequired-solid');
    expect(component.getBundleStatusIcon('STOPPED')).toContain('png-alert-stopped-solid');
    expect(component.getBundleStatusIcon('IN_PROGRESS')).toContain('png-alert-inprogress');
    expect(component.getBundleStatusIcon('COMPLETED')).toContain('png-alert-ok-solid');
    expect(component.getBundleStatusIcon('QUEUED')).toContain('png-signin');
  });

  it('should return the increased icon size based on bundle status', () => {
    expect(component.getBundleStatusIcon('ACTION_REQUIRED', 'x2')).toContain('x2');
    expect(component.getBundleStatusIcon('ERROR', 'x2')).toContain('x2');
    expect(component.getBundleStatusIcon('STOPPED', 'x2')).toContain('x2');
    expect(component.getBundleStatusIcon('IN_PROGRESS', 'x2')).toContain('x2');
    expect(component.getBundleStatusIcon('COMPLETED', 'x2')).toContain('x2');
    expect(component.getBundleStatusIcon('QUEUED', 'x2')).toContain('x2');
  });

  it('should get name for the instances of log reader and  DB2I data connection if a DB2I connection is in the project', () => {
    component.filesInTheBundle = filesInTheBundle;
    spyOn(component, 'getConnectionAndLogReaderName').and.callThrough();
    component.checkIfIBMIConnectionUsedInProject([{ name: 'test', connectionType: 'DB2I' }] as Connection[], { id: 'abc' } as Project);
    expect(component.getConnectionAndLogReaderName).toHaveBeenCalled();
    expect(component.db2iConnectionName).toEqual('test');
    expect(logReadersApiService.getLogReaders).toHaveBeenCalled();
  });

  it('should get specified files total size and status type', () => {
    component.filesInTheBundle = filesInTheBundle;
    expect(component.getSpecifiedFileInformation('AGENT').status).toEqual('ERROR');
    expect(component.getSpecifiedFileInformation('JOB_CONTROLLER').status).toEqual('QUEUED');
    expect(component.getSpecifiedFileInformation('LISTENER').status).toEqual('STOPPED');
    expect(component.getSpecifiedFileInformation('KERNEL').status).toEqual('COMPLETED');
    expect(component.getSpecifiedFileInformation('XML').status).toEqual('IN_PROGRESS');
  });

  it('should open error message sidebar', () => {
    spyOn(sidebarManagerService, 'setActiveSidebar').and.returnValue();
    component.bundleDetails = { details: 'error' } as Bundle;
    component.openErrorMessageSidebar();
    expect(sidebarManagerService.setActiveSidebar).toHaveBeenCalled();
  });

  it('should hide individual file status icon if the file overall status is QUEUED', () => {
    component.filesInTheBundle = filesInTheBundle;
    expect(component.showBundleFileStatusIcon('JOB_CONTROLLER')).toBe(false);
  });

  it('should show individual file status icon if the file overall status is not QUEUED', () => {
    component.filesInTheBundle = filesInTheBundle;
    expect(component.showBundleFileStatusIcon('AGENT')).toBe(true);
    expect(component.showBundleFileStatusIcon('LISTENER')).toBe(true);
    expect(component.showBundleFileStatusIcon('KERNEL')).toBe(true);
    expect(component.showBundleFileStatusIcon('XML')).toBe(true);
    expect(component.showBundleFileStatusIcon('IBMI')).toBe(true);
  });

  it('should expect size of a file (in the bundle) to be 0.00 MB if its total size returned from API is equal to 0', () => {
    component.filesInTheBundle = [
      {
        fileType: 'KERNEL',
        totalSize: 0,
        directory: './',
        metadataDetailsList: []
      }
    ];
    expect(component.getSpecifiedFileInformation('KERNEL').totalSize).toEqual('0.00 MB');
  });
  it('should hide total size of kernel log in bundle content table, if bundle details response consist of kernel log having total size of -1', () => {
    component.filesInTheBundle = [
      {
        fileType: 'KERNEL',
        totalSize: -1,
        directory: './',
        metadataDetailsList: []
      }
    ];
    expect(component.hideBundleFileEstimatedSize('KERNEL')).toBe(true);
  });
  it('should hide total size of a log in bundle content table, if the specific log data is not returned from bundle details response', () => {
    component.filesInTheBundle = [
      {
        fileType: 'KERNEL',
        totalSize: 0,
        directory: './',
        metadataDetailsList: []
      }
    ];
    expect(component.hideBundleFileEstimatedSize('LISTENER')).toBe(true);
  });
  it('should expect location of bundle to include container name in the beginning of the path', () => {
    component.bundleDetails = { location: '/home/connect/.connect/jobcontroller/bundles/test.zip' } as Bundle;
    expect(component.locationOfBundle).toEqual('connect-agent-jobcontroller:/home/connect/.connect/jobcontroller/bundles/test.zip');
  });
});
