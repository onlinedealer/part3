import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { StopBundleFormComponent } from './stop-bundle-form.component';

describe('StopBundleComponent', () => {
  let component: StopBundleFormComponent;
  let fixture: ComponentFixture<StopBundleFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [StopBundleFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StopBundleFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return appropriate verb', () => {
    component.bundlesCount = 1;
    expect(component.pluralOrSingularVerb).toBe('bundles.STOP_BUNDLE.BUNDLE');
    component.bundlesCount = 10;
    expect(component.pluralOrSingularVerb).toBe('bundles.STOP_BUNDLE.BUNDLES');
  });
});
