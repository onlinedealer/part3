import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { ConnectionDetailsFormComponent } from './connection-details-form.component';

describe('ConnectionDetailsFormComponent', () => {
  let component: ConnectionDetailsFormComponent;
  let fixture: ComponentFixture<ConnectionDetailsFormComponent>;

  const mockSelectedPipeline: any = {
    projectId: '61ae6e1abfb2cd1777a98edd',
    name: 'test',
    captureStatus: 'UNKNOWN',
    dataFlowType: 'REPLICATE',
    replicationStatus: 'UNKNOWN',
    runtimeServers: [
      {
        dataConnections: [
          {
            connectionType: 'KAFKA',
            logReaders: [],
            name: 'HJ11(2)',
            source: false,
            target: true
          },
          {
            connectionType: 'DB2I',
            logReaders: [
              {
                journal: 'GISLARDJ/JRNRCV0037',
                name: 'GISLARDJ/TSTJRN',
                sequence: '00000000000000000045',
                status: 'OK'
              }
            ],
            name: 'LTIAS08',
            source: true,
            target: false
          }
        ]
      }
    ]
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule],
      declarations: [ConnectionDetailsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectionDetailsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.selectedPipeline = mockSelectedPipeline;
    component.selectedConnection = mockSelectedPipeline.runtimeServers[0].dataConnections[1];
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call hasMonitoringStatusValues', () => {
    expect(component.hasMonitoringStatusValues()).toBe(true);
    component.selectedPipeline = { projectId: '61ae6e1abfb2cd1777a98edd' };
    expect(component.hasMonitoringStatusValues()).toBe(false);
    component.selectedPipeline = null;
    expect(component.hasMonitoringStatusValues()).toBe(false);
  });

  it('should call isSourceConnecton', () => {
    expect(component.isSourceConnecton()).toBe(true);
    component.selectedConnection = mockSelectedPipeline.runtimeServers[0].dataConnections[0];
    expect(component.isSourceConnecton()).toBe(false);
  });

  it('should call isSourceConnecton', () => {
    expect(component.getRole()).toContain('SOURCE');
    component.selectedConnection = mockSelectedPipeline.runtimeServers[0].dataConnections[0];
    expect(component.getRole()).toContain('TARGET');
  });
});
