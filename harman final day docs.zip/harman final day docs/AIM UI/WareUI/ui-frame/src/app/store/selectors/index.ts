import * as UISelectors from "./ui.selectors";
import * as SecuritySelectors from "./security.selectors";
import * as ConfigurationsSelectors from "./configurations.selectors";
import * as UserSettingsSelectors from "./user-settings.selectors";
import * as RouterSelectors from "./router.selectors";
import * as NetworkSpecificConfigSelectors from "./network-specific-config.selectors";
import * as EnvironmentIndicatorSelector from "./environment-indicator.selectors";

export {
    UISelectors,
    SecuritySelectors,
    ConfigurationsSelectors,
    UserSettingsSelectors,
    RouterSelectors,
    NetworkSpecificConfigSelectors,
    EnvironmentIndicatorSelector
};
