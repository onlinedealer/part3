import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Connection, CONNECTION_TYPE } from '../../shared/connection';

@Component({
  selector: 'p-connect-manage-catalog-sidebar',
  templateUrl: './manage-catalog-sidebar.component.html'
})
export class ManageCatalogSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * The display of the sidebar component
   */
  @Input() isVisible: boolean;
  @Output() isVisibleChanged = new EventEmitter<boolean>();

  /**
   * The connection that the catalogs are related to
   */
  @Input() connection: Connection;

  primaryButton: SidebarButton = {
    isHidden: true
  };

  cancelButton: SidebarButton = {
    id: 'manageCatalogCancel',
    text: 'common.BUTTONS.CLOSE'
  };

  /**
   * Event handler for when an error occurs in the catalog component
   * @param error The error message to display
   */
  onServiceError(error) {
    this.sidebarComponent.parseHttpClientResponseMessage('error', error);
  }

  /**
   * Toggles the wait state of the sidebar
   * @param isProcessing Whether the sidebar is in the wait state
   */
  onProcessingRequest(isProcessing) {
    this.sidebarComponent.isProcessingRequest = isProcessing;
  }

  onActionCompleted() {
    if (this.connection.connectionType === CONNECTION_TYPE.KAFKA) {
      this.isVisible = false;
      this.isVisibleChanged.emit(false);
    }
  }

  /**
   * Toggle the display of the sidebar
   * @param $event The event that is emitted when the user clicks the cancel button
   */
  toggleSidebarVisibility($event: boolean) {
    this.isVisible = false;
    this.isVisibleChanged.emit(false);
  }
}
