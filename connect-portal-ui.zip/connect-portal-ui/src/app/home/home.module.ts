import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeComponent } from './home.component';
import { HomeRoutingModule } from './home-routing.module';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SharedModule } from '../shared/shared.module';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { AgentsHomeComponent } from './agents-home/agents-home.component';
import { ServersHomeComponent } from './servers-home/servers-home.component';
import { PipelinesHomeComponent } from './pipelines-home/pipelines-home.component';
import { commonLoader, homeLoader, pipelinesLoader, pngLoader, serversLoader, projectsLoader } from '../i18n-loaders';
import { ServersModule } from '../servers/servers.module';
import { MessagesModule } from 'primeng/messages';
import { MessageModule } from 'primeng/message';
import { ProjectsHomeComponent } from './projects-home/projects-home.component';
import { ProjectsModule } from '../projects/projects.module';

@NgModule({
  declarations: [HomeComponent, AgentsHomeComponent, ServersHomeComponent, PipelinesHomeComponent, ProjectsHomeComponent],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'home', loader: homeLoader },
        { scope: 'servers', loader: serversLoader },
        { scope: 'pipelines', loader: pipelinesLoader },
        { scope: 'png', loader: pngLoader },
        { scope: 'projects', loader: projectsLoader }
      ]
    }
  ],
  imports: [
    HomeRoutingModule,
    ProgressSpinnerModule,
    CommonModule,
    SharedModule,
    TranslocoModule,
    ServersModule,
    ProjectsModule,
    MessagesModule,
    MessageModule
  ]
})
export class HomeModule {}
