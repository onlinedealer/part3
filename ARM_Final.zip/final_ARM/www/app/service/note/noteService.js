(function () {
    'use strict';

    angular.module('arm').factory('noteService', ['serviceApi', '$rootScope', '$filter', 'SERVICE_TYPE', 'sqliteService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', noteService]);

    function noteService(serviceApi, $rootScope, $filter, SERVICE_TYPE, sqliteService, utility, MASTER_TABLE, GENERAL_CONFIG) {

        var serArr = {};

         // Note Module code
        serArr.noteMod = function () {
            return {
                noteModel: {
                    ContactID: 0,
                    ContactObjID: '',
                    CreatorID: 0,
                    CreatedOn: '',
                    CreatorName: '',
                    CreatedAt: null,
                    Description: '',
                    DeviceObjID: serArr.generateUUID(),
                    EntityID: 0,
                    ParentDeviceObjID:'',
                    ModuleID: 0,
                    NoteID: 0,
                    RepresentativeID: null,
                    RepresentativeObjID: null
                }
            }
        };

        serArr.generateUUID = function () {
            var d = new Date().getTime();
            if (window.performance && typeof window.performance.now === "function") {
                d += performance.now(); //use high-precision timer if available
            }
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });
            return uuid;
        }

        serArr.addNoteToServer = function(obj) {      
            var headerconfig = { headers: { 'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;' } };
            var finalData = {  "Data": obj };

            return serviceApi.doPostWithData("NoteAddService",
                SERVICE_TYPE.CONTACTNOTE, finalData, headerconfig).then(function(response) {
                return response;
            });  
        }

        serArr.addNoteToSql = function(objNote) { 
            var queryBindingsArr = [];
            angular.forEach(objNote, function (noteObj) {
                queryBindingsArr.push(serArr.prepareNotesInsertQuery(noteObj));
            });

            return sqliteService.multipleQueries(queryBindingsArr).then(function(result) {}, function(error) {});
        }

        serArr.prepareNotesInsertQuery = function(objNotes) {
            if(objNotes.DeviceObjID == 'null' || objNotes.DeviceObjID == null){
                    var notesConcatenatedQuery = "INSERT INTO Notes (DeviceObjID, EntityID, ModuleID, NoteID, ParentDeviceObjID, Description, ContactObjID, CreatorID, CreatorName, CreatedOn, CreatedAt, RepresentativeID, RepresentativeObjID, LoggedInUserID)" +
                "SELECT '" + objNotes.DeviceObjID + "'," + objNotes.EntityID + "," + objNotes.ModuleID + "," + objNotes.NoteID + ",'" + objNotes.ParentDeviceObjID + "','" + objNotes.Description + "','" + objNotes.ContactObjID + "'," +
                    objNotes.CreatorID + ",'" + objNotes.CreatorName + "','" + objNotes.CreatedOn + "','" + objNotes.CreatedAt + "'," + objNotes.RepresentativeID + ",'" + objNotes.RepresentativeObjID + "'," + $rootScope.loggedInUserID +
                " WHERE NOT EXISTS (SELECT 1 FROM Notes WHERE NoteID =" + objNotes.NoteID + ")";
            }else{
                var notesConcatenatedQuery = "INSERT INTO Notes (DeviceObjID, EntityID, ModuleID, NoteID, ParentDeviceObjID, Description, ContactObjID, CreatorID, CreatorName, CreatedOn, CreatedAt, RepresentativeID, RepresentativeObjID, LoggedInUserID)" +
                "SELECT '" + objNotes.DeviceObjID + "'," + objNotes.EntityID + "," + objNotes.ModuleID + "," + objNotes.NoteID + ",'" + objNotes.ParentDeviceObjID + "','" + objNotes.Description + "','" + objNotes.ContactObjID + "'," +
                    objNotes.CreatorID + ",'" + objNotes.CreatorName + "','" + objNotes.CreatedOn + "','" + objNotes.CreatedAt + "'," + objNotes.RepresentativeID + ",'" + objNotes.RepresentativeObjID + "'," + $rootScope.loggedInUserID +
                " WHERE NOT EXISTS (SELECT 1 FROM Notes WHERE DeviceObjID ='" + objNotes.DeviceObjID + "' )";
            }
            


            // var queryVal = "('" + objNotes.DeviceObjID + "'," + objNotes.EntityID + "," + objNotes.ModuleID + "," + objNotes.NoteID + ",'" + objNotes.ParentDeviceObjID + "','" + objNotes.Description + "','" + objNotes.ContactObjID + "'," +
            //     objNotes.CreatorID + ",'" + objNotes.CreatorName + "','" + objNotes.CreatedOn + "','" + objNotes.CreatedAt + "'," + objNotes.RepresentativeID + ",'" + objNotes.RepresentativeObjID + "'," + $rootScope.loggedInUserID + ")";

            // var notesConcatenatedQuery = "INSERT INTO Notes (DeviceObjID, EntityID, ModuleID, NoteID, ParentDeviceObjID, Description, ContactObjID, CreatorID, CreatorName, CreatedOn, CreatedAt, RepresentativeID, RepresentativeObjID, LoggedInUserID) VALUES" + queryVal;

            return  {'Query':notesConcatenatedQuery,'Bindings':''};
        };

        serArr.updateNotesQuery = function(objUpdateNote) {
            return sqliteService.query("UPDATE Notes SET NoteID = " + objUpdateNote.Data.NoteID +
                " WHERE DeviceObjID ='" + objUpdateNote.Data.DeviceObjID + "'").then(function(result) {
                return result;
            });
        };

        return serArr;
    }

})();
