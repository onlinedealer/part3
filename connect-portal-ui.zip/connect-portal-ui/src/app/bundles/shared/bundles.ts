export enum BUNDLE_STATUS {
  ERROR = 'ERROR',
  STOPPED = 'STOPPED',
  QUEUED = 'QUEUED',
  IN_PROGRESS = 'IN_PROGRESS',
  COMPLETED = 'COMPLETED'
}

export interface Bundle {
  projectId?: string;
  projectName?: string;
  agentId?: string;
  agentName?: string;
  author?: string;
  bundleName?: string;
  description?: string;
  location?: string;
  processName?: string;
  createdDate?: string;
  status?: string;
  details?: string;
  size?: number;
  id?: string;
  tenantId?: string;
  sizeFormatted?: string;
  logMetadataList?: LogMetadataList;
}

export interface LogFileMetadata {
  agentName: string;
  bundleLocation: string;
  logMetadataList: LogMetadataList;
  projectName: string;
}

export interface LogMetadataList {
  hubMetadataList: MetadataList[];
  serverMetadataList: ServerMetadataList[];
}

export interface MetadataList {
  metadataList: MetadataDetails[];
}

export interface MetadataDetails {
  directory: string;
  fileType: string;
  metadataDetailsList: MetadataDetailsList[];
  totalSize: number;
}

export interface MetadataDetailsList {
  fileName: string;
  fileSize: number;
  status?: string;
  result?: string;
}

export interface ServerMetadataList {
  server: ServerMetadataDetails;
  metadataList: MetadataDetails[];
}

export interface ServerMetadataDetails {
  altIP: string;
  host: string;
  name: string;
  type: string;
  useSSLA: boolean;
  useSSLE: boolean;
  port?: number;
}
