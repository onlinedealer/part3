import { Injectable, Optional, LOCALE_ID, Inject } from "@angular/core";
import { HeaderHelpMenuProvider, HeaderHelpMenuItem } from "../modules/header/common/header-help-menu-provider";
import { Observable, of } from "rxjs";
import { TranslationsService } from "./translations-service";
import { SorterService } from "../../Shared/services/sorter.service";
import { MatDialog } from "@angular/material/dialog";
import { AboutApplicationComponent } from "../modules/header/dialog-components/about-application/about-application.component";
import { VersionNumberService } from "../../Shared/services/version-number.service";

enum HeaderMenuItemId {
    About = "about",
    Help = "help"
}

@Injectable({
    providedIn: "root"
})
export class ApplicationHeaderMenuProviderService extends HeaderHelpMenuProvider {
    latestVersionNumber = "";
    menuItems: HeaderHelpMenuItem[] = [
        {
            id: HeaderMenuItemId.Help,
            name: $localize`:|@@appHeaderMenu.help:Help`
        },
        {
            id: HeaderMenuItemId.About,
            name: $localize`:|@@appHeaderMenu.about:About`
        }
    ];

    constructor(
        private translations: TranslationsService,
        private sorterService: SorterService,
        private matDialog: MatDialog,
        private versionNumberService: VersionNumberService,
        @Optional() @Inject(LOCALE_ID) private localeId: string
    ) {
        super();
        this.localeId = this.localeId || "en";
        this.versionNumberService.getVersionNumber().subscribe((versionNumber) => {
            this.latestVersionNumber = versionNumber;
        });
    }

    getMenuItems(): Observable<HeaderHelpMenuItem[]> {
        return of(this.menuItems); // of(this.sorterService.sortByName(this.menuItems, false, "desc"));
    }
    menuItemClicked(id: string): void {
        switch (id) {
            case HeaderMenuItemId.About:
                this.matDialog.open(AboutApplicationComponent, {
                    width: "600px",
                    disableClose: true,
                    data: {
                        applicationTitle: "AIM",
                        versionNumber: this.latestVersionNumber
                    }
                });
                return;
            case HeaderMenuItemId.Help:
                window.open(`manual/${this.localeId}/index.html`, "_blank");
                return;
        }
    }
}
