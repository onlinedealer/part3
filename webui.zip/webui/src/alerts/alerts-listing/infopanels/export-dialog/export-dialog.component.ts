import { Component, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { AlertService } from 'alerts/alert.service';
import { ExportDialogModel } from 'alerts/export-dialog.model';
import { ReportStatusModel } from 'alerts/report-status.model';
import { EventBusService } from 'core/eventBusService';
import { Helper } from 'discovery-shared';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';

@Component({
  selector: 'discovery-export-dialog',
  templateUrl: './export-dialog.component.html',
  styleUrls: ['./export-dialog.component.css']
})
export class ExportDialogComponent implements OnInit {
  dateRange: string;
  constructor(
    public dialogRef: DynamicDialogRef,
    public config: DynamicDialogConfig,
    private translocoService: TranslocoService,
    private alertService: AlertService,
    private eventBusService: EventBusService
  ) {}

  ngOnInit(): void {
    this.dateRange = 'all';
  }

  cancelExport() {
    this.dialogRef.close();
  }

  submitExport() {
    let alertId = this.config.data.alertId;
    let assetName = this.config.data.assetName;
    const fromDate = Helper.getFromDate(this.dateRange, this.config.data?.toDate);
    const exportPayload: ExportDialogModel = {
      alertId: alertId,
      fromDate: fromDate,
      toDate: this.config.data?.toDate
    };
    this.alertService.reportGenerationRequest(exportPayload).subscribe({
      next: (data: ReportStatusModel) => {
        this.eventBusService.emit('DOBReportingJob', {
          jobId: data?.jobId,
          assetName: assetName
        });
      }
    });
    this.dialogRef.close();
  }
}
