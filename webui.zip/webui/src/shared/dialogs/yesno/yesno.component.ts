﻿import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

/**
 * @internal
 */
@Component({
  selector: 'discovery-yesno',
  templateUrl: './yesno.component.html'
})
export class YesnoComponent {
  title: string;

  titleParams?: Record<string, string>;
  message: string;

  messageParams?: Record<string, string>;

  constructor(public activeModal: NgbActiveModal) {}
}
