import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber } from "lodash";
import { MeterConnectionVO } from "../../models/view-objects/meterconnection-vo.model";

export class MeterConnectionsSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" }> = new BehaviorSubject({
        active: "validUntil",
        direction: "desc"
    } as any);

    meterConnections: MeterConnectionVO[] = [];

    public setMeterConnections(meterConnections: MeterConnectionVO[]) {
        this.meterConnections = meterConnections;
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedMeterConnections(): Observable<MeterConnectionVO[]> {
        return this.sortingSubject.asObservable().pipe(map(() => [...this.meterConnections].sort(this.meterConnectionComparator)));
    }

    public onSortEvent(event: { active: string; direction: "asc" | "desc" }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    meterConnectionComparator = (m1: MeterConnectionVO, m2: MeterConnectionVO): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "meterType":
                return m1.meterType > m2.meterType ? directionMultiplier : -1 * directionMultiplier;
            case "meterSerialNumber":
                return this.sortByString(m1.meterSerialNumber, m2.meterSerialNumber, directionMultiplier);
            case "connectionType":
                return m1.connectionType > m2.connectionType ? directionMultiplier : -1 * directionMultiplier;
            case "configuration":
                return this.sortByConfiguration(m1, m2, directionMultiplier);
            case "validFrom":
                return m1.validFrom > m2.validFrom ? directionMultiplier : -1 * directionMultiplier;
            case "validUntil":
                return this.sortByValidUntilBeforeValidFrom(m1, m2, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByString(value1: string | null, value2: string | null, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }

        return directionMultiplier;
    }

    sortByConfiguration(m1: MeterConnectionVO, m2: MeterConnectionVO, directionMultiplier: number) {
        if (isNil(m1.configuration) && isNil(m2.configuration)) {
            return m1.validFrom > m2.validFrom ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(m1.configuration)) {
            return directionMultiplier;
        }

        if (isNil(m2.configuration)) {
            return -1 * directionMultiplier;
        }

        const configuration1 = m1.configuration.name + m1.configuration.description;
        const configuration2 = m2.configuration.name + m2.configuration.description;

        return configuration1 > configuration2 ? directionMultiplier : -1 * directionMultiplier;
    }

    sortByValidUntilBeforeValidFrom(m1: MeterConnectionVO, m2: MeterConnectionVO, directionMultiplier: number) {
        if (isNumber(m1.validUntil) && isNumber(m2.validUntil)) {
            return m1.validUntil > m2.validUntil ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(m1.validUntil) && isNil(m2.validUntil)) {
            return m1.validFrom > m2.validFrom ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(m1.validUntil)) {
            return directionMultiplier;
        }

        if (isNil(m2.validUntil)) {
            return -1 * directionMultiplier;
        }

        return 0;
    }
}
