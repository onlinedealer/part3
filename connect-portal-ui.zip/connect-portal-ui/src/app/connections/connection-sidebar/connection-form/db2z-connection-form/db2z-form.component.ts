import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { AfterContentInit, AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { environment } from '../../../../../environments/environment';
import { Connection } from '../../../shared/connection';
import { ConnectionFormValidators } from '../shared/connection-form-validators';
import { BaseConnectionForm } from '../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../base-connection-form/base-connection-form.component';
import { Server } from '../../../../servers/shared/server';
import { ConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component';
import { SidebarContext, SidebarManagerService } from '@precisely/prism-ng/sidebar-manager';
import { ErrorMessage } from '@precisely/prism-ng/cloud';

/**
 * DB2 ZOS connection parameters
 */
export enum DB2ZOS_CONNECTION_PARAMETERS {
  DB2Z_DATABASE_NAME = 'DB2Z_DATABASE_NAME',
  DB2Z_PORT_NUMBER = 'DB2Z_PORT_NUMBER',
  DB2Z_CAPTURE_SERVER = 'DB2Z_CAPTURE_SERVER',
  DB2Z_CAPTURE_PORT = 'DB2Z_CAPTURE_PORT',
  DB2Z_CAPTURE_PRIVATE_KEY = 'DB2Z_CAPTURE_PRIVATE_KEY',
  DB2Z_CAPTURE_AGENT = 'DB2Z_CAPTURE_AGENT',
  DB2Z_JCL_INFO_JOB_CARD = 'DB2Z_JCL_INFO_JOB_CARD',
  DB2Z_JCL_INFO_JOB_LIB = 'DB2Z_JCL_INFO_JOB_LIB',
  DB2Z_JCL_INFO_ISPF_LIB = 'DB2Z_JCL_INFO_ISPF_LIB'
}

/**
 * DB2z connection form
 */
@Component({
  selector: 'p-connect-db2z-form',
  templateUrl: './db2z-form.component.html'
})
export class Db2zFormComponent
  extends BaseConnectionFormComponent
  implements OnInit, OnDestroy, AfterViewInit, AfterContentInit, BaseConnectionForm
{
  /**
   * Selected Runtime Server
   */
  @Input() selectedRuntimeServer: Server;

  /**
   * Reference to the credentials child component
   */
  @ViewChild(ConnectionCredentialsFormComponent) credentialsComponent: ConnectionCredentialsFormComponent;

  /**
   * form group
   */
  db2zConnectionForm: FormGroup;

  subscriptions: Subscription[] = [];
  db2Agents: { label: string; value: string }[] = [];
  db2AgentTextValue: string;
  db2GetAgentStatusMessageInfo: string;
  db2GetAgentStatusIconPng: string[];
  agentHttpErrorResponse: HttpErrorResponse;

  constructor(
    private readonly controlContainer: ControlContainer,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly http: HttpClient,
    private readonly sidebarManagerService: SidebarManagerService
  ) {
    super();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
    this.removeChildFormControls(this.db2zConnectionForm);
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.createForm();
  }

  ngAfterContentInit(): void {
    this.subscriptions.push(
      this.db2zConnectionForm.get('db2CaptureServer').valueChanges.subscribe(() => {
        if (this.db2zConnectionForm.get('db2CaptureServer').value === '') {
          this.db2zConnectionForm.get('selectedDb2Agent').disable();
        } else {
          this.db2zConnectionForm.get('selectedDb2Agent').enable();
        }
        this.updateAgentsDropdownList();
      }),
      this.db2zConnectionForm.get('db2CaptureServerPort').valueChanges.subscribe(() => {
        this.updateAgentsDropdownList();
      }),
      this.db2zConnectionForm.get('db2CapturePrivateKeyPath').valueChanges.subscribe(() => {
        this.updateAgentsDropdownList();
      })
    );
  }

  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): Connection {
    const connection = this.credentialsComponent.getConnection(isTesting); // only populates the user & password properties
    connection.database = this.db2zConnectionForm.get('database').value;
    connection.parameters = [
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_DATABASE_NAME,
        value: this.db2zConnectionForm.get('db2DatabaseName').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_PORT_NUMBER,
        value: this.db2zConnectionForm.get('db2DatabasePort').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_SERVER,
        value: this.db2zConnectionForm.get('db2CaptureServer').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_PORT,
        value: this.db2zConnectionForm.get('db2CaptureServerPort').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_PRIVATE_KEY,
        value: this.db2zConnectionForm.get('db2CapturePrivateKeyPath').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_AGENT,
        value: this.db2zConnectionForm.get('db2Agent').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_JOB_CARD,
        value: this.db2zConnectionForm.get('db2JCLJobCard').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_JOB_LIB,
        value: this.db2zConnectionForm.get('db2JCLJobLibrary').value
      },
      {
        key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_ISPF_LIB,
        value: this.db2zConnectionForm.get('db2JCLISPFLibrary').value
      }
    ];
    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   */
  set connection(connection: Connection) {
    this.db2zConnectionForm.patchValue({
      database: connection.database,
      db2DatabaseName: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_DATABASE_NAME),
      db2DatabasePort: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_PORT_NUMBER),
      db2CaptureServer: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_SERVER),
      db2CaptureServerPort: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_PORT),
      db2CapturePrivateKeyPath: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_PRIVATE_KEY),
      db2Agent: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_AGENT),
      db2JCLJobCard: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_JOB_CARD),
      db2JCLJobLibrary: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_JOB_LIB),
      db2JCLISPFLibrary: this.getParameterValue(connection.parameters, DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_ISPF_LIB)
    });
    this.credentialsComponent.connection = connection;
  }

  createForm(): void {
    this.db2zConnectionForm = this.controlContainer.control as FormGroup;
    this.db2zConnectionForm.addControl(
      'database',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.db2zConnectionForm.addControl(
      'db2DatabaseName',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.db2zConnectionForm.addControl(
      'db2DatabasePort',
      new FormControl('448', [Validators.required, Validators.min(1), Validators.max(65535), Validators.pattern('^[0-9]*$')])
    );
    this.db2zConnectionForm.addControl(
      'db2CaptureServer',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.db2zConnectionForm.addControl(
      'db2CaptureServerPort',
      new FormControl('2626', [Validators.min(1024), Validators.max(65535), Validators.pattern('^[0-9]*$')])
    );
    this.db2zConnectionForm.addControl('db2CapturePrivateKeyPath', new FormControl(''));
    this.db2zConnectionForm.addControl(
      'db2Agent',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.db2zConnectionForm.addControl('db2JCLJobCard', new FormControl(''));
    this.db2zConnectionForm.addControl('db2JCLJobLibrary', new FormControl(''));
    this.db2zConnectionForm.addControl('db2JCLISPFLibrary', new FormControl(''));
    this.db2zConnectionForm.addControl('dbmsVersion', new FormControl('-'));
    this.db2zConnectionForm.addControl('driverVersion', new FormControl('-'));
    this.db2zConnectionForm.addControl('gmtOffset', new FormControl('-'));
    this.db2zConnectionForm.addControl('selectedDb2Agent', new FormControl({ value: '', disabled: true }));
  }

  /**
   * Calls the get agents after a period of time following a change to a form control
   */
  updateAgentsDropdownList(): void {
    if (
      this.db2zConnectionForm.get('db2Agent') &&
      this.db2zConnectionForm.get('db2CaptureServer').value !== '' &&
      this.db2zConnectionForm.get('db2CaptureServerPort').value !== '' &&
      this.selectedRuntimeServer !== ''
    ) {
      setTimeout(() => {
        this.getAgents();
      }, 800);
    }
  }

  /**
   * Updates the db2 agent form control with the selected dropdown list value
   * @param selectedItem the selected item from the dropdwon list
   */
  selectDB2AgentFromDropdown(selectedItem) {
    this.db2zConnectionForm.get('db2Agent').setValue(selectedItem);
  }

  openErrorMessageSidebar() {
    const error: ErrorMessage = {
      ...this.agentHttpErrorResponse,
      detailedMessage: this.agentHttpErrorResponse.error.detailedMessage,
      timestamp: this.agentHttpErrorResponse.error.timestamp
    };
    this.sidebarManagerService.setActiveSidebar({ id: 'error-sidebar', data: [error] } as SidebarContext);
  }

  private getURLForAgents(): string {
    const baseUrl = `${environment.connectApiBaseURL}/metadata`;
    const serverName = this.db2zConnectionForm.get('db2CaptureServer').value;
    const portNumber = this.db2zConnectionForm.get('db2CaptureServerPort').value;
    const privateKey = this.db2zConnectionForm.get('db2CapturePrivateKeyPath').value;
    const serverId = this.selectedRuntimeServer.id;

    return encodeURI(`${baseUrl}/agents?server_name=${serverName}&port=${portNumber}&private_key=${privateKey}&server_id=${serverId}`);
  }

  private setDb2AgentTextValue() {
    if (this.db2zConnectionForm.get('db2Agent') && this.db2zConnectionForm.get('db2Agent').value) {
      this.db2AgentTextValue = this.db2zConnectionForm.get('db2Agent').value;
    }
  }

  private getAgents(): void {
    this.agentHttpErrorResponse = null;
    this.db2GetAgentStatusMessageInfo = 'connections.CONNECTION_FORM.DB2ZOS.WHILE_RETRIEVINGTHE_AGENTS';
    this.db2GetAgentStatusIconPng = ['png-alert-inprogress'];
    this.db2Agents = [];
    this.http
      .get(this.getURLForAgents())
      .pipe(first())
      .subscribe({
        next: (response: string[]) => {
          if (response.length) {
            this.db2GetAgentStatusMessageInfo = '';
            this.db2GetAgentStatusIconPng = [];
            response.forEach((agent) => {
              if (!this.db2Agents.some((item) => item.value === agent)) {
                this.db2Agents.push({ label: agent, value: agent });
              }
            });
            if (this.db2zConnectionForm.get('db2Agent') && this.db2zConnectionForm.get('db2Agent').value) {
              this.db2zConnectionForm.patchValue({ selectedDb2Agent: this.db2zConnectionForm.get('db2Agent').value });
            }
          } else {
            this.db2GetAgentStatusMessageInfo = 'connections.CONNECTION_FORM.DB2ZOS.WHEN_NO_AGENTS_ARE_CONFIGURED';
            this.db2GetAgentStatusIconPng = ['png-alert-info-solid', 'text-primary'];
            this.setDb2AgentTextValue();
          }
        },
        error: (error: HttpErrorResponse) => {
          this.agentHttpErrorResponse = error;
          this.db2GetAgentStatusMessageInfo = 'connections.CONNECTION_FORM.DB2ZOS.SERVER_DOES_NOT_RESPOND_OR_EXIST';
          this.db2GetAgentStatusIconPng = ['png-alert-attention-solid', 'text-warning'];
          this.setDb2AgentTextValue();
        }
      });
  }
}
