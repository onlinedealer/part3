import { SimpleChange, SimpleChanges } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Connection } from 'src/app/connections/shared/connection';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { Project } from 'src/app/pipelines/pipeline/shared/project';

import { CreateBundleFormComponent } from './create-bundle-form.component';

describe('CreateBundleFormComponent', () => {
  let component: CreateBundleFormComponent;
  let fixture: ComponentFixture<CreateBundleFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, getTranslocoModule()],
      declarations: [CreateBundleFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateBundleFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should hide/show (kernel logs) bullet point based on if project is committed', () => {
    component.project = { id: '1' } as Project;
    expect(component.isProjectComitted).toBe(true);
    component.project = undefined;
    expect(component.isProjectComitted).toBe(false);
  });

  it('should hide/show (IBM i connections) label and (Log reader logs) bullet point based on if project uses IBMi connections', () => {
    component.listOfSourceConnectionsInProject = [{ name: 'test', connectionType: 'DB2I', accessFromServer: { id: '1' } } as Connection];
    expect(component.areIBMIConnectionsUsedInProject).toBe(true);
    component.listOfSourceConnectionsInProject = undefined;
    expect(component.areIBMIConnectionsUsedInProject).toBe(false);
  });

  it('should create a form', () => {
    component.ngOnInit();
    expect(component.createBundleForm.get('bundleName').value).toEqual('');
    expect(component.createBundleForm.get('bundleDescription').value).toEqual('');
  });

  it('should update bundle name input field value to include the bundle name and date timestamp', () => {
    const changesObj: SimpleChanges = {
      date: new SimpleChange('', '2022-07029_12-51-02', true)
    };
    component.ngOnChanges(changesObj);
    expect(component.createBundleForm.get('bundleName').value).toEqual('Diagnostic_Bundle_2022-07029_12-51-02');
  });
});
