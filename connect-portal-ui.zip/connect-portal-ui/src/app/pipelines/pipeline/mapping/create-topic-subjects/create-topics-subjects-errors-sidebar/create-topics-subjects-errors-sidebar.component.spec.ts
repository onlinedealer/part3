import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';

import { CreateTopicsSubjectsErrorsSidebarComponent } from './create-topics-subjects-errors-sidebar.component';

describe('CreateTopicsSubjectsErrorsSidebarComponent', () => {
  let component: CreateTopicsSubjectsErrorsSidebarComponent;
  let fixture: ComponentFixture<CreateTopicsSubjectsErrorsSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CreateTopicsSubjectsErrorsSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTopicsSubjectsErrorsSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.sidebarComponent = jasmine.createSpyObj<SidebarComponent>(['open', 'close']);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should trigger sidebar open method', () => {
    component.open();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should trigger sidebar close method', () => {
    component.secondaryButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });
});
