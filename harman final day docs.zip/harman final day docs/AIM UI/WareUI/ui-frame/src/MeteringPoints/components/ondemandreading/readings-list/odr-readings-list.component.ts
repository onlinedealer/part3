import { Component, Input, EventEmitter, Output, ChangeDetectionStrategy, SimpleChanges, OnChanges, AfterViewChecked } from "@angular/core";
import {
    OnDemandReading,
    OnDemandReadingRequestSelectedVO,
    OnDemandReadingRequestSelectedVODates,
    OnDemandReadingRequestType,
    OnDemandReadingService,
    OnDemandReadingVO,
    OnDemandReadingStatus
} from "../../../models/ondemandreading.model";
import { OdrTypeTranslations } from "../../../translations/odr-type.translations";
import { dateDiff } from "../../../../Shared/helpers/date.helper";
import { slideCloseOpenAnimationTrulyHide } from "../../../../Shared/Animations/slide-close-open.animation";
import { ODRTranslationsService, ODRTranslation } from "../../../translations/odrtranslations.service";
import { DateFormatService, DateFormats } from "../../../../Shared/services/date-format.service";
import * as moment from "moment";

@Component({
    selector: "landisgyr-ondemandreading-readings-list",
    templateUrl: "./odr-readings-list.component.html",
    styleUrls: ["./odr-readings-list.component.scss"],
    animations: slideCloseOpenAnimationTrulyHide(),
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OnDemandReadingReadingsListComponent implements OnChanges, AfterViewChecked {
    @Input()
    onDemandReadingServices!: OnDemandReadingService[];
    @Input()
    onDemandReadingServicesFetched!: boolean;

    @Input()
    onDemandReadingRequestsFetching!: boolean;
    @Input()
    onDemandReadingRequests!: OnDemandReadingVO[];

    @Input()
    selectedOnDemandReadingquest!: OnDemandReadingRequestSelectedVO;

    @Input()
    scheduledReadings!: OnDemandReading[];

    @Input()
    showSchedules = false;

    @Input()
    index!: number;

    @Output() selectedOnDemandReadingResult: EventEmitter<OnDemandReading> = new EventEmitter();

    @Output() clearSelection: EventEmitter<any> = new EventEmitter<any>();
    @Output() scheduledReadingsClicked = new EventEmitter<void>();

    @Output()
    linkClick = new EventEmitter<{ requestType: string; meteringId: number; from: number; until: number }>();

    resultsVisible = false;
    tableCaption!: string;
    navigateButtonTitle = "";
    multipleResults = false;
    selectedRequestType: string | undefined;
    requestTypeString: string | undefined;
    subTitle?: string;
    infoMessage = this.translations.getTranslation(ODRTranslation.NoReadings);
    scrollToId = "";
    scheduledReadingDateFormat = DateFormats.DATE;

    constructor(
        private odrTypeTranslations: OdrTypeTranslations,
        private translations: ODRTranslationsService,
        public formats: DateFormatService
    ) {}

    selectReading(entry: OnDemandReading) {
        this.selectedOnDemandReadingResult.emit(entry);
    }

    closeReading() {
        this.clearSelection.emit();
    }

    scheduledFuture(request: OnDemandReading) {
        if (request.status && request.status === OnDemandReadingStatus.Failed) {
            return false;
        }
        if (!request.status || request.status === OnDemandReadingStatus.Running) {
            return false;
        }
        return true;
    }

    scrollToScheduledReading(id: string) {
        const item = document.getElementById(id);
        if (item) {
            setTimeout(() => {
                item.scrollIntoView({ behavior: "smooth" });
            }, 200);
        }
    }

    ngAfterViewChecked() {
        if (!this.scrollToId) {
            return;
        }
        this.scrollToScheduledReading(this.scrollToId);
        this.scrollToId = "";
    }
    ngOnChanges(changes: SimpleChanges) {
        this.tableCaption = "";
        this.navigateButtonTitle = "";
        this.multipleResults = false;
        this.requestTypeString = "";
        this.resultsVisible = !!this.selectedOnDemandReadingquest;
        if (
            changes.scheduledReadings &&
            changes.scheduledReadings.currentValue &&
            changes.scheduledReadings.previousValue &&
            !changes.scheduledReadings.isFirstChange() &&
            this.showSchedules === true
        ) {
            const notInPrevious = changes.scheduledReadings.currentValue.filter(
                (scheduledReading: any) =>
                    changes.scheduledReadings.previousValue.findIndex(
                        (previous: any) => previous.requestId === scheduledReading.requestId
                    ) === -1
            );
            if (notInPrevious && notInPrevious.length > 0) {
                this.scrollToId = "scheduled-reading-" + notInPrevious[0].requestId;
            }
        }
        if (changes.selectedOnDemandReadingquest && changes.selectedOnDemandReadingquest.previousValue) {
            this.resultsVisible = !(
                changes.selectedOnDemandReadingquest.previousValue && !changes.selectedOnDemandReadingquest.currentValue
            );
        }
        if (!this.selectedOnDemandReadingquest) {
            return;
        }
        switch (this.selectedOnDemandReadingquest.requestType) {
            case OnDemandReadingRequestType.ReadEventData:
                this.navigateButtonTitle = this.translations.getTranslation(ODRTranslation.EventsView);
                break;
            case OnDemandReadingRequestType.ReadTransformerRatio:
            case OnDemandReadingRequestType.ReadInstantaneousValue:
            case OnDemandReadingRequestType.ReadPeriodicData:
            case OnDemandReadingRequestType.ReadProfileData:
                const foundTypes: string[] = [];
                for (const item of this.selectedOnDemandReadingquest.results) {
                    if (!item.name) {
                        continue;
                    }
                    const existingIndex = foundTypes.findIndex((type) => type === item.name);
                    if (existingIndex === -1 && foundTypes.length > 0) {
                        this.multipleResults = true;
                        break;
                    }
                    foundTypes.push(item.name);
                }
                this.navigateButtonTitle = this.multipleResults
                    ? this.translations.getTranslation(ODRTranslation.MeteringsView)
                    : this.translations.getTranslation(ODRTranslation.MeteringDetailsView);
                if (
                    this.selectedOnDemandReadingquest.requestType === OnDemandReadingRequestType.ReadInstantaneousValue ||
                    this.selectedOnDemandReadingquest.requestType === OnDemandReadingRequestType.ReadTransformerRatio
                ) {
                    this.navigateButtonTitle = "";
                }
                break;
            default:
                break;
        }
        let suffix: string | undefined = "";
        this.subTitle = "";
        if (this.selectedOnDemandReadingquest.requestType === OnDemandReadingRequestType.ReadProfileData) {
            suffix = this.multipleResults
                ? this.translations.getTranslation(ODRTranslation.MultipleMeterings)
                : this.selectedOnDemandReadingquest.results[0].name;
            this.subTitle = suffix || "";
            this.subTitle +=
                !this.multipleResults && this.selectedOnDemandReadingquest.results[0].measuredUnit
                    ? ` (${this.selectedOnDemandReadingquest.results[0].measuredUnit.name})`
                    : "";
        }
        this.tableCaption = this.formatTableCaptionDate(
            this.selectedOnDemandReadingquest.dates,
            this.selectedOnDemandReadingquest.requestType
        );

        this.requestTypeString = this.odrTypeTranslations.getReadingTypeTranslation(this.selectedOnDemandReadingquest.requestType);
        if (this.selectedOnDemandReadingquest.requestType.toString() === "TransformerRatio") {
            this.selectedOnDemandReadingquest.results[0].name = this.odrTypeTranslations.getReadingTypeTranslation(
                OnDemandReadingRequestType.ReadTransformerRatio
            );
        }
    }

    formatTableCaptionDate(dates: OnDemandReadingRequestSelectedVODates, requestType: string) {
        if (requestType === OnDemandReadingRequestType.ReadProfileData) {
            return this.formats.toRangeLocaleString(
                dates.requestUserDefinedStartTime,
                dates.requestUserDefinedEndTime,
                DateFormats.DATETIME_NO_SECS
            );
        }
        if (requestType === OnDemandReadingRequestType.ReadEventData) {
            return "";
        }
        if (dateDiff(dates.valueStart, dates.valueEnd, "minutes") > 0) {
            return this.formats.toRangeLocaleString(dates.valueStart, dates.valueEnd, DateFormats.DATETIME);
        }
        return this.formats.toLocaleString(dates.valueStart, DateFormats.DATETIME);
    }

    trackReadingEntryFn(index: number, item: OnDemandReading) {
        return item.requestId;
    }
}
