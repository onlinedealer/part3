import { NgModule } from '@angular/core';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SharedModule } from 'discovery-shared';
import { connectionsLoader, sharedLoader } from '../core/i18n-loaders';
import { ConnectionDetailComponent } from './connection-detail/connection-detail.component';
import { ConnectionListComponent } from './connection-list/connection-list.component';
import { ConnectionRoutingModule } from './connection-routing.module';

@NgModule({
  declarations: [ConnectionDetailComponent, ConnectionListComponent],
  imports: [SharedModule, ConnectionRoutingModule],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'discoveryConnections', loader: connectionsLoader },
        { scope: 'discoveryShared', loader: sharedLoader }
      ]
    }
  ]
})
export class ConnectionsModule {}
