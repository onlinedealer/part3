import {
    Component,
    Input,
    Output,
    EventEmitter,
    OnDestroy,
    OnChanges,
    SimpleChanges,
    ChangeDetectionStrategy,
    SimpleChange,
    ViewChild,
    ElementRef
} from "@angular/core";
import { FormControl } from "@angular/forms";
import { Subscription, Observable, BehaviorSubject, Subject } from "rxjs";
import { debounceTime } from "rxjs/operators";
import { getMeteringpointsXSFSearchFields } from "../../../containers/meteringpoints-search/meteringpoints-search-form-fields";

@Component({
    selector: "landisgyr-meteringpoints-search-main-input",
    templateUrl: "./mp-search-main-input.component.html",
    styleUrls: ["./mp-search-main-input.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringpointsSearchMainInputComponent implements OnChanges, OnDestroy {
    @Input()
    searchResultsCriteriaInformation!: any;

    @Input()
    placeholderText!: string;

    @Input()
    defaultSearchField!: string;

    @Input()
    defaultSearchFieldLabel!: string;

    @Input()
    mainInputValueInStore!: string;

    @Input()
    xsfSearchOverlayIsShown!: boolean;

    @Output()
    mainInputValue: EventEmitter<string> = new EventEmitter();

    @Output()
    clearXSFSearch: EventEmitter<string> = new EventEmitter();

    @Output()
    openXSFSearchOverlay: EventEmitter<string> = new EventEmitter();

    @ViewChild("input") input!: ElementRef<HTMLElement>;

    inputHasFocus = false;
    mainInputType$: Subject<string> = new BehaviorSubject("text");

    mainInputFormControl: FormControl = new FormControl("");

    ellipsisPresent = false;

    private mainInputValueChanges$: Observable<any> = this.mainInputFormControl.valueChanges.pipe(debounceTime(400));

    private mainInputChangeSubscription: Subscription = this.mainInputValueChanges$.subscribe((value) => {
        if (this.inputHasFocus) {
            this.mainInputValue.emit(value ? value.trim() : "");
        }
    });

    constructor(public elementRef: ElementRef) {}

    checkEllipsis(value: any) {
        if (value.length >= 40) {
            this.ellipsisPresent = true;
        } else {
            this.ellipsisPresent = false;
        }
    }

    onsearch(Searchvalue: any) {
        this.mainInputFormControl.setValue(Searchvalue);
    }
    clearSearch(): void {
        this.mainInputFormControl.setValue("");
        this.clearXSFSearch.emit("");
    }

    ngOnChanges(changes: SimpleChanges) {
        this.updateMainInputValueIfChangedAndFieldIsNotFocused(changes.mainInputValueInStore);
        this.updateMainInputTypeIfDefaultFieldHasChanged(changes.defaultSearchField);
    }

    ngOnDestroy() {
        if (this.mainInputChangeSubscription) {
            this.mainInputChangeSubscription.unsubscribe();
        }
    }

    hasSearchCriteriaInformation(): boolean {
        return this.searchResultsCriteriaInformation !== undefined;
    }

    private updateMainInputValueIfChangedAndFieldIsNotFocused(mainInputValueChange: SimpleChange) {
        if (mainInputValueChange === undefined) {
            return;
        }

        if (mainInputValueChange.firstChange && mainInputValueChange.currentValue && mainInputValueChange.currentValue.length > 0) {
            this.mainInputFormControl.setValue(mainInputValueChange.currentValue);
        }

        if (this.inputHasFocus === false && mainInputValueChange.currentValue !== mainInputValueChange.previousValue) {
            this.mainInputFormControl.setValue(mainInputValueChange.currentValue);
        }
    }

    focusToInput() {
        this.input.nativeElement.focus();
    }

    private updateMainInputTypeIfDefaultFieldHasChanged(defaultSearchFieldChange: SimpleChange) {
        if (defaultSearchFieldChange === undefined || defaultSearchFieldChange.firstChange) {
            return;
        }

        if (this.inputHasFocus === false && defaultSearchFieldChange.currentValue !== defaultSearchFieldChange.previousValue) {
            const searchFieldKey = defaultSearchFieldChange.currentValue;
            const searchFieldInformation = getMeteringpointsXSFSearchFields().find((field) => field.key === searchFieldKey);

            if (searchFieldInformation) {
                const type = searchFieldInformation.type;
                this.mainInputType$.next(type);
            }
        }
    }

    hasMainInputValue(): boolean {
        return this.mainInputFormControl.value && this.mainInputFormControl.value.length > 0;
    }
}
