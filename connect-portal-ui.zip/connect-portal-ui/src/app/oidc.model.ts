export class OIDC {
  static CLIENT_ID = 'OIDC-Connect';
}
