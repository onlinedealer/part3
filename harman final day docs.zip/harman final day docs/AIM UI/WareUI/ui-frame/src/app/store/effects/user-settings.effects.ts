import { Inject, Injectable } from "@angular/core";
import { Actions, ofType, createEffect } from "@ngrx/effects";
import { Store } from "@ngrx/store";
import { State } from "../reducers";
import { of } from "rxjs";
import { map, switchMap, catchError, withLatestFrom, delay, mergeMap, tap } from "rxjs/operators";
import { isEmpty } from "lodash";

import { UserSettingsService } from "../../services/user-settings.service";
import { UserSettingsActions, SecurityActions, ConfigurationsActions, RouterActions } from "../actions";
import { ConfigurationsSelectors, RouterSelectors, SecuritySelectors, UserSettingsSelectors } from "../selectors";
import { ChangeUiConfigurationSettingsPayload } from "../actions/configurations.actions";
import { XSFSearchActions } from "../../../MeteringPoints/store/actions";
import { LandisGyrAimConfigurationModel } from "../../../Shared/models/date-configuration.model";
import { TimeZoneService } from "../../../Shared/services/time-zone.service";

@Injectable()
export class UserSettingsEffects {
    constructor(
        private actions$: Actions,
        private userSettingsService: UserSettingsService,
        private timeZoneService: TimeZoneService,
        private store: Store<State>,
        @Inject(LandisGyrAimConfigurationModel) private config: LandisGyrAimConfigurationModel
    ) {}

    GetUserSettingsConfiguration$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetUserSettingsConfiguration),
            mergeMap(() => {
                return [UserSettingsActions.GetUserSettings(), UserSettingsActions.GetMeteringPointsSearchSettings()];
            })
        )
    );

    GetUserSettings$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetUserSettings),
            switchMap(() => {
                return this.userSettingsService.getUserSetting().pipe(
                    map((userSettings) => UserSettingsActions.GetUserSettingsSuccess({ userSettings })),
                    catchError((error) => of(UserSettingsActions.GetUserSettingsFail({ error: error.error })))
                );
            })
        )
    );

    GetMeteringPointSearchSettings$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetMeteringPointsSearchSettings),
            switchMap(() => {
                return this.userSettingsService.getDefaultMeteringPointSearchSetting().pipe(
                    map((mpSearchSettings) =>
                        UserSettingsActions.GetMeteringPointsSearchSettingsSuccess({ mpSearchSettings: mpSearchSettings })
                    ),
                    catchError((error) => of(UserSettingsActions.GetMeteringPointsSearchSettingsFail({ error: error })))
                );
            })
        )
    );

    setValuesForDefaultSearchSetting$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetMeteringPointsSearchSettingsSuccess),
            map((action) => {
                if (action.mpSearchSettings && action.mpSearchSettings.length > 0) {
                    const searchKeyWord = action.mpSearchSettings[0] ? action.mpSearchSettings[0] : "";
                    if (searchKeyWord.setting) {
                        const data = JSON.parse(searchKeyWord.setting);
                        sessionStorage.setItem("currentXSFDefault", JSON.stringify(data.meteringPoints.defaultSearchField));
                    }
                }
                return XSFSearchActions.CheckXSFSearchUserSettings();
            })
        )
    );

    UpdateUserSettings$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.UpdateUserSettings),
            map((action) => action.userSettings),
            switchMap((userSettings) => {
                return this.userSettingsService.updateUserSetting(userSettings).pipe(
                    map((response) => UserSettingsActions.UpdateUserSettingsSuccess({ userSettings })),
                    catchError((error) => of(UserSettingsActions.UpdateUserSettingsFail({ error: error })))
                );
            })
        )
    );

    UpdateDefaultMeteringPointSearchSettings$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.UpdateMeteringPointsSearchSettings),
            map((action) => action.mpSearchSettings),
            switchMap((userSettings) => {
                return this.userSettingsService.updateDefaultMeteringPointSearchSetting(userSettings).pipe(
                    map((response) => UserSettingsActions.UpdateMeteringPointsSearchSettingsSuccess({ mpSearchSettings: userSettings })),
                    catchError((error) => of(UserSettingsActions.UpdateUserSettingsFail({ error: error })))
                );
            })
        )
    );

    GetUserSettingsAfterSession$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.UpdateSessionSuccess),
            delay(400),
            map(() => UserSettingsActions.GetUserSettings())
        )
    );

    UpdateUserSettingsAfterSettingMeteringPointSearchSettings$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.SetMeteringPointsSearchSettings),
            withLatestFrom(this.store.select(UserSettingsSelectors.getUserSettings)),
            map(([action, userSettings]) =>
                UserSettingsActions.UpdateMeteringPointsSearchSettings({ mpSearchSettings: userSettings.searchSettings })
            )
        )
    );

    updateUserProfileSettings$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.SetUserProfileSetting),
            withLatestFrom(this.store.select(ConfigurationsSelectors.getUIConfiguration)),
            map(([newSettings, configuration]) => {
                const changedUserConfig = {
                    systemLocale: newSettings.systemLocale,
                    userLocale: newSettings.userLocale,
                    dateFormat: { separator: newSettings.dateFormat.separator, format: newSettings.dateFormat.format },
                    timeFormat: newSettings.timeFormat,
                    hours: newSettings.hours,
                    timeZoneInUse: newSettings.timeZoneInUse
                };
                return UserSettingsActions.UpdateUserSettings({ userSettings: changedUserConfig });
            })
        )
    );

    onGetUserSuccessOrFail$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetUserSettingsSuccess, UserSettingsActions.GetUserSettingsFail),
            withLatestFrom(
                this.store.select(UserSettingsSelectors.getUserProfileSettings),
                this.store.select(SecuritySelectors.getUserTimeZone)
            ),
            map(([action, userProfile, userSecurityTimeZone]) => {
                const userProfileSetting = {
                    ...userProfile,
                    timeZoneInUse: userProfile.timeZoneInUse || userSecurityTimeZone || this.timeZoneService.getLocalTimeZoneName()
                } as ChangeUiConfigurationSettingsPayload;

                // In case if the userProfileSetting API is empty or user setting API failed to fetch information
                // then the below default configuration will be set to UI
                const defaultConfigSettings = {
                    systemLocale: this.config.systemLocale,
                    userLocale: this.config.systemLocale,
                    dateFormat: { separator: this.config.dateFormat.separator, format: this.config.dateFormat.format },
                    timeFormat: this.config.timeFormat,
                    hours: this.config.hours,
                    timeZoneInUse: userSecurityTimeZone || this.timeZoneService.getLocalTimeZoneName()
                } as ChangeUiConfigurationSettingsPayload;

                if (!isEmpty(userProfile) && !isEmpty(userProfileSetting)) {
                    return ConfigurationsActions.ChangeUiConfigurationSettings(userProfileSetting);
                } else {
                    // In case if the user dont have any settings returning from the userSetting API
                    return ConfigurationsActions.ChangeUiConfigurationSettings(defaultConfigSettings);
                }
            })
        )
    );

    LoadConfigurationOnGetUserSuccess$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetUserSettingsSuccess),
            delay(500),
            map(() => ConfigurationsActions.LoadWindowDefinedConfiguration())
        )
    );

    // this effect to retain the view when the user settings are being changed
    onPageRefreshSetToCurrentURL$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetUserSettingsSuccess),
            map(() => {
                return localStorage.getItem("current_url");
            }),
            map((url) => {
                localStorage.removeItem("current_url");
                if (url) {
                    return RouterActions.Navigate({
                        commands: [url]
                    });
                }
                return RouterActions.NoOperation();
            })
        )
    );

    storeCurrentURLToLocalStorage$ = createEffect(
        () =>
            this.actions$.pipe(
                ofType(UserSettingsActions.SetUserProfileSetting),
                withLatestFrom(this.store.select(RouterSelectors.getURL)),
                map(([action, url]) => {
                    return url;
                }),
                tap((url: any) => {
                    if (url) {
                        localStorage.setItem("current_url", url);
                    }
                    return RouterActions.NoOperation();
                })
            ),
        { dispatch: false }
    );
}
