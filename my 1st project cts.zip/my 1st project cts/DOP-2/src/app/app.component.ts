import { Component, OnInit, OnChanges, SimpleChange, HostListener, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { ScrollToStartService } from './shared/utility/scroll-to-start.service';
import { Subscription } from 'rxjs/Subscription';
import { InterceptorEmitter } from './shared/interceptor/interceptor-emitter.service';
import { LoaderComponent } from './loader/loader.component';
import { ScriptLoaderService } from './shared/utility/script-loader.service';
import { UtagService } from 'utag-module';
import { recognize } from '@angular/router/src/recognize';
import { RouteConfigurations } from './shared/utility/club-constants.service';
import { AjaxUtilityService } from './shared/utility/ajax-utility.service';
import { CookieUtilityService } from './shared/utility/cookie-utility.service';
import { HttpResponse, HttpParams } from '@angular/common/http';
import { setTimeout } from 'timers';
import { SEOService } from './shared/utility/seo.service';
import { Meta } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})


export class AppComponent implements OnInit, AfterViewInit {
  loadAPI: Promise<any>;
  title = 'CVS club component';
  subscription: Subscription;
  showLoader = false;
  headerServiceData;
  navigatedUrl: string;
  isApp: boolean;
  constructor(
    private _scroller: ScrollToStartService,
    public _router: Router,
    private _interceptorEmitter: InterceptorEmitter,
    private _scriptLoader: ScriptLoaderService,
    private _utag: UtagService,
    private _ajaxUtility: AjaxUtilityService,
    private _cookieService: CookieUtilityService,
    private _seo: SEOService,
    private _meta: Meta,
    private _cd: ChangeDetectorRef
  ) {
    // _meta.addTag({ name: 'robots', content: 'noindex' });    
    this.loadAPI = new Promise((resolve) => {
      let scriptArr = [
        'https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js',
        'https://request.eprotect.vantivcnp.com/eProtect/js/eProtect-iframe-client3.min.js',
        'https://request.eprotect.vantivcnp.com/eProtect/litle-api3.js'
      ];
      if (-1 !== window.location.href.indexOf('m.cvs.com') || -1 !== window.location.href.indexOf('www.cvs.com')) {
        scriptArr = [
          'https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js',
          'https://request.eprotect.vantivcnp.com/eProtect/js/eProtect-iframe-client3.min.js',
          'https://request.eprotect.vantivcnp.com/eProtect/litle-api3.js'
        ];
      } else {
        scriptArr = [
          'https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js',
          'https://request.eprotect.vantivprelive.com/eProtect/js/eProtect-iframe-client3.min.js',
          'https://request.eprotect.vantivprelive.com/eProtect/litle-api3.js'
        ];
      }
      this._scriptLoader.loadScript(scriptArr);
      resolve(true);
  });
  this.addCanonicalLinks();
}


  onHeaderServiceCall(obj) {
    this.headerServiceData = obj;
    const path = ['carepass'];
    this._router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        path.push(event.urlAfterRedirects.split('/')[1]);
      }
    });
    const pathInfo = {
      'breadcrumb': ['home', 'carepass'],
      'url': path
    };
    obj['page_category'] = 'carepass';

    this._utag.save_data(pathInfo);
    this._utag.save_header_data(obj);
    /* This code has been placed to check whether the zip look up is enabled or not
      and then doing the redirection for the same */

    /* Check first if the user is hitting carepass itself. In that case if feature is available then
       check if look up alreadt done or not. In both cases redirect user to dashboard itself from
       there it will be redirected to FAQ if user not enrolled. */
    if (this._router.url === '/' + RouteConfigurations.carepassLookUp) {
      if (!this.headerServiceData['response']['header']['performCarePassZipCodeCheck']) {
        this._router.navigate(['/' + RouteConfigurations.clubDashboard]);
      } else {
        if (sessionStorage.getItem('carepassLookUpDone') == null) {
          this._router.navigate(['/' + RouteConfigurations.carepassLookUp]);
        } else {
          this._router.navigate(['/' + RouteConfigurations.clubDashboard]);
        }
      }
    } else {
      /* If user is hitting other URL's check if feature is available or not and then whether
look up already done or not. based on these two values user is redirected to look up
or user stays in the same page */

      if (window.location.href.indexOf(RouteConfigurations.profileCompletion) === -1
        && window.location.href.indexOf(RouteConfigurations.clubBenefits) === -1) {
        if (this._cookieService.exists('SCC_COOKIE')) {
          if (sessionStorage.getItem('carepassLookUpDone') == null) {
            // call digitalProfileService to check enrolment status and further redirect to dashboard
            if (this.headerServiceData['response'].hasOwnProperty('header')
              && this.headerServiceData['response']['header'].hasOwnProperty('carePassEnrollmentStatus')
              && (
                'ENROLLED' === this.headerServiceData['response']['header']['carePassEnrollmentStatus']
                || 'CANCEL_INITIATED' === this.headerServiceData['response']['header']['carePassEnrollmentStatus']
              )) {
              if (
                -1 === window.location.href.indexOf(RouteConfigurations.clubOrderConfirmation)
                && -1 === window.location.href.indexOf(RouteConfigurations.clubDashboard)
                && -1 === window.location.href.indexOf(RouteConfigurations.clubBenefits)
                && -1 === window.location.href.indexOf(RouteConfigurations.carepassSelfUnenroll)
                && -1 === window.location.href.indexOf(RouteConfigurations.clubPaymentBillingDetails)
              ) {
                this._router.navigate(['/dashboard']);
              }
            } else {
              this.carepassLookUpRedirection();
            }
          }
        } else {
          this.carepassLookUpRedirection();
        }
      }
    }
  }

  carepassLookUpRedirection() {
    if (this.headerServiceData['response']['header']['performCarePassZipCodeCheck']) {
      if (sessionStorage.getItem('carepassLookUpDone') == null) {
        this._router.navigate(['/' + RouteConfigurations.carepassLookUp]);
      }
    }
  }

  ngOnInit() {

    /**
     * Code piece to detect if wrapper is app or not - start
     */

    try {
      this.isApp = (<any>window).native ? true : false;
    } catch (error) {
      this.isApp = false;
      console.error(error);
    }

     /**
      * Code piece to detect if wrapper is app or not - end
      */
    const path = ['carepass'];
    this._router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        path.push(event.urlAfterRedirects.split('/')[1]);
        this.navigatedUrl = event.urlAfterRedirects.split('/')[1];
      }
    });
    this.subscription = this._interceptorEmitter.counter$
    .subscribe(counter => {
      this.showLoader = counter > 0;
      // setTimeout(() => this.showLoader = counter > 0, 0);
    });
    this._scroller.scrollToStart();
  }

  ngAfterViewInit() {
    this._cd.detectChanges();
  }

  /**
   * function call to make to add canonical links
   */

   addCanonicalLinks() {
    const isProd = (-1 !== window.location.href.indexOf('m.cvs.com') || -1 !== window.location.href.indexOf('www.cvs.com'));
    this._router.events.subscribe((event) => {
      if (event instanceof NavigationEnd) {
        this._seo.removeCanonicalLink();
        if(('/' + RouteConfigurations.clubBenefits) === event.urlAfterRedirects) {
          this._seo.addTag( { rel: 'canonical', href: 'http://' + window.location.host + '/carepass' } );
          this._seo.addTag( { rel: 'canonical', href: window.location.host + '/CarePass' } );
          this._seo.addTag( { rel: 'canonical', href: 'https://' + (window.location.href.indexOf('www') ? window.location.host.replace('www','m') : window.location.host) + '/carepass' } );
          this._seo.addTag( { rel: 'canonical', href: 'https://' + (window.location.href.indexOf('www') ? window.location.host.replace('www','m') : window.location.host) + '/carepass/join' } );
        } else {
          this._seo.addTag( { rel: 'canonical', href: 'https://' + (window.location.href.indexOf('www') ? window.location.host.replace('www','m') : window.location.host) + window.location.pathname } );          
        }       
      }
    });
   }
}
