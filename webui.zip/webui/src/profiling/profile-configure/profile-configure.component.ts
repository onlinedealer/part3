import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoService } from '@ngneat/transloco';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import {
  SelectSourceComponent,
  SharedConstants as ProfilingConstants,
  SharedConstants,
  ValidationMessage,
  ValidationMessageTypeModel
} from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { ProfileService } from 'profiling/profile.service';
import { ProfileConfigureModel } from './profile-configure.model';
import { ProfileDetailsComponent } from './profile-details/profile-details.component';
import { ProfilingRulesComponent } from './profiling-rules/profiling-rules.component';

@Component({
  selector: 'discovery-profile-configure',
  templateUrl: './profile-configure.component.html',
  styleUrls: ['./profile-configure.component.css']
})
export class ProfileConfigureComponent implements OnInit {
  @ViewChild('selectSource')
  selectSourceComponent: SelectSourceComponent;
  @ViewChild('profileRules')
  profilingRulesComponent: ProfilingRulesComponent;

  @ViewChild('profileDetail')
  profileDetailsComponent: ProfileDetailsComponent;

  activeIndex: number;
  profileConfigureModel: ProfileConfigureModel;
  failureMessages: any[] = [];
  validationFailures: Set<string>;
  saveInProgress: boolean;
  isActionDisabled: boolean;
  connectionIdKeyFlag: boolean = false;
  catalogConnectionFlag: boolean = false;

  ValidationMessageType: typeof ValidationMessageTypeModel = ValidationMessageTypeModel;
  editMode: boolean = false;
  copyMode: boolean = false;
  profileId: string;
  progressDetails = [
    { progressLabel: 'discoveryProfiling.profileConfigure.selectSource' },
    { progressLabel: 'discoveryProfiling.profileConfigure.configureProfile' },
    { progressLabel: 'discoveryProfiling.profileConfigure.finalize' }
  ];
  progressDetailsWithFeatureFlag = [
    { progressLabel: 'discoveryProfiling.profileConfigure.selectSource' },
    { progressLabel: 'discoveryProfiling.profileConfigure.configureProfile' }
  ];

  get scheduleFeatureFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.SCHEDULER);
  }
  constructor(
    private router: Router,
    private profileService: ProfileService,
    private translocoService: TranslocoService,
    private toastrService: ToastrService,
    private activatedRoute: ActivatedRoute,
    private launchDarklyService: LaunchDarklyService
  ) {
    this.activeIndex = 0;
    this.profileConfigureModel = new ProfileConfigureModel();
  }

  ngOnInit(): void {
    this.catalogConnectionFlag = this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.CATALOG);
    this.setActiveIndex();
    this.profileId = this.activatedRoute.snapshot.paramMap.get('profileId');
    if (this.profileId) {
      this.loadProfileById(this.profileId);
    }
  }

  cancelCreate(): void {
    this.router.navigateByUrl('/data-observability/data-profiling');
  }

  saveRunProfile(): void {
    if (this.validate()) {
      this.saveInProgress = true;
      if (!this.scheduleFeatureFlag) {
        delete this.profileConfigureModel.scheduleConfig;
      }
      this.profileService.saveProfile(this.profileConfigureModel, !this.editMode, this.profileId).subscribe(
        (response: any) => {
          this.runProfile(this.editMode ? this.profileId : response.id, this.profileConfigureModel.name);
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.saveInProgress = false;
          if (httpErrorResponse.status === 409) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.nameAlreadyExists', {
                  profileName: this.profileConfigureModel.name
                })
              )
            ];
          } else if (httpErrorResponse.status === 423) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.profileAlreadyRunning')
              )
            ];
          } else if (httpErrorResponse.status === 404) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.profileNotFound')
              )
            ];
          } else {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.profileSaveFailed', {
                  serverMessage:
                    httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                      ? httpErrorResponse.error.message
                      : ''
                })
              )
            ];
          }
        }
      );
    }
  }

  saveProfile(): void {
    if (this.validate()) {
      this.saveInProgress = true;
      if (!this.scheduleFeatureFlag) {
        delete this.profileConfigureModel.scheduleConfig;
      }
      this.profileService.saveProfile(this.profileConfigureModel, !this.editMode, this.profileId).subscribe(
        () => {
          this.saveInProgress = false;
          this.router.navigateByUrl('/data-observability/data-profiling');
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.saveInProgress = false;
          if (httpErrorResponse.status === 409) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.nameAlreadyExists', {
                  profileName: this.profileConfigureModel.name
                })
              )
            ];
          } else if (httpErrorResponse.status === 423) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.profileAlreadyRunning')
              )
            ];
          } else if (httpErrorResponse.status === 404) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.profileNotFound')
              )
            ];
          } else {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryProfiling.profileConfigure.profileSaveFailed', {
                  serverMessage:
                    httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                      ? httpErrorResponse.error.message
                      : ''
                })
              )
            ];
          }
        }
      );
    }
  }

  runProfile(id: string, name: string) {
    this.profileService.runProfile(id).subscribe(
      () => {
        this.toastrService.success(
          name + ' ' + this.translocoService.translate('discoveryProfiling.profileConfigure.profileRunSuccess')
        );
        this.router.navigateByUrl('/data-observability/data-profiling');
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.toastrService.error(
          this.translocoService.translate('discoveryProfiling.profileConfigure.profileRunFail', {
            serverMessage:
              httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                ? httpErrorResponse.error.message
                : ''
          })
        );
      }
    );
  }

  rulesListChanged(selectedRulesList: Map<string, Map<string, any>>) {
    this.profileConfigureModel.rules = {};
    for (const [ruleId, options] of selectedRulesList) {
      const optionsAsKeyValueArr: { [optionId: string]: [optionValue: any] } = {};
      for (const [optionId, optionValues] of options) {
        optionsAsKeyValueArr[optionId] = optionValues;
      }

      this.profileConfigureModel.rules[ruleId] = optionsAsKeyValueArr;
    }
  }

  moveNext() {
    if (this.validate()) {
      ++this.activeIndex;
    }
  }

  movePrevious() {
    --this.activeIndex;
  }

  validate(): boolean {
    //Keep the index 2 if feature flag removed
    const profDetailIndex = this.scheduleFeatureFlag ? 2 : 1;
    if (this.activeIndex === 0) {
      this.validationFailures = this.selectSourceComponent.validate();
    } else if (this.activeIndex === profDetailIndex) {
      this.validationFailures = this.profileDetailsComponent.validate();
    }
    return !(this.validationFailures && this.validationFailures.size > 0);
  }
  loadProfileById(profileId: string) {
    this.profileService.getProfile(profileId).subscribe(
      (response) => {
        this.profileConfigureModel.loadFromSettings(response);
        if (this.copyMode) {
          this.profileConfigureModel.name = this.translocoService.translate(
            'discoveryProfiling.profileConfigure.nameCopy',
            { profileName: this.profileConfigureModel.name }
          );
        }
        this.selectSourceComponent.loadProfileSettings(this.profileConfigureModel);
        this.profileDetailsComponent?.loadProfileSettings(this.profileConfigureModel, this.editMode);
        this.profilingRulesComponent?.loadProfileSettings(this.profileConfigureModel);
      },
      (httpErrorResponse: HttpErrorResponse) => {
        if (httpErrorResponse.status === 404) {
          this.toastrService.error(
            this.translocoService.translate('discoveryProfiling.profileConfigure.profileNotFound')
          );
        }
      }
    );
  }

  //Output listening changes from select source for action buttons
  disableActions(disableFlag: boolean): void {
    this.isActionDisabled = disableFlag;
  }

  private setActiveIndex() {
    if (
      this.activatedRoute.snapshot.queryParamMap.get('index') === ProfilingConstants.PROFILE_CONFIGURE_STEPS.FINALIZE
    ) {
      this.activeIndex = 2;
      this.editMode = true;
    } else if (
      this.activatedRoute.snapshot.queryParamMap.get('index') === ProfilingConstants.PROFILE_CONFIGURE_STEPS.PROFILE
    ) {
      this.activeIndex = 1;
      this.editMode = true;
    } else if (
      this.activatedRoute.snapshot.queryParamMap.get('index') === ProfilingConstants.PROFILE_CONFIGURE_STEPS.SOURCE
    ) {
      this.activeIndex = 0;
      this.editMode = true;
    } else {
      if (this.router.url.indexOf('/edit') > -1) {
        this.editMode = true;
      } else if (this.router.url.indexOf('/copy') > -1) {
        this.copyMode = true;
      }
    }
  }
}
