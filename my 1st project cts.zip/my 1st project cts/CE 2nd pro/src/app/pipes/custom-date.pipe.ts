import {Pipe, PipeTransform} from '@angular/core'

@Pipe ({ name:'dateFormat' })

export class CustomDatePipe implements PipeTransform {
  transform (value:string) {
      let dateStr = value.toString(),
        yyyy = dateStr.substr(0, 4),
        mm = dateStr.substr(4, 2),
        dd = dateStr.substr(6, 2);
        return dateStr = mm + "-" + dd + "-" + yyyy;
  }
  
}