import { Component, Input, Output, OnInit, EventEmitter, OnDestroy } from '@angular/core';
import { Metabase } from '../../shared/metabase.model';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';

@Component({
  selector: 'p-connect-delete-metabase-form',
  templateUrl: './delete-metabase-form.component.html'
})
export class DeleteMetabaseFormComponent implements OnInit, OnDestroy {
  @Input() metabase: Metabase;
  /**
   * Updates the disabled state of the primary button
   */
  @Output() primaryButtonStateChange = new EventEmitter<boolean>();

  metabaseCredentialsForm: FormGroup;

  /**
   * Subscriptions that are used in this component
   */
  subscriptions: Subscription;

  get isIBMi(): boolean {
    return this.metabase?.dataConnection.connectionType === 'DB2I';
  }

  get userNameTranslationString(): string {
    return `metabases.DELETE_DIALOG.FORM.USERNAME_${this.metabase?.dataConnection.connectionType}` || '';
  }

  get databaseServer(): string {
    return !this.isIBMi
      ? `${this.metabase?.dataConnection.database}:${this.metabase?.dataConnection.port}`
      : this.metabase?.dataConnection.database || '';
  }

  get dataConnectionType(): string {
    return this.metabase?.dataConnection.connectionType || '';
  }

  get adminInfoTranslationString(): string {
    return !this.isIBMi ? `metabases.DELETE_DIALOG.${this.metabase?.dataConnection.connectionType}_ADMIN_INFO` : '';
  }

  constructor(private readonly formBuilder: FormBuilder) {}

  ngOnInit(): void {
    this.createForm();
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  open(metabase: Metabase) {
    this.metabaseCredentialsForm.patchValue({
      adminUserId: '',
      password: '',
      removeConfigOnly: false
    });
    this.setFormContent(metabase.dataConnection?.connectionType);
  }

  /**
   * This function is used to fix a bug with p-radiobuttons when used in a reactive form https://github.com/primefaces/primeng/issues/9162
   * @param value the selected value
   */
  setDeleteMetabaseConfigValue(value: boolean): void {
    this.metabaseCredentialsForm.get('removeConfigOnly').setValue(value, { emitEvent: false });
  }

  private createForm(): void {
    this.metabaseCredentialsForm = this.formBuilder.group({
      adminUserId: ['', Validators.required],
      password: ['', Validators.required],
      removeConfigOnly: [false, Validators.required]
    });
    this.subscriptions = this.metabaseCredentialsForm.valueChanges.subscribe(() => {
      this.updateButtonDisabledState();
    });
  }

  private updateButtonDisabledState(): void {
    !this.isIBMi && !this.metabaseCredentialsForm.valid
      ? this.primaryButtonStateChange.emit(true)
      : this.primaryButtonStateChange.emit(false);
  }

  /**
   * Toggles content of form based on connection type
   */
  private setFormContent(connectionType: any): void {
    switch (connectionType) {
      case 'ORACLE':
        this.metabaseCredentialsForm.patchValue({ adminUserId: 'SYS' });
        break;
      case 'SQLSERVER':
        this.metabaseCredentialsForm.patchValue({ adminUserId: 'sa' });
        break;
      case 'DB2':
        this.metabaseCredentialsForm.patchValue({ adminUserId: '' });
        break;
      case 'DB2I':
        this.primaryButtonStateChange.emit(false);
        break;
    }
  }
}
