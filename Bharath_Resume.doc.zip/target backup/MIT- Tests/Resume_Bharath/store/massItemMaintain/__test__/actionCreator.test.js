import {
  getItems,
  getItemsFromTcins,
  excelUpload,
  cancelUpdate,
  toggleLoading,
  changeUpdateMode,
} from '../actionCreator'
import {
  GET_ITEMS,
  SERVICE_FAIL,
  CANCEL_UPDATE,
  TOGGLE_LOADING,
  UPDATE_MODE,
} from '../actionType'

import axios from 'axios'
import configureMockStore from 'redux-mock-store'
import thunk from 'redux-thunk'

describe('rule details actionCreator', () => {
  const mockStore = configureMockStore([thunk])
  let store = mockStore()

  const mockAttr = {
    'item_list': [{
      'tcin': '47029874',
      'dpci': '049-00-0002',
      'barcode': '490490000022',
      'product_title': 'OLAY         SAMPLE COLLECTION',
      'attribute': 'cost',
      'old_value': [
        '3.0',
      ],
      'new_value': null,
      'vendor_id': '3872918',
      'vendor_name': 'PROCTER & GAMBLE DIST LLC',
      'alternate_id': '172257210',
      'vos': '2',
    }],
    'common_field': {
      'jira_id': 'cr-11789',
      'maintainance_type': 'Cost',
      'user_id': null,
    },
    'column_info': [{
      'column_id': 'tcin',
      'column_name': 'TCIN',
      'editable': false,
      'field_type': 'Number',
      'multi_value': false,
      'values': [],
      'send_in_response': true,
      'filterable': false,
    }],
    'errors': [],
  }

  const mockResponse = (resp, shouldReject) => {
    axios.get = jest.fn(() => {
      return Promise[shouldReject ? 'reject' : 'resolve'](resp)
    })
  }

  afterEach(() => {
    store = mockStore()
  })

  it('dispatches GET_ITEMS on request - Jira service', () => {
    mockResponse({status: 200, data: mockAttr})
    store.dispatch(getItems()).then(() => {
      expect(store.getActions()[0].type).toEqual(GET_ITEMS)
    })
  })

  it('dispatches GET_ITEMS upon failure - Jira service', () => {
    mockResponse({status: 500, code: 'Network Error'}, true)
    store.dispatch(getItems()).then(() => {
      expect(store.getActions()[1].type).toEqual(SERVICE_FAIL)
    })
  })

  it('dispatches GET_ITEMS on request - tcin service', () => {
    mockResponse({status: 200, data: mockAttr})
    store.dispatch(getItemsFromTcins()).then(() => {
      expect(store.getActions()[0].type).toEqual(GET_ITEMS)
    })
  })

  it('dispatches GET_ITEMS upon failure - tcin service', () => {
    mockResponse({status: 500, code: 'Network Error'}, true)
    store.dispatch(getItemsFromTcins()).then(() => {
      expect(store.getActions()[1].type).toEqual(SERVICE_FAIL)
    })
  })

  it('dispatches GET_ITEMS on request - excel service', () => {
    const excelData = [
      ['tcin_dpci', 'new_cost', 'vendor_id', 'vos_id'],
      ['', '', '', ''],
    ]
    const sendData = {
      'jira_id': 'cr-123',
      'maintenance_type': 'cost',
      'action': ' ',
      'is_vop_level_attribute': true,
    }
    const excelInfo = {
      'template_mapping': ['tcin_dpci', 'new_cost', 'vendor_id', 'vos_id'],
      'service_name': 'test',
      'grid_required': false,
    }
    mockResponse({status: 200, data: mockAttr})
    store.dispatch(excelUpload(excelData, sendData, excelInfo)).then(() => {
      expect(store.getActions()[0].type).toEqual(GET_ITEMS)
    })
  })

  it('dispatches GET_ITEMS upon failure - excel service', () => {
    const excelData = [
      ['tcin_dpci', 'new_value', 'vendor_id', 'vos_id'],
      ['', '', '', ''],
    ]
    const sendData = {
      'jira_id': 'cr-123',
      'maintenance_type': 'cost',
      'action': ' ',
      'is_vop_level_attribute': true,
    }
    const excelInfo = {
      'template_mapping': ['tcin_dpci', 'new_cost', 'vendor_id', 'vos_id'],
      'service_name': 'test',
      'grid_required': false,
    }
    mockResponse({status: 500, code: 'Network Error'}, true)
    store.dispatch(excelUpload(excelData, sendData, excelInfo)).then(() => {
      expect(store.getActions()[1].type).toEqual(SERVICE_FAIL)
    })
  })

  it('cancelUpdate fucntion', () => {
    const expectedAction = {
      type: CANCEL_UPDATE,
    }
    expect(cancelUpdate()).toEqual(expectedAction)
  })

  it('toggleLoading fucntion', () => {
    const requestPayload = {
      status: true,
      message: 'Loading',
    }
    const responsePayload = {
      type: TOGGLE_LOADING,
      status: true,
      message: 'Loading',
    }
    expect(toggleLoading(true, 'Loading')).toEqual(responsePayload)
    expect(toggleLoading(requestPayload).type).toEqual(TOGGLE_LOADING)
  })

  it('changeUpdateMode fucntion', () => {
    const requestPayload = {
      updateMode: 'tcins',
    }
    const responsePayload = {
      type: UPDATE_MODE,
      updateMode: 'tcins',
    }
    expect(changeUpdateMode('tcins')).toEqual(responsePayload)
    expect(changeUpdateMode(requestPayload).type).toEqual(UPDATE_MODE)
  })
})
