import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TranslocoService } from '@ngneat/transloco';
import { cloneDeep } from 'lodash';

@Component({
  selector: 'p-connect-change-column-mapping-changes-tab',
  templateUrl: './change-column-mapping-changes-tab.component.html',
  styleUrls: ['./change-column-mapping-changes-tab.component.scss']
})
export class ChangeColumnMappingChangesTabComponent implements OnInit {
  @Input() checkedItems: [];
  @Input() tableData: [];
  @Input() changeMetaData;
  @Input() activeTabIndex;
  @Input() isTargetExists: boolean;
  @Input() columnMappingType;
  @Input() selectedTopicsCount;
  @Output() disableSaveButton = new EventEmitter<any>();
  metaDataCheckboxField = false;
  @Input() mapColumnsByDropdownDefaultValue;
  @Input() includeRowMetaDataDropdownDefaultValue;
  storeChangeTabData;

  @Output() disableUpdateDefaultsButton = new EventEmitter<any>();
  @Output() enableUpdateDefaultsButton = new EventEmitter<any>();
  changesTabFormGroup: FormGroup;
  payloadForChanges = {};
  payloadForBulkChanges = [];

  mapColumnsByDropdownData = [
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.DO_NOT_CHANGE',
      value: 'DO_NOT_CHANGE'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.NAME',
      value: 'COLUMN_NAME'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
      value: 'COLUMN_ORDER'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.USE_DEFAULT',
      value: 'USE_DEFAULT'
    }
  ];
  includeRowMetaDataDropdownData = [
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.USE_DEFAULT',
      value: 'USE_DEFAULT'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.DO_NOT_CHANGE',
      value: 'DO_NOT_CHANGE'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
      value: 'NO_ROW_METADATA'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.SELECTED_ROW_METADATA',
      value: 'SELECT_ROW_METADATA'
    }
  ];

  constructor(private formBuilder: FormBuilder, public readonly translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.createForm();
    this.disableUpdateDefaultsButton.emit(this.changesTabFormGroup.value);
  }

  enableUpdateDefaultsBtn() {
    this.enableUpdateDefaultsButton.emit();
  }

  createForm() {
    this.changesTabFormGroup = this.formBuilder.group({
      mapColumnsByDropdown: new FormControl({
        value: this.mapColumnsByDropdownData[0]?.value,
        name: this.mapColumnsByDropdownData[0]?.name
      }),
      rowMetaDataDropdown: new FormControl({
        value: this.includeRowMetaDataDropdownData[0]?.value,
        name: this.includeRowMetaDataDropdownData[0]?.name
      })
    });
  }

  loadChangesTab() {
    this.createForm();
    this.metaDataCheckboxField = false;
  }

  disableSaveButtonIfUnchecked() {
    let isDisableSaveBtn;
    if (this.activeTabIndex === 0) {
      const getDefaultsTabMetaData = this.getBulkChangePayload();
      isDisableSaveBtn = Object.values(getDefaultsTabMetaData.payload).some((val) => val.value === 'INCLUDE');
    } else {
      const getDefaultsTabMetaData = this.getChangesPayloadData();
      isDisableSaveBtn = Object.values(getDefaultsTabMetaData.payload).some((val) => val === 'INCLUDE');
    }
    this.disableSaveButton.emit(isDisableSaveBtn);
  }

  onChangeDropDown() {
    this.disableUpdateDefaultsButton.emit(this.changesTabFormGroup.value);
    if (this.changesTabFormGroup.value.rowMetaDataDropdown.value === 'SELECT_ROW_METADATA') {
      this.metaDataCheckboxField = true;
      this.changeMetaData?.forEach((element) => {
        element['isChecked'] = true;
        element.cdcRowMetadataType = 'INCLUDE';
      });
    } else if (this.changesTabFormGroup.value.rowMetaDataDropdown.value === 'NO_ROW_METADATA') {
      this.metaDataCheckboxField = false;
      this.storeChangeTabData = cloneDeep(this.changeMetaData);
      this.changeMetaData?.forEach((element) => {
        element['isChecked'] = false;
        element.cdcRowMetadataType = 'EXCLUDE';
      });
    } else {
      this.metaDataCheckboxField = false;
    }
    this.rowMetaDataCheckAll();
  }

  rowMetaDataCheckAll() {
    let excludeCoundt = 0;
    this.changeMetaData?.forEach((element) => {
      if (element.cdcRowMetadataType === 'EXCLUDE') {
        excludeCoundt++;
      }
    });
    if (excludeCoundt === this.changeMetaData?.length) {
      this.changeMetaData?.forEach((element) => {
        element['isChecked'] = true;
        element.cdcRowMetadataType = 'INCLUDE';
      });
    }
  }

  getChangeTabEmittedData(metaData) {
    this.changeMetaData = metaData;
    this.disableSaveButtonIfUnchecked();
    this.enableUpdateDefaultsBtn();
  }

  processMetaDataPayload() {
    this.changeMetaData?.forEach((data) => {
      if (
        this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'SELECT_ROW_METADATA' ||
        this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'USE_DEFAULT' ||
        this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'DO_NOT_CHANGE'
      ) {
        this.payloadForChanges[data.key] = data.cdcRowMetadataType;
      } else if (this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'NO_ROW_METADATA') {
        this.payloadForChanges[data.key] = 'EXCLUDE';
      }
    });
  }

  processMetaDataBulkChangePayload() {
    this.payloadForBulkChanges = [];
    this.changeMetaData?.forEach((data) => {
      if (
        this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'SELECT_ROW_METADATA' ||
        this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'USE_DEFAULT' ||
        this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'DO_NOT_CHANGE'
      ) {
        this.payloadForBulkChanges.push({ key: data.key, value: data.cdcRowMetadataType });
      } else if (this.changesTabFormGroup.get('rowMetaDataDropdown').value.value === 'NO_ROW_METADATA') {
        this.payloadForBulkChanges.push({ key: data.key, value: 'EXCLUDE' });
      }
    });
  }

  processMapColumnsKey() {
    let getMapColumns;
    if (this.isTargetExists) {
      if (this.changesTabFormGroup.value.mapColumnsByDropdown.value === 'COLUMN_NAME') {
        getMapColumns = 'Column name';
      } else if (this.changesTabFormGroup.value.mapColumnsByDropdown.value === 'COLUMN_ORDER') {
        getMapColumns = 'Column order';
      } else if (
        this.changesTabFormGroup.value.mapColumnsByDropdown.value === 'USE_DEFAULT' ||
        this.changesTabFormGroup.value.mapColumnsByDropdown.value === 'DO_NOT_CHANGE'
      ) {
        const getColMap = this.mapColumnsByDropdownData.filter((entry) => entry.value === `${this.columnMappingType}`);
        getMapColumns = getColMap[0]?.value === 'COLUMN_ORDER' ? 'Column order' : 'Column name';
      }
    } else {
      getMapColumns = undefined;
    }
    return getMapColumns;
  }

  getChangesPayloadData() {
    this.processMetaDataPayload();
    const getMapColumns = this.processMapColumnsKey();
    return {
      payload: this.payloadForChanges,
      mapColumns: getMapColumns
    };
  }

  getBulkChangePayload() {
    this.processMetaDataBulkChangePayload();
    const getMapColumns = this.processMapColumnsKey();
    return {
      payload: this.payloadForBulkChanges,
      mapColumns: getMapColumns
    };
  }
}
