export interface CatalogTableStatus {
  columnsCompleted: number;
  columnsCount: number;
  lastCompleted: string;
  lastUpdated?: string;
  triggeredAt?: string;
  status: string;
  table: string;
  // Error message in json format
  errorMessage: string;
}
