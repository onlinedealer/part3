(function() {
    'use strict';

    fileuploader.controller("custTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$location', '$route', '$window', '$timeout', '$http', '$uibModal', 'ngTableParams', 'imgCrop', custTemplateCtrl]);

    function custTemplateCtrl($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $location, $route, $window, $timeout, $http, $uibModal, ngTableParams, imgCrop) {
    
    $scope.imagepreview = "apps/images/income.jpg";

    $scope.size='small';
        $scope.type='circle';
        $scope.imageDataURI='';
        $scope.resImageDataURI='';
        $scope.resImgFormat='image/png';
        $scope.resImgQuality=1;
        $scope.selMinSize=100;
        $scope.resImgSize=200;
        //$scope.aspectRatio=1.2;
        $scope.onChange=function($dataURI) {
          console.log('onChange fired');
        };
        $scope.onLoadBegin=function() {
          console.log('onLoadBegin fired');
        };
        $scope.onLoadDone=function() {
          console.log('onLoadDone fired');
        };
        $scope.onLoadError=function() {
          console.log('onLoadError fired');
        };
        var handleFileSelect=function(evt) {
          var file=evt.currentTarget.files[0];
          var reader = new FileReader();
          reader.onload = function (evt) {
            $scope.$apply(function($scope){
              $scope.imageDataURI=evt.target.result;
            });
          };
          reader.readAsDataURL(file);
        };

    }

   
   
})();
