import { Injectable } from "@angular/core";
import { Actions, ofType, createEffect } from "@ngrx/effects";
import { of } from "rxjs";
import { map, switchMap, catchError } from "rxjs/operators";
import { NetworkSpecificConfigurationService } from "../../services/network-specific-config.service";
import { NetworkSpecificConfigActions } from "../actions";
import { NetworkControlParam } from "../../models/network-specific-config.model";

@Injectable()
export class NetworkSpecificConfigurationEffects {
    constructor(private actions$: Actions, private networkSpecificConfigService: NetworkSpecificConfigurationService) {}

    LoadNetworkSpecificConfiguration$ = createEffect(() =>
        this.actions$.pipe(
            ofType(NetworkSpecificConfigActions.LoadNetworkSpecificConfiguration),
            switchMap(() => {
                return this.networkSpecificConfigService.getNetworkSpecificConfigurations().pipe(
                    map((networkSpecificConfig: NetworkControlParam) =>
                        NetworkSpecificConfigActions.LoadNetworkSpecificConfigurationSuccess(networkSpecificConfig)
                    ),
                    catchError(error => of(NetworkSpecificConfigActions.LoadNetworkSpecificConfigurationFailure({ error: error })))
                );
            })
        )
    );
}
