import { Spies } from 'discovery-test';
import { ProfileResultsTableModel } from 'profiling/profile-results/profile-results-table.model';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { TreeTableModel } from 'profiling/profile-results/tree-table.model';
import { StackedDonutChartComponent } from './stacked-donut-chart.component';

describe('StackedDonutChartComponent', () => {
  let component: StackedDonutChartComponent;

  beforeEach(() => {
    Spies.init();
    component = new StackedDonutChartComponent(Spies.TranslateService);
    component.totalRows = 50000000;
    component.data = {
      labels: [],
      datasets: [
        {
          data: [],
          backgroundColor: []
        },
        {
          data: [],
          backgroundColor: []
        }
      ]
    };
    component.treePath = new TreePath();
    component.treePath.treeData = new TreeTableModel();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
  it('Initialize ngOnInit with Column View Completeness', () => {
    component.statistics = {
      type: 'UniquenessStatistics',
      uniqueCount: 19,
      distinctCount: 20
    } as any;
    component.treePath.columnView = true;
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = component.totalRows;
    component.ngOnInit();
    const nonUniqueCount = component.totalRows - component.statistics['uniqueCount'];
    const unique: number = parseFloat(
      (
        (component.statistics['uniqueCount'] /
          (component.statistics['uniqueCount'] + (component.totalRows - component.statistics['uniqueCount']))) *
        100
      ).toFixed(2)
    );
    const distinct = parseFloat(
      ((component.statistics['distinctCount'] / (component.statistics['uniqueCount'] + nonUniqueCount)) * 100).toFixed(
        2
      )
    );
    const nonUnique = parseFloat(
      ((nonUniqueCount / (component.statistics['uniqueCount'] + nonUniqueCount)) * 100).toFixed(2)
    );
    expect(component.data.datasets[0].data[0]).toBe(unique);
    expect(component.data.datasets[0].data[1]).toBe(nonUnique);
    expect(component.data.datasets[0].data[2]).toBe(0);
    expect(component.data.datasets[0].data[3]).toBe(0);
    expect(component.data.datasets[1].data[0]).toBe(0);
    expect(component.data.datasets[1].data[1]).toBe(0);
    expect(component.data.datasets[1].data[2]).toBe(distinct);
    expect(component.data.datasets[1].data[3]).toBe(100 - distinct);
  });
});
