import { DatadriftConfigureModel } from './rules-configure/data-drift-configure/data-drift-configure.model';
import { VolumeConfigureModel } from './rules-configure/volume-configure/volume-configure.model';

export class SavedRuleModel {
  volume: VolumeConfigureModel;
  dataDrift: DatadriftConfigureModel;

  constructor() {
    this.volume = new VolumeConfigureModel();
    this.dataDrift = new DatadriftConfigureModel();
  }
}
