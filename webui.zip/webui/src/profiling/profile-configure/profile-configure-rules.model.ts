export class ProfileConfigureRulesModel {}
