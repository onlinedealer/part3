import { Component } from "@angular/core";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { Store } from "@ngrx/store";

@Component({
    selector: "landisgyr-meteringpoints-header",
    templateUrl: "./meteringpoints-header-container.component.html",
    styleUrls: ["./meteringpoints-header-container.component.scss"]
})
export class MeteringpointsHeaderContainerComponent {
    constructor(private store: Store<MeteringPointsFeatureState>) {}
}
