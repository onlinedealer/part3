import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, Renderer2, ViewChild } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { TableMapping } from 'src/app/pipelines/pipeline/shared/pipeline';
import { TableConfiguration } from 'src/app/shared/components/generic-table/generic-table';
import { GenericTableComponent } from 'src/app/shared/components/generic-table/generic-table.component';
import { ColumnMap } from '../../../shared/map-columns';
import * as _ from 'lodash';
import { Table } from 'primeng/table';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
import { PipelineEntityService } from 'src/app/pipelines/pipeline/shared/pipeline-entity.service';
@Component({
  selector: 'p-connect-column-mapping-table',
  templateUrl: './column-mapping-table.component.html',
  styleUrls: ['column-mapping-table.component.scss']
})
export class ColumnMappingTableComponent extends GenericTableComponent implements OnInit {
  @Input() tableConfiguration: TableConfiguration;
  @Input() columnList;
  @Input() actionList: string[];
  @Input() targetEditable: boolean;
  @Input() isReorderEnabled: boolean;
  @Input() tableMapping: TableMapping;
  @Input() rowData;
  @Input() masterColumnList;
  @Input() pipeline;
  @Input() set searchFilter(value: string) {
    if (this.dt) {
      this.dt.filterGlobal(value, 'contains');
    }
  }
  @ViewChild('dt') dt: Table;
  @Output() dataChange = new EventEmitter<any>();
  @Output() hasCustomColumnMappingsChange = new EventEmitter<any>();
  @Output() checkedItemsChange = new EventEmitter<any>();
  @Output() displayValuesChange = new EventEmitter<any>();
  @Output() primaryButtonStateChange = new EventEmitter<any>();
  @Output() errorMessageChange = new EventEmitter<any>();
  data: ColumnMap[];
  displayValues;
  checkedItems: any[];
  selectedKeys: any[] = [];
  checkingValues;
  hasCustomColumnMappings: boolean;
  metadataRows;
  actionDropdownItems: { label: string; value: string }[];
  constructor(
    public readonly changeDetectorRef: ChangeDetectorRef,
    public readonly translocoServer: TranslocoService,
    private readonly pipelineMappingService: PipelineMappingService,
    private readonly pipelineEntityService: PipelineEntityService,
    private renderer: Renderer2
  ) {
    super(changeDetectorRef, translocoServer);
  }

  ngOnInit(): void {
    this.updateActionTypeOptions();
    this.pipeline = this.pipelineEntityService.getPipeline();
    this.pipelineMappingService.getChangeColumnMappingDefaults(this.pipeline.id).subscribe({
      next: (data) => {
        this.metadataRows = data.cdcRowMetadatas;
      }
    });
  }
  deleteRow(row): void {
    if (this.displayValues.length === 1) {
      this.errorMessageChange.emit({ message: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.ERROR.DELETE_ERROR' });
    } else if (this.displayValues.length > 1) {
      this.displayValues.splice(this.displayValues.indexOf(row), 1);
      this.displayValues = [...this.displayValues];
      let excessItem = this.checkedItems.find((ci) => ci.id === row.id);
      this.checkedItems.splice(this.checkedItems.indexOf(excessItem), 1);
    }
    this.checkedItemsChange.emit(this.checkedItems);
    this.displayValuesChange.emit(this.displayValues);
    this.updateAllInputFields();
    this.updateHasCustomColumnMappings();
  }

  actionSelect(row: ColumnMap, event): void {
    this.displayValues[this.displayValues.indexOf(row)].action = event.value;
    this.updateHasCustomColumnMappings();
  }

  defaultMapping(data: ColumnMap[]) {
    this.updateDisplayValues(data);
    this.updateSelectedKeys();
    for (let i = 0; i < this.displayValues.length; i++) {
      this.displayValues[i].sourceColumnName = data[i].sourceColumnName;
      this.displayValues[i].sourceColType = data[i].sourceColType;
      this.displayValues[i].targetColType = data[i].targetColType;
      this.displayValues[i].targetColumnName = data[i].targetColumnName;
      this.displayValues[i].state = data[i].state;
    }
  }

  updateDisplayValues(data: ColumnMap[]) {
    this.displayValues = data.map((d) => ({ ...d, id: data.indexOf(d) + 1 }));
    this.checkingValues = JSON.parse(JSON.stringify(data));
    this.checkingValues = this.checkingValues.map((d) => ({ ...d, id: this.checkingValues.indexOf(d) + 1 }));
  }

  private updateActionTypeOptions() {
    this.actionDropdownItems = this.actionList.map((action) => {
      return {
        label: this.translocoService.translate(`pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.ACTION_LIST.${action.toUpperCase()}`),
        value: action
      };
    });
  }

  applyBulkMapping(bulkMappingObj, checkedItems: any[]) {
    this.applyPattern(bulkMappingObj, checkedItems);
    checkedItems.forEach((item) => {
      if (bulkMappingObj.action === 'IGNORE') {
        this.displayValues.find((element) => element.id === item.id).action = 'Ignore';
      } else if (bulkMappingObj.action === 'COPY') {
        this.displayValues.find((element) => element.id === item.id).action = 'Copy';
      }
      if (bulkMappingObj.case !== 'SOURCE_NAME') {
        this.displayValues.find((element) => element.id === item.id).targetColumnName = this.applyCasing(
          bulkMappingObj.case,
          item.targetColumnName
        );
      }
    });
  }

  applyPattern(bulkMappingObj, checkedItems: any[]) {
    if (bulkMappingObj.targetColumnName?.length) {
      const targetColumnNamePattern = [];
      bulkMappingObj.targetColumnName.forEach((x) => {
        targetColumnNamePattern.push(x.code);
      });
      const indexOfAll = (arr, val) => arr.reduce((acc, el, i) => (el === val ? [...acc, i] : acc), []);
      const sourceColumnIndex = indexOfAll(targetColumnNamePattern, 'SOURCE_COLUMN');
      const sourceColumn = targetColumnNamePattern.findIndex((ele) => ele === 'SOURCE_COLUMN');
      const restPart = targetColumnNamePattern.findIndex((ele) => ele !== sourceColumn);
      checkedItems.forEach((item) => {
        sourceColumnIndex.forEach((e) => {
          targetColumnNamePattern[e] = item.sourceColumnName;
        });
        targetColumnNamePattern[restPart] = targetColumnNamePattern.find((ele) => ele !== sourceColumn);
        const targetColumnName = targetColumnNamePattern.join('');
        this.displayValues.find((element) => element.id === item.id).targetColumnName = targetColumnName;
      });
    }
  }

  applyCasing(casing: string, targetColumnName): string {
    const match = /[-_.]/.exec(targetColumnName);
    switch (casing) {
      case 'SENTENCE_CASE':
        return targetColumnName.replace(/\w\S*/g, (txt) => {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
      case 'LOWERCASE':
        return targetColumnName.toLowerCase();

      case 'UPPERCASE':
        return targetColumnName.toUpperCase();

      case 'CAPITALIZE':
        return targetColumnName
          .toLowerCase()
          .split(targetColumnName[match?.index])
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(targetColumnName[match?.index]);

      case 'TOGGLECASE':
        return targetColumnName
          .toUpperCase()
          .split(targetColumnName[match?.index])
          .map((word) => {
            return word.charAt(0).toLowerCase() + word.slice(1);
          })
          .join(targetColumnName[match?.index]);
    }
  }

  applyResetDefault(resetData: ColumnMap[], checkedItems: any[]) {
    checkedItems.forEach((element, index) => {
      let keys = Object.keys(element);
      keys.forEach((key) => {
        if (element[key] && key !== 'id') {
          element[key] = resetData[index][key];
        }
      });
    });
    this.updateHasCustomColumnMappings();
  }

  updateData() {
    // we need to pass a copy here, otherwise display values (kind of directly) linked
    // to column mapping grid behaviour fails. For e.g. after save, if you select the
    // source dropdown, the datatype of every row gets updated, because id is not available
    // and the subsequent function on dropdown change runs for every row element
    const _data = _.cloneDeep(this.displayValues);
    _data.map((data) => {
      delete data.id;
      return data;
    });
    this.dataChange.emit(_data);
    this.updateHasCustomColumnMappings();
  }

  updateHasCustomColumnMappings() {
    this.updateAllInputFields();
    this.hasCustomColumnMappings = this.rowData.hasCustomColMappings || !_.isEqual(this.displayValues, this.checkingValues);
    this.hasCustomColumnMappingsChange.emit(this.hasCustomColumnMappings);
  }

  onCheckedOrUnchecked() {
    this.checkedItems = this.checkedItems.filter((item) => {
      if (item.sourceColumnName) return item;
    });
    this.checkedItemsChange.emit(this.checkedItems);
    this.displayValuesChange.emit(this.displayValues);
  }

  /* Responsible for adding a new row to the column mapping grid. 
    When grid is empty, adding a row has a default ID of 1 (all rows are 1-indexed)
    */
  addColumnMapping() {
    this.displayValues.push({
      id: this.displayValues.length === 0 ? 1 : this.displayValues[this.displayValues.length - 1].id + 1,
      sourceColumnName: null,
      sourceColType: null,
      action: 'Copy',
      isKey: false,
      isExpression: null,
      targetColumnName: null,
      targetColType: null
    });
    this.checkedItemsChange.emit(this.checkedItems);
    this.displayValuesChange.emit(this.displayValues);
    this.updateHasCustomColumnMappings();
    if (this.displayValues.length) {
      this.primaryButtonStateChange.emit(false);
    }
    this.changeDetectorRef.detectChanges();
    this.updateAllInputFields();
  }

  /*
  Checks relevant isKey checkboxes when column mappings are loaded
  */
  updateSelectedKeys() {
    this.selectedKeys = this.displayValues.map((data) => {
      if (data.isKey) return data.id;
    });
  }

  /*
  Toggling behaviour for isKey checkboxes
  */
  selectKey(row: any) {
    if (row.isKey) row.isKey = false;
    else row.isKey = true;
    this.updateHasCustomColumnMappings();
  }

  /*
    Handles populating relevant fields upon changing the Source Column
    For physical rows, no auto-population is done
    For metadata rows, target field name is populated with backend data
  */
  onSourceColumnChange(row: any) {
    let matchedRow = this.checkingValues.find((data) => {
      return data.sourceColumnName === row.sourceColumnName;
    });
    if (!matchedRow) {
      row.isExpression = false;
      this.metadataRows.forEach((metaRow) => {
        if (metaRow.key === row.sourceColumnName) {
          row.targetColumnName = metaRow.value;
          row.isExpression = true;
        }
      });
      row.sourceColType = this.masterColumnList.find((list) => {
        return list.columnName === row.sourceColumnName;
      }).columnDataType;
      row.targetColType = row.sourceColType;
      return;
    }
    this.displayValues
      .filter((dv) => dv.id === row.id)
      .map((dv) => {
        dv.sourceColType = matchedRow.sourceColType;
        dv.targetColType = matchedRow.targetColType;
        dv.isExpression = matchedRow.isExpression;
        if (matchedRow.isExpression) {
          dv.targetColumnName = matchedRow.targetColumnName;
        }
      });
    this.updateAllInputFields();
    this.updateHasCustomColumnMappings();
  }

  /*
    Checks whether the source & target column fields match or not
    For metadata rows, the target field name is checked against the name sent from the backend
    Blue indicator is not shown when target field name is empty
  */
  areDifferentNames(row: any): boolean {
    if (!row.isExpression) {
      if (row.sourceColumnName != row.targetColumnName && row.targetColumnName?.trim().length !== 0) {
        return true;
      } else return false;
    } else {
      for (let data of this.metadataRows) {
        if (row.sourceColumnName === data.key && row.targetColumnName != data.value && row.targetColumnName) {
          return true;
        }
      }
      return false;
    }
  }

  /*
    Checks whether the source & target column types are different
   */
  areDifferentTypes(row: any): boolean {
    if (row.sourceColType != row.targetColType) return true;
    else return false;
  }

  targetValidate(row): boolean {
    let count = 0;
    for (let i in this.displayValues) {
      if (this.displayValues[i].targetColumnName === row.targetColumnName && row.targetColumnName?.trim().length !== 0) {
        count++;
      }
      if (count > 1) {
        break;
      }
    }
    return count > 1;
  }

  updateAllInputFields() {
    // update empty fields
    this.handleEmptyFields();
  }

  /**
   * Method to validate the mapping grid
   * Can be called from external (parent) component or internally
   * If invoked from outside, we can hook any special requirements like scroll, etc
   * @param invokedFromElseWhere - flag to check invocation point
   */
  validateGrid(invokedFromElseWhere: boolean = false): boolean {
    // check for empty records and highlight
    if (this.checkEmpty()) {
      this.handleEmptyFields(invokedFromElseWhere);
      return false;
    }
    // check if all are ignored then appropriate error is displayed
    if (this.checkAllIgnore()) {
      this.showAllIgnoredErrorMessage();
      return false;
    }
    // check for duplicate records
    if (this.checkDuplicate()) {
      return false;
    }
    return true;
  }

  checkDuplicate(): boolean {
    let duplicate = new Set();
    let isDuplicate = this.displayValues.some((obj) => {
      return duplicate.size === duplicate.add(obj.targetColumnName).size;
    });
    return isDuplicate;
  }

  checkAllIgnore(): boolean {
    const allIgnoredRows = this.displayValues.filter((obj) => obj.action === 'Ignore');
    return allIgnoredRows?.length === this.displayValues.length;
  }

  checkEmpty(): boolean {
    let count = 0;
    for (let i in this.displayValues) {
      if (
        (this.displayValues[i].action !== 'Ignore' && this.displayValues[i].targetColumnName?.trim().length === 0) ||
        this.displayValues[i].targetColumnName === null ||
        !this.displayValues[i].sourceColumnName
      ) {
        count++;
      }
      if (count > 0) {
        break;
      }
    }
    return count > 0;
  }

  private showAllIgnoredErrorMessage() {
    this.errorMessageChange.emit({ message: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.ERROR.DELETE_ERROR' });
  }

  addOrRemoveHighlightingToEmptyFields(fields: HTMLFormElement[]) {
    fields?.forEach((field) => {
      if (
        (field?.type === 'text' && !field?.disabled && field?.value?.length < 1) ||
        (field?.type !== 'text' && field?.innerText?.trim().length < 1)
      ) {
        this.renderer.addClass(field, 'border-danger');
      } else {
        this.renderer.removeClass(field, 'border-danger');
      }
    });
  }

  /**
   * Method to get all (and any) type of element within table body
   * @param selector choice of selector to get
   */
  getAllFormElements(selector: string) {
    return this.dt?.tableViewChild?.nativeElement?.querySelectorAll(`tbody > tr > td > ${selector}`);
  }

  handleEmptyFields(shouldScrollToTarget: boolean = false) {
    const errorInputFields = [];
    let targetInputFields = this.getAllFormElements('input');
    let sourceDropdownFields = this.getAllFormElements('p-dropdown[data-cy=columnDropdown] div.p-dropdown');
    // highlight target input fields
    this.addOrRemoveHighlightingToEmptyFields(targetInputFields);
    // highlight source dropdown fields
    this.addOrRemoveHighlightingToEmptyFields(sourceDropdownFields);
    // have the list of erroneous fields
    if (targetInputFields) {
      targetInputFields.forEach((f) => {
        if (!f?.value || !f?.value?.length) {
          errorInputFields.push(f);
        }
      });
      // scroll to the first most error field if required
      if (shouldScrollToTarget && errorInputFields.length > 0) {
        errorInputFields[0].scrollIntoView({
          behavior: 'smooth',
          block: 'start',
          inline: 'nearest'
        });
      }
    }
  }
}
