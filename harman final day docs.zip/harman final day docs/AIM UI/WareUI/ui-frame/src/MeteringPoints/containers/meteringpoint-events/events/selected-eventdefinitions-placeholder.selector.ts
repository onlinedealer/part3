import { createSelector } from "@ngrx/store";
import { getSelectedEventDefinitionIDs, getEventTreeTypes } from "../../../store/selectors/event.definitions.selector";
import { TodoItemNode } from "../../../store/reducers/event-definitions.reducer";
import { flatten } from "lodash";

const checkEventClassForSelectedDefinitions = (eventClass: TodoItemNode, eventClassId: number, selectedDefinitions: number[]) => {
    const selectedDefinitionsOfThisEventClass = eventClass.children.filter((eventDefinition: TodoItemNode) =>
        selectedDefinitions.includes(eventDefinition.id)
    );

    return {
        allChildrenSelected: selectedDefinitionsOfThisEventClass.length === eventClass.children.length,
        selectedChildren: selectedDefinitionsOfThisEventClass,
        item: eventClass.item,
        id: eventClassId
    };
};

const checkEventTypeForSelectedDefinitions = (eventType: TodoItemNode, eventTypeId: number, selectedDefinitions: number[]) => {
    const selectedClassesOfThisEventType = eventType.children
        .map((eventClass: TodoItemNode, index: number) =>
            checkEventClassForSelectedDefinitions(eventClass, eventTypeId + (index + 1) * 10000, selectedDefinitions)
        )
        .filter((eventClassResponse) => eventClassResponse.allChildrenSelected || eventClassResponse.selectedChildren.length > 0);

    const selectedClassesWithAllDefinitionsSelected = selectedClassesOfThisEventType.filter((eventClass) => eventClass.allChildrenSelected);

    return {
        allChildrenSelected: selectedClassesWithAllDefinitionsSelected.length === eventType.children.length,
        selectedChildren: selectedClassesOfThisEventType,
        item: eventType.item,
        id: eventTypeId
    };
};

const getPlaceHolderTextBase = (
    eventTypesWithFullChildrenSelections: any[],
    eventClassesWithFullChildrenSelections: any[],
    eventDefinitionSelections: any[]
) => {
    if (eventTypesWithFullChildrenSelections.length > 0) {
        return eventTypesWithFullChildrenSelections[0];
    } else if (eventClassesWithFullChildrenSelections.length > 0) {
        return eventClassesWithFullChildrenSelections[0];
    } else if (eventDefinitionSelections.length > 0) {
        return eventDefinitionSelections[0];
    }
};

const getPlaceHolderPlusCounter = (selectedId: number, eventTypes: any[]) => {
    let counter = 0;

    eventTypes
        .filter((eventType) => eventType.id !== selectedId)
        .forEach((eventType) => {
            if (eventType.allChildrenSelected) {
                counter = counter + 1;
            } else {
                eventType.selectedChildren
                    .filter((eventClass: any) => eventClass.id !== selectedId)
                    .forEach((eventClass: any) => {
                        if (eventClass.allChildrenSelected) {
                            counter = counter + 1;
                        } else {
                            counter =
                                counter +
                                eventClass.selectedChildren.filter((eventDefinition: any) => eventDefinition.id !== selectedId).length;
                        }
                    });
            }
        });

    return counter;
};
const getSelectedItems = (eventTypes: any[]) => {
    let counter: any;
    counter = [];
    eventTypes.forEach((eventType) => {
        if (eventType.allChildrenSelected) {
            counter.push(eventType.item);
        } else {
            eventType.selectedChildren.forEach((eventClass: any) => {
                if (eventClass.allChildrenSelected) {
                    counter.push(eventClass.item);
                } else {
                    eventClass.selectedChildren.forEach((eventDefinition: any) => {
                        counter.push(eventDefinition.item);
                    });
                }
            });
        }
    });
    return counter;
};

export const getSelectedEventDefinitionPlaceholderText = createSelector(
    getEventTreeTypes,
    getSelectedEventDefinitionIDs,
    (eventTypes, selectedDefinitions) => {
        if (eventTypes[0]) {
            const selectedTypes = eventTypes[0].children
                .map((eventType, index) => checkEventTypeForSelectedDefinitions(eventType, (index + 1) * 100000, selectedDefinitions))
                .filter((eventTypeResponse) => eventTypeResponse.allChildrenSelected || eventTypeResponse.selectedChildren.length > 0);

            const eventTypesWithFullChildrenSelections = selectedTypes.filter((eventType) => eventType.allChildrenSelected);
            const eventClassedWithChildrenSelections = flatten(selectedTypes.map((eventType) => eventType.selectedChildren));

            const eventClassesWithFullChildrenSelections = eventClassedWithChildrenSelections.filter(
                (eventClass) => eventClass.allChildrenSelected
            );

            const eventDefinitionSelections = flatten(eventClassedWithChildrenSelections.map((eventClass) => eventClass.selectedChildren));

            const placeHolderTextBase = getPlaceHolderTextBase(
                eventTypesWithFullChildrenSelections,
                eventClassesWithFullChildrenSelections,
                eventDefinitionSelections
            );

            const placeHolderPlusCounter = placeHolderTextBase ? getPlaceHolderPlusCounter(placeHolderTextBase.id, selectedTypes) : 0;
            let placeHolderText = placeHolderTextBase ? placeHolderTextBase.item : "";

            if (placeHolderPlusCounter > 0) {
                placeHolderText = placeHolderText + " ( + " + placeHolderPlusCounter + " " + $localize`:|@@profileForm.others:others` + ")";
            }
            if (eventTypes[0].children.length === eventTypesWithFullChildrenSelections.length) {
                placeHolderText = $localize`:|@@meteringpointEvents.allEvents:All events`;
            }
            return placeHolderText;
        } else {
            return [];
        }
    }
);
export const getSelectedEventTexts = createSelector(getEventTreeTypes, getSelectedEventDefinitionIDs, (eventTypes, selectedDefinitions) => {
    if (eventTypes[0]) {
        const selectedTypes = eventTypes[0].children
            .map((eventType, index) => checkEventTypeForSelectedDefinitions(eventType, (index + 1) * 100000, selectedDefinitions))
            .filter((eventTypeResponse) => eventTypeResponse.allChildrenSelected || eventTypeResponse.selectedChildren.length > 0);

        const eventNames = getSelectedItems(selectedTypes);
        const eventTypesWithFullChildrenSelections = selectedTypes.filter((eventType) => eventType.allChildrenSelected);
        if (eventTypes.length === eventTypesWithFullChildrenSelections.length) {
            return [];
        } else {
            return eventNames;
        }
    } else {
        return [];
    }
});
