import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarepassDollarRewardComponent } from './carepass-dollar-reward.component';

describe('CarepassDollarRewardComponent', () => {
  let component: CarepassDollarRewardComponent;
  let fixture: ComponentFixture<CarepassDollarRewardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarepassDollarRewardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  //collapsed view tests
  it('should create', () => {
    expect(component).toBeTruthy();
  });
  
  it('should be expandable', () => {
    expect(component.showExpandedView).toBeTruthy();
  });

  it('should be collapsable from the expanded view', () => {
    expect(component.hideFromExpanded).toBeTruthy();
  });

  it('should render a headline in an h3 tag', async(() => {
    const fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h3').textContent).toContain('Welcome to extracare!');
  }));

  it('should render a description', async(() => {
    const fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('span').textContent).toContain(this.data.webDsc);
  }));

  it('should render a send to card action in a p tag', async(() => {
    const fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('p').textContent).toContain('Send to card');
  }));

  //expanded view tests
  it('should render a print action in a span tag', async(() => {
    const fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('span').textContent).toContain('print');
  }));

  it('should render a max issue count', async(() => {
    const fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('div').textContent).toContain('Use' + this.data.maxIssueCnt + 'times!');
  }));

  it('should render a redeem message', async(() => {
    const fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('div').textContent).toContain('Redeem in store or online');
  }));

  it('should render a sequence number', async(() => {
    const fixture = TestBed.createComponent(CarepassDollarRewardComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('div').textContent).toContain('Sequence No. ' + this.data.cpnSeqNbr);
  }));
});
