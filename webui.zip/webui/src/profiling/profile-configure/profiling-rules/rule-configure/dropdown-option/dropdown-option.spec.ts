import { Mocks } from 'discovery-test';
import { DropdownOptionComponent } from './dropdown-option.component';

describe('DropdownOptionComponent', () => {
  let component: DropdownOptionComponent;

  beforeEach(() => {
    component = new DropdownOptionComponent();
    Mocks.MockProfileRuleModels[1].children.forEach((profileRule) => {
      if (profileRule.id === 'PHONE_NUMBER_ANALYSIS_RULE') {
        component.ruleConfigOption = profileRule.ruleConfigurationOptions[0];
        return;
      }
    });
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('test dropDownSelectionChanged', () => {
    spyOn(component.configuredOptionValuesChange, 'emit');
    const event = { value: 'dummyEventValue' };
    component.onDropDownSelectionChanged(event);
    expect(component.configuredOptionValues.size).toEqual(1);
    expect(component.configuredOptionValues.get(component.ruleConfigOption.id)).toEqual('dummyEventValue');
    expect(component.configuredOptionValuesChange.emit).toHaveBeenCalled();
  });

  it('test showRuleSettingsSideBar setter when true', () => {
    component.ruleConfigOption.configuredOptionValue = '';
    component.showRuleSettingsSideBar = true;
    expect(component.selectedOption).toBeDefined();

    component.ruleConfigOption.configuredOptionValue = 'dummyConfiguredValue';
    component.showRuleSettingsSideBar = true;
    expect(component.selectedOption).toEqual('dummyConfiguredValue');
    expect(component.ruleConfigOption).toBeDefined();
  });

  it('test showRuleSettingsSideBar setter when false', () => {
    component.showRuleSettingsSideBar = false;
    expect(component.selectedOption).toBeUndefined();
  });
});
