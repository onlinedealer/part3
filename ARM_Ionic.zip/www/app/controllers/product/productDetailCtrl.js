(function () {
    'use strict';

    angular.module('arm').controller('productDetailCtrl',
                ['$scope', '$state', '$filter', '$ionicModal', '$ionicSideMenuDelegate', 'productService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', '$cordovaFile', productDetailCtrl]);

    function productDetailCtrl($scope, $state, $filter, $ionicModal, $ionicSideMenuDelegate, productService, utility, MASTER_TABLE, GENERAL_CONFIG, $cordovaFile) {

        $scope.productDetails = productService.getSelectedProduct();
        $scope.title = $scope.productDetails.Name;

        for(var i=0;i<$scope.productDetails.Attachments.length;i++){
        	$scope.productDetails.Attachments[i].FilePathToDisplay = cordova.file.cacheDirectory + "productImages/"+$scope.productDetails.Attachments[i].AttachmentID+'.png' + '?' + new Date().getTime();
        }

        utility.busyCursorEnd();

        $scope.backPage = function () {
            $state.go('tab.product');
        }

        $scope.slideHasChanged = function(itemIndex){
        	$scope.productDetails.Attachments[itemIndex].FilePathToDisplay = cordova.file.cacheDirectory + "productImages/"+$scope.productDetails.Attachments[itemIndex].AttachmentID+'.png' + '?' + new Date().getTime();
        }
        
    };

})();