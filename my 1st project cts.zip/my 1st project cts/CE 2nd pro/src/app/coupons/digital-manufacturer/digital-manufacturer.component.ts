import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { CouponHelperService } from '../../services/coupon-helper.service';

@Component({
  selector: 'app-digital-manufacturer',
  templateUrl: './digital-manufacturer.component.html',
  styleUrls: ['./digital-manufacturer.component.scss']
})
export class DigitalManufacturerComponent implements OnInit {
  @Input() data: any;

  imagesPaths: Object = ImagePaths;
  serviceUrls: Object;
  somevalueerror;

  constructor(public couponHelperService: CouponHelperService) { }

  ngOnInit() {
    if(!this.data.imageUrlTxt){
      this.data.imageUrlTxt = this.imagesPaths['MFR_DEFAULT_IMAGE'];
    }
  }

  
  errorHandler(event) {
    event.target.src = this.imagesPaths['MFR_DEFAULT_IMAGE'];
  }

}
