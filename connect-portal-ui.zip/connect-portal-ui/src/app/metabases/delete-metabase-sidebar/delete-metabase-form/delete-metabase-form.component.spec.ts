import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Metabase } from '../../shared/metabase.model';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DeleteMetabaseFormComponent } from './delete-metabase-form.component';

describe('DeleteMetabaseFormComponent', () => {
  let component: DeleteMetabaseFormComponent;
  let fixture: ComponentFixture<DeleteMetabaseFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), RadioButtonModule, FormsModule, ReactiveFormsModule],
      declarations: [DeleteMetabaseFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteMetabaseFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return translation string for username', () => {
    component.metabase = { dataConnection: { id: 'abcd', connectionType: 'ORACLE' } } as Metabase;
    expect(component.userNameTranslationString).toBe('metabases.DELETE_DIALOG.FORM.USERNAME_ORACLE');
  });

  it('should return translation string for the admin information', () => {
    component.metabase = { dataConnection: { id: 'abcd', connectionType: 'ORACLE' } } as Metabase;
    expect(component.adminInfoTranslationString).toBe('metabases.DELETE_DIALOG.ORACLE_ADMIN_INFO');
  });

  it('should return empty string for the admin information if connection type is db2i', () => {
    component.metabase = { dataConnection: { id: 'abcd', connectionType: 'DB2I' } } as Metabase;
    expect(component.adminInfoTranslationString).toBe('');
  });

  it('should create form', () => {
    component.ngOnInit();
    expect(component.metabaseCredentialsForm as FormGroup).toBeTruthy();
    expect(component.metabaseCredentialsForm.get('removeConfigOnly').value).toBe(false);
  });

  it('should set form group value', () => {
    component.metabaseCredentialsForm = new FormGroup({ removeConfigOnly: new FormControl(false) });
    component.setDeleteMetabaseConfigValue(true);
    expect(component.metabaseCredentialsForm.get('removeConfigOnly').value).toBe(true);
  });

  it('should enable delete button if connection type is DB2I', () => {
    spyOn(component.primaryButtonStateChange, 'emit');
    const selectedMetabase = {
      name: 'test',
      dataConnection: {
        connectionType: 'DB2I'
      }
    };
    component.open(selectedMetabase);
    expect(component.primaryButtonStateChange.emit).toHaveBeenCalledWith(false);
  });

  it('should enable delete button if form is valid', () => {
    spyOn(component.primaryButtonStateChange, 'emit');
    component.metabase = {
      name: 'test',
      dataConnection: {
        connectionType: 'DB2I'
      }
    };
    component.metabaseCredentialsForm.patchValue({
      adminUserId: 'test',
      password: 'test',
      removeConfigOnly: false
    });
    expect(component.primaryButtonStateChange.emit).toHaveBeenCalledWith(false);
  });

  it('should set admin user id value if connection type is ORACLE', () => {
    const selectedMetabase = {
      name: 'test',
      dataConnection: {
        connectionType: 'ORACLE'
      }
    };
    component.open(selectedMetabase);
    expect(component.metabaseCredentialsForm.get('adminUserId').value).toEqual('SYS');
  });

  it('should set admin user id value if connection type is SQLSERVER', () => {
    const selectedMetabase = {
      name: 'test',
      dataConnection: {
        connectionType: 'SQLSERVER'
      }
    };
    component.open(selectedMetabase);
    expect(component.metabaseCredentialsForm.get('adminUserId').value).toEqual('sa');
  });

  it('should unsubscribe from observables on destroy', () => {
    spyOn(component.subscriptions, 'unsubscribe');
    component.ngOnDestroy();
    expect(component.subscriptions.unsubscribe).toHaveBeenCalled();
  });

  it('should reset form', () => {
    spyOn(component.metabaseCredentialsForm, 'patchValue');
    component.open({} as Metabase);
    expect(component.metabaseCredentialsForm.patchValue).toHaveBeenCalled();
  });
});
