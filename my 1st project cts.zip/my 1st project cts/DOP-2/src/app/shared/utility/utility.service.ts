import { Injectable } from '@angular/core';

@Injectable()
export class UtilityService {

  constructor() { }

  getCurrentENV() {
    let defaultEnv = 'PROD';

    const _envs = {
      PROD: {
        host: ['t.cvs.com', 'cdcprd1-csr.cvs.com', 'cdcprd2-csr.cvs.com', 'www.cvs.com', 'm.cvs.com']
      },
      IT1: {
        host: ['www-it1.cvs.com', 'm-it1.cvs.com']
      },
      IT2: {
        host: ['www-it2.cvs.com', 'm-it2.cvs.com']
      },
      IT3: {
        host: ['www-it3.cvs.com', 'm-it3.cvs.com', 'csc-it3.cvs.com', 'ri1cdcads3p-it3tools:30013']
      },
      QA1: {
        host: ['www-qa1.cvs.com', 'm-qa1.cvs.com','localhost:4200', 'csc-qa1.cvs.com', 'icet-sit1.cvs.com', 'localhost:8080', 'localhost:8082', '10.245.229.98:4200']
      },
      QA2: {
        host: ['icet-sit3.cvs.com', 'www-qa2.cvs.com', 'm-qa2.cvs.com', 'csc-qa2.cvs.com', 'rri1cdcads2p-qa2tools:30013']
      },
      QA3: {
        host: ['www-qa3.cvs.com', 'm-qa3.cvs.com', 'csc-qa3.cvs.com', 'icet-sit2.cvs.com']
      },
      QA4: {
        host: ['www-qa4.cvs.com', 'm-qa4.cvs.com', 'csc-qa4.cvs.com']
      },
      REG1: {
        host: ['www-reg1.cvs.com', 'm-reg1.cvs.com', 'csc-reg1.cvs.com']
      },
      REG2: {
        host: ['www-reg2.cvs.com', 'm-reg2.cvs.com', 'csc-reg2.cvs.com']
      },
      REG3: {
        host: ['www-reg3.cvs.com', 'm-reg3.cvs.com', 'csc-reg3.cvs.com']
      },
      REG4: {
        host: ['www-reg4.cvs.com', 'm-reg4.cvs.com', 'csc-reg4.cvs.com']
      },
      UAT1: {
        host: ['www-uat1.cvs.com', 'm-uat1.cvs.com', 'csc-uat1.cvs.com']
      },
      UAT2: {
        host: ['www-uat2.cvs.com', 'm-uat2.cvs.com', 'csc-uat2.cvs.com']
      },
      UAT3: {
        host: ['www-uat3.cvs.com', 'm-uat3.cvs.com', 'csc-uat3.cvs.com']
      },
      UAT4: {
        host: ['www-uat3.cvs.com', 'm-uat3.cvs.com', 'csc-uat3.cvs.com']
      },
      PT1: {
        host: ['cdcpt.cvs.com', 'm-cdcpt.cvs.com', 'www-pt1.cvs.com', 'm-pt1.cvs.com']
      },
      PT2: {
        host: ['www-pt2.cvs.com', 'm-pt2.cvs.com']
      }
    };

    const envParam = this.getQueryStringValue('env');
    if (!envParam) {
      var host = window.location.host;
      for (var env in _envs) {
        if (host.indexOf(env) > -1 || (typeof _envs[env].host === "string" && _envs[env].host === host) || (typeof _envs[env].host === "object" && _envs[env].host.indexOf(host) > -1)) {
          _env = env;
          return _env;
        } // if
      } //for
      return defaultEnv;
    } else {
      var _env = _envs[envParam];
      if (_env !== undefined)
        return envParam;
      else
        return defaultEnv;
    }

  }

  getQueryStringValue(key) {
    return (<any>window).unescape(window.location.search.replace(new RegExp("^(?:.*[&\\?]" + (<any>window).escape(key).replace(/[\.\+\*]/g, "\\$&") + "(?:\\=([^&]*))?)?.*$", "i"), "$1"));
  }

  getEncrypted(data): any {
    return btoa(data);
  }

  getDecrypted(data): any {
    return atob(data);
  }

  getUserAgent() {
    // Other
    const userAgentPickedUp = navigator.userAgent;
    let userAgent = 'DESKTOP';
    // ANDROID
    if (/Android/i.test(userAgentPickedUp)) {
      // ANDROID MOBILE
      if (/Mobile/i.test(userAgentPickedUp)) {
        userAgent = 'AND_MOBILE';
        // ANDROID GLASS
      } else if (/Glass/i.test(userAgentPickedUp)) {
        userAgent = 'AND_GLASS';
        // ANDROID TABLET
      } else {
        userAgent = 'AND_TABLET';
      }
      // iOS Mobile
    } else if (/iPhone|iPod/i.test(userAgentPickedUp)) {
      userAgent = 'IOS_MOBILE';
      // iOS Tablet
    } else if (/iPad/i.test(userAgentPickedUp)) {
      userAgent = 'IOS_TABLET';
      // Windows
    } else if (/IEMobile/i.test(userAgentPickedUp)) {
      userAgent = 'WIN_MOBILE';
      // Other identified vendor
    } else if (/webOS|BlackBerry|Opera Mini/i.test(userAgentPickedUp)) {
      userAgent = 'OTH_MOBILE';
    }
    return userAgent;
  }
}
