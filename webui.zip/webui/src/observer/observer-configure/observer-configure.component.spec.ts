import { TestBed } from '@angular/core/testing';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SelectSourceComponent } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { ObserverListingComponent } from 'observer/observer-listing/observer-listing.component';
import { of, throwError } from 'rxjs';
import { ObserverConfigureComponent } from './observer-configure.component';
import { ObserverDetailsComponent } from './observer-details/observer-details.component';

describe('ObserverConfigureComponent', () => {
  let component: ObserverConfigureComponent;
  let router: Router;
  let activateRoute: ActivatedRoute;

  beforeEach(() => {
    Spies.init();

    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: '', component: ObserverListingComponent },
          { path: 'observers/new/select-source', component: SelectSourceComponent },
          { path: 'observers/new/configure-observer', component: ObserverConfigureComponent }
        ])
      ]
    });

    router = TestBed.inject(Router);

    component = new ObserverConfigureComponent(
      router,
      Spies.ObserverService,
      Spies.TranslateService,
      Spies.ToastrService,
      Spies.ActivatedRoute,
      Spies.launchDarklyService
    );

    component.selectSourceComponent = new SelectSourceComponent(
      {} as any,
      Spies.ConnectionService,
      {} as any,
      {} as any,
      {} as any
    );
    component.observerDetailsComponent = new ObserverDetailsComponent(Spies.launchDarklyService);
    Spies.launchDarklyService.variation.and.returnValue(false);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('validation observer select source', () => {
    expect(component.validate()).toBe(false);
  });

  it('test ngOnInit with editMode success', () => {
    const mockUrlTree = router.parseUrl('/data-observability/observers/edit/2c9380837dbe23a9017dc7908e080001');
    // @ts-ignore: force this private property value for testing.
    router.currentUrlTree = mockUrlTree;
    component.observerId = Spies.ActivatedRoute.paramMap;
    spyOn(component, 'loadObserverById');
    Spies.ObserverService.getObserver.and.returnValue(of('dummy'));
    component.ngOnInit();
    expect(component.editMode).toBe(true);
  });

  it('test ngOnInit failure', () => {
    component.observerId = Spies.ActivatedRoute.paramMap;
    Spies.ObserverService.getObserver.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[2]));
    component.ngOnInit();
    expect(component.editMode).toBe(false);
  });
  it('test ngOnInit failure with 404 code', () => {
    component.observerId = Spies.ActivatedRoute.paramMap;
    Spies.ObserverService.getObserver.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.ngOnInit();
    expect(component.editMode).toBe(false);
    expect(Spies.ToastrService['error']).toHaveBeenCalled();
  });
  it('validation observer details', () => {
    component.activeIndex = 2;
    component.observerDetailsComponent.observerDetailForm = new NgForm([], []);
    expect(component.validate()).toBe(false);
  });
  it('test moveNext fn call', () => {
    component.validationFailures = new Set<string>();
    component.activeIndex = 0;
    spyOn(component, 'validate').and.returnValue(true);
    component.moveNext();
    expect(component.activeIndex).toBe(1);
  });
  it('test movePrev fn call', () => {
    component.activeIndex = 1;
    component.movePrevious();
    expect(component.activeIndex).toBe(0);
  });
  it('test cancel', () => {
    const spy = spyOn(router, 'navigateByUrl');
    component.cancelCreate();
    expect(spy.calls.first().args[0]).toBe('/data-observability/observers');
  });

  it('test save observer success', () => {
    spyOn(component, 'validate').and.returnValue(true);
    const spy = spyOn(router, 'navigateByUrl');
    Spies.launchDarklyService.variation.and.returnValue(true);
    Spies.ObserverService.saveObserver.and.returnValue(of('dummy'));
    component.saveObserver();
    expect(component.saveInProgress).toBe(false);
    expect(spy.calls.first().args[0]).toBe('/data-observability/observers');
  });
  it('test save observer failed at server side', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ObserverService.saveObserver.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.saveObserver();
    expect(component.saveInProgress).toBe(false);
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test save observer failed with response 409', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ObserverService.saveObserver.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[2]));
    component.saveObserver();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });

  it('test save observer failed with response 423', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ObserverService.saveObserver.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[3]));
    component.saveObserver();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test save observer failed with response 404', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ObserverService.saveObserver.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.saveObserver();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });

  it('load from settings', () => {
    component.observeConfigureModel.loadFromSettings(Mocks.MockProfiles[0]);
    expect(component.observeConfigureModel.name).toBe('Profile1');
    expect(component.observeConfigureModel.tables.length).toBe(1);
  });
  it('test disableActions event', () => {
    const result = false;
    component.disableActions(result);
    expect(component.isActionDisabled).toBe(result);
  });
});
