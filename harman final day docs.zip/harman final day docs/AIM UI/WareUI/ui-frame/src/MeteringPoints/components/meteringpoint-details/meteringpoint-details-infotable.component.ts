import { Component, Input, Output, EventEmitter } from "@angular/core";
import { MeteringPointDetails, Customer } from "../../models/meteringpoint.model";
import { Contract } from "../../models/contract.model";
import { TranslationsService } from "../../../app/services/translations-service";

@Component({
    selector: "landisgyr-meteringpoint-details-infotable",
    templateUrl: "./meteringpoint-details-infotable.component.html",
    styleUrls: ["./meteringpoint-details-infotable.component.scss"]
})
export class MeteringPointDetailsInfotableComponent {
    @Input() activeContract!: Contract;
    @Input() meteringPointCustomer!: Customer;
    @Input()
    set meteringPoint(meteringPoint: MeteringPointDetails) {
        this.mp = meteringPoint;
        this.formatAddress();
        this.formatFusesize();
        this.formattedControlDate = this.mp !== null ? this.mp.controlDate : undefined;
    }

    get meteringPoint(): MeteringPointDetails {
        return this.mp;
    }

    @Input()
    sideviewOpen!: boolean;

    @Output() contractsClick: EventEmitter<null> = new EventEmitter();
    @Output() customPropertiesClick: EventEmitter<null> = new EventEmitter();

    mp!: MeteringPointDetails;
    formattedControlDate: number | undefined = 0;

    fuseSize!: string;
    streetAddressStart!: string;
    streetAddressEnd!: string;
    allContracts = $localize`:|@@meteringpointDetailsInfotable.allContracts:All contracts`;
    customProperties = "";

    constructor(public translations: TranslationsService) {
        this.customProperties = this.translations.getTranslation("Custom properties");
    }

    onContractsClick() {
        this.contractsClick.emit();
    }
    custompropertiesclick() {
        this.customPropertiesClick.emit();
    }
    formatAddress() {
        if (this.meteringPoint && this.meteringPoint.address) {
            const address = this.meteringPoint.address;
            let street = address.streetName ? address.streetName : "";
            street += address.streetNumber ? " " + address.streetNumber : "";
            street += address.streetNumberExtension ? " " + address.streetNumberExtension : "";
            street += address.apartment ? " " + address.apartment : "";
            this.streetAddressStart = street = street.trim().replace(" +", " ");

            let post = address.postalCode ? address.postalCode : "";
            post += address.areaName ? " " + address.areaName : "";
            post += address.city ? " " + address.city : "";
            post += address.countryCode ? " " + address.countryCode : "";
            this.streetAddressEnd = post = post.trim().replace(" +", " ");

            return street && post ? street + "\n" + post : street + post;
        }
    }

    formatFusesize() {
        if (this.meteringPoint && this.meteringPoint.phase && this.meteringPoint.fuseSize) {
            this.fuseSize = this.meteringPoint.phase + " x " + this.meteringPoint.fuseSize + " A";
        } else {
            this.fuseSize = "";
        }
    }
}
