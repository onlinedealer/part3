import axios from 'axios'
import config from '../config/apiConfig'
import { getPayload, getKey } from 'react-oauth-openid'

const token = getKey('id_token')
const idPayload = getPayload('id_token')

export function getService (serviceName, memberOf, userId) {
  const getUrl = config.grouper.commonPath + serviceName
  return axios.get(getUrl, {
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': idPayload.memberof,
      'X-TGT-LANID': idPayload.samaccountname,
    },
  })
    .then(resp => {
      return resp.data
    })
}

export function postService (input, serviceName, memberOf, userId) {
  const postUrl = config.grouper.commonPath + serviceName
  if (token === null) {
    window.location.reload()
  }
  return axios.post(postUrl, input, {
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': idPayload.memberof,
      'X-TGT-LANID': idPayload.samaccountname,
    },
  })
    .then(resp => {
      return resp.data
    })
}

export function putService (input, serviceName, memberOf, userId) {
  const putUrl = config.grouper.commonPath + serviceName
  return axios.put(putUrl, input, {
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': idPayload.memberof,
      'X-TGT-LANID': idPayload.samaccountname,
    },
  })
    .then(resp => {
      return resp.data
    })
}

export function deleteService (input, serviceName, memberOf, userId) {
  const deleteUrl = config.grouper.commonPath + serviceName + '?group_type=' + input.group_type + '&group_id=' + input.group_id
  return axios.delete(deleteUrl, { data: input,
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': idPayload.memberof,
      'X-TGT-LANID': idPayload.samaccountname,
      'Content-Type': 'application/json',
    },
  })
    .then(resp => {
      return resp.data
    })
}
