import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { BulkColumnMappingSidebarComponent } from './bulk-column-mapping-sidebar.component';

describe('BulkColumnMappingSidebarComponent', () => {
  let component: BulkColumnMappingSidebarComponent;
  let fixture: ComponentFixture<BulkColumnMappingSidebarComponent>;
  @Component({
    selector: 'p-connect-sidebar',
    template: '',
    providers: [
      {
        provide: SidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    open() {}
    close() {}
    parseHttpClientResponseMessage() {}
  }
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [BulkColumnMappingSidebarComponent, MockSidebarComponent],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: '' } }]
    }).compileComponents();
    fixture = TestBed.createComponent(BulkColumnMappingSidebarComponent);
    component = fixture.componentInstance;
    component.checkedItems = [{}];
    component.displayValues = [{}];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should open sidebar', () => {
    const openSidebar = spyOn(component.sidebar, 'open');
    component.changeColumnMappingClicked();
    expect(openSidebar).toHaveBeenCalled();
  });
  it('should close sidebar', () => {
    const closeSidebar = spyOn(component.sidebar, 'close');
    component.close();
    expect(component.selectedAction).toEqual('DO_NOT_CHANGE');
    expect(component.selectedCase).toEqual('SOURCE_NAME');
    expect(component.selectedTargetColumnName.length).toBe(0);
    expect(closeSidebar).toHaveBeenCalled();
  });
  it('should change the bulkColumnMappingObj', () => {
    const outputSpy = spyOn(component.bulkMappingObjChange, 'emit');
    component.selectedAction = 'Copy';
    component.selectedCase = 'UPPERCASE';
    component.selectedTargetColumnName = [];
    component.primaryButtonClicked();
    expect(component.bulkMappingObj).toEqual({ action: 'Copy', targetColumnName: [], case: 'UPPERCASE' });
    expect(outputSpy).toHaveBeenCalled();
  });
  it('should filter patterns', () => {
    const event1 = { code: 's', name: 's', query: 's' };
    component.filterTargetColumnName(event1);
    expect(component.filteredTargetColumnNames.length).toBe(1);
  });
  it('should handle manual input', () => {
    const event = { target: { value: 'somthing' }, which: 13 };
    component.selectedTargetColumnName = [{ code: 'omthing', value: 'somthing' }];
    component.handleManualInput(event);
    expect(component.selectedTargetColumnName.length).toBeGreaterThan(0);
  });
  it('should set multipleEnable to false if selected item is do-not-change', () => {
    component.selectedTargetColumnName = [{ code: 'DO_NOT_CHANGE' }];
    component.onSelect(component.selectedTargetColumnName);
    expect(component.multipleEnable).toBe(false);
  });
  it('should set multipleEnable to true if selected item is source-column', () => {
    component.selectedTargetColumnName = [{ code: 'SOURCE_COLUMN' }];
    const event = { code: 'SOURCE_COLUMN' };
    component.onSelect(event);
    expect(component.multipleEnable).toBe(true);
  });
  it('should set multipleEnable to false if selected item returns single object and selection is target column', () => {
    component.selectedTargetColumnName = { code: 'DO_NOT_CHANGE' };
    const event = { code: 'DO_NOT_CHANGE' };
    component.onSelect(event);
    expect(component.multipleEnable).toBe(false);
  });
  it('should set multipleEnable to true if selected item returns single object and selection is source column', () => {
    component.selectedTargetColumnName = { code: 'SOURCE_COLUMN' };
    const event = { code: 'SOURCE_COLUMN' };
    component.onSelect(event);
    expect(component.multipleEnable).toBe(true);
  });
});
