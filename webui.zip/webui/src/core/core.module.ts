import { NgModule } from '@angular/core';

/**
 * CoreModule is a conventional name for an NgModule with providers for the singleton services you load
 * when the application starts.
 *
 * This module houses models and providers that are used throughout the application (i.e. they are not
 * component specific).
 *
 * Import CoreModule in the root AppModule only. Never import CoreModule in any other module.
 */

@NgModule({
  imports: [],
  declarations: [],
  exports: []
})
export class CoreModule {}
