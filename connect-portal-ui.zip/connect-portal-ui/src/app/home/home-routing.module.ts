import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgentsHomeComponent } from './agents-home/agents-home.component';
import { ServersHomeComponent } from './servers-home/servers-home.component';
import { PipelinesHomeComponent } from './pipelines-home/pipelines-home.component';
import { HomeComponent } from './home.component';
import { ProjectsHomeComponent } from './projects-home/projects-home.component';

const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    children: [
      {
        path: '',
        redirectTo: 'home/pipeline'
      },
      {
        path: 'home/agent',
        component: AgentsHomeComponent
      },
      {
        path: 'home/server',
        component: ServersHomeComponent
      },
      {
        path: 'home/project',
        component: ProjectsHomeComponent
      },
      {
        path: 'home/pipeline',
        component: PipelinesHomeComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HomeRoutingModule {}
