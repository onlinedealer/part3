import { LogManagerService } from './log-manager.service';

describe('LogManagerService', () => {
  let logManager: LogManagerService;

  beforeEach(() => {
    logManager = new LogManagerService();
  });

  it('should be created', () => {
    expect(logManager).toBeTruthy();
  });

  it('should be able to set DEBUG log level', () => {
    logManager.setLevel('DEBUG');
    expect(logManager.getLevel()).toBe('DEBUG');
  });

  it('should be able to set INFO log level', () => {
    logManager.setLevel('INFO');
    expect(logManager.getLevel()).toBe('INFO');
  });

  it('should be able to set WARN log level', () => {
    logManager.setLevel('WARN');
    expect(logManager.getLevel()).toBe('WARN');
  });

  it('should be able to set ERROR log level', () => {
    logManager.setLevel('ERROR');
    expect(logManager.getLevel()).toBe('ERROR');
  });

  it('should be able to set OFF log level', () => {
    logManager.setLevel('OFF');
    expect(logManager.getLevel()).toBe('OFF');
  });

  it('setLevel() should throw error on invalid log level', () => {
    expect(() => {
      logManager.setLevel('FOO');
    }).toThrow();
  });

  it('should be able to get/set log level via "spectrum" global', () => {
    (window as any).spectrum.core.log.level('DEBUG');
    expect((window as any).spectrum.core.log.level()).toBe('DEBUG');

    (window as any).spectrum.core.log.level('INFO');
    expect((window as any).spectrum.core.log.level()).toBe('INFO');

    (window as any).spectrum.core.log.level('WARN');
    expect((window as any).spectrum.core.log.level()).toBe('WARN');

    (window as any).spectrum.core.log.level('ERROR');
    expect((window as any).spectrum.core.log.level()).toBe('ERROR');

    (window as any).spectrum.core.log.level('OFF');
    expect((window as any).spectrum.core.log.level()).toBe('OFF');
  });

  it('should be able to get logger', () => {
    const logger = logManager.getLogger('foo');
    expect(logger).toBeTruthy();
  });

  it('should be able to get logger with undefined type', () => {
    const logger = logManager.getLogger(undefined);
    expect(logger).toBeTruthy();
  });
});
