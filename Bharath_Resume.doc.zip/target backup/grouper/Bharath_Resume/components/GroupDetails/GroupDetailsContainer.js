import React from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Helmet } from 'react-helmet'
import HeaderTitle from '../Header/HeaderTitle'
import GroupDetails from './GroupDetails'
import { getGroupDetails, removeTcins, updateGroupName, updateItemsOrder, clearActionTypes, updateVariationGroupName, updateVariationDetails, setVariationDetails, sendUpdateGroupVariationDetails, setGroupDetails, changeCollectionPublishStatus } from '../../store/GroupDetails/actionCreator'
import { getItemThemes, getCollectionMtas, getFixedThemes, addGroup } from '../../store/Dashboard/actionCreator'

class GroupDetailsContainer extends React.Component {
  componentWillMount () {
    let urlStr = window.location.pathname
    if (urlStr.indexOf('group-details') !== -1) {
      this.props.getGroupDetails(this.props.match.params.groupId, this.props.auth.memberOf, this.props.auth.lanId, 'load')
      this.props.getFixedThemes()
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.dashboardRequestType) {
      if (nextProps.dashboardRequestType === 'ADD') {
        window.location.replace('group-details/' + nextProps.recentAddedGroup)
      }
    }
  }

  render () {
    return (
      <div>
        <HeaderTitle title="Group Details" />
        <Helmet>
          <title>{this.props.headerTitle}</title>
        </Helmet>
        <GroupDetails
          auth={this.props.auth}
          groupDetails={this.props.groupDetails}
          itemThemes={this.props.itemThemes}
          requestType={this.props.requestType}
          groupDetailsErrorTcins={this.props.groupDetailsErrorTcins}
          loadingBtnStatus={this.props.loadingBtnStatus}
          removeTcins={this.props.removeTcins}
          updateGroupName={this.props.updateGroupName}
          updateItemsOrder={this.props.updateItemsOrder}
          clearActionTypes={this.props.clearActionTypes}
          getItemThemes={this.props.getItemThemes}
          getCollectionMtas={this.props.getCollectionMtas}
          collectionMTAs={this.props.collectionMTAs}
          history={this.props.history}
          variationPage1Data={this.props.variationPage1Data}
          updateVariationGroupName={this.props.updateVariationGroupName}
          fixedThemes={this.props.fixedThemes}
          updateVariationDetails={this.props.updateVariationDetails}
          setVariationDetails={this.props.setVariationDetails}
          addGroup={this.props.addGroup}
          sendUpdateGroupVariationDetails={this.props.sendUpdateGroupVariationDetails}
          setGroupDetails={this.props.setGroupDetails}
          changeCollectionPublishStatus={this.props.changeCollectionPublishStatus}
        />
      </div>
    )
  }
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getGroupDetails,
    removeTcins,
    updateGroupName,
    updateItemsOrder,
    clearActionTypes,
    getItemThemes,
    getCollectionMtas,
    updateVariationGroupName,
    updateVariationDetails,
    getFixedThemes,
    setVariationDetails,
    addGroup,
    sendUpdateGroupVariationDetails,
    setGroupDetails,
    changeCollectionPublishStatus,
  }, dispatch)

const mapStateToProps = state => ({
  auth: state.get('auth').toJS(),
  groupDetails: state.getIn(['GroupDetails', 'groupDetails']).toJS(),
  headerTitle: state.getIn(['layout', 'headerTitle']),
  itemThemes: state.getIn(['grouperDashboard', 'itemThemes']).toJS(),
  requestType: state.getIn(['GroupDetails', 'requestType']),
  groupDetailsErrorTcins: state.getIn(['GroupDetails', 'groupDetailsErrorTcins']).toJS(),
  loadingBtnStatus: state.getIn(['Snackbar', 'loadingBtnStatus']).toJS(),
  collectionMTAs: state.getIn(['grouperDashboard', 'collectionMTAs']).toJS(),
  variationPage1Data: state.getIn(['grouperDashboard', 'variationPage1Data']).toJS(),
  fixedThemes: state.getIn(['grouperDashboard', 'fixedThemes']).toJS(),
  dashboardRequestType: state.getIn(['grouperDashboard', 'requestType']),
  recentAddedGroup: state.getIn(['grouperDashboard', 'recentAddedGroup']),
})

export default connect(mapStateToProps, mapDispatchToProps)(GroupDetailsContainer)
