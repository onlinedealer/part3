import { WarningAlertModel } from '../warning-alert.model';
import { AlertAgainstTypeEnum } from './alert-against-type.enum';

export class ThresholdBasedModel {
  alertAgainst: AlertAgainstTypeEnum;
  movingAverage: number;
  warningAlerts: WarningAlertModel;
  constructor() {
    this.warningAlerts = new WarningAlertModel();
  }
}
