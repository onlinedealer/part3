import { Injectable, NgZone } from '@angular/core';
import { Observable } from 'rxjs';
import { AuthenticationService } from './authentication.service';
import { EventSourcePolyfill } from 'event-source-polyfill';

@Injectable({
  providedIn: 'root'
})
export class ServerSentEventsService {
  events = {};

  constructor(private _zone: NgZone, private authenticationService: AuthenticationService) {}

  getServerSentEvent(url: string): Observable<any> {
    return new Observable((observer) => {
      const eventSource = this.getEventSource(url);
      this.events[url] = eventSource;
      eventSource.onmessage = (event) => {
        this._zone.run(() => {
          observer.next(JSON.parse(event.data));
        });
      };
      eventSource.onerror = (error) => {
        this._zone.run(() => {
          observer.error(error);
        });
      };
    });
  }

  closeSSEConnection(url: string) {
    if (this.events[url] !== null) {
      const eventSource: EventSource = this.events[url];
      eventSource.close();
    }
  }

  private getEventSource(url: string): EventSource {
    return new EventSourcePolyfill(url, {
      headers: {
        Authorization: 'Bearer ' + this.authenticationService.getToken()
      }
    });
  }
}
