(function () {
    'use strict';

    angular.module('arm').service('utility',
        ['$http', 'localStorageService', '$filter', 'focus', 'sqliteService', 'MASTER_TABLE', 'GENERAL_CONFIG', 'ALERT_MESSAGE', '$ionicHistory','$rootScope','$cordovaDialogs', '$ionicLoading','$q','$cordovaFile','$window',utility]);
    function utility($http, localStorageService, $filter, focus, sqliteService, MASTER_TABLE, GENERAL_CONFIG, ALERT_MESSAGE, $ionicHistory, $rootScope, $cordovaDialogs,$ionicLoading,$q,$cordovaFile,$window) {
        var serArr = this;
        serArr.lagType = '';
        var key = CryptoJS.enc.Utf8.parse('AMINHAKEYTEM32NYTES1234567891234');
        var iv = CryptoJS.enc.Utf8.parse('7061737323313233');

        var dateFormat = 'dd-MM-yyyy';
        var dateFormatMMDDYYYY = 'MM-dd-yyyy';
        var dateFormat_2 = 'yyyy-MM-dd';

        //encrypt the data
        serArr.encrypt = function (data) {
            var PlainText = JSON.stringify(data);
            try {

                var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(PlainText), "a16byteslongkey!a16byteslongkey!", key,
                {
                    keySize: 128,
                    iv: iv,
                    mode: CryptoJS.mode.CBC,
                    padding: CryptoJS.pad.Pkcs7
                });
                return encrypted.toString();
            }
            catch (err) {
                return "";
            }
        }

        //decrypt the data
        serArr.decrypt = function (encryptedData) {
            var decryptedText = null;
            try {
                var decrypted = CryptoJS.AES.decrypt(encryptedData.finalData, "a16byteslongkey!a16byteslongkey!", key,
                {
                    keySize: 128,
                    iv: iv,
                    mode: CryptoJS.mode.CBC,
                    padding: CryptoJS.pad.Pkcs7
                });
                return angular.fromJson(decrypted.toString(CryptoJS.enc.Utf8));
            }
            catch (err) {
                return "";
            }
        }

        //stored the whole master data as per request
        serArr.storeMasterData = function (objArr) {
            angular.forEach(objArr, function (obj, key) {
            if(angular.isArray(obj) && obj.length > 0)
            {
                serArr.removeMasterDataByKey(key);
            }
            if (localStorageService.get(key) == null)
                localStorageService.set(key, obj);

            });
        }

        //set the master data
        serArr.setMasterData = function (key, data) {
            localStorageService.set(key, data);
        }

        //get the master data as per key
        serArr.getMasterDataByKey = function (key) {
            if(localStorageService.get(key) == 'true' || localStorageService.get(key) == 'TRUE')
                return true;
            else if(localStorageService.get(key) == 'false' || localStorageService.get(key) == 'FALSE')
                return false;

            return localStorageService.get(key);
        }

        //get the master data as per key
        serArr.removeMasterDataByKey = function (key) {
            localStorageService.remove(key);
        }

        serArr.getNameFromMultLangMasData = function(array,value)
        {
            var name = '';
            angular.forEach(array, function (obj) {
                if (obj.Value == value)
                {
                    name = obj.Text;
                }
            });
            return name;
        }
        //get the data for fill the DDL
        serArr.getMultLangMasData = function (key) {
            var objCol = serArr.getMasterDataByKey(key);
            var retCol = [];
            var obj = new Object();
            for (var i = 0; i < objCol.length; i++) {
                var colName = key + 'ID';
                objCol[i].Value = objCol[i][colName];
                var txt = '';
                if (serArr.lagType == 'OL1') {
                    txt = objCol[i]['Name_OL1'];
                }
                else if (serArr.lagType == 'OL2') {
                    txt = objCol[i]['Name_OL2'];
                }
                else {
                    txt = objCol[i]['Name'];
                }
                objCol[i].Text = txt;
            }
            return objCol;
        }

        //get the textbox value as per type
        function GetText(obj, indx, type, val) {
            if (val != '') return val;
            if (serArr.lagType == type) {
                var typeCheck = type === '' ? '' : '_' + type;
                var colName = 'Name' + typeCheck;
                return obj[indx][colName];
            }
            return "";
        }

        //*get the date wwith UTC
        serArr.getTimeUTC = function (date) {
            //console.log(date);

            var appDate = date + " UTC";
            return $filter('date')(new Date(appDate), 'hh:mm a');
        }

        //*get the date wwith UTC
        serArr.getCurrentDateUTC = function (date) {
            //console.log(date);

            var appDate = date + " UTC";
            return $filter('date')(new Date(appDate), dateFormat);
        }

        //convert the time
        serArr.convertTimeFormat = function (time) {
            if (time == null || time == '' || time == 'undefined') return '';
            // Check correct time format and split into components
            time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

            if (time.length > 1) { // If time format correct
                time = time.slice(1);  // Remove full string match value
                time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
                time[0] = +time[0] % 12 || 12; // Adjust hours
            }
            return time.join(''); // return adjusted time or original string
        }


        //get the date format but pass input type string date
        serArr.getDateStringFormat = function (inputStr) {
            if (inputStr == null || inputStr == '' || inputStr == 'undefined') return '';
            var dsplit = inputStr.split("-");
            var dt = new Date(dsplit[0], dsplit[1] - 1, dsplit[2]);
            return $filter('date')(new Date(dt), dateFormat);
        }

        //*returns Date(yyyy-mm-dd) for Activity
        serArr.saveDateStringUTC = function (inputStr) {
            if (inputStr == null || inputStr == '' || inputStr == 'undefined') return '';
            var dsplit = inputStr.split("-");
            var dt = new Date(dsplit[2], dsplit[1] - 1, dsplit[0]);
            var appDate = dt + " UTC";
            return $filter('date')(new Date(appDate), dateFormat_2);
        }

        //*get the date format but pass the input type date
        serArr.saveDateUTC = function (inputdate) {
            if (inputdate == null || inputdate == '' || inputdate == 'undefined') return '';
            var appDate = inputdate + " UTC";
            return $filter('date')(new Date(appDate), dateFormat_2);
        }

        //get date string from Date in UTC
        serArr.getDateStringInUTC = function (date) {
            return date.toUTCString();
        }

        //get UTC date from String
        serArr.getLocalDateFromUTC = function (dateString) {
            return new Date(dateString);
        }

        // remove white spaces in string
        serArr.removeWhitespace = function (string) {
            if(string!=null && string.length>0)
                return string.trim();
            else return '';

        }

        //get the date current date
        serArr.currentdate = function () {
            return $filter('date')(new Date(), dateFormat);
        }

        //get the date format
        serArr.getDateInDisplayFormat = function (date) {
            return $filter('date')(new Date(date), dateFormat);
        }

        //get the date format to send to the server
        serArr.getDateInServerFormat = function (date) {
            if (date == null || date == '' || date == 'undefined') return '';
            var dsplit = date.split("-");
            var dt = new Date(dsplit[2], dsplit[1] - 1, dsplit[0]);
            return $filter('date')(dt, dateFormat_2);
        }

        // get the date format to send to the server from todays date
        serArr.getDateInServerFormatFromToday = function (date) {
            if (date == null || date == '' || date == 'undefined') return '';
            return $filter('date')(date, dateFormat_2);
        }

        //get the date format to send to the server
        serArr.getDateInDisplayFormatFromServerDate = function (date) {
            if (date == null || date == '' || date == 'undefined') return '';
            var dsplit = date.split("-");
            var dt = new Date(dsplit[0], dsplit[1] - 1, dsplit[2]);
            return $filter('date')(dt, dateFormat);
        }

        //get the datetime format
        serArr.getDateTimeInDisplayFormat = function (date) {
            if (date == null || date == '' || date == 'undefined') return;
            return $filter('date')(new Date(date), 'dd-MM-yyyy | hh:mm a');
        }

        //get the datetime format
        serArr.getDateOnlyDisplayFormat = function (date) {
            if (date == null || date == '' || date == 'undefined') return;
            return $filter('date')(new Date(date), 'dd-MM-yyyy');
        }

        //get the datetime format for notes
        serArr.getDateTimeInDisplayFormatForNotes = function (date) {
            if (date == null || date == '' || date == 'undefined') return;
            return $filter('date')(new Date(date), 'dd-MM-yyyy, hh:mm a');
        }

        //convert mon to number
        serArr.monthNameToNum = function (monthName) {
            var myDate = new Date(monthName + " 1, 2000");
            var monthDigit = myDate.getMonth();
            return isNaN(monthDigit) ? 0 : (monthDigit + 1);
        }

        //set multiple lang
        serArr.setlang = function (type) {
            serArr.lagType = type;
        }

        //date the cal as per days/week/month
        serArr.dateCal = function (inputDate, inputVal, inType) {
            var dt = new Date();
            if (inType == 'M') {
                dt.setDate(inputDate.getDate());
                dt.setMonth(inputDate.getMonth() + inputVal);
            }
            else {
                dt.setDate(inputDate.getDate() + inputVal);
                dt.setMonth(dt.getMonth());
            }
            var count = 0, idnx = 0;
            var chkDates = ["FRI", "SAT"];
            var curD = ("0" + dt.getDate()).slice(-2);
            var day = dt.getDay();
            var dates = ["SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"];
            for (var indx = 0; indx <= chkDates.length; indx++) {
                if (chkDates[indx] == dates[day] && indx == 0) {
                    count = chkDates.length;
                }
                else if (chkDates[indx] == dates[day] && indx == 1) {
                    count = 1;
                }
            }
            dt.setDate(dt.getDate() + count);
            return dt;
        }

        serArr.getNextContactDate = function (tierId) {
             var curDt = new Date();
            if (tierId == 0 || tierId == '' || typeof tierId == 'undefined') return serArr.getDateStringInUTC(curDt);
            var tier = serArr.getMultLangMasData(MASTER_TABLE.ConTier);
            var filterTier = serArr.getObjData(tier, 'TierID', tierId);

            if (filterTier.length == 0) return serArr.getDateStringInUTC(curDt);
            if (filterTier[0].ReminderUnit == 'Months') {
                var m = curDt.getMonth() + filterTier[0].ReminderDurationInDays;
                curDt.setMonth(m);
                //curDt.setDate(curDt.getDate());
            }
            else {
                var d = curDt.getDate() + filterTier[0].ReminderDurationInDays;
                //curDt.setMonth(curDt.getMonth());
                curDt.setDate(d);
            }
            //var curDateArr = curDt.getDate() + curDt.toString().split("-");

            //curDt.setFullYear(curDt.getYear(), (curDt.getMonth() - 1), curDt.getDate());
            return serArr.getDateStringInUTC(curDt);
        }

        //Update the model with collection
        serArr.syncModelWithCollection = function (srcObject, destObject) {
            for (var key in destObject) {
                if (destObject.hasOwnProperty(key) && srcObject.hasOwnProperty(key)) {
                    ////console.log('inside if');
                    if(srcObject[key] == 'true')
                    {
                        srcObject[key] = true;
                    }else if(srcObject[key] == 'false')
                    {
                        srcObject[key] = false;
                    }

                    if(srcObject[key] == 'null' || srcObject[key] == 'NULL'){
                        srcObject[key] = null;
                    }
                    destObject[key] = srcObject[key];
                }
            }
            return destObject;
        }

        // Update the model without inner collection

        serArr.syncModelWithoutInnerCollection = function (srcObject, destObject) {
            for (var key in destObject) {
                if (destObject.hasOwnProperty(key) && srcObject.hasOwnProperty(key)) {
                    ////console.log('inside if');
                    if(!(angular.isArray(destObject[key]))){
                        if(srcObject[key] == 'true')
                            {
                                srcObject[key] = true;
                            }else if(srcObject[key] == 'false')
                            {
                                srcObject[key] = false;
                            }

                            if(srcObject[key] == 'null' || srcObject[key] == 'NULL'){
                                srcObject[key] = null;
                            }
                            destObject[key] = srcObject[key];
                    }
                }
            }
            return destObject;
        }

        serArr.validate = function (value, directiveCall, alertExtension, valFlag) {
            //alert('common validation flag'+commonValidationFlag+'and'+value);
            if (valFlag) {
                if (value == '') {
                    alert("enter the value");
                    directiveCall();
                    //$cordovaDialogs.alert('Please enter the ' + alertExtension, 'Contacts', 'OK').then(function () {
                    //    // callback success
                    //    directiveCall();
                    //});
                    valFlag = false;
                }
            }
            return valFlag;
        }

        serArr.checkExitingList = function (selLst, tarLst) {
            var isFlag = true;
            angular.forEach(selLst, function (obj, key) {
                if (tarLst.UserName == obj.UserName) {
                    isFlag = false;
                }
            });
            return isFlag;
        }
        serArr.getCurrentLoc = function() {
                var curAt = '';
                var options = {
                    enableHighAccuracy: true,
                    timeout: 5000,
                    maximumAge: 0
                };
                navigator.geolocation.getCurrentPosition(function (position) {
                    curAt = position.coords.latitude + ' ' + position.coords.longitude;
                    return curAt;
                }, function () { }, options);
            }
        //get the name as owner or creator
        serArr.getNameByOrOwner = function (obj) {
            var name = "";
            var loginInfo = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            if(loginInfo.UserID != obj.OwnerID){
                var dispOwnerName = serArr.removeWhitespace(obj.OwnerName);
                if(dispOwnerName=="" || dispOwnerName=='null' || dispOwnerName==null || typeof dispOwnerName==undefined)
                    name = "";
                else name = "Owner : " + dispOwnerName;
            }else if(loginInfo.UserID != obj.CreatorID){
                var dispCreatorName = serArr.removeWhitespace(obj.CreatorName);
                if(dispCreatorName=="" || dispCreatorName=='null' || dispCreatorName==null || typeof dispCreatorName==undefined)
                    name = "";
                else name = "By : " + dispCreatorName;
            }else{
                name = "";
            }
            return name;
        }
        //get the name as by creator
        serArr.getNameByForNotes = function (obj) {
            var name = "";
            var loginInfo = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            if(loginInfo.UserID != obj.CreatorID){
                var dispCreatorName = serArr.removeWhitespace(obj.CreatorName);
                if(dispCreatorName=="" || dispCreatorName=='null' || dispCreatorName==null || typeof dispCreatorName==undefined)
                    name = "";
                else name = "By : " + dispCreatorName;
            }else{
                name = "";
            }
            return name;
        }

        serArr.updateUserList = function (lst, selLst) {
            angular.forEach(lst, function (obj, key) {
                var indx = -1;
                indx = selLst.indexOf(obj);
                if (indx >= 0)
                    obj.IsChecked = true;
                else
                    obj.IsChecked = false;
            });
        }

        serArr.selectedUserList = function (lst, selLst) {
            angular.forEach(lst, function (obj, key) {
                var indx = -1;
                indx = selLst.indexOf(obj);
                if (obj.IsChecked) {
                    if (indx < 0)
                        selLst.push(obj);
                }
                else {
                    if (indx >= 0)
                        selLst.splice(indx, 1);
                }
            });
        }

        serArr.editSelUserList = function (lst, objSel, exitingArr) {
            var flag = false;
            angular.forEach(exitingArr, function (obj, key) {
                if ((objSel.UserID == obj.AttendeeID && obj.Type == 'UP') ||
                    (objSel.AttendeeDeviceObjID == obj.AttendeeDeviceObjID && obj.Type == 'CP')) {
                    objSel.IsChecked = true;
                    objSel.EntityAttendeeID = obj.EntityAttendeeID;
                    objSel.DeviceObjID = obj.DeviceObjID;
                    lst.push(objSel);
                }
            });
        }

        serArr.updateContactUserList = function (lst, selLst, switchFlag) {
            angular.forEach(lst, function (obj, key) {
                var indx = -1;
                indx = selLst.indexOf(obj);
                if (indx >= 0)
                    obj.IsChecked = true;
                else
                    obj.IsChecked = false;
                if(switchFlag){
                    if (indx >= 0){
                        if(obj.AccessCategoryID == GENERAL_CONFIG.AccessCategory.FullAccess){
                            obj.IsSwitchOn = true;
                        }else if(obj.AccessCategoryID == GENERAL_CONFIG.AccessCategory.RestrictedAccess){
                            obj.IsSwitchOn = false;
                        }
                    }else{
                        obj.IsSwitchOn=false;
                    }
                }
            });
        }

        serArr.selectedContactUserList = function (lst, selLst, switchFlag) {
            angular.forEach(lst, function (obj, key) {
                var indx = -1;
                indx = selLst.indexOf(obj);
                if (obj.IsChecked) {
                    if(switchFlag){
                        if(obj.IsSwitchOn==true){
                            obj.AccessCategoryID = GENERAL_CONFIG.AccessCategory.FullAccess;
                        }else{
                            obj.AccessCategoryID = GENERAL_CONFIG.AccessCategory.RestrictedAccess;
                        }
                    }
                    if (indx < 0)
                        selLst.push(obj);
                }
                else {
                    if (indx >= 0)
                        selLst.splice(indx, 1);
                    obj.IsSwitchOn=false;
                }
            });
        }

        function containsObject(obj, list) {
            var i;
            for (i = 0; i < list.length; i++) {
                if (list[i].FieldID === obj.FieldID) {
                    return i;
                }
            }
            return -1;
        }

        serArr.updateFieldList = function (lst, selLst) {
            angular.forEach(lst, function (obj, key) {
                var indx = -1;
                indx = containsObject(obj, selLst);
                if (indx < 0)
                    obj.FieldValue = '';
                else
                    obj.FieldValue = selLst[indx].FieldValue;
            });
        }



        serArr.selectedFieldList = function (lst, selLst) {
            angular.forEach(lst, function (obj, key) {
                var indx = -1;
                indx = containsObject(obj, selLst);
                if (obj.FieldValue != '') {
                    if (indx < 0) {
                        var newObj = angular.copy(obj);
                        selLst.push(newObj);
                    } else {
                        selLst[indx].FieldValue = obj.FieldValue;
                    }
                }
                else {
                    if (indx >= 0)
                        selLst.splice(indx, 1);
                }
            });
        }

        serArr.commonValidationStatic = function (inputVal, valFlag, inputId, msg) {
            if (valFlag) {
                if (inputVal == '') {
                    $cordovaDialogs.alert('Please enter the ' + msg, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                    .then(function() {
                     // callback success
                    });
                    focus(inputId);
                    return false;
                } else {
                    return true;
                }
            }

        }

        serArr.commonValidation = function (inputVal, valFlag, msg) {
            if (valFlag) {
                if (inputVal == '') {
                    $cordovaDialogs.alert('Please enter the ' + msg, 'Sales ARM', 'OK')
                    .then(function() {
                     // callback success
                    });
                    return false;
                } else {
                    return true;
                }
            }

        }

        serArr.commonValidationDynamic = function (fielddb) {
            var valFlag = true;
            for (var i = 0; i < fielddb.length; i++) {
                if (fielddb[i].FieldValue == '' && fielddb[i].IsMandatory) {
                    $cordovaDialogs.alert('Please enter the mandatory fields.', 'Sales ARM', 'OK')
                    .then(function() {
                     // callback success
                        //focus(fielddb[i].FieldName);
                        //$scope.$broadcast(fielddb[i].Name);
                    });
                    valFlag = false;
                    break;
                }
            }
            return valFlag;
        }

        // Deal Stage Model ID Check

        serArr.dealStageModelIDCheck = function(dealStageID){
            var dealStages = serArr.getMultLangMasData(MASTER_TABLE.DelSubStg);
            for(var i=0;i<dealStages.length;i++){
                if(dealStageID == dealStages[i].DealStageID){
                    return dealStages[i].DealStageModelID;
                }
            }

        }

        serArr.dealStageName = function(dealStageID){
            var dealStages = serArr.getMultLangMasData(MASTER_TABLE.DelSubStg);
            for(var i=0;i<dealStages.length;i++){
                if(dealStageID == dealStages[i].DealStageID){
                    return dealStages[i].Name;
                }
            }

        }

        serArr.getDefaultDropDownId = function (dropDownArr) {
            if(dropDownArr.length ==0)
                return 0;
            var selectedDropDown = $filter('filter')(dropDownArr, {IsDefault: true});
            if(selectedDropDown.length == 1){
                return selectedDropDown[0].Value;
            }else{
                return dropDownArr[0].Value;
            }
        }
        serArr.getDefaultDropDownCorrospondance = function (dropDownArr) {
            if(dropDownArr.length ==0)
                return 0;
            var selectedDropDown = $filter('filter')(dropDownArr, {IsDefault: true});
            if(selectedDropDown.length == 1){
                return selectedDropDown[0].CorrospondanceTypeID;
            }else{
                return dropDownArr[0].CorrospondanceTypeID;
            }
        }

        serArr.commonValidationForContact = function (contactIndividualObj, contactCompanyObj) {
            var communicationData = contactIndividualObj.Communications;
            return true;
        }

        serArr.updateFldArrValues = function (srcArr, DestnArr) {
            for (var i = 0; i < srcArr.length; i++) {
                DestnArr[i].FieldValue = srcArr[i].FieldValue;
            }
        }

        serArr.generateUUID = function () {
            var d = new Date().getTime();
            if (window.performance && typeof window.performance.now === "function") {
                d += performance.now(); //use high-precision timer if available
            }
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });
            return uuid;
        }

        serArr.prepareDynamicFldQuery = function (model) {

            var entityID = 0;
             if (model.ModuleID == GENERAL_CONFIG.MODULES.Contact) {
                 entityID = model.ContactID;
             }else if (model.ModuleID == GENERAL_CONFIG.MODULES.Activity)
             {
                entityID = model.ActivityID;
            }else if (model.ModuleID == GENERAL_CONFIG.MODULES.Deal)
            {
                entityID = model.DealID;
            }
            var fieldsArr = model.Fields;
            var fieldsColumnNamesArr = ['EntityID','ModuleID','ParentDeviceObjID','LoggedInUserID'];
            var fieldsValuesArr = [entityID, model.ModuleID, model.DeviceObjID,$rootScope.loggedInUserID];
            var questionArr = ['?','?', '?', '?'];

            angular.forEach(fieldsArr, function (obj, key) {
                fieldsColumnNamesArr.push(obj.FieldName);
                fieldsValuesArr.push(obj.FieldValue);
                questionArr.push('?');
            });

            var dynamicFldQuery = 'INSERT INTO DynamicFields ('

            dynamicFldQuery += fieldsColumnNamesArr.join(',');


            dynamicFldQuery += ')' + 'VALUES (' + questionArr.join(',') + ')';

            return { 'Query': dynamicFldQuery, 'Bindings': fieldsValuesArr }
        }

       serArr.CheckNull = function (val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return "NULL";
            }
            return val;
        }

        serArr.CheckModelNull = function (val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return null;
            }
            return val;
        }

        serArr.noteInsertQuery = function (objAct, parentDevObjId) {
            return "INSERT INTO Notes (DeviceObjID,ModuleID,EntityID,ParentDeviceObjID,Description,CreatedOn,CreatorID,CreatorName,CreatedAt,ModifiedBy,ModifiedOn,ModifiedAt,LoggedInUserID,NoteID)" +
                               " VALUES ('" + objAct.DeviceObjID + "'," + serArr.CheckNull(objAct.ModuleID) + "," + serArr.CheckNull(objAct.EntityID) + ",'" + parentDevObjId + "','" + objAct.Description + "','" +
                                objAct.CreatedOn + "'," + serArr.CheckNull(objAct.CreatorID) + ",'" + objAct.CreatorName + "','" + objAct.CreatedAt + "','" + objAct.ModifiedBy + "','" +
                                objAct.ModifiedOn + "','" + objAct.ModifiedAt + "'," + $rootScope.loggedInUserID + "," + serArr.CheckNull(objAct.NoteID) + ")";

        }

        serArr.noteSelectQuery = function (actId) {
            return "SELECT ROWID,* FROM Notes WHERE ParentDeviceObjID ='" + actId + "' order by ROWID DESC";
        }

        serArr.getObjData = function (arr, propName, propValue) {
            if (propValue == null || propValue == 0) {
                return arr;
            }
            var filterArry = [];
            for (var i = 0; i < arr.length; i++) {
                if (arr[i][propName] == propValue) {
                    filterArry.push(arr[i]);
                }
            }

            return filterArry;
        }
        // Attachment Module code
        serArr.attachMod = function () {
            return {
                attachObj: {
                    AttachmentCategoryID: 0,
                    AttachmentID: 0,
                    AttachmentSize : '0',
                    EntityID: 0,
                    DeviceObjID: serArr.generateUUID(),
                    ModuleID: 0,
                    ParentDeviceObjID: '',
                    Base64String: '',
                    FileName: '',
                    MIMEContentType: '',
                    Extension: '',
                    DocumentID: null,
                    DocumentName: '',
                    ModifiedBy: 0,
                    SyncStatus: 0,
                    ModifiedAt: ''
                }
            }
        };

        serArr.sqlAttachInsertData = function (attach) {
            sqliteService.query("INSERT INTO Attachments (DeviceObjID,ParentType,ParentDeviceObjID,AttachImageName,AttachImagePath,AttachDocTypeId,AttachDocTypeName,IsChecked,LoggedInUserID) VALUES ('"
             + attach.DeviceObjID + "','" + attach.ParentType + "','" + attach.ParentDeviceObjID + "','" + attach.AttachImageName + "','" + attach.AttachImagePath + "','" + attach.AttachDocTypeId + "','" + attach.AttachDocTypeName + "','" + attach.IsChecked + "'," + $rootScope.loggedInUserID + ")").then(function (result) {
                 //console.log("insert attach");
             });
        };

        serArr.b64toBlob = function (b64Data, contentType, sliceSize) {
        contentType = contentType || '';
        sliceSize = sliceSize || 512;

        var byteCharacters = atob(b64Data);
        var byteArrays = [];

            for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
                var slice = byteCharacters.slice(offset, offset + sliceSize);

                var byteNumbers = new Array(slice.length);
                for (var i = 0; i < slice.length; i++) {
                    byteNumbers[i] = slice.charCodeAt(i);
                }

                var byteArray = new Uint8Array(byteNumbers);

                byteArrays.push(byteArray);
            }
            var blob = new Blob(byteArrays, {type: contentType});
            return blob;
        };

        /**
         * Create a Image file according to its database64 content only.
         *
         * @param folderpath {String} The folder where the file will be created
         * @param filename {String} The name of the file that will be created
         * @param content {Base64 String} Important : The content can't contain the following string (data:image/png[or any other format];base64,). Only the base64 string is expected.
         */
        serArr.savebase64AsImageFile = function(folderpath,filename,content,contentType,folderName){
            // Convert the base64 string in a Blob
            var DataBlob = serArr.b64toBlob(content,contentType);

            console.log("Starting to write the file :3");
            $window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem2) {
                      fileSystem2.getDirectory(folderName, { create: true, exclusive: false }, function (dirEntry) {
                            dirEntry.getFile(filename, {create:false}, function(fileEntry){

                            },function(){
                                $window.resolveLocalFileSystemURL(folderpath, function(dir) {
                                    console.log("Access to the directory granted succesfully");
                                    dir.getFile(filename, {create:true}, function(file) {
                                        console.log("File created succesfully.");
                                        file.createWriter(function(fileWriter) {
                                            console.log("Writing content to file");
                                            fileWriter.write(DataBlob);
                                        }, function(){
                                            alert('Unable to save file in path '+ folderpath);
                                        });
                                    });
                                });
                            });
                      });
            });
        }

        serArr.getContactInverseRelationType = function (relationType) {
            var inverseRelations = serArr.getMultLangMasData(MASTER_TABLE.RelInverseType);
            var inverseRelation = 0;
            angular.forEach(inverseRelations, function (obj, key) {
                if (obj.RelationshipTypeID == relationType) {
                    inverseRelation = obj.InverseRelationshipTypeID;
                } else if (obj.InverseRelationshipTypeID == relationType) {
                    inverseRelation = obj.RelationshipTypeID;
                }
            }
                );
            return inverseRelation;
        };
        /*serArr.sqlAttachFetchData = function(pType,pDeviceId){
            sqliteService.query("SELECT * FROM Attachments WHERE ParentType = "+ pType +" and ParentDeviceObjID = "+ pDeviceId).then(function (result) {
                return result;
                //console.log("fetch attach");
            });
        };
        serArr.sqlAttachDeleteData = function(attachId){
            sqliteService.query("DELETE FROM Attachments WHERE DeviceObjID = "+ attachId).then(function (result) {
                //console.log("attach delete");
            });
        };*/

        serArr.getSubject = function (obj) {
            var subject = '';
            var conType = obj.Type == 'A' ? obj.ActivityType : '';

            if (obj.ContactTypeID == '1' && obj.ContactName != null && obj.ContactName != 'null') {//indu
                 subject = conType + obj.ContactName;
            }
            else {
                if(obj.RepresentativeName != null && obj.RepresentativeName != 'null'){
                    subject = conType + obj.RepresentativeName;
                }
            }
            if (obj.CompanyName != '' && obj.CompanyName != null && obj.CompanyName != 'null') {
                subject += '-' + obj.CompanyName;
            }

            return subject
        }

        // Contact Model Code
        serArr.contactSelectionMod = function () {
            return {
                uiObject: {
                    ContactName: '',
                    ContactID: 0,
                    ContactDeviceObjID: '',
                    ContactOwnerID: 0,
                    ContactOwnerName: '',
                    ContactTypeID: 0,
                    CompanyName: '',
                    CompanyID: 0,
                    CompanyDeviceObjID: '',
                    RepresentativeName: '',
                    RepresentativeID: 0,
                    RepresentativeDeviceObjID: '',
                    DisplayName: '',
                    IsChecked: false,
                    UserName: '',
                    UserID: 0,
                    ActivityAttendeeID: 0,
                    ContactTierName: '',
                    ContactTierID: 0,
                    ContactSegmentName: '',
                    ContactSegmentID: 0
                }
            }
        };

        serArr.sqlGetAllContacts = function (obj) {
            return sqliteService.query('SELECT * from Contacts WHERE ((ContactTypeID=1 AND IsRepresentative="false") OR (ContactTypeID=2 AND IsEmployer="false")) AND LoggedInUserID = '+  $rootScope.loggedInUserID).then(function (result) {
                return result;
            });
        }

        serArr.sqlGetAllIndividualContactsRelationships = function (obj) {
            var returnArr = [obj];
            return sqliteService.query('SELECT * from Contacts WHERE DeviceObjID IN (SELECT RelationshipWithContactDeviceObjID from ContactRelationships WHERE (ContactRelationshipTypeID="4" AND ContactDeviceObjID="' + obj.DeviceObjID + '"))').then(function (result) {
                returnArr.push(result);
                return returnArr;
            });
        }

        serArr.sqlGetAllRepresentativeDetails = function (obj) {
            var returnArr = [obj];
            return sqliteService.query('SELECT * from Contacts WHERE DeviceObjID IN (SELECT RelationshipWithContactDeviceObjID from ContactRelationships WHERE (ContactRelationshipTypeID="2" AND ContactDeviceObjID="' + obj.DeviceObjID + '"))').then(function (result) {
                returnArr.push(result);
                return returnArr;
            });
        }

        serArr.getColorCode = function (inputDate, inputTime, inputStage) {
            var dt = new Date();
            var priority = 2;//done/cancel/due later
            var curDate = new Date();

            var nextThreeDay = new Date();
            nextThreeDay.setDate(curDate.getDate() + 3);
            //var actDateFormat = serArr.getDateInDisplayFormatFromServerDate(inputDate);
            var actTime = serArr.convertTimeFormat(inputTime);
            var finalActDateTime = inputDate + ' ' + inputTime + ':00';

            var s = finalActDateTime.replace(/[ :]/g, "-").split("-");
            var actDate = new Date(s[0], s[1] - 1, s[2], s[3], s[4], s[5]);

            if (inputStage == GENERAL_CONFIG.ActivityStage.Done) {
                priority = 4;
            }
            else if (inputStage == GENERAL_CONFIG.ActivityStage.Cancel) {
                priority = 5;
            }
            else if (actDate.getTime() < curDate.getTime())//(isLessThanTo(finalActDateTime)) //(curDate.getTime() > actDate.getTime())//overdue
            {
                priority = 1;
            }
            else if (actDate.getTime() >= curDate.getTime() && actDate <= nextThreeDay)//(isGreaterThanTo(finalActDateTime) && actDate <= nextThreeDay)//(curDate.getTime() <= actDate.getTime() && actDate.getTime() <= nextThreeDay.getTime())//due soon
            {
                priority = 3;
            }
            return priority;
        }

        serArr.getColorCodeForDeals = function (inputDate, inputStage) {
            var dt = new Date();
            var priority = 2;//done/cancel/due later
            var curDate = new Date();

            var nextThreeDay = new Date();
            nextThreeDay.setDate(curDate.getDate() + 3);

            var s = inputDate.split("-");
            var dealDate = new Date(s[0], s[1] - 1, s[2]);

            if (inputStage == GENERAL_CONFIG.DealStageModel.Close) {
                priority = 4;
            }
            else if(inputStage == GENERAL_CONFIG.DealStageModel.Lost){
                priority = 5;
            }
            else if (dealDate < curDate)
            {
                priority = 1;
            }
            else if (dealDate >= curDate && dealDate <= nextThreeDay)
            {
                priority = 3;
            }
            return priority;
        }

        serArr.getColorCodeForContact = function (inputDate) {
            var dt = new Date();
            var priority = 2;//done/cancel/due later
            if(typeof inputDate == 'undefined' || inputDate == null || inputDate == ''){
                return priority;
            }
            var curDate = new Date();

            var nextThreeDay = new Date();
            nextThreeDay.setDate(curDate.getDate() + 3);

            var s = inputDate.split("-");
            var contactDate = new Date(s[0], s[1] - 1, s[2]);

            if (contactDate < curDate)
            {
                priority = 1;
            }
            else if (contactDate >= curDate && contactDate <= nextThreeDay)
            {
                priority = 3;
            }
            return priority;
        }

         //get the date format but pass input type string date
        serArr.getDateStringMDYFormat = function (inputStr) {
            if (inputStr == null || inputStr == '' || inputStr == 'undefined') return '';
            var dsplit = inputStr.split("-");
            var dt = new Date(dsplit[0], dsplit[1] - 1, dsplit[2]);
            return $filter('date')(new Date(dt), dateFormatMMDDYYYY);
        }

        function isLessThanTo(dtmfrom) {
                return new Date(dtmfrom).getTime() < new Date().getTime();
            }

        function isGreaterThanTo(dtmfrom) {
            return new Date(dtmfrom).getTime() >= new Date().getTime();
        }

        serArr.allowEditing = function (model) { //|| model.ContactOwnerID == loginInfo.UserID -->Deal & Activity
            var loginInfo = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            if (model.ModuleID == GENERAL_CONFIG.MODULES.Contact) {
                if (model.OwnerID == loginInfo.UserID) {
                    return true;
                }
            }else if (model.ModuleID == GENERAL_CONFIG.MODULES.Activity)
            {
                if ((model.ActivityStageID!=2 && model.ActivityStageID!=3) && (model.OwnerID == loginInfo.UserID || model.CreatorID == loginInfo.UserID)) {
                    return true;
                }
            }else if (model.ModuleID == GENERAL_CONFIG.MODULES.Deal) {
                var dealStageModelID = serArr.dealStageModelIDCheck(model.DealStageID);
                if ((dealStageModelID!=4 && dealStageModelID!=5) && (model.OwnerID == loginInfo.UserID || model.CreatorID == loginInfo.UserID)) {
                    return true;
                }
            }
            return false;
        }

        serArr.convertTime24Format = function (time) {
            var hours = Number(time.match(/^(\d+)/)[1]);
            var minutes = Number(time.match(/:(\d+)/)[1]);
            var AMPM = time.match(/\s(.*)$/)[1];
            if (AMPM == "PM" && hours < 12) hours = hours + 12;
            if (AMPM == "AM" && hours == 12) hours = hours - 12;
            var sHours = hours.toString();
            var sMinutes = minutes.toString();
            if (hours < 10) sHours = "0" + sHours;
            if (minutes < 10) sMinutes = "0" + sMinutes;
            return sHours + ":" + sMinutes;
        }

         serArr.bitValCheck = function (val) {
            if (val == 1 || val == true) {
                return true;
            }
            else {
                return false;
            }
        }

         serArr.prepareServerDateTimes = function () {
             var ServerDateTimes = {
                 'LoggedInuser': {
                     'MasterDateTime': '',
                     'HomeDateTime': '',
                     'ContactDateTime': { 'Next': '', 'Prev': '' },
                     'ActivityDateTime': { 'Next': '', 'Prev': '' },
                     'DealDateTime': { 'Next': '', 'Prev': '' },
                     'UserDateTime': { 'Next': '', 'Prev': '' }
                 },
                 'LoggedInAsOtheruser': {
                     'MasterDateTime': '',
                     'HomeDateTime': '',
                     'ContactDateTime': { 'Next': '', 'Prev': '' },
                     'ActivityDateTime': { 'Next': '', 'Prev': '' },
                     'DealDateTime': { 'Next': '', 'Prev': '' },
                     'UserDateTime': { 'Next': '', 'Prev': '' }
                 }
             };
             return ServerDateTimes;
         }

        serArr.wipeUserData = function(hasChnagedRootUser)
        {
            var queryBindingsArray = [];

            var tableNames = GENERAL_CONFIG.TableNames;
            if (hasChnagedRootUser) {
                //Clean Whole App data
                serArr.clearAllLocalStorage();
                angular.forEach(tableNames, function(tableName) {
                    queryBindingsArray.push({'Query':'DELETE FROM ' + tableName,'Bindings':''});
               })
            }else
            {
                var loggedInUser = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
                //Delete Server dates also
                var serverDateTimes = serArr.getMasterDataByKey(GENERAL_CONFIG.ServerDateTimes);

                if (serverDateTimes != null && typeof serverDateTimes != 'undefined') {
                    var loggedInUserDateTimes = serverDateTimes.LoggedInuser;
                    var loggedInAsUserDateTimes = serverDateTimes.LoggedInAsOtheruser;

                    var blankServerDateTimesModel = serArr.prepareServerDateTimes();
                    serverDateTimes.LoggedInAsOtheruser = blankServerDateTimesModel.LoggedInAsOtheruser;

                    if ($rootScope.loadNewMasterDataForLoggedInAsUser == false) {
                        //Comment below line in case we want to load new master for new switched user
                        loggedInAsUserDateTimes.MasterDateTime = loggedInUserDateTimes.MasterDateTime; //**********
                    };

                    serArr.setMasterData(GENERAL_CONFIG.ServerDateTimes, serverDateTimes);


                }
                //Clearing LoggedInAsUser Info
                var storedLoggedInAsUserInfo = serArr.getMasterDataByKey(GENERAL_CONFIG.ServerDateTimes);
                if(storedLoggedInAsUserInfo)
                    serArr.removeMasterDataByKey(MASTER_TABLE.LoggedInAsUserInfo);

                if (loggedInUser != null) {
                     angular.forEach(tableNames, function(tableName) {
                                    queryBindingsArray.push({'Query':"DELETE FROM " + tableName + " WHERE LoggedInUserID != " + loggedInUser.UserID,'Bindings':''});
                               })
                 }

            }
             return sqliteService.multipleQueries(queryBindingsArray).then(function (result) {
                    return result;
                    }, function (error) {
                        alert(error);
                        return error;
                            });
        }

        serArr.activeUserName = function()
        {
            var activeUserName = '';

            var loggedInUserInfo = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            if ($rootScope.loggedInUserID == loggedInUserInfo.UserID) {
                activeUserName = loggedInUserInfo.UserName;
            }else
            {
             var loggedInAsUserInfo = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInAsUserInfo);
             if(loggedInAsUserInfo)
                activeUserName = loggedInAsUserInfo.UserName;
            }
            $rootScope.loggedInUserName = activeUserName;
            return activeUserName;
        }
          serArr.clearAllLocalStorage =  function(){
           return localStorageService.clearAll();
          }


        serArr.clearIonicHistory = function(){
          $ionicHistory.clearCache();
          $ionicHistory.clearHistory();
        }

        serArr.busyCursorStart = function() {
            $ionicLoading.show({
                template: 'Loading...'
            });
        };

        serArr.busyCursorEnd = function() {
            $ionicLoading.hide();
        };

        //####################### LoggedIn As User START ##########################
         serArr.loadLoggodInAsUsers = function(userList) {
            var loggedInUserInfo = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            serArr.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.LoggedInAsUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var newObj = result.rows.item(i);
                    if(newObj.UserID != loggedInUserInfo.UserID)
                         userList.push(newObj);
                }
            });
        }
        var loggedInSelUser = null;
        var deferred = null;

        serArr.selectedLogginAsUser = function(index,isSelfUser,model,userList)
        {
            deferred = $q.defer();

            if (isSelfUser) {
                    serArr.busyCursorStart();
                    serArr.clearIonicHistory();
                    $rootScope.isAccessingOtherUserProfile = false;
                    var loggedInUserInfo = serArr.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
                    $rootScope.loggedInUserID = loggedInUserInfo.UserID;
                    var hasRootUserChanged = false;
                    serArr.wipeUserData(hasRootUserChanged).then(function (result) {
                        serArr.activeUserName();
                        model.hide();
                        userList=[];
                        serArr.busyCursorEnd();
                        deferred.resolve("success");
                    });
            }else
            {
                serArr.busyCursorStart();

                loggedInSelUser = userList[index];

                if (loggedInSelUser) {
                    serArr.clearIonicHistory();
                    $rootScope.isAccessingOtherUserProfile = true;
                    $rootScope.loggedInUserID = loggedInSelUser.UserID;
                    var hasRootUserChanged = false;
                    serArr.wipeUserData(hasRootUserChanged).then(function (result) {
                        serArr.setMasterData(MASTER_TABLE.LoggedInAsUserInfo, loggedInSelUser);
                        serArr.activeUserName();
                        model.hide();
                        userList = [];
                        serArr.busyCursorEnd();
                        deferred.resolve("success");
                    });
                }
            }
            return deferred.promise;
        }
         serArr.userListLoadByUserCategory = function (UserCategoryTypeId) {
            return sqliteService.query('SELECT * FROM Users where UserType = '+ UserCategoryTypeId).then(function (result) {
                return result;
            });
         }
         serArr.isEmpty = function (obj) {
             for (var prop in obj) {
                 if (obj.hasOwnProperty(prop))
                     return false;
             }

             return true && JSON.stringify(obj) === JSON.stringify({});
         }
    };
})();
