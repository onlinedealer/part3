(function() {
    'use strict';
    // Header
    FirstApp.directive('headerTemplate', ['uiRouters', headerTemplate]);

    function headerTemplate(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/header.html',
            
        }
    }
    
    // Footer
    FirstApp.directive('footerTemplate', ['uiRouters', footerTemplate]);

    function footerTemplate(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/footer.html'
        }
    }

    
})();
