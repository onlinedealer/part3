(function() {
    'use strict';
    angular.module('arm').controller('dashboardGraphCtrl', ['$scope', '$rootScope', '$filter', '$state', '$ionicModal', '$ionicSideMenuDelegate', 'dashboardService', 'utility', 'MASTER_TABLE', 'ALERT_MESSAGE', '$cordovaDialogs','homeService', dashboardGraphCtrl]);

    function dashboardGraphCtrl($scope, $rootScope, $filter, $state, $ionicModal, $ionicSideMenuDelegate, dashboardService, utility, MASTER_TABLE, ALERT_MESSAGE, $cordovaDialogs,homeService) {

        // Dashboard Back Button
        //$scope.radioBtnIdStore;
        $scope.dropDownShow = false;
        $scope.dashboardBack = function() {
            $state.go('tab.home');
        }

        $scope.list = [{
            name: 'Self',
            ID: 1
        }, {
            name: 'Team',
            ID: 2
        }, {
            name: 'Group',
            ID: 3
        }];

        var ranges = [{
            divider: 1e6,
            suffix: 'M'
        }, {
            divider: 1e3,
            suffix: 'K'
        }];

        // Function suffix K or M and decimal float limit to 2 digits
        function formatNumber(n) {
            for (var i = 0; i < ranges.length; i++) {
                if (n >= ranges[i].divider) {
                    n = (n / ranges[i].divider);
                    if (parseInt(n) == n) {} else if (parseFloat(n) == n) {
                        n = n.toFixed(1);
                    }
                    n = n.toString() + ranges[i].suffix;
                }
            }
            return n.toString();
        };

        $scope.userGroup = utility.getMultLangMasData(MASTER_TABLE.UserGroup);
        console.log($scope.userGroup)

        $scope.handleRadioClick = function(getID) {
            $scope.getRowDetails = getID;
            if (getID.ID == 3) {
                $scope.dropDownShow = true;
            } else {
                $scope.dropDownShow = false;
            }
        };

        $scope.submitFilter = function() {
            var date = $filter('date')(new Date(), 'yyyy-MM-dd');
            if ($scope.getRowDetails.ID == 3) {
                if ($scope.groupGroupID == undefined) {
                    $cordovaDialogs.alert(ALERT_MESSAGE.GROUP, ALERT_MESSAGE.ALERT_TITLE, 'OK').then(function () { });
                } else {
                    console.log($scope.getRowDetails.ID)
                    var forOpe;
                    console.log("test" + $scope.groupGroupID)
                        //var url = GetContactDashboard/{loggedInUserID}/{id}/{forOperation}/{timeStamp};
                    var url = "/" + $rootScope.loggedInUserID + "/" + $scope.groupGroupID + "/" + "3" + "/" + date;
                    console.log(url)
                    dashboardService.dashGraphFilterAdd(url).then(function(res) {
                        ////console.log("Dashboard Response" + JSON.stringify(res));
                        $scope.getData = res;
                        console.log(JSON.stringify($scope.getData));
                        $scope.closeFilter();
                        $scope.bindingValues();
                    }, function(err) {
                        //console.log('product family error' + err);
                    });
                }
            } else {
                console.log($scope.getRowDetails.ID);

                var url = "/" + $rootScope.loggedInUserID + "/" + $scope.getRowDetails.ID + "/" + "null" + "/" + date;
                console.log(url)
                dashboardService.dashGraphFilterAdd(url).then(function(res) {
                    ////console.log("Dashboard Response" + JSON.stringify(res));
                    $scope.getData = res;
                    console.log(JSON.stringify($scope.getData));
                    $scope.closeFilter();
                    $scope.bindingValues();
                }, function(err) {
                    //console.log('product family error' + err);
                });
            }
        };

        $scope.groupRadio = function(getUserGroupID) {
            //console.log(getUserGroupID.UserGroupID)
            $scope.groupGroupID = getUserGroupID.UserGroupID;
            console.log($scope.groupGroupID);
        }

        // function fetching dashboard data to server
        function fetchDashboardData() {
            dashboardService.dashAdd().then(function(res) {
                ////console.log("Dashboard Response" + JSON.stringify(res));
                $scope.getData = res;
                console.log(JSON.stringify($scope.getData));
                //console.log("##CHECK VALUES1###", JSON.stringify($scope.getData));
                ////console.log("checking perday1 value", $scope.getData.ActivityDashboard[0].PerDay);
                ////console.log("checking perday value",$scope.getData.results.Data.ActivityDashboard[0].PerDay)
                $scope.bindingValues();
            }, function(err) {
                //console.log('product family error' + err);
            });
        }

        fetchDashboardData();

        $scope.bindingValues = function() {

            $scope.ActiCallDayValue = $scope.getData.ActivityDashboard[0].PerDay;
            $scope.ActiMeetingDayValue = $scope.getData.ActivityDashboard[1].PerDay;

            /** ACTIVITY START *******/
            $scope.ActiCallDayDonePercentage = $scope.getData.ActivityDashboard[0].DonePercentage;
            $scope.ActiCallDayTargetPercentage = $scope.getData.ActivityDashboard[0].TargetPercentage;
            $scope.ActiCallDayPlannedPercentage = $scope.getData.ActivityDashboard[0].PlannedPercentage;

            $scope.ActiCallDayDone = formatNumber($scope.getData.ActivityDashboard[0].Done);
            $scope.ActiCallDayPlanned = formatNumber($scope.getData.ActivityDashboard[0].Planned);
            $scope.ActiCallDayTarget = formatNumber($scope.getData.ActivityDashboard[0].Target);

            $scope.ActiMeetingDayDonePercentage = $scope.getData.ActivityDashboard[1].DonePercentage;
            $scope.ActiMeetingDayTargetPercentage = $scope.getData.ActivityDashboard[1].TargetPercentage;
            $scope.ActiMeetingDayPlannedPercentage = $scope.getData.ActivityDashboard[1].PlannedPercentage;

            $scope.ActiMeetingDayDone = formatNumber($scope.getData.ActivityDashboard[1].Done);
            $scope.ActiMeetingDayPlanned = formatNumber($scope.getData.ActivityDashboard[1].Planned);
            $scope.ActiMeetingDayTarget = formatNumber($scope.getData.ActivityDashboard[1].Target);

            /** ACTIVITY END *******/

            /** DEAL START *******/

            $scope.DealsNumberDayClosedPercetange = $scope.getData.DealDashboard[0].ClosedPercentage;
            $scope.DealsNumberDayPlannedPercentage = $scope.getData.DealDashboard[0].PlannedPercentage;
            $scope.DealsNumberDayTargetPercentage = $scope.getData.DealDashboard[0].TargetPercentage;

            $scope.DealsNumberDayValue = $scope.getData.DealDashboard[0].PerDay;
            $scope.DealsNumberDayClosed = $scope.getData.DealDashboard[0].Closed;
            $scope.DealsNumberDayPlanned = $scope.getData.DealDashboard[0].Planned;
            $scope.DealsNumberDayTarget = $scope.getData.DealDashboard[0].Target;

            $scope.DealsRevenueDayClosedPercetange = $scope.getData.DealDashboard[1].ClosedPercentage;
            $scope.DealsRevenueDayPlannedPercentage = $scope.getData.DealDashboard[1].PlannedPercentage;
            $scope.DealsRevenueDayTargetPercentage = $scope.getData.DealDashboard[1].TargetPercentage;

            $scope.DealsRevenueDayValue = formatNumber($scope.getData.DealDashboard[1].PerDay);
            $scope.DealsRevenueDayClosed = formatNumber($scope.getData.DealDashboard[1].Closed);
            $scope.DealsRevenueDayPlanned = formatNumber($scope.getData.DealDashboard[1].Planned);
            //console.log($scope.DealsRevenueDayPlanned)
            //console.log($scope.getData.DealDashboard[1].Planned)
            $scope.DealsRevenueDayTarget = formatNumber($scope.getData.DealDashboard[1].Target);

            $scope.DealsValueDayClosedPercetange = $scope.getData.DealDashboard[2].ClosedPercentage;
            $scope.DealsValueDayPlannedPercentage = $scope.getData.DealDashboard[2].PlannedPercentage;
            $scope.DealsValueDayTargetPercentage = $scope.getData.DealDashboard[2].TargetPercentage;

            $scope.DealsValueDayValue = formatNumber($scope.getData.DealDashboard[2].PerDay);
            $scope.DealsValueDayClosed = formatNumber($scope.getData.DealDashboard[2].Closed);
            $scope.DealsValueDayPlanned = formatNumber($scope.getData.DealDashboard[2].Planned);
            $scope.DealsValueDayTarget = formatNumber($scope.getData.DealDashboard[2].Target);

            /** DEAL END *******/

            /** CONTACT START *******/

            $scope.ContactsIgnored = $scope.getData.ContactDashboard.IgnoredPercentage;
            $scope.ContactsTotal = $scope.getData.ContactDashboard.Total;

            $scope.ContactsContactedPercentage = $scope.getData.ContactDashboard.ContactedPercentage;
            $scope.ContactsTargetPercentage = $scope.getData.ContactDashboard.TargetPercentage;
            $scope.ContactsTargetToDatePercentage = formatNumber($scope.getData.ContactDashboard.TargetToDatePercentage);
            //console.log($scope.getData.ContactDashboard.TargetToDatePercentage)
            $scope.ContactsContacted = formatNumber($scope.getData.ContactDashboard.Contacted);
            $scope.ContactsTarget = formatNumber($scope.getData.ContactDashboard.Target);
            $scope.ContactsTargetToDate = formatNumber($scope.getData.ContactDashboard.TargetToDate);

            /** CONTACT END *******/

            /** CAMPAIGN  START *******/
            $scope.CampaignsIgnored = $scope.getData.CampaignDashboard.IgnoredPercentage;
            //$scope.CampaignsTotal = $scope.getData.CampaignDashboard.Total;

            $scope.CampaignsClosedPercentage = $scope.getData.CampaignDashboard.ClosedPercentage;
            $scope.CampaignsLostPercentage = $scope.getData.CampaignDashboard.LostPercentage;
            $scope.CampaignsInProgressPercentage = $scope.getData.CampaignDashboard.InProgressPercentage;
            $scope.CampaignsTotalPercentage = $scope.getData.CampaignDashboard.TotalPercentage;

            $scope.CampaignsClosed = formatNumber($scope.getData.CampaignDashboard.Closed);
            $scope.CampaignsLost = formatNumber($scope.getData.CampaignDashboard.Lost);
            $scope.CampaignsInProgress = formatNumber($scope.getData.CampaignDashboard.InProgress);
            $scope.CampaignsTotal = formatNumber($scope.getData.CampaignDashboard.Total);
        }

        //############### LoggedInAs User  functionality START ##############
        $ionicModal.fromTemplateUrl('app/views/common/loggedInAsUserList.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function(modal) {
            $scope.modalLoginAsUsers = modal;
        });

        $scope.loggedInUsers = [];
        var loggedInUserInfo = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.selfLoggedInID = loggedInUserInfo.UserID;

        $scope.selectedUser = function(index, isSelfUser) {
            utility.selectedLogginAsUser(index, isSelfUser, $scope.modalLoginAsUsers, $scope.loggedInUsers).then(function(res) {
                fetchDashboardData();
                if ($rootScope.isAccessingOtherUserProfile) {
                    homeService.syncServerRecords();
                }
            });
        }

        $scope.openLogInUserMenu = function() {
            $scope.loggedInUsers = [];
            utility.loadLoggodInAsUsers($scope.loggedInUsers);
            $scope.modalLoginAsUsers.show();
        };
        $scope.closeLogInMenu = function() {
            $scope.modalLoginAsUsers.hide();
            $scope.loggedInUsers = [];
        };


        $scope.openDashGraphFilter = function() {
            $scope.modalcntfilterGraph.show();
            //console.log($scope.objFilter.search)
        };

        $ionicModal.fromTemplateUrl('app/views/dashboard/dashboardGraphFilter.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function(modal) {
            $scope.modalcntfilterGraph = modal;
        });
        $scope.openFilter = function() {
            $scope.modalcntfilterGraph.show();
            //console.log($scope.objFilter.search)
        };
        $scope.closeFilter = function() {
            $scope.modalcntfilterGraph.hide();
        };
        //############### LoggedInAs User  functionality END ##############
    };

})();