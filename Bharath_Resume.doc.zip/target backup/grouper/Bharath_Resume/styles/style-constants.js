export const colors = {
  black: '#000',
  brightPink: '#E0007F',
  gray: {
    dark: '#666',
    darkest: '#333',
    light: '#D6D6D6',
    lightest: '#F7F7F7',
    medium: '#888',
  },
  primary: {
    dark: '#0000B5',
    light: '#85D2ED',
    main: '#1976D2',
  },
  secondary: {
    dark: '#D43900',
    light: '#FFD180',
    main: '#FF9100',
  },
  success: {
    dark: '#1D781D',
    light: '#AED581',
    medium: '#6FA136',
  },
  warn: {
    darkRed: '#A20806',
    red: '#D50000',
  },
  white: '#FFF',
  yellow: {
    light: '#FFF7C0',
    main: '#FFE08A',
  },
}
