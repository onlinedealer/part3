import { Component, Input, OnInit } from '@angular/core';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-histogram-chart',
  templateUrl: './histogram-chart.component.html',
  styleUrls: ['./histogram-chart.component.css']
})
export class HistogramChartComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, any>;
  @Input()
  index: number;
  data: any;
  options: any;
  ngOnInit(): void {
    this.data = {
      labels: [],
      datasets: [
        {
          label: '',
          data: [],
          backgroundColor: ProfilingConstants.FREQUENCYCHARTCOLORS[this.index],
          barPercentage: 0.97,
          categoryPercentage: 1,
          minBarLength: 2
        }
      ]
    };
    this.options = {
      scales: {
        x: {
          grid: {
            drawOnChartArea: false
          },
          ticks: {
            beginAtZero: true
          }
        },
        y: {
          grid: {
            drawOnChartArea: false
          },
          ticks: {
            beginAtZero: true,
            callback: (value) => {
              if (value % 1 === 0) {
                return value;
              }
            }
          }
        }
      },
      plugins: {
        legend: {
          display: false
        }
      }
    };
    this.generateDataLabel();
  }
  private generateDataLabel(): void {
    if (this.treePath.columnView) {
      // eslint-disable-next-line guard-for-in
      for (const key in this.statistics['frequency']) {
        this.data.labels.push(key);
        this.data.datasets[0].data.push(this.statistics['frequency'][key]);
      }
    }
  }
}
