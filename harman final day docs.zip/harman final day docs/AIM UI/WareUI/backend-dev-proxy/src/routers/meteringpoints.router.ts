import { Router, Request, Response } from 'express'
import { MeteringpointsService } from '../services/meteringpoints.service'

export const meteringpointsRouter = Router();
const meteringpointsService = new MeteringpointsService();

meteringpointsRouter.get('/', (req: Request, res: Response) => {
  meteringpointsService.getMeteringpoints().subscribe( (response: any[]) => res.json(response));
})
