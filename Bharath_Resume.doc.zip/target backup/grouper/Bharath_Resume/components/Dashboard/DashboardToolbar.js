import React from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
// import _ from 'lodash'
import { withStyles } from '@material-ui/core/styles'
import Toolbar from '@material-ui/core/Toolbar'
import Grid from '@material-ui/core/Grid'
import FilterListIcon from '@material-ui/icons/FilterList'
import { getStatusFormat, convertStatusFormat } from '../common/Utils/CommonUtils'
import Button from '@material-ui/core/Button'
import CreateIcon from '@material-ui/icons/Add'
import GrouperDrawer from '../common/GrouperDrawer/GrouperDrawer'
import CreateGroupContainer from './CreateGroupContainer'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormControl from '@material-ui/core/FormControl'
import TextField from '@material-ui/core/TextField'
import MenuItem from '@material-ui/core/MenuItem'
import Select from '@material-ui/core/Select'

const toolbarStyles = theme => ({
  root: {
    padding: 24,
  },
  headerTitle: {
    fontWeight: 500,
    fontSize: 24,
    margin: '10px 0',
    display: 'inline-block',
    verticalAlign: 'middle',
  },
  spacer: {
    flex: '0 1 50%',
  },
  actions: {
    color: theme.palette.text.secondary,
  },
  title: {
    flex: '0 0 auto',
  },
  groupsPadding: {
    padding: '20px 0px',
  },
  button: {
    margin: theme.spacing.unit,
  },
  leftIcon: {
    marginRight: theme.spacing.unit,
  },
  filterIcon: {
    float: 'left',
    paddingTop: 20,
    paddingRight: 10,
  },
  createGroupButtonStyle: {
    background: '#1976d2',
    color: '#fff',
    fontWeight: 300,
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  groupAddIcon: {
    color: '#1976d2',
    background: '#fff',
    width: '0.7em',
    height: '0.7em',
    marginRight: 7,
    borderRadius: 2,
  },
  groupFilters: {
    display: 'flex',
  },
  createBtnBlock: {
    textAlign: 'right',
  },
  addItemsButtonStyle: {
    border: '1px solid #1976d2',
    background: '#1976d2',
    marginRight: 5,
    fontWeight: 300,
    color: '#fff',
    fontSize: 12,
    '&:hover': {
      background: '#1976d2',
      color: '#fff',
    },
  },
  addIcon: {
    width: '0.6em',
    height: '0.6em',
    marginRight: 10,
    borderRadius: 2,
    background: '#fff',
    color: '#1976d2',
  },
  resetBtnPadding: {
    padding: '0 13px',
    height: 30,
    marginTop: 12,
  },
  formControl: {
    marginRight: 5,
    width: 145,
  },
  filterRow2: {
    marginLeft: 28,
  },
})

export class DashboardToolbar extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      selectRef: {
        group_type: '',
        parent_tcin: '',
        group_name: '',
        department_id: '',
        start_time: '',
        end_time: '',
        group_state: '',
      },
      drawerOpenStatus: false,
      drawerContent: '',
      currentValue: '',
      listRequestParams: this.props.groupListRequestParams,
    }
  }

    resetFilter = () => {
      const selectRef = {
        group_type: '',
        parent_tcin: '',
        group_name: '',
        department_id: '',
        start_time: '',
        end_time: '',
        group_state: '',
      }
      this.setState({ selectRef, currentValue: 'Reset' })
      setTimeout(() => {
        this.searchFilter()
      }, 100)
    }

    readFilters = (colId, sugg) => {
      sugg = (colId === 'group_state') ? convertStatusFormat(sugg) : sugg
      const { selectRef } = this.state
      if (sugg !== '') {
        selectRef[colId] = sugg
      } else {
        delete selectRef[colId]
      }
      this.setState({ selectRef, currentValue: '' })
      // this.props.onFilterRequest(selectRef)
    }

    searchFilter = () => {
      const { selectRef, listRequestParams } = this.state
      let tempFilter = {
        group_id: listRequestParams.group_id,
        pagination_filter: listRequestParams.pagination_filter,
      }
      for (let key of Object.keys(selectRef)) {
        if (selectRef[key]) { tempFilter[key] = selectRef[key] }
      }
      this.props.updateGroupListRequestParams(tempFilter)
      this.props.getGrouperList(tempFilter)
    }

    openDrawer = (event) => {
      this.setState({ drawerOpenStatus: true })
    }

    closeDrawer = () => {
      this.setState({ drawerOpenStatus: false })
    }

    handleFilterChange = (stName) => event => {
      const { selectRef } = this.state
      const curValue = (event.target.value && (stName === 'parent_tcin' || stName === 'department_id')) ? parseInt(event.target.value) : event.target.value
      selectRef[stName] = curValue
      this.setState({ selectRef })
    }

    render () {
      const { classes, groupTypes, statusList } = this.props
      const { selectRef } = this.state

      return (
        <Toolbar
          className={classNames(classes.root)}
        >
          <Grid container>
            <Grid item xs={12} className={classes.groupsPadding}>
              <Grid container>
                <Grid item xs={10}>
                  <h2 className={classes.headerTitle}>Groups</h2>
                </Grid>
                <Grid item xs={2} className={classes.createBtnBlock}>
                  <Button color="primary" variant="outlined" className={classes.addItemsButtonStyle} onClick={this.openDrawer}>
                    <CreateIcon className={classes.addIcon} /> CREATE GROUP
                  </Button>
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={12} className={classes.groupFilters}>
                  <FilterListIcon className={classes.filterIcon} />
                  <FormControl className={classes.formControl}>
                    <InputLabel htmlFor="age-simple">Group Type</InputLabel>
                    <Select
                      value={selectRef['group_type']}
                      onChange={this.handleFilterChange('group_type')}
                      inputProps={{
                        name: 'group_type',
                        id: 'age-simple',
                      }}
                    >
                      {groupTypes.map((typeObj) => {
                        return (<MenuItem value={typeObj.id}>{typeObj.name}</MenuItem>)
                      })
                      }
                    </Select>
                  </FormControl>
                  <FormControl className={classes.formControl} aria-describedby="name-helper-text">
                    <InputLabel htmlFor="name-helper">Parent TCIN</InputLabel>
                    <Input id="name-helper" value={selectRef['parent_tcin']} onChange={this.handleFilterChange('parent_tcin')} type="number" />
                  </FormControl>
                  <FormControl className={classes.formControl} aria-describedby="name-helper-text">
                    <InputLabel htmlFor="name-helper">Group Name</InputLabel>
                    <Input id="name-helper" value={selectRef['group_name']} onChange={this.handleFilterChange('group_name')} />
                  </FormControl>
                  <FormControl className={classes.formControl} aria-describedby="name-helper-text">
                    <InputLabel htmlFor="name-helper">Department ID</InputLabel>
                    <Input id="name-helper" value={selectRef['department_id']} onChange={this.handleFilterChange('department_id')} type="number" />
                  </FormControl>
                  <TextField
                    id="date"
                    label="Launch Date From"
                    type="date"
                    defaultValue=""
                    className={classes.formControl}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.handleFilterChange('start_time')}
                    value={selectRef['start_time']}
                  />
                  <TextField
                    id="date"
                    label="Launch Date To"
                    type="date"
                    defaultValue=""
                    className={classes.formControl}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    onChange={this.handleFilterChange('end_time')}
                    value={selectRef['end_time']}
                  />
                  <FormControl className={classes.formControl}>
                    <InputLabel htmlFor="status-simple">Status</InputLabel>
                    <Select
                      value={selectRef['group_state']}
                      onChange={this.handleFilterChange('group_state')}
                      inputProps={{
                        name: 'group_state',
                        id: 'status-simple',
                      }}
                    >
                      {statusList.map((typeObj) => {
                        return (<MenuItem value={typeObj}>{getStatusFormat(typeObj)}</MenuItem>)
                      })
                      }
                    </Select>
                  </FormControl>
                  <Button color="primary" variant="outlined" className={[classes.addItemsButtonStyle, classes.resetBtnPadding]} onClick={this.searchFilter}>
                    SEARCH
                  </Button>
                  <Button color="primary" variant="outlined" className={[classes.addItemsButtonStyle, classes.resetBtnPadding]} onClick={this.resetFilter}>
                    RESET
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          <GrouperDrawer
            drawerPosition="right"
            drawerContent={<CreateGroupContainer closeDrawer={this.closeDrawer} loadingBtnStatus={this.props.loadingBtnStatus} />}
            openStatus={this.state.drawerOpenStatus}
            closeCallback={this.closeDrawer}
          />
        </Toolbar>
      )
    }
}

DashboardToolbar.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(toolbarStyles)(DashboardToolbar)
