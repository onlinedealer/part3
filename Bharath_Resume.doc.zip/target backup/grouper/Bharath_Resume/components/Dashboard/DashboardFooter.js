import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import DeleteIcon from '@material-ui/icons/Delete'
import CircularProgress from '@material-ui/core/CircularProgress'

const styles = theme => ({
  footer: {
    borderTop: '1px solid #E4E4E4',
    position: 'absolute',
    bottom: 0,
    width: '100%',
    background: '#fff',
    display: 'flex',
  },
  container: {
    width: '100%',
    textAlign: 'right',
    padding: '10px 0px',
  },
  addItemsButtonStyle: {
    border: '1px solid #1976d2',
    color: '#1976d2',
    margin: '0 20px',
    fontWeight: 300,
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
  },
  saveButtonStyle: {
    position: 'relative',
    border: '1px solid #1976d2',
    color: '#1976d2',
    background: '#fff',
    margin: '0 40px',
    fontSize: 12,
    boxShadow: 'none',
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
    /* '&disbaled': {
      border: '0px solid #1976d2',
      background: 'rgb(182, 182, 182)',
      color: '#fff',
    }, */
  },
  saveButtonStyleDisabled: {
    border: '1px solid rgb(182, 182, 182)',
    background: 'rgb(182, 182, 182)',
    color: '#fff',
    margin: '0 40px',
    fontSize: 12,
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  addIcon: {
    width: '0.7em',
    height: '0.7em',
    marginRight: 10,
    borderRadius: 2,
  },
  saveIcon: {
    color: '#fff',
    background: 'transparent',
    width: '0.7em',
    height: '0.7em',
    marginRight: 7,
    borderRadius: 2,
  },
})

export class DashboardFooter extends React.Component {
  render () {
    const { classes, isDeleteDisabled, deleteMultipleConfirmCB, loadingBtnStatus } = this.props
    let isDeleteDisabledStatus = (loadingBtnStatus.status && loadingBtnStatus.btnName === 'Delete Group') ? true : isDeleteDisabled
    return (
      <div className={classes.footer}>
        <div className={classes.container}>
          <Grid container>
            <Grid item xs={12} >
              <Button variant="contained" className={isDeleteDisabledStatus ? classes.saveButtonStyleDisabled : classes.saveButtonStyle} disabled={isDeleteDisabledStatus} onClick={deleteMultipleConfirmCB}>
                <DeleteIcon className={classes.addIcon} />
                {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Delete Group') &&
                <CircularProgress
                  className={classes.progress}
                  size={25}
                />
                }
                    DELETE
              </Button>
            </Grid>
          </Grid>
        </div>
      </div>
    )
  }
}

export default withStyles(styles)(DashboardFooter)
