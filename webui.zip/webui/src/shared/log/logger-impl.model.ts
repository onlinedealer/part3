import { LOG_LEVELS } from './log-levels.model';
import { Logger } from './logger.model';
import { Styles } from './styles.model';

/**
 * @internal
 */
export class LoggerImpl implements Logger {
  private window: any;

  constructor(private name: string) {
    this.window = window;
  }

  trace(msg: string | Error): void {
    if (this.enabled(LOG_LEVELS.TRACE)) {
      this.window.console.debug(this.format('TRACE', msg), Styles.TRACE, Styles.CLASS, Styles.MSG);
    }
  }

  debug(msg: string | Error): void {
    if (this.enabled(LOG_LEVELS.DEBUG)) {
      this.window.console.debug(this.format('DEBUG', msg), Styles.DEBUG, Styles.CLASS, Styles.MSG);
    }
  }

  info(msg: string | Error): void {
    if (this.enabled(LOG_LEVELS.INFO)) {
      this.window.console.info(this.format('INFO', msg), Styles.INFO, Styles.CLASS, Styles.MSG);
    }
  }

  warn(msg: string | Error): void {
    if (this.enabled(LOG_LEVELS.WARN)) {
      this.window.console.warn(this.format('WARN', msg), Styles.WARN, Styles.CLASS, Styles.MSG);
    }
  }

  error(msg: string | Error): void {
    if (this.enabled(LOG_LEVELS.ERROR)) {
      this.window.console.error(this.format('ERROR', msg), Styles.ERROR, Styles.CLASS, Styles.MSG);
    }
  }

  private enabled(logLevel: number): boolean {
    return LOG_LEVELS[this.getLevel()] <= logLevel;
  }

  private format(level: string, msg: string | Error): string {
    // Output full stack trace for Errors.
    if (msg instanceof Error) {
      if (msg.stack) {
        msg = msg.stack;
      }
    }

    // Most loggers will use this format.
    if (this.name) {
      return `%c${level} %c[${this.name}] %c${msg}`;
    }

    // For nameless loggers, add %c style directive for any message w/leading class name related
    // text (e.g "[ClassName] Some message here" -> "%c[ClassName] Some message here").
    const hasClassName = /(^\[\w+\] )/;
    if (typeof msg === 'string' && hasClassName.test(msg as string)) {
      msg = (msg as string).replace(hasClassName, '%c$1%c');
      return `%c${level} ${msg}`;
    }

    // Nameless logger w/out class name info.
    return `%c${level}%c %c${msg}`;
  }

  private getLevel(): string {
    return this.window.spectrum.core.log.level();
  }
}
