import { Component, ChangeDetectionStrategy, ViewEncapsulation } from "@angular/core";
import { HeaderHelpMenuItem, HeaderHelpMenuProvider } from "../../common/header-help-menu-provider";
import { Observable, BehaviorSubject } from "rxjs";

@Component({
    selector: "landisgyr-header-help-area",
    templateUrl: "./header-help-area.component.html",
    styleUrls: ["../../styles/component.styles.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush,
    encapsulation: ViewEncapsulation.None
})
export class HeaderHelpAreaComponent {
    _menuItems$: Observable<Array<HeaderHelpMenuItem>>;
    menuOpen = new BehaviorSubject(false);
    constructor(private headerMenuItemProvider: HeaderHelpMenuProvider) {
        this._menuItems$ = this.headerMenuItemProvider.getMenuItems();
    }

    menuItemClicked(item: HeaderHelpMenuItem) {
        this.headerMenuItemProvider.menuItemClicked(item.id);
    }
}
