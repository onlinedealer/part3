import { Spies } from 'discovery-test';
import { ProfileResultsTableModel } from '../profile-results-table.model';
import { SematicAnalysisResultsComponent } from './sematic-analysis-results.component';
import { TreePath } from '../tree-path.model';
import { TreeTableModel } from '../tree-table.model';

describe('SematicAnalysisResultsComponent', () => {
  let component: SematicAnalysisResultsComponent;

  beforeEach(async () => {});

  beforeEach(() => {
    Spies.init();
    component = new SematicAnalysisResultsComponent(Spies.TranslateService);
    component.treePath = new TreePath();
    component.treePath.treeData = new TreeTableModel();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call singleSemanticTableConfig on single semantic type', () => {
    component._semanticStats = [
      {
        type: 'DateSemanticStatistics',
        group: 'SEMANTIC_ANALYSIS',
        semanticType: 'DATE',
        validity: {
          type: 'ValidityStatistics',
          validCount: 3060007,
          invalidCount: 6
        },
        displayName: 'Date',
        dateFormatFrequency: {
          type: 'FrequencyStatistics',
          frequency: {
            'yyyy-MM-dd': 3060000,
            'MM/dd/yyyy': 7,
            'dd/MM/yyyy': 2
          }
        }
      }
    ];
    component.loadData();
    expect(component.semanticStats.length).toEqual(1);
    expect(component.isMultiSemanticInfo).toBe(false);
    expect(component.semanticDonuts.length).toEqual(1);
  });

  it('should call multipleSemanticTableConfig on multiple semantic type', () => {
    component._semanticStats = [
      {
        type: 'SemanticStatistics',
        group: 'SEMANTIC_ANALYSIS',
        semanticType: 'LASTNAME',
        validity: {
          type: 'ValidityStatistics',
          validCount: 6,
          invalidCount: 3060007
        },
        displayName: 'Last Name'
      },
      {
        type: 'DateSemanticStatistics',
        group: 'SEMANTIC_ANALYSIS',
        semanticType: 'DATE',
        validity: {
          type: 'ValidityStatistics',
          validCount: 3060007,
          invalidCount: 6
        },
        displayName: 'Date',
        dateFormatFrequency: {
          type: 'FrequencyStatistics',
          frequency: {
            'yyyy-MM-dd': 3060000,
            'MM/dd/yyyy': 7,
            'dd/MM/yyyy': 2
          }
        }
      }
    ];
    component.treePath.columnView = true;
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 3060013;
    component.loadData();
    const donutChartWidth = component.getDonutChartWidth();
    expect(component.semanticStats.length).toEqual(2);
    expect(component.isMultiSemanticInfo).toBe(false);
    expect(component.semanticTables.length).toBe(1);
    expect(donutChartWidth).toBe(12);
  });
  it('should append stat arrays on single semantic type', () => {
    component._semanticStats = [
      {
        type: 'EmailSemanticStatistics',
        group: 'SEMANTIC_ANALYSIS',
        semanticType: 'EMAIL',
        validity: {
          type: 'ValidityStatistics',
          validCount: 3060007,
          invalidCount: 6
        },
        displayName: 'Email',
        dateFormatFrequency: {
          type: 'FrequencyStatistics',
          frequency: {
            'hotmail.com': 7920,
            'gmail.com': 508776,
            'yahoo.com': 13122
          }
        }
      }
    ];
    component.treePath.columnView = true;
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 3060007;
    component.loadData();
    const tableChartWidth = component.getTableChartWidth(1);
    expect(component.semanticTables.length).toEqual(1);
    expect(component.semanticDonuts.length).toEqual(1);
    expect(tableChartWidth).toBe(12);
    expect(component.semanticDonuts[0]['type']).toEqual(component._semanticStats[0]['semanticType']);
    expect(component.semanticDonuts[0]['displayName']).toEqual(component._semanticStats[0]['displayName']);
    expect(component.semanticDonuts[0]['data']).toEqual(component._semanticStats[0]['validity']);
  });
});
