import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { AuthenticationService } from 'discovery-shared';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertProfileMetricsService {
  baseUrl: string;

  constructor(
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('obsmetrics', 'profiling', 'api/v1/');
  }

  getTrendsHistory(
    assetId: string,
    metric: string,
    from?: Date,
    alertDate?: Date,
    sampleKey?: string,
    trendsCount?: number
  ): Observable<any> {
    // hardcoding need to be removed, Shapes Cardinality trends not avialble right now
    if (metric === 'Shapes Cardinality') {
      metric = 'Row Count';
    }

    let params: Param = {};

    if (from !== null && from !== undefined && alertDate !== null && alertDate !== undefined && trendsCount > 0) {
      params = {
        metricName: metric,
        fromDate:
          from.getFullYear() + '-' + ('0' + (from.getMonth() + 1)).slice(-2) + '-' + ('0' + from.getDate()).slice(-2),
        toDate:
          alertDate.getFullYear() +
          '-' +
          ('0' + (alertDate.getMonth() + 1)).slice(-2) +
          '-' +
          ('0' + alertDate.getDate()).slice(-2),
        trendsCount: trendsCount
      };
    } else if (from !== null && from !== undefined && alertDate !== null && alertDate !== undefined) {
      params = {
        metricName: metric,
        fromDate:
          from.getFullYear() + '-' + ('0' + (from.getMonth() + 1)).slice(-2) + '-' + ('0' + from.getDate()).slice(-2),
        toDate:
          alertDate.getFullYear() +
          '-' +
          ('0' + (alertDate.getMonth() + 1)).slice(-2) +
          '-' +
          ('0' + alertDate.getDate()).slice(-2)
      };
    } else if (from !== null && from !== undefined) {
      params = {
        metricName: metric,
        fromDate:
          from.getFullYear() + '-' + ('0' + (from.getMonth() + 1)).slice(-2) + '-' + ('0' + from.getDate()).slice(-2)
      };
    } else {
      params = {
        metricName: metric
      };
    }

    if (sampleKey) {
      params.sampleKey = sampleKey;
    }

    return this.httpClient.get(this.baseUrl + 'dataprofiles/trends/metric' + '/' + assetId, {
      headers: this.authenticationService.getHttpHeaders(),
      params: params
    });
  }
}

interface Param {
  [key: string]: any;
}
