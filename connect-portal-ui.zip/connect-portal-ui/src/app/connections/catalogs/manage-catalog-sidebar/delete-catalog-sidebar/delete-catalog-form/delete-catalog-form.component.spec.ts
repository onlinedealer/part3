import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../../../../core/transloco-testing.module';
import { DeleteCatalogFormComponent } from './delete-catalog-form.component';

describe('DeletePipelinesComponent', () => {
  let component: DeleteCatalogFormComponent;
  let fixture: ComponentFixture<DeleteCatalogFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [DeleteCatalogFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteCatalogFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return correct translation value for selected item', () => {
    component.connection = { connectionType: 'ORACLE' };
    expect(component.itemTypeSelected).toBe('connections.DELETE_CATALOG.SELECTED_OBJECTS.SCHEMAS');
    component.connection = { connectionType: 'DB2I' };
    expect(component.itemTypeSelected).toBe('connections.DELETE_CATALOG.SELECTED_OBJECTS.LIBRARIES');
    component.connection = { connectionType: 'KAFKA' };
    component.catalogStatus = { params: { totalNumber: 2000, structureType: 'topics', partialNumber: 2000 } };
    expect(component.itemTypeSelected).toBe('connections.DELETE_CATALOG.SELECTED_OBJECTS.TOPICS');
    component.catalogStatus = { params: { totalNumber: 1, structureType: 'topics', partialNumber: 1 } };
    expect(component.itemTypeSelected).toBe('connections.DELETE_CATALOG.SELECTED_OBJECTS.TOPIC');
  });

  it('should filter list of selected schemas to get schemas that have complete catalog status', () => {
    component.schemas = [
      { schema: 'test', status: 'COMPLETE' },
      { schema: 'test-1', status: 'FAILED' }
    ];
    expect(component.schemasOrLibrariesToBeRemoved).toEqual(1);
  });
});
