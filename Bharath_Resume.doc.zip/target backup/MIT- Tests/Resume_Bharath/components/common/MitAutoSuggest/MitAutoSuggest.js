import React from 'react'
import Autosuggest from 'react-autosuggest'
import './MitAutoSuggest.css'

export class MitAutoSuggest extends React.Component {
  constructor () {
    super()
    this.state = {
      value: '',
      suggestions: [],
      initSuggestions: [],
    }
  }

  componentWillMount () {
    let suggestionArray = []
    Object.keys(this.props.groupList).map((option) => {
      const dispOption = this.props.concatWith !== undefined ? option + ' - ' + this.props.groupList[option][0][this.props.concatWith] : option
      suggestionArray.push(dispOption)
    })
    this.setState({
      suggestions: suggestionArray,
      initSuggestions: suggestionArray,
    })
  }

  resetForm () {
    this.setState({
      value: '',
    })
  }

  getSuggestions = inputValue => {
    const inputLength = inputValue.length
    return inputLength === 0 ? [] : this.state.initSuggestions.filter(function (el) {
      return el.toLowerCase().indexOf(inputValue.toLowerCase()) > -1
    })
  }

  onSuggestionsFetchRequested = ({ value }) => {
    this.setState({
      suggestions: this.getSuggestions(value),
    })
  }

  onSuggestionsClearRequested = () => {
    if (this.props.clearField === 'yes') {
      this.setState({
        value: '',
      })
    }
  }

  getSuggestionValue = (suggestion) => {
    this.props.getSuggestionCallback(this.props.column_id, suggestion)
    return suggestion
  }

  onSuggestChange = (event, { newValue, method }) => {
    this.setState({
      value: newValue,
    })
    this.getSuggestionValue(newValue)
  }

  renderSuggestion = (suggestion) => {
    return (
      <span>{suggestion}</span>
    )
  }

  render () {
    const { classes } = this.props
    let placeHolderText = 'Apply to ' + this.props.filter_name + ' (optional)'

    const inputProps = {
      label: 'test',
      placeholder: placeHolderText,
      value: this.state.value,
      classes,
      onChange: this.onSuggestChange,
    }

    return (<Autosuggest
      suggestions={this.state.suggestions}
      onSuggestionsFetchRequested={this.onSuggestionsFetchRequested}
      onSuggestionsClearRequested={this.onSuggestionsClearRequested}
      getSuggestionValue={this.getSuggestionValue}
      renderSuggestion={this.renderSuggestion}
      inputProps={inputProps}
      id={this.props.id}
    />)
  }
}

export default MitAutoSuggest
