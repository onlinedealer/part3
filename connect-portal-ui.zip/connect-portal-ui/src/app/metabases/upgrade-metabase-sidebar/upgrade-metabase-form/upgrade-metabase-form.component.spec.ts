import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { Metabase } from '../../shared/metabase.model';
import { MetabasesApiService } from '../../shared/metabases-api.service';

import { UpgradeMetabaseFormComponent } from './upgrade-metabase-form.component';

describe('UpgradeMetabaseFormComponent', () => {
  let component: UpgradeMetabaseFormComponent;
  let fixture: ComponentFixture<UpgradeMetabaseFormComponent>;
  let metabasesApiService: MetabasesApiService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      declarations: [UpgradeMetabaseFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpgradeMetabaseFormComponent);
    metabasesApiService = TestBed.inject(MetabasesApiService);
    spyOn(metabasesApiService, 'getMetabaseVersionForUpgrade').and.returnValue(of({ response: '40g', id: '1' }));
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get metabase version available for upgrade', () => {
    component.open({} as Metabase);
    expect(component.metabaseExists).toBe(true);
    expect(metabasesApiService.getMetabaseVersionForUpgrade).toHaveBeenCalled();
    component.upgradedMetabaseVersion.subscribe((upgradeVersion) => expect(upgradeVersion).toEqual('40g'));
  });

  it('should handle error for fetching metabase version available for upgrade', () => {
    spyOn(component.metabaseDeletedEvent, 'emit');
    const errorResponse = { error: { message: 'Metabase not found in project' } } as HttpErrorResponse;
    component.handleError(errorResponse);
    expect(component.metabaseDeletedEvent.emit).toHaveBeenCalled();
    expect(component.metabaseExists).toBe(false);
  });

  it('should display user id & password input fields if connection type is not DB2I', () => {
    component.selectedMetabase = { name: 'test', dataConnection: { connectionType: 'ORACLE' } } as Metabase;
    expect(component.displayUsernamePasswordInputFields).toBe(true);
  });

  it('should hide user id & password input fields if connection type is DB2I', () => {
    component.selectedMetabase = { name: 'test', dataConnection: { connectionType: 'DB2I' } } as Metabase;
    expect(component.displayUsernamePasswordInputFields).toBe(false);
  });

  it('should initalise form values', () => {
    component.ngOnInit();
    expect(component.upgradeMetabaseForm.get('adminUserId').value).toEqual('');
    expect(component.upgradeMetabaseForm.get('adminUserPassword').value).toEqual('');
  });

  it('should initalise form content for a DB2I connection', () => {
    component.open({ name: 'test', dataConnection: { connectionType: 'DB2I', database: '0.1.2.3', port: '51701' } as Metabase });
    expect(component.selectedMetabase.dataConnection.connectionType).toEqual('DB2I');
    expect(component.databaseServerName).toEqual('0.1.2.3');
  });

  it('should initalise form content for a ORACLE connection', () => {
    component.open({ name: 'test', dataConnection: { connectionType: 'ORACLE', database: '1.2.3.4', port: '51701' } as Metabase });
    expect(component.selectedMetabase.dataConnection.connectionType).toEqual('ORACLE');
    expect(component.userIdInputLabel).toEqual('metabases.METABASE_FORM.ORACLE.USER_ID');
    expect(component.upgradeMetabaseForm.get('adminUserId').value).toEqual('SYS');
  });

  it('should initalise form content for a SQLSERVER connection', () => {
    component.open({ name: 'test', dataConnection: { connectionType: 'SQLSERVER', database: '2.3.4.5', port: '51701' } as Metabase });
    expect(component.selectedMetabase.dataConnection.connectionType).toEqual('SQLSERVER');
    expect(component.userIdInputLabel).toEqual('metabases.METABASE_UPGRADE.SQL_USER_ID');
    expect(component.upgradeMetabaseForm.get('adminUserId').value).toEqual('sa');
  });

  it('should initalise form content for a DB2 connection', () => {
    component.open({ name: 'test', dataConnection: { connectionType: 'DB2', database: '3.4.5.6', port: '51701' } as Metabase });
    expect(component.selectedMetabase.dataConnection.connectionType).toEqual('DB2');
    expect(component.userIdInputLabel).toEqual('metabases.METABASE_UPGRADE.DB2_USER_ID');
  });

  it('should get credentials of DB2I connection and set this as value of admin user and password fields', () => {
    const selectedMetabase = {
      name: 'test',
      dataConnection: {
        name: 'connection',
        connectionType: 'DB2I'
      },
      parameters: [
        { key: 'REPLICATION_USER_ID', value: 'rep1' },
        { key: 'REPLICATION_USER_PASSWORD', value: '?' }
      ],
      version: '40i'
    };
    component.open(selectedMetabase);
    expect(component.upgradeMetabaseForm.get('adminUserId').value).toEqual('rep1');
    expect(component.upgradeMetabaseForm.get('adminUserPassword').value).toEqual('?');
  });

  it('should enable primary button if value entered in required fields', () => {
    spyOn(component.primaryButtonStateChange, 'emit');
    component.upgradeMetabaseForm.patchValue({ adminUserId: 'rep1', adminUserPassword: '?' });
    expect(component.primaryButtonStateChange.emit).toHaveBeenCalledWith(false);
  });

  it('should disable primary button if value entered in required fields', () => {
    spyOn(component.primaryButtonStateChange, 'emit');
    component.upgradeMetabaseForm.patchValue({ adminUserId: 'rep1', adminUserPassword: '' });
    expect(component.primaryButtonStateChange.emit).toHaveBeenCalledWith(true);
  });
});
