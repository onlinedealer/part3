import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MessageService } from 'primeng/api';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { AirbyteApiService } from 'src/app/pipelines/pipeline/shared/airbyte-api.service';

import { SharedConnectionsComponent } from './shared-connections.component';

describe('SharedConnectionsComponent', () => {
  let component: SharedConnectionsComponent;
  let fixture: ComponentFixture<SharedConnectionsComponent>;

  let airbyteApiService;
  let messageService;

  beforeEach(async () => {
    airbyteApiService = jasmine.createSpyObj('AirbyteApiService', ['getConnectionSpec', 'getConnectionDetails']);
    airbyteApiService.getConnectionDetails.and.returnValue(
      of([
        {
          isSource: false,
          isTarget: true,
          logoURL: '',
          type: 'S3'
        }
      ])
    );
    airbyteApiService.getConnectionSpec.and.returnValue(of(null));

    messageService = jasmine.createSpyObj('MessageService', ['add']);
    messageService.add.and.callThrough();

    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [SharedConnectionsComponent],
      providers: [
        { provide: AirbyteApiService, useValue: airbyteApiService },
        { provide: MessageService, useValue: messageService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SharedConnectionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load connection spec', () => {
    const event = {
      isSource: false,
      isTarget: true,
      logoURL: '',
      type: 'S3'
    };
    component.loadSelectedConnection(event);
    expect(airbyteApiService.getConnectionSpec).toHaveBeenCalled();
    expect(airbyteApiService.getConnectionSpec).toHaveBeenCalledWith(event);
    expect(component.connectionSpec).toEqual(null);
  });

  it('should throw error if unable to load connection spec', () => {
    airbyteApiService.getConnectionSpec.and.returnValue(throwError(() => new Error('404')));

    const event = {
      isSource: false,
      isTarget: true,
      logoURL: '',
      type: 'S3'
    };
    component.loadSelectedConnection(event);

    expect(messageService.add).toHaveBeenCalled();
    expect(messageService.add).toHaveBeenCalledWith({ severity: 'error', detail: 'connections.API_ERROR.CONNECTION_SPEC_NOT_FOUND' });
  });

  it('should load connection detail', () => {
    component.ngOnInit();
    expect(airbyteApiService.getConnectionDetails).toHaveBeenCalled();
    expect(component.connectionTypes).toEqual([
      {
        isSource: false,
        isTarget: true,
        logoURL: '',
        type: 'S3'
      }
    ]);
  });

  it('should throw error if unable to load connection detail', () => {
    airbyteApiService.getConnectionDetails.and.returnValue(throwError(() => new Error('404')));

    component.ngOnInit();
    expect(airbyteApiService.getConnectionDetails).toHaveBeenCalled();
    expect(messageService.add).toHaveBeenCalled();
    expect(messageService.add).toHaveBeenCalledWith({ severity: 'error', detail: 'connections.API_ERROR.CONNECTION_TYPE_UNABLE_TO_LOAD' });
  });
});
