import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { of, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { AgentsApiService } from '../agents/shared/agents-api.service';
import { getTranslocoModule } from '../core/transloco-testing.module';
import { CatalogApiService } from './catalogs/shared/catalog-api.service';
import { CatalogStatusSummary } from './catalogs/shared/catalog-status-summary';
import { ConnectionSidebarComponent } from './connection-sidebar/connection-sidebar.component';
import { ConnectionsComponent } from './connections.component';
import { Connection } from './shared/connection';
import { ConnectionsApiService } from './shared/connections-api.service';

describe('ConnectionsComponent', () => {
  let component: ConnectionsComponent;
  let fixture: ComponentFixture<ConnectionsComponent>;
  let connectionService: ConnectionsApiService;
  let catalogApiService: CatalogApiService;
  let agentService: AgentsApiService;
  let mockFeatureFlagService: any;

  const mockSupportedSources = [
    { connectionType: 'ORACLE', accessMethods: ['JDBC'] },
    { connectionType: 'DB2ZOS', accessMethods: ['DB2ZOS'] },
    { connectionType: 'SQLSERVER', accessMethods: ['JDBC'] }
  ];

  @Component({
    selector: 'p-connect-connection-sidebar',
    template: '',
    providers: [
      {
        provide: ConnectionSidebarComponent,
        useClass: MockConnectionSidebarComponent
      }
    ]
  })
  class MockConnectionSidebarComponent {
    openConnection() {}
  }

  const mockSupportedTargets = [{ connectionType: 'KAFKA', accessMethods: [] }];

  let catalogStatusMockResponse = {
    workspaceId: 'Precisely',
    connectionId: 'test1',
    schemas: {
      total: 1,
      completed: 1,
      inprogress: 0,
      error: 0,
      stopped: 0,
      tables: {
        total: 7,
        completed: 7,
        inprogress: 0,
        error: 0,
        stopped: 0
      }
    },
    topics: {
      total: 0,
      completed: 0,
      inprogress: 0,
      error: 0,
      stopped: 0
    },
    subjects: {
      total: 0,
      completed: 0,
      inprogress: 0,
      error: 0,
      stopped: 0,
      schemas: {
        total: 0,
        completed: 0,
        inprogress: 0,
        error: 0,
        stopped: 0
      }
    },
    status: 'complete'
  } as CatalogStatusSummary;

  beforeEach(async () => {
    mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      declarations: [ConnectionsComponent, MockConnectionSidebarComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {
          provide: ConnectionSidebarComponent,
          useClass: MockConnectionSidebarComponent
        },
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectionsComponent);
    environment.supportedSourceConnectionTypes = mockSupportedSources;
    environment.supportedTargetConnectionTypes = mockSupportedTargets;
    component = fixture.componentInstance;
    catalogApiService = TestBed.inject(CatalogApiService);
    connectionService = TestBed.inject(ConnectionsApiService);
    agentService = TestBed.inject(AgentsApiService);
    jasmine.getEnv().allowRespy(true);
    spyOn(connectionService, 'getAll').and.returnValue(
      of([
        { id: 'test1', connectionType: 'test1', accessFromServer: { agentId: 'test1' } },
        { id: 'test2', connectionType: 'test2', accessFromServer: { agentId: 'test2' } },
        { id: 'test3', connectionType: 'test3', accessFromServer: { agentId: 'test3' } }
      ])
    );
    spyOn(agentService, 'getAll').and.returnValue(of([{ agentId: 'test1', agentName: 'test1' }]));
    spyOn(catalogApiService, 'statusSummary').and.returnValue(of([catalogStatusMockResponse]));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('connection list', () => {
    it('should remove SQLSERVER and DB2 connection type if feature flag for them are not enabled', () => {
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(false);
      component.ngOnInit();
      expect(component.supportedConnectionTypes.filter((connection) => connection === 'SQLSERVER').length).toBe(0);
      expect(component.supportedConnectionTypes.filter((connection) => connection === 'DB2').length).toBe(0);
    });
  });

  it('should disable the delete button if not item is selected', () => {
    component.selectedConnections = null;
    expect(component.tableConfiguration.menuItemDisabled(component.toolbarMenuItems[0], {})).toBe(true);
    component.selectedConnections = [];
    expect(component.tableConfiguration.menuItemDisabled(component.toolbarMenuItems[0], {})).toBe(true);
  });

  it('should enable by default items in the menu', () => {
    expect(component.tableConfiguration.menuItemDisabled({ id: 'enable_by_default' }, {})).toBe(false);
  });

  it('should enable the delete button when items have been selected', () => {
    component.selectedConnections = [{ id: 'abcd' }];
    expect(component.tableConfiguration.menuItemDisabled(component.toolbarMenuItems[0], {})).toBe(false);
  });

  it('should open connection sidebar to add a new connection', () => {
    component.tableConfiguration.createButtonClicked();
    expect(component.isConnectionSidebarVisible).toBe(true);
  });

  it('should keep track of selected items', () => {
    component.tableConfiguration.rowSelectionChangedEvent([{ id: 'abcd' } as Connection]);
    expect(component.selectedConnections.length).toBe(1);
  });

  it('should open the delete dialog', () => {
    component.toolbarMenuItems[0].command();
    expect(component.deleteSidebarConfiguration.isSidebarVisible).toBe(true);
  });

  it('should support opening the delete dialog', () => {
    spyOn(connectionService, 'delete').and.returnValue(of());
    component.tableConfiguration.rowAction.menuItems
      .find((item) => item.id === 'deleteMenuItem')
      .command({ item: { target: { id: '1' } } });
    expect(component.deleteSidebarConfiguration.isSidebarVisible).toBe(true);
  });

  it('should handle deleting a connection', () => {
    spyOn(component.deleteCompleted, 'next').and.returnValue();
    spyOn(connectionService, 'delete').and.returnValue(of({}));
    spyOn(catalogApiService, 'deleteCatalogs').and.returnValue(of({}));
    component.deleteSidebarConfiguration.deleteButtonClicked([{ id: '1' }]);
    expect(component.deleteCompleted.next).toHaveBeenCalled();
  });

  it('should handle an error when deleting a connection', () => {
    spyOn(component.deleteCompleted, 'next').and.returnValue();
    spyOn(connectionService, 'delete').and.returnValue(throwError({}));
    component.deleteSidebarConfiguration.deleteButtonClicked([]);
    expect(component.deleteCompleted.next).toHaveBeenCalled();
  });

  it('should support editing a connection', () => {
    spyOn(component.connectionSidebarComponent, 'openConnection').and.returnValue();
    component.tableConfiguration.rowAction.menuItems.find((item) => item.id === 'editMenuItem').command({ item: { target: { id: '1' } } });
    expect(component.isConnectionSidebarVisible).toBe(true);
    expect(component.connectionSidebarComponent.openConnection).toHaveBeenCalled();
  });

  it('should handle an error when deleting a connection when catalogInformation dosent exists', () => {
    spyOn(component.deleteCompleted, 'next').and.returnValue();
    spyOn(connectionService, 'delete').and.returnValue(of({}));
    spyOn(catalogApiService, 'deleteCatalogs').and.returnValue(throwError({}));
    component.deleteSidebarConfiguration.deleteButtonClicked([{ id: '1' }]);
    expect(component.deleteCompleted.next).toHaveBeenCalled();
  });

  it('has manage catalog as an action that can be clicked', () => {
    expect(component.isManageCatalogSidebarVisible).toBeFalse();
    const manageCatalogItem = component.tableConfiguration.rowAction.menuItems.find((item) => item.id === 'manageCatalogMenuItem');
    expect(manageCatalogItem.id).toBe('manageCatalogMenuItem');
    manageCatalogItem.command({ item: { target: { id: 'test' } } });
    expect(component.isManageCatalogSidebarVisible).toBeTrue();
    expect(component.manageCatalogTargetConnection.id).toBe('test');
  });

  it('should expect list of connection types to include those hidden under feature flag', () => {
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
    component.ngOnInit();
    expect(component.supportedConnectionTypes.length).toEqual(5);
  });

  it('should expect list of connection types to not include those hidden under feature flag', () => {
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(false);
    component.ngOnInit();
    expect(component.supportedConnectionTypes.length).toEqual(2);
  });

  it('should set interval of 30 seconds to autorefresh catalog status if feature is enabled', () => {
    spyOn(catalogApiService, 'statusSummary').and.returnValue(of([catalogStatusMockResponse]));
    spyOn(window, 'setInterval').and.stub();
    component.ngOnInit();
    expect(window.setInterval).toHaveBeenCalled();
  });

  it('should call status summary API after 30 second refresh', () => {
    spyOn(catalogApiService, 'statusSummary').and.returnValue(of([catalogStatusMockResponse]));
    jasmine.clock().install();
    component.ngOnInit();
    jasmine.clock().tick(35000);
    expect(catalogApiService.statusSummary).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  describe('getting Connections Data', () => {
    it('should update the connections table', () => {
      spyOn(catalogApiService, 'statusSummary').and.returnValue(of([catalogStatusMockResponse]));
      component.onConnectionSavedEvent(null);
      expect(connectionService.getAll).toHaveBeenCalled();
      expect(catalogApiService.statusSummary).toHaveBeenCalled();
    });

    it('sets agents correctly', () => {
      component.onConnectionSavedEvent(null);
      expect(component.connections.length).toBe(3);
      expect(component.connections[0].agentName).toBe('test1');
      expect(component.connections[1].agentName).toBe('-');
      expect(component.connections[2].agentName).toBe('-');
    });
  });

  describe('on destroy', () => {
    it('should stop autorefresh of connections catalog status', () => {
      spyOn(window, 'clearInterval').and.stub();
      component.ngOnDestroy();
      expect(window.clearInterval).toHaveBeenCalled();
    });
  });
});
