import { Component, OnInit } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';

@Component({
  selector: 'app-account-info',
  templateUrl: './account-info.component.html',
  styleUrls: ['./account-info.component.scss']
})
export class AccountInfoComponent implements OnInit {

  imagesPaths:Object = ImagePaths;
  constructor() { }

  ngOnInit() {
  }

}
