
(function () {
    'use strict';

    angular.module('arm').controller('homeCtrl',
            ['$scope', '$ionicModal', '$ionicSideMenuDelegate', 'homeService', '$state', 'dealService', 'activityService', 'contactService', 'utility', 'authService', 'GENERAL_CONFIG', '$rootScope', 'MASTER_TABLE', '$filter', '$timeout', homeCtrl]);

    function homeCtrl($scope, $ionicModal, $ionicSideMenuDelegate, homeService, $state, dealService, activityService, contactService, utility, authService, GENERAL_CONFIG, $rootScope, MASTER_TABLE, $filter, $timeout) {

        $scope.showContacts = true;
        $scope.showCompany = false;
        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };

        //############### LoggedInAs User  functionality START ##############
        $ionicModal.fromTemplateUrl('app/views/common/loggedInAsUserList.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function (modal) {
            $scope.modalLoginAsUsers = modal;
        });

        $scope.loggedInUsers = [];
        var loggedInUserInfo = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        if (loggedInUserInfo)
            $scope.selfLoggedInID = loggedInUserInfo.UserID;

        $scope.selectedUser = function (index, isSelfUser) {
            utility.selectedLogginAsUser(index, isSelfUser, $scope.modalLoginAsUsers, $scope.loggedInUsers).then(function (res) {
                if ($rootScope.isAccessingOtherUserProfile) {
                    homeService.syncServerRecords();
                    $scope.IndividualContactList = homeService.IndividualContactList;
                    $scope.dealList = homeService.dealList;
                    $scope.actList = homeService.actList;
                    $scope.campList = homeService.campList;
                }
                else {
                    homeService.loadContacts($scope.IndividualContactList);
                    homeService.loadActivities($scope.actList);
                    homeService.loadDeals($scope.dealList);
                    homeService.loadCamps($scope.campList);
                }
            });
        }


        $scope.openLogInUserMenu = function () {
            $scope.loggedInUsers = [];
            utility.loadLoggodInAsUsers($scope.loggedInUsers);
            $scope.modalLoginAsUsers.show();

        };
        $scope.closeLogInMenu = function () {
            $scope.modalLoginAsUsers.hide();
            $scope.loggedInUsers = [];
        };
        //############### LoggedInAs User  functionality END ##############


        // Modal filter
        $ionicModal.fromTemplateUrl('app/views/contact/contactFilter.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalcntfilter = modal;
        });
        $scope.openFilter = function () {
            $scope.modalcntfilter.show();
        };
        $scope.closeModalB = function () {
            $scope.modalcntfilter.hide();
        };

        $scope.openDashboardGraph = function () {
            $state.go("tab.dashboardGraph");
        };

        $scope.openAlertScreen = function () {
            $state.go("tab.alertList");
        };


        function init() {
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("deviceready", onDeviceReady, false);
            }
            $scope.IndividualContactList = [];
            $scope.dealList = [];
            $scope.actList = [];
            $scope.campList = [];
            $scope.CompanyContactList = [];
            if ($rootScope.previousState.name == 'signin') {
                homeService.syncServerRecords();
                $scope.IndividualContactList = homeService.IndividualContactList;
                $scope.dealList = homeService.dealList;
                $scope.actList = homeService.actList;
                $scope.campList = homeService.campList;
            }
            else {
                homeService.loadContacts($scope.IndividualContactList);
                homeService.loadActivities($scope.actList);
                homeService.loadDeals($scope.dealList);
                homeService.loadCamps($scope.campList);
            }
        };

        init();

        function syncServerRecords() {
            $scope.allDeviceObjIdsByLoginUserID = []; $scope.allActDevicesByLoginUserID = []; $scope.allDealDevicesByLoginUserID = [];
            homeService.synchData().then(function (response) {
                var r = response;
                utility.busyCursorStart();

                //syncContacts(response.Contacts);
                contactService.sqlGetAllDeviceObjIds().then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        $scope.allDeviceObjIdsByLoginUserID.push(result.rows.item(i));
                    }
                    contactService.syncServerContactFromOtherModule(response.Contacts, $scope.allDeviceObjIdsByLoginUserID);
                    if ($scope.IndividualContactList.length == 0) {
                        loadContacts();
                    }
                });

                // Update and insert into local device DB for Deal section
                // syncDealServerRecords(response);
                dealService.sqlGetAllDealDeviceObjIds().then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        $scope.allDealDevicesByLoginUserID.push(result.rows.item(i));
                    }
                    var obj = new Object();
                    obj.OverDue = 0;
                    dealService.syncDealServerRecords(response.Deals, $scope.dealList, obj, $scope.allDealDevicesByLoginUserID);
                    if ($scope.dealList.length == 0) {
                        loadDeals();
                        loadCamps();
                    }

                });

                activityService.sqlGetAllActDeviceObjIds().then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        $scope.allActDevicesByLoginUserID.push(result.rows.item(i));
                    }
                    var obj = new Object();
                    obj.OverDue = 0;
                    activityService.syncServerRecords(response.Activities, $scope.actList, obj, $scope.allActDevicesByLoginUserID);
                    if ($scope.actList.length == 0) {
                        loadActivities();
                    }
                });

               
                $timeout(function () {
                    utility.busyCursorEnd();
                }, 4000);
            });
        }

        $scope.displayEmployerName = function (item) {
            var employerName = "";
            if (item.IsRepresentative == false) {
                employerName = item.EmployerName;
            } else {
                employerName = item.CompanyName;
            }
            return employerName;
        };

        // details page
        $scope.contactDetails = function (contactObj, objType, repCompany) {
            //debugger
            contactService.setSelectedContactType(objType);

            contactService.setSelectedIndividualContact(contactObj);
            if (contactObj.IsRepresentative == false) {
                contactService.sqlGetCompanyData(contactObj.EmployerDeviceObjID).then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        var companyObjdata = contactService.models().contactModel;
                        companyObjdata = utility.syncModelWithCollection(result.rows.item(i), companyObjdata);
                        contactService.setSelectedCompanyContact(companyObjdata);
                    }
                    if (result.rows.length == 0) {
                        contactService.setSelectedCompanyContact(null);
                    }
                });
            } else {
                contactService.setSelectedCompanyContact(repCompany);
            }
            if (contactObj.IsRepresentative == false)
                $state.go('tab.contactDetails');
            else $state.go('tab.repreContactDetails');

        }

        function syncActivties(serverResponse) {
            angular.forEach(serverResponse, function (responseObj) {
                var createNewActObjModel = activityService.activityMod().uiObject;
                utility.syncModelWithoutInnerCollection(responseObj, createNewActObjModel);
                $scope.actList.push(createNewContactObjModel);
            });
        }

        function syncContacts(serverResponse) {
            angular.forEach(serverResponse, function (responseObj) {
                if (responseObj.ContactTypeID == contactService.constants().contactType.Individual) {
                    var createNewContactObjModel = contactService.models().contactModel;
                    utility.syncModelWithoutInnerCollection(responseObj, createNewContactObjModel);
                    createNewContactObjModel.Priority = utility.getColorCodeForContact(createNewContactObjModel.NextContactedDate);
                    $scope.IndividualContactList.push(createNewContactObjModel);
                }
                //if (responseObj.ContactTypeID == contactService.constants().contactType.Individual) {
                //    var existedRecord = $filter('filter')($scope.IndividualContactList, { DeviceObjID: responseObj.DeviceObjID });
                //    if (existedRecord.length == 0) {
                //        var createNewContactObjModel = contactService.models().contactModel;
                //        utility.syncModelWithoutInnerCollection(responseObj, createNewContactObjModel);
                //        if (createNewContactObjModel.IsRepresentative == false) {
                //            createNewContactObjModel.Priority = utility.getColorCodeForContact(createNewContactObjModel.NextContactedDate);
                //            $scope.IndividualContactList.push(createNewContactObjModel);
                //        }
                //        else {
                //            var relMappingArray = responseObj.ContactRelationshipMappings;
                //            var relatedRelationArr = $filter('filter')(relMappingArray, { ContactRelationshipTypeID: $scope.contactRelationTypes.RepresentativeOf });
                //            angular.forEach(relatedRelationArr, function (relationMap) {
                //                var existingCompany = $filter('filter')($scope.CompanyContactList, { DeviceObjID: relationMap.RelationshipWithContactDeviceObjID });
                //                if (existingCompany.length > 0) {
                //                    var existingCompanyRep = $filter('filter')(existingCompany[0].Representatives, { DeviceObjID: responseObj.DeviceObjID });
                //                    if (existingCompanyRep.length == 0) {
                //                        createNewContactObjModel.Priority = utility.getColorCodeForContact(createNewContactObjModel.NextContactedDate);
                //                        existingCompany[0].Representatives.push(createNewContactObjModel);
                //                    } else {
                //                        utility.syncModelWithCollection(createNewContactObjModel, existingCompanyRep[0]);
                //                    }
                //                }
                //            });
                //        }
                //    }
                //}
                //else {
                //    // This condition for the Company Contact List
                //    var existedRecord = $filter('filter')($scope.CompanyContactList, {DeviceObjID: responseObj.DeviceObjID});
                //    if (existedRecord.length == 0) {
                //        var createNewContactObjModel = contactService.models().contactModel;
                //        utility.syncModelWithoutInnerCollection(responseObj, createNewContactObjModel);

                //        if (createNewContactObjModel.IsEmployer == false) {
                //            setTimeout(function () {
                //                utility.sqlGetAllRepresentativeDetails(createNewContactObjModel).then(function (result) {
                //                    var companyObj = result[0];
                //                    for (var j = 0; j < result[1].rows.length; j++) {
                //                        var repObjList = contactService.models().contactModel;
                //                        repObjList = utility.syncModelWithCollection(result[1].rows.item(j), repObjList);
                //                        repObjList.Priority = utility.getColorCodeForContact(repObjList.NextContactedDate);
                //                        var existingCompanyRep2 = $filter('filter')(companyObj.Representatives, { DeviceObjID: repObjList.DeviceObjID });
                //                        if (existingCompanyRep2.length == 0)
                //                            companyObj.Representatives.push(repObjList);
                //                    }
                //                });
                //            }, 1);

                //            $scope.CompanyContactList.push(createNewContactObjModel);
                //        }
                //    }
                //}
            });

            //if ($scope.IndividualContactList.length > 0) {
            //    $scope.showContacts = true;
            //}
            //else {
            //    $scope.showContacts = false;
            //}
            //if ($scope.CompanyContactList.length > 0) {
            //    $scope.showCompany = true;
            //}
            //else
            //{
            //    $scope.showCompany = false;
            //}
        }

        function loadContacts() {
            $scope.contactTypeInd = contactService.constants().contactType.Individual;
            homeService.sqlGetContactData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var individualObjList = contactService.models().contactModel;
                    individualObjList = utility.syncModelWithCollection(result.rows.item(i), individualObjList);
                    individualObjList.Priority = utility.getColorCodeForContact(individualObjList.NextContactedDate);
                    $scope.IndividualContactList.push(individualObjList);
                }
                ////console.log($scope.IndividualContactList);
            });
        }

        function loadActivities() {
            homeService.sqlGetActData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var srcObj = result.rows.item(i);
                    $scope.actList.push(activityService.activityMod().uiObject);
                    $scope.actList[i] = utility.syncModelWithCollection(srcObj, $scope.actList[i]);
                    $scope.actList[i].Priority = utility.getColorCode(result.rows.item(i)['ActivityDate'], result.rows.item(i)['ActivityTime'], result.rows.item(i)['ActivityStageID']);
                    $scope.actList[i].Notes = [];

                    loadNote(result.rows.item(i)['DeviceObjID'], $scope.actList[i].Notes);
                }
            },
            function (err) {
                $scope.errorMessage = err;
            });
        }

        function loadNote(actId, objNote) {
            activityService.sqlGetNote(actId).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    objNote.Description = result.rows.item(i)['Description'];
                }
            });
        }

        function loadDeals() {
            homeService.sqlGetDealData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var srcObj = result.rows.item(i);
                    $scope.dealList.push(dealService.dealMod().uiObject);
                    $scope.dealStageModelID = utility.dealStageModelIDCheck(result.rows.item(i)['DealStageID']);
                    $scope.dealList[i].Priority = utility.getColorCodeForDeals(result.rows.item(i)['ExpectedDealCloseDate'], $scope.dealStageModelID);
                    $scope.dealList[i] = utility.syncModelWithCollection(srcObj, $scope.dealList[i]);

                    $scope.dealList[i].ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate($scope.dealList[i].ExpectedDealCloseDate).toString();
                    $scope.dealList[i].OwnerNameToDisplay = utility.getNameByOrOwner($scope.dealList[i]);
                }
            },
            function (err) {
                $scope.errorMessage = err;
            });
        }

        function loadCamps() {
            homeService.sqlGetCampData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var srcObj = result.rows.item(i);
                    $scope.campList.push(dealService.dealMod().uiObject);
                    $scope.campaignStageModelID = utility.dealStageModelIDCheck(result.rows.item(i)['DealStageID']);
                    $scope.campList[i].Priority = utility.getColorCodeForDeals(result.rows.item(i)['ExpectedDealCloseDate'], $scope.campaignStageModelID);
                    $scope.campList[i] = utility.syncModelWithCollection(srcObj, $scope.campList[i]);

                    $scope.campList[i].ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate($scope.campList[i].ExpectedDealCloseDate).toString();
                    $scope.campList[i].OwnerNameToDisplay = utility.getNameByOrOwner($scope.campList[i]);
                }
            },
            function (err) {
                $scope.errorMessage = err;
            });
        }

        $scope.toggleGroup = function (group) {
            group.show = !group.show;
        };

        $scope.isGroupShown = function (group, accordTitle) {
            if (accordTitle == 'Activities') {
                return group.show;
            } else {
                return !group.show;
            }
        };

        $scope.groupsAcd = [
                {
                    title: 'Deals',
                    content: 'dealList',
                    icon: 'icon-deals'
                },
                {
                    title: 'Contacts',
                    content: 'contactList',
                    icon: 'icon-contacts-title'
                },
                {
                    title: "Activities",
                    content: 'activityList',
                    icon: 'icon-activity'
                },
                {
                    title: "Campaigns",
                    content: 'campaignsList',
                    icon: 'icon-campaigns'

                }
        ];

        /////////////////////////////////////activity Module//////////////////////////////////////////

        function onDeviceReady() {
            // Register the event listener
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("resume", onEndCallKeyDown, false);
            }
        }

        var count = 0;
        $scope.actID = 0;
        $scope.startDt;
        function onEndCallKeyDown() {
            if ($scope.actType != 'Call') return;
            count++;
            var endDt = new Date();
            checkTime($scope.startDt, endDt);
        }

        function checkTime(startDt, endDt) {
            var dif = endDt.getTime() - startDt.getTime();
            //var startSec = startDt.getSeconds();
            //var endSec = endDt.getSeconds();
            var difDt = dif / 1000;
            var finalDifDate = Math.abs(difDt);
            if (finalDifDate >= 15) {
                $scope.openHappend('D', $scope.actID, $scope.actType);
            }
        }

        $scope.screenType = GENERAL_CONFIG.ScreenType.HomeActivity;

        $scope.openActivityType = function (type, activitiesID, stageId, ConDevId) {
            if (stageId > GENERAL_CONFIG.ActivityStage.Open) {
                return;
            }
            activityService.sqlGetCommnications(ConDevId).then(function (result) {
                var comArr = contactService.getAllComData(result);
                $scope.phone = comArr.mobilePhone;
                $scope.email = comArr.email;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                $scope.screenType = GENERAL_CONFIG.ScreenType.HomeActivity;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                if (type == 1) {
                    $scope.callNumber(activitiesID);
                }
                else if (type == 3) {//sms
                    $scope.openSMS(activitiesID);
                }
                else if (type == 4) {//email
                    $scope.openEmail(activitiesID);
                }
            });

        }

        $scope.openSMS = function (activitiesID) {

            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }
            var message = '';//'hello text';
            //console.log("going to send " + message + " to " + number);

            //simple validation for now
            //if (number === '' || message === '') return;

            var msg = {
                phoneNumber: number,
                textMessage: message
            };
            //CONFIGURATION
            var options = {
                replaceLineBreaks: false, // true to replace \n by a new line, false by default
                android: {
                    intent: 'INTENT'  // send SMS with the native android SMS messaging
                    //intent: '' // send SMS without open any other app
                }
            };

            var success = function (res) {
                var s = res;
                $scope.openHappend('D', activitiesID, 'SMS');
                //if(s == 'ok')
                //alert('Message sent successfully');
            };

            var error = function (e) { alert('Message Failed:' + e); };
            sms.send(number, message, options, success, error);
        }

        $scope.openEmail = function (activitiesID) {
            //if (utility.alertMsg(stageId)) {
            //    return;
            //}
            cordova.plugins.email.open({
                to: $scope.email,
                cc: '',
                bcc: [''],
                subject: 'Greetings',
                body: 'test mail'
            });
            $scope.openHappend('D', activitiesID, 'Email');
        }

        $scope.callNumber = function (activitiesID) {
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }

            window.plugins.CallNumber.callNumber(function () {
                if (window.cordova && ionic.Platform.isAndroid()) {
                    $scope.startDt = new Date();
                    $scope.actType = 'Call';
                    $scope.actID = activitiesID;
                    count++;
                }
                else {
                    $scope.openHappend('D', activitiesID, 'Call');
                }
            }, function () {
                console.log("eroor");
                //error logic goes here
            }, number)
        };

        $scope.openHappend = function (val, devId, actType) {
            activityService.setActStatus('C');
            if ($scope.screenType == GENERAL_CONFIG.ScreenType.HomeActivity)
                activityService.setActivity(utility.getObjData($scope.actList, 'DeviceObjID', devId));
            $state.go('tab.activityHappen', { devObjId: devId, actStatgeType: val, screenType: $scope.screenType, actType: actType });
        };

        $scope.activitiesdetail = function (activitiesId) {
            $scope.selActTypeIndx = -1;
            activityService.setActivity(utility.getObjData($scope.actList, 'DeviceObjID', activitiesId))
            $state.go('tab.activityDetail', { activitiesId: activitiesId, screenType: 'List' });
        }

        $scope.selActTypeIndx = -1;
        $scope.selConActTypeIndx = -1;
        $scope.selConActTypeParentIndx = -1;
        $scope.fnclickToggle = function ($index, actStageId) {
            if (actStageId > 1) return;
            $scope.selActTypeIndx = $index;
            $scope.selConActTypeIndx = -1;
            $scope.selConActTypeParentIndx = -1;
        };

        $scope.fnContactClickToggle = function (index, parIndx) {
            $scope.selConActTypeIndx = index;
            $scope.selConActTypeParentIndx = parIndx;
            $scope.selActTypeIndx = -1;
        };

        $scope.fnswitchToggle = function ($index) {
            $scope.selActTypeIndx = -1;            
            $scope.selConActTypeIndx = -1;
            $scope.selConActTypeParentIndx = -1;
        };
        /////////////////////////////////////activity Module END//////////////////////////////////////////

        /////////////////////////////////////Contact module start/////////////////////////////////////////
        $scope.openActType = function (type, conDevId, model, cmpModel) {
            activityService.sqlGetCommnications(conDevId).then(function (result) {
                var comArr = contactService.getAllComData(result);
                $scope.phone = comArr.mobilePhone;
                $scope.email = comArr.email;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                $scope.screenType = GENERAL_CONFIG.ScreenType.HomeContact;
                if (model.IsRepresentative == false) {
                    contactService.setSelectedIndividualContact(model);
                    contactService.setSelectWhathappened(contactService.constants().contactType.Individual);
                }
                else {
                    contactService.setSelectedCompanyContact(cmpModel);
                    contactService.setSelectedIndividualContact(model);
                    contactService.setSelectWhathappened(contactService.constants().contactType.Company);
                }
                if (type == 1) {
                    $scope.callNumber(conDevId);
                }
                else if (type == 3) {//sms
                    $scope.openSMS(conDevId);
                }
                else if (type == 4) {//email
                    $scope.openEmail(conDevId);
                }
            });
        }

        ///////////////////////////////////contact module end/////////////////////////////////////////////


        ////////////////////////////////////deal module start///////////////////////////////////////////////////

        // Deal Stage
        $scope.selDealStages = {
            activeDealStage: "",
            tempDealStage: "",
            dealItemClicked: "",
            previousDealStageID: "",
            previousDealStageName: ""
        };

        var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.dealStages = utility.getMultLangMasData(MASTER_TABLE.DelSubStg);
        $scope.currencies = utility.getMultLangMasData(MASTER_TABLE.Curcy);
        $scope.user = {};

        function syncDealServerRecords(serverResponse) {

            angular.forEach(serverResponse.Deals, function (responseObj) {
                var existedRecord = $filter('filter')($scope.dealList, { DeviceObjID: responseObj.DeviceObjID });
                //if(existedRecord == null || existedRecord == ""){
                if (existedRecord.length == 0) {
                    var createNewDealObjModel = dealService.dealMod().uiObject;
                    $scope.dealList.push(createNewDealObjModel);

                    var dealStageModelID = utility.dealStageModelIDCheck(responseObj.DealStageID);
                    createNewDealObjModel.Priority = utility.getColorCodeForDeals(responseObj.ExpectedDealCloseDate, dealStageModelID);
                    if (createNewDealObjModel.Priority == 1) {
                        $scope.overDueCount++;
                    }
                    utility.syncModelWithoutInnerCollection(responseObj, createNewDealObjModel);
                    createNewDealObjModel.ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate(createNewDealObjModel.ExpectedDealCloseDate).toString();
                    createNewDealObjModel.OwnerNameToDisplay = utility.getNameByOrOwner(createNewDealObjModel);
                    createNewDealObjModel.DealStageModelIDToCheck = dealStageModelID;
                    createNewDealObjModel.DealStageName = utility.dealStageName(createNewDealObjModel.DealStageID);
                    responseObj.DealStageName = utility.dealStageName(createNewDealObjModel.DealStageID);
                    if (createNewDealObjModel.ContactTypeID == 1) {
                        createNewDealObjModel.ContactDisplayName = responseObj.ContactName;
                        responseObj.ContactDisplayName = responseObj.ContactName;
                        //tarLst.ContactName = tarLst.contactName;
                        if (typeof responseObj.EmployerName != 'undefined' || responseObj.EmployerName != null) {
                            createNewDealObjModel.CompanyName = responseObj.EmployerName;
                            responseObj.CompanyName = responseObj.EmployerName;
                        }
                        else {
                            createNewDealObjModel.CompanyName = '';
                            responseObj.CompanyName = '';
                        }
                    }
                    else {
                        createNewDealObjModel.CompanyName = responseObj.ContactName;
                        responseObj.CompanyName = responseObj.ContactName;
                        if (typeof responseObj.RepresentativeName != 'undefined' || responseObj.RepresentativeName != null) {
                            createNewDealObjModel.ContactDisplayName = responseObj.RepresentativeName;
                            responseObj.ContactDisplayName = responseObj.RepresentativeName;
                            createNewDealObjModel.RepresentativeName = responseObj.RepresentativeName;
                        }
                        else {
                            createNewDealObjModel.ContactDisplayName = '';
                            responseObj.ContactDisplayName = '';
                        }
                    }
                    // add the obj in model and SQLight DB
                    dealService.addDealToSql(responseObj).then(function (result) {
                    }, function (error) { });

                } else {
                    // update the obj in model and SQLight DB

                    // Assign the sub child model for Deal Document Mapping
                    if (responseObj.DealDocumentMapping.length > 0) {
                        existedRecord[0].DealDocumentMapping = responseObj.DealDocumentMapping;
                    } else {
                        existedRecord[0].DealDocumentMapping = [];
                        //contactService.bindCorrespondencesEmptyModel(existedRecord);
                    }
                    // Assign the sub child model for Notes
                    if (responseObj.Notes.length > 0) {
                        existedRecord[0].Notes = responseObj.Notes;
                    } else {
                        existedRecord[0].Notes = [];
                    }
                    // Assign the sub child model for Deal Attendees
                    if (responseObj.DealAttendees.length > 0) {
                        existedRecord[0].DealAttendees = responseObj.DealAttendees;
                    } else {
                        existedRecord[0].DealAttendees = [];
                    }
                    // Assign the sub child model for Activity Deal Mappings
                    if (responseObj.ActivityDealMappings.length > 0) {
                        // utility.syncModelWithoutInnerCollection(resFieldsObj,existedRecord[index]);
                        existedRecord[0].ActivityDealMappings = responseObj.ActivityDealMappings;
                    } else {
                        existedRecord[0].ActivityDealMappings = [];
                    }
                    // Assign the sub child model for Attachments
                    if (responseObj.Attachments.length > 0) {
                        existedRecord[0].Attachments = responseObj.Attachments;
                    } else {
                        existedRecord[0].Attachments = [];
                    }

                    // Assign the sub child model for Attachments
                    if (responseObj.Fields.length > 0) {
                        if (existedRecord[0].Fields.length > 0) {
                            angular.forEach(responseObj.Fields, function (resFieldsObj, index) {
                                var existedField = $filter('filter')(existedRecord.Fields, { FieldName: responseObj.FieldName });
                                if (existedField != null || existedField != "") {
                                    utility.syncModelWithCollection(resFieldsObj, existedField);
                                }
                            });
                        }
                    } else {
                        existedRecord[0].Fields = [];
                        //contactService.bindFieldsEmptyModel(existedRecord);
                    }
                    dealService.updateDealToSql(existedRecord[0]).then(function (result) {
                    }, function (error) { });
                }
            });
        }
        $ionicModal.fromTemplateUrl('app/views/deal/dealStages.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStages = modal;
        });

        $scope.openDealStagesList = function (val, dealsId) {
            $scope.modelSelected = val;
            $scope.selDealStages.dealItemClicked = "";
            for (var i = 0; i < $scope.dealList.length; i++) {
                if ($scope.dealList[i].DeviceObjID == dealsId) {
                    var dealStageModelID = utility.dealStageModelIDCheck($scope.dealList[i].DealStageID);
                    if (!(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close || dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost)) {
                        $scope.selDealStages.activeDealStage = $scope.dealList[i].DealStageID;
                        $scope.selDealStages.dealItemClicked = i;
                        $scope.selDealStages.previousDealStageID = $scope.dealList[i].DealStageID;
                        $scope.selDealStages.previousDealStageName = $scope.dealList[i].DealStageName;
                        $scope.modalDealStages.show();
                    }
                }
            }
        };
        $scope.closeDealStagesList = function () {
            $scope.selDealStages.dealItemClicked = "";
            $scope.modalDealStages.hide();
        };

        $scope.actionDealStagesList = function () {
            var dealStageModelID = utility.dealStageModelIDCheck($scope.selDealStages.activeDealStage);
            if (!(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close || dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost)) {
                $scope.selDealStages.tempDealStage = $scope.selDealStages.activeDealStage;
                for (var i = 0; i < $scope.dealStages.length; i++) {
                    if ($scope.selDealStages.activeDealStage == $scope.dealStages[i].DealStageID) {
                        $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.dealStages[i].DealStageID;
                        $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.dealStages[i].Name;
                        $scope.dealCloseModel = dealService.dealCloseLostMod().uiObject;
                        $scope.dealCloseModel.DeviceObjID = $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID;
                        $scope.dealCloseModel.DealID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealID;
                        $scope.dealCloseModel.DealStageID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID;
                        $scope.dealCloseModel.DealStageName = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName;
                        $scope.dealCloseModel.ModifiedBy = lgnUser.UserID;
                        var dateStringInUTC = utility.getDateStringInUTC(new Date());
                        $scope.dealCloseModel.ModifiedOn = dateStringInUTC;

                        dealService.sqlDealStageUpdate($scope.dealList[$scope.selDealStages.dealItemClicked]).then(function () {

                            dealService.dealCloseLost($scope.dealCloseModel).then(function (res) {
                                //console.log("Deal Stage Update Result is"+JSON.stringify(res));
                            }, function (err) {
                                alert(err);
                            });
                        }, function (err) {
                            alert(err);
                        });
                        //console.log('Deal Stage ID is'+$scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID);
                        //console.log('Deal Stage Model ID is'+$scope.dealStages[i].DealStageModelID);
                    }
                }
                $scope.modalDealStages.hide();
            } else {
                for (var i = 0; i < $scope.dealStages.length; i++) {
                    if ($scope.selDealStages.activeDealStage == $scope.dealStages[i].DealStageID) {
                        $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.dealStages[i].DealStageID;
                        $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.dealStages[i].Name;
                        //console.log('Deal Stage ID is'+$scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID);
                        //console.log('Deal Stage Model ID is'+$scope.dealStages[i].DealStageModelID);
                    }
                }
                if (dealStageModelID == GENERAL_CONFIG.DealStageModel.Close) {
                    $scope.openDealStagesClose('DSC');
                    $scope.modalDealStages.hide();

                } else if (dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost) {
                    $scope.openDealStagesLost('DSL');
                    $scope.modalDealStages.hide();
                }
            }
        };

        /////////////////////////////////////////////////////////// Modal for Deal Stages Close /////////////////////////////////////////////////////////////

        $ionicModal.fromTemplateUrl('app/views/deal/dealStagesClose.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesClose = modal;
        });

        $scope.openDealStagesClose = function (val) {
            $scope.modelSelected = val;
            for (var i = 0; i < $scope.currencies.length; i++) {
                if ($scope.currencies[i].CurrencyID == $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealSizeCurrencyID) {
                    $scope.user.dealSizeCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.actualDealSize = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealSize;
            $scope.user.actualDealSizeConverted = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealSizeConverted;

            for (var i = 0; i < $scope.currencies.length; i++) {
                if ($scope.currencies[i].CurrencyID == $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealRevenueCurrencyID) {
                    $scope.user.dealRevenueCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.actualDealRevenue = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealRevenue;
            $scope.user.actualDealRevenueConverted = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealRevenueConverted;
            $scope.modalDealStagesClose.show();
        };
        $scope.closeDealStagesClose = function () {
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.selDealStages.previousDealStageID;
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.selDealStages.previousDealStageName;
            $scope.modalDealStagesClose.hide();
        };

        $scope.actionDealStagesClose = function () {
            $scope.dealCloseModel = dealService.dealCloseLostMod().uiObject;
            $scope.dealCloseModel.DeviceObjID = $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID;
            $scope.dealCloseModel.DealID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealID;
            $scope.dealCloseModel.ActualDealCloseDate = utility.getDateInServerFormatFromToday(new Date()).toString();
            $scope.dealCloseModel.ActualDealRevenue = $scope.user.actualDealRevenue;
            $scope.dealCloseModel.ActualDealRevenueConverted = $scope.user.actualDealRevenueConverted;
            $scope.dealCloseModel.ActualDealRevenueCurrencyConvRate = $scope.user.dealRevenueCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealRevenueCurrencyID = $scope.user.dealRevenueCurrencyObject.CurrencyID;
            $scope.dealCloseModel.ActualDealSize = $scope.user.actualDealSize;
            $scope.dealCloseModel.ActualDealSizeConverted = $scope.user.actualDealSizeConverted;
            $scope.dealCloseModel.ActualDealSizeCurrencyConvRate = $scope.user.dealSizeCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealSizeCurrencyID = $scope.user.dealSizeCurrencyObject.CurrencyID;
            $scope.dealCloseModel.DealStageID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID;
            $scope.dealCloseModel.DealStageName = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName;
            $scope.dealCloseModel.ModifiedBy = lgnUser.UserID;
            var dateStringInUTC = utility.getDateStringInUTC(new Date());
            $scope.dealCloseModel.ModifiedOn = dateStringInUTC;
            $scope.dealStageModelID = utility.dealStageModelIDCheck($scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID);
            $scope.dealList[$scope.selDealStages.dealItemClicked].ActualDealSizeConverted = $scope.user.actualDealSizeConverted;
            $scope.dealList[$scope.selDealStages.dealItemClicked].ActualDealRevenueConverted = $scope.user.actualDealRevenueConverted;
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageModelIDToCheck = $scope.dealStageModelID;


            dealService.dealCloseToSql($scope.dealCloseModel).then(function (result) {
                dealService.dealCloseLost($scope.dealCloseModel).then(function (res) {
                    //console.log("Deal Close Result is"+JSON.stringify(res));
                }, function (err) {
                    alert(err);
                });

            }, function (err) {
                alert(err);
            });


            $scope.modalDealStagesClose.hide();
        };

        /////////////////////////////////////////////////////////// Expected Deal Size Conversion ///////////////////////////////////////////////////////

        $scope.actualDealSizeConversion = function () {
            $scope.user.actualDealSizeConverted = ($scope.user.actualDealSize * $scope.user.dealSizeCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Expected Deal Revenue Conversion ///////////////////////////////////////////////////////

        $scope.actualDealRevenueConversion = function () {
            $scope.user.actualDealRevenueConverted = ($scope.user.actualDealRevenue * $scope.user.dealRevenueCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $scope.removeZero = function () {
            if ($scope.user.actualDealSize == 0)
                $scope.user.actualDealSize = '';
            if ($scope.user.actualDealRevenue == 0)
                $scope.user.actualDealRevenue = '';
        }

        /////////////////////////////////////////////////////////// Modal for Deal Stages Lost /////////////////////////////////////////////////////////////

        $ionicModal.fromTemplateUrl('app/views/deal/dealStagesLost.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesLost = modal;
        });

        $scope.openDealStagesLost = function (val) {
            $scope.modelSelected = val;
            $scope.modalDealStagesLost.show();
        };
        $scope.closeDealStagesLost = function () {
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.selDealStages.previousDealStageID;
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.selDealStages.previousDealStageName;
            $scope.modalDealStagesLost.hide();
        };

        $scope.actionDealStagesLost = function () {
            $scope.dealLostModel = dealService.dealCloseLostMod().uiObject;
            $scope.dealLostModel.DeviceObjID = $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID;
            $scope.dealLostModel.DealID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealID;
            $scope.dealLostModel.DealStageID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID;
            $scope.dealLostModel.DealStageName = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName;
            $scope.dealLostModel.ModifiedBy = lgnUser.UserID;
            var dateStringInUTC = utility.getDateStringInUTC(new Date());
            $scope.dealLostModel.ModifiedOn = dateStringInUTC;
            if ($scope.user.notes != '') {
                $scope.dealLostModel.Note = {
                    DeviceObjID: utility.generateUUID(),
                    EntityID: $scope.dealList[$scope.selDealStages.dealItemClicked].DealID,
                    ModuleID: GENERAL_CONFIG.MODULES.Deal,
                    NoteID: 0,
                    ParentDeviceObjID: $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID,
                    Description: $scope.user.notes,
                    CreatorID: lgnUser.UserID,
                    CreatorName: lgnUser.UserName,
                    CreatedOn: utility.getDateStringInUTC(new Date()),
                    CreatedAt: $scope.dealList[$scope.selDealStages.dealItemClicked].CreatedAt,
                    ModifiedBy: null,
                    ModifiedOn: utility.getDateStringInUTC(new Date()),
                    ModifiedAt: $scope.dealList[$scope.selDealStages.dealItemClicked].ModifiedAt
                };

                dealService.dealLostToSql($scope.dealLostModel).then(function (result) {
                    dealService.dealCloseLost($scope.dealLostModel).then(function (res) {
                        //console.log("Deal Lost Result is"+JSON.stringify(res));
                        dealService.dealLostUpdateNotesToSql(res).then(function (result) {

                        }, function (err) {
                            alert(err);
                        });
                    }, function (err) {
                        alert(err);
                    });
                }, function (err) {
                    alert(err);
                });

                $scope.modalDealStagesLost.hide();

                //console.log('Notes String'+JSON.stringify($scope.dealModel.Notes));
            }

        }

        $scope.dealsdetail = function (dealsId, itemClickedIndex) {
            //console.log('item clicked is'+itemClickedIndex);
            for (var i = 0; i < $scope.dealList.length; i++) {
                if ($scope.dealList[i].DeviceObjID == dealsId) {
                    dealService.setSelectedDeal($scope.dealList[i]);
                    $state.go('tab.dealDetail', { dealsId: dealsId });
                }
            }
        }


        ////////////////////////////////////deal module END///////////////////////////////////////////////////
    };

})();
