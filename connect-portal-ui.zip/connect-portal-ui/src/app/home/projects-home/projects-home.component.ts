import { Component, ViewChild } from '@angular/core';
import { ProgressIndicatorStateService } from '@shared/components/progress-indicator/progress-indicator-state.service';
import { ProjectSidebarComponent } from 'src/app/projects/project-sidebar/project-sidebar.component';

@Component({
  selector: 'p-connect-projects-home',
  templateUrl: './projects-home.component.html'
})
export class ProjectsHomeComponent {
  @ViewChild(ProjectSidebarComponent) projectSidebarComponent: ProjectSidebarComponent;

  constructor(private readonly progressIndicatorStateService: ProgressIndicatorStateService) {}

  projectSavedEvent() {
    this.progressIndicatorStateService.setIsValid(2, true);
  }

  openProjectSidebar(): void {
    this.projectSidebarComponent.open(null);
  }
}
