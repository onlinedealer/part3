import { Component, OnDestroy, HostListener } from "@angular/core";
import { Subscription } from "rxjs";
import { MeteringpointsSearchfieldMenuRef } from "./menu.ref";
import { menuAnimations, MenuAnimationState } from "./menu-animation";
import { AnimationEvent } from "@angular/animations";
import { ESCAPE } from "@angular/cdk/keycodes";

export class MeteringpointsSearchfieldMenuData {
    searchField?: string;
}

@Component({
    templateUrl: "./menu.component.html",
    styleUrls: ["./menu.component.scss"],
    animations: [menuAnimations.fadeMenu]
})
export class MeteringpointsSearchfieldMenuComponent implements OnDestroy {
    animationState: MenuAnimationState = "default";
    backdropClickSubscription!: Subscription;

    @HostListener("document:keydown", ["$event"]) private handleKeydown(event: KeyboardEvent) {
        if (event.keyCode === ESCAPE) {
            this.close();
        }
    }

    constructor(
        readonly data: MeteringpointsSearchfieldMenuData,
        readonly meteringpointsSearchfieldMenuRef: MeteringpointsSearchfieldMenuRef
    ) {
        this.backdropClickSubscription = meteringpointsSearchfieldMenuRef.backdropClick$.subscribe(() => this.close());
    }

    onDefaultSearchTargetClick() {
        if (this.data.searchField) {
            this.meteringpointsSearchfieldMenuRef.setDefaultSearchFieldSelected(this.data.searchField);
        }
        this.animationState = "closing";
    }

    close() {
        this.animationState = "closing";
    }

    onFadeFinished(event: AnimationEvent) {
        const { toState } = event;
        const isFadeOut = (toState as MenuAnimationState) === "closing";
        const itFinished = this.animationState === "closing";

        if (isFadeOut && itFinished) {
            this.meteringpointsSearchfieldMenuRef.close();
        }
    }

    ngOnDestroy() {
        if (this.backdropClickSubscription) {
            this.backdropClickSubscription.unsubscribe();
        }
    }
}
