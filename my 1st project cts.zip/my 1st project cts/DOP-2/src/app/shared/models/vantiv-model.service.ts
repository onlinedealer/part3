import { Injectable } from '@angular/core';

@Injectable()
export class VantivModelService {

  public VANTIV_MODEL = {
    'VANTIV_ERRORS' : {
        '871': 'Invalid Card Number please check and retry',
        '872': 'Invalid Card Number please check the number of digits and retry',
        '873': 'Invalid Card Number please check the number of digits and retry',
        '874': 'Invalid Card Number please check and retry',
        '875': 'We are experiencing technical difficulties. Please try again later or call 1-888-607-4CVS (1-888-607-4287)',
        '876': 'Invalid Card Number please check and retry',
        '881': 'Invalid CVV (card validation code) please check and retry',
        '882': 'Invalid CVV (card validation code) please check and retry',
        '883': 'Invalid CVV (card validation code) please check and retry',
        '889': 'We are experiencing technical difficulties. Please try again later or call 1-888-607-4CVS (1-888-607-4287)',
        'INVALID_CARD_DETAILS': 'Invalid card details. Check and retry.',
        'TIME_OUT': 'We are experiencing technical difficulties. Please try again later or call 1-888-607-4CVS (1-888-607-4287)',
        'TECHNICAL_DIFFICULTIES': 'We are experiencing technical difficulties. Please try again or call us to complete your order'
    },
    'VANTIV_CONFIGURATION' : {
      'style': 'FIPS3', //--> create new stylesheets
      'height': '220px', //-->
      'reportGroup': 'ABCDEFGH', //--> This is constant value. For now give any Hardcoded value
      'timeout': 15000,
      'div': 'eProtectCard',
      'showCvv': true,
      'months': {
        '1': 'January',
        '2': 'February',
        '3': 'March',
        '4': 'April',
        '5': 'May',
        '6': 'June',
        '7': 'July',
        '8': 'August',
        '9': 'September',
        '10': 'October',
        '11': 'November',
        '12': 'December'
      },
      'numYears': 8,
      'tooltipText': 'A CVV is the 3 digit code on the back of your Visa, MasterCard and Discover or a 4 digit code on the front of your American Express',
      'tabIndex': {'accountNumber': 1,'expMonth': 2,'expYear': 3, 'cvv': 4},
      'placeholderText': {
        'cvv': 'CVV',
        'accountNumber':'Credit Card Number'
      },
      'enhancedUxFeatures' : {
      'inlineFieldValidations': true,
      }
    }
  }

  constructor() { }

}
