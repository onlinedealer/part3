import { Spies } from 'discovery-test';
import { ProfileResultsTabComponent } from './profile-results-tab.component';
import { TreePath } from '../tree-path.model';
import { TreeTableModel } from '../tree-table.model';
import { ProfileResultsTableModel } from '../profile-results-table.model';

describe('ProfileResultsTabComponent', () => {
  let component: ProfileResultsTabComponent;

  beforeEach(() => {
    Spies.init();
    component = new ProfileResultsTabComponent(Spies.TranslateService, Spies.HttpUtilService);
    component.treePath = new TreePath();
    component.treePath.treeData = new TreeTableModel();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should check on table view', () => {
    const statistics = [
      {
        type: 'CompletenessStatistics',
        group: 'TABLE_ANALYSIS',
        completeCount: 5000000,
        nullCount: 0,
        blankCount: 0
      }
    ];
    component.treePath.tableView = true;
    component.treePath.modelView = false;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 5000000;
    component.treePath.treeData.data.statistics = statistics;
    component.ngOnInit();
    expect(component.donutCharts.length).toEqual(1);
    expect(component.getDonutChartWidth()).toEqual(12);
    expect(component.failureMessages.length).toEqual(0);
  });

  it('should check on column view', () => {
    const statistics = [
      {
        type: 'CompletenessStatistics',
        completeCount: 5000000,
        nullCount: 0,
        blankCount: 0
      },
      {
        type: 'UniquenessStatistics',
        uniqueCount: 0,
        distinctCount: 18889
      },
      {
        type: 'FrequencyStatistics',
        frequency: {
          '2004-04-18': 332
        }
      },
      {
        type: 'MinMaxValueStatistics',
        group: 'DATE_ANALYSIS',
        min: '1970-01-01',
        max: '2021-09-18'
      },
      {
        type: 'HistogramStatistics',
        frequency: {
          '1970-01-01-1975-03-04': 501108,
          '1975-03-05-1980-05-05': 499395
        }
      },
      {
        type: 'StringLengthStatistics',
        maxLength: 200,
        minLength: 0
      },
      {
        type: 'NumericalStatistics',
        group: 'NUMERICAL_ANALYSIS',
        avg: 4996.392831,
        stddev: 2883,
        variance: 8316588
      },
      {
        type: 'TextPatternStatistics',
        groups: [
          {
            groupPattern: 'Aa{1,9}',
            groupRegex: '[A-Z][a-z]{1,9}',
            patterns: {
              Aaaa: {
                '[A-Z][a-z]{3}': 112
              }
            }
          }
        ]
      },
      {
        type: 'ScriptDistributionStatistics',
        frequency: {
          Han: 10,
          Latin: 9,
          Common: 5
        }
      },
      {
        type: 'PercentileStatistics',
        percentiles: {
          '1.0': 100.37908567880628,
          '5.0': 501.83858315267554,
          '25.0': 2501.478044638815,
          '50.0': 4998.396343539876
        }
      },
      {
        type: 'CharacterSpacingStatistics',
        group: 'CHARACTER_ANALYSIS',
        frequency: { 'Multiple Spaces': 1, 'Single Space': 1 }
      }
    ];
    component.treePath.columnView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 5000000;
    component.treePath.treeData.data.statistics = statistics;
    component.ngOnInit();
    expect(component.donutCharts.length).toBe(1);
    expect(component.stackedDonutCharts.length).toBe(1);
    expect(component.tableChart.length).toBe(2);
    expect(component.numericalAnalysisStat.length).toBe(2);
    expect(component.histogramChart.length).toBe(1);
    expect(component.getDonutChartWidth()).toEqual(4);
    expect(component.failureMessages.length).toEqual(0);
    expect(component.charAnalysisGroupChart.length).toBe(1);
  });
});
