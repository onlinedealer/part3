import { ProfileResultsModel } from './profile-results.model';
import { Spies } from 'discovery-test';

import { ProfileResultsService } from './profile-results.service';
import { of } from 'rxjs';
import { TreePath } from './tree-path.model';
import { TreeTableModel } from './tree-table.model';
import { ProfileResultsTableModel } from './profile-results-table.model';
import { Component } from '@angular/core';

describe('ProfileResultsService', () => {
  let service: ProfileResultsService;

  beforeEach(() => {
    Spies.init();
    service = new ProfileResultsService(
      Spies.HttpClient,
      Spies.AuthenticationService,
      Spies.TranslateService,
      Spies.HttpUtilService
    );
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getProfileStatsById be called', () => {
    service.getProfileStatsById('8a8a82eb7b4e5d45017b4ea633ca0001', '3820r20urkdk').subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should return headers and data on getTableSummary', () => {
    const treePath = new TreePath();
    treePath.treeData = new TreeTableModel();
    treePath.treeData.data = new ProfileResultsTableModel();

    treePath.treeData.data.columns = [
      {
        name: 'CC',
        type: 'STRING',
        status: 'SUCCESS',
        statistics: [
          {
            type: 'CompletenessStatistics',
            completeCount: 3060013,
            nullCount: 0,
            blankCount: 0
          },
          {
            type: 'UniquenessStatistics',
            uniqueCount: 7,
            distinctCount: 500011
          },
          {
            type: 'StringLengthFrequencyStatistics',
            frequency: {
              2: 6
            }
          },
          {
            type: 'DetectedSemanticTypeStatistics',
            group: 'STRING_ANALYSIS',
            semanticType: 'CREDITCARD'
          },
          {
            type: 'StringLengthStatistics',
            maxLength: 19,
            minLength: 2
          },
          {
            type: 'FrequencyStatistics',
            frequency: {
              501823395527: 21
            }
          },
          {
            type: 'CreditCardSemanticStatistics',
            group: 'SEMANTIC_ANALYSIS',
            semanticType: 'CREDITCARD',
            validity: {
              type: 'ValidityStatistics',
              validCount: 2550723,
              invalidCount: 509290
            },
            cardTypeFrequency: {
              type: 'FrequencyStatistics',
              frequency: {
                VISA: 766839
              }
            }
          }
        ]
      }
    ];
    treePath.treeData.data.columns[0]['status'] = 'SUCCESS';
    service.getTableSummary(treePath);
    expect(service.summaryData[0].column).toBe(treePath.treeData.data.columns[0].name);
    expect(service.summaryHeaders[0].field).toBe('column');
    expect(service.summaryData[0].semanticType).toBe('CREDITCARD');
  });

  it('should check getTableStats called', () => {
    const profileMetadata = {
      host: 'host',
      source: 'source',
      sourceType: 'sourceType',
      db: 'db',
      schema: 'schema'
    };
    service.getTableStats('id', profileMetadata, 'tableName').subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should check getColumnStats called', () => {
    const profileMetadata = {
      host: 'host',
      source: 'source',
      sourceType: 'sourceType',
      db: 'db',
      schema: 'schema'
    };
    service.getColumnStats('id', profileMetadata, 'tableName', 'columnName').subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });
});
