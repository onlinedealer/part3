import { Injectable } from '@angular/core';
import { TargetConnection } from './target-connection';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TargetConnectionsService implements TargetConnection {
  constructor() {}

  public get(): Observable<any> {
    return of([
      {
        name: 'KAFKA'
      }
    ]);
  }
}
