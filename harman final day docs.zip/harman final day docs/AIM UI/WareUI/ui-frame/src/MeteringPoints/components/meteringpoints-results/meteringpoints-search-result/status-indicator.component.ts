import { Component, Input, Output, EventEmitter } from "@angular/core";
import { trigger, state, style, transition, animate } from "@angular/animations";

@Component({
    selector: "landisgyr-meteringpoint-status-indicator1",
    templateUrl: "./status-indicator.component.html",
    styleUrls: ["./status-indicator.component.scss"],
    animations: [
        trigger("expand", [
            state(
                "visible",
                style({
                    width: "4px"
                })
            ),
            state(
                "hidden",
                style({
                    width: "0px"
                })
            ),
            transition("visible => hidden", [animate("0.2s")]),
            transition("hidden => visible", [animate("0.2s")])
        ])
    ]
})
export class StatusIndicatorComponent {
    @Input() checkedMeteringPointIds!: number[];
    @Input() id!: number;
    @Input() statusIndicator!: string;
    @Input() checkbox!: boolean;
    @Output() checkboxCheck: EventEmitter<number> = new EventEmitter();
    selectCheckbox() {
        this.checkboxCheck.emit(this.id);
    }
}
