import { OkComponent } from './ok.component';

describe('OkComponent', () => {
  let component: OkComponent;

  beforeEach(() => {
    component = new OkComponent({} as any);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
