import React from 'react'
import { shallow } from 'enzyme'
import { DrawerComponent } from '../DrawerComponent'

describe('Drawer component ', () => {
  // let handleDrawerClose = sinon.spy()
  let wrapper
  // beforeEach(() => {
  //   wrapper = shallow(<DrawerComponent />)
  // })

  const props = {
    theme: {
      direction: 'rtl',
    },
    classes: {},
  }
  const props1 = {
    theme: {
      direction: 'ltl',
    },
    classes: {},
  }

  it('renders with props', () => {
    wrapper = shallow(
      <DrawerComponent {...props} />
    )
    expect(wrapper).toHaveLength(1)
  })

  it('Trigger Drawer Open', () => {
    wrapper = shallow(
      <DrawerComponent {...props1} />
    )
    wrapper.instance().handleDrawerOpen()
    expect(wrapper.instance().state.open).toEqual(true)
  })

  it('Trigger Drawer Close', () => {
    wrapper = shallow(
      <DrawerComponent {...props1} />
    )
    wrapper.instance().handleDrawerClose()
    expect(wrapper.instance().state.open).toEqual(false)
  })
})
