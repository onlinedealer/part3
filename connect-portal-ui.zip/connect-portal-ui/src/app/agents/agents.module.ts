import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgentsRoutingModule } from './agents-routing.module';
import { AgentsComponent } from './agents.component';
import { SharedModule } from '../shared/shared.module';
import { AgentsApiService } from './shared/agents-api.service';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { TooltipModule } from 'primeng/tooltip';
import { AgentSidebarComponent } from './agent-sidebar/agent-sidebar.component';
import { AgentFormComponent } from './agent-sidebar/agent-form/agent-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { commonLoader, agentsLoader, pngLoader } from '../i18n-loaders';

@NgModule({
  declarations: [AgentsComponent, AgentSidebarComponent, AgentFormComponent],
  providers: [
    AgentsApiService,
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'agents', loader: agentsLoader },
        { scope: 'png', loader: pngLoader }
      ]
    }
  ],
  imports: [CommonModule, SharedModule, AgentsRoutingModule, TranslocoModule, TooltipModule, FormsModule, ReactiveFormsModule]
})
export class AgentsModule {}
