import { StsConfigHttpLoader } from 'angular-auth-oidc-client';
import { of } from 'rxjs';
import { httpLoaderFactory } from './auth-config.module';

describe('AuthConfigModule', () => {
  let oidcConfigService: any;
  let http: any;

  beforeEach(() => {
    oidcConfigService = jasmine.createSpyObj('OidcConfigService', ['withConfig']);

    http = jasmine.createSpyObj('HttpClient', ['get']);
    http.get.and.returnValue(of({ clientId: 'foo', stsServer: 'bar' }));
  });

  it('can load oidc config', () => {
    const configLoader: StsConfigHttpLoader = httpLoaderFactory(http);
    expect(configLoader).toBeDefined();
  });
});
