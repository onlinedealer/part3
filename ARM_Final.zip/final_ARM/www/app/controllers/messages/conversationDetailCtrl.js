(function () {
    'use strict';

    angular.module('arm').controller('conversationDetailCtrl',
                ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate','messageService', 'utility', 'MASTER_TABLE', conversationDetailCtrl]);

    function conversationDetailCtrl($scope, $state, $ionicModal, $ionicSideMenuDelegate,messageService, utility, MASTER_TABLE) 
    {
    	$scope.txtFld = '';
        $scope.loggedInUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);

		var conversation = messageService.getSelectedConversation();
		var message = messageService.models().MessageModel;
		message.InternalMessageID = 1;
		message.ConversationDeviceObjID = conversation.DeviceObjID;
		message.SendByID = 10;
		message.SendByName = 'Akshay';
		message.SendToID = $scope.loggedInUser.UserID;
		message.SendToName = $scope.loggedInUser.UserName;
		message.IsGroup = false;
		message.Description = 'Hello ' + $scope.loggedInUser.UserName;
		
		var message2 = messageService.models().MessageModel;
		message2.InternalMessageID = 2;
		message2.ConversationDeviceObjID = conversation.DeviceObjID;
		message2.SendByID = $scope.loggedInUser.UserID;
		message2.SendByName = $scope.loggedInUser.UserName;
		message2.SendToID = 10;
		message2.SendToName = 'Akshay';
		message.IsGroup = false;
		message2.Description = 'Hello Akshay';

		$scope.messages = [message,message2];
		conversation.Messages = $scope.messages;

		//$scope.messages = conversation.Messages;
		$scope.cancel = function()
		{
			conversation = null;
			$state.go('tab.conversationList', {
            });
		}

		$scope.sendMsg = function()
		{
			var description = utility.removeWhitespace($scope.txtFld);
			if (description.length) {
				utility.busyCursorStart();
				var msgModel = createMsgModel(description);

			}
			$scope.txtFld = '';
		}

		function createMsgModel(description)
		{
			var message = messageService.models().MessageModel;
			message.InternalMessageID = 0;
			message.ConversationDeviceObjID = conversation.DeviceObjID;
			message.SendByID = $scope.loggedInUser.UserID;
			message.SendByName = $scope.loggedInUser.UserName;
			message.SendToID = 0;
			message.SendToName = '';
			message.IsGroup = false;
			message.Description = description;
			return message;
		}		   
	};
})();



