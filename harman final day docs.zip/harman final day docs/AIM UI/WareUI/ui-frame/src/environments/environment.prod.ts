export const environment = {
    production: true,
    fresh_data_expiration_time: 60000,
    uam_timeout_in_seconds_to_show_session_expiring_dialog: 3600,
    uam_timeout_in_seconds_after_dialog_is_shown_before_session_expiration: 60,
    uam_token_refresh_interval_in_minutes: 60,
    uam_userinfo_refresh_interval_in_minutes: 120,
    backend_api_prefix: "../../AIMWare/rs",
    application_url: "../../AIMUI",
    change_pass_word_url: "../changePassword",
    security_base_url: ""
};
