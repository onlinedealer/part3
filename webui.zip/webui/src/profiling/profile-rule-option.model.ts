export class ProfileRuleOptionModel {
  id: string;
  displayName: string;
  optionType: string;
  description: string;
  defaultOptionValue: string;
  labelValueOptionItems?: [] = [];
  configuredOptionValue: any;
}
