(function() {
    'use strict';

    fileuploader.controller("viewTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$location', '$route', '$window', '$http', viewTemplateCtrl]);

    function viewTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, $location, $route, $http) {


        $scope.fetchpreviewData = function() {
                var rowData = $rootScope.globalTemplateD;
                var id = rowData.id;
                
                var url = "/ocr/rest/v1/service/get/tiffimage/tiff/file/" + id;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                console.log(url)
                $scope.getId = id;
                promise.then(function(data) {
                    var outputimage = data;
                    var output = "data:image/tiff;base64," + outputimage.inputdata;
                    $scope.uploadpreview = output;
                    //$rootScope.globalImgPreview = $scope.uploadpreview;
                    //console.log($scope.uploadpreview)
                });

                promise.catch(function(data) {
                    console.log('catch block executed', data);
                    return data;
                });
        };
        $scope.fetchpreviewData();

    }

})();
