import { Component, OnChanges, SimpleChanges } from "@angular/core";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import * as fromDeviceRelay from "../../../store/selectors/device-relay.selectors";
import * as MeterConnectionSelectors from "../../../store/selectors/meterconnections.selectors";
import { DeviceRelayVO } from "../../../models/view-objects/device-relay-vo.model";
import { TranslationsService } from "../../../../app/services/translations-service";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { map } from "rxjs/operators";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { SSRelaysSorter } from "./ss-relays-sorter";
import { MeteringsSelectors } from "../../../store/selectors";
import { ControlRelayTranslations } from "../../../../MeteringPoints/RelayControl/translations/control-relay.translations";
import { MatDialog } from "@angular/material/dialog";
import { SetRelayUsageActions } from "../../../store/actions";

@Component({
    selector: "landisgyr-ss-relays",
    templateUrl: "./ss-relays.component.html",
    styleUrls: ["./ss-relays.component.scss"]
})
export class SSRelaysComponent implements OnChanges {
    infoMessage = $localize`:|@@ssRelays.noRelaysMessage:No relays`;
    inactiveMeteringPointInfoMessage = $localize`:|@@ssRelays.inactiveRelaysMessage:Inactive connection: the relays cannot be edited`;

    selectedMeterSerialNumber$ = this.store
        .select(MeterConnectionSelectors.getSelectedMeterConnection)
        .pipe(
            map((meterConnection) =>
                meterConnection && meterConnection.deviceMeter ? meterConnection.deviceMeter.meterSerialNumber + "" : ""
            )
        );
    relays$: Observable<DeviceRelayVO[]> = this.store.select(fromDeviceRelay.getSelectedMeterConnectionRelayEntitiesForTable);
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    ssrelaysSorter = new SSRelaysSorter();
    sortedRelaysData$ = this.ssrelaysSorter.getSortedRelaysData(this.relays$);
    loading$: Observable<boolean> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);
    refreshDataLoading$: Observable<boolean> = this.store.select(fromDeviceRelay.getLoadingData);
    selectedMeteringConnection$: Observable<number | undefined> = this.store.select(
        MeterConnectionSelectors.getSelectedActiveDeviceMeterId
    );

    ngOnChanges(changes: SimpleChanges) {
        this.ssrelaysSorter.setDeviceRelays(this.relays$);
    }

    constructor(
        private dialog: MatDialog,
        private store: Store<MeteringPointsFeatureState>,
        public translations: TranslationsService,
        public relayTranslations: ControlRelayTranslations
    ) {}

    public reversedToText(reversed: boolean): string {
        return reversed ? $localize`:|@@ssRelays.inverted:Inverted` : $localize`:|@@ssRelays.normal:Normal`;
    }

    openSetRelayUsageDialog(relay: any) {
        const data = {
            header: "Add new relay",
            relay: relay,
            operation: "add"
        };
        this.store.dispatch(SetRelayUsageActions.OpenSetRelayUsageDialog({ data: data }));
    }

    openSetRelayUsageEditDialog(relay: any) {
        const data = {
            header: "Edit relay",
            relay: relay,
            operation: "edit"
        };
        this.store.dispatch(SetRelayUsageActions.OpenSetRelayUsageDialog({ data: data }));
    }

    openSetRelayUsageDeleteDialog(relay: any) {
        const data = {
            header: "Delete Relay",
            relay: relay,
            operation: "delete"
        };
        this.store.dispatch(SetRelayUsageActions.OpenSetRelayUsageDeleteDialog({ data: data }));
    }
}
