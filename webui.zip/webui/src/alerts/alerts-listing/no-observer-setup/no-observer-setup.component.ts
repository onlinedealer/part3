import { Component, Input } from '@angular/core';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

@Component({
  selector: 'discovery-no-observer-setup',
  templateUrl: './no-observer-setup.component.html',
  styleUrls: ['./no-observer-setup.component.scss']
})
export class NoObserverSetupComponent {
  @Input() hasObserver: boolean = false;

  constructor(public httpUtil: HttpUtilService) {}
}
