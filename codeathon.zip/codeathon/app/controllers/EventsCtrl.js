(function() {
    'use strict';

    codeathonApp.controller("EventsCtrl", ['$scope', 'Idle', 'Keepalive', '$uibModal', '$location', 'uiRouters', EventsCtrl]);

    function EventsCtrl($scope, Idle, Keepalive, $uibModal, $location, uiRouters) {
        $scope.started = false;
        $scope.events = [];
        $scope.idle = uiRouters.idleTime;
        $scope.timeout = uiRouters.idleWarningTime;

        function closeModals() {
            if ($scope.warning) {
                $scope.warning.close();
                $scope.warning = null;
            }

            if ($scope.timedout) {
                $scope.timedout.close();
                $scope.timedout = null;
            }
        }

        $scope.$on('IdleStart', function() {
            closeModals();
            $scope.warning = $uibModal.open({
                templateUrl: 'warning-dialog.html',
                windowClass: 'modal-danger'
            });
        });
        $scope.$on('IdleEnd', function() {
            closeModals();
        });
        $scope.$on('IdleWarn', function(e, countdown) {
            addEvent({
                event: 'IdleWarn',
                date: new Date(),
                countdown: countdown
            });
        });
        $scope.$on('IdleTimeout', function() {
            closeModals();
            Codeathon.utils.removeSessionItem('userId');
            $location.url(uiRouters.login);
        });
        $scope.$on('Keepalive', function() {
            addEvent({
                event: 'Keepalive',
                date: new Date()
            });
        });

        function addEvent(evt) {
            $scope.$evalAsync(function() {
                $scope.events.push(evt);
            })
        }
        $scope.reset = function() {
            Idle.watch();
        }
        $scope.$watch('idle', function(value) {
            if (value !== null) Idle.setIdle(value);
        });
        $scope.$watch('timeout', function(value) {
            if (value !== null) Idle.setTimeout(value);
        });

    }

})();
