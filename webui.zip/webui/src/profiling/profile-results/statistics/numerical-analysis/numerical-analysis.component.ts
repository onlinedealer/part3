import { Component, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { StatisticalAnalysisModel } from './statistical-analysis-model';
import { EventBusService } from 'core/eventBusService';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

@Component({
  selector: 'discovery-numerical-analysis',
  templateUrl: './numerical-analysis.component.html',
  styleUrls: ['./numerical-analysis.component.css']
})
export class NumericalAnalysisComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics = [];

  field: string[][] = [
    ['min', 'max'],
    ['stddev', 'variance', 'avg']
  ];
  label: { [key: string]: string } = {
    avg: this.translocoService.translate('discoveryProfiling.results.average'),
    min: this.translocoService.translate('discoveryProfiling.results.minimum'),
    max: this.translocoService.translate('discoveryProfiling.results.maximum'),
    stddev: this.translocoService.translate('discoveryProfiling.results.standardDeviation'),
    variance: this.translocoService.translate('discoveryProfiling.results.variance')
  };
  imageUrl: { [key: string]: string } = {
    avg: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/average.svg'),
    min: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/minimum.svg'),
    max: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/maximum.svg'),
    stddev: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/deviation.svg'),
    variance: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/variance.svg')
  };

  objNumericalAnalysis = [];

  constructor(
    private translocoService: TranslocoService,
    private eventBusService: EventBusService,
    public httpUtil: HttpUtilService
  ) {}

  ngOnInit(): void {
    this.loadData();
  }

  launchTrendsSidebar(stat: string) {
    this.eventBusService.emit('TrendsSidebarToggle', { flag: true, stat: stat });
  }

  private loadData(): void {
    if (this.treePath.columnView) {
      if (this.statistics[0]['group'] === ProfilingConstants.STATSGROUPS.NUMERICAL_ANALYSIS) {
        for (const index in this.field) {
          if (this.statistics.hasOwnProperty(index)) {
            const childs: StatisticalAnalysisModel[] = [];
            for (const key of this.field[index]) {
              const dataValue = parseFloat(this.statistics[index][key]).toFixed(2);
              const child = new StatisticalAnalysisModel();
              child.data = Number(dataValue);
              child.label = this.label[key];
              child.imageUrl = this.imageUrl[key];
              child.fieldName = key;
              childs.push(child);
            }
            this.objNumericalAnalysis.push(childs);
          }
        }
      } else if (this.statistics[0]['group'] === ProfilingConstants.STATSGROUPS.DATE_ANALYSIS) {
        for (const index in this.field) {
          if (this.statistics.hasOwnProperty(index)) {
            const childs: StatisticalAnalysisModel[] = [];
            for (const key of this.field[index]) {
              const child = new StatisticalAnalysisModel();
              child.data = this.statistics[index][key];
              child.label = this.label[key];
              child.imageUrl = this.imageUrl[key];
              child.fieldName = key;
              childs.push(child);
            }
            this.objNumericalAnalysis.push(childs);
          }
        }
      }
    }
  }
}
