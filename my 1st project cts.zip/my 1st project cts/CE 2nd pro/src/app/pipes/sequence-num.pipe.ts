import {Pipe, PipeTransform} from '@angular/core'

@Pipe ({ name:'bold' })

export class BoldPipe implements PipeTransform {
  transform (value:string) {
    if(value){
      let sequence,
      boldNum;
      sequence = value.toString().slice(0, -5);
      boldNum = value.toString().slice(-5);
      return sequence + '<strong>' + boldNum +'</strong>';
    }
    else{
      return value;
    }
  }
  
}