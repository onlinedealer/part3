import { TestBed } from '@angular/core/testing';
import { ObserverModule } from './observer.module';
import { Router, UrlTree } from '@angular/router';
import { ObserveFeatureFlagGuard } from '../shared/observer-feature-flag-guard';

describe('ObserverModule', () => {
  const mockRouter = jasmine.createSpyObj(['navigateByUrl']);
  const mockGuard = jasmine.createSpyObj(['canActivate']);

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [ObserverModule],
      providers: [
        { provide: ObserveFeatureFlagGuard, useValue: mockGuard },
        { provide: Router, useValue: mockRouter }
      ]
    });
  });

  it('initializes', () => {
    const module = TestBed.inject(ObserverModule);
    expect(module).toBeTruthy();
  });

  it('redirects if guard not passed', () => {
    mockGuard.canActivate.and.returnValue(new UrlTree());
    const module = TestBed.inject(ObserverModule);
    expect(mockRouter.navigateByUrl).toHaveBeenCalled();
  });
});
