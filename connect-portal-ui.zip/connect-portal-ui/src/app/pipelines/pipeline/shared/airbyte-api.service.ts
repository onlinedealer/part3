import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { GenericConnection } from 'dqcore-catalog/lib/connection-properties/connections-typings';
import { Observable } from 'rxjs';
import { BaseAirbyteApiService } from 'src/app/core/base-airbyte-api.serveice';

@Injectable({
  providedIn: 'root'
})
export class AirbyteApiService extends BaseAirbyteApiService {
  constructor(protected httpClient: HttpClient) {
    super(httpClient, '/');
  }

  getLogs(pipeline_id: string, run_id?: string): Observable<any> {
    let params: { pipeline_id: string; run_id?: string } = {
      pipeline_id
    };

    if (run_id) {
      params = { ...params, run_id: run_id };
    }

    return this.httpClient.get(this.serviceURL + 'logs', {
      params,
      responseType: 'arraybuffer'
    });
  }

  getConnectionDetails() {
    return this.httpClient.get(this.serviceURL + 'connections/details');
  }

  getConnectionSpec(connection: GenericConnection) {
    let params = {};

    if (!connection.isSource) {
      params = { connection_origin: 'destination' };
    }

    return this.httpClient.get(this.serviceURL + `connections/${connection.type}/spec`, {
      params
    });
  }
}
