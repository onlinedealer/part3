import { Component, ChangeDetectionStrategy, Input } from "@angular/core";
import { HeaderData } from "../../common/header-data-provider";

@Component({
    selector: "landisgyr-header-text-area",
    templateUrl: "./header-text-area.component.html",
    styleUrls: ["../../styles/component.styles.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeaderTextAreaComponent {
    @Input() headerData!: HeaderData;
}
