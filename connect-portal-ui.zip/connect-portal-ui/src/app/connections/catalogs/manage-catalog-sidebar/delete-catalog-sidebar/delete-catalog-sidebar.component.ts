import { Component, ViewChild, Input } from '@angular/core';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { first } from 'rxjs/operators';
import { CatalogApiService } from '../../shared/catalog-api.service';
import { Connection } from 'src/app/connections/shared/connection';

@Component({
  selector: 'p-connect-delete-catalog-sidebar',
  templateUrl: './delete-catalog-sidebar.component.html'
})
export class DeleteCatalogSidebarComponent {
  /**
   * Is the catalog in progress?
   */
  @Input() isInProgress: boolean = false;

  /**
   * List of schemas to be deleted
   */
  @Input() schemas = [];

  /**
   * The connection type for the selected schemas
   */
  @Input() connection: Connection;

  /**
   * The current project id, required for the get schemas and get calalogs API calls
   */
  @Input() projectId: string;

  /**
   * catalog status of connection
   */
  @Input() catalogStatus: { params: { partialNumber: number; totalNumber: number; structureType: string } };

  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  primaryButton: SidebarButton = {
    id: 'deleteCatalogDelete',
    text: 'common.BUTTONS.REMOVE'
  };

  cancelButton: SidebarButton = {
    id: 'deleteCatalogCancel',
    text: 'common.BUTTONS.CANCEL'
  };

  constructor(private readonly catalogApiService: CatalogApiService) {}

  open(): void {
    this.sidebarComponent.open();
  }
  /**
   * Click event for the primary button
   */
  onPrimaryButtonClicked(): void {
    const schemas = this.schemas.map((schema) => {
      return schema.schema;
    });
    this.sidebarComponent.isProcessingRequest = true;
    this.catalogApiService
      .deleteCatalog(schemas, this.connection, this.projectId)
      .pipe(first())
      .subscribe({
        next: () => {
          this.sidebarComponent.close();
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  /**
   * Click event for the cancel button
   */
  onCancelButtonClicked(): void {
    this.sidebarComponent.close();
  }
}
