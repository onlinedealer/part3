import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber } from "lodash";
import { OnDemandReadingRequestResult } from "../../../../models/ondemandreading.model";

export class ODREventsTableSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" }> = new BehaviorSubject({
        active: "Time",
        direction: "desc"
    } as any);

    odrEventsReadingTableObj: OnDemandReadingRequestResult[] = [];

    public setODRReadingTable(odrEventsTableObj: OnDemandReadingRequestResult[]) {
        this.odrEventsReadingTableObj = odrEventsTableObj;
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedODRReadingTable(): Observable<OnDemandReadingRequestResult[]> {
        return this.sortingSubject.asObservable().pipe(map(() => [...this.odrEventsReadingTableObj].sort(this.ODREventsReadingComparator)));
    }

    public onSortChange(event: { active: string; direction: "asc" | "desc" }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    ODREventsReadingComparator = (r1: any, r2: any): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "Time":
                return this.sortByDateStartTime(r1, r2, directionMultiplier);
            case "Description":
                return this.sortByString(r1.description.replace(/\s/g, ""), r2.description.replace(/\s/g, ""), directionMultiplier);
            default:
                return 0;
        }
    };

    sortByDateStartTime(r1: any, r2: any, directionMultiplier: number) {
        if (isNumber(r1.eventTime) && isNumber(r2.eventTime)) {
            return r1.eventTime > r2.eventTime ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(r1.eventTime) && isNil(r2.eventTime)) {
            return this.sortByString(r1.description.replace(/\s/g, ""), r2.description.replace(/\s/g, ""), 1);
        }

        if (isNil(r1.eventTime)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.eventTime)) {
            return directionMultiplier;
        }

        return 0;
    }

    sortByString(value1: string | undefined, value2: string | undefined, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }
        return directionMultiplier;
    }
}
