import React from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as userActions from '../../store/auth'
import OAuthProviderConfig from '../../config/OAuthProviderConfig'

class Logout extends React.Component {
  componentDidMount () {
    window.onbeforeunload = ''
    this.props.userActions.signOut()
    window.localStorage.removeItem('access_token')
    window.localStorage.removeItem('id_token')
    const myWindow = window.open(OAuthProviderConfig.logoutUrl, 'groupr logout', 'width=200, height=100')
    setTimeout(() => {
      myWindow.close()
      window.location.replace('/')
    }, 3000)
  }

  render () {
    return (<div>
        successfully logged out
    </div>)
  }
}

function mapStateToProps (state) {
  return {
    userInfo: state.get('auth'),
  }
}

function mapDispatchToProps (dispatch) {
  return {
    userActions: bindActionCreators(userActions, dispatch),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(Logout)
