//This component represents the common upper part for the connection forms(MSSQL, DB2LUW)

import { ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ControlContainer, FormControl, FormGroup } from '@angular/forms';
import { Server } from 'src/app/servers/shared/server';
import { BaseConnectionFormComponent } from '../../base-connection-form/base-connection-form.component';

@Component({
  selector: 'p-connect-connection-runtime-engine-form',
  templateUrl: './connection-runtime-engine-form.component.html'
})
export class ConnectionRuntimeEngineFormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy {
  constructor(private readonly controlContainer: ControlContainer, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }

  @Input() runtimeServerDropdownList = [];
  @Input() runtimeServer: { label: string; value: Server }[] = [];

  @Input() formGroup;

  @Output() addServerButtonClickedEvent: EventEmitter<any> = new EventEmitter<any>();

  ngOnInit(): void {
    this.formGroup = new FormGroup({
      formGroup: new FormControl()
    });
    this.formGroup.addControl('runtimeServer', new FormControl(''));
  }
  ngOnDestroy(): void {
    this.removeChildFormControls(this.formGroup);
  }

  addRuntimeServer(): void {
    this.addServerButtonClickedEvent.emit();
  }
}
