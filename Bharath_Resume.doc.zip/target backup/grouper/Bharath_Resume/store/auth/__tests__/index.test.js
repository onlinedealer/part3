import reducer, {
  initialState,
  signIn,
  signInSuccess,
  signOut,
  promptToSignIn,
  declineSignIn,
  formatUserInfo,
} from '../index'

describe('auth store', () => {
  const userInfo = {
    firstName: 'Luke',
    lastName: 'Skywalker',
    samaccountname: 'Z012345',
    memberof: [
      'CN=TTS-Rebel-Alliance,OU=Application,OU=Groupings,DC=corp,DC=republic,DC=com',
      'CN=APP-Rogue-5,OU=Application,OU=Groupings,DC=corp,DC=republic,DC=com',
    ],
    accessToken: 'Tydirium',
  }

  it('reducer returns the initial state', () => {
    expect(reducer(undefined, {})).toEqual(initialState)
  })

  it('signIn', () => {
    expect(reducer(undefined, signIn()).popupType).toEqual('login')
  })

  it('signInSuccess', () => {
    expect(reducer(undefined, signInSuccess(userInfo)).lanId).toEqual('Z012345')
  })

  it('signOut', () => {
    expect(reducer(undefined, signOut()).popupType).toEqual('logout')
  })

  it('promptToSignIn', () => {
    expect(reducer(undefined, promptToSignIn()).authModalIsShown).toEqual(true)
  })

  it('declineSignIn', () => {
    expect(reducer(undefined, declineSignIn())).toEqual(initialState)
  })

  it('formatUserInfo', () => {
    const info = formatUserInfo(userInfo)
    expect(info.memberOf).toEqual(['TTS-Rebel-Alliance', 'APP-Rogue-5'])
  })
})
