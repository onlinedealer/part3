/**
 * Inline loaders used to load translations via webpack import.
 * See https://ngneat.github.io/transloco/docs/lazy-load/inline-loaders/ for more info.
 */
const LANGS = ['en', 'ja'];

export const alertsLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../alerts/i18n/${lang}.json`);
  return acc;
}, {});

export const connectionsLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../connections/i18n/${lang}.json`);
  return acc;
}, {});

export const observerLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../observer/i18n/${lang}.json`);
  return acc;
}, {});

export const profilngLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../profiling/i18n/${lang}.json`);
  return acc;
}, {});

export const sharedLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../shared/i18n/${lang}.json`);
  return acc;
}, {});

export const connectLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../connection-container/i18n/${lang}.json`);
  return acc;
}, {});

export const catalogLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/catalog/${lang}.json`);
  return acc;
}, {});

export const dataCatalogLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../data-catalog-container/i18n/${lang}.json`);
  return acc;
}, {});

export const datasetViewLoader = LANGS.reduce((acc: any, lang) => {
  acc[lang] = () => import(`../dataset-view-container/i18n/${lang}.json`);
  return acc;
}, {});
