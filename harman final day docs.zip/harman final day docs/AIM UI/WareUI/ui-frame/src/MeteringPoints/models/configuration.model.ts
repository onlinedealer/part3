export interface ConfigurationsResponse {
    parameters: Parameters;
    data: Configuration[];
}

export interface Parameters {
    meterConnectionId: string;
}

export interface Configuration {
    meterConnectionId: number;
    deviceInputId: number;
    validFrom: number;
    deviceTypeConfigurationId: number;
    name: string;
    description: string;
}
