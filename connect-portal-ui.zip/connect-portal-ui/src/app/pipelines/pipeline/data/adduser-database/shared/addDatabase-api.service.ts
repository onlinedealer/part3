import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseConnectApiService } from 'src/app/core/base-connect-api.service';
import { environment } from 'src/environments/environment';
import { AddDatabase } from './addDatabase';

@Injectable({
  providedIn: 'root'
})
export class AddDatabaseApiService extends BaseConnectApiService<AddDatabase> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient);
  }

  add(addDatabase: AddDatabase) {
    return this.httpClient.post(`${environment.connectApiBaseURL}/metadata/prepareDatabases`, addDatabase);
  }
}
