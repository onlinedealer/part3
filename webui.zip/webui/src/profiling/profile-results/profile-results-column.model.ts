export class ProfileResultsColumnModel {
  name: string;
  type: string;
  statistics?: any[];
  status: string;
  errorMessage?: string;
}
