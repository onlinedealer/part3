import * as cheerio from "cheerio";
import request = require("request-promise");
import {
  BACKEND_URL_SCHEME,
  REQUEST_DEBUG,
  UAM_HOST,
  UAM_PORT,
  UAM_DEV_USER,
  UAM_DEV_PASSWORD,
  BACKEND_HOST,
  BACKEND_ROOT,
  BACKEND_SAML_URL,
} from "../constants";

request.defaults({ jar: true });
request.debug = REQUEST_DEBUG;

export class SessionService {
  static getSession(): void {
    request
      .get({
        url: `${BACKEND_URL_SCHEME}://${BACKEND_HOST}${BACKEND_ROOT}`,
        rejectUnauthorized: false,
        followAllRedirects: true,
        jar: true,
        resolveWithFullResponse: true,
      })
      .then((response) => {
        if (response.req.path.includes("AuthnEngine")) {
          console.log("OK: ", response.req.path);
        } else {
          throw new Error(
            "'Something bad happened. We are not in AuthnEngine."
          );
        }

        return request.post({
          url: `https://${UAM_HOST}:${UAM_PORT}/ui_igm/login/password_check`,
          rejectUnauthorized: false,
          followAllRedirects: true,
          jar: true,
          json: false,
          headers: {
            Connection: "keep-alive",
            Referer: `https://${UAM_HOST}:${UAM_PORT}/ui_igm/AuthnEngine`,
          },
          form: {
            j_username: UAM_DEV_USER,
            j_password: UAM_DEV_PASSWORD,
          },
          resolveWithFullResponse: true,
        });
      })
      .then((response) => {
        if (!response.req.path.includes("/ui_igm/profile/SAML2/Redirect/SSO")) {
          throw new Error("Login went to wrong place!");
        }

        const $ = cheerio.load(response.body);

        const RelayState = $("input[name='RelayState']").val();
        const SAMLResponse = $("input[name='SAMLResponse']").val();

        return request.post({
          url: BACKEND_SAML_URL,
          rejectUnauthorized: false,
          followAllRedirects: true,
          jar: true,
          json: false,
          headers: {
            Connection: "keep-alive",
          },
          form: {
            RelayState: RelayState,
            SAMLResponse: SAMLResponse,
          },
          resolveWithFullResponse: true,
        });
      })
      .then((response) => {
        if (response.request.href.includes(BACKEND_HOST)) {
          console.log(`Got session for ${BACKEND_HOST}`);
          console.log("GSS_SESSION_ID=", response.request.headers.cookie);
        } else {
          throw new Error(
            "We are not back in correct place! (" + response.request.href + ")"
          );
        }
      })
      .error((error) => {
        console.log("Got error when getting session: " + error);
      });
  }

  static refreshSession(): void {
    request
      .get({
        url: `${BACKEND_URL_SCHEME}://${BACKEND_HOST}${BACKEND_ROOT}security/getSessions`,
        rejectUnauthorized: false,
        followAllRedirects: true,
        jar: true,
        resolveWithFullResponse: true,
      })
      .then((resp) => {
        var resp = JSON.parse(resp.body);
        console.log(
          `Refreshed session for '${BACKEND_HOST}'.`,
          "Count of sessions:",
          Object.keys(resp).length
        );
      })
      .catch((err) => {
        console.log("refreshSession failed. statusCode:", err.statusCode);
      });
  }
}
