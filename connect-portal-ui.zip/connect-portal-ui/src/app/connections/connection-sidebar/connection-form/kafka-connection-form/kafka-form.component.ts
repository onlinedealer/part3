import { AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { AbstractControl, ControlContainer, FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../shared/connection';
import { ConnectionFormValidators } from '../shared/connection-form-validators';
import { BaseConnectionForm } from '../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../base-connection-form/base-connection-form.component';
import { Server } from '../../../../servers/shared/server';

/**
 * Connection parmaeters for the kafka connection
 */
export enum KAFKA_CONNECTION_PARAMETERS {
  KAFKA_PRODUCER_CONFIG_FILE_PATH = 'KAFKA_PRODUCER_CONFIG_FILE_PATH',
  KAFKA_USE_KERBEROS = 'KAFKA_USE_KERBEROS',
  KAFKA_KERBEROS_PRINCIPAL = 'KAFKA_KERBEROS_PRINCIPAL',
  KAFKA_KERBEROS_KEYTAB_LOCATION = 'KAFKA_KERBEROS_KEYTAB_LOCATION',
  KAFKA_ENABLE_BATCH = 'KAFKA_ENABLE_BATCH',
  KAFKA_BATCH_SIZE = 'KAFKA_BATCH_SIZE'
}

@Component({
  selector: 'p-connect-kafka-form',
  templateUrl: './kafka-form.component.html'
})
export class KafkaFormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy, AfterViewInit, BaseConnectionForm {
  /**
   * Selected Runtime Server
   */
  @Input() selectedRuntimeServer: Server;

  /**
   * form group
   */
  kafkaFormGroup: FormGroup;

  /**
   * Controls whether to show or hide the kerberos settings
   */
  isKerberosSectionVisible = false;

  constructor(
    private readonly controlContainer: ControlContainer,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly formBuilder: FormBuilder
  ) {
    super();
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.createForm();
    this.addFormValidators();
  }

  ngOnDestroy(): void {
    this.removeChildFormControls(this.kafkaFormGroup);
  }

  /**
   * Creates form controls for this connection type
   */
  createForm(): void {
    this.kafkaFormGroup = this.controlContainer.control as FormGroup;
    this.kafkaFormGroup.addControl('configurationFile', new FormControl(''));
    this.kafkaFormGroup.addControl('useKerberos', new FormControl(false));
    this.kafkaFormGroup.addControl('principal', new FormControl(''));
    this.kafkaFormGroup.addControl('keytabLocation', new FormControl(''));
    this.kafkaFormGroup.addControl('brokers', new FormArray([]));
    this.kafkaFormGroup.addControl('enableBatch', new FormControl(true));
    this.kafkaFormGroup.addControl('batchSize', new FormControl(1000));
    this.addBrokerItem();
  }

  /**
   * Adds a new broker to the brokers form array
   */
  addBrokerItem() {
    const brokers = this.kafkaFormGroup.get('brokers') as FormArray;
    brokers.push(this.createBrokerFormGroup());
  }

  /**
   * removes a broker from the fomr array
   * @param index the item to remove by index
   */
  removeBrokerItem(index) {
    const brokers = this.kafkaFormGroup.get('brokers') as FormArray;
    brokers.removeAt(index);
  }

  /**
   * Returns a comma seperated string of all the brokers added
   */
  get brokers(): string {
    return Array.prototype.map.call(this.kafkaFormGroup.get('brokers').value, (item) => `${item.name}:${item.port}`).join(',');
  }

  /**
   * Returns a connection object from the form controls
   */
  getConnection(isTesting: boolean): Connection {
    const connection = {} as Connection;

    connection.database = this.brokers;
    const isUsingKerberos = this.kafkaFormGroup.get('useKerberos').value;
    const isEnableBatch = this.kafkaFormGroup.get('enableBatch').value;
    connection.parameters = [
      {
        key: KAFKA_CONNECTION_PARAMETERS.KAFKA_PRODUCER_CONFIG_FILE_PATH,
        value: this.kafkaFormGroup.get('configurationFile').value
      },
      {
        key: KAFKA_CONNECTION_PARAMETERS.KAFKA_USE_KERBEROS,
        value: isUsingKerberos
      },
      {
        key: KAFKA_CONNECTION_PARAMETERS.KAFKA_ENABLE_BATCH,
        value: isEnableBatch
      }
    ];

    if (isUsingKerberos) {
      connection.parameters.push({
        key: KAFKA_CONNECTION_PARAMETERS.KAFKA_KERBEROS_PRINCIPAL,
        value: this.kafkaFormGroup.get('principal').value
      });
      connection.parameters.push({
        key: KAFKA_CONNECTION_PARAMETERS.KAFKA_KERBEROS_KEYTAB_LOCATION,
        value: this.kafkaFormGroup.get('keytabLocation').value
      });
    }

    if (isEnableBatch) {
      connection.parameters.push({
        key: KAFKA_CONNECTION_PARAMETERS.KAFKA_BATCH_SIZE,
        value: this.kafkaFormGroup.get('batchSize').value
      });
    }

    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   */
  set connection(connection: Connection) {
    const isUsingKerberos = JSON.parse(this.getParameterValue(connection.parameters, KAFKA_CONNECTION_PARAMETERS.KAFKA_USE_KERBEROS));
    const isEnableBatch = JSON.parse(this.getParameterValue(connection.parameters, KAFKA_CONNECTION_PARAMETERS.KAFKA_ENABLE_BATCH));
    this.kafkaFormGroup.patchValue({
      configurationFile: this.getParameterValue(connection.parameters, KAFKA_CONNECTION_PARAMETERS.KAFKA_PRODUCER_CONFIG_FILE_PATH),
      useKerberos: isUsingKerberos,
      principal: this.getParameterValue(connection.parameters, KAFKA_CONNECTION_PARAMETERS.KAFKA_KERBEROS_PRINCIPAL),
      keytabLocation: this.getParameterValue(connection.parameters, KAFKA_CONNECTION_PARAMETERS.KAFKA_KERBEROS_KEYTAB_LOCATION),
      enableBatch: isEnableBatch,
      batchSize: this.getParameterValue(connection.parameters, KAFKA_CONNECTION_PARAMETERS.KAFKA_BATCH_SIZE)
    });

    const formBuilder = new FormBuilder();
    const brokers = this.convertStringToBrokersObject(connection.database);
    const brokersFormGroups = brokers.map((broker) => formBuilder.group(broker));
    const brokersFormArray = formBuilder.array(brokersFormGroups);
    this.kafkaFormGroup.setControl('brokers', brokersFormArray);
    this.isKerberosSectionVisible = isUsingKerberos;
    this.enableBatchChanged(isEnableBatch);
  }

  /**
   * getter to return the brokers array from the form
   */
  get brokersArray(): FormArray {
    return this.kafkaFormGroup.get('brokers') as FormArray;
  }

  /**
   * Adds form validations
   */
  private addFormValidators() {
    this.kafkaFormGroup.setValidators([this.kerberosFieldRequired.bind(this)]);
    this.enableBatchChanged(true);
  }

  /**
   * validator for checking if the kerberos extra fields have been entered
   * @param input form group
   * @returns null if no errors are found or an object detialing the error
   */
  private kerberosFieldRequired(input: AbstractControl) {
    const useKerberos = input.get('useKerberos').value;
    if (useKerberos) {
      const principal = input.get('principal').value;
      const keytabLocation = input.get('keytabLocation').value;
      if (principal === '' || keytabLocation === '') {
        return {
          useKerberosError: {
            missingRequiredFields: true
          }
        };
      }
    }

    return null;
  }

  /**
   * enable/disable the batch size control and validators based on whether the "Enable asynchronous apply" checkbox is checked or not
   * @param isChecked whether the "Enable asynchronous apply" checkbox is checked or not
   */
  enableBatchChanged(isChecked) {
    const batchSizeControl = this.kafkaFormGroup.get('batchSize');

    if (isChecked) {
      batchSizeControl.enable();
      batchSizeControl.setValidators([Validators.required, Validators.min(100), Validators.max(10000), Validators.pattern('^[0-9]*$')]);
    } else {
      batchSizeControl.disable();
      batchSizeControl.clearValidators();
    }
    batchSizeControl.updateValueAndValidity();
  }

  /**
   * creates a new form group containing the controls for the new broker object
   * @returns form group containing the new options for the new broker
   */
  private createBrokerFormGroup(): FormGroup {
    return this.formBuilder.group({
      name: ['', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator]],
      port: ['', [Validators.required, Validators.min(1024), Validators.max(65535), Validators.pattern('^[0-9]*$')]]
    });
  }

  /**
   * Converts a string representation of the brokers to an object
   * @param brokers comma seperate string containing the broker information
   */
  private convertStringToBrokersObject(brokers: string) {
    return brokers.split(',').map((brokerString) => {
      const [name, port] = brokerString.split(':');
      return {
        name: new FormControl(name, Validators.required),
        port: new FormControl(port, [Validators.required, Validators.min(1024), Validators.max(65535), Validators.pattern('^[0-9]*$')])
      };
    });
  }
}
