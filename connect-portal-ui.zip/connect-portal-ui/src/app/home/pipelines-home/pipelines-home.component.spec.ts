import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { PipelinesHomeComponent } from './pipelines-home.component';
import { PipelineService } from '../../pipelines/pipeline/pipeline.service';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { ProjectsApiService } from '../../pipelines/pipeline/shared/projects-api.service';
import { Project } from '../../pipelines/pipeline/shared/project';

describe('PipelinesHomeComponent', () => {
  let component: PipelinesHomeComponent;
  let fixture: ComponentFixture<PipelinesHomeComponent>;
  let projectsApiService: ProjectsApiService;

  const mockPipelineService = jasmine.createSpyObj<Partial<PipelineService>>('mockPipelineService', [
    'createProjectIfRequired',
    'setProjectId'
  ]);
  const mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), RouterTestingModule, HttpClientTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [PipelinesHomeComponent],
      providers: [
        { provide: PipelineService, useValue: mockPipelineService },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(PipelinesHomeComponent);
    projectsApiService = TestBed.inject(ProjectsApiService);
    component = fixture.componentInstance;
    fixture.detectChanges();
    mockPipelineService.createProjectIfRequired.calls.reset();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should navigate to create pipeline when button is clicked and multiple projects flag is set', waitForAsync(() => {
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(component, 'navigateTo').and.returnValue();
    component.createPipelineClicked();
    fixture.whenStable().then(() => {
      expect(mockPipelineService.setProjectId).toHaveBeenCalledWith('abcd');
      expect(mockPipelineService.createProjectIfRequired).not.toHaveBeenCalled();
      expect(component.navigateTo).toHaveBeenCalledWith('pipelines/create');
    });
  }));

  it('should create default project and navigate to create pipeline when button is clicked and multiple projects flag is not set', waitForAsync(() => {
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(false);
    spyOn(component, 'navigateTo').and.returnValue();
    component.createPipelineClicked();
    fixture.whenStable().then(() => {
      expect(mockPipelineService.createProjectIfRequired).toHaveBeenCalled();
      expect(component.navigateTo).toHaveBeenCalledWith('pipelines/create');
    });
  }));
});
