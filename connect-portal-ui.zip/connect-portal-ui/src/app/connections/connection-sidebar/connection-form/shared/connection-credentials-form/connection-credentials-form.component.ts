import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { ConnectionFormValidators } from '../../shared/connection-form-validators';
import { BaseConnectionForm } from '../../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../../base-connection-form/base-connection-form.component';
import { Connection } from '../../../../shared/connection';

@Component({
  selector: 'p-connect-connection-credentials-form',
  templateUrl: './connection-credentials-form.component.html'
})
export class ConnectionCredentialsFormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy, BaseConnectionForm {
  @Input() formGroup;

  userControlName = 'catalogUser';
  passwordControlName = 'catalogPassword';
  hasPasswordChanged = false;
  passwordMask = '........';

  ngOnDestroy(): void {
    this.removeChildFormControls(this.formGroup);
  }

  constructor(private readonly controlContainer: ControlContainer) {
    super();
  }

  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): Connection {
    const connection = {} as Connection;
    connection.username = this.formGroup.get(this.userControlName).value;
    connection.password = this.hasPasswordChanged ? this.formGroup.get(this.passwordControlName).value : '';
    return connection;
  }

  set connection(connection: Connection) {
    this.formGroup.patchValue({
      [this.userControlName]: connection.username,
      [this.passwordControlName]: this.passwordMask
    });
    this.formGroup.get(this.passwordControlName).clearValidators();
    this.formGroup.get(this.passwordControlName).updateValueAndValidity();
  }

  ngOnInit(): void {
    this.createForm();
  }

  createForm(): void {
    this.formGroup = this.controlContainer.control as FormGroup;
    const validators = [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator];
    this.formGroup.addControl(this.userControlName, new FormControl('', validators));
    this.formGroup.addControl(this.passwordControlName, new FormControl('', validators));
  }

  passwordChanged(): void {
    if (!this.hasPasswordChanged) {
      this.hasPasswordChanged = true;
      this.formGroup.get(this.passwordControlName).setValue('');
    }
  }

  requireCredentials(): void {
    const userControl = this.formGroup.get(this.userControlName);
    const passwordControl = this.formGroup.get(this.passwordControlName);
    // clear the values
    userControl.setValue('');
    passwordControl.setValue('');
    // require the credentials to be entered again
    const validators = [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator];
    userControl.setValidators(validators);
    userControl.updateValueAndValidity();
    passwordControl.setValidators(validators);
    passwordControl.updateValueAndValidity();
  }
}
