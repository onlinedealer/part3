import { HttpErrorResponse, HttpHeaders } from '@angular/common/http';
import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Connection } from 'src/app/connections/shared/connection';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';
import { SidebarButton } from 'src/app/shared/components/sidebar/sidebar-button';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { first } from 'rxjs/operators';
import { Pipeline, TableMapping } from '../../../shared/pipeline';
import { PipelineEntityService } from '../../../shared/pipeline-entity.service';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { ColumnList, ColumnMap } from '../../shared/map-columns';
import { ColumnMappingTableComponent } from './column-mapping-table/column-mapping-table.component';
import { BulkColumnMappingSidebarComponent } from './bulk-column-mapping-sidebar/bulk-column-mapping-sidebar.component';
import { TranslocoService } from '@ngneat/transloco';
import { MAPPING_CONST } from '../../shared/mapping_constants';
import { ColumnMappingOverviewComponent } from './column-mapping-overview/column-mapping-overview.component';
@Component({
  selector: 'p-connect-column-mapping-sidebar',
  templateUrl: './column-mapping-sidebar.component.html',
  styleUrls: ['column-mapping-sidebar.component.scss']
})
export class ColumnMappingSidebarComponent {
  @Input() sourceDataConnection: Connection;
  @Input() targetDataConnection: Connection;
  @Input() pipeline: Pipeline;
  @Output() updatedTableMapping = new EventEmitter<any>();
  @Output() updateCheckingData = new EventEmitter<any>();
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(ColumnMappingTableComponent) tableComponent: ColumnMappingTableComponent;
  @ViewChild(BulkColumnMappingSidebarComponent) bulkMappingComponent: BulkColumnMappingSidebarComponent;
  @ViewChild(ColumnMappingOverviewComponent) overviewComponent: ColumnMappingOverviewComponent;
  targetEditable = false;
  data: ColumnMap[];
  columnList: { label: string; value: ColumnList }[] = [];
  actionList: string[] = ['Copy', 'Ignore'];
  skipHeader = new HttpHeaders().set(InterceptorSkipHeader, '');
  rowData: any;
  renderTable = false;
  schemaLibrary: string;
  tableMapping: TableMapping[];
  rowTableMapping: TableMapping;
  resetData;
  isReorderEnabled: boolean;
  hasCustomColumnMappings: boolean;
  searchText: string;
  schemaRegistryAvailable: boolean;
  masterColumnList: ColumnList[];
  displayValues: any[];
  versionsList;

  cancelButton: SidebarButton = {
    id: 'columnMappingCancel',
    text: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.BUTTONS.CANCEL_BUTTON',
    testId: 'column-mapping-sidebar-cancel-button'
  };

  primaryButton: SidebarButton = {
    id: 'saveColumnMapping',
    text: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.BUTTONS.PRIMARY_BUTTON'
  };
  checkedItems: any[] = [];

  constructor(
    private readonly pipelineMappingService: PipelineMappingService,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly translocoService: TranslocoService
  ) {}

  open(row) {
    this.sidebarComponent.open();
    this.rowData = row;
    this.tableMapping = this.pipelineEntityService.getPipeline().tableMapping;
    this.saveTableMapping(row);
    this.sidebarComponent.isProcessingRequest = true;
    this.rowTableMapping = this.findTableMappingByID();
    this.hasCustomColumnMappings = this.rowTableMapping?.hasCustomColMappings;
    this.setTargetEditable();
    this.overviewComponent.open();
    setTimeout(() => {
      this.renderTable = true;
    });
  }

  setTargetEditable() {
    this.schemaRegistryAvailable = this.pipeline.target.parameters?.find((ele) => ele.key === 'SCHEMA_REGISTRY_ID') ? true : false;
    if (!this.schemaRegistryAvailable) {
      this.targetEditable = true;
    }
  }

  reorderChangeEvent(event) {
    this.isReorderEnabled = event.checked;
  }

  getColumnList(row) {
    this.columnList = [];
    this.setSchemaLibrary(row);
    this.pipelineMappingService
      .getColumns(this.pipeline?.id, this.rowTableMapping?.id)
      .pipe(first())
      .subscribe({
        next: (data: ColumnList[]) => {
          this.masterColumnList = data;
          this.alphabeticalSortColumnList();
          this.columnList = this.masterColumnList.map((d) => ({ label: d.displayLabel, value: d }));
          if (this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID) !== undefined) {
            this.rowTableMapping.type.includes('SUBJECT_DOES_NOT_EXIST') ? this.getColumnMapping() : this.getVersions();
          } else {
            this.getColumnMapping();
          }
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
          this.sidebarComponent.isProcessingRequest = false;
        }
      });
  }

  findTableMappingByID(): TableMapping {
    return this.tableMapping.filter((tMapping) => {
      if (tMapping.id === this.rowData.id) return tMapping;
    })[0];
  }

  getVersions() {
    this.pipelineMappingService
      .getVersions(
        this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID).value,
        this.rowData.subject.name
      )
      .subscribe({
        next: (data: any[]) => {
          this.versionsList = data.map((obj) => obj.version);
          this.transformVersionList();
          this.getColumnMapping();
        },
        error: (error: HttpErrorResponse) => {
          this.sidebarComponent.isProcessingRequest = false;
          this.sidebarComponent.parseHttpClientResponseMessage('error', error);
        }
      });
  }

  getColumnMapping(version?) {
    this.sidebarComponent.isProcessingRequest = true;
    let schemaVersion = version?.value || null;
    this.pipelineMappingService
      .getColumnMappings(this.pipeline.id, this.rowTableMapping.id, schemaVersion)
      .pipe(first())
      .subscribe({
        next: (columnMaps: ColumnMap[]) => {
          this.data = columnMaps;
          this.tableComponent?.defaultMapping(this.data);
          this.sidebarComponent.isProcessingRequest = false;
          this.tableComponent.updateHasCustomColumnMappings();
        },
        error: (errorResponse: HttpErrorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
          this.sidebarComponent.isProcessingRequest = false;
        }
      });
  }

  primaryButtonClicked() {
    this.tableComponent.updateData();
    if (this.tableComponent.validateGrid(true)) {
      this.saveColumnMapping(this.data);
    }
  }

  saveColumnMapping(columnMaps: ColumnMap[]) {
    this.rowTableMapping.columnMappings = columnMaps;
    this.rowTableMapping.hasCustomColMappings = this.hasCustomColumnMappings;
    this.sidebarComponent.isProcessingRequest = true;
    this.pipelineMappingService.saveColumnMapping(this.pipeline.id, this.rowTableMapping).subscribe({
      next: (schemaVersion: string) => {
        this.sidebarComponent.isProcessingRequest = false;
        this.updatedTableMapping.emit({
          hasCustomColMappings: this.hasCustomColumnMappings,
          rowId: this.rowTableMapping.id,
          version: schemaVersion,
          tableMappingType: this.rowTableMapping.type,
          subject: this.rowData.subject
        });
        this.close();
      },
      error: (errorResponse) => {
        this.sidebarComponent.isProcessingRequest = false;
        this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
      }
    });
  }

  saveTableMapping(row) {
    this.pipelineMappingService.saveTableMapping(this.pipeline.id, this.tableMapping).subscribe({
      next: () => {
        this.updateCheckingData.emit();
        this.getColumnList(row);
      },
      error: (error) => {
        this.sidebarComponent.parseHttpClientResponseMessage('error', error);
        this.sidebarComponent.isProcessingRequest = false;
      }
    });
  }

  alphabeticalSortColumnList() {
    let mergedList = [];
    let metadataColumnList = this.masterColumnList.filter((columns) => columns.isCDCRowMetaDataColumn === true);
    let nonMetadataColumnList = this.masterColumnList.filter((columns) => columns.isCDCRowMetaDataColumn === false);
    nonMetadataColumnList.forEach((element) => {
      element.displayLabel = element.columnName;
    });
    metadataColumnList = metadataColumnList.map((object) => ({
      ...object,
      displayLabel: this.translocoService.translate(
        `pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ROW_METADATA_FIELDS.` + object.columnName
      )
    }));
    metadataColumnList.sort((a, b) => {
      return a.displayLabel.toLowerCase().localeCompare(b.displayLabel.toLowerCase());
    });
    mergedList = nonMetadataColumnList.concat(metadataColumnList);
    this.masterColumnList = mergedList;
  }

  dataChangeEvent($event) {
    this.data = $event;
  }

  hasCustomColumnMappingsChangeEvent($event) {
    this.hasCustomColumnMappings = $event;
  }

  bulkMappingSaveEvent(event) {
    this.tableComponent.applyBulkMapping(event, this.checkedItems);
    this.tableComponent.updateHasCustomColumnMappings();
    this.tableComponent.updateAllInputFields();
  }

  resetDataChangeEvent(event: ColumnMap[]) {
    this.tableComponent.applyResetDefault(event, this.checkedItems);
    this.tableComponent.updateHasCustomColumnMappings();
  }

  updateCheckedItems(event: any) {
    this.checkedItems = event;
  }

  displayValuesChangeEvent(event: any[]) {
    this.displayValues = event;
  }

  primaryButtonDisable(event: boolean) {
    this.primaryButton.isDisabled = event;
  }

  deleteErrorMessageEvent(event) {
    this.sidebarComponent.parseHttpClientResponseMessage('warning', event);
  }

  setSchemaLibrary(row) {
    if (this.sourceDataConnection.connectionType === 'DB2I') {
      this.schemaLibrary = row.library;
    } else {
      this.schemaLibrary = row.schema;
    }
  }

  transformVersionList() {
    this.versionsList = this.versionsList.map((versions) => ({
      key: versions,
      value: versions
    }));
    if (this.versionsList.length) {
      this.versionsList[this.versionsList.length - 1].value = this.translocoService.translate(
        'pipelines.STAGES.MAPPING.COLUMN_MAPPING_OVERVIEW.DROPDOWN_NEWEST'
      );
    }
    this.versionsList.reverse();
  }

  close() {
    this.isReorderEnabled = false;
    this.sidebarComponent.close();
    this.data = [];
    this.checkedItems = [];
    this.tableComponent.checkedItems = [];
    this.tableComponent.updateDisplayValues(this.data);
    this.hasCustomColumnMappings = false;
    this.isReorderEnabled = false;
  }
  versionChangeEvent(event) {
    this.getColumnMapping(event);
  }
}
