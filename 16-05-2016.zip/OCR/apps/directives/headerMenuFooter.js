(function() {
    'use strict';
    // Header
    fileuploader.directive('headerTemplate', ['uiRouters', headerTemplate]);

    function headerTemplate(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/header.html',
            
        }
    }
    
    // Footer
    fileuploader.directive('footerTemplate', ['uiRouters', footerTemplate]);

    function footerTemplate(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/footer.html'
        }
    }

    
})();
