import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective } from '@angular/forms';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { OrderbyascPipe } from 'src/app/shared/pipes/dynamic-dropdown-sort.pipe';
import { ConnectionCredentialsFormComponent } from './connection-credentials-form.component';
import { ServiceInjector } from '../../../../../shared/services/service.injector';
import { Connection } from '../../../../shared/connection';

// mocked component to be used everywhere the credentials component is used and tested
@Component({
  selector: 'p-connect-connection-credentials-form',
  template: '',
  providers: [
    {
      provide: ConnectionCredentialsFormComponent,
      useClass: MockConnectionCredentialsFormComponent
    }
  ]
})
export class MockConnectionCredentialsFormComponent {
  passwordMask = '........';
  getConnection(): Connection {
    return {};
  }
  set connection(connection: Connection) {}
  requireCredentials() {}
}

describe('ConnectionCredentialsFormComponent', () => {
  let component: ConnectionCredentialsFormComponent;
  let fixture: ComponentFixture<ConnectionCredentialsFormComponent>;
  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  class mockInjector {
    get() {
      return {};
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [ConnectionCredentialsFormComponent, OrderbyascPipe],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    ServiceInjector.injector = new mockInjector();
    fixture = TestBed.createComponent(ConnectionCredentialsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return credentials for saving', () => {
    component.formGroup.patchValue({
      catalogUser: 'user',
      catalogPassword: 'pwd'
    });
    component.hasPasswordChanged = true;
    const connection: Connection = component.getConnection(false);
    expect(connection.username).toBe('user');
    expect(connection.password).toBe('pwd');
  });

  it('should return credentials for updating', () => {
    component.formGroup.patchValue({
      catalogUser: 'user',
      catalogPassword: 'pwd'
    });
    component.hasPasswordChanged = false;
    const connection: Connection = component.getConnection(false);
    expect(connection.username).toBe('user');
    expect(connection.password).toBe('');
  });

  it('should set the credentials', () => {
    const dataConnection = {
      username: 'newUser'
    } as Connection;
    component.connection = dataConnection;
    expect(component.formGroup.get('catalogUser').value).toBe('newUser');
    expect(component.formGroup.get('catalogPassword').value).toBe(component.passwordMask);
  });

  it('should set whether the password changed or not', () => {
    component.passwordChanged();
    expect(component.hasPasswordChanged).toBeTrue();
    component.passwordChanged();
    expect(component.hasPasswordChanged).toBeTrue();
  });

  it('should require the credentials', () => {
    const dataConnection = {
      username: 'newUser'
    } as Connection;
    component.connection = dataConnection;
    expect(component.formGroup.get('catalogUser').value).toBe('newUser');
    expect(component.formGroup.get('catalogPassword').value).toBe(component.passwordMask);
    component.requireCredentials();
    expect(component.formGroup.get('catalogUser').value).toBe('');
    expect(component.formGroup.get('catalogPassword').value).toBe('');
  });
});
