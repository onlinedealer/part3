export interface INotifyConfifEmail {
  recipients: Array<string>;
  type: 'email';
  enabled: boolean;
}
export class NotifyConfig {
  notifications: INotifyConfifEmail[];
  constructor(notifyData) {
    if (notifyData) {
      this.notifications = notifyData;
    } else {
      this.notifications = [
        {
          recipients: [],
          type: 'email',
          enabled: true
        }
      ];
    }
  }
}
