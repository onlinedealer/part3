import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router'
import styles from './style.css';
import {reactLocalStorage} from 'reactjs-localstorage';

class Reg extends React.Component {
		constructor(props) {
		    super(props);
		    this.state = { name: "bharath" };

		    this.handleSubmit = this.handleSubmit.bind(this);
		}
	
	  
	  handleSubmit(e) {	  
    	const data = new FormData(event.target);
    	console.log(data);
    	fetch('/api/form-submit-url', {
	      method: 'POST',
	      body: data,
	    });
	  }

   render() {
      return (
         <div className="container-fluid">
			<div className="row">
			    <div className="col-lg-10">
			     
			      <form class="form-horizontal" onSubmit={this.handleSubmit}>
			      	<h1 class="text-center">Registration Employee Form</h1>
					<hr/>
				    <div class="form-group">
				      <label class="control-label col-sm-2" htmlFor="email">Email:</label>
				      <div class="col-sm-10">
				        <input type="email" class="form-control" onChange={ this.email } placeholder="Enter email" name="email" />
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-sm-2" htmlFor="fName" >First Name:</label>
				      <div class="col-sm-10">
				        <input type="text" class="form-control" onChange={ this.fName } placeholder="Enter First Name" name="fName" />
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-sm-2" htmlFor="lName">Last Name:</label>
				      <div class="col-sm-10">
				        <input type="text" class="form-control" onChange={ this.lName }  placeholder="Enter Last Name" name="lName" />
				      </div>
				    </div>
				    <div class="form-group">
				      <label class="control-label col-sm-2" htmlFor="id">ID:</label>
				      <div class="col-sm-10">
				        <input type="number" class="form-control" onChange={ this.empID } placeholder="Enter New Emp ID" name="id" />
				      </div>
				    </div>
				    
				    <div class="form-group">        
				      <div class="col-sm-offset-2 col-sm-10">
				        <button type="submit" class="btn btn-default">Submit</button>
				      </div>
				    </div>
				  </form>







			    </div>
			</div>
		</div>
      );
   }
}

export default Reg;