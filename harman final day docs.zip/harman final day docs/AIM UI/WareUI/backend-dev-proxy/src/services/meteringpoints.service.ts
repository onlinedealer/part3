import { Observable, from, of } from "rxjs";
import { map, tap, catchError, concatMap } from "rxjs/operators";
import * as soapAPI from "../soap-api/index";

import { Parser, processors } from "xml2js";

const parser = new Parser({
  ignoreAttrs: true,
  tagNameProcessors: [
    processors.stripPrefix,
    processors.firstCharLowerCase,
    processors.parseNumbers,
    processors.parseBooleans
  ],
  explicitArray: false
});

export class MeteringpointsService {

  getMeteringpoints(): Observable<any> {

    return from(soapAPI.getMeteringPoints()).pipe(
      map( (response: string) => this.convertToJson(response)),
      map( (response: any) => this.convertToResults(response)),
      catchError( (error:any) => {
        console.log(JSON.stringify(error, null, 4));
        return of([]);
      }
    ));
  }

  private convertToResults( response: any ): any {
    return response.envelope.body.searchResponseElement.result.searchResults.map(this.convertMeteringPoint);
  }

  private convertMeteringPoint( meteringPoint: any){
    return {
      id: Number(meteringPoint.meteringPointId),
      name: meteringPoint.meteringPointName,
      gsrn: meteringPoint.gsrn,
      address: meteringPoint.meteringPointAddress,
      postalCode: meteringPoint.meteringPointPostalCode,
      city: meteringPoint.meteringPointCity,
      customerNumber: meteringPoint.customerNumber,
      customerName: meteringPoint.customerName,
      flagState: meteringPoint.flagState,
    }
  }

  private convertToJson(data: string): any {

    let res;

    parser.parseString(data, (error: any, result: any) => {
      
      if (error) {
        throw new Error(error);
      } else {
        res = result;
      }

    });

    return res;
  }

}
