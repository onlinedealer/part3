export class ResultHeaderModel {
  name: string;
  description: string;
  dataConnectionName: string;
  dataConnectionType: string;
  profileName: string;
  runByUser: string;
  lastRun: Date;
  duration: string;
  rowsProcessed: number;
  account: string;
  databaseName: string;
  schema: string;
  warehouse: string;
}
