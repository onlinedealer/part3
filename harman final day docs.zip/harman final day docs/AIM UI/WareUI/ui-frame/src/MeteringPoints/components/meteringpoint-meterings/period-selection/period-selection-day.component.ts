import {
    Component,
    ChangeDetectionStrategy,
    Input,
    ViewChild,
    ElementRef,
    EventEmitter,
    Output,
    OnDestroy,
    SimpleChanges,
    OnChanges
} from "@angular/core";
import { debounceTime, filter, map } from "rxjs/operators";
import { FormControl } from "@angular/forms";
import { Subscription, Observable } from "rxjs";
import * as moment from "moment";
import { MatDatepicker } from "@angular/material/datepicker";

@Component({
    selector: "landisgyr-period-selection-day",
    templateUrl: "./period-selection-day.component.html",
    styleUrls: ["./period-selection.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PeriodSelectionDayComponent implements OnChanges, OnDestroy {
    @ViewChild("datePicker", { static: true }) datePicker!: MatDatepicker<any>;
    @ViewChild("dayInput", { static: true }) input!: ElementRef<HTMLInputElement>;

    @Input()
    disabled = false;

    @Input()
    from!: number;

    @Input()
    until!: number;

    @Output()
    timePeriodChange = new EventEmitter<{ from: number; until: number }>();

    dayInputControl = new FormControl({ value: "", disabled: this.disabled });

    private dayInputValueChanges$: Observable<any> = this.dayInputControl.valueChanges.pipe(
        debounceTime(200),
        map((value) => moment(value)),
        filter((value) => moment.isMoment(value))
    );

    private dayInputChangeSubscription: Subscription = this.dayInputValueChanges$.subscribe((value) => {
        this.timePeriodChange.emit({
            until: value.valueOf(),
            from: value.valueOf()
        });
    });

    ngOnChanges(changes: SimpleChanges) {
        if (this.until) {
            const endMoment = moment(this.until);
            const nowMoment = moment();
            const momentToUse = endMoment.isBefore(nowMoment) ? endMoment : nowMoment;

            this.dayInputControl.setValue(new Date(momentToUse.valueOf()));
        }

        if (this.disabled) {
            this.dayInputControl.disable();
        } else {
            this.dayInputControl.enable();
        }
    }

    ngOnDestroy() {
        this.dayInputChangeSubscription.unsubscribe();
    }

    onArrowClickBackward() {
        this.dayInputControl.setValue(new Date(moment(this.dayInputControl.value).subtract(1, "day").valueOf()));
    }

    onArrowClickForward() {
        const nextDay = moment(this.dayInputControl.value).add(1, "day");
        const nowMoment = moment();

        if (nextDay.isSameOrBefore(nowMoment)) {
            this.dayInputControl.setValue(new Date(nextDay.valueOf()));
        }
    }
}
