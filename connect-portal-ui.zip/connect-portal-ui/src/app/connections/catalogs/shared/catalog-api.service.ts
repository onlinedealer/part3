import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseCatalogApiService } from 'src/app/core/base-catalog-api.service';
import { Connection, CONNECTION_TYPE } from '../../shared/connection';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';
import { CatalogSchema } from './catalog-schema';
import { map, Observable } from 'rxjs';
import { CatalogStatus } from './catalog-status';

export enum UPDATE_CATALOG_ACTION {
  'START' = 'start',
  'STOP' = 'stop'
}

/**
 * Service for managing the catalog
 */
@Injectable({
  providedIn: 'root'
})
export class CatalogApiService extends BaseCatalogApiService<CatalogSchema> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient, 'api/v1');
  }

  /**
   * Updates the catalog schemas for an existing catalog
   * @param schemas The schemas to start the catalog for
   * @param connection The connection to use for the catalog
   * @param projectId The project id to use for the catalog
   * @param action The action to perform, default is start
   * @returns
   */
  updateCatalog(schemas: string[], connection: Connection, projectId: string, action: UPDATE_CATALOG_ACTION = UPDATE_CATALOG_ACTION.START) {
    let updateCatalogUrl = this.getCatalogUrl(connection.connectionType);
    if (action === UPDATE_CATALOG_ACTION.STOP) {
      updateCatalogUrl += '?action=stop';
    }
    return this.httpClient.put(updateCatalogUrl, {
      catalogSchemas: schemas,
      connectionId: connection.id,
      connectionName: connection.name,
      connectionType: connection.connectionType,
      projectId: projectId
    });
  }

  /**
   * Start the catalog process for the selected schemas for the first time
   * @param schemas The schemas to start the catalog for
   * @param connection The connection to use for the catalog
   * @param projectId The project id to use for the catalog
   * @returns
   */
  createCatalog(schemas: string[], connection: Connection, projectId: string) {
    let createCatalogUrl = this.getCatalogUrl(connection.connectionType);
    return this.httpClient.post(createCatalogUrl, {
      catalogSchemas: schemas,
      connectionId: connection.id,
      connectionName: connection.name,
      connectionType: connection.connectionType,
      projectId: projectId
    });
  }

  /**
   * Delete the catalog for the given connection id and selected schemas
   * @param schemas The schemas to delete the catalog for
   * @param connection The connection to use for the catalog
   * @param projectId The project id to use for the catalog
   * @returns
   */
  deleteCatalog(schemas: string[], connection: Connection, projectId: string) {
    return this.httpClient.delete(this.serviceURL + '/catalog/schemas', {
      body: {
        catalogSchemas: schemas,
        connectionId: connection.id,
        connectionName: connection.name,
        connectionType: connection.connectionType,
        projectId: projectId
      }
    });
  }

  /**
   * Delete the catalog for multiple data connections
   * @returns
   */
  deleteCatalogs(ids: string[]) {
    return this.httpClient.delete(this.serviceURL + '/catalog/schemass', {
      body: ids
    });
  }

  /**
   * Retrieve the catalog status for the given connection id
   * @param connectionId The connection id to use for the catalog
   * @param details if true it will display the details, default is false
   * @returns The catalog status
   */
  status(connectionId: string, details: boolean): Observable<CatalogStatus> {
    const headers = new HttpHeaders().set(InterceptorSkipHeader, '');
    return this.httpClient
      .get(this.serviceURL + '/status?connection_id=' + connectionId + '&details=' + details, { headers })
      .pipe(map((response: CatalogStatus) => response));
  }

  /**
   * Retrieve the catalog status for the given connection ids
   * @param connectionIds List of connection ids to get the catalog status for
   * @param details whether to display the details or not
   * @returns Catalog status for the given connection ids
   */
  statusSummary(connectionIds: string[], details = true) {
    const headers = new HttpHeaders().set(InterceptorSkipHeader, '');
    return this.httpClient.post(this.serviceURL + '/status/summary?details=' + details, connectionIds, { headers });
  }

  private getCatalogUrl(connectionType: string): string {
    switch (connectionType) {
      case CONNECTION_TYPE.KAFKA:
        return this.serviceURL + '/catalog/topics';
      case CONNECTION_TYPE.SCHEMAREGISTRY:
        return this.serviceURL + '/catalog/subjects';
      default:
        return this.serviceURL + '/catalog/schemas';
    }
  }
}
