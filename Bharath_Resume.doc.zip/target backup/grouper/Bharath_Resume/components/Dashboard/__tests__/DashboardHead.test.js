import React from 'react'
import { shallow } from 'enzyme'
import DashboardHead from '../DashboardHead'

describe('DashboardHead component', () => {
  let wrapper, wrapperBlock
  let props = {
    classes: {},
    order: 'asc',
    orderBy: 'group_id',
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }
  it('renders', () => {
    props.onRequestSort = jest.fn()
    wrapper = shallow(
      <DashboardHead {...props} />)
    expect(wrapper).toHaveLength(1)
  })

  it('invoking createSortHandler ', () => {
    props.onRequestSort = jest.fn()
    wrapperBlock = shallow(
      <DashboardHead {...props} />)
    wrapperBlock.instance().createSortHandler('group_id')({})
    expect(props.onRequestSort.mock.calls.length).toEqual(1)
  })
})
