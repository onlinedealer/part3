import { ProfileResultsTableModel } from './profile-results-table.model';

export class ProfileResultsModel {
  name: string;
  description: string;
  dataConnectionName: string;
  dataConnectionType: string;
  runByUser: string;
  lastRun: Date;
  duration: string;
  rowsProcessed: number;
  tables: ProfileResultsTableModel[];
  status: string;
  errorMessages: [];
  account: string;
  databaseName: string;
  schema: string;
  warehouse: string;
  host: string;
}
