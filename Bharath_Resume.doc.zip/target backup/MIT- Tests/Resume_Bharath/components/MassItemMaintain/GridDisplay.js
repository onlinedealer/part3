import React from 'react'
import { object } from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { withStyles } from '@material-ui/core/styles'
import { AgGridReact } from 'ag-grid-react'
// import 'ag-grid-enterprise'
import { pageLimit, gridColumFit } from './constants'
import GridUpdate from './GridUpdate'
import Grid from '@material-ui/core/Grid'

import 'ag-grid/dist/styles/ag-grid.css'
import 'ag-grid/dist/styles/ag-theme-balham.css'
import deleteOutline from '../../images/baseline-delete_outline-24px.svg'
import deleteForever from '../../images/baseline-delete_forever-24px.svg'

import {
  saveItems,
  cancelUpdate,
  toggleLoading,
} from '../../store/massItemMaintain/actionCreator'

const styles = theme => ({
  root: {
    textAlign: 'center',
  },
  paper: {
    padding: theme.spacing.unit * 2,
    textAlign: 'center',
    color: theme.palette.text.secondary,
    margin: theme.spacing.unit * 2,
  },
  button: {
    margin: 10,
  },
  progress: {
    margin: theme.spacing.unit * 2,
  },
  loaderBlock: {
    marginTop: 50,
    fontSize: 18,
  },
  errorMsg: {
    color: 'red',
  },
})

export class GridDisplay extends React.Component {
  getInitialState () {
    return { loading: true }
  }

  static propTypes = {
    classes: object,
  }
  state = {
    columnDefs: [],
    rowData: [],
    defaultColDef: {
      width: 300,
      filter: 'agTextColumnFilter',
      colKey: false,
    },
    commonFields: [],
    frameworkComponents: {
      numericCellEditor: NumericCellEditor,
      cellValueGetter: cellValueGetter,
      cellValueSetter: cellValueSetter,
    },
    loading: false,
    filteredData: [],
    appliedItems: '',
    UpdatedItems: false,
  }

  componentDidMount () {
    this.setState({ loading: false })
  }

  componentWillReceiveProps (nextProps) {
    const columnDefsTemp = []
    this.setState({ 'loading': false })

    if (nextProps.columnInfo) {
      nextProps.columnInfo.map((obj, index) => {
        let valGetterObj = ''
        let valSetterObj = ''
        let cellRenderObj = ''
        let cellEditor = ''
        let cellHide = false
        let cellWidth = 130
        let cellEvent = ''
        const cellColor = (obj.editable) ? '#fff' : '#ebebeb'
        const pinnedStatus = !!((index <= 2))
        if (obj.column_id === 'new_value') {
          valGetterObj = cellValueGetter
          valSetterObj = cellValueSetter
        } else if (obj.column_id === 'mode') {
          cellRenderObj = this.cellDeleteRenderer
          cellEvent = this.onDeleteEventClicked.bind(this)
        } else if (obj.column_id === 'copy') {
          cellRenderObj = this.cellCopyRender
          cellEvent = this.onCopyEventClicked.bind(this)
        }
        cellEditor = (obj.field_type === 'Number') ? 'numericCellEditor' : ''
        cellHide = (obj.column_id === 'primary_case_pack') ? true : cellHide
        cellWidth = (obj.column_id === 'mode' || obj.column_id === 'copy') ? 80 : cellWidth
        columnDefsTemp.push({
          headerName: obj.column_name,
          field: obj.column_id,
          width: cellWidth,
          sort: false,
          editable: obj.editable,
          pinned: pinnedStatus,
          cellStyle: {'background-color': cellColor, 'text-align': 'left'},
          valueGetter: valGetterObj,
          valueSetter: valSetterObj,
          cellRenderer: cellRenderObj,
          cellEditor: cellEditor,
          hide: cellHide,
          onCellClicked: cellEvent,
        })
      })
    }
    this.setState({ columnDefs: columnDefsTemp })
    this.setState({ rowData: nextProps.listItems })
  }

  cellDeleteRenderer (params) {
    var eSpan = document.createElement('img')
    if (params.value === 'delete') {
      eSpan.setAttribute('src', deleteForever)
    } else {
      eSpan.setAttribute('src', deleteOutline)
    }
    return eSpan
  }

  cellCopyRender (params) {
    var eSpan = document.createElement('input')
    eSpan.setAttribute('type', 'checkbox')
    if (params.value) {
      eSpan.setAttribute('checked', true)
    }
    return eSpan
  }

  onDeleteEventClicked = (event) => {
    var rowNode = this.gridApi.getRowNode(event.rowIndex)
    rowNode.data.mode = (rowNode.data.mode === '' || rowNode.data.mode === 'edit') ? 'delete' : ''
    rowNode.setData(rowNode.data)
    window.onbeforeunload = function () {
      return 'Data will be lost if you leave the page, are you sure?'
    }
  }

  onCopyEventClicked = (event) => {
    var rowNode = this.gridApi.getRowNode(event.rowIndex)
    rowNode.data.copy = !(rowNode.data.copy)
    rowNode.setData(rowNode.data)
    window.onbeforeunload = function () {
      return 'Data will be lost if you leave the page, are you sure?'
    }
  }

  onCellValueChanged = (event) => {
    var rowNode = this.gridApi.getRowNode(event.rowIndex)
    rowNode.data.mode = (rowNode.data.mode === '') ? 'edit' : rowNode.data.mode
    rowNode.setData(rowNode.data)
    window.onbeforeunload = function () {
      return 'Data will be lost if you leave the page, are you sure?'
    }
  }

  onCellEditingStarted = (event) => {
    var rowNode = this.gridApi.getRowNode(event.rowIndex)
    if (rowNode.data.mode === 'delete') { this.gridApi.stopEditing(true) }
  }

  onGridReady (params) {
    this.gridApi = params.api
    this.columnApi = params.columnApi
    if (gridColumFit) {
      this.gridApi.sizeColumnsToFit()
      window.addEventListener('resize', function () {
        setTimeout(function () {
          params.api.sizeColumnsToFit()
        })
      })
      params.api.sizeColumnsToFit()
    }
    this.gridApi.paginationSetPageSize(pageLimit)
  }

  setfilteredData = (newValue) => (node, index) => {
    if (node.data.new_value === undefined) {
      const valObj = [{
        'value': newValue,
        'id': '',
        'uom': '',
      }]
      node.data.new_value = valObj
    } else {
      node.data.new_value[0].value = newValue
    }
  }

  updateItems = (newValue) => {
    this.gridApi.forEachNodeAfterFilter(this.setfilteredData(newValue))
    this.gridApi.refreshCells()
    this.setState({ 'appliedItems': this.gridApi.getDisplayedRowCount() })
    setTimeout(function () {
      this.setState({ 'appliedItems': '' })
    }.bind(this), 2000)
    window.onbeforeunload = function () {
      return 'Data will be lost if you leave the page, are you sure?'
    }
  }

  saveItems = () => {
    this.setState({ 'loading': true })
    let commonFields = this.props.commonFields
    commonFields.user_id = this.props.auth.lanId
    let tempRowData = []
    if (this.props.updateMode !== 'excel') {
      if (commonFields.maintenance_type === 'cost') {
        this.state.rowData.map((rowData) => {
          if (rowData.new_value !== '' && rowData.new_value !== null) {
            if (rowData.new_value[0].value !== null && rowData.new_value[0].value !== '') {
              tempRowData.push(rowData)
            }
          }
        })
      } else {
        this.state.rowData.map((rowData) => {
          if (rowData.copy || (rowData.mode !== '' && rowData.mode !== undefined)) {
            tempRowData.push(rowData)
          }
        })
      }
      if (tempRowData.length >= 1) {
        this.props.toggleLoading(true, 'Saving')
        this.props.saveItems(tempRowData, commonFields, this.props.errorItems, this.props.auth.memberOf, this.props.auth.lanId)
      } else {
        // this.props.updateToastMessage(true, 'Please update new value atleast 1 item.')
        this.setState({ 'loading': false })
        this.setState({ 'UpdatedItems': true })
        setTimeout(function () {
          this.setState({ 'UpdatedItems': false })
        }.bind(this), 3000)
      }
    } else {
      this.props.toggleLoading(true, 'Saving')
      this.props.saveItems(this.state.rowData, commonFields, this.props.errorItems, this.props.auth.memberOf, this.props.auth.lanId)
    }
  }

   cancelUpdate = () => {
     this.props.cancelUpdate()
   }

   setFilter (selectRef) {
     const filterData = {}
     for (let key of Object.keys(selectRef)) {
       if (selectRef[key] !== '') {
         const keyObj = (key === 'vendor_id') ? isNaN(selectRef[key]) ? 'vendor_name' : 'vendor_id' : key
         filterData[keyObj] = {
           type: 'contains',
           filter: selectRef[key],
         }
       }
     }
     this.gridApi.setFilterModel(filterData)
     this.gridApi.onFilterChanged()
   }
   render () {
     return (
       <div>
         { this.props.listStatus &&
         <Grid container>
           <Grid item xs={12}>
             <GridUpdate
               auth={this.props.auth}
               listItems={this.props.listItems}
               columnInfo={this.props.columnInfo}
               commonFields={this.props.commonFields}
               gridText={this.props.gridText}
               updateCallBack={this.updateItems.bind(this)}
               setFilterCallBack={this.setFilter.bind(this)}
               appliedItems={this.state.appliedItems}
               cancelUpdateCallBack={this.cancelUpdate.bind(this)}
               saveItemsCallBack={this.saveItems.bind(this)}
             />
           </Grid>
           <Grid item xs={12}>
             <div style={{height: 400, margin: '10px', backgroundColor: '#e6e6e6'}} className="ag-theme-balham">
               <AgGridReact
                 id="itemsGrid"
                 // properties
                 columnDefs={this.state.columnDefs}
                 rowData={this.state.rowData}
                 defaultColDef={this.state.defaultColDef}
                 // events
                 onGridReady={this.onGridReady.bind(this)}
                 enableSorting
                 enableFilter
                 pagination="true"
                 enableColResize
                 components={this.state.frameworkComponents}
                 onCellValueChanged={this.onCellValueChanged.bind(this)}
                 onCellEditingStarted={this.onCellEditingStarted.bind(this)}
               />
             </div>
           </Grid>
         </Grid>
         }
       </div>
     )
   }
}

function cellValueGetter (params) {
  if (params.data.new_value === undefined) {
    const valurObj = [{
      'value': null,
      'id': null,
      'uom': null,
    }]
    params.data.new_value = valurObj
  }
  return params.data.new_value[0].value
}

function cellValueSetter (params) {
  params.data.new_value[0].value = params.newValue
  return params.data.new_value[0].value
}

function getCharCodeFromEvent (event) {
  event = event || window.event
  return (typeof event.which === 'undefined') ? event.keyCode : event.which
}

function isCharNumeric (charStr) {
  // return !!/\d/.test(charStr);
  return (charStr === 'Backspace' || charStr === '.') ? true : !!/\d/.test(charStr)
}

function isKeyPressedNumeric (event) {
  var charCode = getCharCodeFromEvent(event)
  var charStr = String.fromCharCode(charCode)
  return isCharNumeric(charStr)
}

// function to act as a class
function NumericCellEditor () {
}

// gets called once before the renderer is used
NumericCellEditor.prototype.init = function (params) {
  // create the cell
  this.eInput = document.createElement('input')

  if (isCharNumeric(params.charPress)) {
    this.eInput.value = params.charPress
  } else {
    if (params.value !== undefined && params.value !== null) {
      this.eInput.value = params.value
    }
  }

  var that = this
  this.eInput.addEventListener('keypress', function (event) {
    if (!isKeyPressedNumeric(event)) {
      that.eInput.focus()
      if (event.preventDefault) event.preventDefault()
    } else if (that.isKeyPressedNavigation(event)) {
      event.stopPropagation()
    }
  })

  // only start edit if key pressed is a number, not a letter
  var charPressIsNotANumber = params.charPress && ('1234567890'.indexOf(params.charPress) < 0)
  this.cancelBeforeStart = charPressIsNotANumber
}

NumericCellEditor.prototype.isKeyPressedNavigation = function (event) {
  return event.keyCode === 39 ||
        event.keyCode === 37
}

// gets called once when grid ready to insert the element
NumericCellEditor.prototype.getGui = function () {
  return this.eInput
}

// focus and select can be done after the gui is attached
NumericCellEditor.prototype.afterGuiAttached = function () {
  this.eInput.focus()
  this.eInput.select()
}

// returns the new value after editing
NumericCellEditor.prototype.isCancelBeforeStart = function () {
  return this.cancelBeforeStart
}

// example - will reject the number if it contains the value 007
// - not very practical, but demonstrates the method.
NumericCellEditor.prototype.isCancelAfterEnd = function () {
  var value = this.getValue()
  return value.indexOf('007') >= 0
}

// returns the new value after editing
NumericCellEditor.prototype.getValue = function () {
  return this.eInput.value
}

// any cleanup we need to be done here
NumericCellEditor.prototype.destroy = function () {
  // but this example is simple, no cleanup, we could  even leave this method out as it's optional
}

// if true, then this editor will appear in a popup
NumericCellEditor.prototype.isPopup = function () {
  // and we could leave this method out also, false is the default
  return false
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    saveItems,
    cancelUpdate,
    toggleLoading,
  }, dispatch)

const mapStateToProps = state => ({
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(GridDisplay))
