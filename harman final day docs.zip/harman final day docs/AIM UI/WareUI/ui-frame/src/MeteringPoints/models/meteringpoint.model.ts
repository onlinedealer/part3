import { CustomProperty } from "./custom-property.model";

export interface MeteringPointsSearchParameters {
    meteringPointName?: string;
    customerName?: string;
    customerNumber?: string;
    customerAddress?: string;
    zipCode?: string;
    gsrn?: string;
    deviceNumber?: string;
}

export interface MeteringPointsSearchResponse {
    parameters?: MeteringPointsSearchResponseParameters;
    data: MeteringPoint[];
}

export interface MeteringPointsSearchResponseParameters {
    query: string;
    type: number;
}

export interface MeteringPoint {
    id: number;
    name: string;
    gsrn?: string;
    address: Address;
    transformerArea?: string;
    remoteConnectable?: boolean;
    meteringPointStates: MeteringPointStates[];
    meterConnectionStatus: string;
    customerName?: any;
    customerNo?: any;
}

export interface MeteringPointStates {
    name: string;
    mpLifeCycleStateIdentifier: string;
    reasonCategoryIdentifier: string;
}
export interface Address {
    streetName: string;
    streetNumber: number;
    streetNumberExtension?: string;
    apartment?: string;
    areaCode: string;
    areaName?: string;
    postalCode: string;
    city: string;
    territory: string;
    countryCode?: string;
    postOfficeBox?: string;
}

export interface Source {
    partyId: number;
    identifier: string;
    name: string;
    sourceId: number;
    sourceType: number;
}

export interface Region {
    childRegionIds: any[];
    name: string;
    regionId: number;
}

export interface Party {
    abbreviation: string;
    allowAperakRequests: number;
    name: string;
    partyId: number;
}

export interface MeteringPointState {
    commentBy: string;
    commentTime: string;
    comments: string;
    endTime: string;
    meteringPointStateId: number;
    startTime: string;
    stateType: StateType;
    stateValue: string;
}

export interface StateType {
    displaySequenceNo: number;
    identifier: string;
    modifiable: number;
    mpLifeCycleStateIdentifier: string;
    mpLifecycleClassName: string;
    name: string;
    objectType: number;
    reasonCategoryClassId: number;
    reasonCategoryIdentifier: string;
    stateTypeId: number;
    usage: number;
}
export interface Customer {
    address: Address;
    id: number;
    name: string;
    customerNo: string;
}

export interface MeteringPointDetails {
    address: Address;
    customer: Customer;
    fuseSize: number;
    id: number;
    name: string;
    gsrn?: number;
    xCoordinate: string;
    yCoordinate: string;
    controlDate?: number;
    meteringPointStates: MeteringPointState[];
    party?: Party;
    phase?: number;
    region?: Region;
    remoteConnectable?: boolean;
    source?: Source;
    transformerArea?: string;
    description?: string;
    meteringPointType?: string;
    customerType: CustomerType;
    customerGroup: CustomerGroup;
    typeCurve: TypeCurve;
    parentName?: string;
    contractNo?: string;
    productName?: string;
    contractValidFrom?: number;
}
export interface CustomerType {
    classId?: number;
    identifier?: string;
    classification: Classification;
    modifiable: number;
    name: string;
}
export interface CustomerGroup {
    classId?: number;
    identifier?: string;
    classification: Classification;
    modifiable: number;
    name: string;
}
export interface TypeCurve {
    classId?: number;
    identifier?: string;
    classification: Classification;
    modifiable: number;
    name: string;
}

export interface Classification {
    classificationId: number;
    name: string;
    extensible: number;
    identifier: string;
}

export interface MeteringPointCustomProperty {
    entities: CustomProperty[];
}
