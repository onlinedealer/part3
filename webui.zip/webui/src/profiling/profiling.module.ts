import { NgModule } from '@angular/core';
import { SharedModule } from 'discovery-shared';
import { ProfileConfigureComponent } from './profile-configure/profile-configure.component';
import { ProfileListingComponent } from './profile-listing/profile-listing.component';
import { ProfilingRoutingModule } from './profiling-routing.module';
import { ProfilingRulesComponent } from './profile-configure/profiling-rules/profiling-rules.component';
import { ProfileDetailsComponent } from './profile-configure/profile-details/profile-details.component';
import { RuleConfigureComponent } from './profile-configure/profiling-rules/rule-configure/rule-configure.component';
import { ProfileResultsComponent } from './profile-results/profile-results.component';
import { HeaderResultsComponent } from './profile-results/header-results/header-results.component';
import { ResultsComponent } from './profile-results/results/results.component';
import { ProfileResultsTabComponent } from './profile-results/profile-results-tab/profile-results-tab.component';
import { DonutChartComponent } from './profile-results/charts/donut-chart/donut-chart.component';
import { TableSummaryComponent } from './profile-results/statistics/table-summary/table-summary.component';
import { StackedDonutChartComponent } from './profile-results/charts/stacked-donut-chart/stacked-donut-chart.component';
import { CharactorCategoryChartComponent } from './profile-results/charts/charactor-category-chart/charactor-category-chart.component';
import { PercentileChartComponent } from './profile-results/charts/percentile-chart/percentile-chart.component';
import { HistogramChartComponent } from './profile-results/charts/histogram-chart/histogram-chart.component';
// eslint-disable-next-line max-len
import { ProfileResultsTableStatisticsComponent } from './profile-results/profile-results-table-statistics/profile-results-table-statistics.component';
import { NumericalAnalysisComponent } from './profile-results/statistics/numerical-analysis/numerical-analysis.component';
import { StringMaxminComponent } from './profile-results/statistics/string-maxmin/string-maxmin.component';
import { TextPatternComponent } from './profile-results/statistics/text-pattern/text-pattern.component';
import { SematicAnalysisResultsComponent } from './profile-results/semantic-analysis/sematic-analysis-results.component';
import { DropdownOptionComponent } from './profile-configure/profiling-rules/rule-configure/dropdown-option/dropdown-option.component';
import { ChipsOptionComponent } from './profile-configure/profiling-rules/rule-configure/chips-option/chips-option.component';
import { SemanticTableComponent } from './profile-results/semantic-analysis/statistics/semantic-table/semantic-table.component';
// eslint-disable-next-line max-len
import { SemanticDonutChartComponent } from './profile-results/semantic-analysis/statistics/semantic-donut-chart/semantic-donut-chart.component';
// eslint-disable-next-line max-len
import { MultiSemanticInfoTableComponent } from './profile-results/semantic-analysis/statistics/multi-semantic-info-table/multi-semantic-info-table.component';
import { HistoryHeaderResultsComponent } from './profile-results/history-header-results/history-header-results.component';
import { TrendAnalysisComponent } from './profile-results/trend-analysis/trend-analysis.component';
import { EventBusService } from 'core/eventBusService';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { profilngLoader, sharedLoader } from '../core/i18n-loaders';
import { DonutCustomLegendsComponent } from './profile-results/charts/donut-custom-legends/donut-custom-legends.component';
import { TrendsTableComponent } from './profile-results/trend-analysis/trends-table/trends-table.component';
import { TrendsChartComponent } from './profile-results/trend-analysis/trends-chart/trends-chart.component';

@NgModule({
  imports: [SharedModule, ProfilingRoutingModule],
  providers: [
    EventBusService,
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'discoveryProfiling', loader: profilngLoader },
        { scope: 'discoveryShared', loader: sharedLoader }
      ]
    }
  ],
  declarations: [
    CharactorCategoryChartComponent,
    DonutChartComponent,
    HeaderResultsComponent,
    HistogramChartComponent,
    ResultsComponent,
    ProfileConfigureComponent,
    ProfileListingComponent,
    ProfileDetailsComponent,
    ProfilingRulesComponent,
    ProfileDetailsComponent,
    ProfileResultsComponent,
    ProfileResultsTabComponent,
    ProfileResultsTableStatisticsComponent,
    PercentileChartComponent,
    RuleConfigureComponent,
    SematicAnalysisResultsComponent,
    StackedDonutChartComponent,
    TableSummaryComponent,
    NumericalAnalysisComponent,
    StringMaxminComponent,
    TextPatternComponent,
    DropdownOptionComponent,
    ChipsOptionComponent,
    SemanticTableComponent,
    SemanticDonutChartComponent,
    MultiSemanticInfoTableComponent,
    HistoryHeaderResultsComponent,
    MultiSemanticInfoTableComponent,
    DonutCustomLegendsComponent,
    TrendAnalysisComponent,
    TrendsTableComponent,
    TrendsChartComponent
  ]
})
export class ProfilingModule {}
