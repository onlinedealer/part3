import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { BaseComponent } from '../../../../core/base.component';
import { SelectedTables } from '../../shared/pipeline';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { PipelinesApiService } from '../../shared/pipelines-api.service';

@Component({
  selector: 'p-connect-filters-form',
  templateUrl: './filters-form.component.html'
})
export class FiltersFormComponent extends BaseComponent implements OnInit, OnDestroy {
  /**
   * List of schemas and tables for use in the filter
   */
  @Input() schemasAndTables: SelectedTables[] = [];

  filterFormGroup: FormGroup;
  validateExpressionButton = {
    isDisabled: true,
    label: 'filters.BUTTONS.VALIDATE'
  };
  expression: any;
  filterValidationExpression: string;
  subscriptions: Subscription[] = [];

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly pipelineApiService: PipelinesApiService,
    private readonly pipelineEntityService: PipelineEntityService
  ) {
    super();
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  ngOnInit(): void {
    this.createForm();
    this.subscriptions.push(
      this.filterFormGroup.get('expression').valueChanges.subscribe((value) => {
        this.validateExpressionButton.isDisabled = !(value && value.length > 0);
      })
    );
  }

  get schemas() {
    return this.schemasAndTables?.map((obj) => obj.key);
  }

  get tables() {
    const selectedSchema = this.schemasAndTables?.find((obj) => obj.key === this.filterFormGroup.get('schema').value);
    return selectedSchema ? selectedSchema.value.tableAndKeys : [];
  }

  private createForm() {
    this.filterFormGroup = this.formBuilder.group({
      id: null,
      schema: new FormControl('', [Validators.required]),
      table: new FormControl('', [Validators.required]),
      expression: new FormControl('')
    });
  }

  validate() {
    const tableValue: string = this.filterFormGroup.get('table').value;
    const expression: string = this.filterFormGroup.get('expression').value;
    const pipelineId = this.pipelineEntityService.getPipeline().id;

    return this.pipelineApiService.validateFilter(pipelineId, tableValue, expression).subscribe({
      next: (data) => {
        this.filterValidationExpression = data.status;
      },
      error: ({ error }) => {
        this.filterValidationExpression = error.detailedMessage;
      }
    });
  }
}
