import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CatalogSchema } from '../../catalogs/shared/catalog-schema';
import { CatalogStatus } from '../../catalogs/shared/catalog-status';
import { CatalogStatusSummary } from '../../catalogs/shared/catalog-status-summary';
import { CatalogSubject } from '../../catalogs/shared/catalog-subject';
import { CatalogTopic } from '../../catalogs/shared/catalog-topic';
import { CatalogStatusComponent } from './catalog-status.component';

describe('CatalogStatusComponent', () => {
  let component: CatalogStatusComponent;
  let fixture: ComponentFixture<CatalogStatusComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CatalogStatusComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CatalogStatusComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return true if cataloging is complete', () => {
    component.catalogStatus = { status: 'complete', subjects: [{ subject: 'test1' } as CatalogSubject] } as CatalogStatus;
    expect(component.isCatalogComplete).toBe(true);
  });

  it('should return true if cataloging is complete', () => {
    component.catalogStatusSummary = { status: 'complete', subjects: { total: 1 } } as CatalogStatusSummary;
    expect(component.isCatalogComplete).toBe(true);
  });

  it('should show the correct icon', () => {
    expect(component.getStatusIcon('NOT_CATALOGED')).toEqual(['png-disabled', 'text-muted']);
    expect(component.getStatusIcon('COMPLETE')).toEqual(['png-alert-open', 'text-success']);
    expect(component.getStatusIcon('INPROGRESS')).toEqual(['png-alert-inprogress', 'text-success']);
    expect(component.getStatusIcon('OTHER')).toEqual([]);
  });

  it('should show the correct text for KAFKA', () => {
    component.connectionType = 'KAFKA';
    component.catalogStatus = { topics: [{ topic: 'test1' } as CatalogTopic] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.TOPIC');
    expect(component.getItemCount()).toBe(1);
    component.catalogStatus = { topics: [{ topic: 'test1' } as CatalogTopic, { topic: 'test2' } as CatalogTopic] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.TOPICS');
    expect(component.getItemCount()).toBe(2);
  });

  it('should show the correct text for SCHEMAREGISTRY', () => {
    component.connectionType = 'SCHEMAREGISTRY';
    component.catalogStatus = { subjects: [{ subject: 'test1' } as CatalogSubject] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.SUBJECT');
    expect(component.getItemCount()).toBe(1);
    component.catalogStatus = {
      subjects: [{ subject: 'test1' } as CatalogSubject, { subject: 'test2' } as CatalogSubject]
    } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.SUBJECTS');
    expect(component.getItemCount()).toBe(2);
  });

  it('should show the correct text for DB2', () => {
    component.connectionType = 'DB2';
    component.catalogStatus = { schemas: [{ schema: 'test1' } as CatalogSchema] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.LIBRARY');
    expect(component.getItemCount()).toBe(1);
    component.catalogStatus = { schemas: [{ schema: 'test1' } as CatalogSchema, { schema: 'test2' } as CatalogSchema] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.LIBRARIES');
    expect(component.getItemCount()).toBe(2);
  });

  it('should show the correct text for Oracle', () => {
    component.connectionType = 'ORACLE';
    component.catalogStatus = { schemas: [{ schema: 'test1' } as CatalogSchema] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.SCHEMA');
    expect(component.getItemCount()).toBe(1);
    component.catalogStatus = { schemas: [{ schema: 'test1' } as CatalogSchema, { schema: 'test2' } as CatalogSchema] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.SCHEMAS');
    expect(component.getItemCount()).toBe(2);
  });

  it('should get correct ORACLE item count for catalog status summary ', () => {
    component.connectionType = 'ORACLE';
    component.catalogStatusSummary = { schemas: { total: 1 } } as CatalogStatusSummary;
    expect(component.getItemCount()).toBe(1);
  });

  it('should return 0 from SCHEMAREGISTRY item count by default for schema registry', () => {
    component.connectionType = 'ORACLE';
    component.catalogStatusSummary = null;
    component.catalogStatus = null;
    expect(component.getItemCount()).toBe(0);
  });

  it('should get correct KAFKA item count for catalog status summary', () => {
    component.connectionType = 'KAFKA';
    component.catalogStatusSummary = { topics: { total: 1 } } as CatalogStatusSummary;
    expect(component.getItemCount()).toBe(1);
  });

  it('should return 0 from SCHEMAREGISTRY item count by default for schema registry', () => {
    component.connectionType = 'KAFKA';
    component.catalogStatusSummary = null;
    component.catalogStatus = null;
    expect(component.getItemCount()).toBe(0);
  });

  it('should get correct SCHEMAREGISTRY item count for catalog status summary', () => {
    component.connectionType = 'SCHEMAREGISTRY';
    component.catalogStatusSummary = { subjects: { total: 1 } } as CatalogStatusSummary;
    expect(component.getItemCount()).toBe(1);
  });

  it('should return 0 from SCHEMAREGISTRY item count by default for schema registry', () => {
    component.connectionType = 'SCHEMAREGISTRY';
    component.catalogStatusSummary = null;
    component.catalogStatus = null;
    expect(component.getItemCount()).toBe(0);
  });

  it('should return translated catalog status from catalogStatus object', () => {
    const catalogStatus = {
      status: 'complete'
    };
    expect(component.getTranslatedCatalogStatus(catalogStatus, {}, 'abc')).toBe(
      'connections.CATALOG_STATUS.' + catalogStatus.status.toUpperCase() + 'abc'
    );
  });

  it('should return translated catalog status from catalogStatusSummary object', () => {
    const catalogStatusSummary = {
      status: 'complete'
    };
    expect(component.getTranslatedCatalogStatus({}, catalogStatusSummary, 'abc')).toBe(
      'connections.CATALOG_STATUS.' + catalogStatusSummary.status.toUpperCase() + 'abc'
    );
  });
  it('should show the correct text for SQLSERVER', () => {
    component.connectionType = 'SQLSERVER';
    component.catalogStatus = { schemas: [{ schema: 'test1' } as CatalogSchema] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.DATABASE');
    expect(component.getItemCount()).toBe(1);
    component.catalogStatus = { schemas: [{ schema: 'test1' } as CatalogSchema, { schema: 'test2' } as CatalogSchema] } as CatalogStatus;
    expect(component.getItemLabel()).toBe('connections.CATALOG_STATUS.ITEM_TYPES.DATABASES');
    expect(component.getItemCount()).toBe(2);
  });
});
