import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { ChangeTableMappingComponent } from '../change-table-mapping.component';
import { ChangeTableMappingSidebarComponent } from './change-table-mapping-sidebar.component';

@Component({
  selector: 'p-connect-change-table-mapping',
  template: '',
  providers: [
    {
      provide: ChangeTableMappingComponent,
      useClass: MockChangeTableMappingComponent
    }
  ]
})
class MockChangeTableMappingComponent {
  onApply() {}
  getPrimaryObject() {}
}

describe('ChangeTableMappingSidebarComponent', () => {
  let component: ChangeTableMappingSidebarComponent;
  let fixture: ComponentFixture<ChangeTableMappingSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ChangeTableMappingSidebarComponent, MockChangeTableMappingComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeTableMappingSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    component.sidebarComponent = jasmine.createSpyObj<SidebarComponent>(['open', 'close']);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger sidebar open method', () => {
    component.open();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should trigger sidebar close method', () => {
    component.cancelSidebarButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should pass apply button details to child', () => {
    spyOn(component.changeTableMapping, 'getPrimaryObject');
    component.ngAfterViewInit();
    expect(component.changeTableMapping.getPrimaryObject).toHaveBeenCalledWith(component.applyButton);
  });

  it('should trigger onApply method', () => {
    spyOn(component.changeTableMapping, 'onApply');
    component.onApplyClicked();
    expect(component.changeTableMapping.onApply).toHaveBeenCalled();
  });
});
