import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { MockSidebarComponent } from '../../../../../shared/components/sidebar/mock-sidebar.component.spec';
import { LogReader } from '../../shared/logreader';
import { LogReaderConfigurationFormComponent } from '../logreader-configuration-form/logreader-configuration-form.component';
import { LogReaderConfigurationSidebarComponent } from './logreader-configuration-sidebar.component';

describe('LogReaderConfigurationSidebarComponent', () => {
  let component: LogReaderConfigurationSidebarComponent;
  let fixture: ComponentFixture<LogReaderConfigurationSidebarComponent>;

  @Component({
    selector: 'p-connect-logreader-configuration-form',
    template: '',
    providers: [
      {
        provide: LogReaderConfigurationFormComponent,
        useClass: MockLogReaderConfigurationFormComponent
      }
    ]
  })
  class MockLogReaderConfigurationFormComponent {
    close() {}
    open() {}
  }

  const mockLogReaders = [
    {
      type: 'logReader',
      dataConnectionId: '1',
      journalName: 'SCHEMA/JOURNAL',
      logReaderId: '1',
      name: 'LGNAME1'
    } as LogReader
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, getTranslocoModule(), HttpClientTestingModule],
      declarations: [LogReaderConfigurationSidebarComponent, MockLogReaderConfigurationFormComponent, MockSidebarComponent],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'logreaders' } }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogReaderConfigurationSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close sidebar when close button is clicked', () => {
    const closeSpyForm = spyOn(component.logReaderFormComponent, 'close');
    const closeSpySidebar = spyOn(component.sidebarComponent, 'close');
    component.open(mockLogReaders);
    component.cancelSidebarButtonClicked();
    expect(closeSpyForm).toHaveBeenCalled();
    expect(closeSpySidebar).toHaveBeenCalled();
  });
});
