import { ProfileListConnectionModel, ScheduleConfigModel } from 'discovery-core';
import { AlertLevelCountModel } from './alert-level-count.model';

export class ObserverListModel {
  observableId: string;
  name: string;
  runSuggestion: boolean;
  connection: ProfileListConnectionModel;
  status: string;
  runByUser: string;
  createdBy: string;
  resourceConnectionName: string;
  resourceConnectionType: string;
  scheduleConfig: ScheduleConfigModel;
  alertCounts: AlertLevelCountModel;
  profileId: string;
  lastProfileRunDetails?: any;
}
