
import React from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Helmet } from 'react-helmet'
import HeaderTitle from '../Header/HeaderTitle'
import Dashboard from './Dashboard'
import { getGrouperList, deleteGroup, closeSnackBar, deleteGroupMultiple, getGrouperTypes, updateGroupListRequestParams, getStatusList } from '../../store/Dashboard/actionCreator'
import { clearGroupDetails } from '../../store/GroupDetails/actionCreator'

export class DashboardContainer extends React.Component {
  componentDidMount () {
    if (this.props.grouperList.length === 0) {
      this.props.getGrouperList(this.props.groupListRequestParams)
    }
    if (this.props.groupTypes.length === 0) {
      this.props.getGrouperTypes()
      this.props.getStatusList()
    }
    this.props.closeSnackBar()
    this.props.clearGroupDetails()
  }

  componentWillReceiveProps (nextProps) {
    if (Object.keys(nextProps.variationPage1Data).length > 0) {
      const detailLink = '/variationPage2'
      nextProps.history.push(detailLink)
    }
  }

  render () {
    const { headerTitle } = this.props
    return (
      <div>
        <HeaderTitle title="Group Details" />
        <Helmet>
          <title>{headerTitle}</title>
        </Helmet>
        <Dashboard
          auth={this.props.auth}
          grouperList={this.props.grouperList}
          snackbarMessage={this.props.snackbarMessage}
          getGrouperList={this.props.getGrouperList}
          deleteGroup={this.props.deleteGroup}
          closeSnackBar={this.props.closeSnackBar}
          loadingBtnStatus={this.props.loadingBtnStatus}
          deleteGroupMultiple={this.props.deleteGroupMultiple}
          history={this.props.history}
          groupTypes={this.props.groupTypes}
          groupListRequestParams={this.props.groupListRequestParams}
          updateGroupListRequestParams={this.props.updateGroupListRequestParams}
          statusList={this.props.statusList}
        />
      </div>
    )
  }
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getGrouperList,
    deleteGroup,
    closeSnackBar,
    deleteGroupMultiple,
    getGrouperTypes,
    clearGroupDetails,
    updateGroupListRequestParams,
    getStatusList,
  }, dispatch)

const mapStateToProps = state => ({
  auth: state.get('auth').toJS(),
  grouperList: state.getIn(['grouperDashboard', 'grouperList']).toJS(),
  snackbarMessage: state.getIn(['grouperDashboard', 'snackbarMessage']).toJS(),
  headerTitle: state.getIn(['layout', 'headerTitle']),
  loadingBtnStatus: state.getIn(['Snackbar', 'loadingBtnStatus']).toJS(),
  groupTypes: state.getIn(['grouperDashboard', 'groupTypes']).toJS(),
  variationPage1Data: state.getIn(['grouperDashboard', 'variationPage1Data']).toJS(),
  groupListRequestParams: state.getIn(['grouperDashboard', 'groupListRequestParams']).toJS(),
  statusList: state.getIn(['grouperDashboard', 'statusList']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(DashboardContainer)
