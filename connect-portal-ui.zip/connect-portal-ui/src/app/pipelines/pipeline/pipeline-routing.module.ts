import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PipelineDataComponent } from './data/pipeline-data.component';
import { FiltersComponent } from './filters/filters.component';
import { PipelineFinalizeComponent } from './finalize/pipeline-finalize.component';
import { PipelineGeneralComponent } from './general/pipeline-general.component';
import { PipelineMappingComponent } from './mapping/pipeline-mapping.component';
import { PipelineComponent } from './pipeline.component';

const routes: Routes = [
  {
    path: '',
    component: PipelineComponent,
    children: [
      {
        path: '',
        redirectTo: 'general'
      },
      {
        path: 'general',
        component: PipelineGeneralComponent
      },
      {
        path: 'connections',
        loadChildren: () => import('./connections/pipeline-connections.module').then((m) => m.PipelineConnectionsModule)
      },
      {
        path: 'data',
        component: PipelineDataComponent
      },
      {
        path: 'mapping',
        component: PipelineMappingComponent
      },
      {
        path: 'filters',
        component: FiltersComponent
      },
      {
        path: 'finalize',
        component: PipelineFinalizeComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PipelineRoutingModule {}
