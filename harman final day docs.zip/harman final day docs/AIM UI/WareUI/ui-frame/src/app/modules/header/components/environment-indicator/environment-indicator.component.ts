import { Component, Input } from "@angular/core";

@Component({
    selector: "landisgyr-environment-indicator",
    templateUrl: "./environment-indicator.component.html",
    styleUrls: ["./environment-indicator.component.scss"]
})
export class EnvironmentIndicatorComponent {
    constructor() {}
    @Input() text!: string;

    @Input()
    environmentTextColor!: string;

    @Input()
    environmentIndicatorBackgroundColor!: string;
}
