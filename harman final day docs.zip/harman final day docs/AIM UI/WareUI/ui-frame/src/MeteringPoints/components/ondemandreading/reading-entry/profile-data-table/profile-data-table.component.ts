import { Component, Input, EventEmitter, Output, ChangeDetectionStrategy } from "@angular/core";
import { slideCloseOpenAnimation } from "../../../../../Shared/Animations/slide-close-open.animation";
import { OnDemandReadingRequestResult } from "../../../../models/ondemandreading.model";

export interface ProfileDataGroup {
    id: number;
    name: string;
    meteringMeasuredUnitName: string;
    meterings: OnDemandReadingRequestResult[];
    groupIsVisible: boolean;
    groupIsCreated?: boolean;
    dateRangeString: string;
    linkTitle: string;
}
@Component({
    selector: "landisgyr-profile-data-table",
    templateUrl: "./profile-data-table.component.html",
    styleUrls: ["./profile-data-table.component.scss"],
    animations: slideCloseOpenAnimation(),
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ProfileDataTableComponent {
    @Input()
    dataGroups: ProfileDataGroup[] | undefined;

    @Input()
    useColumns!: any[];
    @Input()
    valueStart: any;
    @Input()
    valueEnd: any;
    @Input() userDefinedStartTime!: number;
    @Input() userDefinedEndTime!: number;
    @Output()
    navigateDetails = new EventEmitter<ProfileDataGroup>();
    @Output()
    groupVisibilityChanges = new EventEmitter<ProfileDataGroup>();

    trackByFn(index: number, dataGroup: ProfileDataGroup) {
        return dataGroup.name;
    }

    toggleContent(dataGroup: ProfileDataGroup) {
        this.groupVisibilityChanges.emit({
            ...dataGroup,
            groupIsVisible: !dataGroup.groupIsVisible,
            groupIsCreated: true
        });
    }

    navigateToDetails(dataGroup: ProfileDataGroup) {
        this.navigateDetails.emit(dataGroup);
    }
}
