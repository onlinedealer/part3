import { DatadriftConfidenceModel } from './data-drift-confidence.model';

export class DatadriftConfigureModel {
  confidence: DatadriftConfidenceModel;

  constructor() {
    this.confidence = new DatadriftConfidenceModel();
  }
}
