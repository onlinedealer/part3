import reducer, { initialState } from '../reducer'
import { fromJS } from 'immutable'
import _ from 'lodash'
import {
  GET_MAINTENANCE_DETAILS,
  GET_ITEMS,
  SERVICE_FAIL,
  TOGGLE_LOADING,
  SAVE_ITEMS,
  SAVE_FAIL,
  CANCEL_UPDATE,
  UPDATE_MODE,
} from '../actionType'

const getListItems = () => {
  return ([
    {
      'tcin': 47029874,
      'dpci': '049-00-0002',
      'barcode': '490490000022',
      'product_title': 'OLAY SAMPLE COLLECTION',
      'attribute': 'cost',
      'old_value': [
        '3.0',
      ],
      'new_value': null,
      'vendor_id': '3872918',
      'vos_id': '172257210',
    },
  ])
}

const mockPayload = {
  'item_list': [
    {
      'tcin': 47029874,
      'dpci': '049-00-0002',
      'barcode': '490490000022',
      'product_title': 'OLAY SAMPLE COLLECTION',
      'attribute': 'cost',
      'old_value': [
        '3.0',
      ],
      'new_value': null,
      'vendor_id': '3872918',
      'vos_id': '172257210',
    }],
  'common_field': {
    'jira_id': 'CR-1234',
    'maintenance_type': 'Cost',
  },
  'column_info': [
    {
      'column_id': 'tcin',
      'column_name': 'TCIN',
      'editable': false,
      'field_type': 'Number',
      'values': null,
      'send_in_response': true,
      'multivalue': false,
      'filterable': false,
    }],
  'grid_text': {},
  'errors': [{
    'tcin': 222222,
    'message': 'Invalid Tcin',
  }],
}

describe('rule details reducer', () => {
  it('returns the initial state', () => {
    expect(
      reducer(undefined, {})
    ).toEqual(initialState)
  })

  it('GET_MAINTENANCE_DETAILS adds the new state to the state', () => {
    const mockMaintenanceDetails = [
      {
        'maintenance_type': 'Cost',
        'maintenance_options': [
          {
            'option_name': 'Process Tcin Dpci List',
            'display_text': 'Please enter the list of Tcins / Dpcis in the field below',
            'service_name': 'processTcinDpciList',
            'grid_required': true,
          },
          {
            'option_name': 'Excel Upload',
            'display_text': 'Upload excel file based on downloaded template',
            'template': ['tcin_dpci', 'new_cost'],
            'service_name': 'processExcelUpload',
            'grid_required': true,
          },
        ],
      }]
    const initial = initialState.toJS()
    initial['maintenanceDetails'] = fromJS(mockMaintenanceDetails)
    expect(reducer(fromJS({}), {
      type: GET_MAINTENANCE_DETAILS,
      data: mockMaintenanceDetails,
    })).toEqual(fromJS(initial))
  })

  it('GET_ITEMS adds the new state to the state', () => {
    const listSendFields = _.groupBy(mockPayload.column_info, function (obj) { return obj.send_in_response }).true
    const listSendFieldsArray = listSendFields.map((fieldObj) => {
      return fieldObj.column_id
    })
    const getLoadingInfo = {
      status: false,
      message: '',
    }
    const mode = 'paste box'
    const submitMessage = {
      type: 'success',
      message: '1 Item loaded successfully from ' + mode + '.',
      variant: 'success',
    }
    const stateUpdate = fromJS({
      listItems: getListItems(),
      columnInfo: mockPayload.column_info,
      commonFields: mockPayload.common_field,
      errorItems: mockPayload.errors,
      sendToResponse: listSendFieldsArray,
      listStatus: true,
      submitStatus: true,
      loadingInfo: getLoadingInfo,
      submitMessage: submitMessage,
      gridText: {},
    })
    expect(reducer(fromJS({}), {
      type: GET_ITEMS,
      data: mockPayload,
      mode: mode,
    })).toEqual(stateUpdate)
  })

  it('SERVICE_FAIL adds the new state to the state', () => {
    const failureExcelUpload = {'type': 'failure', 'message': 'service failed', 'variant': 'error'}
    const initial = initialState.toJS()
    initial['submitStatus'] = true
    initial['submitMessage'] = failureExcelUpload
    initial['maintenanceDetails'] = undefined
    expect(reducer(fromJS({}), {
      type: SERVICE_FAIL,
      message: 'service failed',
      variant: 'error',
    })).toEqual(fromJS(initial))
  })

  it('TOGGLE_LOADING adds the new state to the state', () => {
    const loadingInfo = {
      status: true,
      message: 'Loading',
    }
    const initial = initialState.toJS()
    initial['loadingInfo'] = loadingInfo
    initial['maintenanceDetails'] = undefined
    expect(reducer(fromJS({}), {
      type: TOGGLE_LOADING,
      status: true,
      message: 'Loading',
    })).toEqual(fromJS(initial))
  })

  it('SAVE_ITEMS adds the new state to the state', () => {
    const successSubmitMessage = { 'type': 'success', 'message': 'success saved', 'variant': 'success' }
    const initial = initialState.toJS()
    initial['submitStatus'] = true
    initial['submitMessage'] = successSubmitMessage
    initial['maintenanceDetails'] = undefined
    expect(reducer(fromJS({}), {
      type: SAVE_ITEMS,
      data: { message: 'success saved', variant: 'error' },
    })).toEqual(fromJS(initial))
  })

  it('SAVE_FAIL adds the new state to the state', () => {
    const failureSubmitMessage = { 'type': 'failure', 'message': 'failed saved', 'variant': 'error' }
    const initialFail = initialState.toJS()
    initialFail['submitStatus'] = true
    initialFail['submitMessage'] = failureSubmitMessage
    initialFail['maintenanceDetails'] = undefined
    expect(reducer(fromJS({}), {
      type: SAVE_FAIL,
      message: 'failed saved',
      variant: 'error',
    })).toEqual(fromJS(initialFail))
  })

  it('CANCEL_UPDATE adds the new state to the state', () => {
    const initial = initialState.toJS()
    initial['maintenanceDetails'] = undefined
    expect(reducer(fromJS({}), {
      type: CANCEL_UPDATE,
    })).toEqual(fromJS(initial))
  })

  it('UPDATE_MODE adds the new state to the state', () => {
    const initial = initialState.toJS()
    initial['updateMode'] = 'tcins'
    initial['maintenanceDetails'] = undefined
    expect(reducer(fromJS({}), {
      type: UPDATE_MODE,
      updateMode: 'tcins',
    })).toEqual(fromJS(initial))
  })
})
