(function() {
    'use strict';

    widget.controller("editCtrl", ['$scope', 'uiRouters', '$state', '$rootScope', 'ajaxFactory', editCtrl]);

    function editCtrl($scope, uiRouters, $state, $rootScope, ajaxFactory) {

        $scope.disableRegBtn = true;
        $scope.disableSaveBtn = false;
        $scope.propertyValues = 1;

    	 function generateUUID() {
            var d = new Date().getTime();
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });
            return uuid;
        };
       
        if (ajaxFactory.getEditDataToSave() !== undefined) {
            var data = [];
            data = ajaxFactory.getEditDataToSave();
            $scope.user = data;            
            $scope.disableSaveBtn = true;
            $scope.disableRegBtn = false;
        };

    	$scope.register = function(){
    		var id = generateUUID();
    		$scope.user["id"] = id;
    		localStorage.setItem(id, JSON.stringify($scope.user));
            $state.go('home')
            ajaxFactory.setData($scope.user);
            ajaxFactory.deleteEditDataToSave()
    	}
    	$scope.editme = function(){
    		var id = '0f5a0884-c352-4a64-b977-bd575d385cf7';
    		$scope.user["id"] = id;
    		$scope.user.widgetName = "bharath";
            $scope.register();
            $state.go('home');
    		localStorage.setItem(id, angular.toJson($scope.user));
    	}

        $scope.saveLocal = function(){
            var id = ajaxFactory.getEditDataToSave().id;
            localStorage.setItem(id, angular.toJson($scope.user));
            $state.go('home');
            ajaxFactory.deleteEditDataToSave();
        };
    }
})();