(function () {
    'use strict';

    angular.module('arm', [
      'ionic',
      'ngCordova',
      'arm.config',
      'LocalStorageModule',
      'pascalprecht.translate',
      'ion-datetime-picker'

    ])
      .run(function ($ionicPlatform, sqliteService, $ionicPopup,$rootScope,$cordovaDialogs,ALERT_MESSAGE) {
          $ionicPlatform.ready(function () {
              if (cordova.platformId === 'ios' && window.cordova && window.cordova.plugins.Keyboard) {
                  // Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
                  // for form inputs)
                  cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);

                  // Don't remove this line unless you know what you are doing. It stops the viewport
                  // from snapping when text inputs are focused. Ionic handles this internally for
                  // a much nicer keyboard experience.
                  cordova.plugins.Keyboard.disableScroll(true);

              }
              if (window.StatusBar) {
                  StatusBar.styleDefault();
              }
              //sqliteService.init();
              /*
               title: "Internet Disconnected",
                          subTitle: "The internet is disconnected on your device.",
                          buttons: [{ text: 'Close' }]
              */

			if (window.Connection) {

			                  if (navigator.connection.type == Connection.NONE) {
			                        ////console.log('app is offline');
			                        $rootScope.isNetworkAvailable = false;

			                   }else{
			                   		$rootScope.isNetworkAvailable = true;
			                        ////console.log('app is online');
			                   }

			                   window.addEventListener("online", function(e) {
			                   		$rootScope.isNetworkAvailable = true;
			                        ////console.log('app is online');

			                   }, false);

			                   window.addEventListener("offline", function(e) {
			                   		$rootScope.isNetworkAvailable = false;
			                        ////console.log('app is offline');
			                        $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                   .then(function () {
                					});

			                   }, false);
			              }
			          });
           $rootScope.$on('$stateChangeSuccess', function(event, to, toParams, from, fromParams) {
              //save the previous state in a rootScope variable so that it's accessible from everywhere
              $rootScope.previousState = from;
              $rootScope.previousStateParm = fromParams;
          });
      })

    //.config(['$httpProvider', function ($httpProvider) {
    //    $httpProvider.defaults.useXDomain = true;
    //    delete $httpProvider.defaults.headers.common['X-Requested-With'];
    //}
    //])
    // Fix for platform-specific URL prefixing.
    .config([
        '$compileProvider',
        function ($compileProvider) {
            $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|ghttps?|ms-appx|x-wmapp0):/);
            // Use $compileProvider.urlSanitizationWhitelist(...) for Angular 1.2
            $compileProvider.imgSrcSanitizationWhitelist(/^\s*(https?|ftp|file|ms-appx|x-wmapp0):|data:image\//);
        }
    ])
    .config(function ($stateProvider, $urlRouterProvider, $ionicConfigProvider, PATH, $translateProvider) {

        // Register a loader for the static files
        // So, the module will search missing translation tables under the specified urls.
        // Those urls are [prefix][langKey][suffix].
        $translateProvider.useStaticFilesLoader({
            prefix: 'translate/',
            suffix: '.json'
        });

        // Tell the module what language to use by default
        $translateProvider.preferredLanguage('en');

        // Ionic uses AngularUI Router which uses the concept of states
        // Learn more here: https://github.com/angular-ui/ui-router
        // Set up the various states which the app can be in.
        // Each state's controller can be found in controllers.js
        $ionicConfigProvider.tabs.position('bottom');
        $ionicConfigProvider.views.swipeBackEnabled(false);
        $stateProvider
            // setup an abstract state for the tabs directive
	    .state('tab', {
	        url: '/tab',
	        abstract: true,
	        templateUrl: PATH.VIEW + 'layout/tabs.html',
	        controller: "tabCtrl"
	    })
        // setup an abstract state for the tabs directive
       	.state('start', {
       	    url: "/start",
       	    abstract: true,
       	    templateUrl: PATH.VIEW + 'layout/startLayout.html',
       	})
		.state('signin', {
		    url: "/signin",
		    cache: false,
		    templateUrl: PATH.VIEW + 'authentication/signin.html',
		    controller: 'signinCtrl'
		})
		.state('forgot', {
		    url: "/forgot",
		    templateUrl: PATH.VIEW + "authentication/forgot.html",
		    controller: 'forgotController'
		})
		.state('tab.home', {
		    url: '/home',
		    cache: false,
		    views: {
		        'tab-home': {
		            templateUrl: PATH.VIEW + 'home/home.html',
		            controller: 'homeCtrl'
		        }
		    }
		})
		.state('tab.dashboardGraph', {
  		    url: '/dashboardGraph',
  		    cache: false,
  		    views: {
  		        'tab-home': {
  		            templateUrl: PATH.VIEW + 'dashboard/dashboardGraph.html',
  		            controller: 'dashboardGraphCtrl'
  		        }
  		    }
  		})

		.state('tab.contact', {
		    url: '/contact',
		    cache: false,
		    views: {
		        'tab-contact': {
		            templateUrl: PATH.VIEW + 'contact/contacts.html',
		            controller: 'contactListCtrl'
		        }
		    }
		})
		.state('tab.contactGraph', {
        		    url: '/contactGraph',
        		    views: {
        		        'tab-contact': {
        		            templateUrl: PATH.VIEW + 'contact/contactGraph.html',
        		            controller: 'contactGraphCtrl'
        		        }
        		    }
        })
        .state('tab.contactNote', {
                    url: '/contactNote',
                    views: {
                        'tab-contact': {
                            templateUrl: PATH.VIEW + 'contact/contactNote.html',
                            controller: 'contactNoteCtrl'
                        }
                    }
        })
		.state('tab.contactAdd', {
		    url: '/contactAdd/:editModeFlag',
		    cache: false,
		    views: {
		        'tab-contact': {
		            templateUrl: PATH.VIEW + 'contact/contactAdd.html',
		            controller: 'contactAddCtrl'
		        }
		    }
		})
        .state('tab.contactDetails', {
            url: '/contactDetails',
            cache: false,
            views: {
                'tab-contact': {
                    templateUrl: PATH.VIEW + 'contact/contactDetail.html',
                    controller: 'contactDetailsCtrl'
                }
            }
        })
        .state('tab.repreContactDetails', {
            url: '/repreContactDetails',
            cache: false,
            views: {
                'tab-contact': {
                    templateUrl: PATH.VIEW + 'contact/representativeContactDetail.html',
                    controller: 'contactDetailsCtrl'
                }
            }
        })
		.state('tab.deal', {
		    url: '/deal',
		    cache: false,
		    views: {
		        'tab-deals': {
		            templateUrl: PATH.VIEW + 'deal/dealList.html',
		            controller: 'dealCtrl'
		        }
		    }
		})
		.state('tab.dealDetail', {
		    url: '/deal/:dealsId',
		    cache: false,
		    views: {
		        'tab-deals': {
		            templateUrl: PATH.VIEW + 'deal/dealDetail.html',
		            controller: 'dealDetailCtrl'
		        }
		    }
		})
		.state('tab.dealAdd', {
		    url: '/dealAdd/:dealId/:editModeFlag',
		    cache: false,
		    views: {
		        'tab-deals': {
		            templateUrl: PATH.VIEW + 'deal/dealAdd.html',
		            controller: 'dealAddCtrl'
		        }
		    }
		})
		.state('tab.activity', {
		    url: '/activity',
		    cache: false,
		    views: {
		        'tab-activities': {
		            templateUrl: PATH.VIEW + 'activity/activityList.html',
		            controller: 'activityListCtrl'
		        }
		    }
		})
		.state('tab.activityDetail', {
		    url: '/activities/:activitiesId',
		    cache: false,
		    views: {
		        'tab-activities': {
		            templateUrl: PATH.VIEW + 'activity/activityDetail.html',
		            controller: 'activityDetailCtrl'
		        }
		    }
		})
		.state('tab.activityAdd', {
		    url: '/activityAdd/:actId/:editModeFlag/:screenType',
		    cache: false,
		    views: {
		        'tab-activities': {
		            templateUrl: PATH.VIEW + 'activity/activityAdd.html',
		            controller: 'activityAddCtrl'
		        }
		    }
	    })
        .state('tab.activityHappen', {
            url: '/activityHappen/:devObjId/:actStatgeType/:screenType/:actType',
            cache: false,
            views: {
                'tab-more': {
                    templateUrl: PATH.VIEW + 'activity/activityWhathappen.html',
                    controller: 'activityHappenCntrl'
                }
            }
        })
  		.state('tab.conversationList', {
  		    url: '/conversationList',
  		    views: {
  		        'tab-more': {
  		            templateUrl: PATH.VIEW + 'messages/conversationList.html',
  		            controller: 'conversationListCtrl'
  		        }
  		    }
  		})
  		.state('tab.conversationDetail', {
  		    url: '/conversationList/:messageId',
  		    views: {
  		        'tab-more': {
  		            templateUrl: PATH.VIEW + 'messages/conversationDetail.html',
  		            controller: 'conversationDetailCtrl'
  		        }
  		    }
  		})
      .state('tab.conversationParticipantList', {
              url: '/conversationParticipantList',
              views: {
                  'tab-more': {
                      templateUrl: PATH.VIEW + 'messages/conversationParticipantList.html',
                      controller: 'conversationParticipantList'
                  }
              }
          })
        .state('tab.product', {
               url: '/product',
               cache: false,
               views: {
               'tab-more': {
               templateUrl: PATH.VIEW + 'product/product.html',
                  controller: 'productCtrl'
               }
               }
        })

       .state('tab.productDetail', {
              url: '/product/:productId',
              cache: false,
              views: {
              'tab-more': {
              templateUrl: PATH.VIEW + 'product/productDetail.html',
              controller: 'productDetailCtrl'
              }
            }
       })


		.state('tab.addNotes', {
		    url: '/addNotes',
		    views: {
		        'tab-contact': {
		            //templateUrl: PATH.VIEW + 'contacts/addNotes.html',
		            //controller: 'addNotesController'
		        }
		    }
		})

        .state('tab.calculator', {
          url: '/calculator',
          views: {
              'tab-more': {
                  templateUrl: PATH.VIEW + 'calculator/calculator.html',
                  controller: 'calculatorController'
              }
          }
        })
        .state('tab.smecalculator', {
          url: '/smecalculator',
          views: {
              'tab-more': {
                  templateUrl: PATH.VIEW + 'calculator/smecalculator.html',
                  controller: 'calculatorController'
              }
          }
        })
        // if none of the above states are matched, use this as the fallback
        //$urlRouterProvider.otherwise('/tab/dash');
        $urlRouterProvider.otherwise('/signin');
    });
})();
