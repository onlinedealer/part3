import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { ResourcePermissionService } from '@shared/services/resource-permission.service';
import { of, throwError } from 'rxjs';
import { environment } from '../../environments/environment';
import { getTranslocoModule } from '../core/transloco-testing.module';
import { AgentSidebarComponent } from './agent-sidebar/agent-sidebar.component';

import { AgentsComponent } from './agents.component';
import { Agent } from './shared/agent';
import { AgentsApiService } from './shared/agents-api.service';

describe('AgentsComponent', () => {
  let component: AgentsComponent;
  let fixture: ComponentFixture<AgentsComponent>;
  let agentsService: AgentsApiService;

  @Component({
    selector: 'p-connect-agent-sidebar',
    template: '',
    providers: [
      {
        provide: AgentSidebarComponent,
        useClass: MockAgentSidebarComponent
      }
    ]
  })
  class MockAgentSidebarComponent {
    setAgent() {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'agents' } }],
      declarations: [AgentsComponent, MockAgentSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentsComponent);
    component = fixture.componentInstance;
    agentsService = TestBed.inject(AgentsApiService);
    spyOn(agentsService, 'getAll').and.returnValue(of([{ agentId: '1', name: 'test' }]));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the sidebar component to edit an agent when menu item clicked', () => {
    spyOn(component.agentSidebarComponent, 'setAgent').and.returnValue();
    component.actionDropdownMenuItems[0].command({ item: { target: {} } });
    expect(component.isAgentSidebarVisible).toBe(true);
    expect(component.agentSidebarComponent.setAgent).toHaveBeenCalled();
  });

  describe('delete agent', () => {
    it('should open delete dialog to remove agent', () => {
      component.actionDropdownMenuItems[1].command({ item: { target: {} } });
      expect(component.deleteSidebarConfiguration.isSidebarVisible).toBe(true);
    });

    it('should open delete dialog to remove agent', () => {
      component.actionDropdownMenuItems[1].command({ item: { target: { agentUpOrDownStatus: 'up' } } });
      expect(component.deleteSidebarConfiguration.isSidebarVisible).toBe(true);
      expect(component.deleteSidebarConfiguration.bodyText).toBe('agents.REMOVE_AGENT_DIALOG.MESSAGE_AGENT_ACTIVE');
    });

    it('should handle deleting a agent', () => {
      spyOn(component.deleteCompleted, 'next').and.returnValue();
      spyOn(agentsService, 'deleteAgent').and.returnValue(of({}));
      component.deleteSidebarConfiguration.deleteButtonClicked([{ tenantId: '1', productName: 'test', agentId: '1234' } as Agent]);
      expect(component.deleteCompleted.next).toHaveBeenCalled();
    });

    it('should handle an error when deleting a agent', () => {
      spyOn(component.deleteCompleted, 'next').and.returnValue();
      spyOn(agentsService, 'deleteAgent').and.returnValue(throwError({}));
      component.deleteSidebarConfiguration.deleteButtonClicked([{ tenantId: '1', productName: 'test', agentId: '1234' } as Agent]);
      expect(component.deleteCompleted.next).toHaveBeenCalled();
    });
  });

  it('should open url for downloading an agent', () => {
    spyOn(window, 'open');
    component.tableConfiguration.createButtonClicked();
    expect(window.open).toHaveBeenCalledWith(environment.agentDownloadURL, '_self');
  });

  it('should handle auto refreshing', () => {
    component.tableConfiguration.autoRefreshTimeElapsedEvent();
    expect(agentsService.getAll).toHaveBeenCalled();
  });
});
