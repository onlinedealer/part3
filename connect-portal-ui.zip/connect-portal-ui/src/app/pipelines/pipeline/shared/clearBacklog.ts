export interface ClearBacklogRequest {
  dataFlowName: string;
  projectId: string;
  forceDelete: boolean;
}
