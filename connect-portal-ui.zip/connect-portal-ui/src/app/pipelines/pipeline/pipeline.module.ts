import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CheckboxModule } from 'primeng/checkbox';
import { DividerModule } from 'primeng/divider';
import { DropdownModule } from 'primeng/dropdown';
import { ListboxModule } from 'primeng/listbox';
import { ProgressSpinnerModule } from 'primeng/progressspinner';
import { RadioButtonModule } from 'primeng/radiobutton';
import { TableModule } from 'primeng/table';
import { ToggleButtonModule } from 'primeng/togglebutton';
import { TooltipModule } from 'primeng/tooltip';
import { CatalogsModule } from '../../connections/catalogs/catalogs.module';
import { MetabasesModule } from '../../metabases/metabases.module';
import { TabViewModule } from 'primeng/tabview';
import { InputSwitchModule } from 'primeng/inputswitch';
import { SharedModule } from '../../shared/shared.module';
import { PipelinesSharedModule } from '../shared/pipelines-shared.module';
import { ExcludeusersFormComponent } from './data/logreaders/excludeusers-form/excludeusers-form.component';
import { ExcludeusersSidebarComponent } from './data/logreaders/excludeusers-sidebar/excludeusers-sidebar.component';
import { LogReaderConfigurationFormComponent } from './data/logreaders/logreader-configuration-form/logreader-configuration-form.component';
import { LogReaderConfigurationSidebarComponent } from './data/logreaders/logreader-configuration-sidebar/logreader-configuration-sidebar.component';
import { LogReaderFormComponent } from './data/logreaders/logreader-form/logreader-form.component';
import { LogReaderSidebarComponent } from './data/logreaders/logreader-sidebar/logreader-sidebar.component';
import { PipelineDataComponent } from './data/pipeline-data.component';
import { SchemaTableSelectorComponent } from './data/schema-table-selector/schema-table-selector.component';
import { SourceGeneralComponent } from './data/source-general/source-general.component';
import { FiltersFormComponent } from './filters/filters-form/filters-form.component';
import { FiltersSidebarComponent } from './filters/filters-sidebar/filters-sidebar.component';
import { FiltersComponent } from './filters/filters.component';
import { PipelineFinalizeModule } from './finalize/pipeline-finalize.module';
import { PipelineGeneralComponent } from './general/pipeline-general.component';
import { ColumnMappingOverviewComponent } from './mapping/data-table/column-mapping-sidebar/column-mapping-overview/column-mapping-overview.component';
import { ColumnMappingSidebarComponent } from './mapping/data-table/column-mapping-sidebar/column-mapping-sidebar.component';
import { ColumnMappingTableComponent } from './mapping/data-table/column-mapping-sidebar/column-mapping-table/column-mapping-table.component';
import { DataTableComponent } from './mapping/data-table/data-table.component';
import { MappingOverviewComponent } from './mapping/mapping-overview/mapping-overview.component';
import { PipelineMappingComponent } from './mapping/pipeline-mapping.component';
import { ResetToDefaultSidebarComponent } from './mapping/reset-to-default/sidebar/reset-to-default-sidebar.component';
import { PipelineRoutingModule } from './pipeline-routing.module';
import { PipelineComponent } from './pipeline.component';
import { BulkColumnMappingSidebarComponent } from './mapping/data-table/column-mapping-sidebar/bulk-column-mapping-sidebar/bulk-column-mapping-sidebar.component';
import { ChangeTableMappingComponent } from './mapping/change-mapping/change-table-mapping/change-table-mapping.component';
import { ChangeColumnMappingSidebarComponent } from './mapping/change-mapping/change-column-mapping/change-column-mapping-sidebar.component';
import { ChangeColumnMappingChangesTabComponent } from './mapping/change-mapping/change-column-mapping/change-column-mapping-changes-tab/change-column-mapping-changes-tab.component';
import { ChangeColumnMappingDefaultsTabComponent } from './mapping/change-mapping/change-column-mapping/change-column-mapping-defaults-tab/change-column-mapping-defaults-tab.component';
import { ChangeTableMappingSidebarComponent } from './mapping/change-mapping/change-table-mapping/change-table-mapping-sidebar/change-table-mapping-sidebar.component';
import { ResetDefaultSidebarComponent } from './mapping/data-table/column-mapping-sidebar/reset-default-sidebar/reset-default-sidebar.component';
import { RowMetadataColumnComponent } from './mapping/change-mapping/change-column-mapping/row-metadata-column/row-metadata-column.component';
import { PipelineConnectionsModule } from './connections/pipeline-connections.module';
import {
  commonLoader,
  homeLoader,
  serversLoader,
  pipelinesLoader,
  finalizeLoader,
  metabasesLoader,
  dataLoader,
  pngLoader,
  filtersLoader,
  logReadersLoader,
  connectionsLoader
} from '../../i18n-loaders';
import { DiscardColumnMappingSidebarComponent } from './mapping/data-table/discard-column-mapping-sidebar/discard-column-mapping-sidebar.component';
import { CreateTopicsSubjectsSidebarComponent } from './mapping/create-topic-subjects/create-topics-subjects-sidebar/create-topics-subjects-sidebar.component';
import { KnobModule } from 'primeng/knob';
import { CreateTopicsSubjectsErrorsSidebarComponent } from './mapping/create-topic-subjects/create-topics-subjects-errors-sidebar/create-topics-subjects-errors-sidebar.component';
import { AdduserDatabaseComponent } from './data/adduser-database/adduser-database.component';
import { AddDatabaseFormComponent } from './data/adduser-database/add-database-form/add-database-form.component';

@NgModule({
  declarations: [
    PipelineDataComponent,
    FiltersComponent,
    FiltersFormComponent,
    FiltersSidebarComponent,
    PipelineComponent,
    PipelineGeneralComponent,
    SchemaTableSelectorComponent,
    SourceGeneralComponent,
    LogReaderConfigurationFormComponent,
    LogReaderConfigurationSidebarComponent,
    PipelineMappingComponent,
    MappingOverviewComponent,
    LogReaderFormComponent,
    LogReaderSidebarComponent,
    ResetToDefaultSidebarComponent,
    DataTableComponent,
    ExcludeusersFormComponent,
    ExcludeusersSidebarComponent,
    ChangeTableMappingComponent,
    ChangeTableMappingSidebarComponent,
    ColumnMappingSidebarComponent,
    ColumnMappingOverviewComponent,
    ColumnMappingTableComponent,
    ChangeColumnMappingSidebarComponent,
    ChangeColumnMappingChangesTabComponent,
    ChangeColumnMappingDefaultsTabComponent,
    BulkColumnMappingSidebarComponent,
    ResetDefaultSidebarComponent,
    RowMetadataColumnComponent,
    DiscardColumnMappingSidebarComponent,
    CreateTopicsSubjectsSidebarComponent,
    CreateTopicsSubjectsErrorsSidebarComponent,
    AdduserDatabaseComponent,
    AddDatabaseFormComponent
  ],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'connections', loader: connectionsLoader },
        { scope: 'home', loader: homeLoader },
        { scope: 'servers', loader: serversLoader },
        { scope: 'pipelines', loader: pipelinesLoader },
        { scope: 'filter', loader: filtersLoader },
        { scope: 'finalize', loader: finalizeLoader },
        { scope: 'metabases', loader: metabasesLoader },
        { scope: 'data', loader: dataLoader },
        { scope: 'logreaders', loader: logReadersLoader },
        { scope: 'png', loader: pngLoader }
      ]
    }
  ],
  imports: [
    CommonModule,
    DropdownModule,
    FormsModule,
    PipelineRoutingModule,
    RadioButtonModule,
    CheckboxModule,
    ReactiveFormsModule,
    MetabasesModule,
    SharedModule,
    TableModule,
    TranslocoModule,
    PipelineFinalizeModule,
    PipelinesSharedModule,
    PipelineConnectionsModule,
    DividerModule,
    ToggleButtonModule,
    ProgressSpinnerModule,
    AutoCompleteModule,
    ListboxModule,
    TooltipModule,
    CatalogsModule,
    TabViewModule,
    InputSwitchModule,
    KnobModule
  ]
})
export class PipelineModule {}
