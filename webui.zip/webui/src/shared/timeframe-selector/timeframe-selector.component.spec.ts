import { CommonModule } from '@angular/common';
import { EventEmitter } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslocoModule } from '@ngneat/transloco';
import { SharedModule } from 'discovery-shared';
import { TimeframeSelectorComponent } from './timeframe-selector.component';

describe('TimeframeSelectorComponent', () => {
  let component: TimeframeSelectorComponent;
  let fixture: ComponentFixture<TimeframeSelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [TimeframeSelectorComponent],
      imports: [CommonModule, TranslocoModule, SharedModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TimeframeSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should have default value for id', () => {
    expect(component.id).toBeDefined();
    expect(component.id).not.toBeNull();
  });

  it('timeframeChange should be of Event Type ', () => {
    expect(component.timeframeChange).toBeInstanceOf(EventEmitter);
  });

  it('should be an array', () => {
    expect(component.timeSelectionDropdown).toBeInstanceOf(Array);
  });

  it('should have length equals to 4 for dropdown values', () => {
    expect(component.timeSelectionDropdown.length).toBe(4);
  });
});
