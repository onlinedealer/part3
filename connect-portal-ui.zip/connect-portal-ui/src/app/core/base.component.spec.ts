import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { of } from 'rxjs';
import { BaseComponent } from './base.component';

describe('BaseComponent', () => {
  let component: BaseComponent;
  let fixture: ComponentFixture<BaseComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [BaseComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should parse message error from API response', () => {
    component.parseHttpClientResponseMessage('error', { error: { message: 'error' } });
    expect(component.messageType).toBe('error');
    expect(component.message).toBe('error');
  });

  it('should parse message from API response', () => {
    component.parseHttpClientResponseMessage('error', { message: 'error' });
    expect(component.messageType).toBe('error');
    expect(component.message).toBe('error');
  });

  it('should naviagte to new route', () => {
    spyOn(component.router, 'navigate').and.returnValue(of(true).toPromise());
    component.navigateTo('test');
    expect(component.router.navigate).toHaveBeenCalledWith([`/data-integration/test`], undefined);
  });

  it('should return empty text when text is not truncated', () => {
    expect(component.displayTooltipOnOverflow({ offsetWidth: 100, scrollWidth: 50, innerText: 'test' })).toBe('');
  });

  it('should return inner text is truncated', () => {
    expect(component.displayTooltipOnOverflow({ offsetWidth: 100, scrollWidth: 150, innerText: 'test' })).toBe('test');
  });

  it('should return the correct style class list for the correct status', () => {
    expect(component.getStatusIconStyleClassList('UP')).toEqual(['png-alert-ok-solid', 'text-success']);
    expect(component.getStatusIconStyleClassList('DOWN')).toEqual(['png-alert-attention-solid', 'text-warning']);
    expect(component.getStatusIconStyleClassList('PARTIAL')).toEqual(['png-alert-partial', 'text-danger']);
    expect(component.getStatusIconStyleClassList('STOPPED')).toEqual(['png-alert-stopped-solid', 'text-danger']);
    expect(component.getStatusIconStyleClassList('IN_PROGRESS')).toEqual(['png-refresh', 'text-warning']);
    expect(component.getStatusIconStyleClassList('STOPPING')).toEqual(['png-refresh', 'text-success']);
    expect(component.getStatusIconStyleClassList('STARTING')).toEqual(['png-refresh', 'text-success']);
    expect(component.getStatusIconStyleClassList('ACTION_REQUIRED')).toEqual(['png-alert-actionrequired-solid', 'text-danger']);
    expect(component.getStatusIconStyleClassList('OK')).toEqual([]);
    expect(component.getStatusIconStyleClassList('DISABLED')).toEqual(['png-disabled', 'text-muted']);
    expect(component.getStatusIconStyleClassList('ENABLED')).toEqual(['png-alert-open', 'text-success']);
    expect(component.getStatusIconStyleClassList('UNKNOWN')).toEqual(['png-alert-unknown-solid', 'text-warning']);
    expect(component.getStatusIconStyleClassList('ATTENTION')).toEqual(['png-alert-attention-solid', 'text-warning']);
    expect(component.getStatusIconStyleClassList('ERROR')).toEqual(['png-alert-actionrequired-solid', 'text-danger']);
    expect(component.getStatusIconStyleClassList('COMPLETED')).toEqual(['png-check', 'text-success']);
    expect(component.getStatusIconStyleClassList('QUEUED')).toEqual(['png-signin', 'text-success']);
    expect(component.getStatusIconStyleClassList('IGNORED')).toEqual(['png-alert-stopped-solid', 'text-muted']);
  });

  it('should return the correct style class list for the correct overall status', () => {
    expect(component.getOverallStatusStyleClass('ACTION_REQUIRED')).toContain('png-alert-actionrequired-solid');
    expect(component.getOverallStatusStyleClass('STOPPED')).toContain('png-alert-stopped-solid');
    expect(component.getOverallStatusStyleClass('IN_PROGRESS')).toContain('png-refresh');
    expect(component.getOverallStatusStyleClass('UNKNOWN')).toContain('png-alert-unknown-solid');
    expect(component.getOverallStatusStyleClass('ATTENTION')).toContain('png-alert-attention-solid');
    expect(component.getOverallStatusStyleClass('STOPPING')).toContain('png-refresh');
    expect(component.getOverallStatusStyleClass('STARTING')).toContain('png-refresh');
    expect(component.getOverallStatusStyleClass('OK')).toContain('png-alert-open');
    expect(component.getOverallStatusStyleClass('COMPLETED')).toContain('png-check');
    expect(component.getOverallStatusStyleClass('PARTIAL')).toContain('png-alert-partial');
    expect(component.getOverallStatusStyleClass('IGNORED')).toContain('png-alert-stopped-solid');
  });

  it('should not show the hover text on mouse over if we can fit in the whole text', () => {
    component.fieldValueMouseOver({ target: { offsetWidth: 350, scrollWidth: 300, innerText: 'testing' } });
    expect(component.fieldValueHoverText).toBe('');
  });

  it('should show the hover text on mouse over', () => {
    component.fieldValueMouseOver({ target: { offsetWidth: 200, scrollWidth: 300, innerText: 'testing' } });
    expect(component.fieldValueHoverText).toBe('testing');
  });

  it('should clear the hover text on mouse out', () => {
    component.fieldValueMouseOut({});
    expect(component.fieldValueHoverText).toBe('');
  });

  it('should be able to return a parameter value', () => {
    const params = [
      { key: 'a', value: '1' },
      { key: 'b', value: '2' },
      { key: 'c', value: '3' }
    ];
    expect(component.getParameterValue(params, 'a')).toBe('1');
  });

  it('should return empty string if parameter value not found', () => {
    const params = [
      { key: 'a', value: '1' },
      { key: 'b', value: '2' },
      { key: 'c', value: '3' }
    ];
    expect(component.getParameterValue(params, 'd')).toBe('');
  });
});
