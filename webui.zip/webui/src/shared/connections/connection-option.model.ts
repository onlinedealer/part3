export class ConnectionOptionModel {
  constructor(public name: string, public value: string) {}
}
