import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { EventBusService } from 'core/eventBusService';
import { Helper } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { ObserverConstants } from 'observer/observer-constants';
import { ObserverService } from 'observer/observer.service';
import { Subscription } from 'rxjs';
import { ObserverConfigureModel } from '../observer-configure.model';
import { ObserverRulesModel } from './observerRules.model';
import { MetricRuleModel } from './rules-configure/metric-rule-model';
import { SavedRuleModel } from './saved-rule.model';

@Component({
  selector: 'discovery-observer-rules',
  templateUrl: './observer-rules.component.html',
  styleUrls: ['./observer-rules.component.css']
})
export class ObserverRulesComponent implements OnInit, OnDestroy {
  @Input() editMode: boolean;
  @Output() observationRuleListChange: EventEmitter<ObserverRulesModel[]> = new EventEmitter<ObserverRulesModel[]>();
  @Output() metricRuleModelChange: EventEmitter<MetricRuleModel> = new EventEmitter<MetricRuleModel>();

  rulesConfig: { ruleType: string; data: Record<string, unknown> };
  ruleSidebarVisible = false;
  observationRules: ObserverRulesModel[];
  selectedObservationRuleList: ObserverRulesModel[] = [];
  failureMessage: any[] = [];
  loadInProgress: boolean = false;
  showTriState: boolean;
  showError: boolean = false;
  value: boolean;
  selectAll: boolean = true;
  allNodeSeleted: boolean;
  ruleConfigSubscription: Subscription;
  savedRules = new SavedRuleModel();

  constructor(
    private observerService: ObserverService,
    private toastrService: ToastrService,
    private translocoService: TranslocoService,
    private eventBusService: EventBusService
  ) {}

  ngOnInit(): void {
    this.loadRuleListData();
    this.getRulesConfig();
  }

  loadRuleListData() {
    this.loadInProgress = true;
    if (!this.editMode) {
      this.getObserverRuleService();
    }
  }

  getObserverRuleService(observeConfigureModel?: ObserverConfigureModel) {
    this.observerService.getObservationRulesList().subscribe(
      (response) => {
        this.loadInProgress = true;
        this.observationRules = [];
        this.observationRules = response;
        if (!this.editMode) {
          this.changeStatus();
        } else if (this.editMode) {
          for (const observationRule of this.observationRules) {
            if (observeConfigureModel.metrics.includes(observationRule.metricName)) {
              observationRule.selected = true;
            }
          }
        }
        this.observationRulesList();
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.loadInProgress = false;
        this.toastrService.error(
          this.translocoService.translate('discoveryObserver.observerRules.fetchObservationRuleFailed', {
            serverMessage:
              httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                ? httpErrorResponse.error.message
                : ''
          })
        );
      }
    );
  }

  tableHeaderSelectionChanged() {
    this.showError = false;
    if (this.selectAll === true) {
      for (const observerRule of this.observationRules) {
        observerRule.selected = true;
      }
    } else if (!this.selectAll) {
      for (const observerRule of this.observationRules) {
        observerRule.selected = null;
      }
    }
    this.observationRulesList();
  }

  nodeClicked(ruleNode: ObserverRulesModel) {
    this.showError = false;
    if (ruleNode.selected === false) {
      ruleNode.selected = null;
    } else if (ruleNode.selected === null) {
      ruleNode.selected = true;
    }
    this.observationRulesList();
  }

  observationRulesList() {
    for (const observationRule of this.observationRules) {
      if (observationRule.selected) {
        const index = this.selectedObservationRuleList.findIndex(
          (rule) => rule.metricName === observationRule.metricName
        );
        if (index === -1) {
          const ruleNodeModel: ObserverRulesModel = new ObserverRulesModel();
          ruleNodeModel.metricName = observationRule.metricName;
          this.selectedObservationRuleList.push(ruleNodeModel);
        }
      } else {
        const index = this.selectedObservationRuleList.findIndex(
          (rule) => rule.metricName === observationRule.metricName
        );
        if (index !== -1) {
          this.selectedObservationRuleList.splice(index, 1);
        }
      }
      if (
        (this.selectAll === true && !observationRule.selected) ||
        (this.selectAll === null && observationRule.selected)
      ) {
        this.selectAll = false;
      }
      if (this.selectedObservationRuleList.length === 0) {
        this.selectAll = null;
      }
      if (this.selectedObservationRuleList.length === this.observationRules.length) {
        this.selectAll = true;
      }
    }
    this.observationRuleListChange.emit(this.selectedObservationRuleList);
  }

  loadObserverSettings(observeConfigureModel: ObserverConfigureModel) {
    this.getObserverRuleService(observeConfigureModel);
    this.loadRuleConfigSettings(observeConfigureModel);
  }

  changeStatus() {
    for (const observationRule of this.observationRules) {
      observationRule.selected = true;
    }
    this.observationRulesList();
  }

  validate(): Set<string> {
    this.showError = false;
    const errors: Set<string> = new Set<string>();
    this.updateRuleConfigs();
    if (!this.selectedObservationRuleList.length) {
      this.showError = true;
      errors.add('discoveryObserver.observerRules.invalidRules');
    }
    return errors;
  }
  rulesSidebarChange(rowData) {
    this.ruleSidebarVisible = true;
    const metricName = Helper.getTitleCaseString(rowData?.metricName);
    this.rulesConfig = {
      ruleType: metricName,
      data: this.savedRules ? this.savedRules[Helper.getCamcelCaseString(metricName)] : null
    };
  }
  ngOnDestroy(): void {
    if (this.ruleConfigSubscription) {
      this.ruleConfigSubscription.unsubscribe();
    }
  }
  private updateRuleConfigs() {
    const ruleConfig = new MetricRuleModel();
    for (const rule of this.selectedObservationRuleList) {
      switch (Helper.getTitleCaseString(rule.metricName)) {
        case ObserverConstants.RULE_METRIC_TYPES.VOLUME:
          if (
            !Helper.isEmpty(this.savedRules.volume.confidence.warningAlerts) ||
            !Helper.isEmpty(this.savedRules.volume.threshold.warningAlerts)
          ) {
            ruleConfig.volumeConfig[this.savedRules.volume.configType] =
              this.savedRules.volume[this.savedRules.volume.configType];
          } else {
            ruleConfig.volumeConfig.confidence.warningAlerts =
              this.observerService.getDefaultsConfigForObserverRules().volumeConfig.warningAlerts;
            this.savedRules.volume.configType = ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE;
          }
          this.savedRules.volume.configType === ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE
            ? delete ruleConfig.volumeConfig[ObserverConstants.RULE_CONFIG_VOLUME_TYPES.THRESHOLD]
            : delete ruleConfig.volumeConfig[ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE];
          break;
        case ObserverConstants.RULE_METRIC_TYPES.DATA_DRIFT:
          if (Helper.isEmpty(this.savedRules.dataDrift.confidence.warningAlerts)) {
            ruleConfig.dataDriftConfig.confidence =
              this.observerService.getDefaultsConfigForObserverRules().dataConfig.confidence;
          } else {
            ruleConfig.dataDriftConfig = this.savedRules.dataDrift;
          }
          break;
      }
    }
    this.getSelectedRuleConfig(ruleConfig);
  }

  private loadRuleConfigSettings(observeConfigureModel) {
    this.savedRules = new SavedRuleModel();
    for (const key in observeConfigureModel.metricRule) {
      switch (key) {
        case ObserverConstants.RULE_CONFIG_KEYS.VOLUME_CONFIG:
          if (observeConfigureModel.metricRule.volumeConfig[ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE]) {
            this.savedRules.volume.configType = ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE;
            this.savedRules.volume.confidence = observeConfigureModel.metricRule.volumeConfig.confidence;
          } else {
            this.savedRules.volume.configType = ObserverConstants.RULE_CONFIG_VOLUME_TYPES.THRESHOLD;
            this.savedRules.volume.threshold = observeConfigureModel.metricRule.volumeConfig.threshold;
          }
          break;
        case ObserverConstants.RULE_CONFIG_KEYS.DATA_DRIFT_CONFIG:
          this.savedRules.dataDrift = observeConfigureModel.metricRule.dataDriftConfig;
          break;
      }
    }
  }

  private getRulesConfig() {
    this.ruleConfigSubscription = this.eventBusService?.on<any>('OBSRuleConfig')?.subscribe((data) => {
      this.savedRules[data.ruleType] = data.data;
    });
  }

  private getSelectedRuleConfig(ruleConfig: MetricRuleModel) {
    const selectedObserverRuleArray = Array.from(this.selectedObservationRuleList, (item) => {
      const metricName = Helper.getTitleCaseString(item.metricName);
      if (metricName === ObserverConstants.RULE_METRIC_TYPES.VOLUME) {
        return ObserverConstants.RULE_CONFIG_KEYS.VOLUME_CONFIG;
      } else if (metricName === ObserverConstants.RULE_METRIC_TYPES.DATA_DRIFT) {
        return ObserverConstants.RULE_CONFIG_KEYS.DATA_DRIFT_CONFIG;
      }
    });

    for (const key of Object.keys(ruleConfig)) {
      if (!selectedObserverRuleArray.includes(key)) {
        delete ruleConfig[key];
      }
    }
    this.metricRuleModelChange.emit(ruleConfig);
  }
}
