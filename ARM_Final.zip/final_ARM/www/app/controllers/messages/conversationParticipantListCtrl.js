(function () {
    'use strict';

    angular.module('arm').controller('conversationParticipantListCtrl',
                ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate','MASTER_TABLE', 'messageService', 'utility', '$filter', conversationParticipantListCtrl]);

    function conversationParticipantListCtrl($scope, $state, $ionicModal, $ionicSideMenuDelegate, MASTER_TABLE, messageService, utility, $filter) {
		
        $scope.conversationList = messageService.getConversationList();

        fetchParticipant();

		$scope.messageDetail = function(participant) 
        {
            var loggedInUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            var existedConversation = $filter('filter')($scope.conversationList, {Participant1ID: participant.Id, Participant2ID: loggedInUser.UserID});
            if (existedConversation.length == 0) {
                existedConversation = $filter('filter')($scope.conversationList, {Participant1ID: loggedInUser.UserID, Participant2ID: participant.Id});
            }

            if (existedConversation.length) {
                var conversation = existedConversation[0];
                messageService.setSelectedConversation(conversation);
                $state.go('tab.conversationDetail', {
                    });
            }else
            {
                $scope.conversation = messageService.models().ConversationModel;
                $scope.conversation.Participant1ID = loggedInUser.UserID;
                $scope.conversation.Participant2ID = participant.Id;
                $scope.conversation.ImgSrc = participant.ImgSrc;
                messageService.insertConversation($scope.conversation).then(function(result){
                    $scope.conversationList.push($scope.conversation);
                    messageService.setSelectedConversation($scope.conversation);
                    $state.go('tab.conversationDetail', {
                    });
                });
            }
			console.log("Selected Participant"+ participant.Id + " " + participant.Name);
        }  

        function fetchParticipant()
        {
            $scope.participantList = [];
            var userGroup = utility.getMultLangMasData(MASTER_TABLE.UserGroup);
            angular.forEach(userGroup,function(group)
            {
                var participantModel = messageService.models().ParticipantModel;
                participantModel.IsGroup = true;
                participantModel.Id = group.UserGroupID;
                participantModel.Name = group.Name;
                participantModel.ImgSrc = "images/avatar-group.png";//images/avatar.png
                $scope.participantList.push(participantModel);
            });

        }
	};
})();







