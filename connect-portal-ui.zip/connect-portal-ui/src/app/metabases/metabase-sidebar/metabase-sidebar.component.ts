import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { Subscription } from 'rxjs';
import { mergeMap, first } from 'rxjs/operators';
import { Connection } from '../../connections/shared/connection';
import { BaseComponent } from '../../core/base.component';
import { ProjectsApiService } from '../../pipelines/pipeline/shared/projects-api.service';
import { SidebarButton } from '../../shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';
import { MetabaseFormComponent } from './metabase-form/metabase-form.component';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { EncryptionService } from '../../shared/services/encryption.service';

@Component({
  selector: 'p-connect-metabase-sidebar',
  templateUrl: './metabase-sidebar.component.html'
})
export class MetabaseSidebarComponent extends BaseComponent implements OnChanges, OnDestroy, AfterViewInit {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * Reference to the MetabaseFormComponent child component
   */
  @ViewChild(MetabaseFormComponent) metabaseFormComponent: MetabaseFormComponent;

  /**
   * Set to true to display the sidebar component
   */
  @Input() isVisible: boolean;

  /**
   * If provided will default to this when creating a metabase
   */
  @Input() selectedConnection: Connection;

  /**
   * Event when the cancel button is clicked
   */
  @Output() cancelButtonClicked = new EventEmitter<boolean>();

  /**
   * Event when a metabase has been saved
   */
  @Output() metabaseSavedEvent = new EventEmitter<{ id: number }>();

  primaryButton: SidebarButton = {
    id: 'metabaseSaveButton',
    text: 'metabases.METABASE_FORM.BUTTONS.CREATE',
    isDisabled: true
  };
  cancelButton: SidebarButton = {
    id: 'metabaseCancelButton',
    text: 'metabases.METABASE_FORM.BUTTONS.CANCEL'
  };

  subscriptions: Subscription[] = [];

  constructor(
    private readonly projectsApiService: ProjectsApiService,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly metabasesApiService: MetabasesApiService,
    private readonly encryptionService: EncryptionService
  ) {
    super();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.isVisible && this.isVisible) {
      this.subscriptions.push(
        this.metabaseFormComponent.metabaseFormGroup.valueChanges.subscribe(() => {
          this.changeDetectorRef.markForCheck();
          this.updateButtonDisabledState();
        })
      );
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  ngAfterViewInit() {
    this.changeDetectorRef.detectChanges();
  }

  setMetabase(id: string): void {
    // to do - open a metabase
  }

  async saveMetabaseButtonClicked() {
    this.sidebarComponent.isProcessingRequest = true;
    const metabase = this.metabaseFormComponent.metabase;
    const passwordParameter = metabase.parameters.find((parameter) => parameter.key === 'REPLICATION_USER_PASSWORD');
    const serverName = this.metabaseFormComponent.metabase.dataConnection.accessFromServer;
    let encryptedPassword: any = await this.encryptionService.encrypt(serverName.name, passwordParameter.value).catch((errorResponse) => {
      this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
    });
    passwordParameter.value = encryptedPassword;

    // for Oracle we also need to encrypt admin password
    if (metabase?.adminUserPassword) {
      encryptedPassword = await this.encryptionService.encrypt(serverName.name, metabase.adminUserPassword).catch((errorResponse) => {
        this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
      });
      metabase.adminUserPassword = encryptedPassword;
    }

    this.projectsApiService
      .getDefaultProject()
      .pipe(
        mergeMap((project) => {
          this.metabasesApiService.serviceURL = `projects/${project.id}/metabases`;
          return this.metabasesApiService.create(metabase);
        })
      )
      .subscribe({
        next: (response: { id: number }) => {
          this.metabaseSavedEvent.emit(response);
          this.closeSidebar();
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  cancelMetabaseButtonClicked(): void {
    this.cancelButtonClicked.emit(true);
    this.closeSidebar();
  }

  private closeSidebar(): void {
    this.isVisible = false;
    this.metabaseFormComponent.childComponentReference.destroy();
    this.metabaseFormComponent.metabaseFormGroup.reset(this.metabaseFormComponent.initialFormGroupValues);
  }

  private updateButtonDisabledState(): void {
    /** Need to add a timeout here to avoid Expression ___ has changed after it was checked error  */
    setTimeout(() => {
      this.primaryButton.isDisabled = !this.metabaseFormComponent.metabaseFormGroup.valid;
      this.changeDetectorRef.markForCheck();
    });
  }
}
