import { Injectable } from '@angular/core';
import { UtilityService } from './utility.service';

const configParams = [{
    envs: ['QA1', 'QA2', 'QA3', 'QA4', 'PT1', 'PT2', 'REG1', 'REG2', 'REG3', 'REG4', 'UAT1', 'UAT2', 'UAT3', 'UAT4'],
    values: {
        'endPoint': 'https://services-sit3.cvs.com/',
        'apiSecret': 'bf2a3c64-16df-4bfe-8fa9-53c24b079ea7',
        'apiKey': '2e77f5eb-016f-44a6-8d73-d5f2e6a01a54',
    }
},
{
    envs: ['PROD'],
    values: {
        'endPoint': 'https://services.cvs.com/',
        'apiSecret': 'a8df2d6e-b11c-4b73-8bd3-71afc2515dae',
        'apiKey': 'a2ff75c6-2da7-4299-929d-d670d827ab4a'
    }
},
{
    envs: ['IT1', 'IT2', 'IT3', 'IT4'],
    values: {
        'endPoint': 'https://services-sit3.cvs.com/',
        'apiSecret': 'bf2a3c64-16df-4bfe-8fa9-53c24b079ea7',
        'apiKey': '2e77f5eb-016f-44a6-8d73-d5f2e6a01a54',
    }
}];


@Injectable()
export class Env {
    appName: String;
    channelName: String;
    deviceType: String;
    apiSecret: string;
    apiKey: string;
    endPoint: string;
    isApp: boolean;
    configValues: any;
    environment: string;
    win_a: any;
    encryption: any;
    constructor(private _utility: UtilityService) {
        this.isApp = (<any>window).native;
        this.appName = this.isApp ? 'CVS_APP' : 'CVS_WEB';
        this.deviceType = _utility.getUserAgent();
        this.channelName = this.deviceType === 'DESKTOP' ? 'WEB' : 'MOBILE';
        this.getEnvValues();
    }


    getEnvValues() {
        const env = this._utility.getCurrentENV();
        const filteredENV = configParams.filter((key, value) => key.envs.indexOf(env) !== -1);
        this.configValues = filteredENV[0].values;
        this.environment = env;
    }
}
