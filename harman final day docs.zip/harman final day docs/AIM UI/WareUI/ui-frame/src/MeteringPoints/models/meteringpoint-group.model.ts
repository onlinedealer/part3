import { MeteringPoint } from "./meteringpoint.model";

export interface MeteringPointGroup {
    id: number;
    name?: string;
    meteringPointIds?: number[];
}
