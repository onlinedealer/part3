import { Clipboard } from '@angular/cdk/clipboard';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, ViewChild } from '@angular/core';
import { ErrorMessage } from '@precisely/prism-ng/cloud';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';

@Component({
  selector: 'p-connect-cataloging-error-sidebar',
  templateUrl: './cataloging-error-sidebar.component.html'
})
export class CatalogingErrorSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  errorMessage: ErrorMessage[];

  primaryButton: SidebarButton = {
    isHidden: true
  };

  displayErrorType: boolean = false;

  cancelButton: SidebarButton = {
    id: 'catalogErrorSidebarClose',
    text: 'common.BUTTONS.CLOSE'
  };

  constructor(private clipboard: Clipboard) {}

  /**
   * @param errorMessages For a connection, a list of catalog errors or selected schema & associated table errors
   */
  open(errorMessages: ErrorMessage[]): void {
    this.errorMessage = errorMessages.map((errorResponse: any) => {
      if (errorResponse instanceof HttpErrorResponse) {
        return {
          message: errorResponse.error.message,
          detailedMessage: errorResponse.error.detailedMessage,
          status: errorResponse.error.status,
          // with '/metadata/schemas' && '/status' API calls, timestamp key name is either in lowercase or camelcase
          timestamp: errorResponse.error.timeStamp || errorResponse.error.timestamp,
          statusText: errorResponse.statusText,
          path: errorResponse.error.path,
          error: errorResponse.error.error
        };
      } else {
        return errorResponse;
      }
    });
    this.sidebarComponent.open();
    this.displayErrorType = errorMessages.length === 1 ? true : false;
  }

  close(): void {
    this.errorMessage = [];
    this.sidebarComponent.close();
    this.displayErrorType = false;
  }

  copyClipboard(error: HttpErrorResponse): void {
    error ? this.clipboard.copy(error.error) : this.clipboard.copy('');
  }
}
