import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../services/utility.service';
import { SeoService } from '../services/seo.service';

@Component({
  selector: 'app-multi-offer-page',
  templateUrl: './multi-offer-page.component.html',
  styleUrls: ['./multi-offer-page.component.scss']
})
export class MultiOfferPageComponent implements OnInit {

  serviceUrls:Object;
  couponList:any = [];
  activeState:String = 'alldeals';
  subscriber:any;
  isGetCustomerRespRcvd:Boolean = false;

  constructor(public utilityService: UtilityService,private seo:SeoService) { 
    seo.addSeoData();
  }

  ngOnInit() {
    this.getServiceUrls();
    console.log('MultiOffer');
  }

  ngOnDestroy() {
    this.subscriber.unsubscribe();
  }

  getServiceUrls(){  
      this.utilityService.fetchServiceUrls();
      this.subscriber = this.utilityService.serviceUrlsObservable$.subscribe((data) => {
       
        if(!this.utilityService.isEmpty(data) && !data.hasOwnProperty('error')){
        this.serviceUrls = data['config']['serviceUrls'];
        if(this.serviceUrls){         
            this.getCustomerProfile();
        }
        }else if(data.hasOwnProperty('error')){

        }
      });
  }

  getCustomerProfile(){
    let payload = {
    };

    let header = {
    };
    this.utilityService.sendRequest(this.serviceUrls['getCustomerProfile'],payload, header).subscribe((response)=>{
        if(response.hasOwnProperty('cusInfResp') && response['cusInfResp'].hasOwnProperty('xtraCard') && response['cusInfResp'].hasOwnProperty('cpns') && !this.utilityService.isEmpty(response['cusInfResp']['cpns'])){   
            this.couponList = response['cusInfResp'];
            this.isGetCustomerRespRcvd = true;
        }else{
          console.log('error');
        }
      },
      error =>{
        console.log(error);
      });
  }

  changeRightView(activeState){
    this.activeState = activeState;
  }

}
