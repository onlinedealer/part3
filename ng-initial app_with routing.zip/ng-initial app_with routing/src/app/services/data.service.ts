import {Injectable} from "@angular/core";
import {Http, Response} from "@angular/http";
import { HttpClient, HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class DataService {

  constructor(public http: Http) { 
    console.log("in service")
  }
  getPosts(){
    // this.http.get('https://jsonplaceholder.typicode.com/posts');
    // .map(res => res.json());
  }

}
