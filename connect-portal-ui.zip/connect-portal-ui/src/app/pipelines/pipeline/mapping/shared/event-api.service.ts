import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { BaseEventApiService } from 'src/app/core/base-event-api.service';
import { EventResponse } from './event-response';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EventApiService extends BaseEventApiService<EventResponse> {
  private subjectFailureErrors = new Subject<any>();
  public subjectFailureErrors$ = this.subjectFailureErrors.asObservable();

  constructor(protected httpClient: HttpClient) {
    super(httpClient, 'api/v1');
  }
  initiateSubjectAndTopicCreation(url: string) {
    return this.httpClient.post(`${this.serviceURL}/events/${url}`, null);
  }
  getStatusOfSubjectsCreation(dataflowId: string, headers?: HttpHeaders) {
    return this.httpClient.get(`${this.serviceURL}/events/subjects-status?dataflowId=${dataflowId}`, { headers });
  }
  getStatusOfTopicsCreation(dataflowId: string, headers?: HttpHeaders) {
    return this.httpClient.get(`${this.serviceURL}/events/topics-status?dataflowId=${dataflowId}`, { headers });
  }
  emitSubjectFailureErrors(error) {
    this.subjectFailureErrors.next(error);
  }
}
