import React from 'react'
import { object } from 'prop-types'
import { connect } from 'react-redux'
import { Helmet } from 'react-helmet'
import { withStyles } from '@material-ui/core/styles'
import HeaderTitle from '../Header/HeaderTitle'

const styles = {
  homePage: {
    textAlign: 'center',
  },
  homePageIntro: {
    fontSize: 'large',
  },
}

class HomePage extends React.Component {
  static propTypes = {
    classes: object,
  }

  render () {
    const { classes, headerTitle } = this.props

    return (
      <div className={classes.homePage}>
        <HeaderTitle title="Home" />
        <Helmet>
          <title>{headerTitle}</title>
        </Helmet>
        <h1>Welcome to MIT</h1>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  headerTitle: state.getIn(['layout', 'headerTitle']),
})

export default connect(mapStateToProps)(withStyles(styles)(HomePage))
