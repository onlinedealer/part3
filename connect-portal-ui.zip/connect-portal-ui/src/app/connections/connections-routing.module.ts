import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ConnectionsComponent } from './connections.component';
import { SharedConnectionsComponent } from './shared-connections/shared-connections.component';

const routes: Routes = [
  {
    path: '',
    children: [
      {
        path: '',
        component: ConnectionsComponent
      },
      {
        path: 'shared',
        component: SharedConnectionsComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConnectionsRoutingModule {}
