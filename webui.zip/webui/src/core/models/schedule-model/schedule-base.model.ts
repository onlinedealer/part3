export class ScheduleBaseModel {
  runAtTime: Date;
  fromDate: Date;
  setFromDate(minutes = 30): number {
    const date1 = new Date();
    const date2 = new Date(date1);
    return date2.setMinutes(date1.getMinutes() + minutes);
  }
}
