import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslocoService, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of, throwError } from 'rxjs';
import { Connection } from 'src/app/connections/shared/connection';
import { MetadataApiService } from 'src/app/pipelines/pipeline/data/schema-table-selector/metadata-api.service';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { CatalogingErrorSidebarComponent } from '../../cataloging-error-sidebar/cataloging-error-sidebar.component';
import { CatalogingErrorSidebarService } from '../../cataloging-error-sidebar/cataloging-error-sidebar.service';
import { CatalogApiService } from '../../shared/catalog-api.service';
import { CatalogSchema } from '../../shared/catalog-schema';
import { CatalogStatus, CATALOG_STATUS } from '../../shared/catalog-status';
import { DeleteCatalogSidebarComponent } from '../delete-catalog-sidebar/delete-catalog-sidebar.component';
import { ManageCatalogComponent } from './manage-catalog.component';

describe('ManageCatalogComponent', () => {
  let component: ManageCatalogComponent;
  let fixture: ComponentFixture<ManageCatalogComponent>;
  let catalogApiService: CatalogApiService;
  let metadataApiService: MetadataApiService;
  let translocoService: TranslocoService;
  let catalogingErrorService: CatalogingErrorSidebarService;

  @Component({
    selector: 'p-connect-delete-catalog-sidebar',
    template: '',
    providers: [
      {
        provide: DeleteCatalogSidebarComponent,
        useClass: MockDeleteCatalogSidebarComponent
      }
    ]
  })
  class MockDeleteCatalogSidebarComponent {
    open() {}
  }

  @Component({
    selector: 'p-connect-cataloging-error-sidebar',
    template: '',
    providers: [
      {
        provide: CatalogingErrorSidebarComponent,
        useClass: MockCatalogingErrorSidebarComponent
      }
    ]
  })
  class MockCatalogingErrorSidebarComponent {
    open() {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } }],
      declarations: [ManageCatalogComponent, MockDeleteCatalogSidebarComponent, MockCatalogingErrorSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(ManageCatalogComponent);
    component = fixture.componentInstance;
    catalogApiService = TestBed.inject(CatalogApiService);
    metadataApiService = TestBed.inject(MetadataApiService);
    translocoService = TestBed.inject(TranslocoService);
    catalogingErrorService = TestBed.inject(CatalogingErrorSidebarService);

    component.connection = { connectionType: 'ORACLE', id: '123' };
    spyOn(metadataApiService, 'getSchemas').and.returnValue(of([{ name: 'test' }] as any));
    spyOn(catalogApiService, 'status').and.returnValue(of({} as CatalogStatus));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('manage catalog table', () => {
    beforeEach(() => {
      component.connection = { connectionType: 'ORACLE' };
      spyOn(metadataApiService, 'getSchemas').and.returnValue(of([{ name: 'test' }] as any));
    });

    it('should handle selections', () => {
      component.catalogsTable.rowSelectionChangedEvent([{ schema: 'test' }]);
      expect(component.selectedSchemas[0]).toEqual({ schema: 'test' });
    });

    it('should refresh and set 30 second interval', () => {
      spyOn(catalogApiService, 'status').and.returnValue(of({} as CatalogStatus));
      spyOn(metadataApiService, 'getSchemas').and.returnValue(of([{ name: 'test' }] as any));
      spyOn(component, 'updateAutoRefreshTimeout').and.callThrough();
      spyOn(window, 'setInterval').and.stub();
      component.onCatalogUpdated();
      expect(catalogApiService.status).toHaveBeenCalled();
      expect(component.updateAutoRefreshTimeout).toHaveBeenCalled();
      expect(window.setInterval).toHaveBeenCalled();
    });

    it('should handle return response for kafka connections', () => {
      component.connection = { connectionType: 'KAFKA' };
      spyOn(catalogApiService, 'status').and.returnValue(of({} as CatalogStatus));
      component.onCatalogUpdated();
      expect(catalogApiService.status).toHaveBeenCalled();
    });

    it('should be able to handle errors from the metadataApiService service', () => {
      spyOn(catalogApiService, 'status').and.returnValue(of({ schemas: [{ schema: 'test' }] } as CatalogStatus));
      spyOn(metadataApiService, 'getSchemas').and.returnValue(throwError('error'));
      component.onCatalogUpdated();
      expect(component.catalogsData.length).toBe(0);
    });

    it('should be able to handle errors from the catalog service', () => {
      const error = new HttpErrorResponse({ status: 500, error: 'error occured' });
      spyOn(catalogApiService, 'status').and.returnValue(throwError(() => error));
      component.onCatalogUpdated();
      expect(component.isUpdatingCatalog).toBe(false);
      expect(component.catalogsData.length).toBe(1);
    });

    describe('catalog error sidebar', () => {
      const status = {
        errorMessage: '{}',
        schemas: [{ schema: 'test', status: 'failed', errorMessage: '{}', tablesStatus: [{ errorMessage: '{}', table: 'table-1' }] }],
        status: 'failed'
      } as CatalogStatus;
      beforeEach(() => {
        spyOn(catalogingErrorService, 'add').and.returnValue();
        spyOn(component, 'getCatalogErrors').and.callThrough();
        spyOn(catalogApiService, 'status').and.returnValue(of(status));
      });

      it('should store error (for a connection that is not cataloged) to service', () => {
        const error = new HttpErrorResponse({ status: 500, error: 'error occured' });
        spyOn(catalogApiService, 'status').and.returnValue(throwError(() => error));
        component.onCatalogUpdated();
        expect(catalogingErrorService.add).toHaveBeenCalled();
      });

      it('should store error (for a connection that is cataloged but has a failed status) to service', () => {
        component.onCatalogUpdated();
        expect(component.getCatalogErrors).toHaveBeenCalled();
        expect(catalogingErrorService.add).toHaveBeenCalled();
      });

      it('should store error to service when api call to get schemas fail', () => {
        spyOn(metadataApiService, 'getSchemas').and.returnValue(throwError('error'));
        component.onCatalogUpdated();
        expect(catalogingErrorService.add).toHaveBeenCalled();
      });

      it('should open cataloging error sidebar and only show error for a selected schema', () => {
        spyOn(component.catalogingErrorSidebarComponent, 'open');
        component.schemasCataloged = [{ schema: 'test', status: 'failed', errorMessage: '{}' } as CatalogSchema];
        component.openCatalogingErrorSidebar('test');
        expect(component.catalogingErrorSidebarComponent.open).toHaveBeenCalled();
      });

      it('should open cataloging error sidebar and show all catalog errros', () => {
        spyOn(component.catalogingErrorSidebarComponent, 'open');
        component.schemasCataloged = [{ schema: 'test', status: 'failed', errorMessage: '{}' } as CatalogSchema];
        catalogingErrorService.errorMessages = [{ message: '', status: 500 }];
        component.openCatalogingErrorSidebar();
        expect(component.catalogingErrorSidebarComponent.open).toHaveBeenCalledWith(component.catalogErrorMessages);
      });

      it('should display Error Log link next to a schema name (in schemas table) if specific schema or its associated tables has an error', () => {
        component.onCatalogUpdated();
        expect(component.catalogsData.length).toEqual(1);
        component.catalogsData.forEach((schema) => {
          expect(schema.schemaError).toBe(true);
          expect(schema.tableError).toBe(true);
        });
      });
    });

    it('should handle return response for SchemaRegistry connections', () => {
      component.connection.connectionType = 'SCHEMAREGISTRY';
      spyOn(metadataApiService, 'getSubjects').and.returnValue(of([{ name: 'test' }] as any));
      spyOn(catalogApiService, 'status').and.returnValue(of({} as CatalogStatus));
      component.onCatalogUpdated();
      expect(catalogApiService.status).toHaveBeenCalled();
    });

    it('should be able to handle errors for getSubjects from metadataApiService service', () => {
      component.connection.connectionType = 'SCHEMAREGISTRY';

      const error = new HttpErrorResponse({ status: 500, error: 'error occured' });

      spyOn(catalogApiService, 'status').and.returnValue(throwError(() => error));
      spyOn(metadataApiService, 'getSubjects').and.returnValue(throwError(() => error));
      component.onCatalogUpdated();
      expect(component.isUpdatingCatalog).toBe(false);
    });
  });

  it('should return true if items have been selected', () => {
    component.selectedSchemas = [{ schema: 'test' }];
    expect(component.hasItemsSelected).toBe(true);
  });

  it('should return true if table is not visible (kafka)', () => {
    component.connection = { connectionType: 'KAFKA' } as Connection;
    expect(component.hasItemsSelected).toBe(true);
  });

  describe('buttons', () => {
    it('should start cataloging for the selected schemas', () => {
      component.isUpdatingCatalog = false;
      component.connection = { id: 'test' };
      component.selectedSchemas = [{ schema: 'test' }];
      spyOn(catalogApiService, 'createCatalog').and.returnValue(of({}));
      component.onStartCatalogingButtonClicked();
      expect(catalogApiService.createCatalog).toHaveBeenCalled();
    });

    it('should update cataloging for the selected schemas', () => {
      component.isUpdatingCatalog = true;
      spyOn(catalogApiService, 'updateCatalog').and.returnValue(of({}));
      component.onStartCatalogingButtonClicked();
      expect(catalogApiService.updateCatalog).toHaveBeenCalled();
    });

    it('should stop cataloging for the selected schemas', () => {
      component.connection = { id: 'test' };
      component.selectedSchemas = [{ schema: 'test' }];
      let spy = spyOn(catalogApiService, 'updateCatalog').and.returnValue(of({}));
      component.onStopCatalogingButtonClicked();
      expect(spy).toHaveBeenCalled();
    });

    it('should handle errors updating cataloging for the selected schemas', () => {
      component.isUpdatingCatalog = true;
      component.connection = { id: 'test' };
      spyOn(component.serviceError, 'emit').and.callThrough();
      spyOn(catalogApiService, 'updateCatalog').and.returnValue(throwError({}));
      component.onStartCatalogingButtonClicked();
      expect(catalogApiService.updateCatalog).toHaveBeenCalled();
      expect(component.serviceError.emit).toHaveBeenCalled();
    });

    it('should emit an event when start cataloging button is clicked and hide catalog warning message', () => {
      component.isUpdatingCatalog = false;
      component.connection = { id: 'test' };
      component.selectedSchemas = [{ schema: 'test' }];
      spyOn(component.startCatalogingEvent, 'emit').and.callThrough();
      spyOn(catalogApiService, 'createCatalog').and.returnValue(of({}));
      component.onStartCatalogingButtonClicked();
      expect(component.startCatalogingEvent.emit).toHaveBeenCalled();
    });

    it('start cataloging button should be enabled if not all selected schemas are cataloging', () => {
      component.selectedSchemas = [
        { schema: 'test', status: 'inprogress' },
        { schema: 'test2', status: 'complete' },
        { schema: 'test3', status: 'not_cataloged' }
      ];
      expect(component.isStartCatalogingDisabled).toBe(false);
    });

    it('start cataloging button should be disabled if all selected schemas are cataloging', () => {
      component.selectedSchemas = [
        { schema: 'test', status: 'inprogress' },
        { schema: 'test2', status: 'inprogress' }
      ];
      expect(component.isStartCatalogingDisabled).toBe(true);
    });

    it('stop cataloging button should be enabled if not all selected schemas are already stopped or not cataloged', () => {
      component.selectedSchemas = [
        { schema: 'test', status: 'inprogress' },
        { schema: 'test2', status: 'complete' },
        { schema: 'test3', status: 'not_cataloged' }
      ];
      expect(component.isStopCatalogingDisabled).toBe(false);
    });

    it('stop cataloging button should be disabled if all selected schemas are already stopped or not cataloged', () => {
      component.selectedSchemas = [
        { schema: 'test', status: 'complete' },
        { schema: 'test2', status: 'not_cataloged' },
        { schema: 'test3', status: 'complete' }
      ];
      expect(component.isStopCatalogingDisabled).toBe(true);
    });

    it('remove catalog button should be enabled if not all selected schemas are cataloging or not cataloged', () => {
      component.selectedSchemas = [
        { schema: 'test', status: 'inprogress' },
        { schema: 'test2', status: 'complete' },
        { schema: 'test3', status: 'not_cataloged' }
      ];
      expect(component.isRemoveCatalogDisabled).toBe(false);
    });

    it('remove catalog button should be disabled if all selected schemas are cataloging or not cataloged', () => {
      component.selectedSchemas = [
        { schema: 'test', status: 'inprogress' },
        { schema: 'test2', status: 'not_cataloged' },
        { schema: 'test3', status: 'inprogress' }
      ];
      expect(component.isRemoveCatalogDisabled).toBe(true);
    });

    describe('KAFKA', () => {
      beforeEach(() => {
        component.connection = { connectionType: 'KAFKA' };
      });

      it('start cataloging button should be enabled if not cataloging', () => {
        component.catalogStatus = { status: CATALOG_STATUS.NOT_CATALOGED, tooltip: '', icons: [], params: '' };
        expect(component.isStartCatalogingDisabled).toBe(false);
        component.catalogStatus = { status: CATALOG_STATUS.COMPLETE, tooltip: '', icons: [], params: '' };
        expect(component.isStartCatalogingDisabled).toBe(false);
      });

      it('start cataloging button should be disabled if cataloging', () => {
        component.catalogStatus = { status: CATALOG_STATUS.INPROGRESS, tooltip: '', icons: [], params: '' };
        expect(component.isStartCatalogingDisabled).toBe(true);
      });

      it('stop cataloging button should be enabled if not already stopped or not cataloged', () => {
        component.catalogStatus = { status: CATALOG_STATUS.INPROGRESS, tooltip: '', icons: [], params: '' };
        expect(component.isStopCatalogingDisabled).toBe(false);
      });

      it('stop cataloging button should be disabled if already stopped or not cataloged', () => {
        component.catalogStatus = { status: CATALOG_STATUS.COMPLETE, tooltip: '', icons: [], params: '' };
        expect(component.isStopCatalogingDisabled).toBe(true);
        component.catalogStatus = { status: CATALOG_STATUS.NOT_CATALOGED, tooltip: '', icons: [], params: '' };
        expect(component.isStopCatalogingDisabled).toBe(true);
      });

      it('remove catalog button should be enabled if not cataloging or not cataloged', () => {
        component.catalogStatus = { status: CATALOG_STATUS.COMPLETE, tooltip: '', icons: [], params: '' };
        expect(component.isRemoveCatalogDisabled).toBe(false);
      });

      it('remove catalog button should be disabled if cataloging or not cataloged', () => {
        component.catalogStatus = { status: CATALOG_STATUS.INPROGRESS, tooltip: '', icons: [], params: '' };
        expect(component.isRemoveCatalogDisabled).toBe(true);
        component.catalogStatus = { status: CATALOG_STATUS.NOT_CATALOGED, tooltip: '', icons: [], params: '' };
        expect(component.isRemoveCatalogDisabled).toBe(true);
      });
    });
  });

  describe('status icon', () => {
    it('should show the correct icon', () => {
      expect(component.getStatusIcon('FAILED')).toEqual(['png-alert-actionrequired-solid', 'text-danger']);
      expect(component.getStatusIcon('STOPPED')).toEqual(['png-alert-partial', 'text-danger']);
      expect(component.getStatusIcon('INPROGRESS')).toEqual(['png-alert-inprogress', 'text-success']);
      expect(component.getStatusIcon('COMPLETE')).toEqual(['png-alert-open', 'text-success']);
      expect(component.getStatusIcon('NOT_CATALOGED')).toEqual(['png-disabled', 'text-muted']);
      expect(component.getStatusIcon('OTHER')).toEqual([]);
    });
  });

  describe('on init', () => {
    beforeEach(() => {
      spyOn(catalogApiService, 'status').and.returnValue(of({ schemas: [{ schema: 'test' }] } as CatalogStatus));
      spyOn(metadataApiService, 'getSchemas').and.returnValue(of([{ name: 'test' }] as any));
    });

    it('should reset the selection', () => {
      component.selectedSchemas = [1];
      component.ngOnInit();
      expect(component.selectedSchemas.length).toBe(0);
    });

    it('should reset list of catalog errors', () => {
      spyOn(catalogingErrorService, 'resetErrorMessages').and.returnValue();
      component.ngOnInit();
      expect(catalogingErrorService.resetErrorMessages).toHaveBeenCalled();
    });

    it('should open the delete catalog sidebar', () => {
      spyOn(component.deleteCatalogSidebarComponent, 'open');
      component.onDeleteCatalogButtonClicked();
      expect(component.deleteCatalogSidebarComponent.open).toHaveBeenCalled();
    });
  });

  describe('on destroy', () => {
    it('should stop autorefresh of schema & catalog data when closing manage catalog sidebar', () => {
      spyOn(window, 'clearInterval').and.stub();
      component.ngOnDestroy();
      expect(window.clearInterval).toHaveBeenCalled();
    });
  });

  describe('Overall status', () => {
    it('sets correctly for null', () => {
      component.setOverallStatus(null);
      expect(component.catalogStatus).toEqual(
        jasmine.objectContaining({
          status: 'NOT_CATALOGED',
          tooltip: 'connections.CATALOG_STATUS.NOT_CATALOGED.TOOLTIP',
          icons: ['png-disabled', 'text-muted']
        })
      );
    });

    it('set correctly for normal catalog status', () => {
      const catalogStatus = {
        status: 'complete',
        schemas: [{ schema: 'test', status: 'complete', lastCompleted: '10/06/2022, 13:01:55' }]
      } as CatalogStatus;
      component.setOverallStatus(catalogStatus);
      expect(component.catalogStatus).toEqual(
        jasmine.objectContaining({
          status: 'COMPLETE',
          tooltip: 'connections.CATALOG_STATUS.COMPLETE.TOOLTIP',
          params: {
            partialNumber: 1,
            totalNumber: 1,
            structureType: 'connections.catalog_status.item_types.schema'
          },
          icons: []
        })
      );
    });

    it('for stopped and with structure, sets the tooltip', () => {
      const catalogStatus = {
        status: 'stopped',
        schemas: [{ schema: 'test', status: 'stopped', lastCompleted: '10/06/2022, 13:01:55' }]
      } as CatalogStatus;
      component.connection.connectionType = 'NOT_KAFKA';
      component.setOverallStatus(catalogStatus);
      expect(component.catalogStatus).toEqual(
        jasmine.objectContaining({
          status: 'STOPPED',
          tooltip: 'connections.CATALOG_STATUS.STOPPED.STRUCTURE_TOOLTIP'
        })
      );
    });

    it('for stopped and with structure, sets the tooltip', () => {
      const catalogStatus = {
        status: 'stopped',
        schemas: [{ schema: 'test', status: 'stopped', lastCompleted: '10/06/2022, 13:01:55' }]
      } as CatalogStatus;
      component.connection.connectionType = 'KAFKA';
      component.setOverallStatus(catalogStatus);
      expect(component.catalogStatus).toEqual(
        jasmine.objectContaining({
          status: 'STOPPED',
          tooltip: 'connections.CATALOG_STATUS.STOPPED.NO_STRUCTURE_TOOLTIP'
        })
      );
    });

    it('structure type returns correctly for different amounts', () => {
      let testSchema = { schema: 'test', status: 'stopped', lastCompleted: '10/06/2022, 13:01:55' };

      component.connection.connectionType = 'DB2';

      component.setOverallStatus({ schemas: [] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.libraries');
      component.setOverallStatus({ schemas: [testSchema] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.library');
      component.setOverallStatus({ schemas: [testSchema, testSchema] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.libraries');

      component.connection.connectionType = 'DB2I';
      component.setOverallStatus({ schemas: [testSchema, testSchema] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.libraries');

      component.connection.connectionType = 'SQLSERVER';
      component.setOverallStatus({ schemas: [] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.databases');
      component.setOverallStatus({ schemas: [testSchema] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.database');

      component.connection.connectionType = 'KAFKA';
      component.setOverallStatus({ schemas: [] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.topics');
      component.setOverallStatus({ schemas: [testSchema] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.topic');

      component.connection.connectionType = 'ORACLE';
      component.setOverallStatus({ schemas: [] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.schemas');
      component.setOverallStatus({ schemas: [testSchema] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.schema');

      component.connection.connectionType = 'OTHER';
      component.setOverallStatus({ schemas: [testSchema] } as CatalogStatus);
      expect(component.catalogStatus.params.structureType).toBe('connections.catalog_status.item_types.schema');
    });
  });
});
