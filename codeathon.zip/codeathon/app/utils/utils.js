(function(window, initComponents, undefined) {
    codeathon = function() {};
    //make Codeathon global
    window.Codeathon = new codeathon();
})(window, function(Codeathon, window, document) {});

(function(window, initComponents, undefined) {
    utils = function() {};

    utils.prototype.isNullOrEmpty = function(obj) {
        return (angular.isUndefined(obj) || obj == null || obj == 'null' || typeof obj == "undefined" || obj == "");
    };

    utils.prototype.resizeDivisions = function() {
        var vph = $(window).height();
        var headerHeight = $('.mainheader').outerHeight(true);
        var footerHeight = $('footer').outerHeight(true);
        vph -= headerHeight + footerHeight;
        $('.content-leftsec').css({
            'min-height': vph
        });
        $('.content-rightsec').css({
            'min-height': vph - 10
        });
    };

    utils.prototype.hideHeaderFooterMenu = function() {
        $('.content-leftsec,.top_header,footer').hide();
        $('.content-rightsec').css({
            'background': '#F4F5F7'
        });

    };

    utils.prototype.showHeaderFooterMenu = function() {
        $('.content-leftsec,.top_header,footer').show();
        $('.content-rightsec').css({
            'background': '#EDEDED'
        });
    };

    utils.prototype.isValidUser = function(data, username, password) {
        var isValid = false;
        if ((data.login == username) && (data.password == password)) {
            isValid = true;
        }
        return isValid;
    };
    /*
        for a givin Key and Value is Presents in data 
        Ex: checking "username":"bharath" into Data Object
    */
    utils.prototype.extractDataByProperty = function(data, propertyName, value) {
        var valueObj = {};
        for (var i = 0; i < data.length; i++) {
            var item = data[i];
            if (!this.isNullOrEmpty(item) && angular.isObject(item)) {
                angular.forEach(item, function(value, key) {
                    if (key == propertyName && value == value) {
                        valueObj = item
                    }
                });
            }
        }
        return valueObj;
    };
    /*
       Converting date formate into "YYYY-MM-DD"
    */
    utils.prototype.formatDate = function(d) {
        var d = new Date(),
            month = '' + (d.getMonth() + 1),
            day = '' + d.getDate(),
            year = d.getFullYear();

        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;

        return [year, month, day].join('-');
    };
    utils.prototype.makeChecked = function(data, chkedObj) {
        var dataObj = [];
        for (var j = 0; j < chkedObj.length; j++) {
            var chked = chkedObj[j];
            for (var i = 0; i < data.length; i++) {
                var item = data[i];
                if (!this.isNullOrEmpty(item) && angular.isObject(item)) {
                    if (item.value == chked) {
                        item.selected = true;
                        break;
                    }
                }
            }
        };
        if (!this.isNullOrEmpty(data) && data.length != 0) {
            dataObj = data;
        }
        return dataObj;
    };
    utils.prototype.makeUnChecked = function(data) {
        var dataObj = [];
        for (var i = 0; i < data.length; i++) {
            var item = data[i];
            if (!this.isNullOrEmpty(item) && angular.isObject(item)) {
                item.selected = false;
            }
        }
        if (!this.isNullOrEmpty(data) && data.length != 0) {
            dataObj = data;
        }
        return dataObj;
    };

    /*
        This is mainly for Drop downs: This will extract by "Propery" and store it in Array
        
        Ex: displayName : Name
          : displayValue : id
        [{id:"1234","name":"Bharath","city":"bangalore"},{id:"54656","name":"John","city":"US"}]
    */
    utils.prototype.getListByProperty = function(data, displayValue, displayName) {
        var valueObj = [];
        var currentObj = this;
        for (var i = 0; i < data.length; i++) {
            var item = data[i];
            if (!this.isNullOrEmpty(item) && angular.isObject(item)) {
                angular.forEach(item, function(value, key) {
                    if (key == displayName && !currentObj.isNullOrEmpty(value)) {
                        var obj = {};
                        obj.value = item[displayValue];
                        obj.label = value;
                        obj.selected = false;
                        valueObj.push(obj);
                    }
                });
            }
        }

        valueObj = _.uniq(valueObj, function(item, key, a) {
            return item.value;
        });
        valueObj = _.uniq(valueObj, function(item, key, a) {
            return item.label;
        });
        return valueObj;
    };

    utils.prototype.setSessionItem = function(propertyName, propertyValue) {
        if ('localStorage' in window && window['localStorage'] !== null) {
            localStorage.setItem(propertyName, propertyValue);
        } else {
            return false;
        }
    };

    utils.prototype.isSessionItemAvailble = function(propertyName) {
        if ('localStorage' in window && window['localStorage'] !== null) {
            return this.isNullOrEmpty(localStorage.getItem(propertyName));
        } else {
            return false;
        }
    };
    utils.prototype.getSessionItem = function(propertyName) {
        if ('localStorage' in window && window['localStorage'] !== null) {
            return localStorage.getItem(propertyName);
        } else {
            return "";
        }
    };
    utils.prototype.removeSessionItem = function(propertyName) {
        if ('localStorage' in window && window['localStorage'] !== null) {
            localStorage.removeItem(propertyName);

        } else {
            return false;
        }
    };


    //make Codeathon global
    window.Codeathon.utils = new utils();
})(window, function(UTILS, window, document) {});
