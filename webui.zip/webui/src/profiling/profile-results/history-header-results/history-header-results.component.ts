import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { EventBusService } from 'core/eventBusService';
import { SharedConstants } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { HistoryDataModel } from 'shared/history-table/history-data-model';
import { ProfileResultsService } from '../profile-results.service';

@Component({
  selector: 'discovery-history-header-results',
  templateUrl: './history-header-results.component.html',
  styleUrls: ['./history-header-results.component.css']
})
export class HistoryHeaderResultsComponent implements OnInit {
  history: HistoryDataModel[];
  activeIndex: number;
  isLoading: boolean;

  constructor(
    private eventBusService: EventBusService,
    private profileResultsService: ProfileResultsService,
    public activatedRoute: ActivatedRoute,
    public toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this.history = [];
    this.getHistory();
    this.activeIndex = 0;
  }

  getHistory() {
    this.isLoading = true;
    const profileID = this.profileResultsService.profileId;
    this.profileResultsService.getProfileHistory(profileID).subscribe(
      (response: any) => {
        this.isLoading = false;
        for (const history of response) {
          this.history.push(
            new HistoryDataModel({
              run: history.runDateTime,
              duration: history.duration,
              status:
                history.status === SharedConstants.STATUS.SUCCESS ||
                history.status === SharedConstants.STATUS.INPROGRESS
                  ? history.status
                  : history.errorMessage,
              id: history.id,
              rowsProcessed: history.rowsProcessed,
              user: history.runByUser
            })
          );
        }
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.isLoading = false;
        if (httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message) {
          this.toastrService.error(httpErrorResponse.error.message);
        }
      }
    );
  }

  openHistorySidebar() {
    // this.eventBusService.emit('HistorySidebarToggle', { flag: true });
  }

  navigateStats(mode: string): void {
    if (mode === SharedConstants.navigationModes.prev && this.activeIndex > 0) {
      this.activeIndex = this.activeIndex - 1;
      this.eventBusService.emit('HistoryResultsNavigation', { runId: this.history[this.activeIndex].id });
    }
    if (mode === SharedConstants.navigationModes.next && this.history[this.activeIndex + 1]) {
      this.activeIndex = this.activeIndex + 1;
      this.eventBusService.emit('HistoryResultsNavigation', { runId: this.history[this.activeIndex].id });
    }
    if (mode === SharedConstants.navigationModes.latest && this.activeIndex > 0) {
      this.activeIndex = 0;
      this.eventBusService.emit('HistoryResultsNavigation', { runId: this.history[this.activeIndex].id });
    }
  }
}
