// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: false,
    fresh_data_expiration_time: 60000,
    uam_timeout_in_seconds_to_show_session_expiring_dialog: 3600,
    uam_timeout_in_seconds_after_dialog_is_shown_before_session_expiration: 60,
    uam_token_refresh_interval_in_minutes: 60,
    uam_userinfo_refresh_interval_in_minutes: 120,
    backend_api_prefix: "http://fijyvvrapp11.eu.bm.net/AIMWare/rs",
    application_url: "https://fijyvvrapp11.eu.bm.net/AIMUI",
    change_pass_word_url: "http://fijyvvrapp11.eu.bm.net/aim/",
    security_base_url: "http://localhost:3000"
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
