import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import PropTypes from 'prop-types'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TablePagination from '@material-ui/core/TablePagination'
import TableRow from '@material-ui/core/TableRow'
import Checkbox from '@material-ui/core/Checkbox'
import DashboardHead from './DashboardHead'
import { getFormatedDate, getStatusFormat, getStatusStyle } from '../common/Utils/CommonUtils'
import NoImage from '../../images/no-image.png'

const styles = theme => ({
  table: {
    minWidth: 1020,
  },
  tableWrapper: {
    overflowX: 'auto',
    padding: '0px 24px 50px 24px',
  },
  deleteIcon: {
    color: '#1976d2',
  },
  navLink: {
    color: '#1976d2',
    curser: 'pointer',
    textDecoration: 'none',
    '&:hover': {
      textDecoration: 'underline',
    },
  },
  cellPadding: {
    padding: '0px 5px',
    cursor: 'pointer',
  },
  cellPaddingCenter: {
    padding: '0px 5px',
    textAlign: 'center',
    cursor: 'pointer',
  },
  groupStateRFL: {
    backgroundColor: '#85D2ED',
    padding: 5,
    fontSize: 10,
  },
  groupStateRFO: {
    backgroundColor: '#FFF7C0',
    padding: 5,
    fontSize: 10,
  },
  groupStateIn: {
    backgroundColor: '#FCBE86',
    padding: 5,
    fontSize: 10,
  },
  groupStateHis: {
    backgroundColor: '#C0BEC1',
    padding: 5,
    fontSize: 10,
  },
  groupPrimaryImgStyle: {
    width: 46,
    height: 46,
    textAlign: 'center',
    margin: '3px 3px 0px 3px',
  },
  deleteBlock: {
    '&:hover': {
      background: 'rgba(0, 0, 0, 0.08)',
    },
  },
  noData: {
    textAlign: 'center',
    fontSize: 28,
    color: '#ff3d00',
    marginTop: 20,
  },
})

export class DashboardTable extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      order: 'DESC',
      orderBy: 'id',
      selected: [],
      page: 0,
      rowsPerPage: 20,
      rowsPerPageOptions: [20, 50, 100],
      data: [],
      originalData: [],
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.items !== this.props.items) {
      this.setState({ data: nextProps.items, originalData: nextProps.items, selected: [] })
    }
  }
  handleChangePage = (event, page) => {
    this.setState({ page })
    const changePageParams = { ...this.props.groupListRequestParams }
    changePageParams.pagination_filter.page = page
    this.props.updateGroupListRequestParams(changePageParams)
    this.props.getGrouperList(changePageParams)
  };

  handleChangeRowsPerPage = event => {
    this.setState({ rowsPerPage: event.target.value })
    const changeRowsPageParams = { ...this.props.groupListRequestParams }
    changeRowsPageParams.pagination_filter.limit = event.target.value
    this.props.updateGroupListRequestParams(changeRowsPageParams)
    this.props.getGrouperList(changeRowsPageParams)
  }

  handleRequestSort = (property) => {
    const orderBy = property
    let order = 'desc'
    if (this.state.orderBy === property && this.state.order === 'desc') {
      order = 'asc'
    }
    const groupListRequestParams = { ...this.props.groupListRequestParams }
    groupListRequestParams.pagination_filter.order = orderBy
    groupListRequestParams.pagination_filter.direction = order.toUpperCase()

    this.setState({ order, orderBy })

    this.props.updateGroupListRequestParams(groupListRequestParams)
    this.props.getGrouperList(groupListRequestParams)

    /* const data =
      order === 'desc'
        ? this.state.data.sort((a, b) => (b[orderBy] < a[orderBy] ? -1 : 1))
        : this.state.data.sort((a, b) => (a[orderBy] < b[orderBy] ? -1 : 1))
      this.setState({ data, order, orderBy })
    */
  };

  isSelected = id => this.state.selected.indexOf(id) !== -1;

  handleDeleteClick = (event, id) => {
    const { selected } = this.state
    const selectedIndex = selected.indexOf(id)
    let newSelected = []

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, id)
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1))
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1))
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1),
      )
    }

    this.setState({ selected: newSelected })
    this.props.deleteSelectedCB(newSelected)
  };

  navToDetailsPage = (groupId) => {
    const detailLink = '/group-details/' + groupId
    this.props.history.push(detailLink)
  }

  render () {
    const { classes } = this.props
    const { order, orderBy, rowsPerPage, rowsPerPageOptions, page, data } = this.state

    if (data.length === 0) {
      return (
        <div className={classes.noData}>No Groups Found</div>
      )
    }
    return (
      <div className={classes.tableWrapper}>
        <TablePagination
          component="div"
          count={this.props.totalListCount}
          rowsPerPage={rowsPerPage}
          page={page}
          rowsPerPageOptions={rowsPerPageOptions}
          backIconButtonProps={{
            'aria-label': 'Previous Page',
          }}
          nextIconButtonProps={{
            'aria-label': 'Next Page',
          }}
          onChangePage={this.handleChangePage}
          onChangeRowsPerPage={this.handleChangeRowsPerPage}
        />
        <Table className={classes.table} aria-labelledby="tableTitle">
          <DashboardHead
            order={order}
            orderBy={orderBy}
            onRequestSort={this.handleRequestSort}
            rowCount={this.props.totalListCount}
          />
          <TableBody>
            {data
              // .sort(sortData(order, orderBy))
              // .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((obj, key) => {
                if (!obj.group_deleted) {
                  const isSelected = this.isSelected(obj.group_id)
                  let GroupPrimaryImage = NoImage
                  if ((obj.image_base_url && obj.image_base_url !== null) && (obj.primary_image && obj.primary_image !== null)) {
                    GroupPrimaryImage = 'https:' + obj.image_base_url + obj.primary_image + '?wid=46&hei=46&qlt=60&fmt=pjpeg'
                  }
                  return (
                    <TableRow
                      hover
                      aria-checked={isSelected}
                      tabIndex={-1}
                      key={key}
                      selected={isSelected}
                    >
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{obj.group_id}</TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{obj.parent_tcin}</TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{obj.group_type}</TableCell>
                      <TableCell padding="dense" className={classes.cellPaddingCenter}>
                        <img src={GroupPrimaryImage} alt="primary" className={classes.groupPrimaryImgStyle} />
                      </TableCell>
                      <TableCell className={classes.cellPadding} onClick={(e) => this.navToDetailsPage(obj.group_id)}><span dangerouslySetInnerHTML={{__html: obj.group_name}} /></TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{obj.department.department_value}</TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{obj.item_type}</TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{obj.no_of_items}</TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{getFormatedDate(obj.last_modified)}</TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}>{getFormatedDate(obj.launch_date)}</TableCell>
                      <TableCell className={classes.cellPaddingCenter} onClick={(e) => this.navToDetailsPage(obj.group_id)}><span className={classes[getStatusStyle(obj.group_state)]}>{getStatusFormat(obj.group_state)}</span></TableCell>
                      {/* <TableCell className={classes.cellPaddingCenter}>
                          <DeleteIcon className={classes.deleteIcon} onClick={event => validateDelete(event, obj.group_id, obj.group_type)} />
                        </TableCell> */}
                      <TableCell padding="checkbox">
                        <Checkbox className={classes.deleteBlock} checked={isSelected} color="default" onClick={event => this.handleDeleteClick(event, obj.group_id)} />
                      </TableCell>
                    </TableRow>
                  )
                }
              })}
          </TableBody>
        </Table>
        <TablePagination
          component="div"
          count={this.props.totalListCount}
          rowsPerPage={rowsPerPage}
          page={page}
          rowsPerPageOptions={rowsPerPageOptions}
          backIconButtonProps={{
            'aria-label': 'Previous Page',
          }}
          nextIconButtonProps={{
            'aria-label': 'Next Page',
          }}
          onChangePage={this.handleChangePage}
          onChangeRowsPerPage={this.handleChangeRowsPerPage}
        />
      </div>
    )
  }
}

DashboardTable.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(DashboardTable)
