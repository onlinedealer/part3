(function() {
    'use strict';
    // Header
    codeathonApp.directive('headerTemplate', ['uiRouters', headerTemplate]);

    function headerTemplate(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/header.html',
            link: function(scope, element, attrs) {
                $('.showMenu').click(function() {
                    $('.dropMenu').show();
                });
                $(document).mousedown(function() {
                    $('.dropMenu').fadeOut(200);
                });
            }
        }
    }
    // Left Nav Menu
    codeathonApp.directive('leftNavMenuTemplate', ['uiRouters', leftNavMenuTemplate]);

    function leftNavMenuTemplate(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/leftNavMenu.html',
            controller: function($scope, $element, $attrs) {
                Codeathon.utils.resizeDivisions();

                $scope.expandMenu = function(e) {
                    if ($(e.currentTarget).hasClass("direct")) {
                        $(e.currentTarget).stop(true, false).animate({
                            width: '268px'
                        }, 200);
                        return false;
                    }
                };

                $scope.collapseMenu = function(e) {
                    if ($(e.currentTarget).hasClass("direct")) {
                        $(e.currentTarget).stop(true, false).animate({
                            width: '60px'
                        }, 200);
                        $('.content-rightsec').stop(true, false).animate({
                            paddingLeft: '75px'
                        }, 200);
                        $('.content-leftsec .submenu ul').hide();
                        return false;
                    } else {
                        $('.content-rightsec').stop(true, false).animate({
                            paddingLeft: '275px'
                        }, 200);
                    }

                };

                $scope.initMenuEvents = function() {
                    $('.reslist-box li').on("click", function() {
                        $(this).toggleClass("active");
                    });

                    // Accordion for Left Menu
                    $('.content-leftsec nav > ul > li > a').on('click', function() {
                        if (!$(this).parent().find('ul').is(":visible")) {
                            $(this).parent().siblings().find("ul").slideUp();
                            $(this).parent().find('ul').slideDown();
                        } else {
                            $(this).parent().find('ul').slideUp();
                        }
                    });

                    //lock left panel 
                    $('.content-leftsec .show-hide').on('click', function() {
                        if ($(this).hasClass("open")) {
                            $(this).parent().addClass("direct");
                            $(this).removeClass("open");
                        } else {
                            $(this).addClass("open");
                            $(this).parent().removeClass("direct");
                        }
                    });

                    if ($('#resigApproval .tableData').innerHeight() > 217) {
                        $('#resigApproval .tableData').css({
                            'height': 217,
                            'overflow': 'auto'
                        });
                        $('#resigApproval .tableHeading').css({
                            'padding-right': '17px'
                        });
                    }
                    if ($('#resigRevoke .tableData').innerHeight() > 93) {
                        $('#resigRevoke .tableData').css({
                            'height': 93,
                            'overflow': 'auto'
                        });
                        $('#resigRevoke .tableHeading').css({
                            'padding-right': '17px'
                        });
                    }

                    if ($('#pendClearance .tableData').innerHeight() > 371) {
                        $('#pendClearance .tableData').css({
                            'height': 371,
                            'overflow': 'auto'
                        });
                        $('#pendClearance .tableHeading').css({
                            'padding-right': '17px'
                        });
                    }
                    // Multi select
                    $('.setMultipleList span').on("click", function() {
                        $(this).next().trigger("click");
                    });

                    $(window).resize(function() {
                        Codeathon.utils.resizeDivisions();
                    });
                }

            },
            link: function(scope, element, attrs) {
                scope.initMenuEvents();
            }
        }
    }
    // Footer
    codeathonApp.directive('footerTemplate', ['uiRouters', footerTemplate]);

    function footerTemplate(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/footer.html'
        }
    }
})();
