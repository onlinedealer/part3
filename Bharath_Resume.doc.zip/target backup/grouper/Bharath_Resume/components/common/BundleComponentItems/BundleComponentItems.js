
import React, { Component } from 'react'
import BundleComponentItemsUpdate from './BundleComponentItemsUpdate'

export default class BundleComponentItems extends Component {
  constructor (props) {
    super(props)
    this.state = {
    }
  }

  handleSelectChange = (name, value) => {
  }

  delComponentItem = (e, value) => {
  }
  render () {
    const { classes } = this.props
    const { errors, delComponentItem } = this.state
    return (
      <div>
        <BundleComponentItemsUpdate
          handleSelectChange={this.handleSelectChange}
          errors={errors}
          classes={classes}
          delComponentItem={delComponentItem}
        />
      </div>
    )
  }
}
