(function() {
    'use strict';

    fileuploader.controller("createTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', createTemplateCtrl]);

    function createTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.uploadpreview = "apps/images/income.jpg";
        $scope.rows = [];

        $scope.onClick = function(event) {
            var x = event.x;
            var y = event.y;
            var offsetX = event.offsetX;
            var offsetY = event.offsetY;
            console.log(offsetX, offsetY);
        };

        $scope.addRow = function() {
            $scope.companies.push({});
            $scope.name = '';
            $scope.employees = '';
            $scope.headoffice = '';
        };

        /*$scope.myImage='';
            $scope.myCroppedImage='';
            $scope.myAreaCoords = {};

            var handleFileSelect=function(evt) {
              var file=evt.currentTarget.files[0];
              var reader = new FileReader();
              reader.onload = function (evt) {
                $scope.$apply(function($scope){
                  $scope.myImage=evt.target.result;
                });
              };
              reader.readAsDataURL(file);
            };
            angular.element(document.querySelector('#fileInput')).on('change',handleFileSelect);

            }*/


        /*// Remember to invoke within jQuery(window).load(...)
        // If you don't, Jcrop may not initialize properly
        $(function() {

            $('#jcrop_target').Jcrop({
                onChange: showPreview,
                onSelect: showPreview,
                onRelease: hidePreview,
                //aspectRatio: 0.7
            });

            var $preview = $('#preview');
            // Our simple event handler, called from onChange and onSelect
            // event handlers, as per the Jcrop invocation above
            function showPreview(coords) {
                if (parseInt(coords.w) > 0) {
                    var rx = 100 / coords.w;
                    var ry = 100 / coords.h;
                    var obj = {};

                    obj["width"] = Math.round(rx * 500);
                    obj["height"] = Math.round(ry * 370);
                    obj["x"] = Math.round(rx * coords.x);
                    obj["y"] = Math.round(ry * coords.y);
                    console.log(obj)

                    $preview.css({
                        width: Math.round(rx * 500) + 'px',
                        height: Math.round(ry * 370) + 'px',
                        marginLeft: '-' + Math.round(rx * coords.x) + 'px',
                        marginTop: '-' + Math.round(ry * coords.y) + 'px'
                    }).show();
                }
            }

            function hidePreview() {
                $preview.stop().fadeOut('fast');
            }

        });*/


    $(function(){
    var tarGet = document.getElementById("target");
    var imgW = tarGet.clientWidth;
    var imgH = tarGet.clientHeight;
    var newW = 200;
    var jcrop_api;
    $('#target').Jcrop({
        /*setSelect: [400, 200, 50, 50], */
        //aspectRatio: 16 / 8,
        onSelect: showCords, 
        onChange: showCords
    }/*, function(){
        jcrop_api = this;
    }*/);
    
    function showCords(c){
        var obj = {};
        obj["x"] = c.x;
        obj["y"] = c.y;
        obj["w"] = c.w;
        obj["h"] = c.h;
        console.log(obj);
        /*$('input[name="x"]').val(c.x);
        $('input[name="y"]').val(c.y);
        $('input[name="w"]').val(c.w);
        $('input[name="h"]').val(c.h);*/
    }
    /*
    $('#imgCon').click(function(e){
        jcrop_api.animateTo([400, 200, 50, 50]);
        return false;
    });
    */
})



    }
})();