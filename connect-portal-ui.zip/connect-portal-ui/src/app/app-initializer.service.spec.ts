import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ProtectedAppInitializerService } from '@precisely/prism-ng/di-suite';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { CheckSessionService } from 'angular-auth-oidc-client/lib/iframe/check-session.service';
import { of } from 'rxjs';
import { AppInitializerService } from './app-initializer.service';

describe('AppInitializerService', () => {
  let service: AppInitializerService;
  let httpClient: HttpClient;

  let OidcSecurityService: OidcSecurityService;
  let CheckSessionService: CheckSessionService;

  const mockCheckSessionService = {
    start() {}
  };

  const mockOidcSecurityService = {
    isAuthenticated() {},
    checkAuth() {}
  };

  const mockConfigRes = {
    authServerUrl: '/auth',
    bearerOnly: true,
    cors: true,
    principalAttribute: 'preferred_username',
    publicClient: true,
    realm: 'Precisely',
    resource: 'OIDC-Connect',
    sslRequired: 'external'
  };

  const mockProtectedAppInitializerService = {
    init: () => of(null)
  };

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [
        HttpClient,
        {
          provide: ProtectedAppInitializerService,
          useValue: mockProtectedAppInitializerService
        },
        {
          provide: OidcSecurityService,
          useValue: mockOidcSecurityService
        },
        {
          provide: CheckSessionService,
          useValue: mockCheckSessionService
        }
      ]
    });
    service = TestBed.inject(AppInitializerService);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should initialise application if config call is successfull', fakeAsync(() => {
    spyOn(httpClient, 'get').and.returnValue(of(mockConfigRes));
    service.init();
    tick();
    expect(service.isAppInitialized).toBeTruthy();
  }));
});
