import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../services/utility.service';
import { SeoService } from '../services/seo.service';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {

  serviceUrls:Object;
  loggedInState:string = '-1';

  constructor(public utilityService: UtilityService, private seo:SeoService) {
    seo.addSeoData();
   }

  ngOnInit() {
    this.getServiceUrls();
    console.log('Homepage');
  }

  getServiceUrls(){
      this.utilityService.fetchServiceUrls();
      this.utilityService.serviceUrlsObservable$.subscribe((data) => {
       
        if(!this.utilityService.isEmpty(data) && !data.hasOwnProperty('error')){
          this.loggedInState = data['header']['extracareInfo']['ecstate']

          /*this.serviceUrls = data['config']['serviceUrls'];
          if(this.serviceUrls){              
              
          }*/
        }else if(data.hasOwnProperty('error')){

        }
      });
  }

}
