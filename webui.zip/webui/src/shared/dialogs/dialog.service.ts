import { Injectable } from '@angular/core';
import { NgbModal, NgbModalOptions, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { noop } from '../noop.model';
import { OkComponent } from './ok/ok.component';
import { YesNoCancelComponent } from './yesnocancel/yes-no-cancel.component';
import { YesnoComponent } from './yesno/yesno.component';

/**
 * Service for displaying basic ok, yes/no dialogs.
 */
@Injectable({
  providedIn: 'root'
})
export class DialogService {
  private modalRef: NgbModalRef;
  private options: NgbModalOptions = {
    windowClass: 'pb-modal',
    backdrop: 'static'
  };

  /**
   * @internal
   */
  constructor(private modal: NgbModal) {}

  /**
   * Show a simple ok dialog.
   * @param title The title to show in the modal header.  Typically a translation id.
   * @param message The message to show in the modal body.  Typically a translation id.
   * @param titleParams  ngx-translate variables for the title string.
   * @param messageParams ngx-translate variables for the message string.
   */
  ok(
    title: string,
    message: string,
    titleParams?: Record<string, string>,
    messageParams?: Record<string, string>
  ): Promise<any> {
    // Only allow one active modal at a time.
    if (this.modalRef) {
      return;
    }

    this.modalRef = this.modal.open(OkComponent, this.options);
    const component: OkComponent = this.modalRef.componentInstance;
    component.title = title;
    component.titleParams = titleParams;
    component.message = message;
    component.messageParams = messageParams;

    return this.modalRef.result.then(
      () => this.onClose(),
      () => this.onClose()
    );
  }

  /**
   * Show a simple Yes No dialog.
   * @param title The title to show in the modal header.  Typically a translation id.
   * @param message The message to show in the modal body.  Typically a translation id.
   * @param titleParams  ngx-translate variables for the title string.
   * @param messageParams ngx-translate variables for the message string.
   */
  yesno(
    title: string,
    message: string,
    titleParams?: Record<string, string>,
    messageParams?: Record<string, string>
  ): Promise<any> {
    const yesnoModalRef: NgbModalRef = this.modal.open(YesnoComponent, this.options);
    const component: YesnoComponent = yesnoModalRef.componentInstance;
    component.title = title;
    component.titleParams = titleParams;
    component.message = message;
    component.messageParams = messageParams;

    return yesnoModalRef.result;
  }

  /**
   * Show a simple Yes No cancel dialog.
   * @param title The title to show in the modal header.  Typically a translation id.
   * @param message The message to show in the modal body.  Typically a translation id.
   * @param titleParams  ngx-translate variables for the title string.
   * @param messageParams ngx-translate variables for the message string.
   */
  yesNoCancel(
    title: string,
    message: string,
    titleParams?: Record<string, string>,
    messageParams?: Record<string, string>
  ): Promise<any> {
    const yesnocancelModalRef: NgbModalRef = this.modal.open(YesNoCancelComponent, this.options);
    const component: YesnoComponent = yesnocancelModalRef.componentInstance;
    component.title = title;
    component.titleParams = titleParams;
    component.message = message;
    component.messageParams = messageParams;
    return yesnocancelModalRef.result;
  }

  /**
   * Show a simple standard unsaved changes dialog with Yes No dialog.
   */
  unsavedChanges(): Promise<boolean | void> {
    return this.yesno('pb.modal.discardChangesTitle', 'pb.modal.discardChangesMsg', undefined).then(
      (status: string) => status === 'yes',
      noop
    );
  }

  private onClose(): void {
    this.modalRef = undefined;
  }
}
