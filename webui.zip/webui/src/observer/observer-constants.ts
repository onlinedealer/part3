export class ObserverConstants {
  public static OBSERVER_CONFIGURE_STEPS = {
    SOURCE: 'source',
    FINALIZE: 'finalize',
    OBSERVER_RULES: 'Observer Rules'
  };
  public static RULE_METRIC_TYPES = {
    DATA_DRIFT: 'Data Drift',
    VOLUME: 'Volume'
  };

  public static RULE_CONFIG_VOLUME_TYPES = {
    THRESHOLD: 'threshold',
    CONFIDENCE: 'confidence'
  };

  public static RULE_CONFIG_KEYS = {
    VOLUME_CONFIG: 'volumeConfig',
    DATA_DRIFT_CONFIG: 'dataDriftConfig'
  };
  public static OBSERVERNAMEMAXLENGTH: number = 50;

  public static DATA_VOLUME_NO_ALERT_STRINGS = {
    NORED: 'No red',
    RED: 'Red',
    NOYELLOW: 'No yellow',
    YELLOW: 'Yellow'
  };
}
