import { Component, OnInit, ViewChild, AfterViewInit, DoCheck, ChangeDetectorRef, OnDestroy, ElementRef } from '@angular/core';
import { ActivatedRoute, Router, NavigationStart, NavigationEnd } from '@angular/router';
import { CardDetailsComponent } from '../card-details/card-details.component';
import { PaymentSubscriptionComponent } from '../payment-subscription/payment-subscription.component';
import { AddressDetailsComponent } from 'address-details-module';
import { AjaxUtilityService } from '../../shared/utility/ajax-utility.service';
import { HttpResponse, HttpParams } from '@angular/common/http';
import { ActiveModelService } from '../../shared/models/active-model.service';
import { DigitalProfileModel } from '../../shared/models/digital-profile-model';
import { ModalOpenerService } from '../../shared/utility/modal-opener.service';
import { TermsAndConditionsModalComponent } from '../../terms-and-conditions-modal/terms-and-conditions-modal.component';
import * as _ from 'underscore';
import { UtilityService } from '../../shared/utility/utility.service';
import { FormValidationComponent } from '../../shared/components/form-validation/form-validation.component';
import { ClubConstantsService } from '../../shared/utility/club-constants.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ClubGenericErrorComponent } from '../../shared/components/club-generic-error/club-generic-error.component';
import 'rxjs/add/operator/pairwise';
import 'rxjs/add/operator/filter';
import { CarepassErrorBannerComponent } from '../../shared/components/carepass-error-banner/carepass-error-banner.component';
import { DomSanitizer } from '@angular/platform-browser';
import { UtagService } from 'utag-module';
import { Title, Meta } from '@angular/platform-browser';
import { RouteConfigurations } from '../../shared/utility/club-constants.service';
@Component({
  selector: 'app-payment-billing',
  templateUrl: './payment-billing.component.html',
  styleUrls: ['./payment-billing.component.scss']
})
export class PaymentBillingComponent implements OnInit, AfterViewInit, DoCheck, OnDestroy {

  @ViewChild(AddressDetailsComponent) billingAddressComp: AddressDetailsComponent;
  @ViewChild(CardDetailsComponent) cardDetailsComp: CardDetailsComponent;
  @ViewChild(PaymentSubscriptionComponent) paymentDetailsComp: PaymentSubscriptionComponent;
  @ViewChild('invalidClientBanner') invalidClientBanner: ElementRef;
  @ViewChild('invalidServiceBanner') invalidServiceBanner: ElementRef;

  digitalProfile: DigitalProfileModel;
  agreement: boolean;
  isSubmitted: boolean;
  dashboardData: object;
  rxLinked: boolean;
  clubPaymentDetails: any = [];
  serviceError = false;
  businessContent: any;
  businessContentPayment: any;
  paymentBillingErrors: any;
  paymentBillingContent: any;
  paymentBillingErrorBanner: boolean;
  paymentFormGroup: FormGroup;
  agreementForm: any;
  statusMsg = {
    'hasError': false,
    'msg': '',
    'msgDetails': null,
    'id': null
  };
  orderSummary: any = {
    'orderSubtotal': 0,
    'estimatedTax': 0,
    'orderTotal': 0
  };
  calcTaxReq = {
    'calculateTaxRequest': {
      'addressInfo': {},
      'itemInfo': [],
      'requestType': 'clubSubscription'
    }
  };
  selectedCardIndex: number;

  constructor(private _ajaxUtility: AjaxUtilityService,
    private _activeModel: ActiveModelService,
    private _route: ActivatedRoute,
    private _cd: ChangeDetectorRef,
    private _modalService: ModalOpenerService,
    private _ajaxUtilityService: AjaxUtilityService,
    private _utility: UtilityService,
    private _constants: ClubConstantsService,
    private _fb: FormBuilder,
    private _router: Router,
    private _sanitizer: DomSanitizer,
    private _utag: UtagService,
    private _title: Title,
    private _meta: Meta
  ) {
    _title.setTitle(RouteConfigurations.clubPaymentBillingDetailsTitle);
    _meta.removeTag("name='description'");    
    _meta.addTag({ name: 'description', content: RouteConfigurations.carepassPaymentDesc });
  }

  ngOnInit() {
    this.fetchProfile();
    this.agreementForm = this._fb.group({
      paymentCancellation: ['', [Validators.requiredTrue]],
      agreement: ['', [Validators.requiredTrue]]
    });
    this.paymentBillingErrors = this._constants.getBillingPayErrorMessages();
    this.paymentBillingContent = this._constants.getBillingPayContent();
    this._activeModel.setPaymentConstants(this.paymentBillingContent);

    // BCC call to fetch banner and subscription details

    this.fetchPaymentContent(this._utility.getUserAgent().indexOf('_MOBILE') !== -1 ? '30438' : '30439');
  }


/**
   * @method fetchPageContent - method to make BCC service call
   * @param contentId - BCC content id
   */

  fetchPaymentContent(contentId) {
    this._ajaxUtility.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            this.businessContentPayment = JSON.parse(this._utility.getDecrypted(response.details.slotContent));
            try {
              this.businessContentPayment.paymentBanner = this._sanitizer.bypassSecurityTrustHtml(this.businessContentPayment.paymentBanner);
            } catch (error) {
            }
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }


  calculateTaxDefault() {
    if (this._activeModel.getProfile()) {

        const calcTaxReqObj = _.clone(this.calcTaxReq);

        if (this.clubPaymentDetails && this.clubPaymentDetails.length && this.billingAddressComp.isAddressChecked) {
          let enrolledCardIndex = 0;
          _.map(this.clubPaymentDetails, function(card, index) {
            if (card['defaultCard']) {
              enrolledCardIndex = index;
            }
          });
          calcTaxReqObj.calculateTaxRequest.addressInfo = _.pick(
            this.clubPaymentDetails[enrolledCardIndex],
          'firstName',
          'lastName',
          'address1',
          'address2',
          'city',
          'state',
          'postalCode'
        );
        calcTaxReqObj.calculateTaxRequest.addressInfo['zipCode'] = calcTaxReqObj.calculateTaxRequest.addressInfo['postalCode'];
        calcTaxReqObj.calculateTaxRequest.addressInfo = _.omit(calcTaxReqObj.calculateTaxRequest.addressInfo, 'postalCode');
        } else {
          calcTaxReqObj.calculateTaxRequest.addressInfo['firstName'] = this.billingAddressComp.addNewBillingAddressForm.get('firstName').value;
          calcTaxReqObj.calculateTaxRequest.addressInfo['lastName'] = this.billingAddressComp.addNewBillingAddressForm.get('lastName').value;
          calcTaxReqObj.calculateTaxRequest.addressInfo['address1'] = this.billingAddressComp.addNewBillingAddressForm.get('address1').value;
          calcTaxReqObj.calculateTaxRequest.addressInfo['address2'] = this.billingAddressComp.addNewBillingAddressForm.get('address2').value;
          calcTaxReqObj.calculateTaxRequest.addressInfo['city'] = this.billingAddressComp.addNewBillingAddressForm.get('city').value;
          calcTaxReqObj.calculateTaxRequest.addressInfo['state'] = this.billingAddressComp.addNewBillingAddressForm.get('state').value;
          calcTaxReqObj.calculateTaxRequest.addressInfo['zipCode'] = this.billingAddressComp.addNewBillingAddressForm.get('zipCode').value;
        }

      if (this._activeModel.getSubscription()) {
        setTimeout(() => {
          const priceObj = _.pick(
            this.paymentDetailsComp.selectedSubscription,
            'subscriptionPrice'
          );
          priceObj.subscriptionPrice = priceObj.subscriptionPrice.toString();
          calcTaxReqObj.calculateTaxRequest.itemInfo[0] = _.omit(
            _.extend(
              {},
              this.paymentDetailsComp.selectedSubscription,
              this._activeModel.getSubscription()[this.paymentDetailsComp.subscriptionDetailsForm.get('subscriptionRadio').value],
              {'quantity': 1, 'price': priceObj.subscriptionPrice}
            ),
            'subscriptionType',
            'subscriptionSubtext',
            'subscriptionText',
            'subscriptionPrice',
            'listPrice',
            'displayPriority',
            this._activeModel.getSubscription()[this.paymentDetailsComp.subscriptionDetailsForm.get('subscriptionRadio').value]['discount'] > 0
            ? '' : 'discount'
          );
          if (calcTaxReqObj.calculateTaxRequest.addressInfo['firstName']){
            this.calculateTaxSubscription(calcTaxReqObj);
          }
        });
      }
    }
  }

  ngAfterViewInit() {
    // setTimeout(() => {
    //   this.calculateTaxDefault();
    // });
  }

  ngDoCheck() {
     if (this.paymentDetailsComp && this.paymentDetailsComp.hasOwnProperty('selectedSubscription')) {
      this.orderSummary.orderSubtotal = this.paymentDetailsComp.selectedSubscription['subscriptionPrice'];
      this.orderSummary.orderSubtotal = parseFloat(this.orderSummary.orderSubtotal);
      this.orderSummary.orderTotal = this.orderSummary.orderSubtotal + this.orderSummary.estimatedTax;
     }
  }

  submitPayment() {

    // utag.link call on click of submit payment button
    this._utag.link({
      'page_name': 'carepass:submit payment button',
      'link_name': 'custom:carepass:submit payment button'
    });

    this.statusMsg = {
      'hasError': false,
      'msg': '',
      'msgDetails': null,
      'id': null
    };
    this.isSubmitted = true;
    const digitalProfile = this._activeModel.getProfile();
    const addressDetails = this.billingAddressComp.addNewBillingAddressForm;
    this.paymentFormGroup = _.extend({}, this.billingAddressComp.addNewBillingAddressForm);
    this.assignErrorClasses(this.cardDetailsComp.cardDetailsForm);
    this.assignErrorClasses(this.agreementForm);
    this.paymentFormGroup['controls'] = _.extend(
      {},
      this.billingAddressComp.addNewBillingAddressForm['controls'],
      (this.clubPaymentDetails.length && !this.cardDetailsComp.addCard) ? this.cardDetailsComp.cardDetailsForm['controls'] : '',
      this.agreementForm['controls']
    );
    // this.paymentFormGroup = _.pick(this.billingAddressComp.addNewBillingAddressForm, 'controls');
    this.billingAddressComp.validateAdressDetailsForm();
    this.cardDetailsComp.validateCardDetailsForm();
    if (this.agreementForm.get('paymentCancellation').value
    && this.agreementForm.get('agreement').value
    && this.billingAddressComp.addNewBillingAddressForm.valid
    && ((this.clubPaymentDetails.length && !this.cardDetailsComp.addCard) ? this.cardDetailsComp.cardDetailsForm.valid : true)) {
      this.paymentBillingErrorBanner = false;
      this.cardDetailsComp.passSubscriptionData(digitalProfile, addressDetails, this.paymentDetailsComp.selectedSubscription);
      if (this.cardDetailsComp.addCard || this.clubPaymentDetails.length === 0) {
        this.cardDetailsComp.callVantive();
      }else {
        this.cardDetailsComp.updateExistingCardInfo();
      }
    } else {
        this.paymentBillingErrorBanner = true;
        // document.getElementById('invalidClientBanner').focus();
        this.invalidClientBanner.nativeElement.focus();
    }
  }

  fetchProfile() {
    this._route.data.subscribe(
      (data: { profile: any }) => {
        let response;
        if (data.hasOwnProperty('profile') && data.profile.hasOwnProperty('getDigitalProfileResponse')) {
          response = data['profile']['getDigitalProfileResponse'];
          if (response.hasOwnProperty('header') && response.header.hasOwnProperty('statusCode') && '0000' === response.header.statusCode) {
            this.dashboardData = response.additionalDetails;
            this._activeModel.setProfile(this.digitalProfile = new DigitalProfileModel(this.dashboardData));
            this.rxLinked = this.digitalProfile.rxTied;
            if (this.digitalProfile.hasOwnProperty('cardList') && this.digitalProfile.cardList.length) {
              this.clubPaymentDetails = _.filter(this.digitalProfile.cardList, function(card) {
                return !card['fSACard'];
              });
            }
          } else {
            this.serviceError = true;
          }
        } else {
          this.serviceError = true;
        }
      },
      (err) => {
        console.error(err);
        this.serviceError = true;
      }
    );
  }

  calculateTax() {
    this._ajaxUtility.sendRequest('calculateTax', this.calcTaxReq).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            this.orderSummary.estimatedTax = response.taxResponse.totalTax;
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }

  calculateTaxCall(event) {
    this.calcTaxReq.calculateTaxRequest.addressInfo = _.omit(
      this.billingAddressComp.addNewBillingAddressForm.value,
      'savedAddress'
    );
    const priceObj = _.pick(
      this.paymentDetailsComp.selectedSubscription,
      'subscriptionPrice'
    );
    priceObj.subscriptionPrice = priceObj.subscriptionPrice.toString();
    this.calcTaxReq.calculateTaxRequest.itemInfo[0] = _.omit(
      _.extend(
        {},
        this.paymentDetailsComp.selectedSubscription,
        this._activeModel.getSubscription()[this.paymentDetailsComp.subscriptionDetailsForm.get('subscriptionRadio').value],
        {'quantity': 1, 'price': priceObj.subscriptionPrice}
      ),
      'subscriptionType',
      'subscriptionSubtext',
      'subscriptionText',
      'subscriptionPrice',
      'listPrice',
      'displayPriority',
      this._activeModel.getSubscription()[this.paymentDetailsComp.subscriptionDetailsForm.get('subscriptionRadio').value]['discount'] > 0
      ? '' : 'discount'
    );
    if (event) {
      this.calculateTax();
    }
  }

  changeTaxSubscription(subscriptionChange) {
    if (subscriptionChange) {
      this.calculateTaxDefault();
    }
  }

  calculateTaxSubscription(req) {
    if (req) {
      this.calcTaxReq = req;
      this.calculateTax();
    }
  }

  subscriptionServiceError(event) {
    if (event) {
        this.serviceError = event;
        this._cd.detectChanges();
    }
  }

  openAgreementModal() {
    this.fetchPageContent('30454');
  }

  openTermsModal() {
    if (this.businessContent) {
      this._modalService.openModal(TermsAndConditionsModalComponent,
        { windowClass: 'terms-conditions-modal' },
        this.businessContent).result.then(
        (result) => {},
        (reason) => {}
      );
    }
  }
  /**
   * @method fetchPageContent - method to make BCC service call
   * @param contentId - BCC content id
   */

  fetchPageContent(contentId) {
    this._ajaxUtilityService.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            try {
              this.businessContent = this._sanitizer.bypassSecurityTrustHtml(this._utility.getDecrypted(response.details.slotContent));
              this.openTermsModal();
            } catch (error) {}
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }

  errorStatusMsg (event) {
    if (event) {
      this.statusMsg['hasError'] = true;
      this.statusMsg['msg'] = event['msg'];
      this.statusMsg['msgDetails'] = event['msgDetails'];
      this.statusMsg['id'] = event['id'];
      // window.scrollTo(0, 0);
      // document.getElementById('invalidServiceBanner').focus();
      this.invalidServiceBanner.nativeElement.focus();
    }
  }


    /* This function will check form fields for errors and assign a class to them
  but only on submit and not on keypress */

  assignErrorClasses(formObj) {
    for (const controlObjKey of Object.keys(formObj.controls)) {
      formObj['controls'][controlObjKey]['visited'] = false;
      if (formObj['controls'][controlObjKey]['errors'] !== null) {
        formObj['controls'][controlObjKey]['custErrors'] = {};
        formObj['controls'][controlObjKey]['errorState'] = true;
        if (formObj['controls'][controlObjKey]['errors']['required']) {
          formObj['controls'][controlObjKey]['custErrors'] = { 'emptyError': true };
        } else {
          if (formObj['controls'][controlObjKey]['errors']['pattern'] || formObj['controls'][controlObjKey]['errors']['email']) {
            formObj['controls'][controlObjKey]['custErrors'] = { 'patternError': true };
          }
        }
      } else {
        formObj['controls'][controlObjKey]['errorState'] = false;
      }
    }
  }

  selectedCard(event) {
      this.selectedCardIndex = event;
      if (!this.billingAddressComp.isAddressChecked) {
        this.billingAddressComp.updateSelectedAddress(event);
      } else {}
  }

  ngOnDestroy() {
    this._cd.detach();
  }
}
