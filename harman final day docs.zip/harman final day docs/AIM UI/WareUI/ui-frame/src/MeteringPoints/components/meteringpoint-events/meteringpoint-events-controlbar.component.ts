import { Component, Output, EventEmitter, Input } from "@angular/core";
import { MatRadioChange } from "@angular/material/radio";

@Component({
    selector: "landisgyr-meteringpoint-events-controlbar",
    templateUrl: "./meteringpoint-events-controlbar.component.html",
    styleUrls: ["./meteringpoint-events-controlbar.component.scss"]
})
export class MeteringpointEventsControlbarComponent {
    @Input()
    selectedEventsType!: string;

    @Input()
    eventsTimeRange!: { from: number; until: number };

    @Input()
    eventsTimeRangeRadio!: string;

    @Output()
    eventsTypeChange = new EventEmitter<string>();

    @Output()
    timeRangeChange = new EventEmitter<{ from: number; until: number }>();

    @Output()
    timeRangeRadioChange = new EventEmitter<string>();

    onRadioChanged(event: MatRadioChange) {
        this.timeRangeRadioChange.emit(event.value);
    }

    onTimePeriodChanged(timePeriod: { from: number; until: number }) {
        this.timeRangeChange.emit(timePeriod);
    }
}
