import { Component, Output, EventEmitter, Input } from "@angular/core";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { SecondarySideviewActions, MeteringPointsActions, MeteringPointsUIActions, RefreshDataActions } from "../../../store/actions";
import { Store } from "@ngrx/store";

@Component({
    selector: "landisgyr-ss-wrapper",
    templateUrl: "ss-wrapper.component.html",
    styleUrls: ["./ss-wrapper.component.scss"]
})
export class SSWrapperComponent {
    @Input()
    backSegment!: string;

    @Output()
    selfDestruct = new EventEmitter();

    animateHide = false;

    constructor(protected store: Store<MeteringPointsFeatureState>) {}

    onSelfDestruct(callback?: Function): void {
        this.store.dispatch(SecondarySideviewActions.CloseTopSecondarySideview({ backSegment: this.backSegment }));
        this.animateHide = true;
        setTimeout(() => {
            this.selfDestruct.emit();
            if (callback) {
                callback();
            }
        }, 300);
    }

    onClickCloseButton() {
        this.onSelfDestruct(() => this.store.dispatch(MeteringPointsActions.DeselectAllMeteringPoints()));
    }

    onRefreshComponentData(isRefreshClicked: boolean) {
        if (isRefreshClicked) {
            this.store.dispatch(RefreshDataActions.LoadRefreshData());
        }
    }
}
