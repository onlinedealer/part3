import { SeqNumPipe } from './seq-num.pipe';

describe('SeqNumPipe', () => {
  it('create an instance', () => {
    const pipe = new SeqNumPipe();
    expect(pipe).toBeTruthy();
  });
});
