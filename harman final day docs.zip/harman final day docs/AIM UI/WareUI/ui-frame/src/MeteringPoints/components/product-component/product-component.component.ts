import { Component, Input } from "@angular/core";
import { Metering } from "../../models/metering.model";
import { TranslationsService } from "../../../app/services/translations-service";

@Component({
    selector: "landisgyr-product-component",
    templateUrl: "./product-component.component.html",
    styleUrls: ["./product-component.component.scss"]
})
export class ProductComponentComponent {
    @Input() productComponentMeterings!: Metering[];

    constructor(public translations: TranslationsService) {}
}
