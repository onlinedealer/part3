import { Spies } from 'discovery-test';
import { ProfileRuleOptionModel } from 'profiling/profile-rule-option.model';

import { ChipsOptionComponent } from './chips-option.component';

describe('ChipsOptionComponent', () => {
  let component: ChipsOptionComponent;

  beforeEach(async () => {
    Spies.init();
    component = new ChipsOptionComponent(Spies.TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('test onAdd(). MultiChar value', () => {
    //Existing list
    component.editableList = [];
    component.editableList.push('a');
    component.editableList.push('b');
    component.editableList.push('c');

    //New value entered gets pushed to editable list since it has been bind
    //and then callback onAdd() triggered with event containing the same value
    component.editableList.push('DUMMY');
    const event = { originalEvent: KeyboardEvent, value: 'DUMMY' };
    component.onAdd(event);

    expect(component.errorMsg).not.toEqual('');
    expect(component.errorMsg.length).toBeGreaterThan(0);
    expect(component.editableList.length).toEqual(3);
  });

  it('test onAdd(). Duplicate value', () => {
    //Existing list
    component.editableList = [];
    component.editableList.push('a');
    component.editableList.push('b');
    component.editableList.push('c');

    //New value entered gets pushed to editable list since it has been bind
    //and then callback onAdd() triggered with event containing the same value
    component.editableList.push('a');
    const event = { originalEvent: KeyboardEvent, value: 'a' };
    component.onAdd(event);
    expect(component.errorMsg).not.toEqual('');
    expect(component.errorMsg.length).toBeGreaterThan(0);
    expect(component.editableList.length).toEqual(3);
  });

  it('test onAdd() success', () => {
    spyOn(component.configuredOptionValuesChange, 'emit');

    component.ruleConfigOption = new ProfileRuleOptionModel();
    component.ruleConfigOption.id = 'dummyId';

    //Existing list
    component.editableList = [];
    component.editableList.push('a');
    component.editableList.push('b');
    component.editableList.push('c');

    //New value entered gets pushed to editable list since it has been bind
    //and then callback onAdd() triggered with event containing the same value
    component.editableList.push('d');
    const event = { originalEvent: KeyboardEvent, value: 'd' };
    component.onAdd(event);

    expect(component.errorMsg).toEqual('');
    expect(component.editableList.length).toEqual(4);
    expect(component.configuredOptionValues.get(component.ruleConfigOption.id)).toEqual('abcd');
    expect(component.configuredOptionValuesChange.emit).toHaveBeenCalled();
  });

  it('test reset()', () => {
    spyOn(component.configuredOptionValuesChange, 'emit');

    //Default values list
    const defaultValues = 'abc';

    component.ruleConfigOption = new ProfileRuleOptionModel();
    component.ruleConfigOption.defaultOptionValue = defaultValues;

    component.editableList = [];
    component.editableList.push('x');
    component.editableList.push('y');

    component.reset();

    expect(component.errorMsg).toEqual('');
    expect(component.editableList.length).toEqual(3);
    expect(component.editableList.join('')).toEqual(defaultValues);
    expect(component.configuredOptionValuesChange.emit).toHaveBeenCalled();
  });

  it('test showRuleSettingsSideBar setter when user has not configured yet', () => {
    //Default values list
    const defaultValues = 'abc';

    component.ruleConfigOption = new ProfileRuleOptionModel();
    component.ruleConfigOption.defaultOptionValue = defaultValues;

    component.showRuleSettingsSideBar = true;
    expect(component.editableList).toEqual(defaultValues.split(''));
  });

  it('test showRuleSettingsSideBar setter when user has already configured once and trying to re-configure', () => {
    //Default values list
    const defaultValues = 'abc';
    const configuredValues = 'bcyz';

    component.ruleConfigOption = new ProfileRuleOptionModel();
    component.ruleConfigOption.defaultOptionValue = defaultValues;
    component.ruleConfigOption.configuredOptionValue = configuredValues;

    component.showRuleSettingsSideBar = true;
    expect(component.editableList).toEqual(configuredValues.split(''));
  });
});
