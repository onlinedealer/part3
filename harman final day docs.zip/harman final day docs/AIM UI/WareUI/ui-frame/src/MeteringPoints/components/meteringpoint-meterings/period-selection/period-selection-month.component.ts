import {
    Component,
    ChangeDetectionStrategy,
    Input,
    ViewChild,
    ElementRef,
    EventEmitter,
    Output,
    OnDestroy,
    SimpleChanges,
    OnChanges,
    OnInit
} from "@angular/core";
import { debounceTime, filter } from "rxjs/operators";
import { FormControl } from "@angular/forms";
import { Subscription, Observable } from "rxjs";
import * as moment from "moment";
import { DateAdapter, _countGroupLabelsBeforeOption, _getOptionScrollPosition } from "@angular/material/core";
import { MatAutocomplete, AUTOCOMPLETE_OPTION_HEIGHT, AUTOCOMPLETE_PANEL_HEIGHT } from "@angular/material/autocomplete";

const NUMBER_OF_YEARS_FOR_SELECTION = 6;

interface YearMonthValues {
    year: number;
    values: { view: string; year: number; month: number }[];
}

@Component({
    selector: "landisgyr-period-selection-month",
    templateUrl: "./period-selection-month.component.html",
    styleUrls: ["./period-selection.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PeriodSelectionMonthComponent implements OnChanges, OnDestroy {
    constructor(private landisGyrDateDapter: DateAdapter<moment.Moment>) {}
    static newScrollPosition: number;
    static scrollToItemMetering: number;
    static scrollToItemPrepayment: number;
    static scrollToItemTokenlog: number;
    @ViewChild("monthInput", { static: true }) input!: ElementRef<HTMLInputElement>;
    @ViewChild("monthInputDropdown", { static: true }) inputDropdown!: MatAutocomplete;
    @Input()
    disabled = false;
    @Input() tab!: string;
    @Input()
    from!: number;

    @Input()
    until!: number;

    @Output()
    timePeriodChange = new EventEmitter<{ from: number; until: number }>();

    monthOptions: any[] = this.getMonthOptions();
    monthOptionsTemp: any[] = this.monthOptions;
    monthInputControl = new FormControl({ value: "", disabled: this.disabled });
    scrollToItem!: number;

    selectedMonth!: number;
    selectedYear!: number;
    optionHeight = AUTOCOMPLETE_OPTION_HEIGHT;
    panelHeight = AUTOCOMPLETE_PANEL_HEIGHT;
    monthNames = this.landisGyrDateDapter.getMonthNames("long");

    private monthInputValueChanges$: Observable<any> = this.monthInputControl.valueChanges.pipe(
        debounceTime(200),
        filter((value) => value && value.view && value.year && value.month >= 0)
    );

    private monthInputChangeSubscription: Subscription = this.monthInputValueChanges$.subscribe((value) => {
        const monthMoment = moment(`${value.year}-01-01`).add(value.month, "month");
        const from = monthMoment.startOf("month").valueOf();
        const until = monthMoment.endOf("month").valueOf();

        if (from !== this.from || until !== this.until) {
            this.timePeriodChange.emit({
                from,
                until
            });
        }
    });

    ngOnChanges(changes: SimpleChanges) {
        if (this.inputDropdown) {
            if (this.tab === "metering") {
                this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemMetering);
            }
            if (this.tab === "prepayment") {
                this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemPrepayment);
            }
            if (this.tab === "tokenlog") {
                this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemTokenlog);
            }
        }
        if (this.from && this.until) {
            const endMoment = moment(this.until);
            const nowMoment = moment();
            const momentToUse = endMoment.isBefore(nowMoment) ? endMoment : nowMoment;

            const year = momentToUse.year();
            const month = momentToUse.month();
            this.selectedMonth = month;
            this.selectedYear = year;
            this.monthInputControl.setValue({
                year,
                month,
                view: `${this.monthNames[month]}-${year}`
            });
        }

        if (this.disabled) {
            this.monthInputControl.disable();
        } else {
            this.monthInputControl.enable();
        }
    }
    selected(event: any, selectedItem: any) {
        let index = 0;
        const list = this.inputDropdown.options;
        if (event.source.selected) {
            list.forEach((element, i) => {
                if (selectedItem.view === element.value.view) {
                    index = i;
                }
            });
            const labelCount = _countGroupLabelsBeforeOption(index, this.inputDropdown.options, this.inputDropdown.optionGroups);
            if (index === 0 && labelCount === 1) {
                this.inputDropdown._setScrollTop(0);
                PeriodSelectionMonthComponent.newScrollPosition = 0;
            } else {
                PeriodSelectionMonthComponent.newScrollPosition = _getOptionScrollPosition(
                    index + labelCount,
                    this.optionHeight,
                    this.inputDropdown._getScrollTop(),
                    this.panelHeight
                );
            }
            if (this.tab === "metering") {
                PeriodSelectionMonthComponent.scrollToItemMetering = PeriodSelectionMonthComponent.newScrollPosition;
                this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemMetering);
            }
            if (this.tab === "prepayment") {
                PeriodSelectionMonthComponent.scrollToItemPrepayment = PeriodSelectionMonthComponent.newScrollPosition;
                this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemPrepayment);
            }
            if (this.tab === "tokenlog") {
                PeriodSelectionMonthComponent.scrollToItemTokenlog = PeriodSelectionMonthComponent.newScrollPosition;
                this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemTokenlog);
            }
            this.scrollToItem = PeriodSelectionMonthComponent.newScrollPosition;
        }
    }

    filterData() {
        const searchText = this.input.nativeElement.value.toLocaleUpperCase();
        setTimeout(() => {
            this.input.nativeElement.focus();
        });
        if (searchText) {
            this.monthOptions = this.monthOptionsTemp
                .map((years) => ({ year: years.year, values: this.filterMonths(years.values, searchText) }))
                .filter((monthList) => monthList.values.length > 0);
        } else {
            this.monthOptions = this.getMonthOptions();
        }
    }
    filterMonths(years: any[], searchText: string) {
        const filteredDataArray: { view: string; year: number; month: number }[] = years;
        const filteredMonth: { view: string; year: number; month: number }[] = [];
        filteredDataArray.forEach((element: any) => {
            if (element.view.toLocaleUpperCase().startsWith(searchText)) {
                filteredMonth.push(element);
            } else {
                return undefined;
            }
        });
        return filteredMonth;
    }
    getSelectedValueAsFormattedForTextInput(value: any): string {
        return value.view.replace("-", " ");
    }

    resetInput() {
        this.input.nativeElement.blur();
        this.onInputArrowDownClick();
        this.monthInputControl.setValue({
            year: 0,
            month: 0,
            view: ""
        });
    }
    onOutFocus() {
        if (!this.monthInputControl.value.view) {
            this.monthInputControl.setValue({
                year: this.selectedYear,
                month: this.selectedMonth,
                view: `${this.monthNames[this.selectedMonth]}-${this.selectedYear}`
            });
        }
    }
    trackByFn(index: number) {
        return index;
    }

    onArrowClickBackward(): void {
        const value = this.monthInputControl.value;

        const lastMonth = moment(`${value.year}-01-01`).add(value.month, "month").subtract(1, "month");

        this.monthInputControl.setValue({
            year: lastMonth.year(),
            month: lastMonth.month(),
            view: `${this.monthNames[lastMonth.month()]}-${lastMonth.year()}`
        });
    }

    onArrowClickForward(): void {
        const value = this.monthInputControl.value;

        const endOfThisMonth = moment().endOf("month");
        const nextMonth = moment(`${value.year}-01-01`).add(value.month, "month").add(1, "month");

        if (nextMonth < endOfThisMonth) {
            this.monthInputControl.setValue({
                year: nextMonth.year(),
                month: nextMonth.month(),
                view: `${this.monthNames[nextMonth.month()]}-${nextMonth.year()}`
            });
        }
    }

    onInputEnterKey() {
        this.input.nativeElement.blur();
    }

    onInputArrowDownClick() {
        setTimeout(() => {
            this.input.nativeElement.focus();
            setTimeout(() => {
                if (this.tab === "metering") {
                    this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemMetering);
                }
                if (this.tab === "prepayment") {
                    this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemPrepayment);
                }
                if (this.tab === "tokenlog") {
                    this.inputDropdown._setScrollTop(PeriodSelectionMonthComponent.scrollToItemTokenlog);
                }
            });
        });
    }

    getMonthOptions(): YearMonthValues[] {
        let year = moment();
        const years = [{ year: year.year(), values: this.getValuesForYear(year.year(), year.month() + 1) }];

        for (let i = 1; i < NUMBER_OF_YEARS_FOR_SELECTION; i++) {
            year = year.subtract(1, "y");
            years.push({ year: year.year(), values: this.getValuesForYear(year.year(), 12) });
        }

        return years;
    }

    private getValuesForYear(year: number, numberOfMonths: number): { view: string; year: number; month: number }[] {
        const weeks = [];
        const monthNames = this.landisGyrDateDapter.getMonthNames("long");

        for (let i = numberOfMonths - 1; i >= 0; i--) {
            weeks.push({
                view: monthNames[i] + `-${year}`,
                year: year,
                month: i
            });
        }

        return weeks;
    }

    ngOnDestroy() {
        this.monthInputChangeSubscription.unsubscribe();
    }
}
