import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup, FormControl, FormGroupDirective, FormsModule, ReactiveFormsModule, ControlContainer } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { OrderbyascPipe } from '../../../../shared/pipes/dynamic-dropdown-sort.pipe';
import { Connection } from '../../../shared/connection';
import { Db2FormComponent, DB2_UDB_CONNECTION_PARAMETERS } from './db2-form.component';
import { Server } from '../../../../servers/shared/server';
import { ServiceInjector } from '../../../../shared/services/service.injector';
import { MockConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component.spec';

describe('Db2FormComponent', () => {
  let component: Db2FormComponent;
  let fixture: ComponentFixture<Db2FormComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  const runtimeServer = {
    id: '1',
    hostname: 'test'
  } as Server;

  class mockInjector {
    get() {
      return {};
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule, DropdownModule, CheckboxModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ],
      declarations: [Db2FormComponent, OrderbyascPipe, MockConnectionCredentialsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    ServiceInjector.injector = new mockInjector();
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(Db2FormComponent);
    component = fixture.componentInstance;
    component.selectedRuntimeServer = runtimeServer;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('returning connnection object', () => {
    const dataConnection = {
      accessFromServer: { id: '1' },
      database: 'test',
      parameters: [{ key: DB2_UDB_CONNECTION_PARAMETERS.DB2_UDB_PORT_NO, value: '50000' }]
    } as Connection;

    it('should return connection and set database if control is enabled', () => {
      component.selectedRuntimeServer = runtimeServer;
      component.connection = dataConnection;
      expect(component.db2ConnectionForm.get('database').value).toBe('test');
    });
  });

  it('should return connection', () => {
    component.db2ConnectionForm.patchValue({
      database: 'test',
      testUser: 'user',
      testPassword: 'pwd'
    });
    const connection: Connection = component.getConnection(true);
    expect(connection.database).toBe('test');
  });
});
