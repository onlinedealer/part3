import {
    Component,
    ViewChild,
    Input,
    OnChanges,
    SimpleChanges,
    ElementRef,
    AfterViewChecked,
    OnDestroy,
    OnInit,
    AfterContentChecked
} from "@angular/core";
import * as moment from "moment";
import { TranslationsService } from "../../../app/services/translations-service";
import {
    ChartComponent,
    ApexAxisChartSeries,
    ApexChart,
    ApexPlotOptions,
    ApexXAxis,
    ApexFill,
    ApexDataLabels,
    ApexYAxis,
    ApexGrid,
    ApexTooltip
} from "ng-apexcharts";
import { DateFormatService, DateFormats } from "../../../Shared/services/date-format.service";
import { Subscription } from "rxjs";
import { Store } from "@ngrx/store";
import { State } from "../../../app/store/reducers";
import { getWindowHeight } from "../../../app/store/selectors/ui.selectors";

export interface ChartOptions {
    series: ApexAxisChartSeries;
    chart: ApexChart;
    fill: ApexFill;
    dataLabels: ApexDataLabels;
    grid: ApexGrid;
    yaxis: ApexYAxis;
    xaxis: ApexXAxis;
    plotOptions: ApexPlotOptions;
    tooltip: ApexTooltip;
}

@Component({
    selector: "landisgyr-meteringpoint-events-power-quality-chart",
    templateUrl: "./meteringpoint-power-quality-chart.component.html",
    styleUrls: ["./meteringpoint-power-quality-chart.component.scss"]
})
export class MeteringpointPowerQualityChartComponent implements OnChanges, OnDestroy, OnInit, AfterViewChecked {
    @Input() series!: any;
    @Input() pqiDataLoading!: any;
    @Input() pqiDataRange!: { from: number | undefined; until: number | undefined };
    @Input() pqiChartXAxisFormat!: { dateFormat: string; timeFormat: string };
    @Input() sideViewExpanded!: boolean;
    @ViewChild("chart") chart!: ChartComponent;
    public chartOptions: Partial<ChartOptions>;

    emptySeries!: boolean;
    infoMessage = this.translations.getTranslation("No data available for the selected time period");
    @ViewChild("chartContainer") chartContainer!: ElementRef<HTMLElement>;
    translationsForTooltip = {
        startTime: this.translations.getTranslation("Start time"),
        endTime: this.translations.getTranslation("End time"),
        duration: $localize`:|@@meteringpointEvents.duration:Duration`,
        level: $localize`:|@@meteringpointEvents.level:Level`,
        phase: this.translations.getTranslation("Phase")
    };
    windowHeightSub!: Subscription;
    amountOfDifferentEventTypes = 0;
    initialViewCheckDone = false;

    constructor(public translations: TranslationsService, private dateFormatService: DateFormatService, private store: Store<State>) {
        this.chartOptions = {
            series: [
                {
                    data: []
                }
            ],
            chart: {
                height: "400",
                type: "rangeBar",
                redrawOnParentResize: true,
                toolbar: {
                    show: false
                },
                zoom: {
                    enabled: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: true,
                    distributed: true,
                    dataLabels: {
                        hideOverflowingLabels: false
                    },
                    rangeBarOverlap: true
                }
            },
            xaxis: {
                type: "datetime",
                min: undefined,
                max: undefined,
                labels: {
                    datetimeUTC: false,
                    datetimeFormatter: {
                        year: "yyyy",
                        month: "dd/MM/yyyy",
                        day: "dd/MM/yyyy",
                        hour: "HH:mm"
                    }
                }
            },
            tooltip: {
                custom: function ({ seriesIndex, dataPointIndex, w }) {
                    const pqiEventCategory = w.config.series[seriesIndex].data[dataPointIndex].x.toUpperCase();
                    const formattedDuration =
                        w.config.series[seriesIndex].data[dataPointIndex].duration < 0
                            ? ""
                            : dateFormatService.toLocaleString(
                                  w.config.series[seriesIndex].data[dataPointIndex].duration,
                                  DateFormats.DURATION
                              );

                    const voltageLevel = w.config.series[seriesIndex].data[dataPointIndex].voltageLevel;
                    const phase = w.config.series[seriesIndex].data[dataPointIndex].phase;

                    const levelRowHtml =
                        voltageLevel !== undefined
                            ? `<tr>
                    <td class="td-title"> ` +
                              w.config.series[seriesIndex].data[0].translations.level +
                              `
                    </td>
                    <td class="td-bold">` +
                              voltageLevel +
                              `</td>
                    </tr>
                    `
                            : ``;

                    const phaseRowHtml = phase
                        ? `<tr>
                    <td class="td-title"> ` +
                          w.config.series[seriesIndex].data[0].translations.phase +
                          `
                    </td>
                    <td class="td-bold">` +
                          phase +
                          `</td>
                    </tr>
                    `
                        : ``;

                    return (
                        `<div>
                        <h3 >` +
                        pqiEventCategory +
                        `</h3>
                        <table>
                        <tr>
                        <td class="td-title">
                        ` +
                        w.config.series[seriesIndex].data[0].translations.startTime +
                        `
                        </td>
                        <td class="td-bold">` +
                        w.config.series[seriesIndex].data[dataPointIndex].startTimeFormattedForTooltip +
                        `</td>
                        </tr>
                        <tr>
                        <td class="td-title">
                        ` +
                        w.config.series[seriesIndex].data[0].translations.endTime +
                        `
                        </td>
                        <td class="td-bold">` +
                        w.config.series[seriesIndex].data[dataPointIndex].endTimeFormattedForTooltip +
                        `</td>
                        </tr>
                        <tr>
                        <td class="td-title">
                        ` +
                        w.config.series[seriesIndex].data[0].translations.duration +
                        `
                        </td>
                        <td class="td-bold">` +
                        formattedDuration +
                        `</td>
                        </tr>
                        ` +
                        levelRowHtml +
                        phaseRowHtml +
                        `
                        </table>
                        </div>`
                    );
                }
            }
        };
    }
    ngAfterViewChecked(): void {
        if (!this.initialViewCheckDone) {
            this.updateChartHeigthOnlyOnInitialAfterViewCheck();
        }
    }
    ngOnInit(): void {
        this.windowHeightSub = this.store.select(getWindowHeight).subscribe((data) => {
            this.updateChartHeight(true, false);
        });
    }

    ngOnDestroy(): void {
        this.windowHeightSub.unsubscribe();
    }

    ngOnChanges(changes: SimpleChanges): void {
        this.prepareAndAssignDataToChart();
        this.updateChartHeight(true, false);
        this.assignxAxisMinMaxAndFormatValues(this.pqiDataRange.from, this.pqiDataRange.until, this.pqiChartXAxisFormat);
    }

    prepareAndAssignDataToChart() {
        if (this.series.length > 0) {
            if (this.chart) {
                this.chart.updateSeries([this.formatValuesAndTranslationsForTooltip()]);
            } else {
                this.chartOptions.series = [this.formatValuesAndTranslationsForTooltip()];
            }
            this.emptySeries = false;
        } else {
            this.emptySeries = true;
        }
        this.updateChartHeight();
    }

    assignxAxisMinMaxAndFormatValues(
        from: number | undefined,
        until: number | undefined,
        formats: { dateFormat: string; timeFormat: string }
    ) {
        if (this.chartOptions.xaxis && this.chartOptions.xaxis.labels) {
            if (this.chart) {
                this.chart.updateOptions({
                    xaxis: {
                        min: from ? new Date(from).getTime() : undefined,
                        max: until ? new Date(until).getTime() : new Date().getTime()
                    }
                });
            } else {
                this.chartOptions.xaxis.min = from ? new Date(from).getTime() : undefined;
                this.chartOptions.xaxis.max = until ? new Date(until).getTime() : new Date().getTime();
                this.chartOptions.xaxis.labels.datetimeFormatter = {
                    year: "yyyy",
                    month: formats.dateFormat,
                    day: formats.dateFormat,
                    hour: formats.timeFormat
                };
            }
        }
    }

    formatValuesAndTranslationsForTooltip() {
        const seriesWithTranslations = {
            data: this.series.map((pqiEvent: any) => {
                return {
                    ...pqiEvent,
                    startTimeFormattedForTooltip: this.dateFormatService.toLocaleString(pqiEvent.y[0], DateFormats.DATETIME),
                    endTimeFormattedForTooltip:
                        pqiEvent.duration < 0
                            ? $localize`:|@@powerQualityData.ongoing:Ongoing`
                            : this.dateFormatService.toLocaleString(pqiEvent.y[0] + pqiEvent.duration, DateFormats.DATETIME)
                };
            })
        };
        seriesWithTranslations.data[0] = { ...seriesWithTranslations.data[0], translations: this.translationsForTooltip };
        return seriesWithTranslations;
    }

    updateChartHeight(windowResizeEvent?: boolean, initialUpdate?: boolean) {
        const currentAmountOfDifferentEventTypes = this.getAmountOfDifferentEventTypes(this.series);
        if (this.chartContainer && (currentAmountOfDifferentEventTypes !== this.amountOfDifferentEventTypes || windowResizeEvent)) {
            this.amountOfDifferentEventTypes = currentAmountOfDifferentEventTypes;
            const height =
                currentAmountOfDifferentEventTypes < 3 && this.chartContainer.nativeElement.clientHeight > 100
                    ? (this.chartContainer.nativeElement.clientHeight / 3) * currentAmountOfDifferentEventTypes
                    : this.chartContainer.nativeElement.clientHeight - 10;
            if (windowResizeEvent === true && this.chart && !initialUpdate) {
                this.chart.updateOptions({
                    chart: {
                        height: height
                    }
                });
            } else if (this.chartOptions.chart) {
                this.chartOptions.chart.height = height;
            }
        }
    }
    updateChartHeigthOnlyOnInitialAfterViewCheck() {
        this.updateChartHeight(false, true);
        this.initialViewCheckDone = true;
    }
    getAmountOfDifferentEventTypes(series: any[]) {
        const pqiEventTypes: string[] = [];
        let differentPqiEventsAmount = 0;
        series.forEach((pqiEvent) => {
            if (!pqiEventTypes.includes(pqiEvent.x)) {
                differentPqiEventsAmount++;
                pqiEventTypes.push(pqiEvent.x);
            }
        });
        return differentPqiEventsAmount;
    }
}
