import { Spies } from 'discovery-test';
import { SnowflakeConnectionConfigureComponent } from './snowflake-connection.component';
import { SharedConstants } from 'discovery-shared';
import { ConnectionModel } from '../connection.model';
import { NgForm } from '@angular/forms';
import { ConnectionOptionModel } from 'shared/connections/connection-option.model';

describe('ConnectionConfigureComponent', () => {
  let component: SnowflakeConnectionConfigureComponent;

  beforeEach(() => {
    Spies.init();
    component = new SnowflakeConnectionConfigureComponent(Spies.TranslateService);
    component.connectionModel = new ConnectionModel();
    component.snowflakeForm = new NgForm([], []);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('validate Connection Name ', () => {
    component.connectionModel.name = '456@InvalidName';
    component.validateConnectionName();
    expect(component.connectionNameError.invalidName).toBe(true);
  });

  it('should check validate connection name failure', () => {
    component.connectionModel.name =
      'test connectionqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq';
    component.validateConnectionName();
    expect(component.connectionNameError.invalidName).toBe(true);
  });

  it('should test setters', () => {
    (component.account = 'account'),
      (component.schema = 'schema'),
      (component.database = 'db'),
      (component.warehouse = 'warehouse'),
      (component.role = 'role'),
      (component.password = 'password'),
      (component.userName = 'user');
    component.viewType = SharedConstants.connectionConfigureModes.ADD;
    expect(component.viewType).toBe(SharedConstants.connectionConfigureModes.ADD);
    expect(component.snowflakeForm.valid).toBe(true);
  });

  it('should emit event on form valid', () => {
    spyOn(component.setFormValid, 'emit');
    component.account = 'account';
    spyOnProperty(component.snowflakeForm.form, 'valid', 'get').and.returnValue(true);
    expect(component.snowflakeForm.form.valid).toBe(true);
    expect(component.setFormValid.emit).toHaveBeenCalled();
  });

  it('should emit event on form invalid', () => {
    spyOn(component.setFormValid, 'emit');
    spyOnProperty(component.snowflakeForm.form, 'valid', 'get').and.returnValue(false);
    component.account = 'account';
    expect(component.snowflakeForm.form.valid).toBe(false);
    expect(component.setFormValid.emit).toHaveBeenCalled();
  });

  it('should reset form on close', () => {
    const spy = spyOn(component.snowflakeForm, 'resetForm');
    component.connectionNameRef = jasmine.createSpyObj('connectionNameRef', ['nativeElement']);
    component.resetFormSnow = true;
    expect(spy).toHaveBeenCalled();
    expect(component.connectionNameRef.nativeElement.required).toBe(false);
  });

  it('should set value of resourceType', () => {
    component.connectionModel.resourceConnectionType = '';
    component.ngOnInit();
    expect(component.connectionModel.resourceConnectionType).toBe(SharedConstants.connectionConfigureType.SNOWFLAKE);
  });

  it('should call getOption method', () => {
    component.connectionModel.options = [new ConnectionOptionModel('user', 'test user')];
    const user = component.getOption('user');
    expect(component.userName).toBe(user);
  });

  it('should check connection name is required on submit', () => {
    component.connectionNameRef = jasmine.createSpyObj('connectionNameRef', ['nativeElement']);
    component.clickedButtonType = 'connection-save';
    expect(component.connectionNameRef.nativeElement.required).toBe(true);
  });
});
