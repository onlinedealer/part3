import { Component, OnInit, Input } from '@angular/core';
import { UtilityService } from '../shared/utility/utility.service'
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-club-benefit-dashboard',
  templateUrl: './club-benefit-dashboard.component.html',
  styleUrls: ['./club-benefit-dashboard.component.scss']
})
export class ClubBenefitDashboardComponent implements OnInit {

  isDesktop: boolean;
  @Input() benefitDetails: any;

  constructor(private _utility: UtilityService) { 
    this.isDesktop = 'DESKTOP' === this._utility.getUserAgent();
  }

  ngOnInit() {
  }

  getBenefitTitleSubtitle():object{//TODO: Sourav - once we have mock api, move logic to utility.
    if('creditAvailability' === this.benefitDetails.key && this.benefitDetails.values['isCreditAvailable']){
      return {'title':'$10 credit still available', 'subTitle':'Use before '+this.benefitDetails.values['expDate'], 'action': 'Shop online', 'pageToRedirect':'/shop'};
    }else if('freeShippingAvailability' === this.benefitDetails.key && this.benefitDetails.values['isFreeShippingAvailable']){
      return {'title':'Free shipping', 'subTitle':'Buy your favorite items online and get them fast. No minimum purchase.', 'action': 'Try Easy Reorder', 'pageToRedirect': '/account/previous-purchases'};
    }else if('freeNxtDayDelivery' === this.benefitDetails.key && this.benefitDetails.values['isFreeNxtDayDeliveryAvailable']){
      return {'title':'Free next-day delivery', 'subTitle': 'On qualifying prescriptions', 'action': 'Refill now', 'pageToRedirect':'/pharmacy'};
    }else if('pharmacyHotline' === this.benefitDetails.key && this.benefitDetails.values['isPharmacyHotlineAvailable']){
      return {'title':'24/7 pharmacy hotline', 'subTitle':'We\'re here when you need us. Call <a class="red-font" href="tel:1800000000">XXX-XXX-XXXX</a> with Rx questions any time.'};
    }else if('clubDiscount' === this.benefitDetails.key && this.benefitDetails.values['isClubDiscountAvailable']){
      return {'title':'20% off all CVS branded products', 'subTitle':'Some resrtictions may apply.'};      
    }
  }


}
