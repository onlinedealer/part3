export let ColumnHeaders = {
  KAFKA: [
    {
      header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.KAFKA.TOPIC',
      name: 'topic'
    }
  ],
  ORACLE: [
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.ORACLE.SCHEMA', name: 'schema' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.ORACLE.TABLE', name: 'table' }
  ],
  DB2I: [
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.Db2IBMi.LIBRARY', name: 'library' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.Db2IBMi.TABLE', name: 'table' }
  ],
  DB2: [
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.Db2.LIBRARY', name: 'library' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.Db2.TABLE', name: 'table' }
  ],
  SQLSERVER: [
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.MsSql.DATABASE', name: 'database' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.MsSql.OWNER', name: 'owner' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.MsSql.TABLE', name: 'table' }
  ],
  DB2Z: [
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.ORACLE.SCHEMA', name: 'schema' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.ORACLE.TABLE', name: 'table' }
  ],
  SNOWFLAKE: [
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.SNOWFLAKE.DATABASE', name: 'topic' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.SNOWFLAKE.SCHEMA', name: 'topic' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.SNOWFLAKE.TABLE', name: 'topic' }
  ],
  DB2ZOS: [
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.Db2Z.SCHEMA', name: 'schema' },
    { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.Db2Z.TABLE', name: 'table' }
  ],
  SCHEMAREGISTRY: [
    {
      header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.SCHEMA_REGISTRY.TOPIC',
      name: 'topic'
    },
    {
      header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.SCHEMA_REGISTRY.SUBJECT',
      name: 'subject'
    }
  ]
};
