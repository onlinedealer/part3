export const AppResources = {
  HOME: {
    VIEW: []
  },
  AGENT: {
    VIEW: [''],
    ADD: ['Operator'],
    DOWNLOAD: ['Operator'],
    EDIT: ['Operator', 'Designer'],
    DELETE: ['Operator']
  },
  PROJECT: {
    VIEW: [],
    ADD: ['Designer'],
    EDIT: ['Designer'],
    DELETE: ['Designer'],
    START: ['Operator'],
    STOP: ['Operator'],
    DETAILS: ['Operator'],
    ALERTS: ['Operator'],
    VALIDATE: ['Operator'],
    DEBUG: ['Operator'],
    IGNORE: ['Operator'],
    STOP_IGNORING: ['Operator'],
    BUNDLES: ['Operator', 'Designer'],
    EXPORT: ['Operator', 'Designer'],
    IMPORT: ['Operator', 'Designer']
  },
  PIPELINE: {
    VIEW: [],
    ADD: ['Designer'],
    EDIT: ['Designer'],
    DELETE: ['Designer'],
    STAGE: ['Designer'],
    DEPLOY: ['Operator'],
    START: ['Operator'],
    STOP: ['Operator'],
    START_RUNTIME: ['Operator'],
    STOP_RUNTIME: ['Operator'],
    ALERTS: ['Operator'],
    DETAILS: ['Operator'],
    CLEAR_BACKLOG: ['Operator'],
    MANAGE_CAPTURE: ['Operator'],
    DEBUG: ['Operator'],
    LOGREADER_LOG: ['Operator'],
    START_LOGREADER: ['Operator'],
    STOP_LOGREADER: ['Operator'],
    BUNDLES: ['Operator', 'Designer'],
    EXPORT: ['Operator', 'Designer'],
    IMPORT: ['Operator', 'Designer']
  },
  METABASE: {
    VIEW: ['Designer'],
    ADD: ['Designer'],
    EDIT: ['Designer'],
    DELETE: ['Designer']
  },
  CONNECTION: {
    VIEW: [],
    ADD: ['Designer'],
    EDIT: ['Designer'],
    DELETE: ['Designer'],
    MANAGE_CATALOG: ['Designer']
  },
  SERVER: {
    VIEW: [],
    ADD: ['Designer'],
    EDIT: ['Designer'],
    DELETE: ['Designer']
  },
  BUNDLE: {
    ADD: ['Designer'],
    STOP: ['Operator'],
    DELETE: ['Designer']
  },
  SCHEDULED_PIPELINE: {
    ADD: ['Designer'],
    START: ['Operator'],
    STOP: ['Operator']
  }
};
