import { Component } from "@angular/core";
import { TranslationsService } from "../../../../app/services/translations-service";
import { SecondarySideviewService } from "../../../../Shared/services/secondary-sideview.service";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { PrepaymentSelectors, EventsSelectors } from "../../../store/selectors";
import { EventVO } from "../../../models/view-objects/event-vo.model";
import { SSPrepaymentTokenLogSorter } from "./ss-prepayment-token-logs.sorter";
interface ColumnTitles {
    [key: string]: string;
}

@Component({
    selector: "landisgyr-ss-prepayment-token-logs",
    templateUrl: "./ss-prepayment-token-logs.component.html",
    styleUrls: ["./ss-prepayment-token-logs.component.scss"]
})
export class SSPrepaymentTokenLogsComponent {
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);

    tokenLogData$: Observable<EventVO[]> = this.store.select(EventsSelectors.getFilteredEventForTokenLogs);

    tokenLogSorter = new SSPrepaymentTokenLogSorter();
    sortedTokenLogProperties$ = this.tokenLogSorter.getSortedTokenLogProperties(this.tokenLogData$);

    tokenLogLoading$: Observable<any> = this.store.select(PrepaymentSelectors.getLoadingData);

    infoMessage = this.translations.getTranslation("No data available for the selected time period");

    TABLE_COLUMN_TITLES_TOKENLOG: ColumnTitles = {
        time: this.translations.getTranslation("Time"),
        stsToken: $localize`:|Table column title for STS ID@@tokenLogTable.stsToken:STS token`,
        amount: $localize`:|Table column title for amount@@tokenLogTable.amount:Amount`,
        deliveryMethod: $localize`:|Table column title for Delivery method@@tokenLogTable.deliveryMethod:Delivery method`,
        tokenId: $localize`:|Table column title for  Id@@tokenLogTable.tokenId:Token ID`,
        description: this.translations.getTranslation("Description")
    };

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private secondarySideviewService: SecondarySideviewService,
        public translations: TranslationsService
    ) {}

    onSelfDestruct() {
        this.secondarySideviewService.removeLatestSideview();
    }
}
