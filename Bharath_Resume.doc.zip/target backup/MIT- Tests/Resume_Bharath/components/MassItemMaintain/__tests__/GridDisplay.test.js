import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../store/configureStore'
import GridDisplay, { GridDisplay as GridDisplayComponent } from '../GridDisplay'

describe('GridDisplay Page component', () => {
  let store, wrapper, props, wrapperBlock
  store = configureStore()
  props = {
    listStatus: true,
    classes: {},
    updateMode: 'excel',
    loadingInfo: {
      status: false,
      message: '',
    },
    commonFields: {
      jira_id: 'cr-11789',
      maintenance_type: 'cost',
      user_id: null,
    },
    columnInfo: [{
      column_id: 'tcin',
      column_name: 'TCIN',
      editable: true,
      field_type: 'Number',
      multi_value: false,
      values: [],
      send_in_response: true,
      filterable: true,
      filter_name: 'dummy',
    }],
    listItems: [{
      'tcin': '21448960',
      'dpci': '907-30-1933',
      'barcode': '499073019338',
      'product_title': 'Bath Towel Red - Threshold',
      'attribute': 'cost',
      'old_value': [
        '5.0',
      ],
      'new_value': null,
      'vendor_id': '1166383',
      'vendor_name': 'DUMMY MASTER DOM1',
      'alternate_id': '411500265',
      'vos': '2',
    }],
    gridText: {
      grid_text_left: 'left content',
      grid_text_right: 'right content',
    },
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }

  it('renders', () => {
    const div = document.createElement('div')
    shallow(
      <Provider store={store}>
        <GridDisplay {...props} />
      </Provider>, div)
  })

  it('renders Elements', () => {
    wrapper = mount(
      <Provider store={store}>
        <GridDisplay {...props} />
      </Provider>
    )
    expect(wrapper.find('GridUpdate').length).toEqual(1)
    expect(wrapper.find('Button').length).toEqual(4)
  })

  it('invoking cancelUpdate calls cancelUpdate(action creator)', () => {
    props.cancelUpdate = jest.fn()
    wrapperBlock = shallow(
      <GridDisplayComponent
        {...props}
      />
    )
    wrapperBlock.instance().cancelUpdate()
    expect(props.cancelUpdate.mock.calls.length).toEqual(1)
  })

  it('invoking saveItems calls saveItems,toggleLoading(action creator)', () => {
    props.saveItems = jest.fn()
    props.toggleLoading = jest.fn()
    wrapperBlock = shallow(
      <GridDisplayComponent
        {...props}
      />
    )
    wrapperBlock.instance().saveItems()
    expect(props.saveItems.mock.calls.length).toEqual(1)
    expect(props.toggleLoading.mock.calls.length).toEqual(1)
  })
})
