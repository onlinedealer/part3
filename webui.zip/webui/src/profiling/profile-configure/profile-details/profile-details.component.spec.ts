import { ProfileDetailsComponent } from './profile-details.component';
import { NgForm } from '@angular/forms';
import { of } from 'rxjs';
import { ScheduleComponent } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { ScheduleOccurenceTypeEnum } from 'discovery-core';

describe('ProfileDetailsComponent', () => {
  let component: ProfileDetailsComponent;

  beforeEach(() => {
    component = new ProfileDetailsComponent();
    component.profileDetailForm = new NgForm([], []);
    component.scheduleComponent = new ScheduleComponent(Spies.TranslateService);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('validation failed name null', () => {
    component.scheduleComponent.scheduleForm = new NgForm([], []);
    const errors = component.validate();
    expect(errors.size).toBe(1);
    expect(errors.has('discoveryProfiling.profilingDetails.missingName')).toBe(true);
  });

  it('validation failed name blank', () => {
    component.scheduleComponent.scheduleForm = new NgForm([], []);
    component.profileName = '   ';
    const errors = component.validate();
    expect(errors.size).toBe(1);
    expect(errors.has('discoveryProfiling.profilingDetails.missingName')).toBe(true);
  });

  it('validation failed name invalid', () => {
    component.scheduleComponent.scheduleForm = new NgForm([], []);
    component.profileName = '123@#!InvalidName';
    const errors = component.validate();
    expect(errors.size).toBe(1);
    expect(errors.has('discoveryProfiling.profilingDetails.invalidName')).toBe(true);
  });

  it('validate Profile Name ', () => {
    component.profileName = '456@InvalidName';
    component.validateProfileName();
    expect(component.profileNameError.invalidName).toBe(true);
  });

  it('validation success', () => {
    component.scheduleComponent.scheduleForm = new NgForm([], []);
    component.profileName = 'Valid Name-123';
    const errors = component.validate();
    expect(errors.size).toBe(0);
  });

  it('test profile name changed', () => {
    spyOn(component.profileNameChange, 'emit');
    component.profileNameChanged();
    expect(component.profileNameChange.emit).toHaveBeenCalled();
  });

  it('test profile description changed', () => {
    spyOn(component.profileDescriptionChange, 'emit');
    component.profileDescriptionChanged();
    expect(component.profileDescriptionChange.emit).toHaveBeenCalled();
  });

  it('test profile rules list changed', () => {
    spyOn(component.selectedRulesListChange, 'emit');
    component.rulesListChanged(of('dummy'));
    expect(component.selectedRulesListChange.emit).toHaveBeenCalled();
  });
  it('loadProfileSettings should call with schedule config', () => {
    const data = Mocks.MockProfiles[0];
    data.scheduleConfig.schedule.occurence = ScheduleOccurenceTypeEnum.DAILY;
    component.loadProfileSettings(data, true);
    expect(component.scheduleComponent.isEdit).toBe(true);
    expect(component.scheduleComponent.scheduleOccurenceType).toBe('daily');
  });
  it('loadProfileSettings should call with schedule feature off', () => {
    component.scheduleFeatureFlag = false;
    const data = Mocks.MockProfiles[0];
    component.loadProfileSettings(data, true);
    expect(component.profileName).toBeDefined();
  });
  it('test emit scheduler change', () => {
    spyOn(component.schedulerChange, 'emit');
    component.getSchedulerChange('dummy');
    expect(component.schedulerChange.emit).toHaveBeenCalled();
  });
});
