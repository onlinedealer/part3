import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA, Directive, SimpleChange, SimpleChanges, ViewContainerRef } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { environment } from '../../../../environments/environment';
import { ServerSidebarComponent } from '../../../servers/server-sidebar/server-sidebar.component';
import { DynamicHostDirective } from '../../../shared/directives/dynamic-host.directive';
import { ConnectionFormComponent } from './connection-form.component';
import { OrderbyascPipe } from '../../../shared/pipes/dynamic-dropdown-sort.pipe';
import { ServersApiService } from '../../../servers/shared/servers-api.service';
import { Server } from '../../../servers/shared/server';
import { of } from 'rxjs';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { OracleFormComponent } from './oracle-connection-form/oracle-form.component';
import { KafkaFormComponent } from './kafka-connection-form/kafka-form.component';
import { Db2zFormComponent } from './db2z-connection-form/db2z-form.component';
import { FeatureFlagService } from '../../../shared/services/feature-flag.service';
import { Connection } from '../../shared/connection';

describe('ConnectionFormComponent', () => {
  let component: ConnectionFormComponent;
  let fixture: ComponentFixture<ConnectionFormComponent>;
  let serversApiService: ServersApiService;

  const mockSupportedSources = [
    { connectionType: 'ORACLE', accessMethods: ['JDBC'] },
    { connectionType: 'DB2ZOS', accessMethods: ['JDBC'] }
  ];

  const mockSupportedTargets = [{ connectionType: 'KAFKA', accessMethods: [] }];

  const mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

  const mockRuntimeServers = [
    { id: '0', name: 'test1', serverType: 'REPLICATION' } as Server,
    { id: '1', name: 'test2', serverType: 'REPLICATION' } as Server
  ];

  @Component({
    selector: 'p-connect-mock-form',
    template: ''
  })
  class MockFormComponent {
    addServerButtonClickedEvent = of(true);
    getConnection() {
      return {};
    }
  }

  @Component({
    selector: 'p-connect-server-sidebar',
    template: ''
  })
  class MockServerSideBarComponent {}

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, DropdownModule, CheckboxModule, HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        { provide: ServerSidebarComponent, useValue: MockServerSideBarComponent },
        { provide: OracleFormComponent, useValue: MockFormComponent },
        { provide: KafkaFormComponent, useValue: MockFormComponent },
        { provide: Db2zFormComponent, useValue: MockFormComponent },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ],
      declarations: [ConnectionFormComponent, MockFormComponent, DynamicHostDirective, OrderbyascPipe]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectionFormComponent);
    component = fixture.componentInstance;
    serversApiService = TestBed.inject(ServersApiService);

    environment.supportedSourceConnectionTypes = mockSupportedSources;
    environment.supportedTargetConnectionTypes = mockSupportedTargets;

    component.connectionTypes = ['ORACLE', 'KAFKA'];
    component.connectionChildFormComponentList = [
      { connectionType: 'ORACLE', component: MockFormComponent },
      { connectionType: 'KAFKA', component: MockFormComponent },
      { connectionType: 'DB2ZOS', component: MockFormComponent }
    ];

    const changesObj: SimpleChanges = {
      connectionTypes: new SimpleChange(null, ['ORACLE', 'KAFKA'], false)
    };
    component.ngOnChanges(changesObj);

    fixture.detectChanges();
  });

  it('should create', waitForAsync(() => {
    expect(component).toBeTruthy();
    fixture.whenStable().then(() => {
      expect(component.childComponentReference).toBeDefined();
    });
  }));

  it('should return a list of servers', () => {
    spyOn(serversApiService, 'getAll').and.returnValue(of(mockRuntimeServers));
    component.getRuntimeServersList();
    expect(component.runtimeServerDropdownList.length).toBe(2);
  });

  it('should setup form and child component', () => {
    component.setupFormAndChildComponent();
    expect(component.childComponentReference).toBeDefined();
  });

  it('should load connection component connection when form group is defined', waitForAsync(() => {
    fixture.whenStable().then(() => {
      const oldComponentType = component.childComponentReference.componentType;
      const changesObj: SimpleChanges = {
        connectionTypes: new SimpleChange(['ORACLE', 'KAFKA'], ['ORACLE', 'DB2ZOS', 'KAFKA'], false)
      };
      component.ngOnChanges(changesObj);
      fixture.detectChanges();
      expect(component.childComponentReference.componentType).toEqual(oldComponentType);
    });
  }));

  it('should not load connection component if other changes are made to component', waitForAsync(() => {
    fixture.whenStable().then(() => {
      const oldComponentType = component.childComponentReference.componentType;
      const changesObj: SimpleChanges = {
        prop: new SimpleChange(null, '2', false)
      };
      component.ngOnChanges(changesObj);
      fixture.detectChanges();
      expect(component.childComponentReference.componentType).toEqual(oldComponentType);
    });
  }));

  it('should return an error for incorrect connection names', waitForAsync(() => {
    fixture.whenStable().then(() => {
      component.connectionFormGroup.patchValue({ name: 'invalid connection name' });
      fixture.detectChanges();
      expect(component.connectionFormGroup.errors.connectionNameIsInvalid).toBeDefined();
    });
  }));

  it('should not return an error for correct connection names', waitForAsync(() => {
    fixture.whenStable().then(() => {
      component.connectionFormGroup.patchValue({ name: 'connection' });
      fixture.detectChanges();
      expect(component.connectionFormGroup.errors).toBeNull();
    });
  }));

  it('should return connection', waitForAsync(() => {
    fixture.whenStable().then(() => {
      component.connectionFormGroup.patchValue({ name: 'connection' });
      expect(component.getConnection(true).name).toBe('connection');
    });
  }));

  it('should return connection when there is no access method', waitForAsync(() => {
    fixture.whenStable().then(() => {
      component.connectionFormGroup.patchValue({ connectionType: 'KAFKA' });
      fixture.detectChanges();
      expect(component.getConnection(false).accessMethod).toBe('');
    });
  }));

  it('should load connection form when connection type changes', waitForAsync(() => {
    fixture.whenStable().then(() => {
      component.connectionFormGroup.patchValue({ connectionType: 'DB2ZOS' });
      fixture.detectChanges();
      expect(component.childComponentReference).toBeDefined();
    });
  }));

  it('should not load form of chosen connection type, if connection type component is not referenced in connectionChildFormComponentList array', waitForAsync(() => {
    fixture.whenStable().then(() => {
      component.connectionFormGroup.patchValue({ connectionType: 'SCHEMAREGISTRY' });
      const childConnectionComponent = component.connectionChildFormComponentList.find((obj) => obj.connectionType === 'SCHEMAREGISTRY');
      fixture.detectChanges();
      expect(childConnectionComponent).toEqual(undefined);
    });
  }));

  it('should get update list of servers when a new server has been added', waitForAsync(() => {
    fixture.whenStable().then(() => {
      spyOn(serversApiService, 'getAll').and.returnValue(of(mockRuntimeServers));
      component.updateServerListAndSelectNewServer({ id: '1' });
      expect(serversApiService.getAll).toHaveBeenCalled();
    });
  }));

  it('should update the test values from the test response', waitForAsync(() => {
    fixture.whenStable().then(() => {
      const connectionDetailFormGroup = component.connectionFormGroup.get('connectionDetails') as FormGroup;
      connectionDetailFormGroup.addControl('dbmsVersion', new FormControl(''));
      connectionDetailFormGroup.addControl('driverVersion', new FormControl(''));
      connectionDetailFormGroup.addControl('gmtOffset', new FormControl(''));
      component.updateTestValues({ dbmsVersion: 1, driverVersion: 1, gmtOffset: 1 });
      expect(connectionDetailFormGroup.get('dbmsVersion').value).toBe(1);
      expect(connectionDetailFormGroup.get('driverVersion').value).toBe(1);
      expect(connectionDetailFormGroup.get('gmtOffset').value).toBe(1);
    });
  }));

  it('should not update the test values', waitForAsync(() => {
    fixture.whenStable().then(() => {
      const connectionDetailFormGroup = component.connectionFormGroup.get('connectionDetails') as FormGroup;
      connectionDetailFormGroup.addControl('dbmsVersion', new FormControl(''));
      connectionDetailFormGroup.addControl('driverVersion', new FormControl(''));
      connectionDetailFormGroup.addControl('gmtOffset', new FormControl(''));
      component.updateTestValues({});
      expect(connectionDetailFormGroup.get('dbmsVersion').value).not.toBe(1);
      expect(connectionDetailFormGroup.get('driverVersion').value).not.toBe(1);
      expect(connectionDetailFormGroup.get('gmtOffset').value).not.toBe(1);
    });
  }));

  it('should set the connection', () => {
    const dataConnection = {
      accessFromServer: { id: '1' },
      id: '2',
      name: 'MyConnection',
      description: '',
      connectionType: 'ORACLE',
      database: 'test',
      parameters: []
    } as Connection;
    const runtimeServer = mockRuntimeServers[1];
    component.runtimeServerDropdownList = [{ label: runtimeServer.name, value: runtimeServer }];
    component.connection = dataConnection;
    expect(component.connectionFormGroup.get('runtimeServer').value.name).toBe(runtimeServer.name);
  });

  it('should display the server sidebar', () => {
    component.addRuntimeServer();
    expect(component.isServerSidebarVisible).toBeTrue();
  });

  it('should default to the only runtime server configured', waitForAsync(() => {
    const runtimeServer = mockRuntimeServers[1];
    component.runtimeServerDropdownList = [{ label: runtimeServer.name, value: runtimeServer }];
    fixture.whenStable().then(() => {
      component.connectionFormGroup.patchValue({ connectionType: 'DB2ZOS' });
      fixture.detectChanges();
      expect(component.childComponentReference).toBeDefined();
      expect(component.connectionFormGroup.get('runtimeServer').value.name).toBe(runtimeServer.name);
    });
  }));
});
