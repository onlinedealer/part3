import { Helper } from 'discovery-shared';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AuthenticationService, SharedConstants as ProfilingConstants } from 'discovery-shared';
import { Observable } from 'rxjs';
import { ProfileConfigureModel } from './profile-configure/profile-configure.model';
import { ProfileListModel } from './profile-listing/profile-list.model';
import { ProfileRuleModel } from './profile-rule.model';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

@Injectable({
  providedIn: 'root'
})
export class ProfileService {
  /**
   *
   */
  baseUrl: string;

  /**
   *
   */
  constructor(
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('configapi', 'profiling', 'api/v1/');
  }

  /**
   *
   */
  getProfileList(): Observable<ProfileListModel[]> {
    return this.httpClient.get(this.baseUrl + 'profiles', {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<ProfileListModel[]>;
  }

  getRulesList(): Observable<ProfileRuleModel[]> {
    return this.httpClient.get(this.baseUrl + 'profile/rules', {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<ProfileRuleModel[]>;
  }

  runProfile(id: string) {
    return this.httpClient.post(this.baseUrl + 'runtime/profile/run/' + id, '', {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  saveProfile(profileConfigureModel: ProfileConfigureModel, newProfile: boolean, profileId: string) {
    if (profileConfigureModel.scheduleConfig && Helper.isEmpty(profileConfigureModel.scheduleConfig.schedule)) {
      delete profileConfigureModel.scheduleConfig.schedule;
    }
    if (newProfile) {
      return this.httpClient.post(this.baseUrl + 'profile', profileConfigureModel, {
        headers: this.authenticationService.getHttpHeaders()
      });
    } else {
      return this.httpClient.put(this.baseUrl + 'profile/' + profileId, profileConfigureModel, {
        headers: this.authenticationService.getHttpHeaders()
      });
    }
  }

  deleteProfile(profileId: string): Observable<any> {
    return this.httpClient.delete(this.baseUrl + 'profile/' + profileId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  getProfile(profileId: string) {
    return this.httpClient.get(this.baseUrl + 'profile/' + profileId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  stopRunProfile(id: string) {
    return this.httpClient.post(this.baseUrl + 'runtime/profile/cancel/' + id, '', {
      headers: this.authenticationService.getHttpHeaders()
    });
  }
}
