import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../store/configureStore'
import GridEntry, { GridEntry as GridEntryComponent } from '../GridEntry'

describe('GridEntry Page component', () => {
  let store, wrapper, props, wrapperBlock
  store = configureStore()
  props = {
    maintenanceType: 'cost',
    listStatus: true,
    submitStatus: false,
    submitMessage: {
      type: '',
      message: '',
    },
    classes: {},
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }

  it('renders', () => {
    const div = document.createElement('div')
    shallow(
      <Provider store={store}>
        <GridEntry {...props} />
      </Provider>, div)
  })

  it('renders Elements GridDisplay', () => {
    wrapper = mount(
      <Provider store={store}>
        <GridEntry {...props} />
      </Provider>
    )
    expect(wrapper.find('GridDisplay').length).toEqual(1)
    // expect(wrapper.find('Button').length).toEqual(1)
    // expect(wrapper.find('TextField').length).toEqual(1)
  })

  it('invoking submitJiraId calls getItems,changeUpdateMode,toggleLoading(action creator)', () => {
    props.getMaintenanceDetails = jest.fn()
    props.changeUpdateMode = jest.fn()
    props.toggleLoading = jest.fn()
    props.getItems = jest.fn()
    wrapperBlock = shallow(
      <GridEntryComponent
        {...props}
      />
    )
    wrapperBlock.setState({ jiraId: 'CR-123' })
    wrapperBlock.instance().submitJiraId()
    expect(props.changeUpdateMode.mock.calls.length).toEqual(1)
    expect(props.toggleLoading.mock.calls.length).toEqual(1)
    expect(props.getItems.mock.calls.length).toEqual(1)
  })

  it('invoking submitTcins calls getItemsFromTcins,changeUpdateMode,toggleLoading(action creator)', () => {
    props.getMaintenanceDetails = jest.fn()
    props.changeUpdateMode = jest.fn()
    props.toggleLoading = jest.fn()
    props.getItemsFromTcins = jest.fn()
    wrapperBlock = shallow(
      <GridEntryComponent
        {...props}
      />
    )
    wrapperBlock.setState({ tcins: '12344\n234234', jiraId: 'CR-123', maintenance_type: 'Cost' })
    wrapperBlock.instance().submitTcins('serviceName', true)()
    expect(props.changeUpdateMode.mock.calls.length).toEqual(1)
    expect(props.toggleLoading.mock.calls.length).toEqual(1)
    expect(props.getItemsFromTcins.mock.calls.length).toEqual(1)
  })

  it('invoking submitExcel calls excelUpload,changeUpdateMode,toggleLoading(action creator)', () => {
    props.getMaintenanceDetails = jest.fn()
    props.changeUpdateMode = jest.fn()
    props.toggleLoading = jest.fn()
    props.excelUpload = jest.fn()
    wrapperBlock = shallow(
      <GridEntryComponent
        {...props}
      />
    )
    const excelInfo = {
      'template': ['tcin_dpci', 'new_cost'],
      'template_mapping': ['tcin_dpci', 'new_cost'],
      'service_name': 'test',
      'grid_required': false,
    }
    wrapperBlock.setState({ excelData: [['tcin_dpci', 'new_cost'], ['23', '45']], jiraId: 'CR-123', maintenance_type: 'Cost', excelInfo })
    wrapperBlock.instance().submitExcel('serviceName', true)
    expect(props.changeUpdateMode.mock.calls.length).toEqual(1)
    expect(props.toggleLoading.mock.calls.length).toEqual(1)
    expect(props.excelUpload.mock.calls.length).toEqual(1)
  })
})
