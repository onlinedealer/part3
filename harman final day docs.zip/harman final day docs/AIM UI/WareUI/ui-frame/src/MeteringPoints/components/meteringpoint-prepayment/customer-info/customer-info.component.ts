import { Component, Input, AfterViewInit, Output, EventEmitter, ChangeDetectionStrategy } from "@angular/core";
import { TranslationsService } from "../../../../app/services/translations-service";
import { PrepaymentVO } from "../../../models/view-objects/prepayment-vo.model";
import { ProfileData } from "../../../models/profiledata.model";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { Store } from "@ngrx/store";
import { RouterSelectors } from "../../../../app/store/selectors";
import { DetailsTable } from "../../../../Shared/models/details-table.model";
import { DateFormatService, DateFormats } from "../../../../Shared/services/date-format.service";

@Component({
    selector: "landisgyr-prepayment-customer-info",
    templateUrl: "./customer-info.component.html",
    styleUrls: ["./customer-info.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrepaymentCustomerInfoComponent implements AfterViewInit {
    @Input() prepaymentData!: PrepaymentVO;

    @Input() creditAvailable!: ProfileData[];

    @Output() expanded = new EventEmitter<boolean>();

    @Output() tokenLogClick: EventEmitter<null> = new EventEmitter();

    detailsSectionExpanded = false;
    tableExpansion = false;

    METERINGS_TABLE_HEADERS: { [key: string]: string } = {
        paymentMethod: $localize`:|Payment Method@@customerInfoTable.method:Payment method`,
        prepaymentMethod: $localize`:|Prepayment Method@@customerInfoTable.prepaymentMethod:Prepayment method`,
        creditAvailable: $localize`:|Credit Available@@customerInfoTable.creditAvailable:Credit available`,
        emergencyCredit: $localize`:|Emergency Credit@@customerInfoTable.emergencyCredit:Emergency credit`,
        latestUpdate: $localize`:|Latest Update@@customerInfoTable.latestUpdate:Latest update`,
        supplyGroupCode: $localize`:|Supply Group Code@@customerInfoTable.supplyGroupCode:Supply group code`,
        tariffIndex: $localize`:|Tariff Index@@customerInfoTable.tariffIndex:Tariff index`,
        keyNumber: $localize`:|Key Number@@customerInfoTable.keyNumber:Key number`
    };
    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private formatService: DateFormatService,
        public translations: TranslationsService
    ) {}

    onClickExpandDetailsSection(): void {
        this.detailsSectionExpanded = !this.detailsSectionExpanded;
        this.tableExpansion = !this.tableExpansion;
        this.expanded.emit(this.detailsSectionExpanded);
    }

    onTokenLogClick() {
        this.tokenLogClick.emit();
    }

    addCurrencyUnit(value: any, currencyUnit: any) {
        if (value) {
            if (currencyUnit) {
                return value + " " + currencyUnit;
            } else {
                return value + " " + "kWh";
            }
        } else {
            return "";
        }
    }

    ngAfterViewInit() {
        setTimeout(() => this.checkURLForSecondarySideview());
    }

    checkURLForSecondarySideview() {
        this.store
            .select(RouterSelectors.getLastSegment)
            .subscribe((lastSegment) => {
                if (lastSegment === "tokenLog") {
                    this.onTokenLogClick();
                }
            })
            .unsubscribe();
    }

    generateArrayToMeteringsTable(): DetailsTable[] {
        if (this.detailsSectionExpanded === true) {
            return [
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.paymentMethod,
                                value: this.prepaymentData?.paymentMode ? this.prepaymentData.paymentMode : ""
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.prepaymentMethod,
                                value: this.prepaymentData?.prepaymentMode ? this.prepaymentData.prepaymentMode : ""
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.creditAvailable,
                                value:
                                    this.creditAvailable[0] && this.prepaymentData?.currency
                                        ? this.addCurrencyUnit(this.creditAvailable[0].value, this.prepaymentData?.currency)
                                        : ""
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.emergencyCredit,
                                value: this.addCurrencyUnit(this.prepaymentData?.emergencyCredit, this.prepaymentData?.currency)
                                    ? this.addCurrencyUnit(this.prepaymentData?.emergencyCredit, this.prepaymentData?.currency)
                                    : ""
                            }
                        ]
                    }
                },
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.latestUpdate,
                                value: this.formatService.toLocaleString(this.creditAvailable[0]?.readingTime, DateFormats.DATETIME)
                                    ? this.formatService.toLocaleString(this.creditAvailable[0]?.readingTime, DateFormats.DATETIME)
                                    : ""
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.supplyGroupCode,
                                value: this.prepaymentData?.supplyGroupCode ? this.prepaymentData.supplyGroupCode : ""
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.tariffIndex,
                                value: this.prepaymentData?.tariffIndex ? this.prepaymentData.tariffIndex : ""
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.keyNumber,
                                value: this.prepaymentData?.keyRevisionNumber ? this.prepaymentData.keyRevisionNumber : ""
                            }
                        ]
                    }
                }
            ];
        } else {
            return [
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.paymentMethod,
                                value: this.prepaymentData?.paymentMode ? this.prepaymentData.paymentMode : ""
                            }
                        ]
                    }
                },
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.latestUpdate,
                                value: this.formatService.toLocaleString(this.creditAvailable[0]?.readingTime, DateFormats.DATETIME)
                                    ? this.formatService.toLocaleString(this.creditAvailable[0]?.readingTime, DateFormats.DATETIME)
                                    : ""
                            }
                        ]
                    }
                }
            ];
        }
    }
}
