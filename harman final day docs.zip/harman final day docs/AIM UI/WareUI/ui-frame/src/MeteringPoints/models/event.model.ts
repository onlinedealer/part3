export interface Event {
    alarm?: boolean;
    actor: string;
    deliveryStatus: number;
    eventDataId: number;
    eventDefinitionId: number;
    eventTime: number;
    parameters: EventParameter[];
    readingTime: number;
    savingTime: number;
    sourceId: number;
}

export interface EventParameter {
    index: number;
    value: string;
}

export interface EventDefinition {
    description: string;
    displaySequenceNo: number;
    eventClassId: number;
    eventDefinitionId: number;
    eventLevel: number;
    identifier: string;
    name: string;
    parameters: EventParameterDefinition[];
}

export interface EventParameterDefinition {
    index: number;
    type: number;
    name: string;
    description: string;
    usage: number;
}

export interface EventClass {
    eventClassId: number;
    identifier: string;
    eventType: number;
    name: string;
    description: string;
    displaySequenceNo: number;
    definitions: number[];
}

export interface EventType {
    eventType: number;
    name: string;
    description: string;
    classes: number[];
}

export interface MeteringPointEventsRequest {
    meteringPointId: number;
    from: number;
    until: number;
    definitions: boolean;
}

export interface MeteringPointEventsResponse {
    events: Event[];
    classes?: EventClass[];
    definitions?: EventDefinition[];
    types?: EventType[];
}

export interface MeteringPointEventsDefinitionsResponse {
    types: EventType[];
    classes: EventClass[];
    definitions: EventDefinition[];
}
