export interface ChartMulti {
    name: string;
    series: ChartSerie[];
}

export interface ChartSerie {
    name: string | number;
    value: number;
}
export interface GraphDataEssentials {
    value: number;
    valueStartTime?: number;
    meteringId: number;
}
export interface Chartdata {
    calculationType: string;
    profileMeteringId: number;
    unit: string;
    value: number;
    valueCount: number;
    expectedValueCount: number;
    periodStart: number;
    periodEnd: number;
    calendarNumber: number;
    subUnits: Chartdata[] | undefined;
}
