// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { PercentOffComponent } from './percent-off.component';
// import { BoldPipe } from '../../pipes/sequence-num.pipe';

// describe('PercentOffComponent', () => {
//   let component: PercentOffComponent;
//   let fixture: ComponentFixture<PercentOffComponent>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ PercentOffComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(PercentOffComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });

//   //collapsed view tests
//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
  
//   it('should be expandable', () => {
//     expect(component.showExpandedView).toBeTruthy();
//   });

//   it('should be collapsable from the expanded view', () => {
//     expect(component.hideFromExpanded).toBeTruthy();
//   });

//   it('should render a headline in an h3 tag', async(() => {
//     const fixture = TestBed.createComponent(PercentOffComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('h3').textContent).toContain('Welcome to extracare!');
//   }));

//   it('should render a description', async(() => {
//     const fixture = TestBed.createComponent(PercentOffComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('span').textContent).toContain(this.data.webDsc);
//   }));

//   it('should render a send to card action in a p tag', async(() => {
//     const fixture = TestBed.createComponent(PercentOffComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('p').textContent).toContain('Send to card');
//   }));

//   //expanded view tests
//   it('should render a print action in a span tag', async(() => {
//     const fixture = TestBed.createComponent(PercentOffComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('span').textContent).toContain('print');
//   }));

//   it('should render a max issue count', async(() => {
//     const fixture = TestBed.createComponent(PercentOffComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('div').textContent).toContain('Use' + this.data.maxIssueCnt + 'times!');
//   }));

//   it('should render a redeem message', async(() => {
//     const fixture = TestBed.createComponent(PercentOffComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('div').textContent).toContain('Redeem in store or online');
//   }));

//   it('should render a sequence number', async(() => {
//     const fixture = TestBed.createComponent(PercentOffComponent);
//     fixture.detectChanges();
//     const compiled = fixture.debugElement.nativeElement;
//     expect(compiled.querySelector('div').textContent).toContain('Sequence No. ' + this.data.cpnSeqNbr);
//   }));

// });
