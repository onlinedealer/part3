import { HistoryDataModel } from './history-data-model';
import { HistoryHeaderModel } from './history-header.model';

export class HistoryTableSettingModel {
  sortable: boolean;
  defaultSort?: string;
  noHistoryFound: string;
  isTablePagination?: boolean;
  tableHeader: HistoryHeaderModel[];
  tableData: HistoryDataModel[];
}
