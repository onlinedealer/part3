import { Component, OnDestroy, OnInit } from "@angular/core";
import { MatDialogRef } from "@angular/material/dialog";
import { Store } from "@ngrx/store";
import { Observable, Subscription } from "rxjs";
import { OnDemandReadingService, OnDemandReading, OnDemandReadingVO, OnDemandReadingRequestType } from "../../models/ondemandreading.model";
import { MeteringPointDetails } from "../../models/meteringpoint.model";
import { Metering } from "../../models/metering.model";
import * as moment from "moment";
import { map } from "rxjs/operators";
import { MeterConnectionVO } from "../../models/view-objects/meterconnection-vo.model";
import { SorterService } from "../../../Shared/services/sorter.service";
import {
    OnDemandReadingsSelectors,
    MeterConnectionsWithConfigurationsSelectors,
    MeteringPointsSelectors,
    MeteringRegisterSelectors
} from "../../store/selectors";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { OnDemandReadingActions } from "../../store/actions";
import { DateFormatService } from "../../../Shared/services/date-format.service";

const ONE_DAY = 86400000;
const ONE_MONTH = 2678400000;

@Component({
    selector: "landisgyr-ondemandreading-dialog",
    templateUrl: "./ondemandreading-dialog.component.html",
    styleUrls: ["./ondemandreading-dialog.component.scss"]
})
export class OnDemandReadingDialogComponent implements OnInit, OnDestroy {
    onDmeandReadingServices$ = this.store.select(OnDemandReadingsSelectors.getOnDemandReadingTypeServices);

    supportedOnDemandReadings$: Observable<OnDemandReadingService[]> = this.store.select(
        OnDemandReadingsSelectors.getSelectedMeteringPointSupportedOnDemandServiceEntities
    );

    devices$: Observable<MeterConnectionVO[]> = this.store.select(
        MeterConnectionsWithConfigurationsSelectors.getSelectedMeteringPointMeterConnectionsEntitiesForTable
    );

    supportedOnDemandReadingsFetched$: Observable<boolean> = this.store.select(
        OnDemandReadingsSelectors.getSelectedMeteringPointSupportedOnDemandServicesFetched
    );

    profileMeteringsThatCanBeRead$: Observable<Metering[]> = this.store
        .select(MeteringRegisterSelectors.getSelectedMeteringPointProfileMeteringsFilteredByOnlyCurrentlyActiveProductComponents)
        .pipe(
            map((result) => {
                return this.sorterService.sortByMeteringType(result);
            })
        );
    periodicMeteringsThatCanBeRead$: Observable<Metering[]> = this.store
        .select(MeteringRegisterSelectors.getSelectedMeteringPointPeriodicMeteringsFilteredByOnlyCurrentlyActiveProductComponents)
        .pipe(
            map((result) => {
                return this.sorterService.sortByMeteringType(result);
            })
        );
    meteringPoint$: Observable<MeteringPointDetails | undefined> = this.store.select(
        MeteringPointsSelectors.getSelectedMeteringPointDetails
    );
    onDemandReadingRequests$: Observable<OnDemandReadingVO[]> = this.store
        .select(OnDemandReadingsSelectors.getSelectedMeteringPointOnDemandReadingsLatestFirst)
        .pipe(
            map((readings) => {
                const sorted = this.sorterService.sortByValueTimes(readings, "desc");
                return sorted;
            })
        );
    onDemandReadingRequestsFetching$: Observable<boolean> = this.store.select(
        OnDemandReadingsSelectors.getSelectedMeteringPointOnDemandReadingsAreRequesting
    );

    scheduledReadingRequests$: Observable<OnDemandReading[]> = this.store.select(
        OnDemandReadingsSelectors.getSelectedMeteringPointScheduledOnDemandReadingsLatestFirst
    );
    instanteneousReadingTypes$: Observable<string[]> = this.store.select(
        OnDemandReadingsSelectors.getSelectedMeteringPointInstanteneousValuesSupportedReadingTypes
    );

    selectedOnDemandReadingquestResults$: Observable<any | undefined> = this.store
        .select(OnDemandReadingsSelectors.getSelectedOnDemandReadingRequestResults)
        .pipe(
            map((result) => {
                if (!result) {
                    return undefined;
                }
                return {
                    ...result,
                    results: result.results ? this.sorterService.sortByMeteringType(result.results) : []
                };
            })
        );

    loadedActiveOnDemandServiceOperations: string[] = [];
    showSchedules = false;
    meteringPointSub!: Subscription;
    selectedReadingSubscription!: Subscription;
    dialogTitle: string;
    dialogSubTitle$: Observable<string>;
    afterDialogOpened$: Observable<void>;
    constructor(
        public dialogRef: MatDialogRef<OnDemandReadingDialogComponent>,
        private store: Store<MeteringPointsFeatureState>,
        private sorterService: SorterService,
        private dateFormatService: DateFormatService
    ) {
        this.dialogTitle = $localize`:|First part of dialog title text@@onDemandReadingDialog.readData:Read data`;

        this.dialogSubTitle$ = this.meteringPoint$.pipe(
            map((meteringPoint) => {
                return meteringPoint ? meteringPoint.name : "";
            })
        );
        this.afterDialogOpened$ = this.dialogRef.afterOpened();
        this.selectedReadingSubscription = this.afterDialogOpened$.subscribe(() => this.clearSelection());
    }

    ngOnInit(): void {
        this.loadLastResults();
    }
    scheduledReadingsClicked() {
        this.showSchedules = !this.showSchedules;
    }

    onClickCancel(): void {
        this.dialogRef.close();
    }

    clearSelection() {
        this.store.dispatch(OnDemandReadingActions.ClearSelectedOnDemandReadingResultFromModal());
    }

    onClickRead(onDemandReadingRequest: OnDemandReading): void {
        if (
            onDemandReadingRequest.requestType === OnDemandReadingRequestType.ReadPeriodicData &&
            onDemandReadingRequest.expectedReadingTime !== undefined &&
            onDemandReadingRequest.expectedReadingTime > 0
        ) {
            this.showSchedules = true;
        }
        this.store.dispatch(OnDemandReadingActions.RequestOnDemandReading({ payload: onDemandReadingRequest }));
        this.clearSelection();
    }

    onSelectedOnDemandReadingResult(result: OnDemandReading) {
        if (result.startTime && result.endTime && result.requestId) {
            this.store.dispatch(
                OnDemandReadingActions.SelectOnDemandReadingResult({
                    startTime: this.dateFormatService.toStartOfDay(result.startTime),
                    endTime: this.dateFormatService.toEndOfDay(result.endTime),
                    requestId: result.requestId,
                    requestType: result.requestType
                })
            );
        }
    }

    ngOnDestroy(): void {
        if (this.meteringPointSub) {
            this.meteringPointSub.unsubscribe();
        }
        if (this.selectedReadingSubscription) {
            this.selectedReadingSubscription.unsubscribe();
        }
    }

    onLinkClick(event: { requestType: string; meteringId: number; from: number; until: number }) {
        if (event.requestType === "ReadProfileData") {
            this.store.dispatch(
                OnDemandReadingActions.NavigateToOnDemandReadingMeteringDataResults({
                    meteringId: event.meteringId,
                    meteringType: "profile",
                    from: this.dateFormatService.toStartOfDay(event.from),
                    until: this.dateFormatService.toEndOfDay(event.until)
                })
            );
        } else if (event.requestType === "ReadPeriodicData") {
            this.store.dispatch(
                OnDemandReadingActions.NavigateToOnDemandReadingMeteringDataResults({
                    meteringId: event.meteringId,
                    meteringType: "periodic",
                    from: this.dateFormatService.toStartOfDay(event.from - ONE_MONTH),
                    until: this.dateFormatService.toEndOfDay(event.until)
                })
            );
        } else if (event.requestType === "ReadEventData") {
            this.store.dispatch(
                OnDemandReadingActions.NavigateToOnDemandReadingEventsResults({
                    from: this.dateFormatService.toStartOfDay(event.from - ONE_DAY),
                    until: this.dateFormatService.toEndOfDay(event.until + ONE_DAY)
                })
            );
        }

        this.dialogRef.close();
    }

    loadLastResults() {
        const now = new Date().getTime();
        const weekAgo = moment(now).subtract(1, "week").valueOf();
        if (this.meteringPointSub) {
            this.meteringPointSub.unsubscribe();
        }
        this.meteringPointSub = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointDetails).subscribe((meteringPoint) => {
            if (meteringPoint) {
                this.store.dispatch(
                    OnDemandReadingActions.LoadAllOnDemandReadings({
                        meteringPointId: meteringPoint.id,
                        from: weekAgo,
                        until: now
                    })
                );
            }
        });
    }
}
