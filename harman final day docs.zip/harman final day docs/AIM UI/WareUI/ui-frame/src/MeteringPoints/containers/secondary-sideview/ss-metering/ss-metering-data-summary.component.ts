import { Component, ChangeDetectionStrategy } from "@angular/core";

@Component({
    selector: "landisgyr-ss-metering-data-summary",
    templateUrl: "./ss-metering-data-summary.component.html",
    styleUrls: ["./ss-metering-data-summary.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSMeteringDataSummaryComponent {
    /*
    profileMeteringsTableForSummary$: Observable<SummaryTableVO> = this.store
        .select(fromProfileData.getSelectedProfileDataForSummaryView)
        .pipe(
            map(profileMetering => {
                return convertSummaryTableVOEpochsToDisplay(profileMetering, this.dateFormatService);
            })
        );

    */
}
