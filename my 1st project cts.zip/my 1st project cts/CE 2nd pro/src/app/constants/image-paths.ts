/**
 * This file is use to define all the image with paths used through out the application
 * 
 */

import {environment} from '../../environments/environment';

let path = environment.imagePath;

export const ImagePaths = {
    SITE_LOGO: path + "logo-CVS-red.png",
    EXTRACARE_LOGO: path + "dashboard-icons/img-extracare-logo-dWeb.svg",
    MOBILE_SITE_LOGO: path + "dashboard-icons/img-extracare-logo-mWeb.svg",
    PROFILE_ICON: path + "dashboard-icons/i-profile.svg",
    CIRCLE_ICON: path + "dashboard-icons/i-info-circle.svg",
    PENCIL_ICON: path + "dashboard-icons/i-pencil.svg",
    CAREPASS_HEART: path + "your-feed-images/cpn-carepass-heart.svg",
    CAREPASS_CAT: path + "your-feed-images/i-extra-buck-cat.svg",
    CAREPASS_BABY: path + "your-feed-images/i-baby-cat.svg",
    CAREPASS_BEAUTY: path + "your-feed-images/i-beauty-cat.svg",
    CAREPASS_GROCERY: path + "your-feed-images/i-grocery-cat.svg",
    CAREPASS_HEALTH: path + "your-feed-images/i-health-cat.svg",
    CAREPASS_HOUSEHOLD: path + "your-feed-images/i-household-cat.svg",
    CAREPASS_PERSONAL: path + "your-feed-images/i-personal-care-cat.svg",
    COUPON_FLAG: path + "coupon-images/i-new-flag-text.svg",
    COUPON_SEND_TO_CARD: path + "coupon-images/i-send-to-card.svg",
    COUPON_ONCARD: path + "coupon-images/i-on-card.svg",
    COUPON_SHOP: path + "coupon-images/i-shop-deal.svg",
    COUPON_PRINT: path + "coupon-images/i-print.svg",
    COUPON_RETAIL: path + "coupon-images/i-retail-store.svg",
    COUPON_LAPTOP: path + "coupon-images/i-laptop.svg",
    COUPON_PHONE:  path + "coupon-images/i-phone.svg",
    COUPON_XTRABUCKS: path + "coupon-images/cpn-extra-buck.svg",
    CAREPASS_LOGO: path + "coupon-images/carepass-logo.svg",
    EXTRABUCKS_CAT: path + "coupon-images/i-extra-buck-cat.svg",
    LOCK_IMG: path + "coupon-images/i-lock.svg",
    ICON_I_RED:  path + "anonymous/icon-i-red.png",
    SEARCH_ICON: path + "search-icons/i-search-web.svg",
    JOIN_NOW: path + 'coupon-images/i-caret.svg',
    COUPON_PRINTED: path + 'coupon-images/i-printed.svg',
    BEAUTY_CLUB_LOGO: path + 'coupon-images/beauty-club-logo.svg',
    MFR_DEFAULT_IMAGE: path + 'cpn-generic.svg'
}