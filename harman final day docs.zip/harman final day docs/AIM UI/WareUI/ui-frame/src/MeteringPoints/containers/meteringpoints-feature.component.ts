import { Component, ViewChild, ViewContainerRef, ComponentFactoryResolver, ComponentRef, OnInit, OnDestroy } from "@angular/core";
import { delay } from "rxjs/operators";
import { MeteringPointDetails } from "../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../store/reducers";
import { MeteringPointsUISelectors, MeteringPointsSelectors, XSFSearchSelectors } from "../store/selectors";
import { Observable, Subscription } from "rxjs";
import { SecondarySideviewService } from "../../Shared/services/secondary-sideview.service";
import { Store } from "@ngrx/store";
import { trigger, style, animate, transition, state } from "@angular/animations";
import { UIActions, UserSettingsActions } from "../../app/store/actions";
import { XSFSearchActions, MeteringPointsActions } from "../store/actions";
import * as MeteringPointUIActions from "../store/actions/ui.actions";
import * as AppstoreSelectors from "../../app/store/selectors";
import { Action } from "rxjs/internal/scheduler/Action";

@Component({
    templateUrl: "./meteringpoints-feature.component.html",
    styleUrls: ["./meteringpoints-feature.component.scss"],
    animations: [
        trigger("expandShrinkSideView", [
            state(
                "expand",
                style({
                    width: "100%"
                })
            ),
            state(
                "shrink",
                style({
                    width: "70vw"
                })
            ),
            transition("expand => shrink", [animate("0.2s")]),
            transition("shrink => expand", [animate("0.2s")])
        ])
    ]
})
export class MeteringPointsFeatureComponent implements OnInit, OnDestroy {
    sideViewOpened$: Observable<boolean> = this.store.select(MeteringPointsUISelectors.getMeteringPointsSideviewVisible);

    // Used only to delay the appearance of the sideview expand button
    sideViewOpenedSecondary$: Observable<boolean> = this.store
        .select(MeteringPointsUISelectors.getMeteringPointsSideviewVisible)
        .pipe(delay(600));
    sideViewExpanded$: Observable<boolean> = this.store.select(MeteringPointsUISelectors.getMeteringPointsSideviewExpanded);
    sideViewButtonVisible = true;

    showBottomTools$: Observable<boolean> = this.store.select(MeteringPointsSelectors.getIsSingleMeteringPointSelected);

    selectedMeteringPoint$: Observable<MeteringPointDetails | undefined> = this.store.select(
        MeteringPointsSelectors.getSelectedMeteringPointDetails
    );

    selectedMeteringPointId$: Observable<number | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointId);
    /*  Container reference for secondary sideviews */
    @ViewChild("secondarySideviewStack", { read: ViewContainerRef, static: true })
    secondarySideviewStackContainer!: ViewContainerRef;

    /* Secondary sideview component stack */
    secondarySideviews: any[] = [];

    sideViewMaxWidth = 0;

    secondarySideviewComponentRef!: ComponentRef<any>;

    secondarySideviewSub!: Subscription;

    userAndSessionInitializedSub!: Subscription;

    meteringPointsResultsCount$: Observable<number> = this.store.select(XSFSearchSelectors.getResultElementsCount);
    searched$: Observable<boolean> = this.store.select(XSFSearchSelectors.isSearched);

    selectedMeteringPointsAmount!: number;
    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private resolver: ComponentFactoryResolver,
        private secondarySideviewService: SecondarySideviewService
    ) {}

    ngOnInit(): void {
        this.userAndSessionInitializedSub = this.store
            .select(AppstoreSelectors.SecuritySelectors.isUserAndSessionLoaded)
            .subscribe((isUserAndSessionLoaded) => {
                if (isUserAndSessionLoaded) {
                    this.store.dispatch(UserSettingsActions.GetMeteringPointsSearchSettings());

                    this.store.dispatch(XSFSearchActions.CheckSessionXSFSearchGroupId());
                }
            });

        /*
            Subscribe to changes in SideViewStream.
            New components coming in are added automatically on top of each other.
            If incoming data is null, last sideview will be removed from the stack.
         */

        this.secondarySideviewSub = this.secondarySideviewService.getLatestSideViewStream().subscribe((component: any) => {
            if (component) {
                /**
                 * Create secondary sideview component dynamically
                 */
                this.secondarySideviews.push(component);
                this.createComponent();
            } else {
                /**
                 * Destroy secondary sideview component if null-value comes from the stream
                 */
                if (this.secondarySideviews.length > 0) {
                    this.secondarySideviewStackContainer.remove(this.secondarySideviews.length - 1);
                    this.secondarySideviews = this.secondarySideviews.slice(0, this.secondarySideviews.length - 1);
                }
            }
        });

        setTimeout(() =>
            this.store.dispatch(
                UIActions.FeatureModuleInitialized({
                    title: $localize`:|@@meteringpointsFeature.meteringpoints:Metering points`
                })
            )
        );

        this.store
            .select(MeteringPointsSelectors.getMeteringPointIdFromRouteParameters)
            .subscribe(
                (meteringPointId) =>
                    meteringPointId &&
                    this.store.dispatch(MeteringPointsActions.SelectMeteringPoint({ meteringPointId: Number(meteringPointId) }))
            )
            .unsubscribe();

        this.store.dispatch(MeteringPointUIActions.CheckIfMPSideviewOpen());
    }

    createComponent() {
        if (this.secondarySideviewStackContainer) {
            const latest = this.secondarySideviews.length - 1;
            const factory = this.resolver.resolveComponentFactory(this.secondarySideviews[latest].component);
            this.secondarySideviewComponentRef = this.secondarySideviewStackContainer.createComponent(factory);
            this.secondarySideviewComponentRef.instance.data = this.secondarySideviews[latest].data;
        }
    }

    ngOnDestroy() {
        if (this.secondarySideviewComponentRef) {
            this.secondarySideviewComponentRef.destroy();
        }

        if (this.secondarySideviewStackContainer) {
            this.secondarySideviewStackContainer.clear();
        }

        if (this.secondarySideviewSub) {
            this.secondarySideviewSub.unsubscribe();
        }

        if (this.userAndSessionInitializedSub) {
            this.userAndSessionInitializedSub.unsubscribe();
        }
    }
    onClickToggleExpandSideview() {
        this.sideViewButtonVisible = false;
        this.store.dispatch(MeteringPointUIActions.ToggleExpandMeteringPointSideview());
    }
    animDone(event: any) {
        this.sideViewButtonVisible = true;
    }
    reseaveSelectedMeteringPointsAmount(amount: number) {
        this.selectedMeteringPointsAmount = amount;
    }
}
