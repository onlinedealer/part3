export interface LocalSavedUserSettings {
    userDefinedTimeZone: string;
    userDefinedDateFormat: { format: string; separator: string };
    userDefinedTimeFormat: string;
    hours: "12" | "24";
}
