import { ScheduleBaseModel } from './schedule-base.model';

export class ScheduleWeeklyModel extends ScheduleBaseModel {
  daysOfWeek: Array<string>;
  constructor(data?) {
    super();
    this.daysOfWeek = data?.daysOfWeek ? data?.daysOfWeek : ['MON'];
    this.fromDate = data?.fromDate ? data?.fromDate : new Date(this.setFromDate());
    this.runAtTime = data?.runAtTime ? data?.runAtTime : new Date();
  }
}
