import { AfterViewInit, Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild, ChangeDetectorRef } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { Observable, Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { BaseComponent } from '../../../../../core/base.component';
import { SidebarButton } from '../../../../../shared/components/sidebar/sidebar-button';
import { PipelineEntityService } from '../../../shared/pipeline-entity.service';
import { LogReaderFormComponent } from '../logreader-form/logreader-form.component';
import { Connection } from '../../../../../connections/shared/connection';
import { LogReadersApiService } from '../../shared/logreaders-api.service';
import { LogReader } from '../../shared/logreader';
import { MetadataApiService } from '../../schema-table-selector/metadata-api.service';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';

@Component({
  selector: 'p-connect-logreader-sidebar',
  templateUrl: './logreader-sidebar.component.html'
})
export class LogReaderSidebarComponent extends BaseComponent implements AfterViewInit, OnDestroy {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * Reference to the LogReaderFormComponent child component
   */
  @ViewChild(LogReaderFormComponent) logReaderFormComponent: LogReaderFormComponent;

  /**
   * Event that is triggered when the sidebar visible state changes internally
   */
  @Output() isVisibleChanged = new EventEmitter<boolean>();

  /**
   * Source data connection
   */
  @Input() sourceDataConnection: Connection;

  /**
   * Event that is fired when a log reader has been saved
   */
  @Output() logReaderSavedEvent = new EventEmitter<LogReader>();

  primaryButton: SidebarButton = {
    id: 'createLogReaderAddButton',
    isDisabled: true,
    text: 'logreaders.LOGREADER_FORM.BUTTONS.ADD'
  };

  secondaryButton: SidebarButton = {
    id: 'createLogReaderResetDefaultButton',
    text: 'logreaders.LOGREADER_FORM.BUTTONS.RESET_TO_DEFAULT'
  };

  cancelButton: SidebarButton = {
    id: 'createLogReaderCancelButton',
    text: 'logreaders.LOGREADER_FORM.BUTTONS.CANCEL'
  };
  private formValueChangesSubscription: Subscription;
  isEditing = false;
  journals: any[] = [];
  skipHeader = new HttpHeaders().set(InterceptorSkipHeader, '');

  constructor(
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly logReadersApiService: LogReadersApiService,
    private readonly metadataApiService: MetadataApiService,
    private changeDetectorRef: ChangeDetectorRef
  ) {
    super();
  }

  ngOnDestroy(): void {
    this.formValueChangesSubscription?.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
    this.formValueChangesSubscription = this.logReaderFormComponent.logReaderFormGroup.valueChanges.subscribe(() =>
      this.updateButtonDisabledState()
    );
  }

  open(selectedLogReader?: LogReader): void {
    // add any functionality that you want to happen when the form is actually open
    if (selectedLogReader) {
      this.isEditing = true;
    } else {
      this.isEditing = false;
    }

    if (this.sourceDataConnection.connectionType === 'DB2I') {
      this.getJournals();
    }
    this.logReaderFormComponent.open(selectedLogReader);
    this.sidebarComponent.open();
  }

  addLogReader(): void {
    const projectId = this.pipelineEntityService.getPipeline().projectId;
    const connectionId = this.sourceDataConnection.id;
    let logReaderRequest = new Observable<LogReader>();
    this.sidebarComponent.isProcessingRequest = true;

    if (!this.isEditing) {
      logReaderRequest = this.logReadersApiService.createLogReader(
        connectionId,
        projectId,
        this.logReaderFormComponent.logReader,
        this.skipHeader
      );
    } else {
      logReaderRequest = this.logReadersApiService.updateLogReader(
        connectionId,
        projectId,
        this.logReaderFormComponent.logReader,
        this.skipHeader
      );
    }

    logReaderRequest
      .pipe(first())
      .subscribe({
        next: (response: LogReader) => {
          this.logReaderSavedEvent.emit(response);
          this.cancelButtonClicked();
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  getJournals(): void {
    this.sidebarComponent.isProcessingRequest = true;
    this.journals.length = 0;
    if (this.sourceDataConnection.connectionType === 'DB2I') {
      this.metadataApiService
        .getJournals(this.sourceDataConnection.id, this.pipelineEntityService.getPipeline().projectId, this.skipHeader)
        .pipe(first())
        .subscribe({
          next: (journals: string[]) => {
            this.journals = journals;
          },
          error: (errorResponse) => {
            this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
          }
        })
        .add(() => {
          this.sidebarComponent.isProcessingRequest = false;
        });
    }
  }

  cancelButtonClicked() {
    this.sidebarComponent.close();
    this.isVisibleChanged.emit(false);
    this.resetForm();
  }

  resetForm(): void {
    this.logReaderFormComponent.resetForm();
  }

  refreshClickEvent(): void {
    this.getJournals();
  }

  private updateButtonDisabledState(): void {
    this.primaryButton.isDisabled = !this.logReaderFormComponent.logReaderFormGroup.valid;
  }
}
