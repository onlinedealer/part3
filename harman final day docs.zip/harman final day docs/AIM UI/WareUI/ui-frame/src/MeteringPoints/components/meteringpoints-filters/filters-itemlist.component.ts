import { Component, Input } from "@angular/core";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { MeteringPointsUIActions } from "../../store/actions";
import { Store } from "@ngrx/store";

@Component({
    selector: "landisgyr-filters-itemlist",
    templateUrl: "./filters-itemlist.component.html",
    styleUrls: ["./filters-itemlist.component.scss"]
})
export class FiltersItemListComponent {
    @Input()
    title!: string;

    @Input()
    items!: string[];

    constructor(private store: Store<MeteringPointsFeatureState>) {}

    onSelectFilter(event: any, item: any) {
        if (event.srcElement.checked) {
            item.selectItem();
            this.store.dispatch(MeteringPointsUIActions.FilterAdd({ payload: item.name }));
        } else {
            item.deselectItem();
            this.store.dispatch(MeteringPointsUIActions.FilterRemove({ payload: item.name }));
        }
    }
}
