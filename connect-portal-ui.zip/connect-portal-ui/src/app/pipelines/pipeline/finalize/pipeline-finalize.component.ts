import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Subscription, firstValueFrom } from 'rxjs';
import { first } from 'rxjs/operators';
import { BaseComponent } from '../../../core/base.component';
import { StageConfigurationFormComponent } from '../../shared/stage-configuration-form/stage-configuration-form.component';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { PipelineFinalizeSummary } from './pipeline-finalize-summary/pipeline-finalize-summary';
import { DeployConfigurationFormComponent } from '../../shared/deploy-configuration-form/deploy-configuration-form.component';
import { PipelinesMonitoringApiService } from '../../shared/pipelines-monitoring-api.service';
import { PipelinesMonitoringStatus } from '../../shared/pipelines-monitoring-status';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { HttpHeaders } from '@angular/common/http';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { PIPELINE_ENTITY_TYPE } from '../shared/pipeline';
import { ProjectsApiService } from '../shared/projects-api.service';

@Component({
  selector: 'p-connect-pipeline-finalize',
  templateUrl: './pipeline-finalize.component.html'
})
export class PipelineFinalizeComponent extends BaseComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(StageConfigurationFormComponent) stageConfigurationFormComponent: StageConfigurationFormComponent;
  @ViewChild(DeployConfigurationFormComponent) deployConfigurationFormComponent: DeployConfigurationFormComponent;

  summaryData: PipelineFinalizeSummary = {};
  pipelineChangedSubscription$: Subscription;
  applyFormValueChanges$: Subscription;
  applyConfigurationFormGroup: FormGroup;
  anyPipelinesComitted = false;
  containsDB2ZOSSources = false;
  isProcessingRequest = false;
  deployErrorMessage = '';
  pipelineName = '';

  /**
   * Tempoary flag used to determine if the incremental commit feature is enabled
   */
  isIncrementalCommitFeatureEnabled = false;

  get stageChanges(): boolean {
    return this.applyConfigurationFormGroup.get('stageChanges')?.value;
  }

  readonly PIPELINE_TYPE = PIPELINE_ENTITY_TYPE;

  get pipelineEntityType(): string {
    return this.pipelineEntityService.pipelineEntityType;
  }

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService,
    private readonly progressIndicatorStateService: ProgressIndicatorStateService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly projectsApiService: ProjectsApiService
  ) {
    super();
  }

  public updatePipelineEntityService(): void {
    const deployForm = this.applyConfigurationFormGroup.controls.deployChangesFormGroup;
    this.pipelineEntityService.isStageChangesEnabled = this.applyConfigurationFormGroup.get('stageChanges')?.value;
    this.pipelineEntityService.isDeployChangesEnabled = deployForm.enabled && deployForm.get('makeChangesActive')?.value;
    this.pipelineEntityService.isStartPipelineRequested = this.applyConfigurationFormGroup.get('startPipeline')?.value;
    this.pipelineEntityService.isDisplayAlertsEnabled =
      this.pipelineEntityService.isDeployChangesEnabled && deployForm.get('monitorProgress')?.value;
    if (this.isIncrementalCommitFeatureEnabled) {
      this.pipelineEntityService.incrementalStage = this.applyConfigurationFormGroup.get('setStage').value;
    }
    if (this.pipelineEntityService.isDeployChangesEnabled) {
      this.pipelineEntityService.deployInfo = {
        queueTimeoutInMinutes: deployForm.get('backlogEmpty')?.value,
        tableCaptureTimeoutInMinutes: deployForm.get('tableCaptureDisabled')?.value,
        stopRequestTimeoutInMinutes: deployForm.get('replicationStopped')?.value,
        forceDeploy: deployForm.get('forceDeploy')?.value,
        dataFlowNames: this.pipelineEntityService.isStartPipelineRequested ? [this.pipelineName] : []
      };
    }
    // only invalid if deploy is enabled and the deploy form is not valid
    const invalid =
      this.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED
        ? !deployForm.valid
        : this.pipelineEntityService.isDeployChangesEnabled && !deployForm.valid;
    const finalizeStep = this.progressIndicatorStateService.progressSteps?.findIndex((p) => p.id === 'finalize');
    this.progressIndicatorStateService.setIsValid(finalizeStep, !invalid); // TODO: Use a constant to improve readability
  }

  async ngOnInit() {
    this.createForm();
    const currentPipeline = this.pipelineEntityService.getPipeline();
    this.pipelineName = currentPipeline.name;
    const project = await firstValueFrom(this.projectsApiService.get(currentPipeline.projectId));

    this.pipelineChangedSubscription$ = this.pipelineEntityService.pipelineChanged$.subscribe({
      next: (pipeline) => {
        const schemasCount = pipeline.source ? pipeline.source.selectedTables.length : 0;
        const allTables = pipeline.source
          ? pipeline.source.selectedTables.reduce((previousValue, currentValue) => {
              return [...previousValue, ...currentValue.value.tableAndKeys];
            }, [])
          : [];
        const tableCount = allTables.length;

        this.summaryData = {
          name: pipeline.name,
          description: pipeline.description,
          selectedSourceData: { noOfTables: tableCount, noOfSchemasOrLibraries: schemasCount },
          sourceConnectionName: pipeline.source ? pipeline.source.dataConnection.name : '',
          sourceConnectionType: pipeline.source ? `connections.CONNECTION_TYPES.${pipeline.source.dataConnection.connectionType}` : '',
          targetConnectionName: pipeline.target ? pipeline.target.dataConnection.name : '',
          targetConnectionType: pipeline.target ? `connections.CONNECTION_TYPES.${pipeline.target.dataConnection.connectionType}` : '',
          pipelineEntityType: this.pipelineEntityService.pipelineEntityType,
          projectName: project.name
        } as PipelineFinalizeSummary;

        this.containsDB2ZOSSources = pipeline.source?.dataConnection?.connectionType === 'DB2ZOS' && pipeline.dataFlowType !== 'COPY';
        this.pipelineName = pipeline.name;
      }
    });
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      return;
    }
    this.areThereAnyPipelinesComitted();
  }

  ngAfterViewInit(): void {
    // set the initial state
    if (this.pipelineEntityService.pipelineEntityType !== PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.isIncrementalCommitFeatureEnabled = this.featureFlagService.isFeatureEnabled('CDCIncrementalCommitTemp20220822');
    }
    this.updatePipelineEntityService();
    this.applyFormValueChanges$ = this.applyConfigurationFormGroup.valueChanges.subscribe({
      next: () => {
        this.updatePipelineEntityService();
      }
    });
  }

  ngOnDestroy(): void {
    this.applyFormValueChanges$.unsubscribe();
    this.pipelineChangedSubscription$.unsubscribe();
  }

  private createForm(): void {
    this.applyConfigurationFormGroup = this.formBuilder.group({
      stageChangesFormGroup: this.formBuilder.group({}),
      deployChangesFormGroup: this.formBuilder.group({}),
      startPipelineFormGroup: this.formBuilder.group({})
    });
  }

  stateChangesChanged(isChecked: boolean): void {
    this.updateDeployFormState(isChecked);
  }

  downloadJclCompleted(errorResponse): void {
    this.deployErrorMessage = '';

    if (errorResponse) {
      if (errorResponse.error) {
        this.deployErrorMessage = errorResponse.error.message;
      } else {
        this.deployErrorMessage = errorResponse.message;
      }
    }
  }

  private areThereAnyPipelinesComitted(): void {
    this.isProcessingRequest = true;
    this.anyPipelinesComitted = false;
    this.pipelinesMonitoringApiService
      .getStatus(this.pipelineEntityService.getPipeline().projectId, new HttpHeaders().set(InterceptorSkipHeader, ''))
      .pipe(first())
      .subscribe({
        next: (monitoringStatus: PipelinesMonitoringStatus) => {
          if (monitoringStatus.dataFlows) {
            this.anyPipelinesComitted = monitoringStatus.dataFlows.some((dataFlow) => dataFlow.captureStatus);
          }
        },
        error: () => {
          this.anyPipelinesComitted = false;
        }
      })
      .add(() => {
        this.isProcessingRequest = false;
        this.updateDeployFormState(this.applyConfigurationFormGroup.get('stageChanges')?.value);
      });
  }

  private updateDeployFormState(isChecked: boolean): void {
    if (!this.anyPipelinesComitted || !isChecked) {
      this.applyConfigurationFormGroup.controls.deployChangesFormGroup.disable();
    } else {
      this.applyConfigurationFormGroup.controls.deployChangesFormGroup.enable();
    }
  }
}
