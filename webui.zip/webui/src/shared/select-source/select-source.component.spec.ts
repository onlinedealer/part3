import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslocoModule, TranslocoService } from '@ngneat/transloco';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { ColumnModel, TableModel } from 'discovery-core';
import { AuthenticationService, ConnectionService, SharedModule } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/api';
import { ProfileService } from 'profiling/profile.service';
import { of, throwError } from 'rxjs';
import { SelectSourceComponent } from './select-source.component';

describe('SelectSourceComponent', () => {
  let component: SelectSourceComponent;
  let fixture: ComponentFixture<SelectSourceComponent>;
  let translocoService;

  beforeEach(async () => {
    Spies.init();

    await TestBed.configureTestingModule({
      declarations: [SelectSourceComponent],
      imports: [CommonModule, TranslocoModule, TranslocoLocaleModule.forRoot(), HttpClientTestingModule, SharedModule],
      providers: [
        { provide: AuthenticationService, useValue: Spies.AuthenticationService },
        { provide: ProfileService, useValue: Spies.ProfileService },
        { provide: ConnectionService, useValue: Spies.ConnectionService },
        { provide: ToastrService, useValue: Spies.ToastrService },
        { TranslocoService, useValue: Spies.TranslateService },
        { provide: ConfirmationService, useValue: Spies.ConfirmationService },
        { provide: LaunchDarklyService, useValue: Spies.launchDarklyService }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectSourceComponent);
    component = fixture.componentInstance;
    translocoService = TestBed.inject(TranslocoService);
    spyOn(translocoService, 'translate');
    component.multiSchemaFeatureFlag = false;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('validation failed connection', () => {
    const errors = component.validate();
    expect(errors.size).toBeGreaterThanOrEqual(1);
    expect(errors.has('discoveryShared.selectSource.invalidConnection')).toBe(true);
  });

  it('validation failed column', () => {
    component.selectedConnectionId = 'dummy';
    const errors = component.validate();
    expect(errors.size).toBeGreaterThanOrEqual(1);
    expect(errors.has('discoveryShared.selectSource.invalidColumn')).toBe(true);
  });

  it('validation success', () => {
    component.selectedConnectionId = 'dummy';
    component.tableData.length = 0;
    const tableColumnModel = new TableModel();
    tableColumnModel.selected = true;
    const connectionDetailTreeNodeModel = new TableModel(tableColumnModel);
    component.tableData.push(connectionDetailTreeNodeModel);
    const tableColumnModelChild = new ColumnModel();
    tableColumnModelChild.selected = true;
    component.tableData[0].columns.push(new ColumnModel(tableColumnModelChild));
    const errors = component.validate();
    expect(errors.size).toBe(0);
  });

  it('test selected connection changes', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    spyOn(component.selectedConnectionIdChange, 'emit');
    component.selectedConnectionChanged();
    expect(component.selectedConnectionIdChange.emit).toHaveBeenCalled();
  });

  it('test ngOnInit success', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    Spies.ConnectionService.getTableList.and.returnValue(of(Mocks.MockTables));
    component.ngOnInit();
    expect(component.schemaLoading).toBe(false);
    expect(component.tableData).toHaveSize(Mocks.MockTables.length);
  });

  it('test ngOnInit failure', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    Spies.ConnectionService.getTableList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.ngOnInit();
    expect(component.schemaLoading).toBe(false);
    expect(Spies.ToastrService.error).toHaveBeenCalled();
  });

  it('test loadTables success', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);
    component.isShowColumns = false;
    tableModel1.uniqueKey = '0-dummy-table';
    columnModel1.selected = false;
    columnModel1.uniqueKey = '0-dummy-table-column';
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns = [];
    component.tableData[0].columns.push(columnModel1);
    component.tableData[0].count = 1;
    component.tableData[0].selected = false;
    Spies.ConnectionService.getTableList.and.returnValue(of(Mocks.MockTables));
    spyOn<any>(component, 'setDataSnapshot').and.callThrough();
    component.loadTables();
    component.setTableData(Mocks.MockTables);
    expect(component['setDataSnapshot']).toHaveBeenCalled();
    expect(component.schemaLoading).toBe(false);
    expect(component.tableData).toHaveSize(Mocks.MockTables.length);
  });
  it('test loadTables failure', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    Spies.ConnectionService.getTableList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.loadTables();
    expect(component.schemaLoading).toBe(false);
    expect(Spies.ToastrService.error).toHaveBeenCalled();
  });

  it('test loadColumnData failure', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    Spies.ConnectionService.getColumnList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    const tableModel1 = new TableModel(Mocks.MockTables[1]);
    component.loadColumnData(tableModel1);
    expect(component.columnLoading).toBe(false);
    expect(Spies.ToastrService.error).toHaveBeenCalled();
  });

  it('test nodeclicked for table whose columns have not been fetched', () => {
    component.isShowColumns = true;
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    columnModel1.selected = false;
    columnModel1.uniqueKey = '0-dummy-table-column';
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.schemaData.push({ name: Mocks.MockTables[0].schema, count: 0, selected: true, children: [] });
    component.checkedTables.push(tableModel1);

    component.selectedTable = tableModel1;

    component.selectedConnection = Mocks.MockConnections[0];
    component.tableData[0].columns = [];
    component.tableData[0].columns.push(columnModel1);
    component.tableData[0].count = 1;
    component.tableData[0].selected = false;
    spyOn(component.selectListTableChange, 'emit');
    component.onSelectTable(tableModel1);
    expect(component.selectListTableChange.emit).toHaveBeenCalled();
  });

  it('test partial columns selected', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);
    const columnModel2 = new ColumnModel(Mocks.MockColumns[1]);
    const columnModel3 = new ColumnModel(Mocks.MockColumns[2]);

    const tableModel2 = new TableModel(Mocks.MockTables[1]);
    const tableModel3 = new TableModel(Mocks.MockTables[2]);

    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData.push(tableModel2);
    component.tableData.push(tableModel3);
    component.isShowColumns = true;
    columnModel1.selected = true;
    columnModel2.selected = true;
    component.tableData[0].columns = [];
    component.tableData[0].columns.push(columnModel1);
    component.tableData[0].count = 1;
    component.tableData[0].selected = false;
    component.isShowColumns = true;
    component.selectedConnection = Mocks.MockConnections[0];
    spyOn(component.selectListTableChange, 'emit');
    component.onSelectTable(tableModel1);
    expect(component.selectListTableChange.emit).toHaveBeenCalled();
  });

  it('test none selected', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);
    const columnModel2 = new ColumnModel(Mocks.MockColumns[1]);
    const columnModel3 = new ColumnModel(Mocks.MockColumns[2]);

    const tableModel2 = new TableModel(Mocks.MockTables[1]);
    const tableModel3 = new TableModel(Mocks.MockTables[2]);

    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData.push(tableModel2);
    component.isShowColumns = true;
    component.tableData[0].columns = [];
    component.tableData[0].columns.push(columnModel1);
    component.tableData[0].count = 1;
    component.tableData[0].selected = false;
    component.selectedConnection = Mocks.MockConnections[0];
    component.isShowColumns = true;
    spyOn(component.selectListTableChange, 'emit');
    component.onSelectTable(tableModel1);
    expect(component.selectListTableChange.emit).toHaveBeenCalled();
  });

  it('test load profile settings', () => {
    spyOn(component, 'loadTables');
    component.loadProfileSettings(Mocks.MockProfiles[0]);
    const errors = component.validate();
    expect(errors.size).toBeGreaterThanOrEqual(1);
  });

  it('validation failed with non variant column', () => {
    component.isVariantType = true;
    component.variantTableMap = {
      dummytable: true
    };
    const tableData = [
      {
        name: 'DEMOGRAHICS_TABLE',
        schema: 'PUBLIC',
        type: 'TABLE',
        displayName: 'DEMOGRAHICS_TABLE (TABLE)',
        count: 0,
        selected: true,
        uniqueKey: '0-DEMOGRAHICS_TABLE',
        columns: Mocks.MockColumns
      }
    ];
    component.tableData.push(...tableData);
    const errors = component.validate();
    expect(errors.size).toBeGreaterThanOrEqual(1);
    // expect(Spies.ConfirmationService['confirm']).toHaveBeenCalled();
  });

  it('test updateSelectedTables function', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);
    const tables: TableModel[] = [];
    tableModel1.uniqueKey = '0-dummy-table';
    columnModel1.selected = false;
    columnModel1.uniqueKey = '0-dummy-table-column';
    component.isShowColumns = true;
    component.tableData.push(tableModel1);
    tables.push(tableModel1);
    tables[0].columns.push(columnModel1);
    component.schemaData.push({ name: Mocks.MockTables[0].schema, count: 0, selected: true, children: [] });
    component.selectedSchema = component.schemaData[0]; // Assuming first schema will be selected Schema
    component.checkedTables.push(tableModel1);
    component.selectedConnection = Mocks.MockConnections[0];
    component.selectedTable = tableModel1;
    component.tableData[0].columns = [];
    component.tableData[0].columns.push(columnModel1);
    component.tableData[0].count = 1;
    component.tableData[0].selected = false;
    spyOn(component.selectListTableChange, 'emit');

    component.updateSelectedTables(tables);
    expect(component.selectListTableChange.emit).toHaveBeenCalled();
    expect(component.checkedTables.length).toBeGreaterThanOrEqual(1);
  });

  it('test tableSelectionChanged checked event', () => {
    component.checkSelectionMode = false;
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    columnModel1.selected = false;
    columnModel1.uniqueKey = '0-dummy-table-column';
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.schemaData.push({ name: Mocks.MockTables[0].schema, count: 0, selected: true, children: [] });
    component.checkedTables.push(tableModel1);
    component.selectedConnection = Mocks.MockConnections[0];
    component.selectedTable = tableModel1;

    component.tableData[0].columns = [];
    component.tableData[0].columns.push(columnModel1);
    component.tableData[0].count = 1;
    component.tableData[0].selected = true;
    spyOn(component.selectListTableChange, 'emit');

    component.tableSelectionChanged(tableModel1, true);
    expect(component.selectListTableChange.emit).toHaveBeenCalled();
    expect(component.checkedTables.length).toBeGreaterThanOrEqual(1);
  });

  it('test tableSelectionChanged unchecked event', () => {
    component.checkSelectionMode = false;
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    columnModel1.selected = false;
    columnModel1.uniqueKey = '0-dummy-table-column';
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.schemaData.push({ name: Mocks.MockTables[0].schema, count: 0, selected: true, children: [] });
    component.checkedTables.push(tableModel1);
    component.selectedConnection = Mocks.MockConnections[0];
    component.selectedTable = tableModel1;

    spyOn(component.selectListTableChange, 'emit');

    component.tableSelectionChanged(tableModel1, false);
    expect(component.selectListTableChange.emit).toHaveBeenCalled();

    expect(component.checkedTables.length).toBe(0);
  });
  it('test columnSelectionChanged checked event', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    columnModel1.selected = false;
    columnModel1.uniqueKey = '0-dummy-table-column';
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({ name: Mocks.MockTables[0].schema, count: 0, selected: true, children: [] });
    component.selectedSchema = component.schemaData[0];
    component.checkedColumns.push(columnModel1);
    component.selectedConnection = Mocks.MockConnections[0];
    component.selectedTable = tableModel1;
    component.isShowColumns = true;
    spyOn(component.selectListTableChange, 'emit');

    component.columnSelectionChanged(columnModel1, true);
    component.tableData[0].columns[0].selected = true;

    expect(component.selectListTableChange.emit).toHaveBeenCalled();

    expect(component.checkedColumns.length).toBeGreaterThanOrEqual(1);
  });
  it('test columnSelectionChanged unchecked event', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    columnModel1.selected = false;
    columnModel1.uniqueKey = '0-dummy-table-column';
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({ name: Mocks.MockTables[0].schema, count: 0, selected: true, children: [] });
    component.selectedSchema = component.schemaData[0];
    component.checkedColumns.push(columnModel1);
    component.selectedConnection = Mocks.MockConnections[0];
    component.selectedTable = tableModel1;
    component.isShowColumns = true;
    spyOn(component.selectListTableChange, 'emit');

    component.columnSelectionChanged(columnModel1, false);
    component.tableData[0].columns[0].selected = false;

    expect(component.selectListTableChange.emit).toHaveBeenCalled();
    expect(component.checkedColumns.length).toBe(0);
  });

  it('should select the connection on updateConnetionDropdown', () => {
    component.updateConnectionTimeout = setTimeout(() => {
      //a dummy test timeout
    }, 500);
    jasmine.clock().install();
    component.updateConnectionDropdown('b26627bf-2535-4835-b8b0-0ba9d58358aa');
    jasmine.clock().tick(500);
    expect(component.selectedConnection.id).toBe('b26627bf-2535-4835-b8b0-0ba9d58358aa');
    jasmine.clock().uninstall();
  });

  it('should reset the previous selection after load table is executed', () => {
    component.multiSchemaFeatureFlag = true;
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: true,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    component.selectedConnection = Mocks.MockConnections[0];
    component.loadTables();
    // component.setDataSnapshot(Mocks.MockTables);
    expect(component.columnData.length).toBe(0);
    expect(component.checkedColumns.length).toBe(0);
    expect(component.checkedTables.length).toBe(0);
    expect(component.selectedTable).toBeNull();
  });

  it('should reset checked tables and column data when load table is called', () => {
    component.resetTablesAndColumns();
    expect(component.columnData.length).toBe(0);
    expect(component.checkedColumns.length).toBe(0);
    expect(component.checkedTables.length).toBe(0);
    expect(component.selectedTable).toBeNull();
    expect(component.isShowColumns).toBeFalse();
  });

  it('should reset all selection of schema, table and column when loadSchema is called ', () => {
    component.multiSchemaFeatureFlag = true;
    component.resetAllSelections();
    expect(component.columnData.length).toBe(0);
    expect(component.checkedColumns.length).toBe(0);
    expect(component.checkedTables.length).toBe(0);
    expect(component.schemaData.length).toBe(0);
    expect(component.schemaConfiguration.data.length).toBe(0);
    expect(component.tableConfiguration.data.length).toBe(0);
    expect(component.columnConfiguration.data.length).toBe(0);
    expect(component.selectedTable).toBeNull();
    expect(component.selectedTable).toBeNull();
    expect(component.showError).toBeFalse();
    expect(component.selectedSchema).toBeNull();
  });

  it('should not call confirmation dialog when onColumnsCheckedUnchecked checked event is called', () => {
    component.multiSchemaFeatureFlag = true;
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    tableModel1.selected = true;
    columnModel1.selected = true;
    columnModel1.schema = 'testSchema';
    columnModel1.selected = true;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: true,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    component.checkedColumns.push(columnModel1);
    component.selectedConnection = Mocks.MockConnections[0];
    component.selectedTable = tableModel1;
    component.isShowColumns = true;
    spyOn(component, 'onConfirmSchemaChange');
    component.onColumnsCheckedUnchecked(columnModel1, true);
    component.tableData[0].columns[0].selected = true;
    expect(component.onConfirmSchemaChange).not.toHaveBeenCalled();
  });

  it('should call confirmation dialog when onColumnsCheckedUnchecked checked event is called', () => {
    component.multiSchemaFeatureFlag = true;
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    tableModel1.selected = true;
    columnModel1.selected = true;
    columnModel1.schema = 'testSchema';
    columnModel1.selected = true;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: true,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    component.checkedColumns.push({ ...columnModel1, schema: 'otherSchema' });
    component.selectedConnection = Mocks.MockConnections[0];
    component.selectedTable = tableModel1;
    component.isShowColumns = true;
    spyOn(component, 'onConfirmSchemaChange');
    component.onColumnsCheckedUnchecked(component.checkedColumns[0], true);
    component.tableData[0].columns[0].selected = true;
    expect(component.onConfirmSchemaChange).toHaveBeenCalled();
  });

  it('should unselect all other schema`s selection on new schema selection', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    tableModel1.selected = true;
    columnModel1.selected = true;
    columnModel1.schema = 'testSchema';
    columnModel1.selected = true;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: true,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    component.unCheckPreviousSelectedTableAndColumn();
    expect(component.schemaData[0].children[0].selected).toBeFalse();
    expect(component.schemaData[0].children[0].columns[0].selected).toBeFalse();
  });

  it('should return the selected schema if any of the table or column is selected', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    tableModel1.selected = true;
    columnModel1.selected = true;
    columnModel1.schema = 'testSchema';
    columnModel1.selected = true;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: true,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    const schemaWithSelection = component.checkIfTableSelected();
    expect(schemaWithSelection.length).toBeGreaterThan(0);
  });

  it('should return the empty array if none of the table or column is selected', () => {
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    tableModel1.selected = false;
    columnModel1.schema = 'testSchema';
    columnModel1.selected = false;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: false,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    const schemaWithSelection = component.checkIfTableSelected();
    expect(schemaWithSelection.length).toBe(0);
  });

  it('should not call confirmation dialog when onTableCheckedUnchecked checked event is called', () => {
    component.multiSchemaFeatureFlag = true;
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    tableModel1.selected = true;
    columnModel1.selected = true;
    columnModel1.schema = 'testSchema';
    columnModel1.selected = true;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: true,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    component.selectedTable = tableModel1;
    component.isShowColumns = true;
    spyOn(component, 'onConfirmSchemaChange');
    component.onTableCheckedUnchecked(tableModel1, true);
    component.tableData[0].columns[0].selected = true;
    expect(component.onConfirmSchemaChange).not.toHaveBeenCalled();
  });

  it('should call confirmation dialog when onTableCheckedUnchecked checked event is called', () => {
    component.multiSchemaFeatureFlag = true;
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);

    tableModel1.uniqueKey = '0-dummy-table';
    tableModel1.selected = true;
    columnModel1.selected = true;
    columnModel1.schema = 'testSchema';
    columnModel1.selected = true;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns.push(columnModel1);
    component.schemaData.push({
      name: Mocks.MockTables[0].schema,
      count: 0,
      selected: true,
      children: component.tableData
    });
    component.selectedSchema = component.schemaData[0];
    component.selectedTable = { ...tableModel1, schema: 'otherSchema' };
    component.isShowColumns = true;
    spyOn(component, 'onConfirmSchemaChange');
    component.onTableCheckedUnchecked(component.selectedTable, true);
    component.tableData[0].columns[0].selected = true;
    expect(component.onConfirmSchemaChange).toHaveBeenCalled();
  });

  it('should call loadTables if on schema select tables doesnt are not loaded', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    component.schemaData.push({ name: 'testSchema', count: 0, selected: true, children: [] });
    spyOn(component, 'loadTables');
    component.onSchemaSelect(component.schemaData[0]);
    expect(component.loadTables).toHaveBeenCalled();
  });

  it('should not call loadTables if on schema select tables are already present', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    component.tableData.push(tableModel1);
    component.schemaData.push({ name: 'testSchema', count: 0, selected: true, children: component.tableData });
    spyOn(component, 'loadTables');
    spyOn(component, 'onSelectTable');
    component.onSchemaSelect(component.schemaData[0]);
    expect(component.loadTables).not.toHaveBeenCalled();
    expect(component.onSelectTable).toHaveBeenCalled();
  });

  it('should set Table Data and table configuration data', () => {
    component.selectedConnection = Mocks.MockConnections[0];
    const tableModel1 = new TableModel(Mocks.MockTables[0]);
    const columnModel1 = new ColumnModel(Mocks.MockColumns[0]);
    component.isShowColumns = false;
    component.tableData.length = 0;
    component.tableData.push(tableModel1);
    component.tableData[0].columns = [];
    component.tableData[0].columns.push(columnModel1);
    component.tableData[0].count = 1;
    component.tableData[0].selected = false;
    Spies.ConnectionService.getTableList.and.returnValue(of(Mocks.MockTables));
    spyOn<any>(component, 'setDataSnapshot').and.callThrough();
    component.loadTables();
    component.setTableData(Mocks.MockTables);
    expect(component['setDataSnapshot']).toHaveBeenCalled();
    expect(component.schemaLoading).toBe(false);
    expect(component.tableData).toHaveSize(Mocks.MockTables.length);
    expect(component.tableConfiguration.data).toHaveSize(Mocks.MockTables.length);
  });

  it('should initialize table configuration, column configuration, schema configuration', () => {
    spyOn(component, 'initSchemaConfiguration');
    spyOn(component, 'initTableConfiguration');
    spyOn(component, 'initColumnConfiguration');
    component.ngOnInit();
    expect(component.initSchemaConfiguration).toHaveBeenCalled();
    expect(component.initTableConfiguration).toHaveBeenCalled();
    expect(component.initColumnConfiguration).toHaveBeenCalled();
  });

  it('should call `setFetchButtonText` when component initilizes  ', () => {
    spyOn(component, 'setFetchButtonText');
    component.ngOnInit();
    expect(component.setFetchButtonText).toHaveBeenCalled();
  });

  it('multiSchemaFeatureFlag should be `true` if feature flag is `ON`  ', () => {
    component.multiSchemaFeatureFlag = true;
    component.ngOnInit();
    expect(component.multiSchemaFeatureFlag).toBeTrue();
  });

  it('multiSchemaFeatureFlag should be `false` if feature flag is `OFF`  ', () => {
    component.multiSchemaFeatureFlag = false;
    component.ngOnInit();
    expect(component.multiSchemaFeatureFlag).toBeFalse();
  });

  afterAll(() => {
    component.multiSchemaFeatureFlag = false;
    TestBed.resetTestingModule();
  });
});
