import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { BaseApiService } from './base-api.service';

/**
 * Abstract class that provides basic CRUD endpoints
 * Any service that interacts with the Catalog API should extend this base service
 */
export abstract class BaseEventApiService<T> extends BaseApiService<T> {
  constructor(protected httpClient: HttpClient, protected url?: string) {
    super(httpClient, environment.eventApiBaseURL, url);
  }
}
