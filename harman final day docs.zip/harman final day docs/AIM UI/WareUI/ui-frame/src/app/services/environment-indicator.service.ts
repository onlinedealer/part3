import { catchError } from "rxjs/operators";
import { environment } from "../../environments/environment";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { SecurityHTTPService } from "./security-http.service";
import { EnvironmentIndicator } from "../models/environment-indicator.model";

@Injectable({
    providedIn: "root"
})
export class EnvironmentIndicatorService {
    constructor(private http: SecurityHTTPService) {}

    getEnvironmentIndicator(): Observable<EnvironmentIndicator> {
        return this.http
            .get<any>(`${environment.backend_api_prefix}/config/environment/`)
            .pipe(catchError((error: any) => throwError(error.json())));
    }
}
