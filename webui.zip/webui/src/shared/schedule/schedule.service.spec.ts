import { Spies } from 'discovery-test';
import { ScheduleService } from './schedule.service';
describe('ScheduleService', () => {
  let service: ScheduleService;
  beforeEach(() => {
    Spies.init();
    service = new ScheduleService(Spies.HttpClient, Spies.AuthenticationService, Spies.HttpUtilService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getScheduleHistory be called', () => {
    service.getScheduleHistory('123').subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });
});
