import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { forkJoin, of } from 'rxjs';
import { catchError, first } from 'rxjs/operators';
import { AgentsApiService } from '../agents/shared/agents-api.service';
import { BaseComponent } from '../core/base.component';
import { PipelinesApiService } from '../pipelines/pipeline/shared/pipelines-api.service';
import { ServersApiService } from '../servers/shared/servers-api.service';
import { BreadcrumbItem } from '../shared/components/breadcrumb/breadcrumb-item';
import { ProgressIndicatorStateService } from '../shared/components/progress-indicator/progress-indicator-state.service';
import { ProgressStep } from '../shared/components/progress-indicator/progress-step';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { ProjectsApiService } from '../pipelines/pipeline/shared/projects-api.service';

@Component({
  selector: 'p-connect-home',
  templateUrl: './home.component.html',
  providers: [ProgressIndicatorStateService]
})
export class HomeComponent extends BaseComponent implements OnInit {
  isLoadingPage: boolean;
  breadcrumbs: BreadcrumbItem[] = [
    { text: 'common.BREADCRUMBS.APP_ROOT', isActive: true },
    { text: 'common.BREADCRUMBS.SETUP', isActive: true }
  ];

  projectStep: ProgressStep = {
    text: 'home.PROJECTS.PROJECT',
    routerLink: ['/home/project'],
    isValid: false,
    isComplete: false,
    isOptional: false,
    preventAfterComplete: true
  };

  progressSteps: ProgressStep[] = [
    {
      text: 'home.AGENTS.AGENT',
      routerLink: ['/home/agent'],
      isValid: false,
      isComplete: false,
      isOptional: false,
      preventAfterComplete: true
    },
    {
      text: 'home.SERVERS.SERVER',
      routerLink: ['/home/server'],
      isValid: false,
      isComplete: false,
      isOptional: false,
      preventAfterComplete: true
    },
    {
      text: 'home.PIPELINES.PIPELINE',
      routerLink: ['/home/pipeline'],
      isValid: true,
      isComplete: false,
      isOptional: false,
      preventAfterComplete: true
    }
  ];
  homePageApiErrorMessage: string;

  constructor(
    public router: Router,
    private readonly progressIndicatorStateService: ProgressIndicatorStateService,
    private readonly agentsApiService: AgentsApiService,
    private readonly serversApiService: ServersApiService,
    private readonly pipelinesApiService: PipelinesApiService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly projectsApiService: ProjectsApiService
  ) {
    super(router);
  }

  ngOnInit() {
    this.isLoadingPage = true;
    if (this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421')) {
      this.progressSteps.splice(2, 0, this.projectStep);
    }
    this.configurationCheck();
  }

  private readonly setInitialStep = () => {
    const url = this.router.url;
    const urlForProgressIndicator = url.replace('/data-integration', '');
    this.progressIndicatorStateService.setActiveStepByRouterLink(urlForProgressIndicator);
  };

  private configurationCheck() {
    const agentsServiceRequest = this.agentsApiService.getAll().pipe(catchError((error) => of(error)));
    const serversServiceRequest = this.serversApiService.getAll().pipe(catchError((error) => of(error)));
    const pipelinesServiceRequest = this.pipelinesApiService.getAll().pipe(catchError((error) => of(error)));
    const projectsServiceRequest = this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421')
      ? this.projectsApiService.getAll().pipe(catchError((error) => of(error)))
      : of([]);

    forkJoin([agentsServiceRequest, serversServiceRequest, pipelinesServiceRequest, projectsServiceRequest])
      .pipe(first())
      .subscribe({
        next: ([agentsApiResponse, serversApiResponse, pipelinesApiResponse, projectsApiResponse]) => {
          this.progressIndicatorStateService.initiateProgressSteps(this.progressSteps);
          this.setInitialStep();

          const agentsConfigured = Array.isArray(agentsApiResponse) && agentsApiResponse.length > 0;
          const agentsHttpResponseError = !Array.isArray(agentsApiResponse) && agentsApiResponse instanceof HttpErrorResponse;
          const serversConfigured = Array.isArray(serversApiResponse) && serversApiResponse.length > 0;
          const serversHttpResponseError = !Array.isArray(serversApiResponse) && serversApiResponse instanceof HttpErrorResponse;
          const projectsConfigured = Array.isArray(projectsApiResponse) && projectsApiResponse.length > 0;
          const projectsHttpResponseError = !Array.isArray(projectsApiResponse) && projectsApiResponse instanceof HttpErrorResponse;
          const pipelinesConfigured = Array.isArray(pipelinesApiResponse) && pipelinesApiResponse.length > 0;
          const pipelinesHttpResponseError = !Array.isArray(pipelinesApiResponse) && pipelinesApiResponse instanceof HttpErrorResponse;

          // agents
          if (!agentsConfigured && !agentsHttpResponseError) {
            this.isLoadingPage = false;
            this.progressIndicatorStateService.setIsComplete(0, false);
            this.progressIndicatorStateService.setActiveStepIndex(0);
            this.navigateTo('home/agent');
          } else {
            if (agentsHttpResponseError) {
              this.isLoadingPage = false;
              this.progressIndicatorStateService.setIsComplete(0, false);
              this.progressIndicatorStateService.setActiveStepIndex(0);
              this.navigateTo('home/agent');
              this.homePageApiErrorMessage = agentsApiResponse.message;
            } else {
              this.progressIndicatorStateService.setIsComplete(0, true);

              // servers
              if (!serversConfigured && !serversHttpResponseError) {
                this.isLoadingPage = false;
                this.progressIndicatorStateService.setIsComplete(1, false);
                this.progressIndicatorStateService.setActiveStepIndex(1);
                this.navigateTo('home/server');
              } else {
                if (serversHttpResponseError) {
                  this.isLoadingPage = false;
                  this.progressIndicatorStateService.setIsComplete(1, false);
                  this.progressIndicatorStateService.setActiveStepIndex(1);
                  this.navigateTo('home/server');
                  this.homePageApiErrorMessage = serversApiResponse.message;
                } else {
                  this.progressIndicatorStateService.setIsComplete(1, true);

                  if (this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421')) {
                    if (!projectsConfigured && !projectsHttpResponseError) {
                      this.isLoadingPage = false;
                      this.progressIndicatorStateService.setIsComplete(2, false);
                      this.progressIndicatorStateService.setActiveStepIndex(2);
                      this.navigateTo('home/project');
                    } else {
                      if (projectsHttpResponseError) {
                        this.isLoadingPage = false;
                        this.progressIndicatorStateService.setIsComplete(2, false);
                        this.progressIndicatorStateService.setActiveStepIndex(2);
                        this.navigateTo('home/project');
                        this.homePageApiErrorMessage = projectsApiResponse.message;
                      } else {
                        this.progressIndicatorStateService.setIsComplete(2, true);
                        this.pipelineStep(pipelinesApiResponse, pipelinesConfigured, pipelinesHttpResponseError);
                      }
                    }
                  } else {
                    this.pipelineStep(pipelinesApiResponse, pipelinesConfigured, pipelinesHttpResponseError);
                  }
                }
              }
            }
          }
        }
      });
  }

  private pipelineStep(pipelinesApiResponse: any, pipelinesConfigured: any, pipelinesHttpResponseError: any): void {
    // pipelines
    if (!pipelinesConfigured && !pipelinesHttpResponseError) {
      this.isLoadingPage = false;
      this.progressIndicatorStateService.setIsComplete(this.progressSteps.length - 1, false);
      this.progressIndicatorStateService.setActiveStepIndex(this.progressSteps.length - 1);
      this.navigateTo('home/pipeline');
    } else {
      if (pipelinesHttpResponseError) {
        this.progressIndicatorStateService.setIsComplete(this.progressSteps.length - 1, false);
        this.progressIndicatorStateService.setActiveStepIndex(this.progressSteps.length - 1);
        this.navigateTo('home/pipeline');
        this.homePageApiErrorMessage = pipelinesApiResponse.message;
      } else {
        if (this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421') === true) {
          this.navigateTo('projects');
        } else {
          this.navigateTo('pipelines');
        }
      }
    }
  }
}
