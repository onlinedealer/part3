import { ServerSentEventsService } from 'discovery-shared';
import { Spies } from 'discovery-test';

describe('ServerSentEventsService', () => {
  let service: ServerSentEventsService;

  beforeEach(() => {
    service = new ServerSentEventsService(Spies.NgZone, Spies.AuthenticationService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should register an eventsource against url', () => {
    service.getServerSentEvent('testUrl').subscribe((value) => {
      expect(service.events['testUrl']).toBeDefined();
    });
  });
});
