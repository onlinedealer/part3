(function() {
    'use strict';

    fileuploader.service('fileModel', ['$http','$q', function ($http,$q) {
		   /* this.uploadFileToUrl = function(file, uploadUrl){		       
		        $http.post(uploadUrl, file, {
		            transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
		        })
		        .success(function(){
		        })
		        .error(function(){
		        });
		    }
		   */
			this.uploadFileToUrl = function(path, file, params) {
            var deferred = $q.defer();
            $http({
                    method: 'POST',
                    url: path,
                    data: JSON.stringify(params),
					transformRequest: angular.identity,
		            headers: {'Content-Type': undefined}
                })
                .success(function(data, status, headers, config) {
                    deferred.resolve(data);
                })
                .error(function(data, status, headers, config) {
                    deferred.reject(data);
                });

            return deferred.promise;
        };
}]);
})();
