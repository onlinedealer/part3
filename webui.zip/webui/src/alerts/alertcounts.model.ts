export class AlertCountsModel {
  category: string;
  warningCount: number;
  crticalCount: number;
  total: number;
}

export class TotalAlertCount {
  count: number;
}

export interface TrendsMetricModel {
  startTime: string;
  value?: number;
  details?: Array<{ key: string; value: string }>;
  totalCount?: number;
}
