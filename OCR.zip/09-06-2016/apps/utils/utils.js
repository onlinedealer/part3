(function(window, initComponents, undefined) {
    fileuploader = function() {};
    //make Fileuploader global
    window.Fileuploader = new fileuploader();
})(window, function(Fileuploader, window, document) {});

(function(window, initComponents, undefined) {
    utils = function() {};

    utils.prototype.isNullOrEmpty = function(obj) {
        return (angular.isUndefined(obj) || obj == null || obj == 'null' || typeof obj == "undefined" || obj == "");
    };

     utils.prototype.addingObj = function(data) {
        var obj = [];
                       
    };

    

    //make Fileuploader global
    window.Fileuploader.utils = new utils();
})(window, function(UTILS, window, document) {});
