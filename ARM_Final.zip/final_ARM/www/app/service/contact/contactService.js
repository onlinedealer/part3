(function(){
'use strict';
angular.module('arm').factory('contactService', ['utility', '$rootScope', '$cordovaFile', 'MASTER_TABLE','$filter','sqliteService','GENERAL_CONFIG','serviceApi', 'SERVICE_TYPE', 'noteService', factoryModel]);
    function factoryModel(utility,$rootScope,$cordovaFile,MASTER_TABLE,$filter,sqliteService,GENERAL_CONFIG,serviceApi, SERVICE_TYPE, noteService){

    // $injector.invoke(serviceApi, this, {$scope: $scope});

    var factoryFunctionArr = [];

    factoryFunctionArr.models = function()
        {
            return{
                //Contact model
                    contactModel :
                        {
                            SyncStatus: 0,
                            ServerDateTime: null,
                            ModuleID: GENERAL_CONFIG.MODULES.Contact,
                            DeviceObjID: utility.generateUUID(),
                            ContactID: 0,
                            ContactTypeID: 0,
                            OrganisationID: null,
                            SalutationID: null,
                            ContactSegmentID: null,
                            ContactSegmentName: '',
                            ContactTierID: null,
                            ContactTierName: '',
                            FirstName: '',
                            MiddleName: '',
                            LastName: '',
                            CustomerID: 0,
                            Communications: [],
                            Correspondences: [],
                            ContactRelationshipMappings: [],
                            JobTitle: '',
                            CompanyName: '',
                            IsClient: false,
                            IsRepresentative: false,
                            IsEmployer: false,
                            IsDeleted: false,
                            CompanyWebsite: '',
                            Attachments: [],
                            ContactUserMappings: [],
                            Notes: [],
                            OwnerID: null,
                            OwnerName: '',
                            IsConfidential: false,
                            CreatorID: 0,
                            CreatorName: '',
                            CreatedOn: '',
                            CreatedAt: '',
                            ModifiedBy: 0,
                            ModifiedOn: '',
                            ModifiedAt: '',
                            Fields: [],
                            ProfileImageID: 0,
                            LastContactedDate: '',
                            NextContactedDate: '',
                            EmployerName: '',
                            EmployerID: 0,
                            EmployerDeviceObjID: '',
                            Representatives: []
                        },
                //communication model
                    communicationModel:
                        {
                            CommunicationID: 0,
                            DeviceObjID: utility.generateUUID(),
                            ParentDeviceObjID: '',
                            ModuleID: 0,
                            EntityID: 0,
                            CommunicationTypeID: null,
                            CommunicationData: '',
                            IsDefault: false,
                            CreatedOn: '',
                            CreatorID: null,
                            CreatedAt: '',
                            CommunicationCategoryID: 0,
                            IsMandatory : false
                        },
                        //correspondence model
                        correspondenceModel:
                        {
                            CorresspondenceID: 0,
                            DeviceObjID: utility.generateUUID(),
                            CorrespondenceTypeID: null,
                            ParentDeviceObjID: '',
                            ModuleID: 0,
                            EntityID: 0,
                            IsDefault: false,
                            IsMandatory: false,
                            Address: '',
                            CityName: '',
                            CountryName: '',
                            StateName: '',
                            Zip: '',
                            GoogleLat: '',
                            GoogleLong: '',
                            CreatorID: null,
                            CreatedOn: '',
                            CreatedAt: ''
                        },
                        // contact relation model
                        relationshipModel:
                        {
                            ContactRelationshipMappingID: 0,
                            DeviceObjID: utility.generateUUID(),
                            ContactID: 0,
                            ContactName: '',
                            ContactDeviceObjID: '',
                            ContactRelationshipTypeID: 0,
                            RelationshipWithContactID: 0,
                            RelationshipWithContactName: '',
                            RelationshipWithContactDeviceObjID: ''
                        }
                    };
        };

        factoryFunctionArr.constants = function()
        {
            return{
                communicationCategory:
                {
                    Phone: 1,
                    Email: 2
                },inputFieldType:
                {
                    Phone: 1,
                    Email: 2,
                    Correspondence: 3
                },contactType:
                {
                    Individual: 1,
                    Company: 2
                },dynamicFieldType:
                {
                    Additional: 1,
                    Business: 2
                },modelTypes:
                {
                    IndividualAddnType: 1,
                    IndividualBusnessType: 2,
                    CompanyAddnType: 3,
                    CompanyBusnessType: 4
                },relationTypes:
                {
                    RepresentativeOf: 1,
                    Representator:2,
                    EmployeerOf:3,
                    EmployeeOf:4
                }
            }
        };
        var selected_I_Contact = null; var selected_C_Contact = null; var selected_Type_Contact = null;
        factoryFunctionArr.setSelectedIndividualContact = function(I_contact){
             selected_I_Contact = I_contact;
        };
        factoryFunctionArr.getSelectedIndividualContact = function(){
             return selected_I_Contact;
        };
        factoryFunctionArr.setSelectedCompanyContact = function(C_contact){
             selected_C_Contact = C_contact;
        };
        factoryFunctionArr.getSelectedCompanyContact = function(){
             return selected_C_Contact;
        };
        factoryFunctionArr.setSelectedContactType = function(Type){
             selected_Type_Contact = Type;
        };
        factoryFunctionArr.getSelectedContactType = function(){
             return selected_Type_Contact;
        };

        var selectWhathappened = null;
        factoryFunctionArr.setSelectWhathappened = function (whatHappend) {
            selectWhathappened = whatHappend;
        };
        factoryFunctionArr.getSelectWhathappened = function () {
            return selectWhathappened;
        };

        factoryFunctionArr.getAllCommunication = function (comArr) {
            //var comArr = $scope.detailsContact.Communications;
            var objComm = new Object();
            objComm.mobilePhone = '';
            objComm.email = '';
            for (var i = 0; i < comArr.length; i++) {
                if (factoryFunctionArr.constants().communicationCategory.Phone == comArr[i].CommunicationCategoryID) {
                    if (comArr[i].IsDefault == true && comArr[i].CommunicationData != '') {
                        objComm.mobilePhone = comArr[i].CommunicationData;
                    }
                    else {
                        if (comArr[i].CommunicationData != '' && objComm.mobilePhone == '') {
                            objComm.mobilePhone = comArr[i].CommunicationData;
                        }
                    }

                }
                else if (factoryFunctionArr.constants().communicationCategory.Email == comArr[i].CommunicationCategoryID) {
                    objComm.email += comArr[i].CommunicationData + ',';
                }
            }
            objComm.email = objComm.email.substring(0, objComm.email.length - 1);
            return objComm;
        }


        factoryFunctionArr.getAllComData = function (result) {
            //var comArr = $scope.detailsContact.Communications;
            var objComm = new Object();
            objComm.mobilePhone = '';
            objComm.email = '';
            for (var i = 0; i < result.rows.length; i++) {
                if (factoryFunctionArr.constants().communicationCategory.Phone == result.rows.item(i)['CommunicationCategoryID']) {
                    if (result.rows.item(i)['IsDefault'] == true && result.rows.item(i)['CommunicationData'] != '') {
                        objComm.mobilePhone = result.rows.item(i)['CommunicationData'];
                    }
                    else {
                        if (result.rows.item(i)['CommunicationData'] != '' && objComm.mobilePhone == '') {
                            objComm.mobilePhone = result.rows.item(i)['CommunicationData'];
                        }
                    }

                }
                else if (factoryFunctionArr.constants().communicationCategory.Email == result.rows.item(i)['CommunicationCategoryID']) {
                    objComm.email += result.rows.item(i)['CommunicationData'] + ',';
                }
            }
            objComm.email = objComm.email.substring(0, objComm.email.length - 1);
            return objComm;
        }

        factoryFunctionArr.sqlActivityContactData = function(devId){
            return sqliteService.query("SELECT * FROM Communications WHERE ParentDeviceObjID ='" + devId + "'").then(function (result) {
              return result;
            });
        };

        factoryFunctionArr.deleteEmptyObjInSubArray = function(contactObjModel){
            if(contactObjModel.Communications.length > 0){
                for(var i = contactObjModel.Communications.length - 1; i >= 0; i--){
                    if(contactObjModel.Communications[i].CommunicationData == ""){
                        // || angular.isNumber(contactObjModel.Communications[i].CommunicationData) == false
                        contactObjModel.Communications.splice(i, 1);
                    }
                }
            }
            if(contactObjModel.Correspondences.length > 0){
                for(var i = contactObjModel.Correspondences.length - 1; i >= 0; i--){
                    if(contactObjModel.Correspondences[i].Address == "" && contactObjModel.Correspondences[i].CityName == "" && contactObjModel.Correspondences[i].CountryName == "" && contactObjModel.Correspondences[i].StateName == "" && contactObjModel.Correspondences[i].Zip == ""){
                        contactObjModel.Correspondences.splice(i, 1);
                    }
                }
            }
        };
        factoryFunctionArr.deletePushUpdateObjInFieldsArray = function(existingObjArr, serverObjArr){

            for(var i = existingObjArr.length - 1; i >= 0; i--){
                var checkRecordForDelete = $filter('filter')(serverObjArr, {FieldID: existingObjArr[i].FieldID});
                if(checkRecordForDelete == null || checkRecordForDelete == ""){
                    existingObjArr.splice(i, 1);
                }
            }
            angular.forEach(serverObjArr, function (serverObj) {
                var checkRecordForInsert = $filter('filter')(existingObjArr, {FieldID: serverObj.FieldID});
                if(checkRecordForInsert == null || checkRecordForInsert == ""){
                    // insert into the model
                    currentContactObjModel.Communications.push(serverObj);
                }else{
                    // update into the model
                    utility.syncModelWithCollection(serverObj,checkRecordForInsert);
                }
            });
        };
        factoryFunctionArr.deletePushUpdateObjInSubArray = function(existingObjArr, serverObjArr){

            for(var i = existingObjArr.length - 1; i >= 0; i--){
               var checkRecordForDelete = $filter('filter')(serverObjArr, {DeviceObjID: existingObjArr[i].DeviceObjID});
               if(checkRecordForDelete == null || checkRecordForDelete == ""){
                   existingObjArr.splice(i, 1);
               }
            }
            angular.forEach(serverObjArr, function (serverObj) {
                var checkRecordForInsert = $filter('filter')(existingObjArr, {DeviceObjID: serverObj.DeviceObjID});
                if(checkRecordForInsert == null || checkRecordForInsert == ""){
                   // insert into the model
                   currentContactObjModel.Communications.push(serverObj);
                }else{
                   // update into the model
                   utility.syncModelWithCollection(serverObj,checkRecordForInsert);
                }
            });
        };

        factoryFunctionArr.getAllSubArrayDataToModel = function(contactObjModel,shouldBindEmpty){
            //var deferred = $q.defer();
            var isRepresentativeFlag = contactObjModel.IsRepresentative;

            if(contactObjModel.Communications.length == 0){
                factoryFunctionArr.sqlGetPanelData("Communications", contactObjModel.DeviceObjID, isRepresentativeFlag).then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        if (result.rows.item(i).CommunicationCategoryID == 1) {
                            result.rows.item(i).CommunicationData = result.rows.item(i).CommunicationData;
                        }
                        if (result.rows.item(i).IsDefault == 'true') {
                            result.rows.item(i).IsDefault = true;
                        }else if (result.rows.item(i).IsDefault == 'false')
                        {
                            result.rows.item(i).IsDefault = false;
                        }

                        if (result.rows.item(i).IsMandatory == 'true') {
                            result.rows.item(i).IsMandatory = true;
                        }else if (result.rows.item(i).IsMandatory == 'false')
                        {
                            result.rows.item(i).IsMandatory = false;
                        }
                        if (result.rows.item(i).CommunicationTypeID == 'null') {
                            result.rows.item(i).CommunicationTypeID = null;
                        }
                        if (result.rows.item(i).CreatorID == 'null') {
                            result.rows.item(i).CreatorID = null;
                        }
                        contactObjModel.Communications.push(result.rows.item(i));
                    }
                    if(result.rows.length == 0){
                        if(shouldBindEmpty){
                            factoryFunctionArr.bindCommunicationEmptyModel(contactObjModel);
                        }
                    }
                });
            }
            if(contactObjModel.Correspondences.length == 0){
                factoryFunctionArr.sqlGetPanelData("Correspondences", contactObjModel.DeviceObjID, isRepresentativeFlag).then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {

                        if (result.rows.item(i).IsDefault == 'true') {
                            result.rows.item(i).IsDefault = true;
                        }else if (result.rows.item(i).IsDefault == 'false')
                        {
                            result.rows.item(i).IsDefault = false;
                        }

                        if (result.rows.item(i).IsMandatory == 'true') {
                            result.rows.item(i).IsMandatory = true;
                        }else if (result.rows.item(i).IsMandatory == 'false')
                        {
                            result.rows.item(i).IsMandatory = false;
                        }
                         if (result.rows.item(i).CorrespondenceTypeID == 'null') {
                            result.rows.item(i).CorrespondenceTypeID = null;
                         }
                         if (result.rows.item(i).CreatorID == 'null') {
                            result.rows.item(i).CreatorID = null;
                         }
                        contactObjModel.Correspondences.push(result.rows.item(i));
                    }
                    if(result.rows.length == 0){
                        if(shouldBindEmpty){
                            factoryFunctionArr.bindCorrespondencesEmptyModel(contactObjModel);
                        }
                    }
                });
            }
            if(contactObjModel.Notes.length == 0){
                factoryFunctionArr.sqlGetPanelData("Notes", contactObjModel.DeviceObjID, isRepresentativeFlag).then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        contactObjModel.Notes.push(result.rows.item(i));
                        contactObjModel.Notes[i].CreatedOnToDisplay = utility.getDateTimeInDisplayFormatForNotes(contactObjModel.Notes[i].CreatedOn);
                    }
                });
            }
            if(contactObjModel.ContactUserMappings.length == 0){
                factoryFunctionArr.sqlGetPanelData("UsersAccessMapping", contactObjModel.DeviceObjID, isRepresentativeFlag).then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        contactObjModel.ContactUserMappings.push(result.rows.item(i));
                    }
                });
            }
            if(contactObjModel.ContactRelationshipMappings.length == 0){
                factoryFunctionArr.sqlGetPanelData("ContactRelationships", contactObjModel.DeviceObjID, isRepresentativeFlag).then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        contactObjModel.ContactRelationshipMappings.push(result.rows.item(i));
                    }
                });
            }
            if(contactObjModel.Attachments.length == 0){
                factoryFunctionArr.sqlGetPanelData("Attachments", contactObjModel.DeviceObjID, isRepresentativeFlag).then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        contactObjModel.Attachments.push(result.rows.item(i));
                    }
                });
            }

            if(contactObjModel.Fields.length == 0){
                var shouldDisplayConfidentialFields = true;
                var fieldSet = utility.getMasterDataByKey(MASTER_TABLE.ConFieldSet);
                fieldSet = $filter('filter')(fieldSet, {IsStaticField: false});
                if (!shouldDisplayConfidentialFields) { //Display Confidential fields if user== full access
                    fieldSet = $filter('filter')(fieldSet, {IsConfidential: false});
                }
                fieldSet = $filter('filter')(fieldSet, {ContactTypeID: contactObjModel.ContactTypeID});
                fieldSet = $filter('filter')(fieldSet, {IsVisible: true});

                factoryFunctionArr.sqlGetPanelData("DynamicFields", contactObjModel.DeviceObjID, isRepresentativeFlag).then(function (result) {
                    for (var i = 0; i < fieldSet.length; i++) {
                        contactObjModel.Fields.push({
                            EntityID: contactObjModel.ContactID,
                            ModuleID: contactObjModel.ModuleID,
                            ParentDeviceObjID: contactObjModel.DeviceObjID,
                            FieldLabel: fieldSet[i].FieldLabel,
                            FieldName: fieldSet[i].FieldName,
                            FieldValue: result.rows.item(0)[fieldSet[i].FieldName],
                            FieldID: fieldSet[i].FieldID,
                            IsConfidential: fieldSet[i].IsConfidential,
                            IsMandatory: fieldSet[i].IsMandatory,
                            IsVisible: fieldSet[i].IsVisible,
                            ContactTypeID: fieldSet[i].ContactTypeID,
                            ContactFieldCategoryID: fieldSet[i].ContactFieldCategoryID
                        });
                    }
                });
            }
            // return contactObjModel;
        };

        factoryFunctionArr.getCommunicationTypes = function(commCategoryTypeID)
        {
            var communicationTypes = utility.getMultLangMasData(MASTER_TABLE.ComTyp);
             // communicationTypes = $filter('filter')(communicationTypes, {CommunicationCategoryID: commCategoryTypeID});
            return communicationTypes;
        };

        factoryFunctionArr.getCommunicationTypes = function(commCategoryTypeID)
        {
            var communicationTypes = utility.getMultLangMasData(MASTER_TABLE.ComTyp);
             // communicationTypes = $filter('filter')(communicationTypes, {CommunicationCategoryID: commCategoryTypeID});
            return communicationTypes;
        };
        factoryFunctionArr.addContactToSql = function(individualContactModel,companyContactModel)
        {
            ////console.log("Parent Inherited " + serviceApi.TestArr);
            var queryBindingsArr = [];
            if (individualContactModel != null && individualContactModel.FirstName.length > 0) {
            //if (individualContactModel != null) {
                var individualContactQuery = factoryFunctionArr.prepareContactQuery(individualContactModel);
                var individualContactBindings = '';

                var dynamicFldQueryBidings = utility.prepareDynamicFldQuery(individualContactModel);
                var individualDynamicFldQuery = dynamicFldQueryBidings.Query;
                var individualDynamicFldBindings = dynamicFldQueryBidings.Bindings;

                queryBindingsArr.push(
                             {
                             'Query' : individualContactQuery,
                             'Bindings': individualContactBindings
                             },
                             {
                             'Query' : individualDynamicFldQuery,
                             'Bindings': individualDynamicFldBindings
                             });

                angular.forEach(individualContactModel.Communications, function (obj) {
                   queryBindingsArr.push(factoryFunctionArr.prepareCommunicationQuery(obj));
                });

                angular.forEach(individualContactModel.Correspondences, function (obj) {
                    queryBindingsArr.push(factoryFunctionArr.prepareCorrespondenceQuery(obj));
                });

                angular.forEach(individualContactModel.ContactRelationshipMappings, function (obj) {
                    var contactName = individualContactModel.FirstName + " " + individualContactModel.LastName;
                    queryBindingsArr.push(factoryFunctionArr.prepareRelationshipQuery(obj,contactName));
                });

                angular.forEach(individualContactModel.ContactUserMappings, function (obj) {
                    queryBindingsArr.push(factoryFunctionArr.prepareUserAccessMappingQuery(obj,individualContactModel));
                });

                angular.forEach(individualContactModel.Attachments, function (obj) {
                    queryBindingsArr.push(factoryFunctionArr.prepareAttachmentsQuery(obj));
                });

                angular.forEach(individualContactModel.Notes, function (obj) {
                    queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
                });
            }
            if (companyContactModel != null && companyContactModel.CompanyName.length > 0) {
            //if (companyContactModel != null) {
                var companyContactQuery = factoryFunctionArr.prepareContactQuery(companyContactModel);
                var companyContactBindings = '';

                dynamicFldQueryBidings = utility.prepareDynamicFldQuery(companyContactModel);
                var companyDynamicFldQuery = dynamicFldQueryBidings.Query;
                var companyFldBindings = dynamicFldQueryBidings.Bindings;
                queryBindingsArr.push(
                         {
                         'Query' : companyContactQuery,
                         'Bindings': companyContactBindings
                         },
                         {
                         'Query' : companyDynamicFldQuery,
                         'Bindings': companyFldBindings
                         });
                angular.forEach(companyContactModel.Communications, function (obj) {
                   queryBindingsArr.push(factoryFunctionArr.prepareCommunicationQuery(obj));
                });

                angular.forEach(companyContactModel.Correspondences, function (obj) {
                   queryBindingsArr.push(factoryFunctionArr.prepareCorrespondenceQuery(obj));
                });

                angular.forEach(companyContactModel.ContactRelationshipMappings, function (obj) {
                   var contactName = companyContactModel.CompanyName;
                   queryBindingsArr.push(factoryFunctionArr.prepareRelationshipQuery(obj,contactName));
                });

                angular.forEach(companyContactModel.ContactUserMappings, function (obj) {
                    queryBindingsArr.push(factoryFunctionArr.prepareUserAccessMappingQuery(obj,companyContactModel));
                });

                angular.forEach(companyContactModel.Attachments, function (obj) {
                    queryBindingsArr.push(factoryFunctionArr.prepareAttachmentsQuery(obj));
                });

                angular.forEach(companyContactModel.Notes, function (obj) {
                    queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
                });
            }
            return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
                return result;
                }, function (error) {
            });
        };
        // Insert data into the table wise
        factoryFunctionArr.prepareContactQuery = function(contactModel)
        {
            contactModel.SyncStatus = 0; contactModel.IsDeleted = 0; contactModel.ProfileImageID = 0;
            var contactQuery = "INSERT INTO Contacts (DeviceObjID,ContactID,SyncStatus,ModuleID,ContactTypeID,ContactTierID,ContactTierName,ContactSegmentID,ContactSegmentName,"+
                                        "OrganisationID,SalutationID,ContactSegmentID,FirstName,MiddleName,LastName,CompanyName,CompanyWebsite,OwnerID,OwnerName,"+
                                        "CustomerID,ProfileImageID,JobTitle,LastContactedDate,NextContactedDate,IsRepresentative,IsEmployer,IsClient,"+
                                        "IsDeleted,IsConfidential,CreatorID,CreatorName,EmployerName,EmployerID,EmployerDeviceObjID,CreatedOn,CreatedAt,ModifiedBy,ModifiedOn,ModifiedAt,LoggedInUserID)" +
                                        " VALUES ('" + contactModel.DeviceObjID + "','" + CheckNull(contactModel.ContactID) + "','" +
                                contactModel.SyncStatus + "','" + contactModel.ModuleID + "','" + contactModel.ContactTypeID + "','" + contactModel.ContactTierID + "','" + contactModel.ContactTierName + "','" +
                                contactModel.ContactSegmentID + "','" + contactModel.ContactSegmentName + "','"+ contactModel.OrganisationID + "','"+
                                contactModel.SalutationID + "','" + contactModel.ContactSegmentID + "','" + contactModel.FirstName + "','" +
                                contactModel.MiddleName + "','" + contactModel.LastName + "','" + contactModel.CompanyName + "','" + contactModel.CompanyWebsite + "','" + CheckNull(contactModel.OwnerID) + "','" + contactModel.OwnerName + "','" +
                                contactModel.CustomerID + "','" + contactModel.ProfileImageID + "','" + contactModel.JobTitle + "','" +
                                contactModel.LastContactedDate + "','" +contactModel.NextContactedDate + "','" +contactModel.IsRepresentative + "','" +contactModel.IsEmployer + "','" + contactModel.IsClient  + "','" +
                                contactModel.IsDeleted + "','" + contactModel.IsConfidential + "','" +
                                contactModel.CreatorID + "','" + contactModel.CreatorName + "','" + contactModel.EmployerName + "','" + CheckNull(contactModel.EmployerID) + "','" + contactModel.EmployerDeviceObjID + "','" + contactModel.CreatedOn + "','" + contactModel.CreatedAt + "','" +
                                contactModel.ModifiedBy + "','" + contactModel.ModifiedOn + "','" + contactModel.ModifiedAt + "'," + $rootScope.loggedInUserID + ")";
            return contactQuery;
        };
        factoryFunctionArr.prepareRelationshipQuery = function (relation,contactName) {
             /*var relationQuery = "INSERT INTO ContactRelationships (DeviceObjID,ContactRelationshipMappingID,ContactID,ContactName,"+
            "ContactDeviceObjID,ContactRelationshipTypeID,RelationshipWithContactID,RelationshipWithContactName,RelationshipWithContactDeviceObjID,LoggedInUserID)" +
            "SELECT '" + relation.DeviceObjID +"', '" +  relation.ContactRelationshipMappingID  +"','" +  CheckNull(relation.ContactID)  +"','" +  contactName  +"','" +  relation.ContactDeviceObjID  + "','" +  relation.ContactRelationshipTypeID  + "','"+
            CheckNull(relation.RelationshipWithContactID)  +"','"+  relation.RelationshipWithContactName  +"','"+  relation.RelationshipWithContactDeviceObjID  +"', " + $rootScope.loggedInUserID +
            " WHERE NOT EXISTS (SELECT 1 FROM ContactRelationships WHERE DeviceObjID ='" + relation.DeviceObjID + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + ")";*/
            var relationQuery = "INSERT INTO ContactRelationships (DeviceObjID,ContactRelationshipMappingID,ContactID,ContactName,"+
                        "ContactDeviceObjID,ContactRelationshipTypeID,RelationshipWithContactID,RelationshipWithContactName,RelationshipWithContactDeviceObjID,LoggedInUserID)" +
                        "VALUES ('" + relation.DeviceObjID +"', '" +  relation.ContactRelationshipMappingID  +"','" +  CheckNull(relation.ContactID)  +"','" +  contactName  +"','" +  relation.ContactDeviceObjID  + "','" +  relation.ContactRelationshipTypeID  + "','"+
                        CheckNull(relation.RelationshipWithContactID)  +"','"+  relation.RelationshipWithContactName  +"','"+  relation.RelationshipWithContactDeviceObjID  +"', " + $rootScope.loggedInUserID +
                        ")";

            return {'Query':relationQuery,'Bindings':''};
        };
        factoryFunctionArr.prepareCommunicationQuery = function(communication) {
            /*var communicationQuery = "INSERT INTO Communications (DeviceObjID,ParentDeviceObjID,CommunicationID,"+
            "ModuleID,EntityID,CommunicationTypeID,CommunicationCategoryID,CommunicationData,IsDefault,CreatedOn,CreatedAt,IsMandatory,LoggedInUserID)" +
            "SELECT '" +  communication.DeviceObjID  +"','" + communication.ParentDeviceObjID  +"','" +  communication.CommunicationID  + "','" +  communication.ModuleID  + "','"+
            communication.EntityID  +"','"+ communication.CommunicationTypeID  +"','"+  communication.CommunicationCategoryID  +"','"+
            communication.CommunicationData  +"','"+  communication.IsDefault  +"','"+  communication.CreatedOn  +"','"+  communication.CreatedAt  +"','"+  communication.IsMandatory  +"'," + $rootScope.loggedInUserID +
            " WHERE NOT EXISTS (SELECT 1 FROM Communications WHERE DeviceObjID ='" + communication.DeviceObjID + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + ")";*/
            var communicationQuery = "INSERT INTO Communications (DeviceObjID,ParentDeviceObjID,CommunicationID,"+
                        "ModuleID,EntityID,CommunicationTypeID,CommunicationCategoryID,CommunicationData,IsDefault,CreatedOn,CreatedAt,IsMandatory,LoggedInUserID)" +
                        "VALUES ('" +  communication.DeviceObjID  +"','" + communication.ParentDeviceObjID  +"','" +  communication.CommunicationID  + "','" +  communication.ModuleID  + "','"+
                        communication.EntityID  +"','"+ communication.CommunicationTypeID  +"','"+  communication.CommunicationCategoryID  +"','"+
                        communication.CommunicationData  +"','"+  communication.IsDefault  +"','"+  communication.CreatedOn  +"','"+  communication.CreatedAt  +"','"+  communication.IsMandatory  +"'," + $rootScope.loggedInUserID +
                        ")";

            return  {'Query':communicationQuery,'Bindings':''};
        };

        factoryFunctionArr.prepareCorrespondenceQuery = function(correspondence) {
            /*var correspondencyQuery = "INSERT INTO Correspondences (DeviceObjID,ParentDeviceObjID,CorresspondenceID,"+
            "ModuleID,EntityID,CorrespondenceTypeID,IsDefault,IsMandatory,Address,CityName,"+
            "CountryName,StateName,Zip,GoogleLat,GoogleLong,CreatedOn,CreatedAt,LoggedInUserID)" +
            "SELECT '" +  correspondence.DeviceObjID  +"','" +  correspondence.ParentDeviceObjID  +"','" +  correspondence.CorresspondenceID  + "','" +
            correspondence.ModuleID  + "','"+  correspondence.EntityID  +"','"+  correspondence.CorrespondenceTypeID  +"','"+
            correspondence.IsDefault  +"','"+  correspondence.IsMandatory  +"','"+  correspondence.Address  +"','"+
            correspondence.CityName  +"','"+ correspondence.CountryName  +"','"+  correspondence.StateName  +"','"+  correspondence.Zip  +"','"+
            correspondence.GoogleLat  +"','"+  correspondence.GoogleLong  +"','"+  correspondence.CreatedOn  +"','"+
            correspondence.CreatedAt  +"'," + $rootScope.loggedInUserID +
            " WHERE NOT EXISTS (SELECT 1 FROM Correspondences WHERE DeviceObjID ='" + correspondence.DeviceObjID + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + ")";*/
            var correspondencyQuery = "INSERT INTO Correspondences (DeviceObjID,ParentDeviceObjID,CorresspondenceID,"+
                        "ModuleID,EntityID,CorrespondenceTypeID,IsDefault,IsMandatory,Address,CityName,"+
                        "CountryName,StateName,Zip,GoogleLat,GoogleLong,CreatedOn,CreatedAt,LoggedInUserID)" +
                        "VALUES ('" +  correspondence.DeviceObjID  +"','" +  correspondence.ParentDeviceObjID  +"','" +  correspondence.CorresspondenceID  + "','" +
                        correspondence.ModuleID  + "','"+  correspondence.EntityID  +"','"+  correspondence.CorrespondenceTypeID  +"','"+
                        correspondence.IsDefault  +"','"+  correspondence.IsMandatory  +"','"+  correspondence.Address  +"','"+
                        correspondence.CityName  +"','"+ correspondence.CountryName  +"','"+  correspondence.StateName  +"','"+  correspondence.Zip  +"','"+
                        correspondence.GoogleLat  +"','"+  correspondence.GoogleLong  +"','"+  correspondence.CreatedOn  +"','"+
                        correspondence.CreatedAt  +"'," + $rootScope.loggedInUserID +
                        ")";

            return  {'Query':correspondencyQuery,'Bindings':''};
        };

        factoryFunctionArr.prepareUserAccessMappingQuery = function(userAccessMapping,contactModelObj) {
            /*var userAccessMappingQuery = "INSERT INTO UsersAccessMapping (DeviceObjID,ContactID,ParentDeviceObjID,UserID,"+
            "UserName,ManagerID,SalutationID,FirstName,LastName,MiddleName,FullName,"+
            "DOB,DesignationID,UnitID,AllowedContactTypes,PerfferedLanguageID,PasswordHash,IsActive,Islocked,ServerDateTime,UserType,AccessCategoryID,LoggedInUserID)" +
            "SELECT '" +  userAccessMapping.DeviceObjID +"'," +  contactModelObj.ContactID +",'" +  contactModelObj.DeviceObjID +"','" +  userAccessMapping.UserID  +"','" +
            userAccessMapping.UserName  + "','"+  userAccessMapping.ManagerID  +"','"+  userAccessMapping.SalutationID  +"','"+ userAccessMapping.FirstName  +"','"+
            userAccessMapping.LastName  +"','"+  userAccessMapping.MiddleName  +"','"+  userAccessMapping.FullName  +"','"+ userAccessMapping.DOB  +"','"+
            userAccessMapping.DesignationID  +"','"+ userAccessMapping.UnitID  +"','"+  userAccessMapping.AllowedContactTypes  +"','"+  userAccessMapping.PerfferedLanguageID  +"','"+
            userAccessMapping.PasswordHash  +"','"+  userAccessMapping.IsActive  +"','"+  userAccessMapping.Islocked  +"','"+ CheckNull(userAccessMapping.ServerDateTime)  +"','"+
            userAccessMapping.UserType  +"','"+  userAccessMapping.AccessCategoryID  +"'," + $rootScope.loggedInUserID +
            " WHERE NOT EXISTS (SELECT 1 FROM UsersAccessMapping WHERE UserID =" + userAccessMapping.UserID + " AND  ParentDeviceObjID = '" +  contactModelObj.DeviceObjID + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + ")";*/

            /*var userAccessMappingQuery = "INSERT INTO UsersAccessMapping (DeviceObjID,ContactID,ParentDeviceObjID,UserID,"+
                "UserName,AccessCategoryID,LoggedInUserID)" +
                "SELECT '" +  userAccessMapping.DeviceObjID +"'," +  contactModelObj.ContactID +",'" +  contactModelObj.DeviceObjID +"','" +  userAccessMapping.UserID  +"','" +
                userAccessMapping.UserName  +"','"+  userAccessMapping.AccessCategoryID  +"'," + $rootScope.loggedInUserID +
                " WHERE NOT EXISTS (SELECT 1 FROM UsersAccessMapping WHERE UserID =" + userAccessMapping.UserID + " AND  ParentDeviceObjID = '" +  contactModelObj.DeviceObjID + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + ")";*/
            var userAccessMappingQuery = "INSERT INTO UsersAccessMapping (DeviceObjID,ContactID,ParentDeviceObjID,UserID,"+
                    "UserName,AccessCategoryID,LoggedInUserID)" +
                    "VALUES ('" +  userAccessMapping.DeviceObjID +"'," +  contactModelObj.ContactID +",'" +  contactModelObj.DeviceObjID +"','" +  userAccessMapping.UserID  +"','" +
                    userAccessMapping.UserName  +"','"+  userAccessMapping.AccessCategoryID  +"'," + $rootScope.loggedInUserID +
                    ")";

            return  {'Query':userAccessMappingQuery,'Bindings':''};
        };

        factoryFunctionArr.prepareAttachmentsQuery = function(attachments){
            var syncStatus = 0;
            if (attachments.AttachmentID != 0) {
                    syncStatus = 1;
            }
              var attachmentsQuery = "INSERT INTO Attachments (AttachmentCategoryID,AttachmentID,DeviceObjID,EntityID,ModuleID,ParentDeviceObjID,FileName,MIMEContentType,Extension,DocumentID,DocumentName,ModifiedBy,ModifiedAt,SyncStatus,LoggedInUserID)"+
                            "VALUES (" + attachments.AttachmentCategoryID  +"," +  attachments.AttachmentID +",'" +  attachments.DeviceObjID +"',"+  attachments.EntityID +"," + attachments.ModuleID +",'" + attachments.ParentDeviceObjID +"','" +
                            attachments.FileName  +"','" +  attachments.MIMEContentType +"','" +  attachments.Extension +"'," + attachments.DocumentID +",'" + attachments.DocumentName +"'," +
                            $rootScope.loggedInUserID  +",'" + attachments.ModifiedAt  +"'," + syncStatus +"," + $rootScope.loggedInUserID + ")";
              return  {'Query':attachmentsQuery,'Bindings':''};
        };

        // update contact function
        factoryFunctionArr.updateContactToSql = function(individualContactModel,companyContactModel)
        {
            var queryBindingsArr = [];

            //if (individualContactModel != null && individualContactModel.FirstName.length > 0) {
            if (individualContactModel != null) {
                var individualContactQuery = factoryFunctionArr.UpdatePrepareContactQuery(individualContactModel);
                var individualContactBindings = '';

                queryBindingsArr.push(factoryFunctionArr.deleteDynamicFieldsQuery(individualContactModel.DeviceObjID));
                var dynamicFldQueryBidings = utility.prepareDynamicFldQuery(individualContactModel);
                var individualDynamicFldQuery = dynamicFldQueryBidings.Query
                var individualDynamicFldBindings = dynamicFldQueryBidings.Bindings;

                 queryBindingsArr.push(
                     {
                     'Query' : individualContactQuery,
                     'Bindings': individualContactBindings
                     },
                     {
                     'Query' : individualDynamicFldQuery,
                     'Bindings': individualDynamicFldBindings
                 });

                 /*var dummyArrForDeviceObjIDs = [];
                 factoryFunctionArr.selectAllDeviceIDsByTableQuery("ContactRelationships", individualContactModel.DeviceObjID).then(function (result) {
                     for (var i = 0; i < result.rows.length; i++) {
                         dummyArrForDeviceObjIDs.push(result.rows.item(i));
                     }
                 });*/
                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("ContactRelationships",individualContactModel.ContactRelationshipMappings,individualContactModel.DeviceObjID));
                 angular.forEach(individualContactModel.ContactRelationshipMappings, function (obj) {
                    var contactName = individualContactModel.FirstName + " " + individualContactModel.LastName;
                     queryBindingsArr.push(factoryFunctionArr.prepareRelationshipQuery(obj,contactName));
                     /*if(obj.ContactID == null || obj.ContactID == 0){
                        queryBindingsArr.push(factoryFunctionArr.prepareRelationshipQuery(obj));
                     }else{
                        queryBindingsArr.push(factoryFunctionArr.updatePrepareRelationshipQuery(obj,individualContactModel));
                     }*/
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Communications",individualContactModel.Communications,individualContactModel.DeviceObjID));
                 angular.forEach(individualContactModel.Communications, function (obj) {
                     queryBindingsArr.push(factoryFunctionArr.prepareCommunicationQuery(obj));
                     /*if(obj.EntityID == null || obj.EntityID == 0){
                        queryBindingsArr.push(factoryFunctionArr.prepareCommunicationQuery(obj));
                     }else{
                        queryBindingsArr.push(factoryFunctionArr.updatePrepareCommunicationQuery(obj));
                     }*/
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Correspondences",individualContactModel.Correspondences,individualContactModel.DeviceObjID));
                 angular.forEach(individualContactModel.Correspondences, function (obj) {
                     queryBindingsArr.push(factoryFunctionArr.prepareCorrespondenceQuery(obj));
                     /*if(obj.EntityID == null || obj.EntityID == 0){
                        queryBindingsArr.push(factoryFunctionArr.prepareCorrespondenceQuery(obj));
                     }else{
                        queryBindingsArr.push(factoryFunctionArr.updatePrepareCorrespondenceQuery(obj));
                     }*/
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("UsersAccessMapping",individualContactModel.ContactUserMappings,individualContactModel.DeviceObjID));
                 angular.forEach(individualContactModel.ContactUserMappings, function (obj) {
                    queryBindingsArr.push(factoryFunctionArr.prepareUserAccessMappingQuery(obj,individualContactModel));
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Attachments",individualContactModel.Attachments,individualContactModel.DeviceObjID));
                 angular.forEach(individualContactModel.Attachments, function (obj) {
                     queryBindingsArr.push(factoryFunctionArr.prepareAttachmentsQuery(obj));
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Notes",individualContactModel.Notes,individualContactModel.DeviceObjID));
                 angular.forEach(individualContactModel.Notes, function (obj) {
                     queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
                 });

                 if(individualContactModel.IsRepresentative == false){
                   queryBindingsArr.push(factoryFunctionArr.updateActivityPrepareQuery("Activity",individualContactModel,null));
                   queryBindingsArr.push(factoryFunctionArr.updateActivityPrepareQuery("Deals",individualContactModel,null));
                 }
            }
            // add recoreds for the company model
            //if (companyContactModel != null && companyContactModel.CompanyName.length > 0) {
            if (companyContactModel != null) {
                var companyContactQuery = factoryFunctionArr.UpdatePrepareContactQuery(companyContactModel);
                var companyContactBindings = '';

                queryBindingsArr.push(factoryFunctionArr.deleteDynamicFieldsQuery(companyContactModel.DeviceObjID));
                dynamicFldQueryBidings = utility.prepareDynamicFldQuery(companyContactModel);
                var companyDynamicFldQuery = dynamicFldQueryBidings.Query
                var companyFldBindings = dynamicFldQueryBidings.Bindings;
                queryBindingsArr.push(
                         {
                         'Query' : companyContactQuery,
                         'Bindings': companyContactBindings
                         },
                         {
                         'Query' : companyDynamicFldQuery,
                         'Bindings': companyFldBindings
                         });
                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("ContactRelationships",companyContactModel.ContactRelationshipMappings,companyContactModel.DeviceObjID));
                 angular.forEach(companyContactModel.ContactRelationshipMappings, function (obj) {
                     var contactName = companyContactModel.CompanyName;
                     queryBindingsArr.push(factoryFunctionArr.prepareRelationshipQuery(obj,contactName));
                     /*if(obj.ContactID == null || obj.ContactID == 0){
                        queryBindingsArr.push(factoryFunctionArr.prepareRelationshipQuery(obj));
                     }else{
                        queryBindingsArr.push(factoryFunctionArr.updatePrepareRelationshipQuery(obj,companyContactModel));
                     }*/
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Communications",companyContactModel.Communications,companyContactModel.DeviceObjID));
                 angular.forEach(companyContactModel.Communications, function (obj) {
                     queryBindingsArr.push(factoryFunctionArr.prepareCommunicationQuery(obj));
                     /*if(obj.EntityID == null || obj.EntityID == 0){
                        queryBindingsArr.push(factoryFunctionArr.prepareCommunicationQuery(obj));
                     }else{
                        queryBindingsArr.push(factoryFunctionArr.updatePrepareCommunicationQuery(obj));
                     }*/
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Correspondences",companyContactModel.Correspondences,companyContactModel.DeviceObjID));
                 angular.forEach(companyContactModel.Correspondences, function (obj) {
                     queryBindingsArr.push(factoryFunctionArr.prepareCorrespondenceQuery(obj));
                     /*if(obj.EntityID == null || obj.EntityID == 0){
                        queryBindingsArr.push(factoryFunctionArr.prepareCorrespondenceQuery(obj));
                     }else{
                        queryBindingsArr.push(factoryFunctionArr.updatePrepareCorrespondenceQuery(obj));
                     }*/
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("UsersAccessMapping",companyContactModel.ContactUserMappings,companyContactModel.DeviceObjID));
                 angular.forEach(companyContactModel.ContactUserMappings, function (obj) {
                    queryBindingsArr.push(factoryFunctionArr.prepareUserAccessMappingQuery(obj,companyContactModel));
                 });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Attachments",companyContactModel.Attachments,companyContactModel.DeviceObjID));
                 angular.forEach(companyContactModel.Attachments, function (obj) {
                      queryBindingsArr.push(factoryFunctionArr.prepareAttachmentsQuery(obj));
                  });

                 queryBindingsArr.push(factoryFunctionArr.deletePrepareQuery("Notes",companyContactModel.Notes,companyContactModel.DeviceObjID));
                 angular.forEach(companyContactModel.Notes, function (obj) {
                      queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
                 });

                 // Update the Activity and Deal tables
                 if(companyContactModel.IsClient==true){
                     queryBindingsArr.push(factoryFunctionArr.updateActivityPrepareQuery("Activity",companyContactModel,individualContactModel));
                     queryBindingsArr.push(factoryFunctionArr.updateActivityPrepareQuery("Deals",companyContactModel,individualContactModel));
                 }
            }

            return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
                }, function (error) {
                alert(error);
            });
        };

        // Update data into the table wise
        /*factoryFunctionArr.selectAllDeviceIDsByTableQuery = function (tableName,contactDeviceObjID) {
            if(tableName=="ContactRelationships"){
                return sqliteService.query("SELECT DeviceObjID FROM " + tableName + " WHERE ContactDeviceObjID = '" + contactDeviceObjID + "'").then(function (result) {
                    return result;
                });
            }else{
                return sqliteService.query("SELECT DeviceObjID FROM " + tableName + " WHERE ParentDeviceObjID = '" + contactDeviceObjID + "'").then(function (result) {
                    return result;
                });
            }
        }*/
        factoryFunctionArr.deletePrepareQuery = function (tableName,childObjArray,contactDeviceID) {
           var currModifyArr = [];
           for(var i=0; i< childObjArray.length; i++){
               currModifyArr.push("'" + childObjArray[i].DeviceObjID + "'");
           }
           var deviceObjIdInString = currModifyArr.join(",");
           if(tableName=="UsersAccessMapping"){
               var currUserArr = [];
               for(var i=0; i< childObjArray.length; i++){
                      currUserArr.push(childObjArray[i].UserID);
               }
               var userIdsInString = currUserArr.join(",");
            }

            if(tableName=="ContactRelationships"){
                //var deleteQuery = "DELETE FROM " + tableName + " WHERE ContactDeviceObjID = '"+ contactDeviceID +"' AND DeviceObjID NOT IN (" +deviceObjIdInString+ ") AND LoggedInUserID = "+ $rootScope.loggedInUserID +"";
                var deleteQuery = "DELETE FROM " + tableName + " WHERE ContactDeviceObjID = '"+ contactDeviceID +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID +"";
                return  {'Query':deleteQuery,'Bindings':''};
            }else if(tableName=="UsersAccessMapping"){
                //var deleteQuery = "DELETE FROM " + tableName + " WHERE ParentDeviceObjID = '"+ contactDeviceID +"' AND UserID NOT IN (" +userIdsInString+ ") AND LoggedInUserID = "+ $rootScope.loggedInUserID +"";
                var deleteQuery = "DELETE FROM " + tableName + " WHERE ParentDeviceObjID = '"+ contactDeviceID +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID +"";
                return  {'Query':deleteQuery,'Bindings':''};
            }else{
                //var deleteQuery = "DELETE FROM " + tableName + " WHERE ParentDeviceObjID = '"+ contactDeviceID +"' AND DeviceObjID NOT IN (" +deviceObjIdInString+ ") AND LoggedInUserID = "+ $rootScope.loggedInUserID +"";
                var deleteQuery = "DELETE FROM " + tableName + " WHERE ParentDeviceObjID = '"+ contactDeviceID +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID +"";
                return  {'Query':deleteQuery,'Bindings':''};
            }
        }
        factoryFunctionArr.deleteDynamicFieldsQuery = function (contactDeviceID) {
            var deleteQuery = "DELETE FROM DynamicFields WHERE ParentDeviceObjID = '"+ contactDeviceID +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID +"";
            return  {'Query':deleteQuery,'Bindings':''};
        }

        factoryFunctionArr.UpdatePrepareContactQuery = function(contactModel) {
            var contactQuery = "UPDATE Contacts SET" +
                                " ContactID =" + CheckNull(contactModel.ContactID) + "," + " SyncStatus = 0," +
                                " ModuleID =" + contactModel.ModuleID + "," + " ContactTypeID =" + contactModel.ContactTypeID + "," +
                                " ContactTierID =" + contactModel.ContactTierID + "," + " ContactTierName ='" + contactModel.ContactTierName + "'," +
                                " ContactSegmentID =" + contactModel.ContactSegmentID + "," + " ContactSegmentName ='" + contactModel.ContactSegmentName + "'," +
                                " OrganisationID =" + contactModel.OrganisationID + "," + " SalutationID =" + contactModel.SalutationID + "," +
                                " ContactSegmentID =" + contactModel.ContactSegmentID + "," + " FirstName ='" + contactModel.FirstName + "'," + " CompanyName ='" + contactModel.CompanyName + "'," +
                                " LastName ='" + contactModel.LastName + "'," + " CompanyWebsite ='" + contactModel.CompanyWebsite + "'," +
                                " OwnerID =" + CheckNull(contactModel.OwnerID) + "," + " OwnerName ='" + contactModel.OwnerName + "'," +
                                " ProfileImageID = 0," + " JobTitle ='" + contactModel.JobTitle + "'," +
                                " LastContactedDate ='" + contactModel.LastContactedDate + "'," + " IsRepresentative ='" + contactModel.IsRepresentative + "'," +
                                " IsEmployer ='" + contactModel.IsEmployer + "'," + " IsClient ='" + contactModel.IsClient + "'," +" IsDeleted =0," +
                                " CreatorName ='" + contactModel.CreatorName + "'," + " EmployerName ='" + contactModel.EmployerName + "'," +
                                " EmployerID =" + CheckNull(contactModel.EmployerID) + "," + " EmployerDeviceObjID ='" + contactModel.EmployerDeviceObjID + "'," +
                                " CreatedOn ='" + contactModel.CreatedOn + "'," + " CreatedAt ='" + contactModel.CreatedAt + "'," +
                                " ModifiedBy =" + contactModel.ModifiedBy + "," + " ModifiedOn ='" + contactModel.ModifiedOn + "'," +
                                " CreatorID =" + contactModel.CreatorID + ", CreatorName ='" + contactModel.CreatorName + "'," + " ModifiedAt ='" + contactModel.ModifiedAt + "'" +
                                " WHERE DeviceObjID ='" + contactModel.DeviceObjID + "'";
            return contactQuery;
        };
        factoryFunctionArr.updateActivityPrepareQuery = function (tableName, contactObj, repObj) {
            var contactName = ''; var companyName = ''; var contactDisplayName = ''; var representativeID = null;
            var conType = factoryFunctionArr.constants().contactType;
            if(contactObj.ContactTypeID == conType.Individual){
                contactName = contactObj.FirstName + " " + contactObj.LastName;
                companyName = contactObj.EmployerName;
                contactDisplayName = contactName;
                if(companyName != null){
                    if(companyName.length > 0)
                       contactDisplayName = contactName + '(' + companyName + ')';
                }
            }else {
                contactName = contactObj.CompanyName;
                companyName = contactObj.CompanyName;
                if(repObj != null){
                    contactDisplayName = repObj.FirstName + " " + repObj.LastName;
                    if(companyName != null){
                        if(companyName.length > 0)
                           contactDisplayName = repObj.FirstName + " " + repObj.LastName + '(' + companyName + ')';
                    }
                    if(repObj.IsRepresentative == true)
                        representativeID = repObj.ContactID;
                }
            }
            var updateOtherTableQuery = "UPDATE " + tableName +" SET " +
                    " ContactID =" + CheckNull(contactObj.ContactID) + "," + " ContactName ='" + contactName + "'," +
                    " ContactTierID =" + contactObj.ContactTierID + "," + " ContactTierName ='" + contactObj.ContactTierName + "'," +
                    " ContactSegmentID =" + contactObj.ContactSegmentID + "," + " ContactSegmentName ='" + contactObj.ContactSegmentName + "'," +
                    " CompanyName ='" + companyName + "'," + " RepresentativeID =" + representativeID + "," +
                    " ContactTypeID =" + contactObj.ContactTypeID + "," + " ContactDisplayName ='" + contactDisplayName + "'," +
                    " RepresentativeDeviceObjID ='" + contactObj.DeviceObjID + "'" +
                    " WHERE ContactDeviceObjID ='" + contactObj.DeviceObjID + "'";
            return  {'Query':updateOtherTableQuery,'Bindings':''};
        }

        factoryFunctionArr.updatePrepareCommunicationQuery = function(communication) {
            var communicationQuery = "UPDATE Communications SET " +
                                " ParentDeviceObjID ='" + communication.ParentDeviceObjID + "'," + " CommunicationID =" + communication.CommunicationID + "," +
                                " ModuleID =" + communication.ModuleID + "," + " EntityID =" + communication.EntityID + "," +
                                " CommunicationTypeID =" + communication.CommunicationTypeID + "," + " CommunicationCategoryID =" + communication.CommunicationCategoryID + "," +
                                " CommunicationData ='" + communication.CommunicationData + "'," + " IsDefault ='" + communication.IsDefault + "'," +
                                " CreatedOn ='" + communication.CreatedOn + "'," +
                                " CreatedAt ='" + communication.CreatedAt + "'," + " IsMandatory ='" + communication.IsMandatory + "'" +
                                " WHERE DeviceObjID ='" + communication.DeviceObjID + "'";
            return  {'Query':communicationQuery,'Bindings':''};
        };

        factoryFunctionArr.updatePrepareCorrespondenceQuery = function(correspondence)
        {
            var correspondencyQuery = "UPDATE Correspondences SET " +
                                    " ParentDeviceObjID ='" + correspondence.ParentDeviceObjID + "'," + " CorresspondenceID =" + correspondence.CorresspondenceID + "," +
                                    " ModuleID =" + correspondence.ModuleID + "," + " EntityID =" + correspondence.EntityID + "," +
                                    " CorrespondenceTypeID =" + correspondence.CorrespondenceTypeID + "," + " Address ='" + correspondence.Address + "'," +
                                    " CityName ='" + correspondence.CityName + "'," + " Zip ='" + correspondence.Zip + "'," +
                                    " StateName ='" + correspondence.StateName + "'," + " CountryName ='" + correspondence.CountryName + "'," +
                                    " GoogleLat ='" + correspondence.GoogleLat + "'," + " GoogleLong ='" + correspondence.GoogleLong + "'," +
                                    " CreatedOn ='" + correspondence.CreatedOn + "'," +
                                    " CreatedAt ='" + correspondence.CreatedAt + "'" +
                                    " WHERE DeviceObjID ='" + correspondence.DeviceObjID + "'";
            return  {'Query':correspondencyQuery,'Bindings':''};
        };
        factoryFunctionArr.updatePrepareRelationshipQuery = function (relation,contactModel)
        {
            var contactName = "";
            if(contactModel.contactType == 1){
                contactName = contactModel.FirstName +" " + contactModel.LastName;
            }else{
                contactName = contactModel.CompanyName;
            }
            var relationQuery = "UPDATE ContactRelationships SET " +
                                " ContactRelationshipMappingID =" + relation.ContactRelationshipMappingID + "," + " ContactID =" + CheckNull(relation.ContactID) + "," +
                                " ContactName ='" + contactName + "'," + " ContactDeviceObjID ='" + relation.ContactDeviceObjID + "'," +
                                " ContactRelationshipTypeID =" + relation.ContactRelationshipTypeID + "," + " RelationshipWithContactID =" + CheckNull(relation.RelationshipWithContactID) + "," +
                                " RelationshipWithContactName ='" + relation.RelationshipWithContactName + "'," + " RelationshipWithContactDeviceObjID ='" + relation.RelationshipWithContactDeviceObjID + "'" +
                                " WHERE DeviceObjID ='" + relation.DeviceObjID + "'";
            return {'Query':relationQuery,'Bindings':''};
        };

        // synchronise the data into server
        factoryFunctionArr.addContactToServer = function (individualContactModel,companyContactModel) {
             serviceApi.headerConfg['WebServiceType'] = GENERAL_CONFIG.WebServiceType.Contact;
            var contactModels = [];
            var firstName = utility.removeWhitespace(individualContactModel.FirstName);
            if(firstName.length>0)
                contactModels.push(individualContactModel);
            if(companyContactModel != null){
                var companyName = utility.removeWhitespace(companyContactModel.CompanyName);
                if(companyName.length>0)
                    contactModels.push(companyContactModel);
            }
            var finalData = { "data": contactModels };
            return serviceApi.doPostWithData("contactAddService",
                SERVICE_TYPE.CONTACT, finalData, serviceApi.headerConfg).then(function (response) {
                    return response;
                });
        }
        factoryFunctionArr.getAttachmentsDownload = function(attachmentID) {
             var headerconfig = { headers:{'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'} };
             var getAttachmentsURL = SERVICE_TYPE.GETATTACHMENT+'/'+attachmentID;
             return serviceApi.doGetWithoutData("LoadGetAttachments",
                    getAttachmentsURL, headerconfig).then(function (response) {
                return response;
             });
        }
        // get the data from server and save data into SQLight DB and Update module list
        factoryFunctionArr.getContactList = function (type) {
            var serviceType = ''; var RetrievalType = '';
            if(type == "Next"){
                 RetrievalType = GENERAL_CONFIG.DataRetrivalType.Next; // Next
                 serviceType = GENERAL_CONFIG.WebServiceType.ContactListNext; // ContactListNext
            }else{
                 RetrievalType = GENERAL_CONFIG.DataRetrivalType.Pevious;
                 serviceType = GENERAL_CONFIG.WebServiceType.ContactListPrev;
            }
            //$rootScope.loggedInUserID=1; $rootScope.languageID = 1;
            var serviceURL = SERVICE_TYPE.CONTACTLIST+$rootScope.loggedInUserID+"/"+GENERAL_CONFIG.DataRetrivalType.Chunk+"/"+$rootScope.languageID+"/"+RetrievalType;
            serviceApi.headerConfg['WebServiceType'] = serviceType;
            return serviceApi.doGetWithoutData("contactListService",
                serviceURL, serviceApi.headerConfg).then(function (response) {
                    return response;
                });
        }

        factoryFunctionArr.sqlGetAllDeviceObjIds = function () {
            return sqliteService.query("SELECT DeviceObjID FROM Contacts WHERE LoggedInUserID = "+ $rootScope.loggedInUserID +" ").then(function (result) {
                return result;
            });
        }
        // fatah data from tabels
        factoryFunctionArr.sqlContGetAll = function(contactType,isFlag){
            var conType = factoryFunctionArr.constants().contactType;
            if(contactType != conType.Company){
              return sqliteService.query("SELECT * FROM Contacts WHERE ContactTypeID ='" + contactType + "' AND IsRepresentative = '" + isFlag +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID +" ").then(function (result) {
                  return result;
              });
            }else{
              return sqliteService.query("SELECT * FROM Contacts WHERE ContactTypeID ='" + contactType + "' AND IsEmployer = '" + isFlag +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID +"").then(function (result) {
                  return result;
              });
           }
        }
        factoryFunctionArr.sqlGetPanelData = function(tableName,deviceId,isRepFlag){
            if(tableName=="Activity" || tableName=="Deals"){
                if(isRepFlag == false){
                    return sqliteService.query("SELECT * FROM " + tableName + " WHERE ContactDeviceObjID ='" + deviceId +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                        return result;
                    });
                }else{
                    return sqliteService.query("SELECT * FROM " + tableName + " WHERE RepresentativeDeviceObjID ='" + deviceId +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                        return result;
                    });
                }
            }else if(tableName=="ContactRelationships"){
                return sqliteService.query("SELECT * FROM " + tableName + " WHERE ContactDeviceObjID ='" + deviceId +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                    return result;
                });
            }else{
                return sqliteService.query("SELECT * FROM " + tableName + " WHERE ParentDeviceObjID ='" + deviceId +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                    return result;
                });
            }
        }
        factoryFunctionArr.isContactPresentInDB = function(contact)
        {
            return sqliteService.query("SELECT * FROM Contacts WHERE DeviceObjID ='" + contact.DeviceObjID +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                if (result.rows.length) {
                    return true;
                }
                    return false;
                });
        }
        factoryFunctionArr.sqlGetCompanyData = function(empId){
            return sqliteService.query("SELECT * FROM Contacts WHERE DeviceObjID ='" + empId +"' AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                return result;
            });
        }
        factoryFunctionArr.companyListLoad = function(empId){
            return sqliteService.query("SELECT * FROM Contacts WHERE ContactTypeID = 2 AND IsClient = 'true'").then(function (result) {
                return result;
            });
        }
        factoryFunctionArr.updateTableIds = function(tableName, contactObjData){
            if(tableName == "Contacts"){
                var updateTable1 = "UPDATE "+ tableName +" SET ContactID = "+ contactObjData.ContactID +" WHERE DeviceObjID ='" + contactObjData.DeviceObjID +"'";
                return {'Query':updateTable1,'Bindings':''};
            }else if(tableName == "UsersAccessMapping"){
                 var updateTable1 = "UPDATE "+ tableName +" SET ContactID = "+ contactObjData.ContactID +" WHERE ParentDeviceObjID ='" + contactObjData.DeviceObjID +"'";
                 return {'Query':updateTable1,'Bindings':''};
            }else if(tableName == "Participients"){
                 var updateTable1 = "UPDATE "+ tableName +" SET AttendeeID = "+ contactObjData.ContactID +" WHERE ParentDeviceObjID ='" + contactObjData.DeviceObjID +"'";
                 return {'Query':updateTable1,'Bindings':''};
            }else{
                var updateTable1 = "UPDATE "+ tableName +" SET ContactID = "+ contactObjData.ContactID +" WHERE ContactDeviceObjID ='" + contactObjData.DeviceObjID +"'";
                return {'Query':updateTable1,'Bindings':''};
            }
        }
        factoryFunctionArr.updateTableRepIds = function(tableName, contactObjData){
            var updateTable2 = "UPDATE "+ tableName +" SET RepresentativeID = "+ contactObjData.ContactID +" WHERE RepresentativeDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            return {'Query':updateTable2,'Bindings':''};
        }
        factoryFunctionArr.updateTableEmpIds = function(tableName, contactObjData){
            var updateTable3 = "UPDATE "+ tableName +" SET EmployerID = "+ contactObjData.ContactID +" WHERE EmployerDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            return {'Query':updateTable3,'Bindings':''};
        }

        factoryFunctionArr.updateTableEntityIds = function(tableName, tableObj, contactObjData){
            if(tableName == "Communications"){
                var updateTable4 = "UPDATE "+ tableName +" SET CommunicationID = " + tableObj.CommunicationID + ", EntityID = "+ contactObjData.ContactID +" WHERE ParentDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            }else if(tableName == "Correspondences"){
                var updateTable4 = "UPDATE "+ tableName +" SET CorresspondenceID = " + tableObj.CorresspondenceID + ", EntityID = "+ contactObjData.ContactID +" WHERE ParentDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            }else if(tableName == "ContactRelationships"){
                var updateTable4 = "UPDATE "+ tableName +" SET ContactRelationshipMappingID = " + tableObj.ContactRelationshipMappingID + ", ContactID = "+ contactObjData.ContactID +" WHERE ContactDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            }else if(tableName == "Attachments"){
                var updateTable4 = "UPDATE "+ tableName +" SET AttachmentID = " + tableObj.AttachmentID + ", EntityID = "+ contactObjData.ContactID +" WHERE ParentDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            }else if(tableName == "Notes"){
                var updateTable4 = "UPDATE "+ tableName +" SET NoteID = " + tableObj.NoteID + ", EntityID = "+ contactObjData.ContactID +" WHERE ParentDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            }else if(tableName == "DynamicFields"){
                var updateTable4 = "UPDATE "+ tableName +" SET EntityID = "+ contactObjData.ContactID +" WHERE ParentDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            }

            return {'Query':updateTable4,'Bindings':''};
        }
        factoryFunctionArr.updateTableRelationships = function(tableName, contactObjData){
            var updateTable5 = "UPDATE "+ tableName +" SET RelationshipWithContactID = "+ contactObjData.ContactID +" WHERE RelationshipWithContactDeviceObjID ='" + contactObjData.DeviceObjID +"'";
            return {'Query':updateTable5,'Bindings':''};
        }

        //***********************************Start Attachments Send*********************************
        // Upload images to server
         factoryFunctionArr.uploadAttachmentsToServer = function(deviceObjId_1, deviceObjId_2, attachmentsModelFrom){
            var sendAttachData = []; var defaultPath = "";
            if(deviceObjId_1 == null)
                  deviceObjId_1 = "";
            if(deviceObjId_2 == null)
                  deviceObjId_2 = "";

            if(attachmentsModelFrom == GENERAL_CONFIG.MODULES.Contact){
                defaultPath = cordova.file.cacheDirectory + "contactImages/"
            }else{
                defaultPath = cordova.file.cacheDirectory + "dealImages/"
            }

            factoryFunctionArr.getAttachmentData(deviceObjId_1, deviceObjId_2).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                     var attachmentObject = {AttachmentID : result.rows.item(i)['AttachmentID']};
                     var imgPath = defaultPath + result.rows.item(i)['FileName'] + result.rows.item(i)['Extension'];

                     getFileContentAsBase64(imgPath,attachmentObject,function(base64Image,attachmentObj){
                            var base64Code = base64Image.split(",");
                            attachmentObj.Base64String = base64Code[1];
                            sendAttachData.push(attachmentObj);
                            if(sendAttachData.length == result.rows.length){
                                sendAttachDataOneByOne(sendAttachData);
                            }
                     });
                }
            }, function (error) { alert(error); });

        }

        function getFileContentAsBase64(path,attachmentObject,callback){
            window.resolveLocalFileSystemURL(path, gotFile, fail);
            function fail(e) {
                  alert('Cannot found requested file');
            }
            function gotFile(fileEntry) {
               fileEntry.file(function(file) {
                  var reader = new FileReader();
                  reader.onloadend = function(e) {
                       var content = this.result;
                       callback(content,attachmentObject);
                  };
                  // The most important point, use the readAsDatURL Method from the file plugin
                  reader.readAsDataURL(file);
               });
            }
        }
        // synchronise the data into server
        function sendAttachDataOneByOne(sendAttachData){
            angular.forEach(sendAttachData, function (attachObj) {
                 uploadAttachmentToServer(attachObj).then(function (result) {
                     var statusCode = GENERAL_CONFIG.ServerStatusCode;
                     if(statusCode.Success == result[0].StatusCode){
                        var  attachmentId = result[0].Data.AttachmentID;
                        factoryFunctionArr.updateAttachmentSyncStatus(attachmentId);
                     }
                 }, function (error) { alert(error); });
            });
        }
        function uploadAttachmentToServer(attachmentObj) {
        //factoryFunctionArr.uploadAttachmentToServer = function (attachmentObj){
            var finalData = { "data": [attachmentObj] };
            return serviceApi.doPostWithData("attachmentAddService",
                SERVICE_TYPE.ATTACHMENT, finalData, serviceApi.headerConfg).then(function (response) {
                    return response;
                });
        }
        factoryFunctionArr.getAttachmentData = function(deviceObjId_1,deviceObjId_2){
            return sqliteService.query("SELECT * FROM Attachments WHERE ParentDeviceObjID IN('" + deviceObjId_1 + "','" + deviceObjId_2 + "') AND SyncStatus = 0 AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                return result;
            });
        }
        factoryFunctionArr.updateAttachmentSyncStatus = function(attachmentId){
            return sqliteService.query("UPDATE Attachments SET SyncStatus = 1 WHERE AttachmentID = " + attachmentId + " AND LoggedInUserID = "+ $rootScope.loggedInUserID).then(function (result) {
                return result;
            });
        }
        //*************************************End Attachments Send*********************************
        // Bind the data to server response model
        factoryFunctionArr.bindServerResponseModels = function (res){
            var statusCode = GENERAL_CONFIG.ServerStatusCode;
            var queryBindingsArr = [];
            for(var i=0; i < res.length; i++){
                if(statusCode.Success == res[i].StatusCode){
                    queryBindingsArr.push(factoryFunctionArr.updateTableIds("Contacts",res[i].Data));
                    queryBindingsArr.push(factoryFunctionArr.updateTableIds("Activity",res[i].Data));
                    queryBindingsArr.push(factoryFunctionArr.updateTableIds("Deals",res[i].Data));
                    queryBindingsArr.push(factoryFunctionArr.updateTableIds("UsersAccessMapping",res[i].Data));
                    queryBindingsArr.push(factoryFunctionArr.updateTableIds("Participients",res[i].Data));
                     //queryBindingsArr.push(factoryFunctionArr.updateTableIds("ContactRelationships",res[i].Data));

                    // update the contact employerID and Represntative Ids
                    queryBindingsArr.push(factoryFunctionArr.updateTableEmpIds("Contacts",res[i].Data));
                    queryBindingsArr.push(factoryFunctionArr.updateTableRepIds("Activity",res[i].Data));
                    queryBindingsArr.push(factoryFunctionArr.updateTableRepIds("Deals",res[i].Data));

                    // Update the Entity Ids for sub child table
                    angular.forEach(res[i].Data.Communications, function (communicationObj) {
                         queryBindingsArr.push(factoryFunctionArr.updateTableEntityIds("Communications",communicationObj,res[i].Data));
                    });
                    angular.forEach(res[i].Data.Correspondences, function (correspondenceObj) {
                         queryBindingsArr.push(factoryFunctionArr.updateTableEntityIds("Correspondences",correspondenceObj,res[i].Data));
                    });
                    angular.forEach(res[i].Data.ContactRelationshipMappings, function (relationshipObj) {
                         queryBindingsArr.push(factoryFunctionArr.updateTableEntityIds("ContactRelationships",relationshipObj,res[i].Data));
                    });
                    angular.forEach(res[i].Data.Attachments, function (attachmentObj) {
                         queryBindingsArr.push(factoryFunctionArr.updateTableEntityIds("Attachments",attachmentObj,res[i].Data));
                    });
                    angular.forEach(res[i].Data.Notes, function (notesObj) {
                         queryBindingsArr.push(factoryFunctionArr.updateTableEntityIds("Notes",notesObj,res[i].Data));
                    });
                    queryBindingsArr.push(factoryFunctionArr.updateTableEntityIds("DynamicFields",null,res[i].Data));

                    // update relation ship with second contact change
                    queryBindingsArr.push(factoryFunctionArr.updateTableRelationships("ContactRelationships",res[i].Data));
                }
            }
            return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
            }, function (error) { alert(error); });
        } // End bindServerResponseModels()

        // bind communication empty model into contact model
        factoryFunctionArr.bindCommunicationEmptyModel = function (contactModel)
        {
            var contactType = factoryFunctionArr.constants().contactType;
            var communicationTypes =  factoryFunctionArr.getCommunicationTypes();
            var communicationCategory = factoryFunctionArr.constants().communicationCategory;
            if(contactModel.ContactTypeID == contactType.Individual){
                if(contactModel.Communications.length == 0){
                    var communicationModel = factoryFunctionArr.models().communicationModel;
                    communicationModel.CommunicationCategoryID = communicationCategory.Phone;
                    communicationModel.ParentDeviceObjID = contactModel.DeviceObjID;
                    communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    communicationModel.IsMandatory = true;
                    var filterArrPhone = $filter('filter')(communicationTypes, {CommunicationCategoryID: communicationCategory.Phone});
                    communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                    contactModel.Communications.push(communicationModel);

                    communicationModel = factoryFunctionArr.models().communicationModel;
                    communicationModel.CommunicationCategoryID = communicationCategory.Email;
                    communicationModel.ParentDeviceObjID = contactModel.DeviceObjID;
                    communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    communicationModel.IsMandatory = true;
                    var filterArrEmail = $filter('filter')(communicationTypes, {CommunicationCategoryID: communicationCategory.Email});
                    communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrEmail);
                    contactModel.Communications.push(communicationModel);
                }
            }else {
                if(contactModel.Communications.length == 0){
                    communicationModel = factoryFunctionArr.models().communicationModel;
                    communicationModel.CommunicationCategoryID = communicationCategory.Phone;
                    communicationModel.ParentDeviceObjID = contactModel.DeviceObjID;
                    communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    communicationModel.IsMandatory = true;
                    var filterArrPhone = $filter('filter')(communicationTypes, {CommunicationCategoryID: communicationCategory.Phone});
                    communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                    contactModel.Communications.push(communicationModel);
                }
            }
        }
        // bind Correspondences empty model into contact model
        factoryFunctionArr.bindCorrespondencesEmptyModel = function (contactModel)
        {
            var correspondenceTypes = utility.getMultLangMasData(MASTER_TABLE.CorTyp);
            if(contactModel.Correspondences.length == 0){
                var correspondenceModel = factoryFunctionArr.models().correspondenceModel;
                correspondenceModel.ParentDeviceObjID = contactModel.DeviceObjID;
                correspondenceModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                correspondenceModel.IsMandatory = true;
                correspondenceModel.CorrespondenceTypeID = utility.getDefaultDropDownCorrospondance(correspondenceTypes);
                contactModel.Correspondences.push(correspondenceModel);
            }
        }

        // Contact synchronize from Deal And Activity Module
        factoryFunctionArr.syncServerContactFromOtherModule = function (sererResponseContact,existingContact)
        {
            var contactType = factoryFunctionArr.constants().contactType;
            angular.forEach(sererResponseContact, function (responseObj) {
                 // This condition for the Individual Contact List
                 if(responseObj.ContactTypeID == contactType.Individual){
                    var existedRecord = $filter('filter')(existingContact, {DeviceObjID: responseObj.DeviceObjID});
                    //if(existedRecord == null || existedRecord == ""){
                    if(existedRecord.length == 0){
                        var createNewContactObjModel = factoryFunctionArr.models().contactModel;
                        utility.syncModelWithoutInnerCollection(responseObj,createNewContactObjModel);
                        // add the obj in model and SQLight DB
                        factoryFunctionArr.addContactToSql(responseObj,null).then(function (result) {
                        }, function (error) {  });

                    }else{
                        // update the obj in model and SQLight DB
                        factoryFunctionArr.updateContactToSql(responseObj,null).then(function (result) {
                        }, function (error) {  });
                    }
                 }else{
                     // This condition for the Company Contact List
                    var existedRecord = $filter('filter')(existingContact, {DeviceObjID: responseObj.DeviceObjID});
                    //if(existedRecord == null || existedRecord == ""){
                     if(existedRecord.length == 0){
                        var createNewContactObjModel = factoryFunctionArr.models().contactModel;
                        utility.syncModelWithoutInnerCollection(responseObj,createNewContactObjModel);
                        // add the obj in model and SQLight DB
                        factoryFunctionArr.addContactToSql(null,responseObj).then(function (result) {
                        }, function (error) {  });

                    }else{
                        // update the obj in model and SQLight DB
                        factoryFunctionArr.updateContactToSql(null,responseObj).then(function (result) {
                        }, function (error) {  });
                    }
                 }
            });
        }

        // bind dynamic fields empty model into contact model
        factoryFunctionArr.bindFieldsEmptyModel = function (contactModel)
        {
            var shouldDisplayConfidentialFields = true;
            var fieldSet = utility.getMasterDataByKey(MASTER_TABLE.ConFieldSet);
            fieldSet = $filter('filter')(fieldSet, {IsStaticField: false});
            if (!shouldDisplayConfidentialFields) { //Display Confidential fields if user== full access
                fieldSet = $filter('filter')(fieldSet, {IsConfidential: false});
            }
            fieldSet = $filter('filter')(fieldSet, {ContactTypeID: contactObjModel.ContactTypeID});
            fieldSet = $filter('filter')(fieldSet, {IsVisible: true});

            for (var i = 0; i < fieldSet.length; i++) {
                contactModel.Fields.push({
                    EntityID: contactModel.ContactID,
                    ModuleID: contactModel.ModuleID,
                    ParentDeviceObjID: contactModel.DeviceObjID,
                    FieldLabel: fieldSet[i].FieldLabel,
                    FieldName: fieldSet[i].FieldName,
                    FieldValue: '',
                    FieldID: fieldSet[i].FieldID,
                    IsConfidential: fieldSet[i].IsConfidential,
                    IsMandatory: fieldSet[i].IsMandatory,
                    IsVisible: fieldSet[i].IsVisible,
                    ContactTypeID: fieldSet[i].ContactTypeID,
                    ContactFieldCategoryID: fieldSet[i].ContactFieldCategoryID
                });
            }
        }
            return factoryFunctionArr;
        }
        function CheckNull(val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return "NULL";
            }
            return val;
        }
})();
