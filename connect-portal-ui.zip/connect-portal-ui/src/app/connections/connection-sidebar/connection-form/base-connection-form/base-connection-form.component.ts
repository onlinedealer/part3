import { Component, EventEmitter, Output } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { BaseComponent } from '../../../../core/base.component';
import { FeatureFlagService } from '../../../../shared/services/feature-flag.service';
import { ServiceInjector } from '../../../../shared/services/service.injector';

/**
 * Base component for child connection forms
 */
@Component({
  selector: 'p-connect-base-form',
  template: ''
})
export class BaseConnectionFormComponent extends BaseComponent {
  /**
   * Event that is triggered when the add server button is clicked
   */
  @Output() addServerButtonClickedEvent = new EventEmitter();

  private featureFlagService: FeatureFlagService;

  constructor() {
    super();
    // the service injector allows us to inject any service at the parent level without having to pass an instance of it from each child
    if (ServiceInjector.injector) {
      this.featureFlagService = ServiceInjector.injector.get(FeatureFlagService);
    }
  }

  addRuntimeServer(): void {
    this.addServerButtonClickedEvent.emit();
  }

  /**
   * Removes the form controls that were added as in the connection type form
   * @param formGroup the connection details form group
   */
  removeChildFormControls(formGroup: FormGroup): void {
    if (formGroup) {
      formGroup.clearValidators();
      formGroup.updateValueAndValidity();

      Object.keys(formGroup.controls).forEach((key) => {
        formGroup.removeControl(key);
      });
    }
  }
}
