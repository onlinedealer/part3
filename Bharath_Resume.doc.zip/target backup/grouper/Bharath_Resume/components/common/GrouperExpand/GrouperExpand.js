import React from 'react'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import ExpansionPanel from '@material-ui/core/ExpansionPanel'
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails'
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary'
import Typography from '@material-ui/core/Typography'
import ExpandMoreIcon from '@material-ui/icons/ExpandMore'

const styles = theme => ({
  root: {
    zIndex: '999',
    position: 'absolute',
    width: '85%',
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
  contentPadding: {
    padding: 0,
  },
  panelPadding: {
    padding: '0px 16px',
  },
})

class GrouperExpand extends React.Component {
  state = {
    expanded: false,
  };

  handleChange = (event) => {
    const curPanel = this.state.expanded
    this.setState({
      expanded: !curPanel,
    })
  };

  render () {
    const { classes, expandTitle, expandLinkIcon, expandContent } = this.props
    const { expanded } = this.state

    return (
      <div className={classes.root}>
        <ExpansionPanel expanded={expanded}>
          <ExpansionPanelSummary expandIcon={<ExpandMoreIcon onClick={this.handleChange} />} className={classes.panelPadding}>
            <Typography className={classes.heading}>{expandTitle}{expandLinkIcon}</Typography>
          </ExpansionPanelSummary>
          <ExpansionPanelDetails className={classes.contentPadding}>
            {expandContent}
          </ExpansionPanelDetails>
        </ExpansionPanel>
      </div>
    )
  }
}

GrouperExpand.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(GrouperExpand)
