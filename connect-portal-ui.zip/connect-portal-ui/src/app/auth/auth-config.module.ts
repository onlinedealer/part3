import { NgModule } from '@angular/core';
import { AuthModule, LogLevel, StsConfigHttpLoader, StsConfigLoader } from 'angular-auth-oidc-client';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { catchError, map } from 'rxjs/operators';
import { EMPTY } from 'rxjs';

interface SecurityConfig {
  realm: string;
  resource: string;
  authServerUrl: string;
  sslRequired: string;
  publicClient: string;
  bearerOnly: string;
  principalAttribute: string;
  cors: boolean;
}

export const httpLoaderFactory = (http: HttpClient) => {
  const config = http.get<SecurityConfig>(`${environment.connectApiBaseURL}/config`).pipe(
    map((oidcData: SecurityConfig) => {
      return {
        clientId: oidcData.resource,
        authority: `${oidcData.authServerUrl}/realms/${oidcData.realm}`,
        redirectUrl: window.location.origin,
        postLogoutRedirectUri: window.location.origin,
        scope: 'openid profile email offline_access',
        responseType: 'code',
        silentRenew: true,
        useRefreshToken: true,
        renewTimeBeforeTokenExpiresInSeconds: 3000,
        logLevel: LogLevel.Error,
        ignoreNonceAfterRefresh: true
      };
    }),
    catchError((err, caught) => {
      return EMPTY;
    })
  );
  return new StsConfigHttpLoader(config);
};

@NgModule({
  imports: [
    AuthModule.forRoot({
      loader: {
        provide: StsConfigLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ]
})
export class AuthConfigModule {}
