import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../constants/image-paths';
import {BrowserModule, DomSanitizer} from '@angular/platform-browser'
import {Router} from '@angular/router'
import { UtilityService } from '../services/utility.service';
import { GlobalConfig } from '../constants/constants';

@Component({
  selector: 'app-anonymous-view',
  templateUrl: './anonymous-view.component.html',
  styleUrls: ['./anonymous-view.component.scss']
})
export class AnonymousViewComponent implements OnInit {
  
imagesPaths:any;

@Input() ecstate: any
  constructor(private utilityService:UtilityService, private sanitizer: DomSanitizer, private router: Router) { }

  anonymousSlot1Content;
  anonymousSlot2Content;
  getOneNowRoute;
  faqRoute;
  linkYourCardRoute;

  ngOnInit() {
    this.imagesPaths = ImagePaths;
    this.bccContentFunction();
  }

  bccContentFunction(){
    this.utilityService.getBccContent(GlobalConfig.BCC_ANONYMOUS_SLOT1_ID).subscribe((response)=>{
      if(response && response['response']['header']['statusCode'] === '0000'){
        this.anonymousSlot1Content = this.sanitizer.bypassSecurityTrustHtml(atob(response['response']['details']['slotContent']));
      }
    },
    error =>{
      console.log(error);
    });

    this.utilityService.getBccContent(GlobalConfig.BCC_ANONYMOUS_SLOT2_ID).subscribe((response)=>{
      if(response && response['response']['header']['statusCode'] === '0000'){
        this.anonymousSlot2Content = this.sanitizer.bypassSecurityTrustHtml(atob(response['response']['details']['slotContent']));
      }
    },
    error =>{
      console.log(error);
    });
  }
}
