import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ConnectionListComponent } from './connection-list/connection-list.component';
import { ConnectionConfigureComponent } from 'discovery-shared';
import { ConnectionDetailComponent } from './connection-detail/connection-detail.component';

const routes: Routes = [
  {
    path: '',
    component: ConnectionListComponent
  },
  {
    path: 'new',
    component: ConnectionConfigureComponent
  },
  {
    path: 'edit/:connectionId',
    component: ConnectionConfigureComponent
  },
  {
    path: 'copy/:connectionId',
    component: ConnectionConfigureComponent
  },
  {
    path: 'detail/:connectionId',
    component: ConnectionDetailComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConnectionRoutingModule {}
