import { Component, Input, OnInit, Output, ViewChild, EventEmitter } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { SidebarButton } from 'src/app/shared/components/sidebar/sidebar-button';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';

@Component({
  selector: 'p-connect-bulk-column-mapping-sidebar',
  templateUrl: './bulk-column-mapping-sidebar.component.html',
  styleUrls: ['./bulk-column-mapping-sidebar.component.scss']
})
export class BulkColumnMappingSidebarComponent implements OnInit {
  @ViewChild(SidebarComponent) sidebar: SidebarComponent;
  @Input() checkedItems: any[];
  @Input() displayValues: any[];
  @Input() isReorderEnabled: boolean;
  @Output() bulkMappingObjChange = new EventEmitter<any>();

  cancelButton: SidebarButton = {
    id: 'cancelButton',
    text: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.BUTTONS.CANCEL_BUTTON'
  };
  primaryButton: SidebarButton = {
    id: 'primaryButton',
    text: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.BUTTONS.PRIMARY_BUTTON'
  };
  selectedTargetColumnName;
  filteredTargetColumnNames: any[];
  selectedCase = 'SOURCE_NAME';
  selectedAction = 'DO_NOT_CHANGE';
  multipleEnable = true;
  lang = 'pipelines';
  caseTranslationPrefix = 'STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CASE_DROPDOWN.OPTIONS';
  casingDropdownItems$: Observable<{ label: string; value: string }[]>;
  actionDropdownItems = [
    {
      id: 1,
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ACTION_DROPDOWN.OPTIONS.OPTION_1',
      code: 'DO_NOT_CHANGE'
    },
    {
      id: 2,
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ACTION_DROPDOWN.OPTIONS.OPTION_2',
      code: 'COPY'
    },
    {
      id: 3,
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ACTION_DROPDOWN.OPTIONS.OPTION_3',
      code: 'IGNORE'
    }
  ];
  targetColumnNameDropdownItems = [
    {
      code: 'DO_NOT_CHANGE',
      name: this.translocoService.translate(
        'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.TARGET_COLUMN_NAME_DROPDOWN.OPTIONS.OPTION_1'
      )
    },
    {
      code: 'SOURCE_COLUMN',
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.TARGET_COLUMN_NAME_DROPDOWN.OPTIONS.OPTION_2'
    }
  ];
  bulkMappingObj = {
    action: '',
    targetColumnName: [],
    case: ''
  };
  constructor(private readonly translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.initiateCasingDropdownOptions();
  }

  changeColumnMappingClicked() {
    this.sidebar.open();
  }

  primaryButtonClicked() {
    this.bulkMappingObj.action = this.selectedAction;
    this.bulkMappingObj.case = this.selectedCase;
    this.bulkMappingObj.targetColumnName = this.selectedTargetColumnName;
    this.bulkMappingObjChange.emit(this.bulkMappingObj);
    this.close();
  }

  filterTargetColumnName(event: { code?: string; name?: string; query?: any }) {
    const query = event.query.trim();
    this.filteredTargetColumnNames = this.targetColumnNameDropdownItems.filter((c) => c.code.toLowerCase().startsWith(query.toLowerCase()));
  }

  handleManualInput(evt) {
    if (evt.which === 13) {
      if (!this.selectedTargetColumnName) {
        this.selectedTargetColumnName = [
          {
            code: evt.target.value.trim(),
            name: evt.target.value.trim()
          }
        ];
        evt.target.value = '';
        return;
      }
      if (evt.target.value.trim() !== '') {
        this.selectedTargetColumnName.push({
          code: evt.target.value.trim(),
          name: evt.target.value.trim()
        });
        evt.target.value = '';
      }
    }
  }

  onSelect(event) {
    if (this.selectedTargetColumnName.length) {
      if (this.selectedTargetColumnName.some((e) => e.code === 'DO_NOT_CHANGE')) {
        this.multipleEnable = false;
        this.selectedTargetColumnName = {
          code: 'DO_NOT_CHANGE',
          name: this.translocoService.translate(
            'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.TARGET_COLUMN_NAME_DROPDOWN.OPTIONS.OPTION_1'
          )
        };
      } else if (event.code === 'SOURCE_COLUMN') {
        this.multipleEnable = true;
      }
    } else {
      if (this.selectedTargetColumnName.code === 'DO_NOT_CHANGE') {
        this.multipleEnable = false;
        this.selectedTargetColumnName = {
          code: 'DO_NOT_CHANGE',
          name: this.translocoService.translate(
            'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.TARGET_COLUMN_NAME_DROPDOWN.OPTIONS.OPTION_1'
          )
        };
      } else if (this.selectedTargetColumnName.code === 'SOURCE_COLUMN') {
        this.multipleEnable = true;
        this.selectedTargetColumnName = [
          {
            code: 'SOURCE_COLUMN',
            name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.TARGET_COLUMN_NAME_DROPDOWN.OPTIONS.OPTION_2'
          }
        ];
      }
    }
  }

  private initiateCasingDropdownOptions = () => {
    this.casingDropdownItems$ = this.translocoService
      .selectTranslateObject(`${this.caseTranslationPrefix}`, null, this.lang)
      .pipe(map((dropdownOptions) => this.transformToDropdownOptions(dropdownOptions)));
  };

  private transformToDropdownOptions(translationObject, filteredKey?): { label: string; value: string }[] {
    return Object.keys(translationObject)
      .filter((option) => option !== filteredKey)
      .map((key) => ({
        label: translationObject[key],
        value: key
      }));
  }

  close() {
    this.selectedCase = 'SOURCE_NAME';
    this.selectedAction = 'DO_NOT_CHANGE';
    this.selectedTargetColumnName = [];
    this.sidebar.close();
  }
}
