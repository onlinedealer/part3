(function() {
    'use strict';
    /* Technology List */
    codeathonApp.controller("technologyCtrl", ['$scope', 'uiRouters', '$ajaxFactory', '$location', technologyCtrl]);

    function technologyCtrl($scope, uiRouters, $ajaxFactory, $location) {

        $scope.technologyDataSource = [];
        $scope.versionData = [];
        $scope.statusData = [];
        $scope.itemData = {};
        $scope.isEditOrAddPage = false;
        $scope.isAddPage = false;
        $scope.buttonText = "";
        $scope.headerText = "";
        $scope.techName = "";
        $scope.techDescription = "";
        $scope.techStatus = "";
        $scope.techVersion = "";
        var userId = "";
        var techId = "";
        var url = "";

        // redirecting to /login page
        if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        }

        $scope.editItem = function(item) {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = false;
            $scope.itemData = item;
            $scope.techName = item.techName;
            $scope.techDescription = item.description;
            $scope.techVersion = item.version;
            $scope.buttonText = "Update";
            $scope.headerText = "Edit";
            techId = item.id;
        };

        $scope.removeItem = function(tectId) {
            indicatorStart("Deleting technology..");
            url = "/delete/technology/" + tectId + "/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/technology/data.json', 'POST', {});
         //   var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'POST', {});

            promise.then(function(d) {
                $scope.technologyDataSource = d;
                console.log('Delete Success');
				  $scope.fetchDataSource();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.addItem = function() {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = true;
            $scope.techName = "";
            $scope.techDescription = "";
			$scope.techVersion ="";
            $scope.buttonText = "Save";
            $scope.headerText = "Create";
        };

        $scope.saveData = function(e) {
            if (Codeathon.utils.isNullOrEmpty($scope.techName) || Codeathon.utils.isNullOrEmpty($scope.techDescription) ||
                Codeathon.utils.isNullOrEmpty($scope.techVersion)) {
                alert("All Fields Required");
                return;
            } else {
                var obj = {}
                obj.techName = $scope.techName;
                obj.description = $scope.techDescription;
                obj.version = $scope.techVersion;

                // if isAddPage true : Adding New technology
                // if isAddPage False : Editing technology
                if ($scope.isAddPage) {
                    indicatorStart("Adding technology..");
                    url = uiRouters.filepath + '/technology/data.json';
                    // url = uiRouters.urlpath + "/add/new/technology/user/" + userId + "/";
                } else {
                    indicatorStart("Updating technology..");
                    indicatorStart("Updating technology..");
                  url = uiRouters.filepath + '/technology/data.json';
                  //  url = uiRouters.urlpath + " /modify/technology/" + techId + "/user/" + userId + "/";
                }
                var promise = $ajaxFactory.getDataFromServer(url, 'POST', obj);

                promise.then(function(d) {
                    $scope.technologyDataSource = d;
                    $scope.isEditOrAddPage = false;
                    $scope.isAddPage = false;
                    console.log('Success');

                    var obj = {};
                    obj.message = "Technology";
                    obj.content = "Success";
                    obj.eventObj = e;
                    $scope.$emit('openPopupEvent', obj);
					  $scope.fetchDataSource();
                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
                promise.finally(function(d) {
                    console.log('finally block executed', d);
                    indicatorStop();
                });
            }
        };

        $scope.cancel = function() {
            $scope.isEditOrAddPage = false;
            $scope.isAddPage = false;
        };

        $scope.fetchDataSource = function() {
            url = "/get/list/of/technology/user/" + userId + "/";
            // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/technology/data.json', 'GET', {});

            promise.then(function(d) {
                $scope.technologyDataSource = d;
                $scope.versionData = Codeathon.utils.getListByProperty(d, 'version');
                $scope.statusData = Codeathon.utils.getListByProperty(d, 'status');
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.fetchDataSource();
    }

})();
