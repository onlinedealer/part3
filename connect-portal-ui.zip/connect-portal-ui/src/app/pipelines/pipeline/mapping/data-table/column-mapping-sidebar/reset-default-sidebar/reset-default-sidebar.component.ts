import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Pipeline } from 'src/app/pipelines/pipeline/shared/pipeline';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
import { ColumnMap } from '../../../shared/map-columns';
@Component({
  selector: 'p-connect-reset-default-sidebar',
  templateUrl: './reset-default-sidebar.component.html',
  styleUrls: ['./reset-default-sidebar.component.scss']
})
export class ResetDefaultSidebarComponent {
  @ViewChild(SidebarComponent) sidebar: SidebarComponent;
  @Input() checkedItems: any[];
  @Input() displayValues: any[];
  @Input() pipeline: Pipeline;
  @Input() schemaLibrary;
  @Input() rowData;
  @Input() rowTableMapping;
  @Input() isReorderEnabled: boolean;
  @Output() resetDataChange = new EventEmitter<any>();
  @Output() checkedItemsChange = new EventEmitter<any>();
  resetData: ColumnMap[];
  cancelButton: SidebarButton = {
    id: 'cancelButton',
    text: 'pipelines.STAGES.MAPPING.RESET_TO_DEFAULT.CANCEL'
  };
  primaryButton: SidebarButton = {
    id: 'resetButton',
    text: 'pipelines.STAGES.MAPPING.RESET_TO_DEFAULT.RESET_BUTTON'
  };
  constructor(private readonly mappingService: PipelineMappingService) {}
  resetSidebarOpen() {
    this.sidebar.open();
  }
  primaryButtonClicked() {
    this.sidebar.isProcessingRequest = true;
    let sortedCheckedItems = this.checkedItems.sort(this.sortID);
    this.mappingService.resetToDefault(this.pipeline.id, sortedCheckedItems, this.rowTableMapping).subscribe({
      next: (data: ColumnMap[]) => {
        this.handleApiSuccess(data);
      },
      error: (errorMessage: HttpErrorResponse) => {
        this.handleApiFailure(errorMessage);
      }
    });
  }
  private sortID(a, b) {
    return a.id - b.id;
  }
  close() {
    this.sidebar.close();
  }

  handleApiSuccess(data) {
    this.resetData = data;
    this.close();
    this.sidebar.isProcessingRequest = false;
    this.resetDataChange.emit(this.resetData);
  }

  handleApiFailure(errorMessage: HttpErrorResponse) {
    this.sidebar.isProcessingRequest = false;
    this.sidebar.parseHttpClientResponseMessage('error', errorMessage);
  }
}
