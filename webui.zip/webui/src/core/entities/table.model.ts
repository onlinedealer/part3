import { ColumnModel } from './column.model';

export class TableModel {
  name: string;
  /**
   * display name of the table
   */
  displayName: string;

  count: string | number;
  selected: boolean;
  schema: string;

  type: string;
  uniqueKey: string | number;
  rowDisabled?: boolean;
  checkboxDisabled?: boolean;
  columns: ColumnModel[];
  tooltip?: string;

  constructor(table?: TableModel) {
    this.selected = table && table.selected;
    this.columns = [];
    if (table) {
      this.name = table.name;
      this.displayName = table.displayName;
      this.schema = table.schema;
      this.type = table.type;
      this.count = table.count;
      this.uniqueKey = table.uniqueKey;
      this.rowDisabled = table.rowDisabled;
      this.checkboxDisabled = table.checkboxDisabled;
      this.tooltip = table.tooltip;
      if (table.columns) {
        for (const column of table.columns) {
          this.columns.push(new ColumnModel(column));
        }
      }
    }
  }
}
