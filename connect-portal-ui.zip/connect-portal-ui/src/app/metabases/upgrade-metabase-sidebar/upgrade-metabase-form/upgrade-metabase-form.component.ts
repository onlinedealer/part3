import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, TemplateRef } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { EMPTY, Observable, Subscription } from 'rxjs';
import { catchError, pluck } from 'rxjs/operators';
import { Connection } from 'src/app/connections/shared/connection';
import { BaseComponent } from 'src/app/core/base.component';
import { Metabase } from '../../shared/metabase.model';
import { MetabasesApiService } from '../../shared/metabases-api.service';

@Component({
  selector: 'p-connect-upgrade-metabase-form',
  templateUrl: './upgrade-metabase-form.component.html'
})
export class UpgradeMetabaseFormComponent extends BaseComponent implements OnInit, OnDestroy {
  @Input() errorTemplate: TemplateRef<any>;

  /*
   * Selected Metabase
   */
  selectedMetabase: Metabase;

  /*
   * Notifies form on if metabase has been deleted
   */
  metabaseExists: boolean;

  /**
   * Subscriptions that are used in this component
   */
  subscriptions: Subscription;

  /**
   * Name of database server
   */
  databaseServerName: string = '';

  /**
   * Form group
   */
  upgradeMetabaseForm: FormGroup;

  /**
   * Metabase version available for upgrade
   */
  upgradedMetabaseVersion: Observable<any>;

  /**
   * Administrator information for upgrading the metabase
   */
  upgradeMetabaseMessage: string = '';

  /**
   * Input label, different for each connection type
   */
  userIdInputLabel: string = '';

  /**
   * Toggle displaying error message
   */
  displayErrorMessage: boolean = false;

  /**
   * Updates the disabled state of the primary button
   */
  @Output() primaryButtonStateChange = new EventEmitter<boolean>();

  /**
   * Hides primary button and changes cancel button text
   * if metabase no longer exists
   */
  @Output() metabaseDeletedEvent = new EventEmitter();

  /**
   * Shows admin user id and password input fields if connection type is not DB2I
   */
  get displayUsernamePasswordInputFields(): boolean {
    return this.selectedMetabase?.dataConnection?.connectionType !== 'DB2I' ? true : false;
  }

  constructor(private readonly metabasesApiService: MetabasesApiService) {
    super();
  }

  ngOnInit(): void {
    this.createFormGroup();
  }

  ngOnDestroy(): void {
    this.subscriptions.unsubscribe();
  }

  /**
   * Metabase data to be displayed in the form.
   * @param selectedMetabase value always truthy, even if selected metabase
   * is deleted.
   */
  open(selectedMetabase: Metabase) {
    this.selectedMetabase = selectedMetabase;
    this.metabaseExists = true;
    this.setFormContent(selectedMetabase.dataConnection);
    this.setFormValuesForDB2IConnection(selectedMetabase);
    this.setPrimaryButtonDisabledState(selectedMetabase);
    this.upgradedMetabaseVersion = this.metabasesApiService.getMetabaseVersionForUpgrade(selectedMetabase.dataConnection?.id).pipe(
      pluck('response'),
      catchError((errorResponse) => this.handleError(errorResponse))
    );
  }

  /**
   * Toggles content of form based on connection type
   */
  setFormContent(dataConnection: Connection): void {
    switch (dataConnection?.connectionType) {
      case 'DB2':
        this.databaseServerName = `${dataConnection.database}:${dataConnection.port}`;
        this.upgradeMetabaseMessage = 'metabases.METABASE_UPGRADE.DB2_ADMINISTRATOR_INFORMATION';
        this.userIdInputLabel = 'metabases.METABASE_UPGRADE.DB2_USER_ID';
        break;
      case 'ORACLE':
        this.databaseServerName = `${dataConnection.database}:${dataConnection.port}`;
        this.upgradeMetabaseMessage = 'metabases.METABASE_UPGRADE.ORACLE_ADMINISTRATOR_INFORMATION';
        this.userIdInputLabel = 'metabases.METABASE_FORM.ORACLE.USER_ID';
        this.upgradeMetabaseForm.patchValue({ adminUserId: 'SYS' });
        break;
      case 'SQLSERVER':
        this.databaseServerName = `${dataConnection.database}:${dataConnection.port}`;
        this.upgradeMetabaseMessage = 'metabases.METABASE_UPGRADE.SQL_ADMINISTRATOR_INFORMATION';
        this.userIdInputLabel = 'metabases.METABASE_UPGRADE.SQL_USER_ID';
        this.upgradeMetabaseForm.patchValue({ adminUserId: 'sa' });

      case 'DB2I':
        this.databaseServerName = dataConnection.database;
        this.upgradeMetabaseMessage = '';
    }
  }

  handleError(errorResponse: HttpErrorResponse) {
    if (errorResponse.error && errorResponse.error.message?.includes('Metabase not found')) {
      this.metabaseExists = false;
      this.metabaseDeletedEvent.emit();
    }
    return EMPTY;
  }

  private createFormGroup(): void {
    this.upgradeMetabaseForm = new FormGroup({
      adminUserId: new FormControl('', { validators: [Validators.required], updateOn: 'blur' }),
      adminUserPassword: new FormControl('', { validators: [Validators.required], updateOn: 'blur' })
    });
    this.subscriptions = this.upgradeMetabaseForm.valueChanges.subscribe(() => {
      this.updateButtonDisabledState();
    });
  }

  /**
   * Enables primary button if connection type is DB2I
   * DB2I form does not have User Id & Password input fields
   * No form validation required
   */
  private setPrimaryButtonDisabledState(selectedMetabase: Metabase): void {
    selectedMetabase?.dataConnection?.connectionType === 'DB2I'
      ? this.primaryButtonStateChange.emit(false)
      : this.primaryButtonStateChange.emit(true);
  }

  private setFormValuesForDB2IConnection(selectedMetabase: Metabase): void {
    if (selectedMetabase?.dataConnection?.connectionType === 'DB2I' && selectedMetabase?.parameters) {
      this.upgradeMetabaseForm.patchValue({
        adminUserId: this.getParameterValue(selectedMetabase.parameters, 'REPLICATION_USER_ID'),
        adminUserPassword: this.getParameterValue(selectedMetabase.parameters, 'REPLICATION_USER_PASSWORD')
      });
    }
  }

  private updateButtonDisabledState(): void {
    this.upgradeMetabaseForm.valid ? this.primaryButtonStateChange.emit(false) : this.primaryButtonStateChange.emit(true);
  }
}
