import { ProfileRuleAvailabilityModel } from './profile-rule-availability.model';
import { ProfileRuleOptionModel } from './profile-rule-option.model';

export class ProfileRuleInformationModel {
  name: string;
  label: string;
  description: string;
  ruleAvailability: ProfileRuleAvailabilityModel;
  ruleOptionList: ProfileRuleOptionModel[];
}
