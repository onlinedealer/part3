import { Injectable } from "@angular/core";
import { HttpRequest } from "@angular/common/http";

@Injectable({
    providedIn: "root"
})
export class InterceptorFilterService {
    private skipEndPoints = ["security/getUserInfo", "security/updateSession"];

    constructor() {}

    isRequestFiltered(req: HttpRequest<any>) {
        if (req.url.startsWith("assets")) {
            return true;
        }
        if (!req.url) {
            return true;
        }
        for (const endPoint of this.skipEndPoints) {
            if (req.url.endsWith(endPoint)) {
                return true;
            }
        }
        return false;
    }
}
