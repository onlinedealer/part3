import { Observable, from, of } from "rxjs";
import { map, tap, catchError, concatMap } from "rxjs/operators";

export class CompaniesService {

  getCompanies(): Observable<any> {

    return of([
      {
        id: 123,
        partyAbbreviation: "ABR123",
        name: "Company 123",
      },
      {
        id: 222,
        partyAbbreviation: "ABR222",
        name: "Company 222",
      }
    ]);

  }

}
