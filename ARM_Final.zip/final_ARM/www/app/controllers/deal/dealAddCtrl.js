(function () {
    'use strict';

    angular.module('arm').controller('dealAddCtrl',
                ['$scope', '$state', '$filter', 'authService', 'dealService', 'contactService', '$ionicModal', '$cordovaCamera',  '$cordovaFile', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', '$window', '$cordovaDialogs','$rootScope','ALERT_MESSAGE','productService', 'noteService', dealAddCtrl]);

    function dealAddCtrl($scope, $state, $filter, authService, dealService, contactService, $ionicModal, $cordovaCamera, $cordovaFile, utility, MASTER_TABLE, GENERAL_CONFIG, $window, $cordovaDialogs,$rootScope,ALERT_MESSAGE,productService,noteService) {
        // Calendar Date
        $scope.selDate ={
            SelectedDate : ''
        };

        // User contacts

        $scope.selContacts = {
            activeContact: "",
            tempContact: ""
        };

        // Product family
        $scope.selProduct = {
            activeProduct: "",
            tempProduct: ""
        };

        // Deal Stage
        $scope.selDealStages = {
            activeDealStage: "",
            tempDealStage: ""
        };

        // Deal Source
        $scope.selDealSource = {
            activeDealSource: "",
            tempDealSource: ""
        };

        // Deal Owner
        $scope.selUserOwners = {
            activeUser: "",
            tempUser: ""
        };

        $scope.selDealOwner = "";

        //////////////////////////////////////////////// Setting Values from the Master Table ////////////////////////////////////////////////////////////

        $scope.dealSources = utility.getMultLangMasData(MASTER_TABLE.DelSuc);
        $scope.dealStages = utility.getMultLangMasData(MASTER_TABLE.DelSubStg);
        $scope.currencies = utility.getMultLangMasData(MASTER_TABLE.Curcy);
        $scope.fieldSet = utility.getMasterDataByKey(MASTER_TABLE.DelSet);
        $scope.prodType = utility.getMasterDataByKey(MASTER_TABLE.PrdTyp);
        $scope.prodSchemes = utility.getMasterDataByKey(MASTER_TABLE.PrdSch);
        $scope.custType = utility.getMasterDataByKey(MASTER_TABLE.CusTyp);
        $scope.docChecklistMat = utility.getMasterDataByKey(MASTER_TABLE.ChLstMat);
        $scope.docChecklistData = utility.getMasterDataByKey(MASTER_TABLE.ChLstDoc);
        var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);

        //alert(JSON.stringify($scope.fieldSet));
        //console.log('Created By:'+lgnUser.UserID);

        $scope.user = {};
        $scope.user.firstName = '';
        $scope.user.lastName = '';
        $scope.fieldsNo = 10;
        $scope.fields = [];
        $scope.additionalDetailsArr = [];
        $scope.contactDisplayArr = [];
        $scope.individualContactArr = [];
        $scope.companyContactArr = [];
        $scope.productFamilies = [];
        $scope.cntPars = [];
        $scope.prodTypeArr = [];
        $scope.prodSchemeArr = [];
        $scope.user.selectedProdType = '';
        $scope.user.selectedProdScheme = '';
        $scope.user.selectedCustType = '';
        $scope.user.dealaddnotes = '';
        //its used for field controls
        $scope.IsContact = false;
        $scope.selCntPar = [];
        $scope.selUsrPar = [];

        var selCntPar = [];
        var selUsrPar = [];

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        ////////////////////////////////////////////////////// Deal Checklist Search Function //////////////////////////////////////////////////////////

        $scope.documentChecklistSearch = function(){
            var documentChecklistSearchDescription = '';
            var documentChecklistManagementID = '';
            $scope.dealModel.DealChecklistMapping = {};
            $scope.dealModel.DealDocumentMapping = [];
            $scope.dealModel.DealChecklistMappingStr = '';
            if($scope.dealModel.ProductFamilyID){
                documentChecklistSearchDescription += $scope.dealModel.ProductFamilyID;
                $scope.dealModel.DealChecklistMappingStr += $scope.dealModel.ProductFamilyID+',';
                $scope.dealModel.DealChecklistMapping.ProductFamilyID = $scope.dealModel.ProductFamilyID;
            }else{
                documentChecklistSearchDescription += '0';
                $scope.dealModel.DealChecklistMappingStr += '0,';
                $scope.dealModel.DealChecklistMapping.ProductFamilyID = null;
            }
            if($scope.dealModel.ProductID){
                documentChecklistSearchDescription += $scope.dealModel.ProductID;
                $scope.dealModel.DealChecklistMappingStr += $scope.dealModel.ProductID+',';
                $scope.dealModel.DealChecklistMapping.ProductID = $scope.dealModel.ProductID;
            }else{
                documentChecklistSearchDescription += '0';
                $scope.dealModel.DealChecklistMappingStr += '0,';
                $scope.dealModel.DealChecklistMapping.ProductID = null;
            }
            if($scope.user.selectedProdType.ProductTypeID){
                documentChecklistSearchDescription += $scope.user.selectedProdType.ProductTypeID;
                $scope.dealModel.DealChecklistMappingStr += $scope.user.selectedProdType.ProductTypeID+',';
                $scope.dealModel.DealChecklistMapping.ProductTypeID = $scope.user.selectedProdType.ProductTypeID;
            }else{
                documentChecklistSearchDescription += '0';
                $scope.dealModel.DealChecklistMappingStr += '0,';
                $scope.dealModel.DealChecklistMapping.ProductTypeID = null;
            }
            if($scope.user.selectedProdScheme.ProductSchemeID){
                documentChecklistSearchDescription += $scope.user.selectedProdScheme.ProductSchemeID;
                $scope.dealModel.DealChecklistMappingStr += $scope.user.selectedProdScheme.ProductSchemeID+',';
                $scope.dealModel.DealChecklistMapping.ProductSchemeID = $scope.user.selectedProdScheme.ProductSchemeID;
            }else{
                documentChecklistSearchDescription += '0';
                $scope.dealModel.DealChecklistMappingStr += '0,';
                $scope.dealModel.DealChecklistMapping.ProductSchemeID = null;
            }
            if($scope.user.selectedCustType.CustomerTypeID){
                documentChecklistSearchDescription += $scope.user.selectedCustType.CustomerTypeID;
                $scope.dealModel.DealChecklistMappingStr += $scope.user.selectedCustType.CustomerTypeID;
                $scope.dealModel.DealChecklistMapping.CustomerTypeID = $scope.user.selectedCustType.CustomerTypeID;
            }else{
                documentChecklistSearchDescription += '0';
                $scope.dealModel.DealChecklistMappingStr += '0';
                $scope.dealModel.DealChecklistMapping.CustomerTypeID = null;
            }
            //console.log('Product Family'+$scope.dealModel.ProductFamilyID);
            //console.log('Product ID'+$scope.dealModel.ProductID);
            //console.log('Product Type'+$scope.user.selectedProdType.ProductTypeID);
            //console.log('Product Scheme'+$scope.user.selectedProdScheme.ProductSchemeID);
            //console.log('Customer Type'+$scope.user.selectedCustType.CustomerTypeID);
            //console.log('Document Checklist Search Matrix'+documentChecklistSearchDescription);
            //console.log('Document Checklist Search Matrix String'+$scope.dealModel.DealChecklistMappingStr);
            //console.log('Document Checklist Search Matrix Object'+JSON.stringify($scope.dealModel.DealChecklistMapping));


            if($scope.docChecklistMat != null){
            for(var i=0;i<$scope.docChecklistMat.length;i++){
                if($scope.docChecklistMat[i].Description == documentChecklistSearchDescription){
                    documentChecklistManagementID = $scope.docChecklistMat[i].ChecklistManagementID;
                    for(var j=0;j<$scope.docChecklistData.length;j++){
                        if($scope.docChecklistData[j].ChecklistManagementID == documentChecklistManagementID){
                            var documentChecklistObj = {};
                            documentChecklistObj.DocumentID = $scope.docChecklistData[j].DocumentID;
                            documentChecklistObj.DocumentName = $scope.docChecklistData[j].DocumentName;
                            documentChecklistObj.ParentDeviceObjID = $scope.dealModel.DeviceObjID;
                            documentChecklistObj.DeviceObjID = utility.generateUUID();
                            documentChecklistObj.DealID = 0;
                            documentChecklistObj.DealDocumentMappingID = 0;
                            $scope.dealModel.DealDocumentMapping.push(documentChecklistObj);
                        }
                    }
                    //console.log("Document Checklist"+JSON.stringify($scope.dealModel.DealDocumentMapping));
                }
            }
         }

        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////// Add and Edit Mode Initializations //////////////////////////////////////////////////////////////


        $scope.isEditModeFlag = $state.params.editModeFlag;
        if($scope.isEditModeFlag == 0){
            $scope.title = 'Add Deal';
            $scope.dealModel = dealService.dealMod().uiObject;

            $scope.user.dealSizeCurrencyObject = $scope.currencies[0];
            $scope.user.expectedDealSize = $scope.dealModel.ExpectedDealSize;
            $scope.user.expectedDealSizeConverted = $scope.dealModel.ExpectedDealSizeConverted;

            $scope.user.dealRevenueCurrencyObject = $scope.currencies[0];
            $scope.user.expectedDealRevenue = $scope.dealModel.ExpectedDealRevenue;
            $scope.user.expectedDealRevenueConverted = $scope.dealModel.ExpectedDealRevenueConverted;
            $scope.user.docChecklistDisabled = true;

            $scope.selUserOwners = {
                activeUser: lgnUser.UserID,
                tempUser: lgnUser.UserID
            };

            if($scope.dealSources.length > 0){
                $scope.selDealSource.tempDealSource = $scope.dealSources[0].DealSourceID;
                $scope.dealModel.DealSourceName = $scope.dealSources[0].Name;
                $scope.dealModel.DealSourceID = $scope.dealSources[0].DealSourceID;
            }
        }else{
            $scope.title = 'Edit Deal';
            $scope.dealModelEdited = dealService.getSelectedDeal();
            $scope.dealModel = angular.copy($scope.dealModelEdited);
            $scope.dealModel.Notes = [];
            $scope.selContacts.tempContact = $scope.dealModel.ContactDeviceObjID;
            $scope.selProduct.tempProduct = $scope.dealModel.ProductID;
            $scope.selDealStages.tempDealStage = $scope.dealModel.DealStageID;

            for(var i=0;i<$scope.currencies.length;i++){
                if($scope.currencies[i].CurrencyID == $scope.dealModel.ExpectedDealSizeCurrencyID){
                    $scope.user.dealSizeCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.expectedDealSize = $scope.dealModel.ExpectedDealSize;
            $scope.user.expectedDealSizeConverted = $scope.dealModel.ExpectedDealSizeConverted;

            for(var i=0;i<$scope.currencies.length;i++){
                if($scope.currencies[i].CurrencyID == $scope.dealModel.ExpectedDealRevenueCurrencyID){
                    $scope.user.dealRevenueCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.expectedDealRevenue = $scope.dealModel.ExpectedDealRevenue;
            $scope.user.expectedDealRevenueConverted = $scope.dealModel.ExpectedDealRevenueConverted;

            if($scope.selProduct.tempProduct != ''){
                $scope.user.docChecklistDisabled = false;
            }

            for(var k=0;k<$scope.prodType.length;k++){
                if($scope.prodType[k].ProductID == $scope.dealModel.ProductID){
                    var prodTypeObj = {};
                    prodTypeObj.Name = $scope.prodType[k].Name;
                    prodTypeObj.ProductTypeID = $scope.prodType[k].ProductTypeID;
                    $scope.prodTypeArr.push(prodTypeObj);
                }
            }

            var dealChecklistMappingSplitStr = $scope.dealModel.DealChecklistMappingStr.split(",");

            for(var i=0;i<$scope.prodTypeArr.length;i++){
                if(parseInt(dealChecklistMappingSplitStr[2]) == $scope.prodTypeArr[i].ProductTypeID){
                    $scope.user.selectedProdType = $scope.prodTypeArr[i];
                }
            }

            for(var k=0;k<$scope.prodSchemes.length;k++){
                if($scope.prodSchemes[k].ProductID == $scope.dealModel.ProductID){
                    var prodSchemeObj = {};
                    prodSchemeObj.Name = $scope.prodSchemes[k].Name;
                    prodSchemeObj.ProductSchemeID = $scope.prodSchemes[k].ProductSchemeID;
                    $scope.prodSchemeArr.push(prodSchemeObj);
                }
            }

            for(var i=0;i<$scope.prodSchemeArr.length;i++){
                if(parseInt(dealChecklistMappingSplitStr[3]) == $scope.prodSchemeArr[i].ProductSchemeID){
                    $scope.user.selectedProdScheme = $scope.prodSchemeArr[i];
                }
            }

            for(var i=0;i<$scope.custType.length;i++){
                if(parseInt(dealChecklistMappingSplitStr[4]) == $scope.custType[i].CustomerTypeID){
                    $scope.user.selectedCustType = $scope.custType[i];
                }
            }

            $scope.documentChecklistSearch();

            var dealModelAttendeesToAssign = angular.copy($scope.dealModel.DealAttendees);
            $scope.dealModel.DealAttendees = [];

            for(var i=0;i<dealModelAttendeesToAssign.length;i++){
                if(dealModelAttendeesToAssign[i].Type == 'CP'){
                    selCntPar.push(dealModelAttendeesToAssign[i]);

                }else if(dealModelAttendeesToAssign[i].Type == 'UP'){
                    selUsrPar.push(dealModelAttendeesToAssign[i]);
                }
            }

            $scope.selDealSource.tempDealSource = $scope.dealModel.DealSourceID;

            $scope.selUserOwners.activeUser = $scope.dealModel.OwnerID;
            $scope.selDealOwner = $scope.dealModel.OwnerName;
        }


        ////////////////////////////////////////////////////// Calendar Date Implementation ////////////////////////////////////////////////////////////

        $scope.SelFinalDate = $scope.dealModel.ExpectedDealCloseDate;

        $scope.$watch(function (scope) { return scope.selDate.SelectedDate },
              function (newValue, oldValue) {
                  if (newValue == null || newValue == '') return;
                  loadSelIndx(-1);
                  $scope.SelFinalDate = utility.getDateInDisplayFormat(newValue);
              }
        );

        $scope.dealDates = [
            { Date: "6", Month: 'MAY', Year: '2016', Day: 'IN A WEEK', Key: 'C'},
            { Date: "7", Month: 'MAY', Year: '2016', Day: 'IN 2 WEEK', Key: 'M'},
            { Date: "13", Month: 'MAY', Year: '2016', Day: 'NEXT MONTH', Key: 'S' },
            { Date: "6", Month: 'JUNE', Year: '2016', Day: '3 MONTH', Key: 'E'}
        ];

        function init() {
            var curDate = new Date();
            curDate.setDate(curDate.getDate());
            var dt = loadDates(curDate, 7, 0, 'D');
            //In 2 week date

            loadDates(curDate, 14, 1, 'D');

            //Next month date

            loadDates(curDate, 1, 2, 'M');

            // 3 month

            loadDates(curDate, 3, 3, 'M');
            if($scope.isEditModeFlag == 0){
                SelectedDate($scope.dealDates[0]['Date'],$scope.dealDates[0]['Month'],$scope.dealDates[0]['Year']);
                loadSelIndx(0);
                loadSubject();
            }else{
                var closeDateStr = $scope.dealModel.ExpectedDealCloseDate.split("-");
                $scope.SelFinalDate = closeDateStr[2]+"-"+closeDateStr[1]+"-"+closeDateStr[0];
                $scope.selDate.SelectedDate = new Date(closeDateStr[0], (closeDateStr[1] - 1), closeDateStr[2]);
            }
            loadContacts();
            loadProductFamily();
            loadUsersData();
            if($scope.isEditModeFlag == 0){
                loadFields();
            }else{
                angular.copy($scope.dealModel.Fields, $scope.fields);
            }
        }

        function loadSelIndx(val) {
            $scope.selDateIndx = val;
        }

        function loadDates(date,val,indx, type) {
            var retDt = utility.dateCal(date, val, type);
            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            $scope.dealDates[indx]["Date"] = retDt.getDate();
            $scope.dealDates[indx]["Month"] = monthNames[retDt.getMonth()];
            $scope.dealDates[indx]["Year"] = retDt.getFullYear();
            return retDt;
        }

        $scope.actionDate = function ($index, val, month, year) {
            $scope.selDateIndx = $index;
            SelectedDate(val, month, year);
        }

        function SelectedDate(val, month, year) {
            var dt = new Date();
            dt.setDate(val);
            dt.setMonth((utility.monthNameToNum(month) - 1));
            dt.setFullYear(year);
            $scope.SelFinalDate = utility.getDateInDisplayFormat(dt);
        }

        ////////////////////////////////////////////////////////// Loading the Deal Subject ////////////////////////////////////////////////////////////////

        function loadSubject(){
            if($scope.dealModel.ProductFamilyName != ''){
                $scope.dealModel.DealSubject = $scope.dealModel.ProductFamilyName+' - '+$scope.dealModel.ProductName;
            }
        }



        ///////////////////////////////////////////////////////// Loading the User Contacts ////////////////////////////////////////////////////////////////


        function loadContacts(){
            utility.sqlGetAllContacts().then(function(result){
                //console.log("Contacts result is"+JSON.stringify(result));
                for (var i = 0; i < result.rows.length; i++) {
                    //console.log('FirstName'+result.rows.item(i).FirstName+' and Company Name'+result.rows.item(i).CompanyName);
                    if(result.rows.item(i).ContactTypeID == 1){
                        $scope.individualContactArr.push(result.rows.item(i));
                    }else if(result.rows.item(i).ContactTypeID == 2){
                        $scope.companyContactArr.push(result.rows.item(i));
                    }
                }
                //console.log('indi contact'+JSON.stringify($scope.individualContactArr));
                //console.log('rep contact'+JSON.stringify($scope.companyContactArr));

                for(var i=0;i<$scope.individualContactArr.length;i++){
                    if($scope.individualContactArr[i].EmployerDeviceObjID == "" || $scope.individualContactArr[i].EmployerDeviceObjID == "undefined" || $scope.individualContactArr[i].EmployerDeviceObjID == "null"){
                        $scope.contactSelectionModel = utility.contactSelectionMod().uiObject;
                        $scope.contactSelectionModel.ContactName = $scope.individualContactArr[i].FirstName+" "+$scope.individualContactArr[i].LastName;
                        $scope.contactSelectionModel.AttendeeDeviceObjID = $scope.individualContactArr[i].DeviceObjID;
                        $scope.contactSelectionModel.ContactDeviceObjID = $scope.individualContactArr[i].DeviceObjID;
                        $scope.contactSelectionModel.ContactID = $scope.individualContactArr[i].ContactID;
                        $scope.contactSelectionModel.UserID = $scope.individualContactArr[i].ContactID;
                        $scope.contactSelectionModel.ContactTypeID = $scope.individualContactArr[i].ContactTypeID;
                        $scope.contactSelectionModel.ContactOwnerID = $scope.individualContactArr[i].OwnerID;
                        $scope.contactSelectionModel.ContactOwnerName = $scope.individualContactArr[i].OwnerName;
                        $scope.contactSelectionModel.EmployerID = $scope.individualContactArr[i].EmployerID;
                        $scope.contactSelectionModel.EmployerName = "";
                        $scope.contactSelectionModel.DisplayName = $scope.contactSelectionModel.ContactName;
                        $scope.contactSelectionModel.CompanyName = "";
                        $scope.contactSelectionModel.CompanyID = 0;
                        $scope.contactSelectionModel.CompanyDeviceObjID = '';
                        $scope.contactSelectionModel.UserName = $scope.contactSelectionModel.DisplayName;
                        $scope.contactSelectionModel.IsChecked = false;
                        $scope.contactSelectionModel.ContactTierName =$scope.individualContactArr[i].ContactTierName;
                        $scope.contactSelectionModel.ContactTierID = $scope.individualContactArr[i].ContactTierID;
                        $scope.contactSelectionModel.ContactSegmentName = $scope.individualContactArr[i].ContactSegmentName;
                        $scope.contactSelectionModel.ContactSegmentID = $scope.individualContactArr[i].ContactSegmentID;
                        if ($scope.isEditModeFlag != 0) {
                            utility.editSelUserList($scope.selCntPar, $scope.contactSelectionModel, selCntPar);
                        }

                        $scope.contactDisplayArr.push($scope.contactSelectionModel);
                        $scope.cntPars.push($scope.contactSelectionModel);
                    }else{
                            //console.log('device obj id to send'+$scope.individualContactArr[i].DeviceObjID);
                            utility.sqlGetAllIndividualContactsRelationships($scope.individualContactArr[i]).then(function(contactResult){
                                //console.log('contact result'+JSON.stringify(contactResult));
                                $scope.contactSelectionModel = utility.contactSelectionMod().uiObject;
                                $scope.contactSelectionModel.ContactName = contactResult[0].FirstName+" "+contactResult[0].LastName;
                                $scope.contactSelectionModel.AttendeeDeviceObjID = contactResult[0].DeviceObjID;
                                $scope.contactSelectionModel.ContactDeviceObjID = contactResult[0].DeviceObjID;
                                $scope.contactSelectionModel.ContactID = contactResult[0].ContactID;
                                $scope.contactSelectionModel.UserID = contactResult[0].ContactID;
                                $scope.contactSelectionModel.ContactTypeID = contactResult[0].ContactTypeID;
                                $scope.contactSelectionModel.ContactOwnerID = contactResult[0].OwnerID;
                                $scope.contactSelectionModel.ContactOwnerName = contactResult[0].OwnerName;
                                $scope.contactSelectionModel.EmployerID = contactResult[0].EmployerID;
                                $scope.contactSelectionModel.EmployerName = contactResult[0].EmployerName;
                                $scope.contactSelectionModel.DisplayName = $scope.contactSelectionModel.ContactName;
                                $scope.contactSelectionModel.CompanyName = contactResult[1].rows.item(0).CompanyName;
                                $scope.contactSelectionModel.CompanyID = contactResult[1].rows.item(0).ContactID;
                                $scope.contactSelectionModel.CompanyDeviceObjID = contactResult[1].rows.item(0).DeviceObjID;
                                $scope.contactSelectionModel.DisplayName += ' ('+$scope.contactSelectionModel.CompanyName+')';
                                $scope.contactSelectionModel.UserName = $scope.contactSelectionModel.DisplayName;
                                $scope.contactSelectionModel.IsChecked = false;
                                $scope.contactSelectionModel.ContactTierName = contactResult[0].ContactTierName;
                                $scope.contactSelectionModel.ContactTierID = contactResult[0].ContactTierID;
                                $scope.contactSelectionModel.ContactSegmentName = contactResult[0].ContactSegmentName;
                                $scope.contactSelectionModel.ContactSegmentID = contactResult[0].ContactSegmentID;
                                if ($scope.isEditModeFlag != 0) {
                                    utility.editSelUserList($scope.selCntPar, $scope.contactSelectionModel, selCntPar);
                                }

                                $scope.contactDisplayArr.push($scope.contactSelectionModel);
                                $scope.cntPars.push($scope.contactSelectionModel);
                                //console.log('contact model is'+JSON.stringify($scope.contactSelectionModel));
                                //console.log('contactDisplayArrObj is'+JSON.stringify($scope.contactDisplayArr));
                              },function(err){
                                alert(err);
                            });
                    }
                }

                for(var i=0;i<$scope.companyContactArr.length;i++){

                    utility.sqlGetAllRepresentativeDetails($scope.companyContactArr[i]).then(function(repResult){
                                for(var k=0; k<repResult[1].rows.length; k++){
                                        $scope.contactRepModel = utility.contactSelectionMod().uiObject;
                                        $scope.contactRepModel.ContactName = repResult[0].CompanyName;
                                        $scope.contactRepModel.AttendeeDeviceObjID = repResult[0].DeviceObjID;
                                        $scope.contactRepModel.ContactDeviceObjID = repResult[0].DeviceObjID;
                                        $scope.contactRepModel.ContactID = repResult[0].ContactID;
                                        $scope.contactRepModel.UserID = $scope.contactRepModel.ContactID;
                                        $scope.contactRepModel.ContactTypeID = repResult[0].ContactTypeID;
                                        $scope.contactRepModel.ContactOwnerID = repResult[0].OwnerID;
                                        $scope.contactRepModel.ContactOwnerName = repResult[0].OwnerName;
                                        $scope.contactRepModel.CompanyName = repResult[0].CompanyName;
                                        $scope.contactRepModel.CompanyID = repResult[0].ContactID;
                                        $scope.contactRepModel.CompanyDeviceObjID = repResult[0].DeviceObjID;


                                        $scope.contactRepModel.RepresentativeName = repResult[1].rows.item(k).FirstName+" "+repResult[1].rows.item(k).LastName;
                                        $scope.contactRepModel.RepresentativeDeviceObjID = repResult[1].rows.item(k).DeviceObjID;
                                        $scope.contactRepModel.RepresentativeID = repResult[1].rows.item(k).ContactID;
                                        $scope.contactRepModel.DisplayName = $scope.contactRepModel.RepresentativeName + ' ('+$scope.contactRepModel.CompanyName+')';
                                        $scope.contactRepModel.UserName = $scope.contactRepModel.DisplayName;
                                        $scope.contactRepModel.IsChecked = false;
                                        $scope.contactRepModel.ContactTierName = repResult[0].ContactTierName;
                                        $scope.contactRepModel.ContactTierID = repResult[0].ContactTierID;
                                        $scope.contactRepModel.ContactSegmentName = repResult[0].ContactSegmentName;
                                        $scope.contactRepModel.ContactSegmentID = repResult[0].ContactSegmentID;
                                        if ($scope.isEditModeFlag != 0) {
                                            utility.editSelUserList($scope.selCntPar, $scope.contactRepModel, selCntPar);
                                        }
                                        $scope.contactDisplayArr.push($scope.contactRepModel);
                                        $scope.cntPars.push($scope.contactRepModel);
                                        //console.log('contact model is'+JSON.stringify($scope.contactRepModel));
                                        //console.log('contactDisplayArrObj is'+JSON.stringify($scope.contactDisplayArr));

                                }

                        },function(err){
                        alert(err);
                    });

                }

                },function(err){
                alert(err);
            });

        }

        ////////////////////////////////////////////////////////// Loading the User Data /////////////////////////////////////////////////////////

        function loadUsersData() {
            $scope.userPars = [];
            $scope.userDealOwner = [];
            authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.OtherAttendeeUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var newObj = result.rows.item(i);
                    newObj.IsChecked = false;
                    newObj.AttendeeDeviceObjID = "0";
                    if ($scope.isEditModeFlag != 0) {
                        utility.editSelUserList($scope.selUsrPar, newObj, selUsrPar);
                        //newObj.IsChecked = utility.editSelUserList($scope.selUsrPar, newObj);;
                    }


                    $scope.userPars.push(newObj);
                }
                //console.log($scope.userPars);
            });
            authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.DealOwnershipUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.userDealOwner.push(result.rows.item(i));
                }
                for (var i = $scope.userDealOwner.length - 1; i >= 0; i--) {
                    if ($scope.userDealOwner[i].UserID == $scope.selUserOwners.activeUser) {
                        $scope.selDealOwner = $scope.userDealOwner[i].UserName;
                    }
                }
            });
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////// Loading Product Family /////////////////////////////////////////////////////////


        function loadProductFamily(){

            //var productFamilyFlag = utility.getMasterDataByKey("loadProductsFlag");
            var productFamilyFlag = true;

            if(productFamilyFlag){
            //utility.setMasterData("loadProductsFlag", true);
            dealService.dealProductFamily().then(function (productFamilyRes) {
                //console.log('product family response is'+JSON.stringify(productFamilyRes));
                     dealService.sqlProductFamilyAdd(productFamilyRes).then(function(repDetailsResult){
                        dealService.sqlProductsAdd(productFamilyRes).then(function(repDetailsResult){

                            dealService.sqlGetAllProductFamily().then(function(result){
                            //console.log("Products family result is"+JSON.stringify(result));
                            for (var i = 0; i < result.rows.length; i++) {
                                dealService.sqlGetAllProducts(result.rows.item(i)).then(function(res){
                                    //console.log("Products result is"+JSON.stringify(res));
                                    var productFamilyTempObj = {};
                                    productFamilyTempObj.ProductFamilyID = res[0].ProductFamilyID;
                                    productFamilyTempObj.Name = res[0].Name;
                                    var productsArr = [];
                                    for(var j=0;j<res[1].rows.length;j++){
                                        var productsObj = {};
                                        productsObj.ProductID = res[1].rows.item(j).ProductID;
                                        productsObj.Name = res[1].rows.item(j).Name;
                                        productsObj.ProductFamilyID = res[1].rows.item(j).ProductFamilyID;
                                        productsObj.ProductFamilyName = res[1].rows.item(j).ProductFamilyName;
                                        productsArr.push(productsObj);
                                    }
                                    productFamilyTempObj.Products = productsArr;
                                    $scope.productFamilies.push(productFamilyTempObj);
                                    },function(err){
                                       alert(err);
                                    });
                                }
                            },function(err){
                                alert(err);
                            });

                        },function(err){
                         alert(err);
                       });

                    },function(err){
                    alert(err);
                  });

                //$scope.productFamilies = res;
            },function (err) {
                //console.log('product family error'+err);
            });

            }else{
                dealService.sqlGetAllProductFamily().then(function(result){
                            //console.log("Products family result is"+JSON.stringify(result));
                            for (var i = 0; i < result.rows.length; i++) {
                                dealService.sqlGetAllProducts(result.rows.item(i)).then(function(res){
                                    //console.log("Products result is"+JSON.stringify(res));
                                    var productFamilyTempObj = {};
                                    productFamilyTempObj.ProductFamilyID = res[0].ProductFamilyID;
                                    productFamilyTempObj.Name = res[0].Name;
                                    var productsArr = [];
                                    for(var j=0;j<res[1].rows.length;j++){
                                        var productsObj = {};
                                        productsObj.ProductID = res[1].rows.item(j).ProductID;
                                        productsObj.Name = res[1].rows.item(j).Name;
                                        productsObj.ProductFamilyID = res[1].rows.item(j).ProductFamilyID;
                                        productsObj.ProductFamilyName = res[1].rows.item(j).ProductFamilyName;
                                        productsArr.push(productsObj);
                                    }
                                    productFamilyTempObj.Products = productsArr;
                                    $scope.productFamilies.push(productFamilyTempObj);
                                    },function(err){
                                       alert(err);
                                    });
                                }
                },function(err){
                    alert(err);
                });
            }
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Initial Call ////////////////////////////////////////////////////////////////

        init();

        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////// Close Deal Functionality //////////////////////////////////////////////////////

        $scope.closeAddDeal = function () {
            $state.go('tab.deal');
        }


        ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        //////////////////////////////////////////////////////// Add Deal Functionality //////////////////////////////////////////////////


        $scope.addDeal = function () {

            if ($rootScope.isNetworkAvailable == false) {
                            $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                               .then(function () {
                            });
                            return;
            }
            productService.getAttachments(0).then(function(){

            var valDealFlag = true;

            if($scope.dealModel.ContactDisplayName == '' && $scope.dealModel.CompanyName == ''){
                $cordovaDialogs.alert(ALERT_MESSAGE.SELECT_COMPANY, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                    .then(function() {
                    });
                return false;
            }
            valDealFlag = utility.commonValidation($scope.dealModel.ProductName, valDealFlag, 'Product Name');
            if (!valDealFlag) return false;
            valDealFlag = utility.commonValidation($scope.dealModel.DealStageName, valDealFlag, 'Deal Stage');
            if (!valDealFlag) return false;
            valDealFlag = utility.commonValidation($scope.dealModel.DealSourceName, valDealFlag, 'Deal Source');
            if (!valDealFlag) return false;
            valDealFlag = utility.commonValidation($scope.selDealOwner, valDealFlag, 'Deal Owner');
            if (!valDealFlag) return false;

            $scope.dealModel.ExpectedDealSize = $scope.user.expectedDealSize;
            $scope.dealModel.ExpectedDealSizeCurrencyID = $scope.user.dealSizeCurrencyObject.CurrencyID;
            $scope.dealModel.ExpectedDealSizeCurrencyConvRate = $scope.user.dealSizeCurrencyObject.ConversionValue;
            $scope.dealModel.ExpectedDealSizeConverted = $scope.user.expectedDealSizeConverted;
            $scope.dealModel.ExpectedDealRevenue = $scope.user.expectedDealRevenue;
            $scope.dealModel.ExpectedDealRevenueCurrencyID = $scope.user.dealRevenueCurrencyObject.CurrencyID;
            $scope.dealModel.ExpectedDealRevenueCurrencyConvRate = $scope.user.dealRevenueCurrencyObject.ConversionValue;
            $scope.dealModel.ExpectedDealRevenueConverted = $scope.user.expectedDealRevenueConverted;
            $scope.dealModel.ExpectedDealCloseDate = utility.getDateInServerFormat($scope.SelFinalDate).toString();
            $scope.dealModel.OwnerID = $scope.selUserOwners.activeUser;
            $scope.dealModel.OwnerName = $scope.selDealOwner;

            selectPar($scope.selCntPar, $scope.dealModel.DealAttendees, GENERAL_CONFIG.MODULES.Deal, 'CP', true);
            selectPar($scope.selUsrPar, $scope.dealModel.DealAttendees, GENERAL_CONFIG.MODULES.Deal, 'UP', false);

            var dateStringInUTC = utility.getDateStringInUTC(new Date());
            if ($scope.isEditModeFlag == 0) {
                $scope.dealModel.CreatorID = lgnUser.UserID;
                $scope.dealModel.CreatedOn = dateStringInUTC;
                $scope.dealModel.CreatorName = lgnUser.UserName;
            }

            $scope.dealModel.ModifiedBy = lgnUser.UserID;
            $scope.dealModel.ModifiedOn = dateStringInUTC;

            if ($scope.user.dealaddnotes != '') {
                var noteObjModel = noteService.noteMod().noteModel;
                noteObjModel.EntityID = $scope.dealModel.DealID;
                noteObjModel.ModuleID = GENERAL_CONFIG.MODULES.Deal;
                noteObjModel.ParentDeviceObjID = $scope.dealModel.DeviceObjID;
                noteObjModel.Description = $scope.user.dealaddnotes;
                noteObjModel.CreatorID = lgnUser.UserID;
                noteObjModel.CreatorName = lgnUser.UserName;
                noteObjModel.CreatedOn = utility.getDateStringInUTC(new Date());
                noteObjModel.CreatedAt = $scope.dealModel.CreatedAt;
                $scope.dealModel.Notes.push(noteObjModel);
                //console.log('Notes String'+JSON.stringify($scope.dealModel.Notes));
            }

            if($scope.isEditModeFlag == 0){
                if($scope.dealModel.ContactID == 0){
                    $cordovaDialogs.alert(ALERT_MESSAGE.CONTACT_NOT_SYNC, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                               .then(function () {
                    });
                }else{
                    dealService.addDealToSql($scope.dealModel).then(function(result){
                        dealService.dealAdd($scope.dealModel).then(function(res){
                            //console.log('Result is:'+JSON.stringify(res));
                            var dealStageModelID = utility.dealStageModelIDCheck($scope.dealModel.DealStageID);

                            if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close){
                                $scope.dealCloseModel.DealID = res[0].Data.DealID;
                                dealService.dealCloseToSql($scope.dealCloseModel).then(function(result){
                                        dealService.dealCloseLost($scope.dealCloseModel).then(function(closeRes){
                                            if(!(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == '')){
                                                dealService.sqlUpdateContactCustomerID($scope.user.actualDealCustomerID, $scope.dealModel.ContactDeviceObjID).then(function(customerRes){
                                                    //console.log("Deal Close Result is"+JSON.stringify(res));
                                                },function(err){
                                                  alert(err);
                                                });
                                            }
                                            //console.log("Deal Close Result is"+JSON.stringify(res));
                                        },function(err){
                                            alert(err);
                                        });

                                },function(err){
                                    alert(err);
                                });
                            }else if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost){
                                    $scope.dealLostModel.DealID = res[0].Data.DealID;
                                    $scope.dealLostModel.Note.EntityID = res[0].Data.DealID;
                                    dealService.dealLostToSql($scope.dealLostModel).then(function(result){
                                            dealService.dealCloseLost($scope.dealLostModel).then(function(notesRes){
                                                //console.log("Deal Lost Result is"+JSON.stringify(res));
                                                dealService.dealLostUpdateNotesToSql(notesRes).then(function(result){

                                                   },function(err){
                                                        alert(err);
                                                   });
                                            },function(err){
                                                alert(err);
                                            });
                                    },function(err){
                                        alert(err);
                                    });
                            }

                            dealService.sqlDealSync(res[0].Data).then(function (result) {
                                 contactService.uploadAttachmentsToServer($scope.dealModel.DeviceObjID,null,GENERAL_CONFIG.MODULES.Deal);
                                 $state.go('tab.deal');
                            });
                            },function(err){
                                alert(err);
                            });
                    },function(err){
                        alert(err);
                    });
                }
            }else{
                dealService.updateDealToSql($scope.dealModel).then(function(result){
                    dealService.dealAdd($scope.dealModel).then(function(res){
                        //console.log('Result is:'+JSON.stringify(res));
                        var dealStageModelID = utility.dealStageModelIDCheck($scope.dealModel.DealStageID);

                            if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close){
                                $scope.dealCloseModel.DealID = res[0].Data.DealID;
                                dealService.dealCloseToSql($scope.dealCloseModel).then(function(result){
                                        dealService.dealCloseLost($scope.dealCloseModel).then(function(closeRes){
                                            if(!(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == '')){
                                                dealService.sqlUpdateContactCustomerID($scope.user.actualDealCustomerID, $scope.dealModel.ContactDeviceObjID).then(function(customerRes){
                                                    //console.log("Deal Close Result is"+JSON.stringify(res));
                                                },function(err){
                                                  alert(err);
                                                });
                                            }
                                            //console.log("Deal Close Result is"+JSON.stringify(res));
                                        },function(err){
                                            alert(err);
                                        });

                                },function(err){
                                    alert(err);
                                });
                            }else if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost){
                                    $scope.dealLostModel.DealID = res[0].Data.DealID;
                                    $scope.dealLostModel.Note.EntityID = res[0].Data.DealID;
                                    dealService.dealLostToSql($scope.dealLostModel).then(function(result){
                                            dealService.dealCloseLost($scope.dealLostModel).then(function(notesRes){
                                                //console.log("Deal Lost Result is"+JSON.stringify(res));
                                                dealService.dealLostUpdateNotesToSql(notesRes).then(function(result){

                                                   },function(err){
                                                        alert(err);
                                                   });
                                            },function(err){
                                                alert(err);
                                            });
                                    },function(err){
                                        alert(err);
                                    });
                            }


                        dealService.sqlDealSync(res[0].Data).then(function (result) {
                             contactService.uploadAttachmentsToServer($scope.dealModel.DeviceObjID,null,GENERAL_CONFIG.MODULES.Deal);
                             $state.go('tab.deal');
                        });
                    },function(err){
                        alert(err);
                    });
                },function(err){
                    alert(err);
                });
            }
          });
        }

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////// Select Participant Function ///////////////////////////////////////////////////////////////////

        function selectPar(selLst, tarLst, parType, type, isContact) {
            angular.forEach(selLst, function (obj, key) {
                var conUsrID = obj.EntityAttendeeID;
                var devParId = utility.generateUUID();
                if (typeof conUsrID == 'undefined' || conUsrID == null) {
                    conUsrID = 0;
                }
                if ($scope.isEditModeFlag != 0) {
                    if (conUsrID != 0)
                        devParId = obj.DeviceObjID;
                }
                if(obj.UserID == null || obj.UserID == 'null'){
                    tarLst.push(
                    {
                        EntityAttendeeID: conUsrID,//obj.ActivityAttendeeID,//didn't get this value right now..hardcoded 0
                        AttendeeID: null,
                        UserName: obj.UserName,
                        Type: type,
                        ParentDeviceObjType: parType,
                        DeviceObjID: devParId,
                        IsContact: isContact,
                        AttendeeDeviceObjID: obj.AttendeeDeviceObjID
                    });
                }else{
                    tarLst.push(
                    {
                        EntityAttendeeID: conUsrID,//obj.ActivityAttendeeID,//didn't get this value right now..hardcoded 0
                        AttendeeID: obj.UserID,
                        UserName: obj.UserName,
                        Type: type,
                        ParentDeviceObjType: parType,
                        DeviceObjID: devParId,
                        IsContact: isContact,
                        AttendeeDeviceObjID: obj.AttendeeDeviceObjID
                    });
                }
            });
        }

        /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Expected Deal Size Conversion ///////////////////////////////////////////////////////

        $scope.expectedDealSizeConversion = function(){
            $scope.user.expectedDealSizeConverted = ($scope.user.expectedDealSize * $scope.user.dealSizeCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Expected Deal Revenue Conversion ///////////////////////////////////////////////////////

        $scope.expectedDealRevenueConversion = function(){
            $scope.user.expectedDealRevenueConverted = ($scope.user.expectedDealRevenue * $scope.user.dealRevenueCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $scope.removeZeroFromExpectedValues = function(){
            if($scope.user.expectedDealSize == 0)
                $scope.user.expectedDealSize = '';
            if($scope.user.expectedDealRevenue == 0)
                $scope.user.expectedDealRevenue = '';
        }

        /////////////////////////////////////////////////////////////// Is Confidential Toggle Change /////////////////////////////////////////////////

		$scope.isConfidentialToggleChange = function () {
            if ($scope.isConfidentialValue == false) {
                $scope.isConfidentialValue = true;
                $scope.dealModel.IsConfidential = true;
            } else{
                $scope.isConfidentialValue = false;
				$scope.dealModel.IsConfidential = false;
            }
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $scope.user.stageChange = function(stageChosen) {
           //alert(stageChosen);
        }

        ////////////////////////////////// Modal for user list start//////////////////////////////////////////
        // $scope.cntPars = [
        //    { DealAttendeeID: 0, UserID: 1, Type: 'CP', UserName: "int John", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 1, Type: 'CP', UserName: "int James", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 1, Type: 'CP', UserName: "int Maria", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 1, Type: 'CP', UserName: "int David", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 1, Type: 'CP', UserName: "Reese", IsChecked: false }
        // ];

        // $scope.userPars = [
        //    { DealAttendeeID: 0, UserID: 1, Type: 'UP', AccessCategoryID: '', UserName: "John", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 2, Type: 'UP', AccessCategoryID: '', UserName: "James", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 3, Type: 'UP', AccessCategoryID: '', UserName: "Maria", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 4, Type: 'UP', AccessCategoryID: '', UserName: "David", IsChecked: false },
        //    { DealAttendeeID: 0, UserID: 5, Type: 'UP', AccessCategoryID: '', UserName: "Reese", IsChecked: false }
        // ];

        $scope.modelSelected = '';
        $ionicModal.fromTemplateUrl('app/views/common/userList.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalUser = modal;
        });

        $scope.openUserList = function (val) {
            $scope.modelSelected = val;
            if ($scope.modelSelected == 'DO') {
                $scope.selUserOwners.tempUser = $scope.selUserOwners.activeUser;
            }
            else if ($scope.modelSelected == 'CN') {
                $scope.selContacts.activeContact = $scope.selContacts.tempContact;
            }
            else if ($scope.modelSelected == 'DS') {
                $scope.selDealSource.activeDealSource = $scope.selDealSource.tempDealSource;
            }
            $scope.modalUser.show();
        };
        $scope.closeUserList = function () {
            if ($scope.modelSelected == 'C') {
                utility.updateUserList($scope.cntPars, $scope.selCntPar);
            }
            else if ($scope.modelSelected == 'I') {
                utility.updateUserList($scope.userPars, $scope.selUsrPar);
            }
            $scope.modalUser.hide();
        };

        $scope.CheckRepresentativeDeviceObjID = '';
        $scope.radioLink = function (devId) {
            $scope.CheckRepresentativeDeviceObjID = devId;
        }

        $scope.actionUserList = function () {
            //var userLst = $scope.userList;
            if ($scope.modelSelected == 'C') {
                utility.selectedUserList($scope.cntPars, $scope.selCntPar);
            }
            else if ($scope.modelSelected == 'I') {
                utility.selectedUserList($scope.userPars, $scope.selUsrPar);
            }
            else if ($scope.modelSelected == 'DO') {
                $scope.selUserOwners.activeUser = $scope.selUserOwners.tempUser;
                for (var i = $scope.userDealOwner.length - 1; i >= 0; i--) {
                    if ($scope.userDealOwner[i].UserID == $scope.selUserOwners.activeUser) {
                        $scope.selDealOwner = $scope.userDealOwner[i].UserName;
                    }
                }
            }
            else if ($scope.modelSelected == 'DS') {
                $scope.selDealSource.tempDealSource = $scope.selDealSource.activeDealSource;
                for (var i=0; i < $scope.dealSources.length; i++) {
                    if ($scope.dealSources[i].DealSourceID == $scope.selDealSource.activeDealSource) {
                        $scope.dealModel.DealSourceName = $scope.dealSources[i].Name;
                        $scope.dealModel.DealSourceID = $scope.dealSources[i].DealSourceID;
                    }
                }
            }
            else if ($scope.modelSelected == 'CN') {
                $scope.selContacts.tempContact = $scope.selContacts.activeContact;
                for(var i=0;i<$scope.contactDisplayArr.length;i++){
                    if($scope.contactDisplayArr[i].ContactDeviceObjID == $scope.selContacts.activeContact){
                        $scope.dealModel.ContactName = $scope.contactDisplayArr[i].ContactName;
                        $scope.dealModel.CompanyName = $scope.contactDisplayArr[i].CompanyName;
                        $scope.dealModel.ContactID = $scope.contactDisplayArr[i].ContactID;
                        $scope.dealModel.ContactTypeID = $scope.contactDisplayArr[i].ContactTypeID;
                        $scope.dealModel.ContactDeviceObjID = $scope.contactDisplayArr[i].ContactDeviceObjID;
                        $scope.dealModel.RepresentativeDeviceObjID = $scope.contactDisplayArr[i].RepresentativeDeviceObjID;
                        $scope.dealModel.ContactTierName = $scope.contactDisplayArr[i].ContactTierName;
                        $scope.dealModel.ContactTierID = utility.CheckModelNull($scope.contactDisplayArr[i].ContactTierID);
                        $scope.dealModel.ContactSegmentName = $scope.contactDisplayArr[i].ContactSegmentName;
                        $scope.dealModel.ContactSegmentID = utility.CheckModelNull($scope.contactDisplayArr[i].ContactSegmentID);
                        if ($scope.dealModel.ContactTypeID == 1) {
                            if($scope.contactDisplayArr[i].EmployerID == "null"){
                                $scope.dealModel.EmployerID = null;
                            }else{
                                $scope.dealModel.EmployerID = $scope.contactDisplayArr[i].EmployerID;
                            }
                            $scope.dealModel.EmployerName = $scope.contactDisplayArr[i].EmployerName;
                            $scope.dealModel.ContactDisplayName = $scope.contactDisplayArr[i].ContactName;
                        }
                        else{
                            if ($scope.CheckRepresentativeDeviceObjID == $scope.contactDisplayArr[i].RepresentativeDeviceObjID) {
                                if($scope.contactDisplayArr[i].RepresentativeID == "null"){
                                    $scope.dealModel.RepresentativeID = null;
                                }else{
                                    $scope.dealModel.RepresentativeID = $scope.contactDisplayArr[i].RepresentativeID;
                                }
                              $scope.dealModel.RepresentativeName = $scope.contactDisplayArr[i].RepresentativeName;
                              $scope.dealModel.ContactDisplayName = $scope.contactDisplayArr[i].RepresentativeName;
                            }
                        }
                    }
                }
                //$scope.selContacts.activeContact = "";
            }
            $scope.modalUser.hide();
        };

        ///////////////////////////////////////////////////////////////// user list END///////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Modal for Product Family /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealProducts.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalProducts = modal;
        });

        $scope.openProductList = function (val) {
            $scope.modelSelected = val;
            $scope.selProduct.activeProduct = $scope.selProduct.tempProduct;
            $scope.modalProducts.show();

        };
        $scope.closeProductList = function () {
            $scope.modalProducts.hide();
        };

        $scope.actionProductList = function () {
            $scope.selProduct.tempProduct = $scope.selProduct.activeProduct;
            for(var i=0;i<$scope.productFamilies.length;i++){
                for(var j=0;j<$scope.productFamilies[i].Products.length;j++){
                    if($scope.selProduct.activeProduct == $scope.productFamilies[i].Products[j].ProductID){
                        if($scope.user.docChecklistDisabled)
                        $scope.user.docChecklistDisabled = false;
                        $scope.user.selectedProdType = '';
                        $scope.user.selectedProdScheme = '';
                        $scope.dealModel.ProductName = $scope.productFamilies[i].Products[j].Name;
                        $scope.dealModel.ProductFamilyName = $scope.productFamilies[i].Products[j].ProductFamilyName;
                        $scope.dealModel.ProductFamilyID = $scope.productFamilies[i].Products[j].ProductFamilyID;
                        $scope.dealModel.ProductID = $scope.productFamilies[i].Products[j].ProductID;
                        $scope.prodTypeArr = [];
                        $scope.prodSchemeArr = [];

                        for(var k=0;k<$scope.prodType.length;k++){
                            if($scope.prodType[k].ProductID == $scope.dealModel.ProductID){
                                var prodTypeObj = {};
                                prodTypeObj.Name = $scope.prodType[k].Name;
                                prodTypeObj.ProductTypeID = $scope.prodType[k].ProductTypeID;
                                $scope.prodTypeArr.push(prodTypeObj);
                            }
                        }

                        for(var k=0;k<$scope.prodSchemes.length;k++){
                            if($scope.prodSchemes[k].ProductID == $scope.dealModel.ProductID){
                                var prodSchemeObj = {};
                                prodSchemeObj.Name = $scope.prodSchemes[k].Name;
                                prodSchemeObj.ProductSchemeID = $scope.prodSchemes[k].ProductSchemeID;
                                $scope.prodSchemeArr.push(prodSchemeObj);
                            }
                        }
                        $scope.documentChecklistSearch();
                    }
                }
            }
            $scope.modalProducts.hide();
            loadSubject();
        };




        ///////////////////////////////////////////////////////////// Product Family END ///////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Modal for Deal Stages /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStages.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStages = modal;
        });

        $scope.openDealStagesList = function (val) {
            $scope.modelSelected = val;
            $scope.selDealStages.activeDealStage = $scope.selDealStages.tempDealStage;
            $scope.modalDealStages.show();
        };
        $scope.closeDealStagesList = function () {
            $scope.modalDealStages.hide();
        };

        $scope.actionDealStagesList = function () {
            $scope.selDealStages.tempDealStage = $scope.selDealStages.activeDealStage;
            var dealStageModelID = utility.dealStageModelIDCheck($scope.selDealStages.activeDealStage);
            for(var i=0;i<$scope.dealStages.length;i++){
                    if($scope.selDealStages.activeDealStage == $scope.dealStages[i].DealStageID){
                        $scope.dealModel.DealStageID = $scope.dealStages[i].DealStageID;
                        $scope.dealModel.DealStageName = $scope.dealStages[i].Name;
                        //console.log('Deal Stage ID is'+$scope.dealModel.DealStageID);
                    }
            }
            if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close){
                    $scope.openDealStagesClose('DSC');

            }else if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost){
                    $scope.openDealStagesLost('DSL');
            }
            $scope.modalDealStages.hide();
        };

         /////////////////////////////////////////////////////////// Modal for Deal Stages Close /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStagesClose.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesClose = modal;
        });

        $scope.openDealStagesClose = function (val) {
            $scope.modelSelected = val;

            $scope.user.actualDealSize = $scope.dealModel.ActualDealSize;
            $scope.user.actualDealSizeConverted = $scope.dealModel.ActualDealSizeConverted;
            $scope.user.dealSizeCurrencyObject = $scope.currencies[0];

            $scope.user.actualDealRevenue = $scope.dealModel.ActualDealRevenue;
            $scope.user.actualDealRevenueConverted = $scope.dealModel.ActualDealRevenueConverted;
            $scope.user.dealRevenueCurrencyObject = $scope.currencies[0];

            if($scope.dealModel.ContactDeviceObjID != ""){
                dealService.sqlGetContactCustomerID($scope.dealModel.ContactDeviceObjID).then(function(result){
                    for (var i = 0; i < result.rows.length; i++) {
                        if(result.rows.item(i).CustomerID == '0'){
                            $scope.user.actualDealCustomerID == '';
                        }else{
                            $scope.user.actualDealCustomerID = result.rows.item(i).CustomerID;
                        }
                    }
                },function(err){
                    alert(err);
                });
            }

            $scope.modalDealStagesClose.show();
        };
        $scope.closeDealStagesClose = function () {
            $scope.selDealStages.tempDealStage = "";
            $scope.selDealStages.activeDealStage = "";
            $scope.dealModel.DealStageID = 0;
            $scope.dealModel.DealStageName = "";
            $scope.modalDealStagesClose.hide();
        };

        $scope.actionDealStagesClose = function () {
            if(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == ''){
                $cordovaDialogs.confirm('Are you sure you do not want to enter client ID ?', 'SalesARM', ['Yes','No'])
                .then(function(buttonIndex) {
                    if(buttonIndex == 1){
                        $scope.closeDealStageConfirm();
                    }
                });
            }else{
                $scope.closeDealStageConfirm();
            }
        };

        $scope.closeDealStageConfirm = function(){
            $scope.dealCloseModel = dealService.dealCloseLostMod().uiObject;
            $scope.dealCloseModel.DeviceObjID = $scope.dealModel.DeviceObjID;
            $scope.dealCloseModel.DealID = $scope.dealModel.DealID;
            $scope.dealCloseModel.ActualDealCloseDate = utility.getDateInServerFormatFromToday(new Date()).toString();
            $scope.dealCloseModel.ActualDealRevenue = $scope.user.actualDealRevenue;
            $scope.dealCloseModel.ActualDealRevenueConverted = $scope.user.actualDealRevenueConverted;
            $scope.dealCloseModel.ActualDealRevenueCurrencyConvRate = $scope.user.dealRevenueCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealRevenueCurrencyID = $scope.user.dealRevenueCurrencyObject.CurrencyID;
            $scope.dealCloseModel.ActualDealSize = $scope.user.actualDealSize;
            $scope.dealCloseModel.ActualDealSizeConverted = $scope.user.actualDealSizeConverted;
            $scope.dealCloseModel.ActualDealSizeCurrencyConvRate = $scope.user.dealSizeCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealSizeCurrencyID = $scope.user.dealSizeCurrencyObject.CurrencyID;
            $scope.dealCloseModel.DealStageID = $scope.dealModel.DealStageID;
            $scope.dealCloseModel.DealStageName = $scope.dealModel.DealStageName;
            $scope.dealCloseModel.ModifiedBy = lgnUser.UserID;
            var dateStringInUTC = utility.getDateStringInUTC(new Date());
            $scope.dealCloseModel.ModifiedOn = dateStringInUTC;
            if(!(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == '')){
                $scope.dealCloseModel.CustomerID = $scope.user.actualDealCustomerID;
            }
            $scope.dealStageModelID = utility.dealStageModelIDCheck($scope.dealModel.DealStageID);

            $scope.modalDealStagesClose.hide();

        };

        /////////////////////////////////////////////////////////// Expected Deal Size Conversion ///////////////////////////////////////////////////////

        $scope.actualDealSizeConversion = function(){
            $scope.user.actualDealSizeConverted = ($scope.user.actualDealSize * $scope.user.dealSizeCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Expected Deal Revenue Conversion ///////////////////////////////////////////////////////

        $scope.actualDealRevenueConversion = function(){
            $scope.user.actualDealRevenueConverted = ($scope.user.actualDealRevenue * $scope.user.dealRevenueCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $scope.removeZero = function(){
            if($scope.user.actualDealSize == 0)
                $scope.user.actualDealSize = '';
            if($scope.user.actualDealRevenue == 0)
                $scope.user.actualDealRevenue = '';
        }

         /////////////////////////////////////////////////////////// Modal for Deal Stages Lost /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStagesLost.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesLost = modal;
        });

        $scope.openDealStagesLost = function (val) {
            $scope.modelSelected = val;
            $scope.modalDealStagesLost.show();
        };
        $scope.closeDealStagesLost = function () {
            $scope.selDealStages.tempDealStage = "";
            $scope.selDealStages.activeDealStage = "";
            $scope.dealModel.DealStageID = 0;
            $scope.dealModel.DealStageName = "";
            $scope.modalDealStagesLost.hide();
        };

        $scope.actionDealStagesLost = function () {
            $scope.dealLostModel = dealService.dealCloseLostMod().uiObject;
            if ($scope.user.notes != '') {
                $scope.dealLostModel.DeviceObjID = $scope.dealModel.DeviceObjID;
                $scope.dealLostModel.DealID = $scope.dealModel.DealID;
                $scope.dealLostModel.DealStageID = $scope.dealModel.DealStageID;
                $scope.dealLostModel.DealStageName = $scope.dealModel.DealStageName;
                $scope.dealLostModel.ModifiedBy = lgnUser.UserID;
                var dateStringInUTC = utility.getDateStringInUTC(new Date());
                $scope.dealLostModel.ModifiedOn = dateStringInUTC;

                var noteObjModel = noteService.noteMod().noteModel;
                noteObjModel.EntityID = $scope.dealModel.DealID;
                noteObjModel.ModuleID = GENERAL_CONFIG.MODULES.Deal;
                noteObjModel.ParentDeviceObjID = $scope.dealModel.DeviceObjID;
                noteObjModel.Description = $scope.user.notes;
                noteObjModel.CreatorID = lgnUser.UserID;
                noteObjModel.CreatorName = lgnUser.UserName;
                noteObjModel.CreatedOn = utility.getDateStringInUTC(new Date());
                noteObjModel.CreatedAt = $scope.dealModel.CreatedAt;
                $scope.dealModel.Notes.push(noteObjModel);

                $scope.modalDealStagesLost.hide();
            }
        };




        ///////////////////////////////////////////////////////////// Deal Stages END ///////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Modal for Deal Document Checklist /////////////////////////////////////////////////////////////


         $ionicModal.fromTemplateUrl('app/views/deal/dealDocumentChecklist.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealDocChecklist = modal;
        });

        $scope.openDealDocCheckList = function (val) {
            $scope.modelSelected = val;
            $scope.documentChecklistSearch();
            $scope.modalDealDocChecklist.show();
        };
        $scope.closeDealDocCheckList = function () {
            $scope.modalDealDocChecklist.hide();
        };

        $scope.actionDealDocCheckList = function () {
            $scope.modalDealDocChecklist.hide();
        };

        ///////////////////////////////////////////////////////////// Deal Document Checklist END ///////////////////////////////////////////////////////////////


        /////////////////////////////////////////////////////// Modal filter for additional fields ////////////////////////////////////////////////////

        function loadFields() {
            $scope.fields = [];
            for (var i = 0; i < $scope.fieldSet.length; i++) {
                $scope.dealModel.Fields.push({
                    EntityID: $scope.dealModel.DealID,
                    ModuleID: GENERAL_CONFIG.MODULES.Deal,
                    ParentDeviceObjID: $scope.dealModel.DeviceObjID,
                    FieldLabel: $scope.fieldSet[i].FieldLabel,
                    FieldName: $scope.fieldSet[i].FieldName,
                    FieldValue: '',
                    FieldID: $scope.fieldSet[i].FieldID,
                    IsConfidential: $scope.fieldSet[i].IsConfidential,
                    IsMandatory: $scope.fieldSet[i].IsMandatory,
                    IsVisible: $scope.fieldSet[i].IsVisible
                });
            }

            angular.copy($scope.dealModel.Fields, $scope.fields);
        }

        $ionicModal.fromTemplateUrl('app/views/common/fields.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAddDet = modal;

        });

        $scope.openAddDetails = function () {
            $scope.modalAddDet.show();
        };

        $scope.closeAddDetails = function () {
            // utility.updateFieldList($scope.fields, $scope.selFields);
            utility.updateFldArrValues($scope.dealModel.Fields, $scope.fields);
            $scope.modalAddDet.hide();
        };

        //save the field data
        $scope.actionField = function () {
            var validationFlag = true;

            validationFlag = utility.commonValidationDynamic($scope.fields);
            if (!validationFlag) {
                return false;
            }
            utility.updateFldArrValues($scope.fields, $scope.dealModel.Fields);
            $scope.modalAddDet.hide();
        };

        //////////////////////////////////////////////////////////////////////////////////////
        //=====================Attachment Document code Start By NiTiN========================
          $scope.attachment = {docType : ""}; $scope.attachType = false;
          $scope.dealAttachments = [];
          $scope.docTypeData = [{"ID":1, "typeName":"Passport"},{"ID":2, "typeName":"Licences"},{"ID":3, "typeName":"Nationcard"},{"ID":4, "typeName":"Passbook"}];
          $ionicModal.fromTemplateUrl('app/views/common/attachment.html', {
              scope: $scope,
              animation: 'slide-in-left'
          }).then(function (modal) {
              $scope.modalAttachment = modal;
          });

          $scope.openAttachment = function () {
             $scope.attachmentModule = "Deal";
             $scope.attachmentsLength = 1;
             //angular.copy($scope.dealModel.Attachments, $scope.dealAttachments);
             angular.forEach($scope.dealModel.Attachments, function (imgObj) {
                    $scope.downloadImagesFromServer(imgObj);
                });
            if($scope.dealModel.Attachments.length==0)
                $scope.modalAttachment.show();
          };
          $scope.closeAttachment = function () {
              for(var i = 0; i < $scope.dealAttachments.length; i++) {
                  var obj = $scope.dealAttachments[i];
                  if(!obj.IsChecked){
                        var imageName = obj.FileName+obj.Extension;
                        $scope.removeFile(imageName);
                        $scope.dealAttachments.splice(i, 1);
                  }
              }
              $scope.modalAttachment.hide();
          };
          $scope.saveAttachment = function () {
                $scope.dealModel.Attachments = [];
                for(var i = 0; i < $scope.dealAttachments.length; i++) {
                    var obj = $scope.dealAttachments[i];
                    if(!obj.IsChecked){
                          obj.IsChecked = true;
                          //utility.sqlAttachInsertData(obj);
                    }
                    $scope.dealModel.Attachments.push(obj);
                }
                $scope.modalAttachment.hide();
          };
          $scope.removeFile = function(imgFileEntry) {
                window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem){
                    fileSystem.getDirectory('dealImages', { create: false, exclusive: false }, function (dirEntry) {
                        dirEntry.getFile(imgFileEntry, {create:false}, function(fileEntry){
                            fileEntry.remove(function(file){
                                ////console.log("File removed!");
                            },function(){
                                //console.log("error deleting the file " + error.code);
                                });
                        },function(){
                            //console.log("file does not exist");
                        });
                    });
                    },function(evt){
                        //console.log(evt.target.error.code);
                });
          }
          //========================Attachment Document code End=================================
          /////////////////////////////////////camera////////////////////////////////////////////
           // Take picture from camera
          $scope.takePicture = function() {
              var options = {
                  destinationType : Camera.DestinationType.FILE_URI,
                  sourceType : Camera.PictureSourceType.CAMERA, // Camera.PictureSourceType.PHOTOLIBRARY
                  allowEdit : false,
                  encodingType: Camera.EncodingType.JPEG,
                  popoverOptions: CameraPopoverOptions,
              };
              $cordovaCamera.getPicture(options).then(function(imageData) {
                    $scope.saveImageLocally(imageData);
              }, function(err) {
                  //console.log(err);
              });
          }
          // Take picture from gallery
          $scope.takeGalleryPicture = function() {
              var options = {
                  quality: 50,
                  targetWidth: 500,
                  targetHeight: 500,
                  destinationType : Camera.DestinationType.FILE_URI,
                  sourceType : Camera.PictureSourceType.PHOTOLIBRARY, // Camera.PictureSourceType.CAMERA
                  allowEdit : false,
                  encodingType: Camera.EncodingType.JPEG,
                  popoverOptions: CameraPopoverOptions,
              };
              $cordovaCamera.getPicture(options).then(function(imageData) {
                    $scope.saveImageLocally(imageData);
              }, function(err) {
                  //console.log(err);
              });
          }
          $scope.getImagePath = function(item) {
             var imgPath = cordova.file.cacheDirectory + "dealImages/"+ item.FileName + item.Extension;
             return imgPath;
          };
          $scope.removePicture = function (d) {
              var removeId = d.DeviceObjID;
              for(var i = 0; i < $scope.dealAttachments.length; i++) {
                  var obj = $scope.dealAttachments[i];
                  if(removeId == obj.DeviceObjID) {
                      var imageName = obj.FileName+obj.Extension;
                      $scope.removeFile(imageName);
                      $scope.dealAttachments.splice(i, 1);
                  }
              }
          }
          // Show image in full width on popup over
          $scope.showImage = function (d) {
              $ionicModal.fromTemplateUrl('app/views/common/image-popover.html', function ($ionicModal) {
                  $scope.imageModal = $ionicModal;
                  $scope.imageSrc = $scope.getImagePath(d);
                  $scope.imageModal.show();
              }, {
                  // Use our scope for the scope of the modal to keep it simple
                  scope: $scope,
                  controller: 'contactController',
                  // The animation we want to use for the modal entrance
                  animation: 'slide-in-up'
              });
          }
         $scope.closeImgModal = function() {
           $scope.imageModal.remove();
         };

         // File save on our local folder storage
         ////console.log(FileTransfer);
         $scope.saveImageLocally = function(imageData) {
              var docTypeName = "";
              for(var i = 0; i < $scope.docTypeData.length; i++) {
                   if($scope.docTypeData[i].ID == $scope.attachment.docType){
                       docTypeName = $scope.docTypeData[i].typeName;
                   }
              }
              onImageSuccess(imageData);
              function onImageSuccess(fileURI) {
                  createFileEntry(fileURI);
              }
              function createFileEntry(fileURI) {
                  window.resolveLocalFileSystemURL(fileURI, copyFile, fail);
              }
              function copyFile(fileEntry) {
                  var name = fileEntry.fullPath.substr(fileEntry.fullPath.lastIndexOf('/') + 1);
                  var newName = makeid() + name;
                  window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem2) {
                      fileSystem2.getDirectory('dealImages', { create: true, exclusive: false }, function (dirEntry) {
                          fileEntry.copyTo(dirEntry,newName,onCopySuccess,fail);
                      });
                  },fail);
              }
              function onCopySuccess(entry) {
                  $scope.$apply(function () {
                        var attachCategoryArray = utility.getMultLangMasData(MASTER_TABLE.AtchCat);
                        var attachCatId = $filter('filter')(attachCategoryArray, {Name: "Attachments"});
                        var extensionType = entry.name.split(".");
                        var MIMEContentType = '';
                        if(extensionType[1] == "jpg" || extensionType[1] == "jpeg"){
                            MIMEContentType = "image/jpeg";
                        }else if(extensionType[1] == "png"){
                            MIMEContentType = "image/png";
                        }else if(extensionType[1] == "gif"){
                            MIMEContentType = "image/gif";
                        }
                        var dealAttachModel = utility.attachMod().attachObj;
                        dealAttachModel.AttachmentCategoryID = attachCatId[0].AttachmentCategoryID;
                        dealAttachModel.AttachmentID = 0;
                        dealAttachModel.EntityID = $scope.dealModel.DealID;
                        dealAttachModel.DeviceObjID = utility.generateUUID();
                        dealAttachModel.ModuleID = GENERAL_CONFIG.MODULES.Deal;
                        dealAttachModel.ParentDeviceObjID = $scope.dealModel.DeviceObjID;
                        dealAttachModel.FileName = extensionType[0];
                        dealAttachModel.DocumentID = $scope.attachment.docType;
                        dealAttachModel.DocumentName = docTypeName;
                        dealAttachModel.MIMEContentType = MIMEContentType;
                        dealAttachModel.Extension = "."+extensionType[1];
                        $scope.dealAttachments.push(dealAttachModel);
                  });
                  //console.log($scope.dealAttachments);
              }
              function fail(error) {
                  //console.log("fail: " + error.code);
              }
              function makeid() {
                  var text = "";
                  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                  for (var i=0; i < 5; i++) {
                      text += possible.charAt(Math.floor(Math.random() * possible.length));
                  }
                  return text;
              }
         };
         function download(fileEntry, uri) {
             var fileTransfer = new FileTransfer();
             var fileURL = fileEntry.toURL();
             fileTransfer.download(
                 uri,
                 fileURL,
                 function (entry) {
                     //console.log("Successful download...");
                     //console.log("download complete: " + entry.toURL());
                     readFile(entry);
                 },
                 function (error) {
                     //console.log("download error source " + error.source);
                     //console.log("download error target " + error.target);
                     //console.log("upload error code" + error.code);
                 },
                 null, // or, pass false
                 {
                     //headers: {
                     //    "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
                     //}
                 }
             );
         }
        //=====================Attachment Document code End By NiTiN========================
        // Download Image From Server
        $scope.downloadImagesFromServer = function (imgObj) {
             // Check the image in local cache or download the image from server
             if(imgObj.ModuleID == GENERAL_CONFIG.MODULES.Deal){
                 var folderName = "dealImages";
             }
             var filename = imgObj.FileName + imgObj.Extension;
             var totalRecLength = $scope.dealModel.Attachments.length;
             var sourceCopyArray = $scope.dealModel.Attachments;

             $window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem2) {
                   fileSystem2.getDirectory(folderName, { create: true, exclusive: false }, function (dirEntry) {
                         dirEntry.getFile(filename, {create:false}, function(fileEntry){
                              if($scope.attachmentsLength == totalRecLength){
                                   angular.copy(sourceCopyArray, $scope.dealAttachments);
                                   $scope.modalAttachment.show();
                              }else{ $scope.attachmentsLength++; }
                         },function(){
                             dealService.getAttachments(imgObj.AttachmentID).then(function (attachmentsRes) {
                                 var myImgBase64 = attachmentsRes.Base64String;
                                 var contentType = attachmentsRes.MIMEContentType;
                                 var actualImage = utility.b64toBlob(myImgBase64,contentType);
                                 var dirFolderPath = cordova.file.cacheDirectory + folderName;
                                 $window.resolveLocalFileSystemURL(dirFolderPath, function(dir) {
                                     dir.getFile(filename, {create:true}, function(file) {
                                         console.log("File created successfully.");
                                         file.createWriter(function(fileWriter) {
                                             console.log("Writing content to file");
                                             fileWriter.write(actualImage);
                                              if($scope.attachmentsLength == totalRecLength){
                                                 angular.copy(sourceCopyArray, $scope.dealAttachments);
                                                 $scope.modalAttachment.show();
                                              }else{ $scope.attachmentsLength++; }
                                         }, function(){
                                             alert('Unable to save file in path '+ folderpath);
                                         });
                                     });
                                 });
                             });
                         });
                   });
             });
         }

    };

})();
