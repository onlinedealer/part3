import { Component, HostListener, OnInit } from '@angular/core';
import { ErrorMessagesService } from '@precisely/prism-ng/cloud';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { I18nService } from 'discovery-core';
import { routerAnimations } from './router-animation';

@Component({
  selector: 'discovery-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  animations: [routerAnimations]
})
export class AppComponent implements OnInit {
  title = 'discovery-cloud';

  constructor(
    private i18n: I18nService,
    private launchDarkly: LaunchDarklyService,
    public errorMessages: ErrorMessagesService
  ) {}

  // Log out LaunchDarkly client.
  @HostListener('window:beforeunload')
  closeLaunchDarkly(): void {
    this.launchDarkly.close();
  }

  ngOnInit(): void {
    this.i18n.addTranslations('assets/i18n').subscribe();
  }

  getRouterOutletState(outlet) {
    return outlet.isActivated ? outlet.activatedRoute : '';
  }
}
