(function() {
    'use strict';
    FirstApp.constant('uiRouters', {
        filepath: 'apps/datafiles',
	
        directivesHtmlPath: 'apps/views',
        home: '/home/',
        dashboard: '/dashboard/',
        contests: '/contests',
    });
})();
