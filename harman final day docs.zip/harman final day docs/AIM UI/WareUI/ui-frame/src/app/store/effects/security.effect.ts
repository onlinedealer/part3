import { Injectable } from "@angular/core";
import { Actions, ofType, createEffect } from "@ngrx/effects";
import { switchMap, map, catchError, tap, debounceTime, withLatestFrom } from "rxjs/operators";

import { SecurityService } from "../../services/security.service";
import { of } from "rxjs";
import { environment } from "../../../environments/environment";
import { SecurityActions, UserSettingsActions } from "../actions";
import { Store } from "@ngrx/store";
import { State } from "../reducers";
import { SecuritySelectors, ConfigurationsSelectors } from "../selectors";
import { LocalStorageService } from "../../services/local-storage.service";

@Injectable()
export class SecurityEffects {
    constructor(
        private actions$: Actions,
        private securityService: SecurityService,
        private store: Store<State>,
        private localStorageService: LocalStorageService
    ) {}

    getUserInfoSuccess$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.GetUserInfoSuccess),
            map((action: any) => action.response),
            withLatestFrom(this.store.select(ConfigurationsSelectors.getUIConfiguration)),
            map(([userInfo, configuration]) => {
                return UserSettingsActions.GetUserSettingsConfiguration();
            })
        )
    );

    getUserInfo$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.GetUserInfo),
            switchMap(() => {
                return this.securityService.getUserInfo().pipe(
                    map((response: any) => {
                        return SecurityActions.GetUserInfoSuccess({ response: response });
                    }),
                    catchError((error) => of(SecurityActions.GetUserInfoFail(error)))
                );
            })
        )
    );

    retryGettingUserInfoOnFailure$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.GetUserInfoFail),
            debounceTime(2000),
            withLatestFrom(this.store.select(SecuritySelectors.getSecurityResponseFailuresCount)),
            map((action, securityResponseFailuresCount) => {
                if (securityResponseFailuresCount > 2) {
                    return SecurityActions.Logout();
                } else {
                    return SecurityActions.GetUserInfo();
                }
            })
        )
    );

    updateSession$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.UpdateSession),
            switchMap(() => {
                return this.securityService.updateSession().pipe(
                    map((response: any) => {
                        return SecurityActions.UpdateSessionSuccess(response);
                    }),
                    catchError((error) => of(SecurityActions.UpdateSessionFail(error)))
                );
            })
        )
    );

    retrySessionOnFailure$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.UpdateSessionFail),
            debounceTime(2000),
            withLatestFrom(this.store.select(SecuritySelectors.getSecurityResponseFailuresCount)),
            map((action, securityResponseFailuresCount) => {
                if (securityResponseFailuresCount > 2) {
                    return SecurityActions.Logout();
                } else {
                    return SecurityActions.UpdateSession();
                }
            })
        )
    );

    logout$ = createEffect(
        () =>
            this.actions$.pipe(
                ofType(SecurityActions.Logout),
                tap(() => this.localStorageService.writeLogoutEventToLocalStorage()),
                tap(() => (window.location.href = `${environment.security_base_url}/AIMUI/security/logout`))
            ),
        { dispatch: false }
    );

    refreshSessionAfterTime$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.UpdateSessionSuccess),
            debounceTime(environment.uam_token_refresh_interval_in_minutes * 60000),
            map(() => SecurityActions.UpdateSession())
        )
    );

    refreshUserInfoAfterTime$ = createEffect(() =>
        this.actions$.pipe(
            ofType(SecurityActions.GetUserInfoSuccess),
            debounceTime(environment.uam_userinfo_refresh_interval_in_minutes * 60000),
            map(() => SecurityActions.GetUserInfo())
        )
    );
}
