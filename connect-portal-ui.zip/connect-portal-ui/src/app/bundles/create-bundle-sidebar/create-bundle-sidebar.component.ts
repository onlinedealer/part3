import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Connection } from 'src/app/connections/shared/connection';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { LogFileMetadata } from '../shared/bundles';
import { BundlesApiService } from '../shared/bundles-api.service';
import { CreateBundleFormComponent } from './create-bundle-form/create-bundle-form.component';

@Component({
  selector: 'p-connect-create-bundle-sidebar',
  templateUrl: './create-bundle-sidebar.component.html'
})
export class CreateBundleSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(CreateBundleFormComponent) createBundleFormComponent: CreateBundleFormComponent;
  @Output() bundleCreatedEvent = new EventEmitter();
  /**
   * Contains the list of source data connections & associated runtime servers and agent used in the project
   */
  listOfSourceConnectionsInProject: Connection[];
  /**
   * Contains project information such as project name and id
   */
  project: Project;
  /**
   * Get logs file metadata API returns agent name
   */
  agentName: string;
  /**
   * Get logs file metadata API returns bundle location
   */
  bundleLocation: string;
  /**
   * Date timestamp to be appended to bundle name placeholder within the input field
   */
  date: string = '';
  /**
   * Get logs file metadata API returns list of files to be bundled
   */
  listOfFilesToBeBundled: LogFileMetadata;

  primaryButton: SidebarButton = {
    id: 'primaryCreateBundleButton',
    text: 'bundles.CREATE_BUNDLE_SIDEBAR.BUTTONS.CREATE',
    testId: 'createBundleCreateButton'
  };

  cancelButton: SidebarButton = {
    id: 'cancelCreateBundleButton',
    text: 'bundles.CREATE_BUNDLE_SIDEBAR.BUTTONS.CANCEL',
    testId: 'createBundleCancelButton'
  };

  constructor(private readonly bundlesApiService: BundlesApiService, private datePipe: DatePipe) {}

  /**
   * @param project: project of which the bundle will be created in
   * @param listOfSourceConnectionsInProject: list of source connections used for each dataflow in a project
   */
  open(project: Project, listOfSourceConnectionsInProject: Connection[]): void {
    this.createBundleFormComponent.createBundleForm.patchValue({ bundleName: '', bundleDescription: '' });
    this.listOfSourceConnectionsInProject = listOfSourceConnectionsInProject;
    this.project = project;
    this.getListOfFilesToBeBundled(project);
    this.setTimeStampFormatForBundleName();
    this.sidebarComponent.open();
  }

  createButtonClicked(): void {
    this.sidebarComponent.isProcessingRequest = true;

    const { bundleName, bundleDescription } = this.createBundleFormComponent.createBundleForm.controls;
    this.bundlesApiService
      .createBundle(this.project.id, bundleName.value, bundleDescription.value, this.listOfFilesToBeBundled)
      .subscribe({
        next: (bundleName: string) => {
          this.bundleCreatedEvent.emit(bundleName);
          this.cancelButtonClicked();
        },
        error: (errorResponse) => {
          if (errorResponse.status === 200) {
            this.bundleCreatedEvent.emit(bundleName.value);
            this.cancelButtonClicked();
          } else {
            this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
          }
        }
      })
      .add(() => (this.sidebarComponent.isProcessingRequest = false));
  }

  cancelButtonClicked() {
    this.sidebarComponent.close();
  }

  setTimeStampFormatForBundleName(): void {
    this.date = this.datePipe.transform(Date.now(), 'YYYY-MM-dd_HH-mm-ss');
  }

  private getListOfFilesToBeBundled(project: Project): void {
    this.sidebarComponent.isProcessingRequest = true;

    this.bundlesApiService
      .getLogsFileMetadata(project)
      .subscribe({
        next: (response: LogFileMetadata) => {
          this.listOfFilesToBeBundled = response;
          this.bundleLocation = response.bundleLocation;
          this.agentName = response.agentName;
        },
        error: (errorResponse) => this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse)
      })
      .add(() => (this.sidebarComponent.isProcessingRequest = false));
  }
}
