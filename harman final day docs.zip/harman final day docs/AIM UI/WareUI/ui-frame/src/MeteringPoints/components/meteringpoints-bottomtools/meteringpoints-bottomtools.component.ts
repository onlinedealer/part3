import { ClipboardService } from "../../services/clipboard.service";
import { Component, Input, ChangeDetectionStrategy } from "@angular/core";
import { CsvExportService } from "../../services/csv-export.service";
import { LoadMeteringPointSupportedReadings } from "../../store/actions/ondemandreadings.action";
import { MatDialog } from "@angular/material/dialog";
import { MeteringPointDetails } from "../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { OnDemandReadingDialogComponent } from "../../containers";
import { Store } from "@ngrx/store";
import { UAMPermissionsService } from "../../../Shared/services/uam-permissions.service";
import { ControlsDialogComponent } from "../../RelayControl/containers/controls-dialog.component";

@Component({
    selector: "landisgyr-meteringpoints-bottomtools",
    templateUrl: "./meteringpoints-bottomtools.component.html",
    styleUrls: ["./meteringpoints-bottomtools.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringPointsBottomToolsComponent {
    @Input()
    selectedMeteringPoint!: MeteringPointDetails;
    @Input()
    selectedMeteringPointId!: number | undefined;
    @Input()
    meteringPointsAmount!: number;
    @Input()
    searched!: boolean;
    @Input()
    selectedMeteringPointsAmount!: number;
    @Input()
    uamPermissions!: string[];
    @Input()
    showBottomTools!: boolean;
    @Input()
    sideViewOpened!: boolean;

    totalPoints = $localize`:|@@meteringpointsBottomtools.totalMeteringPoints:Total # metering points`;
    totalOneMeteringPoint = $localize`:|@@meteringpointsBottomtools.totalOneMeteringPoint:Total 1 metering point`;

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private clipboardService: ClipboardService,
        private csvExportService: CsvExportService,
        public dialog: MatDialog,
        public uamPermissionService: UAMPermissionsService
    ) {}

    onReadValues() {
        if (!(!!this.selectedMeteringPointId && this.selectedMeteringPointId > 0)) {
            return;
        }
        this.dialog.open(OnDemandReadingDialogComponent, {
            panelClass: "landisgyr-dialog-container",
            disableClose: true
        });

        this.store.dispatch(
            LoadMeteringPointSupportedReadings({
                meteringPointId: this.selectedMeteringPointId
            })
        );
    }

    onControls() {
        this.dialog.open(ControlsDialogComponent, {
            width: "1024px",
            maxWidth: "1024px",
            height: "640px",
            maxHeight: "640px",
            disableClose: true
        });
    }

    onCopy() {
        const meteringPointData = this.clipboardService.getMeteringPointAsText(this.selectedMeteringPoint);
        this.clipboardService.copyToClipboard(meteringPointData);
    }

    onExport() {
        this.csvExportService.exportRegisterData();
    }

    totalMeteringPoints(): string {
        if (this.meteringPointsAmount === 1) {
            return this.totalOneMeteringPoint;
        } else {
            return this.totalPoints.replace("#", this.meteringPointsAmount.toString());
        }
    }
}
