import { Injectable } from '@angular/core';
import { noop } from '../noop.model';
import { DEFAULT_LOG_LEVEL, LOG_LEVELS } from './log-levels.model';
import { LoggerImpl } from './logger-impl.model';
import { Logger } from './logger.model';

/**
 * The anchor point for the logging system. The most common usage of this class is to obtain a named Logger. The method getLogger()
 * is provided as the most convenient way to obtain a named Logger based on the calling class name.
 *
 * The log manager is also used to configure the global log level.  Snapshot builds have a default log level of DEBUG.  Release
 * builds ship with a default log level of INFO.  This log level can be temporarily overriden, via the browser console window, using the
 * following command:  spectrum.core.log.level('DEBUG')
 */
@Injectable({
  providedIn: 'root'
})
export class LogManagerService {
  private window: any;

  /**
   * @internal
   */
  constructor() {
    this.window = window;
    this.addConsoles();
    this.addGlobal();
  }

  /**
   * Gets the current log level.
   * @returns The current log level
   */
  getLevel(): string {
    return this.window.spectrum.core.log.level();
  }

  /**
   * Sets the current log level.
   * @param logLevel A value of 'TRACE', 'DEBUG', 'INFO', 'WARN', 'ERROR', or 'OFF'.
   */
  setLevel(logLevel: string): void {
    this.window.spectrum.core.log.level(logLevel);
  }

  /**
   * Returns a logger with given name.  The name will be output as part of the message and is typically the class name.
   *
   * Note that we cannot use any type of reflection to get the class name as this will break when the code is minified.
   */
  getLogger(name: string): Logger {
    return this.window.spectrum.core.log.getLogger(name);
  }

  /**
   * Avoid `console` errors in browsers that lack a console.
   *   https://gist.github.com/elijahmanor/7884984#file-console-monkey-patch-js
   */
  private addConsoles(): void {
    let method;
    const methods = [
      'assert',
      'clear',
      'count',
      'debug',
      'dir',
      'dirxml',
      'error',
      'exception',
      'group',
      'groupCollapsed',
      'groupEnd',
      'info',
      'log',
      'markTimeline',
      'profile',
      'profileEnd',
      'table',
      'time',
      'timeEnd',
      'timeStamp',
      'trace',
      'warn'
    ];
    let length = methods.length;
    const console = ((window as any).console = window.console || {});

    while (length--) {
      method = methods[length];

      // Only stub undefined methods.
      if (!console[method]) {
        console[method] = noop;
      }
    }
  }

  /**
   * Logging is configured on the global window.  This allows setting of the application-wide log level via the console.  Ex:
   *    spectrum.core.log.level('DEBUG')
   */
  private addGlobal(): void {
    this.window.spectrum = this.window.spectrum || {};
    this.window.spectrum.core = this.window.spectrum.core || {};
    this.window.spectrum.core.log = this.window.spectrum.core.log || {
      current: DEFAULT_LOG_LEVEL,
      getLogger: (name: string): Logger => new LoggerImpl(name),
      level: (logLevel: string) => {
        if (logLevel) {
          logLevel = logLevel.trim().toUpperCase();
          if (typeof LOG_LEVELS[logLevel] !== 'undefined') {
            this.window.spectrum.core.log.current = logLevel;
          } else {
            throw Error('Invalid log level');
          }
        }
        return this.window.spectrum.core.log.current;
      }
    };
  }
}
