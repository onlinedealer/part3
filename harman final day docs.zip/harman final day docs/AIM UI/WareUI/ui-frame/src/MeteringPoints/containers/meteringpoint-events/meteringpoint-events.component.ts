import { Component, Input, ChangeDetectionStrategy, AfterViewInit, OnInit } from "@angular/core";
import { MeteringPoint } from "../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { EventsActions, PqiDataActions } from "../../store/actions";
import { EventsSelectors, EventDefinitionsSelectors } from "../../store/selectors";
import { Store } from "@ngrx/store";
import { RouterSelectors } from "../../../app/store/selectors";

@Component({
    selector: "landisgyr-meteringpoint-events-container",
    templateUrl: "./meteringpoint-events.component.html",
    styleUrls: ["./meteringpoint-events.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringPointEventsComponent implements OnInit, AfterViewInit {
    @Input()
    meteringPoint!: MeteringPoint;

    eventTypeToShow$ = this.store.select(EventsSelectors.getEventsActiveView);
    eventsTimeRange$ = this.store.select(EventsSelectors.getDateRangeForEventsData);
    eventsTimeRangeRadio$ = this.store.select(EventsSelectors.getEventsTimeRangeRadio);

    selectedEvent$ = this.store.select(EventsSelectors.getSelectedMeteringPointSelectedEvent);

    allEventDefinition$ = this.store.select(EventDefinitionsSelectors.getAllDefinitionsofTypesAsArray);
    constructor(private store: Store<MeteringPointsFeatureState>) {}

    ngAfterViewInit() {
        setTimeout(() => this.checkURLForActiveViewOnPageReload());
    }

    ngOnInit() {
        this.store.dispatch(EventsActions.LoadMeteringPointEventDefinitions());
        this.store.dispatch(PqiDataActions.LoadMeteringPointPqiDefinitions());
    }

    checkURLForActiveViewOnPageReload() {
        this.store
            .select(RouterSelectors.getSegmentsWithParams)
            .subscribe((segmentsWithParams) => {
                const segments = segmentsWithParams.segments;
                const activeView = segmentsWithParams.segments[segmentsWithParams.segments.length - 1];

                if (segments.includes("powerQuality")) {
                    if (activeView === "tableview" || activeView === "chartview") {
                        this.store.dispatch(new PqiDataActions.ChangePQIView(activeView));
                    }
                    this.store.dispatch(EventsActions.SetEventsActiveView({ activeView: "powerQuality" }));
                }
            })
            .unsubscribe();

        this.store.dispatch(EventsActions.SetEventActiveViewOnPageReload());
    }

    onEventsTypeChanged(eventsType: string) {
        this.store.dispatch(EventsActions.SetEventsActiveView({ activeView: eventsType }));
    }

    onChangeTimeRange(eventsTimeRange: { from: number; until: number }) {
        this.store.dispatch(EventsActions.SetEventsDateRange(eventsTimeRange));
    }

    onChangeTimeRangeRadio(value: string) {
        this.store.dispatch(EventsActions.SetEventsDateRangeRadio({ rangeRadio: value }));
    }

    onEventSelected(meteringPointSelectedEvent: { meteringPointId: number; eventId: number }) {
        this.store.dispatch(
            EventsActions.SelectMeteringPointEvent({
                meteringPointId: meteringPointSelectedEvent.meteringPointId,
                eventId: meteringPointSelectedEvent.eventId
            })
        );
    }

    onEventSideviewClosed(meteringPointId: number) {
        this.store.dispatch(
            EventsActions.UnselectMeteringPointEvent({
                meteringPointId
            })
        );
    }
}
