import { Component, EventEmitter, Input, Output } from '@angular/core';

/**
 * This component is used by the Entity Card to display a Filter input box to allow the user to filter the contents of the Entity Card.
 */
@Component({
  selector: 'discovery-png-entity-filter',
  templateUrl: './entity-filter.component.html',
  styleUrls: ['./entity-filter.component.scss']
})
export class EntityFilterComponent {
  /**
   * This property is used to disable the input text box, if needed.
   */
  @Input() disabled = false;

  /**
   * This property is used as the placeholder text for the Filter text box.
   */
  @Input() filterPlaceholder: string = 'png.entitySelector.filterPlaceholder';

  /**
   * This event is fired whenever the filter text is modified.
   */
  @Output() filterChange: EventEmitter<string> = new EventEmitter<string>();

  /** @internal */
}
