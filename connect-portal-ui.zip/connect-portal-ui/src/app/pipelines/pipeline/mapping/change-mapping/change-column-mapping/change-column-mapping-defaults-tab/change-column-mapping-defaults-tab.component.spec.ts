import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { FormBuilder } from '@angular/forms';
import { ChangeColumnMappingDefaultsTabComponent } from './change-column-mapping-defaults-tab.component';
import { getTranslocoModule } from '../../../../../../core/transloco-testing.module';
import { PipelineEntityService } from '../../../../shared/pipeline-entity.service';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
import { of } from 'rxjs';

describe('ChangeColumnMappingDefaultsTabComponent', () => {
  let component: ChangeColumnMappingDefaultsTabComponent;
  let fixture: ComponentFixture<ChangeColumnMappingDefaultsTabComponent>;
  let pipelineEntityService: PipelineEntityService;
  let pipelineMappingService: PipelineMappingService;

  let mockPipelineService = {
    getChangeColumnMappingDefaults: () => {}
  };

  const defaultMockData = [
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'EXCLUDE',
      isChecked: false
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true
    },
    {
      key: 'NO_ROW_METADATA',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'EXCLUDE',
      isChecked: false
    }
  ];

  let mockDialogService = jasmine.createSpyObj('PipelineMappingService', ['closeAll']);
  mockDialogService.refs = [];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      declarations: [ChangeColumnMappingDefaultsTabComponent],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        { provide: PipelineMappingService, useValue: mockPipelineService },
        FormBuilder
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeColumnMappingDefaultsTabComponent);
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    component = fixture.componentInstance;
    fixture.detectChanges();
    pipelineMappingService = TestBed.inject(PipelineMappingService);
  });

  it('should get Column Mapping Type if type is column order', () => {
    expect(component.getColumnMappingType('COLUMN_ORDER')).toBe('Column order');
  });

  it('should check all row meta data checkbox', () => {
    component.rowMetadata = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'INCLUDE',
        isChecked: true
      }
    ];
    component.rowMetadata.length = 1;
    component.rowMetaDataCheckAll();
    expect(component.rowMetadata[0].isChecked).toBe(true);
    expect(component.rowMetadata[0].cdcRowMetadataType).toBe('INCLUDE');
  });

  it('should get Column Mapping Type if type is column name', () => {
    expect(component.getColumnMappingType('COLUMN_NAME')).toBe('Column name');
  });

  it('should update from form changes', fakeAsync(() => {
    component.defaultsTabFormGroup.controls[`mapColumnsByDropdown`].setValue({
      value: component.mapColumnsByDropdownData[0]?.value,
      name: component.mapColumnsByDropdownData[0]?.name
    });
    component.defaultsTabFormGroup.controls[`includeRowMetaDataDropdown`].setValue({
      value: component.includeRowMetaDataDropdownData[0]?.value,
      name: component.includeRowMetaDataDropdownData[0]?.name
    });
    expect(component.defaultsTabFormGroup.controls.mapColumnsByDropdown.value).toEqual({
      value: component.mapColumnsByDropdownData[0]?.value,
      name: component.mapColumnsByDropdownData[0]?.name
    });
    expect(component.defaultsTabFormGroup.controls.includeRowMetaDataDropdown.value).toEqual({
      value: component.includeRowMetaDataDropdownData[0]?.value,
      name: component.includeRowMetaDataDropdownData[0]?.name
    });
  }));

  it('should change includeRowMetaData Dropdown value if select row metadata', () => {
    const event = {
      value: { name: 'Select row metadata', value: 'SELECT_ROW_METADATA' }
    };
    component.includeRowMetaDataDropdownChanged(event);
    expect(component.metaDataCheckboxField).toBe(true);
  });

  it('should change includeRowMetaData Dropdown value if No row metadata', () => {
    const event = {
      value: { name: 'No row metadata', value: 'NO_ROW_METADATA' }
    };
    component.rowMetadata = defaultMockData;
    const setMapColumnDropDownValue = spyOn(component, 'rowMetaDataCheckAll').and.returnValue();
    component.includeRowMetaDataDropdownChanged(event);
    expect(component.metaDataCheckboxField).toBe(false);
    expect(setMapColumnDropDownValue).toHaveBeenCalled();
    expect(component.rowMetadata[2].isChecked).toBe(false);
  });

  it('should change map Columns By Dropdown Change value is NAME', () => {
    const event = {
      value: { name: 'Column name', value: 'COLUMN_NAME' },
      id: 2
    };
    component.mapColumnsByDropdownChange(event);
    expect(component.columnMappingType).toEqual(event.value.value);
  });

  it('should change map Columns By Dropdown Change value is ORDINAL', () => {
    const event = {
      value: { name: 'Column order', value: 'COLUMN_ORDER' },
      id: 2
    };
    component.mapColumnsByDropdownChange(event);
    expect(component.columnMappingType).toEqual(event.value.value);
  });

  it('should get Defaults tab Payload Data', () => {
    component.rowMetadata = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'EXCLUDE',
        isChecked: false
      }
    ];
    component.payloadForDefaults = { METADATA_USER_ID: 'EXCLUDE' };
    expect(component.payloadForDefaults['METADATA_USER_ID']).toEqual(component.rowMetadata[0].cdcRowMetadataType);
  });

  it('should get Defaults Payload Data with EXCLUDE option', () => {
    component.rowMetadata = defaultMockData;
    component.defaultsTabFormGroup.controls[`includeRowMetaDataDropdown`].setValue(component.includeRowMetaDataDropdownData[1]?.name);
    component.getDefaultsPayloadData();
    expect(component.payloadForDefaults[defaultMockData[1].key]).toEqual('EXCLUDE');
  });

  it('should get Emitted Default Meta data', () => {
    component.rowMetadata = defaultMockData;
    component.getDefaultEmittedData(defaultMockData);
    expect(component.rowMetadata).toEqual(defaultMockData);
  });

  it('should disable Save Button all checkbox unchecked', () => {
    spyOn(component.disableSaveButton, 'emit');
    component.rowMetadata = defaultMockData;
    component.disableSaveButtonIfUnchecked();
    expect(component.disableSaveButton.emit).toHaveBeenCalled();
  });

  it('should get updated default data', () => {
    const isUpdateDefaultClicked = true;
    spyOn(component, 'loadDefaultTab');
    component.loadDefaultTab(isUpdateDefaultClicked);
    component.isUpdateDefaultClicked = isUpdateDefaultClicked;
    component.getUpdatedRowMetadata();
    expect(component.isUpdateDefaultClicked).toEqual(true);
    expect(component.loadDefaultTab).toHaveBeenCalledWith(isUpdateDefaultClicked);
  });

  it('should get updated default data if isUpdateDefaultClicked is true', () => {
    spyOn(component, 'loadDefaultTab');
    component.loadDefaultTab(true);
    component.isUpdateDefaultClicked = true;
    spyOn(component, 'getUpdatedRowMetadata');
    component.getUpdatedRowMetadata();
    expect(component.getUpdatedRowMetadata).toHaveBeenCalled();
  });

  it('should trigger to get default row metadata', () => {
    const isIncludeExist = true;
    spyOn(component, 'checkIsIncludeExist');
    component.checkIsIncludeExist(isIncludeExist);
    component.getDefaultData();
    expect(isIncludeExist).toEqual(true);
    expect(component.checkIsIncludeExist).toHaveBeenCalledWith(isIncludeExist);
  });

  it('should get updated rowMetaData on update default btn click', () => {
    const mockData = {
      columnMappingType: 'NAME',
      cdcRowMetadatas: [
        {
          key: 'METADATA_USER_ID',
          value: 'sv_trans_username',
          cdcRowMetadataType: 'INCLUDE'
        }
      ]
    };
    const isIncludeExist = true;
    spyOn(pipelineMappingService, 'getChangeColumnMappingDefaults').and.returnValue(of(mockData));
    spyOn(component, 'checkIsIncludeExist');
    component.getUpdatedRowMetadata();
    expect(pipelineMappingService.getChangeColumnMappingDefaults).toHaveBeenCalled();
    expect(component.checkIsIncludeExist).toHaveBeenCalledWith(isIncludeExist);
  });

  it('should set value of includeRowMetaData dropdown if INCLUDE exists', () => {
    spyOn(component, 'checkIsIncludeExist');
    component.checkIsIncludeExist(true);
    component.defaultsTabFormGroup.controls[`includeRowMetaDataDropdown`].setValue({
      value: component.includeRowMetaDataDropdownData[0]?.value,
      name: component.includeRowMetaDataDropdownData[0]?.name
    });
    component.metaDataCheckboxField = true;
    expect(component.metaDataCheckboxField).toEqual(true);
  });

  it('should set value of includeRowMetaData dropdown if all records EXCLUDE', () => {
    spyOn(component, 'checkIsIncludeExist');
    component.checkIsIncludeExist(false);
    component.defaultsTabFormGroup.controls[`includeRowMetaDataDropdown`].setValue({
      value: component.includeRowMetaDataDropdownData[1]?.value,
      name: component.includeRowMetaDataDropdownData[1]?.name
    });
    component.metaDataCheckboxField = false;
    expect(component.metaDataCheckboxField).toEqual(false);
  });

  it('sholud call if rowdata includes cdcRowMetadataType equals to INCLUDE', () => {
    const mockData = {
      columnMappingType: 'NAME',
      cdcRowMetadatas: [
        {
          key: 'METADATA_USER_ID',
          value: 'sv_trans_username',
          cdcRowMetadataType: 'INCLUDE'
        }
      ]
    };
    spyOn(pipelineMappingService, 'getChangeColumnMappingDefaults').and.returnValue(of(mockData));
    component.getUpdatedRowMetadata();
    component.defaultsTabFormGroup.controls[`includeRowMetaDataDropdown`].setValue({
      value: component.includeRowMetaDataDropdownData[0]?.value,
      name: component.includeRowMetaDataDropdownData[0]?.name
    });
    component.metaDataCheckboxField = true;
    expect(pipelineMappingService.getChangeColumnMappingDefaults).toHaveBeenCalled();
    expect(component.defaultsTabFormGroup.controls.includeRowMetaDataDropdown.value).toEqual({
      value: component.includeRowMetaDataDropdownData[0]?.value,
      name: component.includeRowMetaDataDropdownData[0]?.name
    });
    expect(component.metaDataCheckboxField).toBe(true);
  });

  it('sholud call if rowdata includes cdcRowMetadataType equals to EXCLUDE', () => {
    const mockData = {
      columnMappingType: 'NAME',
      cdcRowMetadatas: [
        {
          key: 'METADATA_USER_ID',
          value: 'sv_trans_username',
          cdcRowMetadataType: 'EXCLUDE'
        }
      ]
    };
    spyOn(pipelineMappingService, 'getChangeColumnMappingDefaults').and.returnValue(of(mockData));
    component.getUpdatedRowMetadata();
    component.defaultsTabFormGroup.controls[`includeRowMetaDataDropdown`].setValue({
      value: component.includeRowMetaDataDropdownData[1]?.value,
      name: component.includeRowMetaDataDropdownData[1]?.name
    });
    component.metaDataCheckboxField = false;
    expect(pipelineMappingService.getChangeColumnMappingDefaults).toHaveBeenCalled();
    expect(component.defaultsTabFormGroup.controls.includeRowMetaDataDropdown.value).toEqual({
      value: component.includeRowMetaDataDropdownData[1]?.value,
      name: component.includeRowMetaDataDropdownData[1]?.name
    });
    expect(component.metaDataCheckboxField).toBe(false);
  });

  it('should set default row meta data', () => {
    component.defaultsMetaData = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'EXCLUDE'
      }
    ];
    expect(component.rowMetadata).toBeDefined();
  });

  it('should get updated row metadata when update defaults happen', () => {
    const getUpdatedRowMetaDataSpy = spyOn(component, 'getUpdatedRowMetadata');
    component.loadDefaultTab(true);
    expect(getUpdatedRowMetaDataSpy).toHaveBeenCalled();
  });

  it('should mark each metadata checkbox as checked if all meta data are excluded and user selects - Select row metadata option', () => {
    component.rowMetadata = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'EXCLUDE'
      },
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'EXCLUDE'
      }
    ];
    component.rowMetaDataCheckAll();
    expect(component.rowMetadata.filter((i) => i.isChecked === true).length).toEqual(2);
  });
});
