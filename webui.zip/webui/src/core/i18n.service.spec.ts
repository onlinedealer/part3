import { TranslocoService } from '@ngneat/transloco';
import { HttpClient } from '@angular/common/http';
import { of, EMPTY } from 'rxjs';
import { I18nService } from './i18n.service';

describe('I18nService', () => {
  let http: any;
  let i18n: I18nService;
  const ngxTranslate: any = {
    currentLang: 'en-us',
    setDefaultLang: () => {},
    setTranslation: jasmine.createSpy('setTranslation'),
    use: () => {},
    setActiveLang: (lang) => {},
    getActiveLang: () => ''
  };
  let windowUtil: any;

  beforeEach(() => {
    http = jasmine.createSpyObj('http', ['get']);
    http.get.and.returnValue(of({ foo: 'bar' }));
    windowUtil = {
      nativeWindow: {
        location: {
          search: ''
        },
        navigator: {}
      }
    };
    i18n = new I18nService(http as HttpClient, ngxTranslate as TranslocoService, windowUtil);
  });

  it('should be created', () => {
    expect(i18n).toBeTruthy();
  });

  it('can add translations', () => {
    i18n.addTranslations('test/path').subscribe();
    expect(http.get).toHaveBeenCalledWith('test/path/en.json');
    expect(ngxTranslate.setTranslation).toHaveBeenCalled();
  });

  it('uses default locale when all else fails', () => {
    expect(i18n.getBrowserLocale()).toBe('en-us');
  });
});
