import React from 'react'
import { connect } from 'react-redux'

export class Health extends React.Component {
  render () {
    return (
      'Welcome..!'
    )
  }
}

export default connect()(Health)
