import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PhrLockedComponent } from './phr-locked.component';

describe('PhrLockedComponent', () => {
  let component: PhrLockedComponent;
  let fixture: ComponentFixture<PhrLockedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PhrLockedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PhrLockedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
