import { Component, OnInit, Input, Output, EventEmitter, AfterViewChecked, ChangeDetectorRef, ChangeDetectionStrategy } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { Router } from '@angular/router';
import { ActiveModelService } from '../../shared/models/active-model.service';
import * as _ from 'underscore';
import * as $ from 'jquery';
import { VantivModelService } from '../../shared/models/vantiv-model.service';
import { AjaxUtilityService } from '../../shared/utility/ajax-utility.service';
import { HttpResponse } from '@angular/common/http';
import { CreditCardService } from '../../shared/utility/credit-card.service';
import { OrderModel } from '../../shared/models/order-model';
import { UtagService } from 'utag-module';
import { ClubConstantsService, RouteConfigurations } from '../../shared/utility/club-constants.service';


declare var EprotectIframeClient: any;

@Component({
  selector: 'app-card-details',
  templateUrl: './card-details.component.html',
  styleUrls: ['./card-details.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class CardDetailsComponent implements OnInit, AfterViewChecked {

  defaultData: any;
  public cardDetailsForm: FormGroup;
  invalidCardErr: string;
  errString: string;
  @Input() cardDetails: any;
  @Output() serviceError: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() errorStatusMsg: EventEmitter<any> = new EventEmitter<any>();
  @Output() selectedCard: EventEmitter<number> = new EventEmitter<number>();


  vantivError: boolean;
  vantiveErrorString = '';
  addCard: boolean;
  createSubscriptionOrderReq: any = {};
  formSubmitted: boolean;

  paymentContent: any;

  constructor(private _fb: FormBuilder,
  private _activeModel: ActiveModelService,
  private _vantivService: VantivModelService,
  private _ajaxUtility: AjaxUtilityService,
  private _ccService: CreditCardService,
  private _router: Router,
  private _cd: ChangeDetectorRef,
  private _utag: UtagService,
  private _constants: ClubConstantsService
  ) { }

  ngOnInit() {
    this.invalidCardErr = this._constants.getBillingPayErrorMessages()['prepaidErrorMsgDtls'];
    this.paymentContent = this._activeModel.getPaymentConstants();
    let defaultCardIndex = 0;
    _.map(this.cardDetails, function(card, index) {
      if (card['defaultCard']) {
        defaultCardIndex = index;
      }
    });
    this.cardDetailsForm = this._fb.group({
      savedCard: [this.cardDetails[defaultCardIndex], [Validators.required]],
      cvv: ['', [Validators.required, Validators.maxLength(4), Validators.pattern('^[0-9]{3,4}$')]]
    });

    // defining utagObj param for utag link/ view call
    const utagObj = {
      'page_name': '',
      'pageflag': ''
    };
    if (this.cardDetails.length) {
      window['eProtectiframeClient'] = window['eProtectiframeClient'] || {};

      // utagObj if cardList is not empty
      utagObj.page_name = 'carepass:how would you like to pay';
      utagObj.pageflag = 'saved card:yes';
    } else {

      // utagObj if cardList is empty
      utagObj.page_name = 'carepass:how would you like to pay';
      utagObj.pageflag = 'saved card:no';
      setTimeout(() => {
        this.visaCheckoutInitiation();
      }, 1000);
    }

    // calling utag.view on page load
    setTimeout(() => {
      this._utag.view(utagObj);
    }, 2000);
  }

  ngAfterViewChecked() {
  }

  updateSavedCard(defaultIndex = 0) {
    this.cardDetailsForm.patchValue({
      savedCard: this.cardDetails[defaultIndex]
    });
  }

  addNewCreditCard() {
    setTimeout(() => {
      this.visaCheckoutInitiation();
    }, 1000);
  }

  updateExistingCardInfo() {
    this.createSubscriptionOrderReq.request.createOrderRequest.payment['paymentId'] = this.cardDetailsForm.get('savedCard').value.cardId;
    this.createSubscriptionOrderReq.request.createOrderRequest.payment['creditCardNumber'] = this.getEncrypted(this.cardDetailsForm.get('savedCard').value.token.substr(this.cardDetailsForm.get('savedCard').value.token.length - 4));
    this.createSubscriptionOrderReq.request.createOrderRequest.payment['expirationDate'] = this.getEncrypted(this.cardDetailsForm.get('savedCard').value.expirationMonth+''+this.cardDetailsForm.get('savedCard').value.expirationYear.substr(2));
    this.createSubscriptionOrderReq.request.createOrderRequest.payment['ccCvv'] = this.getEncrypted(this.cardDetailsForm.get('cvv').value);
    this.createSubscriptionOrderReq.request.createOrderRequest.payment['ccType'] = this.cardDetailsForm.get('savedCard').value.creditCardType;
    this.createSubscriptionOrderReq.request.createOrderRequest.payment['tokenType'] = 'HVT';
    this.createSubscriptionOrderReq.request.createOrderRequest.payment['isCCLowToken'] = false;
    this.createSubscription(this.createSubscriptionOrderReq);
  }


  /*Vantiv -- Start*/

  public callVantive(): void {
    const message = {
        'id': this.getVantivPayPageId(),
        'orderId': 'ab124',
        'pciNonSensitive': false
    };
    window['eProtectiframeClient'].getPaypageRegistrationId(message);
  }

  private getVantivPayPageId(): { [s: string]: string } {
    // return {
    //   "paypageId": (_.uppercase(this.util.getCurrentENV() || '')  === 'PROD')
    //     ? "34PQav6ki9WPnQSP" // --> API Key for Prod
    //     : "KTYcZkCYpyYs7UTj" // --> API Key for Dev
    // };
    return {
      'paypageId': (-1 !== window.location.href.indexOf('m.cvs.com') || -1 !== window.location.href.indexOf('www.cvs.com'))
        ? '34PQav6ki9WPnQSP' // --> API Key for Prod
        : 'DrQ54xd7fiJjp2Xf' // --> API Key for Dev
    };
  }

  visaCheckoutInitiation() {

    let eProtectCardElement = document.getElementById('eProtectCard');
    while (eProtectCardElement.hasChildNodes()) {
      eProtectCardElement.removeChild(eProtectCardElement.lastChild);
    }
    const __callbacks: any = {
      'callback': this.visaCheckoutSuccessCallback.bind(this),
      'inputsEmptyCallback': this.inputsEmptyCallback.bind(this)
    };

    let configure: any = _.extend({}, this.getVantivPayPageId(), __callbacks, this._vantivService.VANTIV_MODEL.VANTIV_CONFIGURATION);

    if ('undefined' === typeof window['EprotectIframeClient']) {
      this.vantivError = true;
      this.vantiveErrorString = this._vantivService.VANTIV_MODEL.VANTIV_ERRORS.TECHNICAL_DIFFICULTIES;
    }else {
      window['eProtectiframeClient'] = new window['EprotectIframeClient'](configure);
      window['eProtectiframeClient'].autoAdjustHeight();
    }
  }


  public getEncrypted(data): any {
    return btoa(data);
  }

  public visaCheckoutSuccessCallback(data): void {
    if ('870' === data.response) {
      this.createSubscriptionOrderReq.request.createOrderRequest.payment['paymentId'] = '';
      this.createSubscriptionOrderReq.request.createOrderRequest.payment['creditCardNumber'] = data.paypageRegistrationId;
      this.createSubscriptionOrderReq.request.createOrderRequest.payment['expirationDate'] = this.getEncrypted(data.expMonth+''+data.expYear);
      this.createSubscriptionOrderReq.request.createOrderRequest.payment['ccCvv'] = this.getEncrypted('000');
      this.createSubscriptionOrderReq.request.createOrderRequest.payment['ccType'] = this._ccService._fromNumber(data.firstSix).type;
      this.createSubscription(this.createSubscriptionOrderReq);
    } else {
      this.errorStatusMsg.emit(data.message);
      //this.serviceError.emit(true);
    }
  }

  public eProtectiframeClientCallback(data): void {}

  public inputsEmptyCallback(data): void {}

  /**Vantiv end */

  public passSubscriptionData(profile, addrForm, subscription) {
    this.createSubscriptionOrderReq = {
      'request': {
        'createOrderRequest': {
          'head': {
            'origin': 'Digital',
            'frequency': subscription.subscriptionType.toLowerCase() === 'annually' ? 'annual' : 'monthly',
            'enrollmentType': 'Initial'
          },
          'payment': {
            'paymentId': '',
            'creditCardNumber': '',
            'expirationDate': '',
            'ccCvv': '',
            'firstName': addrForm.get('firstName').value,
            'lastName': addrForm.get('lastName').value,
            'address1': addrForm.get('address1').value,
            'address2': addrForm.get('address2').value,
            'city': addrForm.get('city').value,
            'ccType': '',
            'state': addrForm.get('state').value,
            'zipCode': addrForm.get('zipCode').value,
            'isCCLowToken': true,
            'isFsaCard': 'N',
            'tokenType': 'LVT',
            'decryptData': true,
            'saveCard': true
          }
        }
      }
    };
  }

  createSubscription(req) {
    window.scrollTo(0, document.body.scrollHeight);
    this.errString = null;
    this._ajaxUtility.sendRequest('createSubscriptionOrder', req).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            const clubStorage: any = {
              orderId: ''
            };
            clubStorage.orderId = response.additionalData.orderId;
            sessionStorage.setItem('clubStorage', JSON.stringify(clubStorage));
            const clubStorageConf: any = {
              counter: 0
            };
            clubStorageConf.counter++;
            sessionStorage.setItem('clubStorageConf', JSON.stringify(clubStorageConf));
/*             if (response.hasOwnProperty('additionalData')) {
              this._activeModel.setOrder(new OrderModel(response.additionalData));
            } */
            this._router.navigate(['/' + RouteConfigurations.clubOrderConfirmation]);
            // window.location.reload(true);
          } else if ('9288' === response.header.statusCode) {
            this.errorStatusMsg.emit({'msg': this._constants.getBillingPayErrorMessages()['fsaErrorMsg']});
            window.scrollTo(0, 0);
          } else if ('9298' === response.header.statusCode) {
            this.errString = response.header.statusCode;
            this.errorStatusMsg.emit({
                'msg': this._constants.getBillingPayErrorMessages()['prepaidErrorMsg'],
                'msgDetails':this._constants.getBillingPayErrorMessages()['prepaidErrorMsgDtls'],
                'id': 'card-error-id'
              });
            window.scrollTo(0, 0);
          } else {
            this.serviceError.emit(true);
            window.scrollTo(0, 0);
          }
        } else {
          this.serviceError.emit(true);
          window.scrollTo(0, 0);
        }
      },
      (err) => {
        console.error(err);
        this.serviceError.emit(true);
        window.scrollTo(0, 0);
      }
    );
  }

  validateCardDetailsForm() {
    this.formSubmitted = true;
    this.assignErrorClasses(this.cardDetailsForm);
  }

  /* This function will check form fields for errors and assign a class to them
  but only on submit and not on keypress */
  assignErrorClasses(formObj) {
    for (const controlObjKey of Object.keys(formObj.controls)) {
      formObj['controls'][controlObjKey]['visited'] = false;
      if (formObj['controls'][controlObjKey]['errors'] !== null) {
        formObj['controls'][controlObjKey]['custErrors'] = {};
        formObj['controls'][controlObjKey]['errorState'] = true;
        if (formObj['controls'][controlObjKey]['errors']['required']) {
          formObj['controls'][controlObjKey]['custErrors'] = { 'emptyError': true };
        } else {
          if (formObj['controls'][controlObjKey]['errors']['pattern'] || formObj['controls'][controlObjKey]['errors']['email']) {
            formObj['controls'][controlObjKey]['custErrors'] = { 'patternError': true };
          }
        }
      } else {
        formObj['controls'][controlObjKey]['errorState'] = false;
      }
    }
  }

  selectCard(event) {
    this.selectedCard.emit(event.target.selectedIndex);
  }
}
