import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { Component, Input, OnInit } from '@angular/core';
import { TreePath } from '../tree-path.model';
import { TranslocoService } from '@ngneat/transloco';
import { SortEvent } from 'primeng/api';

@Component({
  selector: 'discovery-profile-results-table-statistics',
  templateUrl: './profile-results-table-statistics.component.html',
  styleUrls: ['./profile-results-table-statistics.component.css']
})
export class ProfileResultsTableStatisticsComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, any>;
  cols = [];
  data = [];
  defaultSort: string;
  constructor(private translocoService: TranslocoService) {}

  ngOnInit(): void {
    if (this.treePath.columnView) {
      if (this.statistics['type'] === ProfilingConstants.STATS.FREQUENCY) {
        this.cols = [
          {
            field: 'column',
            header: this.translocoService.translate('discoveryProfiling.results.columnName')
          },
          {
            field: 'count',
            header: this.translocoService.translate('discoveryProfiling.results.countColumn')
          }
        ];
        this.defaultSort = 'count';
      }
      if (this.statistics['type'] === ProfilingConstants.STATS.STRINGLENGTH) {
        this.cols = [
          {
            field: 'length',
            header: this.translocoService.translate('discoveryProfiling.results.lengthColumn')
          },
          {
            field: 'count',
            header: this.translocoService.translate('discoveryProfiling.results.countColumn')
          }
        ];
        this.defaultSort = 'count';
      }
      if (this.statistics['type'] === ProfilingConstants.STATS.SCRIPTPATTERN) {
        this.cols = [
          {
            field: 'script',
            header: this.translocoService.translate('discoveryProfiling.results.scriptColumn')
          },
          {
            field: 'count',
            header: this.translocoService.translate('discoveryProfiling.results.countColumn')
          }
        ];
        this.defaultSort = 'count';
      }
      this.formatFrequency();
    }
  }

  customSort(event: SortEvent) {
    event.data.sort((data1, data2) => {
      let value1 = data1[event.field];
      let value2 = data2[event.field];
      let result = null;
      value1 = this.customTypeCast(value1);
      value2 = this.customTypeCast(value2);

      if (value1 == null && value2 != null) result = -1;
      else if (value1 != null && value2 == null) result = 1;
      else if (value1 == null && value2 == null) result = 0;
      else if (typeof value1 === 'string' && typeof value2 === 'string') result = value1.localeCompare(value2);
      else {
        if (value1 > value2) {
          result = -1;
        } else if (value1 < value2) {
          result = 1;
        } else {
          result = 0;
        }
      }

      return event.order * result;
    });
  }

  private customTypeCast(value) {
    return Number(value) ? Number(value) : value;
  }

  private formatFrequency(): void {
    this.data = [];
    // eslint-disable-next-line guard-for-in
    for (const key in this.statistics['frequency']) {
      const value = this.statistics['frequency'][key];
      if (this.statistics['type'] === ProfilingConstants.STATS.FREQUENCY) {
        this.data.push({
          column: key,
          count: value
        });
      }
      if (this.statistics['type'] === ProfilingConstants.STATS.STRINGLENGTH) {
        this.data.push({
          // convert the key to int since string length is always integer not string.
          length: parseInt(key, 10),
          count: value
        });
      }
      if (this.statistics['type'] === ProfilingConstants.STATS.SCRIPTPATTERN) {
        this.data.push({
          script: key,
          count: value
        });
      }
    }
  }
}
