(function () {
    'use strict';

    angular.module('arm').controller('contactDetailsCtrl', ['$scope', '$state', '$window', '$filter', 'contactService', 'activityService', 'utility', '$ionicScrollDelegate','$timeout','$q','$ionicPopover','$ionicModal','$ionicSideMenuDelegate', 'MASTER_TABLE','GENERAL_CONFIG', contactDetController]);

      function contactDetController($scope, $state, $window, $filter, contactService, activityService,  utility, $ionicScrollDelegate, $timeout, $q,$ionicPopover,$ionicModal,$ionicSideMenuDelegate,MASTER_TABLE,GENERAL_CONFIG) {
        // page title
          $scope.title = "Contacts Details";
          $scope.showCallSmsEmail = true;
        //===============================Code Added by NiTiN========================================
         $scope.$on("$ionicView.beforeEnter", function() {
             if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("deviceready", onDeviceReady, false);
            }
            //  fetch data for details page from get data function witch card type individual or company
            $scope.contactTypeInfo = contactService.constants().contactType;
            $scope.contactTypeVal = contactService.getSelectedContactType();
            // Check for the card type individual or company
            if($scope.contactTypeInfo.Individual == $scope.contactTypeVal){
                $scope.detailsContact =  contactService.getSelectedIndividualContact();
                $scope.showContacts = true; $scope.showCompany = false;
                contactService.setSelectWhathappened(contactService.constants().contactType.Individual);
                $scope.displayContactName = $scope.detailsContact.FirstName + " " + $scope.detailsContact.LastName;
            }else{
                $scope.detailsContact =  contactService.getSelectedCompanyContact();
                $scope.showContacts = false; $scope.showCompany = true;
                contactService.setSelectWhathappened(contactService.constants().contactType.Company);
                $scope.displayContactName = $scope.detailsContact.CompanyName;
                $scope.showCallSmsEmail = false;
            }
            var isRepresentativeFlag = $scope.detailsContact.IsRepresentative;
            //$scope.contactLastDate = $scope.detailsContact.LastContactedDate;
            // add sub array model
            //debugger
            $scope.dynamicFieldType = contactService.constants().dynamicFieldType;
            contactService.getAllSubArrayDataToModel($scope.detailsContact,false);
            //console.log($scope.detailsContact);
            $scope.communicationTypes =  contactService.getCommunicationTypes();
            $scope.correspondenceTypes = utility.getMultLangMasData(MASTER_TABLE.CorTyp);


            // Fetch the activity list and deal list
            $scope.contactActivityList = []; $scope.contactDealList = [];
            contactService.sqlGetPanelData("Activity", $scope.detailsContact.DeviceObjID, isRepresentativeFlag).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.contactActivityList.push(result.rows.item(i));
                    $scope.contactActivityList[i].Priority = utility.getColorCode(result.rows.item(i)['ActivityDate'], result.rows.item(i)['ActivityTime'], result.rows.item(i)['ActivityStageID']);
                    $scope.contactActivityList[i].Notes = [];
                    loadNote(result.rows.item(i)['DeviceObjID'], $scope.contactActivityList[i].Notes);
                }
            });
            contactService.sqlGetPanelData("Deals", $scope.detailsContact.DeviceObjID, isRepresentativeFlag).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.contactDealList.push(result.rows.item(i));
                    var dealStageModelID = utility.dealStageModelIDCheck(result.rows.item(i)['DealStageID']);
                    $scope.contactDealList[i].Priority = utility.getColorCodeForDeals(result.rows.item(i)['ExpectedDealCloseDate'], dealStageModelID);
                }
            });
            $scope.detailsContactInfo = [];
            $scope.detailsContactInfo = [$scope.detailsContact];
         });
        //===============================Code Added by NiTiN========================================
        // details page
         $scope.contactDetails = function (contactObj, objType, repCompany) {
             contactService.setSelectedContactType(objType);
             if ($scope.contactTypeInfo.Individual == objType) {
                 contactService.setSelectedIndividualContact(contactObj);
                 $state.go('tab.repreContactDetails');
             }
         }
        $scope.getCommNameData = function(array,value) {
            var name = '';
            angular.forEach(array, function (obj) {
                if (obj.Value == value) {
                    name = obj.Text;
                }
            });
            return name;
        }
        $scope.getCorrNameData = function(array,value) {
            var name = '';
            angular.forEach(array, function (obj) {
                if (obj.CorrospondanceTypeID == value){
                    name = obj.Text;
                }
            });
            return name;
        };
        $scope.displayEmployerName = function(item) {
            var employerName = "";
            if(item.IsRepresentative== false){
                employerName = item.EmployerName;
            }else{
                employerName = item.CompanyName;
            }
            return employerName;
        }
        $scope.getContactRelations = function(relId) {
            var relationName = "";
            var relationshipType = utility.getMultLangMasData(MASTER_TABLE.RelTyp);
            for(var i=0; i < relationshipType.length; i++){
                var nameRelId = relationshipType[i].ContactRelationshipTypeID;
                if( nameRelId == relId){
                    relationName = relationshipType[i].Name;
                }
            }
            return relationName;
        }
        $scope.getNameValue = function(item) {
            return utility.getNameByOrOwner(item);
        };
        $scope.getNameValueForNote = function(item) {
            return utility.getNameByForNotes(item);
        };
        $scope.toggleGroup = function(group) {
            group.show = !group.show;
        };
        $scope.isGroupShown = function(group) {
            return group.show;
        };
        $scope.getNameValue = function(item) {
            return utility.getNameByOrOwner(item);
      	};

      	$scope.activitiesdetail = function (activitiesId) {
            $scope.selActTypeIndx = -1;
            activityService.setActivity(utility.getObjData($scope.contactActivityList, 'DeviceObjID', activitiesId))
            $state.go('tab.activityDetail', { activitiesId: activitiesId, screenType: 'List' });
        }

        $scope.ActivityPanel = false; $scope.DealsPanel = false; $scope.RelationalPanel = false; $scope.BasicPanel = false;
        $scope.AdditionalPanel = false; $scope.BusinessPanel = false; $scope.OtherPanel = false; $scope.AttachmentPanel = false;
        $scope.togglePanel = function(panelName) {
            if(panelName=="Activity"){
                $scope.ActivityPanel = !$scope.ActivityPanel;
            }else if(panelName=="Notes"){
                $scope.NotesPanel = !$scope.NotesPanel;
            }else if(panelName=="Deals"){
                $scope.DealsPanel = !$scope.DealsPanel;
            }else if(panelName=="Relational"){
                $scope.RelationalPanel = !$scope.RelationalPanel;
            }else if(panelName=="Basic"){
                $scope.BasicPanel = !$scope.BasicPanel;
            }else if(panelName=="Additional"){
                $scope.AdditionalPanel = !$scope.AdditionalPanel;
            }else if(panelName=="Business"){
                $scope.BusinessPanel = !$scope.BusinessPanel;
            }else if(panelName=="Other"){
                $scope.OtherPanel = !$scope.OtherPanel;
            }else if(panelName=="Attachment"){
                $scope.AttachmentPanel = !$scope.AttachmentPanel;
            }
        }

        $scope.openMenu = function () {
            $ionicSideMenuDelegate.toggleLeft();
        }
        $scope.backPage = function () {
            //$window.history.back();
            $state.go('tab.contact');
        }
        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };

        $scope.editTapped = function () {
            $state.go('tab.contactAdd', { editModeFlag: 1});
        };

        // Show image in full width on popup over
        $scope.showImage = function (imgObj) {
            // Check the image in local cache or download the image from server
            if(imgObj.ModuleID == GENERAL_CONFIG.MODULES.Contact){
                var folderName = "contactImages";
            }
            var filename = imgObj.FileName + imgObj.Extension;

            $window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem2) {
                  fileSystem2.getDirectory(folderName, { create: true, exclusive: false }, function (dirEntry) {
                        dirEntry.getFile(filename, {create:false}, function(fileEntry){
                            $scope.showImgModal(imgObj);
                        },function(){
                            contactService.getAttachmentsDownload(imgObj.AttachmentID).then(function (attachmentsRes) {
                                var myImgBase64 = attachmentsRes.Base64String;
                                var contentType = attachmentsRes.MIMEContentType;
                                var actualImage = utility.b64toBlob(myImgBase64,contentType);
                                var dirFolderPath = cordova.file.cacheDirectory + folderName;
                                $window.resolveLocalFileSystemURL(dirFolderPath, function(dir) {
                                    dir.getFile(filename, {create:true}, function(file) {
                                        console.log("File created succesfully.");
                                        file.createWriter(function(fileWriter) {
                                            console.log("Writing content to file");
                                            fileWriter.write(actualImage);
                                            $scope.showImgModal(imgObj);
                                        }, function(){
                                            alert('Unable to save file in path '+ folderpath);
                                        });
                                    });
                                });
                            });
                        });
                  });
            });
        }
        $scope.showImgModal = function(d) {
            $ionicModal.fromTemplateUrl('app/views/common/image-popover.html', function ($ionicModal) {
              $scope.imageModal = $ionicModal;
              $scope.imageSrc = $scope.getImagePath(d);
              $scope.imageModal.show();
            }, {
              // Use our scope for the scope of the modal to keep it simple
              scope: $scope,
              controller: 'contactController',
              // The animation we want to use for the modal entrance
              animation: 'slide-in-up'
            });
        };
        $scope.closeImgModal = function() {
            $scope.imageModal.remove();
        };
        $scope.getImagePath = function(item) {
            var imgPath = cordova.file.cacheDirectory + "contactImages/"+ item.FileName + item.Extension;
            return imgPath;
        };
        /*// Modal filter
        $ionicModal.fromTemplateUrl('app/views/contact/contactFilter.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalcntfilter = modal;
        });
        $scope.openFilter = function () {
            $scope.modalcntfilter.show();
        };
        $scope.closeModalB = function () {
            $scope.modalcntfilter.hide();
        };*/

        // toggle button
        //$scope.fnclickToggle = function (){
        //    $scope.isVisible = ! $scope.isVisible;
        //};
        //$scope.fnswitchToggle = function (){
        //    $scope.isVisible = ! $scope.isVisible;
        //};

          //////////////////CALL/SMS/EMAIL//////////////////
        $scope.screenType = GENERAL_CONFIG.ScreenType.ContactDetail;
        $scope.selActTypeIndx = -1;
        $scope.fnclickToggle = function ($index, actStageId) {
            if (actStageId > 1) return;
            $scope.selActTypeIndx = $index;
        };

        $scope.fnswitchToggle = function ($index) {
            $scope.selActTypeIndx = -1;
        };
           $scope.openActivityType = function (type, activitiesID, stageId, ConDevId) {
            if (stageId > GENERAL_CONFIG.ActivityStage.Open) {
                return;
            }
            activityService.sqlGetCommnications(ConDevId).then(function (result) {
                var comArr = contactService.getAllComData(result);
                $scope.phone = comArr.mobilePhone;
                $scope.email = comArr.email;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                $scope.screenType = GENERAL_CONFIG.ScreenType.ContactDetailActivity;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                if (type == 1) {
                    $scope.callNumber(activitiesID);
                }
                else if (type == 3) {//sms
                    $scope.openSMS(activitiesID);
                }
                else if (type == 4) {//email
                    $scope.openEmail(activitiesID);
                }
            });

        }

        function onDeviceReady() {
            // Register the event listener
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("resume", onEndCallKeyDown, false);
            }
        }

        $scope.count = 0;
        $scope.devID = 0;
        $scope.startDt;
        function onEndCallKeyDown() {
            if ($scope.count >= 1) return;
            if ($scope.type != 'Call') return;
            $scope.count++;
            var endDt = new Date();
            checkTime($scope.startDt, endDt);
        }

        function checkTime(startDt, endDt) {
            var dif = endDt.getTime() - startDt.getTime();
            var difDt = dif / 1000;
            var finalDifDate = Math.abs(difDt);
            if (finalDifDate >= 15) {
                $scope.openHappend('D', $scope.devID, $scope.type);
            }
        }

        $scope.openActType = function (type) {
            $scope.showCallSmsEmail = true;
            activityService.sqlGetCommnications($scope.detailsContact.DeviceObjID).then(function (result) {
                var comArr = contactService.getAllComData(result);
                $scope.phone = comArr.mobilePhone;
                $scope.email = comArr.email;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                $scope.screenType = GENERAL_CONFIG.ScreenType.ContactDetail;
                if (type == 1) {
                    $scope.callNumber($scope.detailsContact.DeviceObjID);
                }
                else if (type == 3) {//sms
                    $scope.openSMS($scope.detailsContact.DeviceObjID);
                }
                else if (type == 4) {//email
                    $scope.openEmail($scope.detailsContact.DeviceObjID);
                }
            });
        }

        $scope.openSMS = function (devId) {
            $scope.count = 0;
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined') {
                alert("Phone number is not configured for this contact.");
                return true;
            }
            var message = '';//'hello text';
            //console.log("going to send " + message + " to " + number);

            //simple validation for now
            //if (number === '' || message === '') return;

            var msg = {
                phoneNumber: number,
                textMessage: message
            };
            //CONFIGURATION
            var options = {
                replaceLineBreaks: false, // true to replace \n by a new line, false by default
                android: {
                    intent: 'INTENT'  // send SMS with the native android SMS messaging
                    //intent: '' // send SMS without open any other app
                }
            };

            var success = function (res) {
                var s = res;
                $scope.type = 'SMS';
                $scope.openHappend('D', devId, 'SMS');
                //if(s == 'ok')
                //alert('Message sent successfully');
            };

            var error = function (e) { console.log('Message Failed:' + e); };
            sms.send(number, message, options, success, error);
        }

        $scope.openEmail = function (devId) {
            $scope.count = 0;
            $scope.type = 'EMAIL';

            cordova.plugins.email.open({
                to: $scope.email,
                cc: '',
                bcc: [''],
                subject: 'Greetings',
                body: 'test mail'
            });
            $scope.openHappend('D', devId, 'Email');
        }

        $scope.callNumber = function (devId) {
            var number =  $scope.phone ;
            if (number == '' || typeof number == 'undefined') {
                alert("Phone number is not configured for this contact.");
                return true;
            }
            window.plugins.CallNumber.callNumber(function () {
                if (window.cordova && ionic.Platform.isAndroid()) {
                    $scope.startDt = new Date();
                    $scope.type = 'Call';
                    $scope.devID = devId;
                    $scope.count = 0;
                }
                else {
                    $scope.openHappend('D', devId, 'Call');
                }
            }, function () {
                console.log("eroor");
                //error logic goes here
            }, number)
        };

        $scope.openHappend = function (val, devId, actType) {
            activityService.setActStatus('C');
            if ($scope.screenType == GENERAL_CONFIG.ScreenType.ContactDetailActivity)
                activityService.setActivity(utility.getObjData($scope.contactActivityList, 'DeviceObjID', activitiesId));
            $state.go('tab.activityHappen', { devObjId: devId, actStatgeType: val, screenType: $scope.screenType, actType: actType });
        };

        function loadNote(actId, objNote) {
            activityService.sqlGetNote(actId).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    objNote.Description = result.rows.item(i)['Description'];
                }
            });
        }
        /////////////////CALL/SMS/EMAIL////////END///////////////////////

    };

})();
