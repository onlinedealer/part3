import { Component } from "@angular/core";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { RegisterVO } from "../../../models/view-objects/register-vo.model";
import { TranslationsService } from "../../../../app/services/translations-service";
import { Configuration } from "../../../models/configuration.model";
import { map } from "rxjs/operators";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import * as MeterConnectionSelectors from "../../../store/selectors/meterconnections.selectors";
import * as RegistersSelectors from "../../../store/selectors/registers.selectors";
import * as ConfigurationsSelectors from "../../../store/selectors/configurations.selectors";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { MeteringsSelectors } from "../../../store/selectors";

@Component({
    selector: "landisgyr-ss-registers",
    templateUrl: "./ss-registers.component.html",
    styleUrls: ["./ss-registers.component.scss"]
})
export class SSRegistersComponent {
    selectedMeterSerialNumber$ = this.store
        .select(MeterConnectionSelectors.getSelectedMeterConnection)
        .pipe(
            map((meterConnection) =>
                meterConnection && meterConnection.deviceMeter ? meterConnection.deviceMeter.meterSerialNumber + "" : ""
            )
        );
    loading$: Observable<boolean> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);
    tableDataLoading$: Observable<boolean> = this.store.select(RegistersSelectors.getRegistersLoading);
    refreshDataLoading$: Observable<boolean> = this.store.select(RegistersSelectors.getRegistersLoading);
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    registers$: Observable<RegisterVO[]> = this.store.select(RegistersSelectors.getSelectedMeterConnectionRegistersEntitiesForTable);
    configurations$: Observable<Configuration[]> = this.store.select(ConfigurationsSelectors.getSelectedMeterConnectionConfigurations);

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {}
}
