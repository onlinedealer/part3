import { HttpClient, HttpContext, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

/**
 * Abstract class that provides basic CRUD endpoints
 * Any service that interacts with an API endpoint should extend this base service
 */
export abstract class BaseApiService<T> {
  constructor(protected httpClient: HttpClient, environmentBaseUrl: string, protected url?: string) {
    this.environmentBaseUrl = environmentBaseUrl;
    if (url) {
      this.baseUrl = `${this.environmentBaseUrl}/${url}`;
    }
  }

  private environmentBaseUrl = '';
  private baseUrl = '';

  public get serviceURL() {
    return this.baseUrl;
  }

  public set serviceURL(url: string) {
    this.baseUrl = `${this.environmentBaseUrl}/${url}`;
  }

  create(item: T, params?: { [key: string]: string }) {
    const options = { params: null };
    if (params) {
      options.params = new HttpParams({ fromObject: params });
    }
    return this.httpClient.post(`${this.baseUrl}/create`, item, options);
  }

  get(id: string, headers?: HttpHeaders): Observable<T> {
    return this.httpClient.get<T>(`${this.baseUrl}/${id}`, { headers }).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  getByName(name: string) {
    return this.httpClient.get<T>(`${this.baseUrl}/by-name/${name}`).pipe(
      map((response: any) => {
        return response;
      })
    );
  }

  getAll(params?: { [key: string]: string }, context?: HttpContext): Observable<T[]> {
    const options = { params: null, context };
    if (params) {
      options.params = new HttpParams({ fromObject: params });
    }
    return this.httpClient.get<T[]>(`${this.baseUrl}`, options).pipe(
      map((response: any) => {
        const content = response.content || response;
        return content.map((item: T) => {
          return item;
        });
      })
    );
  }

  getFirst(): Observable<T> {
    return this.httpClient.get<T[]>(`${this.baseUrl}`).pipe(
      map((response: any) => {
        const content = response.content || response;
        const items = content.map((item: T) => {
          return item;
        });

        return items[0];
      })
    );
  }

  /**
   * Update Pipeline
   * @param item - All form parameters
   * @param {boolean} addUpdateToPath - to be used for forming the url
   * @param {boolean} isFeatureEnabled - a placeholder param to be used to handle conditions for feature flags.
   * By default it is false
   * @returns {Observable<any>}
   */
  update(item: any, addUpdateToPath = false, isFeatureEnabled = false): Observable<any> {
    // We have to set the default parameters in order to pass the API requirements.
    // However, these params are not considered when dataflow.xml is being generated for the execution.
    // The tableMapping array takes precedence and all these defaults are ignored.
    this.settingDefaultTableMappingParams(item);
    let url = `${this.baseUrl}/${item.id}`;
    if (addUpdateToPath) {
      url += '/update';
    }
    return this.httpClient.put(url, item);
  }

  settingDefaultTableMappingParams(item) {
    // item.target only comes when we edit the pipeline
    if (!item.target) {
      return;
    }
    for (let i = 0; i < item.target.parameters?.length; i++) {
      if (item.target?.parameters[i]?.key === 'MAP_TABLES') {
        item.target.parameters[i].value = 'ONE_TABLE_ONE_TOPIC';
      } else if (
        (item.target?.parameters[i]?.value === undefined && item.target?.parameters[i]?.key === 'PARTITION_MESSAGES_BY') ||
        item.target?.parameters[i]?.key === 'USE_EXISTING_TOPIC'
      ) {
        item.target.parameters.splice(i, 1);
        this.settingDefaultTableMappingParams(item);
      } else if (item.target?.parameters[i]?.key === 'PREFIX_MESSAGES_WITH_TABLENAME') {
        item.target.parameters[i].value = 'false';
      }
    }
    return item;
  }

  delete(ids: string[]): Observable<any> {
    const options = {
      body: ids
    };
    return this.httpClient.request('delete', `${this.baseUrl}/delete`, options);
  }
}
