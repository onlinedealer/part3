import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { environment } from 'src/environments/environment';
import { Bundle, LogFileMetadata } from './bundles';
import { BundlesApiService } from './bundles-api.service';

describe('BundlesApiService', () => {
  let service: BundlesApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(BundlesApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get project logs metadata', () => {
    const responseData = { logMetadataList: { serverMetadataList: [] } } as LogFileMetadata;

    const projectId = '1';
    const url = `${environment.connectApiBaseURL}/cdc/monitoring/${projectId}/logs`;

    service.getLogsFileMetadata({ id: '1' } as Project).subscribe((response) => {
      expect(response).toEqual(responseData);
    });

    const req = httpMock.expectOne(url);
    expect(req.request.method).toEqual('POST');
    req.flush(responseData);
    httpMock.verify();
  });

  it('should create bundle', () => {
    const responseData = 'test-bundle';

    const projectId = '1';
    const bundleName = 'test-bundle';
    const bundleDescription = 'testdescription';
    const url = `${environment.connectApiBaseURL}/cdc/monitoring/bundles/full/start?projectId=${projectId}&bundleName=${bundleName}&description=${bundleDescription}`;

    service.createBundle('1', 'test-bundle', 'testdescription', {} as LogFileMetadata).subscribe((response) => {
      expect(response).toEqual(responseData);
    });

    const req = httpMock.expectOne(url);
    expect(req.request.method).toEqual('POST');
    req.flush(responseData);
    httpMock.verify();
  });

  it('should get list of bundles', () => {
    const responseData = [{ bundleName: 'test' }] as Bundle[];

    const url = `${environment.connectApiBaseURL}/cdc/monitoring/bundles`;

    service.getBundles().subscribe((response) => {
      expect(response).toEqual(responseData);
    });

    const req = httpMock.expectOne(url);
    expect(req.request.method).toEqual('GET');
    req.flush(responseData);
    httpMock.verify();
  });

  it('should stop the bundles', () => {
    const expectedRequestMethod = 'POST';
    const expectedEndpointUrl = `${environment.connectApiBaseURL}/cdc/monitoring/bundles/stop`;
    const ids = ['1', '2', '3'];
    let actualResponse;

    service.stopBundle(ids).subscribe((response) => {
      actualResponse = response;
    });

    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should delete the bundles', () => {
    const expectedRequestMethod = 'DELETE';
    const expectedEndpointUrl = `${environment.connectApiBaseURL}/cdc/monitoring/bundles/delete`;
    const ids = ['1', '2', '3'];
    let actualResponse;

    service.deleteBundle(ids).subscribe((response) => {
      actualResponse = response;
    });

    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });
});
