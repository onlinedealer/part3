import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EntityCardComponent } from './entity-card.component';

describe('EntityCardComponent', () => {
  let component: EntityCardComponent;
  let fixture: ComponentFixture<EntityCardComponent>;

  beforeEach(() => {
    component = new EntityCardComponent();
  });

  it('can load instance', () => {
    expect(component).toBeTruthy();
  });

  it(`showFilter has default value`, () => {
    expect(component.showFilter).toEqual(true);
  });

  it(`allowSelection has default value`, () => {
    expect(component.allowSelection).toEqual(true);
  });

  it('should call updateRowStyle method', () => {
    const mockEvent = { type: 'click', target: { classList: [] } };
    const mockRowData = { library: 'sales', selected: 21 };
    spyOn(component, 'updateRowStyle');
    component.rowSelection(mockEvent, mockRowData);
    expect(component.updateRowStyle).toHaveBeenCalled();
  });

  it('should call checkBoxSelection method', () => {
    const mockEvent = { type: 'checkbox' };
    const mockRowData = { tables: 'customers', journal: 'qauser1/qsqcjrn' };
    spyOn(component, 'checkBoxSelection');
    component.rowSelection(mockEvent, mockRowData);
    expect(component.checkBoxSelection).toHaveBeenCalled();
  });

  it('should call checkBoxSelection method for tri-state checkbox', () => {
    component.headers = [];
    component.showTriState = true;

    const mockEvent = {
      data: {},
      originalEvent: {
        stopPropagation: () => {},
        stopImmediatePropagation: () => {},
        preventDefault: () => {}
      }
    };
    const mockRowData = { tables: 'customers', journal: 'qauser1/qsqcjrn' };
    spyOn(component.dataSelected, 'emit');
    component.checkBoxSelection(mockEvent, mockRowData);
    expect(component.dataSelected.emit).toHaveBeenCalled();
  });

  it('should call updateRowStyle method on row click', () => {
    component.isLoading = true;
    component.allowSelection = true;
    component.headers = [
      { fieldName: 'libraries', displayName: 'Libraries' },
      { fieldName: 'selected', displayName: 'Selected' }
    ];
    component.keyField = 'libraries';
    component.rowHover = true;
    component.scrollHeight = '250px';
    component.apiData = [
      { libraries: 'SALES', selected: 21 },
      { libraries: 'FINANCIAL', selected: 18 }
    ];
    component.isLoading = false;
    component.headerText = 'Sample Header';
    component.showFilter = false;
    // const targetElement: HTMLElement = document.querySelector('tbody tr:first-child td:first-child');
    // if (targetElement) {
    //   targetElement.click();
    //   spyOn(component, 'rowSelection');
    //   expect(component.rowSelection).toHaveBeenCalled();
    // }
    expect(component.apiData).toBeDefined();
  });

  it('should run updateRowStyle method and emit event', () => {
    const mockTableRow1 = document.createElement('tr');
    const mockTableRow2 = document.createElement('tr');
    const childElement = document.createElement('td');
    mockTableRow1.appendChild(childElement);
    mockTableRow2.appendChild(childElement);
    const mockEvt = {
      target: {
        parentElement: {
          parentElement: {
            querySelectorAll: (inp: string) => [mockTableRow1, mockTableRow2]
          },
          classList: {
            add: (inp: string) => {},
            remove: (input: string) => {}
          }
        }
      }
    };
    spyOn(component.rowSelected, 'emit');
    const mockRowData = { tables: 'sales', selected: 18 };
    component.updateRowStyle(mockEvt, mockRowData);
    expect(component.rowSelected.emit).toHaveBeenCalled();
  });

  it('should checkbox selection emit appropriate event', () => {
    spyOn(component.dataSelected, 'emit');
    component.headers = [];
    component.showTriState = false;
    const mockEvent = {
      data: {},
      originalEvent: {
        stopPropagation: () => {},
        stopImmediatePropagation: () => {},
        preventDefault: () => {}
      }
    };
    component.checkBoxSelection(mockEvent);
    expect(component.dataSelected.emit).toHaveBeenCalled();
  });

  it('should checkbox un-select emit appropriate event', () => {
    spyOn(component.dataUnselected, 'emit');
    const mockEvent = {
      data: {},
      originalEvent: {
        stopPropagation: () => {},
        stopImmediatePropagation: () => {},
        preventDefault: () => {}
      }
    };
    component.checkBoxUnselect(mockEvent);
    expect(component.dataUnselected.emit).toHaveBeenCalled();
  });

  it('should checkbox un-select emit appropriate event when original event is missing', () => {
    spyOn(component.dataUnselected, 'emit');
    const mockEvent = {
      data: {},
      stopPropagation: () => {},
      stopImmediatePropagation: () => {},
      preventDefault: () => {}
    };
    component.checkBoxUnselect(mockEvent);
    expect(component.dataUnselected.emit).toHaveBeenCalled();
  });

  it('should filter text not be empty', () => {
    component.dataTable = jasmine.createSpyObj(['filterGlobal']);
    const searchString = 'test1';
    component.filterData(searchString);
    expect(component.dataTable.filterGlobal).toHaveBeenCalled();
  });

  it('should emit select all event', () => {
    component.headers = [];
    component.showTriState = false;
    spyOn(component.selectAllRows, 'emit');
    const mockEvent = {};
    component.selectAll(mockEvent);
    expect(component.selectAllRows.emit).toHaveBeenCalled();
  });

  it('should change the rowData selected value of tri-state change as per the selection', () => {
    const mockTriStateEvent = true;
    const mockRowData = { selected: false };
    component.triStateChange(mockTriStateEvent, mockRowData);
    expect(mockRowData.selected).toBeTruthy();
  });
});
