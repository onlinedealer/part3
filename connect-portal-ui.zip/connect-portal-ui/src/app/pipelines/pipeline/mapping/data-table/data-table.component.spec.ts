import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { TableConfiguration } from 'src/app/shared/components/generic-table/generic-table';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { DataTableComponent } from './data-table.component';
import { Component } from '@angular/core';
import { FeatureFlagService } from 'src/app/shared/services/feature-flag.service';
import { ColumnMappingSidebarComponent } from './column-mapping-sidebar/column-mapping-sidebar.component';
import { PipelineService } from '../../pipeline.service';
import { TableModule } from 'primeng/table';
import { ChangeColumnMappingSidebarComponent } from '../change-mapping/change-column-mapping/change-column-mapping-sidebar.component';
import { PipelineMappingService } from '../pipeline-mapping.service';
import { Observable, of, throwError } from 'rxjs';

describe('DataTableComponent', () => {
  let component: DataTableComponent;
  let fixture: ComponentFixture<DataTableComponent>;
  let featureFlagService: FeatureFlagService;
  let pipelineService: PipelineService;
  let pipelineMappingService: PipelineMappingService;

  const mockPipelineMappingService = {
    getChangeColumnMappingDefaults: () => {},
    getMappingIcon: () => {},
    checkIfButtonDisabled: () => {},
    saveTableMapping: () => {}
  };
  const mockColumns = [
    { name: 'Keylex', dataType: 'long', isPrimaryKey: false },
    { name: 'Cardguard', dataType: 'double', isPrimaryKey: false }
  ];
  const defaultMockData = [
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'EXCLUDE',
      isChecked: true
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true
    }
  ];

  let mockDialogService = jasmine.createSpyObj('PipelineMappingService', ['closeAll']);
  mockDialogService.refs = [];
  @Component({
    selector: 'p-connect-column-mapping-sidebar',
    template: '',
    providers: [
      {
        provide: ColumnMappingSidebarComponent,
        useClass: MockSidebarComponent
      },
      {
        provide: ChangeColumnMappingSidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    messageType: string;
    open() {}
    parseHttpClientResponseMessage() {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, TableModule],
      declarations: [DataTableComponent, MockSidebarComponent],
      providers: [{ provide: PipelineMappingService, useValue: mockPipelineMappingService }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DataTableComponent);
    pipelineService = TestBed.inject(PipelineService);
    component = fixture.componentInstance;
    featureFlagService = TestBed.inject(FeatureFlagService);
    pipelineMappingService = TestBed.inject(PipelineMappingService);
    spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
    component.tableConfiguration = {
      fields: [],
      tableMessages: {},
      rowAction: {
        fieldIndex: 0,
        menuItems: [{ id: '1', label: 'test' }]
      }
    } as TableConfiguration;
    component.patchPipeline = () => {};
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should handle special characters input on topic input change', () => {
    component.filteredTargets = [];
    component.topics = ['topic'];
    component.data = [
      {
        topic: {
          name: 't!'
        }
      }
    ];
    const event = { query: 't!' };
    component.filterTarget(event);
    expect(component.filteredTargets.length).toBe(0);
  });

  it('should have "filterTarget()" pushing data', () => {
    component.filteredTargets = [];
    component.topics = ['topic'];
    component.data = [
      {
        topic: {
          name: 't'
        }
      }
    ];
    const event = { query: 't' };
    component.filterTarget(event);
    expect(component.filteredTargets.length).toBe(1);
  });

  it('should filter subject as per input', () => {
    component.filteredTargets = [];
    component.subjects = ['subject'];
    const event = { query: 's' };
    component.filterSubject(event);
    expect(component.filteredSubjects.length).toBe(1);
  });

  it('should change mapping icon to blue select from dropdown and the element is not equal to table', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: ' ',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    const event = { query: 't' };
    component.topics = ['t'];
    component.subjects = ['s'];
    component.isSchemaRegistryThere = true;
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ATTENTION_BLUE',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onSelectTopic(row, event);
    expect(row.topic.mappingIcon).toEqual('ATTENTION_BLUE');
  });

  it('should change mapping icon to yellow when the topic is not there in topics array', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    const event = 'Table_topic';
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ATTENTION',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onSelectTopic(row, event);
    expect(row.topic.mappingIcon).toEqual('ATTENTION');
  });

  it('should handle mappingIcon when a subject is selected', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: 'topic1',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        name: 'sub',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    const event = 'sub1';
    component.subjects = ['sub1'];
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ATTENTION',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onSelectSubject(row, event);
    expect(row.subject.mappingIcon).toEqual('ATTENTION');
  });

  it('should handle key change when no new input provided', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    component.isSchemaRegistryThere = true;
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ACTION_REQUIRED',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onManualInputTopic(row, '');
    expect(row.topic.mappingIcon).toEqual('ACTION_REQUIRED');
  });

  it('should call saveTableMapping API', () => {
    const saveTableSpy = spyOn(pipelineMappingService, 'saveTableMapping').and.returnValue(of(Observable));
    component.saveTableMappings();
    expect(component.spinnerForChangeColumnMapping).toBe(false);
    expect(saveTableSpy).toHaveBeenCalled();
  });

  it('should handle subject manual change when no new input provided', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    const event = { target: { value: '' } };
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ACTION_REQUIRED',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onManualInputSubject(row, event);
    expect(row.subject.mappingIcon).toEqual('ACTION_REQUIRED');
  });

  it('should handle subject manual change when new input provided', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    const event = { target: { value: 'sub' } };
    component.subjects = ['sub'];
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ATTENTION',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onManualInputSubject(row, event);
    expect(row.subject.mappingIcon).toEqual('ATTENTION');
  });

  it('should handle mappingIcon when a value is there but not matching the topics Array', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: ' ',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    component.isSchemaRegistryThere = true;
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ATTENTION',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onManualInputTopic(row, 'topic');
    expect(row.topic.mappingIcon).toEqual('ATTENTION');
  });

  it('should handle mappingIcon when a value is there and matching the topics Array', () => {
    component.topics = ['topic'];
    component.subjects = ['sub'];
    const row = {
      schema: 'Uxtesting1',
      table: 'topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    component.isSchemaRegistryThere = true;
    component.onManualInputTopic(row, 'topic');
    expect(row.topic.mappingIcon).toEqual('');
  });

  it('should handle mappingIcon when a value is there and matching the topics Array but not matching the table name', () => {
    component.topics = ['topic'];
    const row = {
      schema: 'Uxtesting1',
      table: 'topics',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      },
      subject: {
        mappingIcon: ''
      }
    };

    component.isSchemaRegistryThere = true;
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ATTENTION_BLUE',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.onManualInputTopic(row, 'topic');
    expect(row.topic.mappingIcon).toEqual('ATTENTION_BLUE');
  });

  it('should open Column Mapping sidebar when map columns is clicked', fakeAsync(() => {
    const openSidebar = spyOn(component.columnMappingSidebar, 'open');
    const rowData = { topic: { mappingIcon: '' } };
    component.open(rowData);
    expect(openSidebar).toHaveBeenCalledWith(rowData);
  }));

  it('should handle next event in Ngoninit', () => {
    component.ngOnInit();
    component.data = [
      {
        schema: 'Uxtesting1',
        table: 'Table_topic',
        topic: {
          name: '',
          mappingIcon: '',
          iconTooltip: '',
          class: ''
        },
        subject: {
          name: '',
          class: ''
        }
      }
    ];
    component.updateTextBox();
    expect(component.data[0].topic.class).toBe('danger');
  });

  it('should emit selected Data to parent', () => {
    spyOn(component.emitSelectedSourceData, 'emit');
    component.emitSelectedData();
    expect(component.emitSelectedSourceData.emit).toHaveBeenCalled();
  });

  it('should emit send selected source data to parent to enable or disable Reset to Default buttons', () => {
    spyOn(component.enableRestToDefaultBtn, 'emit');
    component.resetDefaultChecked();
    expect(component.enableRestToDefaultBtn.emit).toHaveBeenCalled();
  });

  it('should reset selected source data', () => {
    component.resetSelectedSourceData();
    expect(true).toBeTrue();
  });

  it('should filter Table data on the basis other columns', () => {
    const event = {
      target: { value: '' }
    };
    const column = 'topic';
    component.filterColumn(event, column);
    expect(component.data.length).toBe(0);
  });

  it('should filter Table data on the basis of Target column', () => {
    const event = {
      target: { value: '' }
    };
    const column = 'topic';
    component.targetColumnField = ['topic'];
    component.filterColumn(event, column);
    expect(component.data.length).toBe(0);
  });

  it('should duplicate row on clicking add icon', () => {
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    const index = 1;
    spyOn(pipelineMappingService, 'getMappingIcon').and.returnValue({
      icon: 'ACTION_REQUIRED',
      tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
    });
    component.dupRow(row, index);
    expect(component.data.length).toBe(1);
  });

  it('should remove row on clicking remove icon', () => {
    const index = 1;
    component.removeRow(index);
    expect(component.data.length).toBe(0);
  });

  it('should enable the mapping columns button if something is typed into autocomplete', () => {
    const row = { topic: { name: 'someName' }, isButtonEnabled: false };
    component.ngModelChange(row);
    expect(row.isButtonEnabled).toBe(true);
  });

  it('should not enable the mapping columns button if nothing is typed into autocomplete', () => {
    const row = { topic: { name: '' }, isButtonEnabled: true };
    component.ngModelChange(row);
    expect(row.isButtonEnabled).toBe(false);
  });

  it('should call changeColumnMapping get Defaults API and check all meta data', () => {
    const mockRowMetaData = {
      cdcRowMetadatas: [{ key: 'METADATA_USER_ID', value: 'sv_trans_username', cdcRowMetadataType: 'INCLUDE' }]
    };
    const getDefaults = spyOn(pipelineMappingService, 'getChangeColumnMappingDefaults').and.returnValue(of(mockRowMetaData));
    component.rowMetaDataAllcheck = 1;
    component.openChangeColumnMappingSideBar();
    expect(getDefaults).toHaveBeenCalled();
  });

  it('should call changeColumnMapping get Defaults API and uncheck all meta data', () => {
    const mockRowMetaData = {
      cdcRowMetadatas: [
        { key: 'METADATA_USER_ID', value: 'sv_trans_username', cdcRowMetadataType: 'EXCLUDE' },
        { key: 'METADATA_USER_ID', value: 'sv_trans_username', cdcRowMetadataType: 'EXCLUDE' }
      ]
    };
    const getDefaults = spyOn(pipelineMappingService, 'getChangeColumnMappingDefaults').and.returnValue(of(mockRowMetaData));
    component.rowMetaDataAllcheck = 2;
    component.openChangeColumnMappingSideBar();
    expect(getDefaults).toHaveBeenCalled();
  });

  it('should show error message on sidebar when getChangeColumnMappingDefaults API fail', () => {
    const error = { detailedMessage: 'something failed' };
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      open: () => {},
      parseHttpClientResponseMessage: () => {}
    });
    const getDefaults = spyOn(pipelineMappingService, 'getChangeColumnMappingDefaults').and.returnValue(throwError(error));
    component.rowMetaDataAllcheck = 1;
    component.openChangeColumnMappingSideBar();
    expect(getDefaults).toHaveBeenCalled();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should update tableMappings when there is hasCustomColMappings change', () => {
    const event = { rowId: 'test', hasCustomColMappings: true };
    component.data = [
      {
        id: 'test'
      }
    ];
    component.updatedTableMapping(event);
    expect(component.data[0].hasCustomColMappings).toBeTruthy();
  });

  it('should trigger onManualInputTopic with clipboard values', () => {
    spyOn(component, 'onManualInputTopic');
    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    component.onManualInputTopic(row, 'pastedValue');
    expect(component.onManualInputTopic).toHaveBeenCalled();
  });

  it('should trigger onPasteTopic', () => {
    spyOn(component, 'onManualInputTopic');

    const row = {
      schema: 'Uxtesting1',
      table: 'Table_topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    var dT = null;
    try {
      dT = new DataTransfer();
    } catch (e) {}
    var evt = new ClipboardEvent('paste', { clipboardData: dT });
    evt.clipboardData.setData('text/plain', 'Value');
    let pastedText = evt.clipboardData.getData('text/plain');
    component.onPasteTopic(row, evt);
    component.onManualInputTopic(row, pastedText);
    expect(pastedText).toBe('Value');
  });

  it('should open discard warning dialog when custom column mappings exist and subject is changed to another subject that exists', () => {
    component.checkingData = [{ id: 'mapping_abc1', hasCustomColMappings: true, subject: { name: 'abc', mappingIcon: 'ATTENTION_BLUE' } }];
    const row = { id: 'mapping_abc1', hasCustomColMappings: true, subject: { name: 'def', mappingIcon: 'ATTENTION_BLUE' } };
    expect(component.isDiscardScenario(row)).toBeTrue();
  });

  it('should not open discard warning dialog when changing to non-existing subject', () => {
    component.checkingData = [{ id: 'mapping_abc1', hasCustomColMappings: true, subject: { name: 'abc', mappingIcon: 'ATTENTION_BLUE' } }];
    const row = { id: 'mapping_abc1', hasCustomColMappings: true, subject: { name: 'def', mappingIcon: 'ATTENTION' } };
    expect(component.isDiscardScenario(row)).toBeFalse();
  });
});
