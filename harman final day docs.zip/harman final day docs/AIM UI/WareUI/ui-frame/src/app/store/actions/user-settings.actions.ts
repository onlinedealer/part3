import { createAction, props } from "@ngrx/store";
import { MeteringPointsSearchSettings } from "../reducers/user-settings.reducer";
import { ChangeUiConfigurationSettingsPayload } from "./configurations.actions";

export const GetUserSettingsConfiguration = createAction("[User settings] Get User Setting Configurations");

export const GetUserSettings = createAction("[User Settings] Get User Settings");
export const GetUserSettingsFail = createAction(
    "[User Settings] Get User Settings Fail",
    props<{
        error: any;
    }>()
);
export const GetUserSettingsSuccess = createAction("[User Settings] Get User Settings Success", props<{ userSettings: any }>());

export const UpdateUserSettings = createAction("[User Settings] Update User Settings", props<{ userSettings: any }>());
export const UpdateUserSettingsFail = createAction(
    "[User Settings] Update User Settings Fail",
    props<{
        error: any;
    }>()
);
export const UpdateUserSettingsSuccess = createAction("[User Settings] Update User Settings Success", props<{ userSettings: any }>());

export const GetMeteringPointsSearchSettings = createAction("[User Settings] Get MeteringPoints Search Settings");
export const GetMeteringPointsSearchSettingsFail = createAction(
    "[User Settings] Get MeteringPoints Search Settings Fail",
    props<{
        error: any;
    }>()
);
export const GetMeteringPointsSearchSettingsSuccess = createAction(
    "[User Settings] Get MeteringPoints Search Settings Success",
    props<{ mpSearchSettings: any }>()
);

export const SetMeteringPointsSearchSettings = createAction(
    "[User Settings] Set MeteringPoints Search Settings",
    props<{ meteringPointsSearchSettings: MeteringPointsSearchSettings }>()
);
export const UpdateMeteringPointsSearchSettings = createAction(
    "[User Settings] Update Metering Points Search Settings",
    props<{ mpSearchSettings: any }>()
);

export const UpdateMeteringPointsSearchSettingsSuccess = createAction(
    "[User Settings] Update Metering Points Search Settings Success",
    props<{ mpSearchSettings: any }>()
);

export const SetUserProfileSetting = createAction(
    "[User Settings] Set User Profile Settings",
    props<ChangeUiConfigurationSettingsPayload>()
);
