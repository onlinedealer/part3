import { TestBed, inject } from '@angular/core/testing';

import { AjaxUtilityService } from './ajax-utility.service';

describe('AjaxUtilityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [AjaxUtilityService]
    });
  });

  it('should be created', inject([AjaxUtilityService], (service: AjaxUtilityService) => {
    expect(service).toBeTruthy();
  }));
});
