import { environment } from "../../environments/environment";
import { fromEvent, merge, Subscription, Subject } from "rxjs";
import { Injectable, OnDestroy } from "@angular/core";
import { isString } from "lodash";
import { LocalStorageService } from "./local-storage.service";
import { State } from "../store/reducers";
import { Store } from "@ngrx/store";
import { throttleTime, withLatestFrom, filter } from "rxjs/operators";
import * as SecurityActions from "../store/actions/security.actions";
import * as SecuritySelectors from "../store/selectors/security.selectors";

@Injectable({
    providedIn: "root"
})
export class SessionActivityService implements OnDestroy {
    TIMEOUT_TO_SHOW_DIALOG = 1000 * environment.uam_timeout_in_seconds_to_show_session_expiring_dialog;

    mousemoveEvents$ = fromEvent(document, "mousemove");
    mousedownEvents$ = fromEvent(document, "mousedown");
    keypressEvents$ = fromEvent(document, "keypress");
    touchmoveEvents$ = fromEvent(document, "touchmove");

    storeActionsSubject: Subject<any> = new Subject();
    storeActions$ = this.storeActionsSubject.asObservable();

    isUserAndSessionLoaded$ = this.store.select(SecuritySelectors.isUserAndSessionLoaded);
    showingTimeoutDialog$ = this.store.select(SecuritySelectors.isShowingTimeoutDialog);

    timeoutId!: ReturnType<typeof setTimeout>;

    activity$ = merge(this.mousemoveEvents$, this.mousedownEvents$, this.keypressEvents$, this.touchmoveEvents$, this.storeActions$).pipe(
        withLatestFrom(this.showingTimeoutDialog$, this.isUserAndSessionLoaded$),
        filter(([events, showingTimeoutDialog, isUserAndSessionLoaded]) => !showingTimeoutDialog && isUserAndSessionLoaded),
        throttleTime(5000)
    );

    activityEventsSubscription!: Subscription;

    constructor(private store: Store<State>, private localStorageService: LocalStorageService) {
        this.startTrackingMouseAndKeyboardEventsAndStoreActions();
    }

    startTrackingMouseAndKeyboardEventsAndStoreActions() {
        this.activityEventsSubscription = this.activity$.subscribe(() => this.setActivityTimestamp());
    }

    storeActionOccurred() {
        this.storeActionsSubject.next();
    }

    setActivityTimestamp() {
        this.clearTimer();

        this.localStorageService.setActivityTimestamp();

        this.setTimer();
    }

    clearTimer() {
        if (this.timeoutId) {
            clearTimeout(this.timeoutId);
        }
    }

    setTimer(timeout = this.TIMEOUT_TO_SHOW_DIALOG) {
        this.timeoutId = setTimeout(() => this.checkTimeout(), timeout);
    }

    checkTimeout() {
        const timeSinceLastActivity = this.getTimeSinceLastActivity();

        if (timeSinceLastActivity >= this.TIMEOUT_TO_SHOW_DIALOG) {
            this.store.dispatch(SecurityActions.ShowTimeoutDialog());
        } else {
            this.setTimer(this.TIMEOUT_TO_SHOW_DIALOG - timeSinceLastActivity);
        }
    }

    getTimeSinceLastActivity(): number {
        const wareUIActivityTimestamp = this.localStorageService.getActivityTimeStampValueFromStorage();

        if (isString(wareUIActivityTimestamp)) {
            return Date.now() - Number(wareUIActivityTimestamp);
        }

        return 0;
    }

    ngOnDestroy() {
        if (this.activityEventsSubscription) {
            this.activityEventsSubscription.unsubscribe();
        }
    }
}
