import { Injectable } from "@angular/core";
import { Store } from "@ngrx/store";
import { State } from "../store/reducers";
import * as SecurityActions from "../store/actions/security.actions";
import { LocalSavedTableColumnConfigurations } from "../models/local-saved-column-configurations.model";
import { Subject } from "rxjs";
import { share } from "rxjs/operators";

export enum LocalStorageKeys {
    LocalColumnConfigurationSettings = "localColumnConfigurationSettings",
    WareUIActivityTimestamp = "WareUIActivityTimestamp",
    WareUILogoutTimestamp = "WareUILogoutTimestamp",
    WareSessionExpirationDialogClosedTimestamp = "WareSessionExpirationDialogClosedTimestamp",
    eventTime = "eventTime",
    pqiTable = "pqiTable",
    meteringDataTable = "meteringDataTable",
    meteringDataTableCollapsed = "meteringDataTableCollapsed",
    prepaymentTable = "prepaymentTable",
    prepaymentTableCollapsed = "prepaymentTableCollapsed",
    mpSearchTable = "mpSearchTable",
    mpDevicesTable = "mpDevicesTable",
    changeLogs = "changeLogs"
}

@Injectable({
    providedIn: "root"
})
export class LocalStorageService {
    localStorageIsSupported = true;
    fallbackStorage: { [key: string]: string } = {};

    // The Subject is being used to subscribe to the local storage changes
    private onColumnChange = new Subject<{ key: string; value: any }>();
    public changedColumnInfo = this.onColumnChange.asObservable().pipe(share());

    constructor(private store: Store<State>) {
        this.localStorageIsSupported = this.isLocalStorageSupported();

        if (this.localStorageIsSupported) {
            window.addEventListener("storage", this.onLocalStorageEvent.bind(this));
        }
    }
    public setLocalColumnConfigurationSettings(columnConfigSettings: LocalSavedTableColumnConfigurations | null | undefined) {
        this.setItem(LocalStorageKeys.LocalColumnConfigurationSettings, JSON.stringify(columnConfigSettings));
    }

    public getLocalColumnConfigurationSettings(): LocalSavedTableColumnConfigurations | null {
        const saved = this.getItem(LocalStorageKeys.LocalColumnConfigurationSettings);
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch (es) {
                console.error("[LocalStorageService] Couldn't load json from local storage. Error was ", es);
            }
        }
        return null;
    }

    public setColumnConfiguration(key: LocalStorageKeys, columnConfigSettings: any | null | undefined) {
        this.setItem(key, JSON.stringify(columnConfigSettings));
        this.onColumnChange.next({ key: key, value: columnConfigSettings });
    }

    public getColumnConfiguration(key: LocalStorageKeys): any | null {
        const saved = this.getItem(key);
        if (saved) {
            try {
                return JSON.parse(saved);
            } catch (es) {
                console.error("[LocalStorageService] Couldn't load json from local storage. Error was ", es);
            }
        }
        return null;
    }

    public setActivityTimestamp() {
        this.storeTimestampWithKey(LocalStorageKeys.WareUIActivityTimestamp);
    }

    public writeLogoutEventToLocalStorage() {
        this.storeTimestampWithKey(LocalStorageKeys.WareUILogoutTimestamp);
    }

    public writeDialogClosedEventToLocalStorage() {
        this.storeTimestampWithKey(LocalStorageKeys.WareSessionExpirationDialogClosedTimestamp);
    }

    public getActivityTimeStampValueFromStorage() {
        return this.getItem(LocalStorageKeys.WareUIActivityTimestamp);
    }

    private storeTimestampWithKey(key: LocalStorageKeys) {
        return this.setItem(key, Date.now().toString());
    }

    private onLocalStorageEvent(event: StorageEvent) {
        if (event.key === LocalStorageKeys.WareUILogoutTimestamp) {
            this.store.dispatch(SecurityActions.Logout());
        }

        if (event.key === LocalStorageKeys.WareSessionExpirationDialogClosedTimestamp) {
            this.store.dispatch(SecurityActions.ClosedTimeoutDialog());
        }
    }

    private setItem(key: LocalStorageKeys, value: any) {
        if (this.localStorageIsSupported) {
            return localStorage.setItem(key, value);
        }
        const oldValue = this.getItem(key);
        this.fallbackStorage[key] = value;
        this.onLocalStorageEvent({ newValue: value, oldValue: oldValue, key: key } as any);
        return value;
    }

    private getItem(key: LocalStorageKeys) {
        if (this.localStorageIsSupported) {
            return localStorage.getItem(key);
        }
        return this.fallbackStorage[key];
    }

    public removeLocalStorageItem(key: string) {
        localStorage.removeItem(key);
    }

    private isLocalStorageSupported(): boolean {
        try {
            const key = "AIMWareUIKeyThatIsUsedOnlyForThisChecking";
            localStorage.setItem(key, key);
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            return false;
        }
    }
}
