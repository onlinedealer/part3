import { Component, Output, EventEmitter, Input } from "@angular/core";
import { Store } from "@ngrx/store";
import { MeteringPointsFeatureState } from "../../store/reducers";
import * as PQIDataActions from "../../store/actions/pqidata.action";

@Component({
    selector: "landisgyr-power-quality-view-selector",
    templateUrl: "./meteringpoint-power-quality-view-selector.component.html",
    styleUrls: ["./meteringpoint-power-quality-view-selector.component.scss"]
})
export class MeteringpointPowerQualityViewSelectorComponent {
    @Input()
    selectedView!: string;
    @Input() pqiDataLoading!: any;

    @Output()
    viewSelection = new EventEmitter<string>();
    constructor(private store: Store<MeteringPointsFeatureState>) {}

    selectView(view: string) {
        this.store.dispatch(new PQIDataActions.ChangePQIView(view));
    }
}
