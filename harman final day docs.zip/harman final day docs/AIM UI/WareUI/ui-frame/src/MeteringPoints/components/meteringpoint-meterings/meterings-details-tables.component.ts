import { Component, Input, ChangeDetectionStrategy, EventEmitter, Output } from "@angular/core";
import { DetailsTable } from "../../../Shared/models/details-table.model";
import { TranslationsService } from "../../../app/services/translations-service";
import { Metering } from "../../models/metering.model";
import * as MeteringsSelectors from "../../store/selectors/meterings.selectors";
import { Store } from "@ngrx/store";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { getRegistersEntities, getDeviceMeterRegisterIds } from "./../../store/selectors/registers.selectors";
import { getDeviceMeters } from "./../../store/selectors/meterconnections.selectors";
import { Register } from "../../models/register.model";
import { DeviceMeter } from "../../models/meterconnection.model";

@Component({
    selector: "landisgyr-meterings-details-tables",
    templateUrl: "./meterings-details-tables.component.html",
    styleUrls: ["./meterings-details-tables.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringsDetailsTablesComponent {
    @Input()
    metering!: Metering;

    @Output()
    expanded = new EventEmitter<boolean>();

    detailsSectionExpanded = false;
    meterSerialNumber = "";
    selectedMetering: Metering | undefined;
    loadedRegisters: { [id: number]: Register } = {};
    deviceMeterRegisterIds: { [deviceMaterId: number]: number[] } = {};
    deviceMeters: { [id: number]: DeviceMeter } = {};

    METERINGS_TABLE_HEADERS: { [key: string]: string } = {
        unit: this.translations.getTranslation("Measurement unit"),
        meteringType: $localize`:|Table column title for Metering type@@meteringsDetails.meteringType:Metering type`,
        device: this.translations.getTranslation("Device number"),
        periodLength: this.translations.getTranslation("Period length"),
        productComponent: this.translations.getTranslation("Product component"),
        measuredAttribute: $localize`:|Table column title for Metering mode@@meteringsDetails.measuredAttribute:Measured attribute`,
        meteringMode: $localize`:|Table column title for Metering mode@@meteringsDetails.meteringMode:Metering mode`,
        frozenUntil: $localize`:|Table column title for Frozen until@@meteringsDetails.frozenUntil:Frozen until`,
        powerDimension: $localize`:|Table column title for Power dimension@@meteringsDetails.powerDimension:Power dimension`,
        obisCode: this.translations.getTranslation("OBIS code"),
        pulseConstant: $localize`:|Table column title for Pulse constant@@meteringsDetails.pulseConstant:Pulse constant`
    };

    private typeLabels: Map<string, string> = new Map([
        ["profile", $localize`:|@@meteringType.profile:Profile`],
        ["periodic", $localize`:|@@meteringType.periodic:Periodic`]
    ]);

    private modeLabels: Map<string, string> = new Map([
        ["UNDEFINED", $localize`:|@@meteringMode.undefined:Undefined`],
        ["CUMULATIVE", $localize`:|@@meteringMode.cumulative:Cumulative`],
        ["NON_CUMULATIVE", $localize`:|@@meteringMode.nonCumulative:Non-cumulative`],
        ["PEAK", $localize`:|@@meteringMode.maxDemand:Max demand`],
        ["CUMULATIVE_MAX", $localize`:|@@meteringMode.cumulativeMaximum:Cumulative maximum`],
        ["MINIMUM", $localize`:|@@meteringMode.minimum:Minimum`],
        ["CUMULATIVE_MINIMUM", $localize`:|@@meteringMode.cumulativeMinimum:Cumulative minimum`],
        ["INSTANTANEOUS", $localize`:|@@meteringMode.instantaneous:Instantaneous`],
        ["CURRENT_AVG", $localize`:|@@meteringMode.currentAverage:Current average`],
        ["LAST_AVG", $localize`:|@@meteringMode.lastAverage:Last average`]
    ]);

    constructor(public translations: TranslationsService, private store: Store<MeteringPointsFeatureState>) {}

    onClickExpandDetailsSection(): void {
        this.detailsSectionExpanded = !this.detailsSectionExpanded;
        this.expanded.emit(this.detailsSectionExpanded);
    }

    getMeterSerialNumber() {
        this.store
            .select(MeteringsSelectors.getSelectedMetering)
            .subscribe(data => {
                this.selectedMetering = data;
            })
            .unsubscribe();
        this.store
            .select(getRegistersEntities)
            .subscribe(data => {
                this.loadedRegisters = data;
            })
            .unsubscribe();
        this.store
            .select(getDeviceMeterRegisterIds)
            .subscribe(data => {
                this.deviceMeterRegisterIds = data;
            })
            .unsubscribe();
        this.store
            .select(getDeviceMeters)
            .subscribe(data => {
                this.deviceMeters = data;
            })
            .unsubscribe();
        if (this.selectedMetering) {
            const registerarray: Register[] = [];
            const currentTime = new Date().getTime();
            let registerId: any, deviceMeter: any;
            for (const register in this.loadedRegisters) {
                if (
                    (this.loadedRegisters[register].periodicMeteringId &&
                        this.loadedRegisters[register].periodicMeteringId === this.selectedMetering.meteringId) ||
                    (this.loadedRegisters[register].profileMeteringId &&
                        this.loadedRegisters[register].profileMeteringId === this.selectedMetering.meteringId)
                ) {
                    registerarray.push(this.loadedRegisters[register]);
                }
            }

            for (const register of registerarray) {
                if (
                    (!register.deleted &&
                        register.validUntil &&
                        register.validUntil !== null &&
                        register.validFrom < currentTime &&
                        register.validUntil >= currentTime) ||
                    (!register.deleted && !register.validUntil && register.validFrom < currentTime)
                ) {
                    registerId = register.registerId;
                    break;
                }
            }

            for (const deviceRegister in this.deviceMeterRegisterIds) {
                if (this.deviceMeterRegisterIds[deviceRegister].indexOf(registerId) > -1) {
                    deviceMeter = this.deviceMeters[deviceRegister].meterSerialNumber;
                }
            }
            return deviceMeter ? deviceMeter : "";
        } else {
            return "";
        }
    }

    generateArrayToMeteringsTable(): DetailsTable[] {
        if (this.detailsSectionExpanded === true) {
            return [
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.unit,
                                value: this.metering.measuredUnit ? this.metering.measuredUnit.name : ""
                            },
                            { header: this.METERINGS_TABLE_HEADERS.meteringType, value: this.typeLabels.get(this.metering.type) },
                            {
                                header: this.METERINGS_TABLE_HEADERS.device,
                                value: this.getMeterSerialNumber()
                            }
                        ]
                    }
                },
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.periodLength,
                                value: this.metering.periodLength ? this.metering.periodLength : ""
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.productComponent,
                                value:
                                    this.metering.productComponent === undefined || this.metering.productComponent === null
                                        ? ""
                                        : this.metering.productComponent.name === null
                                        ? ""
                                        : this.metering.productComponent.name
                            },
                            {
                                header: this.METERINGS_TABLE_HEADERS.meteringMode,
                                value: this.metering.meteringMode ? this.modeLabels.get(this.metering.meteringMode) : ""
                            }
                        ]
                    }
                },
                {
                    table: {
                        rows: [
                            { header: this.METERINGS_TABLE_HEADERS.powerDimension, value: this.metering.powerDimension },
                            { header: this.METERINGS_TABLE_HEADERS.obisCode, value: this.metering.obis },
                            {
                                header: this.METERINGS_TABLE_HEADERS.measuredAttribute,
                                value:
                                    this.metering.measuredAttribute === undefined || this.metering.measuredAttribute === null
                                        ? ""
                                        : this.metering.measuredAttribute.name === null
                                        ? ""
                                        : this.metering.measuredAttribute.name
                            }
                        ]
                    }
                }
            ];
        } else {
            return [
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.unit,
                                value: this.metering.measuredUnit ? this.metering.measuredUnit.name : ""
                            }
                        ]
                    }
                },
                {
                    table: {
                        rows: [
                            {
                                header: this.METERINGS_TABLE_HEADERS.periodLength,
                                value: this.metering.periodLength ? this.metering.periodLength : ""
                            }
                        ]
                    }
                },
                {
                    table: {
                        rows: [{ header: this.METERINGS_TABLE_HEADERS.powerDimension, value: this.metering.powerDimension }]
                    }
                }
            ];
        }
    }
}
