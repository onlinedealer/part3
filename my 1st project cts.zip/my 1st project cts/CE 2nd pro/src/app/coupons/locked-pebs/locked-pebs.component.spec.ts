import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LockedPebsComponent } from './locked-pebs.component';

describe('LockedPebsComponent', () => {
  let component: LockedPebsComponent;
  let fixture: ComponentFixture<LockedPebsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LockedPebsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LockedPebsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should be expandable', () => {
    expect(component.showExpandedView).toBeTruthy();
  });

  it('should be collapsable from the expanded view', () => {
    expect(component.hideFromExpanded).toBeTruthy();
  });
  it('should render a headline in an h3 tag', async(() => {
    const fixture = TestBed.createComponent(LockedPebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h3').textContent).toContain('ExtraBucks<sup>®</sup> Rewards');
  }));
    it('should render a description', async(() => {
    const fixture = TestBed.createComponent(LockedPebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('span').textContent).toContain(this.data.webDsc);
  }));
   it('should render a Start today message in a p tag', async(() => {
    const fixture = TestBed.createComponent(LockedPebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('p').textContent).toContain('Start today');
  }));
    it('should render a shop to unlock action in a span tag', async(() => {
    const fixture = TestBed.createComponent(LockedPebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('span').textContent).toContain('Shop to unlock');
  }));
});
