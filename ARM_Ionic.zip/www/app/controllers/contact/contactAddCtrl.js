(function () {
    'use strict';

    angular.module('arm').controller('contactAddCtrl',
            ['$scope', '$state', '$window', '$stateParams', 'utility', 'MASTER_TABLE', 'ALERT_MESSAGE', 'authService', 'contactService','$ionicModal', '$cordovaCamera',  '$cordovaFile','$filter','GENERAL_CONFIG', '$cordovaDialogs','$rootScope','productService',addContactCtrl])

    function addContactCtrl($scope, $state, $window, $stateParams, utility, MASTER_TABLE, ALERT_MESSAGE, authService, contactService, $ionicModal, $cordovaCamera, $cordovaFile, $filter, GENERAL_CONFIG, $cordovaDialogs,$rootScope,productService) {
        $scope.title = "";
        var shouldDisplayConfidentialFields = true; //--> if user is having full access
        //debugger
        $scope.editModeFlag = $state.params.editModeFlag;
        $scope.isContactDynamicFlds = false;
        var selectedModelType = 0;
		$scope.shouldShowSwitch = false;
		$scope.disableIsClient = false; $scope.disableIsPhoneBook = false; $scope.mapActive = false;
		$scope.isContactConfidential = false;
		$scope.fields = [];
        var fieldsDataSourceArr = [];
        var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        var CreatorID = lgnUser.UserID;
        $scope.tier = {'tierId': null};
		$scope.segment = {'segmentId': null};

        //Initialize Constants
		$scope.communicationCategory = contactService.constants().communicationCategory;
		$scope.inputFieldTypes =  contactService.constants().inputFieldType;
		$scope.contactType = contactService.constants().contactType;
		$scope.dynamicFieldType = contactService.constants().dynamicFieldType;
		$scope.modelTypes = contactService.constants().modelTypes;

		//Initialize Drop downs
		$scope.salutations = utility.getMultLangMasData(MASTER_TABLE.Sal);
		$scope.inverseRelations = utility.getMultLangMasData(MASTER_TABLE.RelInverseType);
		$scope.communicationTypes =  contactService.getCommunicationTypes();
		$scope.correspondenceTypes = utility.getMultLangMasData(MASTER_TABLE.CorTyp);
		$scope.ownerSelectionList = [{Value: 1,Text:'Atul'},{Value: 2,Text:'Prakash'},{Value: 2,Text:'Randhi'}];
        $scope.tiers = utility.getMultLangMasData(MASTER_TABLE.ConTier);
        $scope.segments = utility.getMultLangMasData(MASTER_TABLE.ConSeg);
		$scope.userSelectionList = [];

		$scope.$on( "$ionicView.beforeEnter", function() {
			configureModel();
			loadContactUsersData();
		});

        function configureModel (){
            // Fetch the all DeviceObjIds for login user Id's
            $scope.allDeviceObjIdsByLoginUserID = [];
            contactService.sqlGetAllDeviceObjIds().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.allDeviceObjIdsByLoginUserID.push(result.rows.item(i));
                }
            });

        	if ($scope.editModeFlag == 0) {
        	    $scope.title = "Add Contact";
				$scope.contactOwnerID = lgnUser.UserID;
				$scope.selContactOwner = lgnUser.UserName;
        		$scope.individualContactModel = contactService.models().contactModel;
				$scope.individualContactModel.ContactTypeID = 1;

        		$scope.companyContactModel = contactService.models().contactModel;
        		$scope.companyContactModel.ContactTypeID = 2;

        		$scope.individualContactModel.SalutationID = utility.getDefaultDropDownId($scope.salutations); //set default.

        		// TODO bind the all default empty objects
                bindDefaultDropDownSelect($scope.individualContactModel);
                bindDefaultDropDownSelect($scope.companyContactModel);

                $scope.tier.tierId = utility.getDefaultDropDownId($scope.tiers);
                $scope.segment.segmentId = utility.getDefaultDropDownId($scope.segments);
        	}else{
                //debuggers
                $scope.title = "Edit Contact"; $scope.disableIsPhoneBook = true;
        		var selectedContactType =  contactService.getSelectedContactType();
        		$scope.companyContactName = ""; $scope.individualFirstName = "";
        		var individualContactModel = contactService.getSelectedIndividualContact();
        		if(individualContactModel != null){
        		    $scope.individualContactModel = {};
                    angular.copy(individualContactModel,$scope.individualContactModel);
                    $scope.individualFirstName = $scope.individualContactModel.FirstName;
                    bindDefaultDropDownSelect($scope.individualContactModel);
        		}else{
                    $scope.individualContactModel = null;
        		}
        		var companyContactModel = contactService.getSelectedCompanyContact();
        		if(companyContactModel != null){
                    $scope.companyContactModel = {};
                    angular.copy(companyContactModel,$scope.companyContactModel);
                    $scope.companyContactName = $scope.companyContactModel.CompanyName;
                    bindDefaultDropDownSelect($scope.companyContactModel);
                }else{
                    $scope.companyContactModel = null;
                }

                if (selectedContactType == $scope.contactType.Individual) {
                	if ($scope.companyContactModel == null) {
                		//create new one #TODO
                		$scope.companyContactModel = contactService.models().contactModel;
						$scope.companyContactModel.ContactTypeID = 2;
                        bindDefaultDropDownSelect($scope.companyContactModel);
                 	}else{
                		//fill $scope.companyContactModel information #TODO
						// bindContactFieldsInEditMode($scope.companyContactModel);
						contactService.getAllSubArrayDataToModel($scope.companyContactModel,false);
                	}
                }else{
                	if ($scope.individualContactModel == null) {
                		//create new one #TODO
                		$scope.individualContactModel = contactService.models().contactModel;
						$scope.individualContactModel.ContactTypeID = 1;
						bindDefaultDropDownSelect($scope.individualContactModel);
                	}else{
                		//fill $scope.individualContactModel information #TODO
                		// bindContactFieldsInEditMode($scope.individualContactModel);
                		contactService.getAllSubArrayDataToModel($scope.individualContactModel,false);
                	}
                }
        		if ($scope.companyContactModel.IsClient == true) {
        		    // disable flag is company client / lead
                    $scope.disableIsClient = true;
        		  	$scope.contactOwnerID = $scope.companyContactModel.OwnerID;
        		  	$scope.tier.tierId = $scope.companyContactModel.ContactTierID;
					$scope.segment.segmentId = $scope.companyContactModel.ContactSegmentID;
					$scope.selContactOwner = $scope.companyContactModel.OwnerName;
					$scope.userSelectionList = $scope.companyContactModel.ContactUserMappings;
        		}else{
 					$scope.contactOwnerID = $scope.individualContactModel.OwnerID;
 					$scope.tier.tierId = $scope.individualContactModel.ContactTierID;
					$scope.segment.segmentId = $scope.individualContactModel.ContactSegmentID;
					$scope.selContactOwner = $scope.individualContactModel.OwnerName;
					$scope.userSelectionList = $scope.individualContactModel.ContactUserMappings;
        		}
        	}
        };

        function bindDefaultDropDownSelect(contactModel){
            $scope.fieldSet = utility.getMasterDataByKey(MASTER_TABLE.ConFieldSet);
            $scope.fieldSet = $filter('filter')($scope.fieldSet, {IsStaticField: false});
            if (!shouldDisplayConfidentialFields) { //Display Confidential fields if user== full access
                $scope.fieldSet = $filter('filter')($scope.fieldSet, {IsConfidential: false});
            }
            if(contactModel.ContactTypeID == $scope.contactType.Individual){
                if(contactModel.Communications.length == 0){
                    var communicationModel = contactService.models().communicationModel;
                    communicationModel.CommunicationCategoryID = $scope.communicationCategory.Phone;
                    communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                    communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    communicationModel.IsMandatory = true;
                    var filterArrPhone = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Phone});
                    communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                    $scope.individualContactModel.Communications.push(communicationModel);

                    communicationModel = contactService.models().communicationModel;
                    communicationModel.CommunicationCategoryID = $scope.communicationCategory.Email;
                    communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                    communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    communicationModel.IsMandatory = true;
                    var filterArrEmail = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Email});
                    communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrEmail);
                    $scope.individualContactModel.Communications.push(communicationModel);
                }else{
                    var existedCommPhone = $filter('filter')(contactModel.Communications, {CommunicationCategoryID: $scope.communicationCategory.Phone});
                    if(existedCommPhone.length == 0){
                        var communicationModel = contactService.models().communicationModel;
                        communicationModel.CommunicationCategoryID = $scope.communicationCategory.Phone;
                        communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                        communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                        communicationModel.IsMandatory = true;
                        var filterArrPhone = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Phone});
                        communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                        $scope.individualContactModel.Communications.push(communicationModel);
                    }
                    var existedCommEmail = $filter('filter')(contactModel.Communications, {CommunicationCategoryID: $scope.communicationCategory.Email});
                    if(existedCommEmail.length == 0){
                        communicationModel = contactService.models().communicationModel;
                        communicationModel.CommunicationCategoryID = $scope.communicationCategory.Email;
                        communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                        communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                        communicationModel.IsMandatory = true;
                        var filterArrEmail = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Email});
                        communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrEmail);
                        $scope.individualContactModel.Communications.push(communicationModel);
                    }
                }
                if(contactModel.Correspondences.length == 0){
                    var correspondenceModel = contactService.models().correspondenceModel;
                    correspondenceModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                    correspondenceModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    correspondenceModel.IsMandatory = true;
                    correspondenceModel.CorrespondenceTypeID = utility.getDefaultDropDownCorrospondance($scope.correspondenceTypes);
                    $scope.individualContactModel.Correspondences.push(correspondenceModel);
                }
                if(contactModel.Fields.length == 0){
                    // Dynamic field added to module
                    for (var i = 0; i < $scope.fieldSet.length; i++) {
                        if($scope.fieldSet[i].ContactTypeID == $scope.contactType.Individual)
                        {
                            $scope.individualContactModel.Fields.push({
                                EntityID: $scope.individualContactModel.ContactID,
                                ModuleID: $scope.individualContactModel.ModuleID,
                                ParentDeviceObjID: $scope.individualContactModel.DeviceObjID,
                                FieldLabel: $scope.fieldSet[i].FieldLabel,
                                FieldName: $scope.fieldSet[i].FieldName,
                                FieldValue: '',
                                FieldID: $scope.fieldSet[i].FieldID,
                                IsConfidential: $scope.fieldSet[i].IsConfidential,
                                IsMandatory: $scope.fieldSet[i].IsMandatory,
                                IsVisible: $scope.fieldSet[i].IsVisible,
                                ContactTypeID: $scope.fieldSet[i].ContactTypeID,
                                ContactFieldCategoryID: $scope.fieldSet[i].ContactFieldCategoryID
                                });
                        }
                    }
                }
            }else{
                if(contactModel.Communications.length == 0){
                    communicationModel = contactService.models().communicationModel;
                    communicationModel.CommunicationCategoryID = $scope.communicationCategory.Phone;
                    communicationModel.ParentDeviceObjID = $scope.companyContactModel.DeviceObjID;
                    communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    communicationModel.IsMandatory = true;
                    var filterArrPhone = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Phone});
                    communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                    $scope.companyContactModel.Communications.push(communicationModel);
                }
                if(contactModel.Correspondences.length == 0){
                    correspondenceModel = contactService.models().correspondenceModel;
                    correspondenceModel.ParentDeviceObjID = $scope.companyContactModel.DeviceObjID;
                    correspondenceModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                    correspondenceModel.IsMandatory = true;
                    correspondenceModel.CorrespondenceTypeID = utility.getDefaultDropDownCorrospondance($scope.correspondenceTypes);
                    $scope.companyContactModel.Correspondences.push(correspondenceModel);
                }

                if(contactModel.Fields.length == 0){
                    for (var i = 0; i < $scope.fieldSet.length; i++) {
                        if($scope.fieldSet[i].ContactTypeID == $scope.contactType.Company)
                        {
                            $scope.companyContactModel.Fields.push({
                                EntityID: $scope.companyContactModel.ContactID,
                                ModuleID: $scope.companyContactModel.ModuleID,
                                ParentDeviceObjID: $scope.companyContactModel.DeviceObjID,
                                FieldLabel: $scope.fieldSet[i].FieldLabel,
                                FieldName: $scope.fieldSet[i].FieldName,
                                FieldValue: '',
                                FieldID: $scope.fieldSet[i].FieldID,
                                IsConfidential: $scope.fieldSet[i].IsConfidential,
                                IsMandatory: $scope.fieldSet[i].IsMandatory,
                                IsVisible: $scope.fieldSet[i].IsVisible,
                                ContactTypeID: $scope.fieldSet[i].ContactTypeID,
                                ContactFieldCategoryID: $scope.fieldSet[i].ContactFieldCategoryID
                                });
                        }
                    }
                }
            }
        }
		$scope.manageCellBtnTapped = function(index,shouldAddExtraCell,fieldType,isIndividualType,item)
		{
			if (shouldAddExtraCell == true) {
			 	switch (fieldType) {
                    case $scope.inputFieldTypes.Phone:
                    {
                        var communicationModel = contactService.models().communicationModel;
                        communicationModel.CommunicationCategoryID = $scope.communicationCategory.Phone;
                        communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                        communicationModel.IsMandatory = false;
                        var filterArrPhone = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Phone});
                        communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                        if(isIndividualType){
                            communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                            $scope.individualContactModel.Communications.push(communicationModel);
                        }else{
                            communicationModel.ParentDeviceObjID = $scope.companyContactModel.DeviceObjID;
                            $scope.companyContactModel.Communications.push(communicationModel);
                        }
                    }
                        break;
                    case $scope.inputFieldTypes.Email:
                    {
                        var communicationModel = contactService.models().communicationModel;
                        communicationModel.CommunicationCategoryID = $scope.communicationCategory.Email;
                        communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                        communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                        communicationModel.IsMandatory = false;
                        var filterArrEmail = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Email});
                        communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrEmail);
                        $scope.individualContactModel.Communications.push(communicationModel);
                    }
                        break;
                    case $scope.inputFieldTypes.Correspondence:
                    {
                        var correspondenceModel = contactService.models().correspondenceModel;
                        correspondenceModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                        correspondenceModel.IsMandatory = false;
                        correspondenceModel.CorrespondenceTypeID = utility.getDefaultDropDownCorrospondance($scope.correspondenceTypes);
                        if(isIndividualType){
                            correspondenceModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                            $scope.individualContactModel.Correspondences.push(correspondenceModel);
                        }else{
                            correspondenceModel.ParentDeviceObjID = $scope.companyContactModel.DeviceObjID;
                            $scope.companyContactModel.Correspondences.push(correspondenceModel);
                        }
                    }
                        break;
                    default:
                }
			}else{
				switch (fieldType) {
                    case $scope.inputFieldTypes.Phone:
                    {
                        //TODO: Delete communication from database if exist.
                        if(isIndividualType)
                            $scope.individualContactModel.Communications.splice($scope.individualContactModel.Communications.indexOf(item),1);
                        else
                            $scope.companyContactModel.Communications.splice($scope.companyContactModel.Communications.indexOf(item),1);
                    }
                        break;
                    case $scope.inputFieldTypes.Email:
                    {
                        //TODO: Delete communication from database if exist.
                         $scope.individualContactModel.Communications.splice($scope.individualContactModel.Communications.indexOf(item),1);
                    }
                        break;
                    case $scope.inputFieldTypes.Correspondence:
                    {
                         if(isIndividualType)
                            $scope.individualContactModel.Correspondences.splice($scope.individualContactModel.Correspondences.indexOf(item),1);
                        else
                            $scope.companyContactModel.Correspondences.splice($scope.companyContactModel.Correspondences.indexOf(item),1);
                    }
                        break;
                    default:
                    {
                        break;
                    }
                }
			}
		};

		$scope.updateCheckBoxSelection = function(tappedIndex,dataSourceArr,tappedItem,type)
		{
			if (type == $scope.inputFieldTypes.Email) {
				dataSourceArr = $filter('filter')(dataSourceArr, {CommunicationCategoryID: $scope.communicationCategory.Email});
			}else if (type == $scope.inputFieldTypes.Phone) {
				dataSourceArr = $filter('filter')(dataSourceArr, {CommunicationCategoryID: $scope.communicationCategory.Phone});
			}
			angular.forEach(dataSourceArr, function(item, index) {
			    if (item != tappedItem)
			        item.IsDefault = false;
			    });
		};

        $scope.dropDownValueChanged = function()
        {
        	 // alert('salutationChanged called' + $scope.SalutationID.id);
        };

   		 ///////////////////////////////////model for the add fields start ////////////////////////////////
        $ionicModal.fromTemplateUrl('app/views/common/fields.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAddDet = modal;
        });
        $scope.openAddDetails = function (section,fieldCategoryType) {
        	$scope.fields = [];
        	if (section == $scope.contactType.Individual && fieldCategoryType == $scope.dynamicFieldType.Additional) {
        		$scope.isContactDynamicFlds = false;
        		selectedModelType = $scope.modelTypes.IndividualAddnType;
        		fieldsDataSourceArr = $filter('filter')($scope.individualContactModel.Fields, {ContactFieldCategoryID: $scope.dynamicFieldType.Additional});
        		angular.copy(fieldsDataSourceArr,$scope.fields);
        	}else if ($scope.companyContactModel.IsClient.toString() == 'false' && fieldCategoryType == $scope.dynamicFieldType.Business){
        		$scope.isContactDynamicFlds = true;
		  		selectedModelType = $scope.modelTypes.IndividualBusnessType;
        		fieldsDataSourceArr = $filter('filter')($scope.individualContactModel.Fields, {ContactFieldCategoryID: $scope.dynamicFieldType.Business});
        		angular.copy(fieldsDataSourceArr,$scope.fields);
        	}else if (section == $scope.contactType.Company && fieldCategoryType == $scope.dynamicFieldType.Additional){
				$scope.isContactDynamicFlds = false;
				selectedModelType = $scope.modelTypes.CompanyAddnType;
				fieldsDataSourceArr = $filter('filter')($scope.companyContactModel.Fields, {ContactFieldCategoryID: $scope.dynamicFieldType.Additional});
				angular.copy(fieldsDataSourceArr,$scope.fields);
        	}else if ($scope.companyContactModel.IsClient.toString() == 'true' && fieldCategoryType == $scope.dynamicFieldType.Business){
				 $scope.isContactDynamicFlds = true;
				 selectedModelType = $scope.modelTypes.CompanyBusnessType;
				 fieldsDataSourceArr = $filter('filter')($scope.companyContactModel.Fields, {ContactFieldCategoryID: $scope.dynamicFieldType.Business});
				 angular.copy(fieldsDataSourceArr,$scope.fields);
        	}
            $scope.modalAddDet.show();
        };
        $scope.closeAddDetails = function () {
	        updateDynamcicFields(true);
	        $scope.modalAddDet.hide();
        }
        //save the field data
        $scope.actionField = function () {
            var validationFlag = true;

            validationFlag = utility.commonValidationDynamic($scope.fields);
            if (!validationFlag) {
                return false;
            }
			updateDynamcicFields(false);
			$scope.modalAddDet.hide();
        };

        function updateDynamcicFields(didTapClose)
        {
        	if (didTapClose)
		        utility.updateFldArrValues(fieldsDataSourceArr,$scope.fields);
		    else
		        utility.updateFldArrValues($scope.fields,fieldsDataSourceArr);
        }
        //////////////////////////////////////////Fields END //////////////////////////////////////////////
        //////////////////////////////////////////Phone contact Start/////////////////////////////////////
        $scope.phoneContactAdd = function () {
            navigator.contacts.pickContact(function (contact) {
                //var ph = contact.phoneNumbers[0].value;
                $scope.$apply(function () {
                    $scope.individualContactModel.Communications = [];
                    $scope.individualContactModel.FirstName = contact.name.givenName;
                    $scope.individualContactModel.MiddleName = contact.name.middleName;
                    $scope.individualContactModel.LastName = contact.name.familyName;
                    if(contact.phoneNumbers != null){
                        for(var i=0; i < contact.phoneNumbers.length; i++){
                            var communicationModel = contactService.models().communicationModel;
                            communicationModel.CommunicationCategoryID = $scope.communicationCategory.Phone;
                            communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                            communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                            if(i==0) communicationModel.IsMandatory = true;
                            else communicationModel.IsMandatory = false;
                            var filterArrPhone = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Phone});
                            communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                            communicationModel.CommunicationData = contact.phoneNumbers[i].value;
                            $scope.individualContactModel.Communications.push(communicationModel);
                        }
                    }else{
                        var communicationModel = contactService.models().communicationModel;
                        communicationModel.CommunicationCategoryID = $scope.communicationCategory.Phone;
                        communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                        communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                        communicationModel.IsMandatory = true;
                        var filterArrPhone = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Phone});
                        communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrPhone);
                        $scope.individualContactModel.Communications.push(communicationModel);
                    }
                    if(contact.phoneNumbers != null){
                        for(var i=0; i < contact.emails.length; i++){
                            var communicationModel = contactService.models().communicationModel;
                            communicationModel.CommunicationCategoryID = $scope.communicationCategory.Email;
                            communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                            communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                            if(i==0) communicationModel.IsMandatory = true;
                            else communicationModel.IsMandatory = false;
                            var filterArrEmail = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Email});
                            communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrEmail);
                            communicationModel.CommunicationData = contact.emails[i].value;
                            $scope.individualContactModel.Communications.push(communicationModel);
                        }
                    }else{
                        communicationModel = contactService.models().communicationModel;
                        communicationModel.CommunicationCategoryID = $scope.communicationCategory.Email;
                        communicationModel.ParentDeviceObjID = $scope.individualContactModel.DeviceObjID;
                        communicationModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                        communicationModel.IsMandatory = true;
                        var filterArrEmail = $filter('filter')($scope.communicationTypes, {CommunicationCategoryID: $scope.communicationCategory.Email});
                        communicationModel.CommunicationTypeID = utility.getDefaultDropDownId(filterArrEmail);
                        $scope.individualContactModel.Communications.push(communicationModel);
                    }
                });

                //console.log('The following contact has been selected:' + JSON.stringify(contact));
            }, function (err) {
                //console.log('Error: ' + err);
            });
        };
        ///////////////////////////////////Phone contact end///////////////////////////////////////////
        ///////////////////////////////////model for the location start ////////////////////////////////
        $scope.geoLocationArr = {}
        $ionicModal.fromTemplateUrl('app/views/common/geolocation.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalLocation = modal;
            //$scope.initMap();
        });
        $scope.openAddLocation = function (item, val, inx) {
            $scope.geoLocationArr.indexId = inx;
            $scope.geoLocationArr.address = item.Address;
            $scope.geoLocationArr.city = item.CityName;
            $scope.geoLocationArr.country = item.CountryName;
            $scope.geoLocationArr.state = item.StateName;
            $scope.geoLocationArr.zipcode = item.Zip;
            $scope.geoLocationArr.lat = item.GoogleLat;
            $scope.geoLocationArr.log = item.GoogleLong;
            $scope.modelGeoSelected = val;
            $scope.$broadcast('changeText', {});
            $scope.modalLocation.show();
        };
        $scope.closeLocation = function () {
            $scope.modalLocation.hide();
        };

        //save the field data
        $scope.actionLocation = function () {
            var index_val = $scope.geoLocationArr.indexId;
            if($scope.modelGeoSelected == "I"){
                $scope.individualContactModel.Correspondences[index_val].Address = $scope.geoLocationArr.address;
                $scope.individualContactModel.Correspondences[index_val].CityName = $scope.geoLocationArr.city;
                $scope.individualContactModel.Correspondences[index_val].CountryName = $scope.geoLocationArr.country;
                $scope.individualContactModel.Correspondences[index_val].StateName = $scope.geoLocationArr.state;
                $scope.individualContactModel.Correspondences[index_val].Zip = $scope.geoLocationArr.zipcode;
                $scope.individualContactModel.Correspondences[index_val].GoogleLat = $scope.geoLocationArr.lat;
                $scope.individualContactModel.Correspondences[index_val].GoogleLong = $scope.geoLocationArr.log;
            }else if($scope.modelGeoSelected == "C"){
                $scope.companyContactModel.Correspondences[index_val].Address = $scope.geoLocationArr.address;
                $scope.companyContactModel.Correspondences[index_val].CityName = $scope.geoLocationArr.city;
                $scope.companyContactModel.Correspondences[index_val].CountryName = $scope.geoLocationArr.country;
                $scope.companyContactModel.Correspondences[index_val].StateName = $scope.geoLocationArr.state;
                $scope.companyContactModel.Correspondences[index_val].Zip = $scope.geoLocationArr.zipcode;
                $scope.companyContactModel.Correspondences[index_val].GoogleLat = $scope.geoLocationArr.lat;
                $scope.companyContactModel.Correspondences[index_val].GoogleLong = $scope.geoLocationArr.log;
            }
            $scope.modalLocation.hide();
        };

        //////////////////////////////////////////location END //////////////////////////////////////////////

        //////////////////////////////////////////USER LIST //////////////////////////////////////////////
        $scope.selUserOwners = {    activeUser: $scope.contactOwnerID,tempUser: $scope.contactOwnerID };
        //$scope.selCompanyClient = {  activeCompany: $scope.companyContactModel.DeviceObjID,tempCompany: $scope.companyContactModel.DeviceObjID };
        function loadContactUsersData() {
            $scope.selUserOwners = {    activeUser: $scope.contactOwnerID,tempUser: $scope.contactOwnerID };
            $scope.selCompanyClient = {  activeCompany: $scope.companyContactModel.DeviceObjID,tempCompany: $scope.companyContactModel.DeviceObjID };

            $scope.companyList = []; $scope.otherUsers = []; $scope.contactOwnerUser = [];
            authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.ContactSharingUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var newObj = result.rows.item(i);
				    newObj.IsChecked = isSelectedItem(newObj);
                    $scope.otherUsers.push(newObj);
                }
            });
            authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.ContactOwnershipUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                	if (result.rows.item(i).UserID == $scope.selUserOwners.activeUser) {
                        $scope.selContactOwner = result.rows.item(i).UserName;
                    }
                    $scope.contactOwnerUser.push(result.rows.item(i));
                }
            });
            contactService.companyListLoad().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                     var companyObjList = contactService.models().contactModel;
                     companyObjList = utility.syncModelWithCollection(result.rows.item(i),companyObjList);
                     $scope.companyList.push(companyObjList);
                }
            });
        };
        $ionicModal.fromTemplateUrl('app/views/common/userList.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalUser = modal;
        });

        function isSelectedItem (obj)
        {
        	for (var i = 0; i < $scope.userSelectionList.length; i++) {
                if ($scope.userSelectionList[i].UserID == obj.UserID) {
                    obj.AccessCategoryID = $scope.userSelectionList[i].AccessCategoryID;
                    if(obj.AccessCategoryID == GENERAL_CONFIG.AccessCategory.FullAccess){
                        obj.IsSwitchOn = true;
                    }else if(obj.AccessCategoryID == GENERAL_CONFIG.AccessCategory.RestrictedAccess){
                        obj.IsSwitchOn = false;
                    }
                    return true;
                }
            }
            return false;
        }
        $scope.clearCompanyModelObject = function () {
            $scope.companyContactModel = {};
            $scope.companyContactModel = contactService.models().contactModel;
            $scope.companyContactModel.ContactTypeID = 2;
            bindDefaultDropDownSelect($scope.companyContactModel);
            $scope.tier.tierId = utility.getDefaultDropDownId($scope.tiers);
            $scope.segment.segmentId = utility.getDefaultDropDownId($scope.segments);
            $scope.contactOwnerID = lgnUser.UserID;
            $scope.selContactOwner = lgnUser.UserName;
            $scope.userSelectionList = $scope.companyContactModel.ContactUserMappings;
            $scope.selUserOwners.activeUser = $scope.contactOwnerID;
            $scope.selUserOwners.tempUser = $scope.contactOwnerID;
            $scope.selCompanyClient.activeCompany =$scope.companyContactModel.DeviceObjID;
            $scope.selCompanyClient.tempCompany = $scope.companyContactModel.DeviceObjID;
            $scope.disableIsClient = false;
        };
        $scope.openUserList = function (val) {
            if($scope.modelSelected == 'CO')
                $scope.selUserOwners.tempUser = $scope.selUserOwners.activeUser;
            if($scope.modelSelected == 'COMP')
                $scope.selCompanyClient.tempCompany = $scope.selCompanyClient.activeCompany;
        	$scope.modelSelected = val;
        	if ($scope.modelSelected == 'OU') {
                $scope.shouldShowSwitch = true;
            }
			$scope.modalUser.show();
        };
        $scope.closeUserList = function () {
            $scope.userKeyword = "";
            if ($scope.modelSelected == 'OU') {
                utility.updateContactUserList($scope.otherUsers, $scope.userSelectionList, $scope.shouldShowSwitch);
                $scope.shouldShowSwitch = false;
            }
            $scope.modalUser.hide();
        };

        $scope.actionUserList = function () {
            $scope.userKeyword = "";
            if ($scope.modelSelected == 'OU') {
                $scope.userSelectionList = [];
                utility.selectedContactUserList($scope.otherUsers, $scope.userSelectionList,  $scope.shouldShowSwitch);
                $scope.shouldShowSwitch = false;
                //console.log($scope.userSelectionList);
            }else if ($scope.modelSelected == 'CO') {
               $scope.selUserOwners.activeUser = $scope.selUserOwners.tempUser;
               $scope.contactOwnerID = $scope.selUserOwners.activeUser;
               for (var i =0; i < $scope.contactOwnerUser.length; i++) {
                   if ($scope.contactOwnerUser[i].UserID == $scope.selUserOwners.activeUser) {
                       $scope.selContactOwner = $scope.contactOwnerUser[i].UserName;
                   }
               }
            }else if ($scope.modelSelected == 'COMP') {
                $scope.selCompanyClient.activeCompany = $scope.selCompanyClient.tempCompany;
                for (var i =0; i < $scope.companyList.length; i++) {
                    if ($scope.companyList[i].DeviceObjID == $scope.selCompanyClient.activeCompany) {
                        $scope.companyContactModel = $scope.companyList[i];
                        contactService.getAllSubArrayDataToModel($scope.companyContactModel,true);
                        // assign the other mapping data to company contact model
                        /*if($scope.companyContactModel.Communications.length == 0)
                            contactService.bindCommunicationEmptyModel($scope.companyContactModel);
                        if($scope.companyContactModel.Correspondences.length == 0)
                            contactService.bindCorrespondencesEmptyModel($scope.companyContactModel);*/
                        $scope.contactOwnerID = $scope.companyContactModel.OwnerID;
                        $scope.tier.tierId = $scope.companyContactModel.ContactTierID;
                        $scope.segment.segmentId = $scope.companyContactModel.ContactSegmentID;
                        $scope.selContactOwner = $scope.companyContactModel.OwnerName;
                        if($scope.selContactOwner == null || $scope.selContactOwner == ""){
                            for (var i =0; i < $scope.contactOwnerUser.length; i++) {
                               if ($scope.contactOwnerUser[i].UserID == $scope.selUserOwners.activeUser) {
                                   $scope.selContactOwner = $scope.contactOwnerUser[i].UserName;
                               }
                           }
                        }
                        $scope.userSelectionList = $scope.companyContactModel.ContactUserMappings;
                        $scope.selUserOwners.activeUser =$scope.contactOwnerID;
                        $scope.selUserOwners.tempUser = $scope.contactOwnerID;
                        $scope.selCompanyClient.activeCompany =$scope.companyContactModel.DeviceObjID;
                        $scope.selCompanyClient.tempCompany = $scope.companyContactModel.DeviceObjID;
                        $scope.disableIsClient = true;
                    }
                }
            }
            $scope.modalUser.hide();
        };

        ////////////////////////////////// user list END//////////////////////////////////////////
		function prepareRelationshipModel(contact,relationalContact,relationTypeID)
		{
		    // check before new object crated
            var relationModel = $filter('filter')(contact.ContactRelationshipMappings, {ContactDeviceObjID: contact.DeviceObjID, RelationshipWithContactDeviceObjID: relationalContact.DeviceObjID, ContactRelationshipTypeID: relationTypeID});
            if(relationModel.length > 0){
                if(contact.ContactTypeID == $scope.contactType.Individual) {
                    relationModel[0].ContactName = contact.FirstName + " " + contact.LastName;
                }else{
                    relationModel[0].ContactName = contact.CompanyName;
                }
                if(relationalContact.ContactTypeID == $scope.contactType.Individual) {
                    relationModel[0].RelationshipWithContactName = relationalContact.FirstName + " " + relationalContact.LastName;
                }else{
                    relationModel[0].RelationshipWithContactName = relationalContact.CompanyName;
                }
            }else{
                relationModel = contactService.models().relationshipModel;
                relationModel.ContactID = contact.ContactID;
                relationModel.ContactDeviceObjID = contact.DeviceObjID;
                relationModel.ContactRelationshipTypeID = relationTypeID;
                relationModel.RelationshipWithContactID = relationalContact.ContactID;

                if(contact.ContactTypeID == $scope.contactType.Individual) {
                    relationModel.ContactName = contact.FirstName + " " + contact.LastName;
                }else{
                    relationModel.ContactName = contact.CompanyName;
                }
                if(relationalContact.ContactTypeID == $scope.contactType.Individual) {
                    relationModel.RelationshipWithContactName = relationalContact.FirstName + " " + relationalContact.LastName;
                }else{
                    relationModel.RelationshipWithContactName = relationalContact.CompanyName;
                }
                relationModel.RelationshipWithContactDeviceObjID = relationalContact.DeviceObjID;
                contact.ContactRelationshipMappings.push(relationModel);
            }
            //return relationModel;
		};

        $scope.addContact = function()
        {
            if ($rootScope.isNetworkAvailable == false) {
                $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK').then(function () { });
                return;
            }

            productService.getAttachments(0).then(function(){

            // before save or update data validation for field
            var editFirstName = utility.removeWhitespace($scope.individualContactModel.FirstName);
            var editCompanyName = utility.removeWhitespace($scope.companyContactModel.CompanyName);
            if(editFirstName.length == 0){
                $cordovaDialogs.alert(ALERT_MESSAGE.FIRST_NAME, ALERT_MESSAGE.ALERT_TITLE, 'OK').then(function () { });
                return;
            }
            if ($scope.companyContactModel.IsClient == true) {
                if(editCompanyName.length == 0){
                    $cordovaDialogs.alert(ALERT_MESSAGE.COMPANY_NAME, ALERT_MESSAGE.ALERT_TITLE, 'OK').then(function () { });
                    return;
                }
            }

            //utility.commonValidationForContact($scope.individualContactModel,$scope.companyContactModel);

        	if ($scope.companyContactModel.IsClient == true) {
        		$scope.individualContactModel.CompanyName = $scope.companyContactModel.CompanyName;
        		$scope.companyContactModel.OwnerID = $scope.contactOwnerID;
        		$scope.companyContactModel.OwnerName = $scope.selContactOwner;
        		$scope.companyContactModel.ContactTierID = $scope.tier.tierId;
        		$scope.companyContactModel.ContactTierName = utility.getNameFromMultLangMasData($scope.tiers,$scope.companyContactModel.ContactTierID);
				$scope.companyContactModel.ContactSegmentID = $scope.segment.segmentId;
				$scope.companyContactModel.ContactSegmentName = utility.getNameFromMultLangMasData($scope.segments,$scope.companyContactModel.ContactSegmentID);
        		$scope.companyContactModel.IsConfidential = $scope.isContactConfidential;
        		$scope.individualContactModel.IsRepresentative = true;
        		$scope.companyContactModel.IsEmployer = false;

	        	var	businessFldsArr = $filter('filter')($scope.individualContactModel.Fields, {ContactFieldCategoryID: $scope.dynamicFieldType.Business});
	        	angular.forEach(businessFldsArr, function (obj, key) {
	        		obj.FieldValue = '';
					});
	        	$scope.companyContactModel.ContactUserMappings = $scope.userSelectionList;
        	}else{
        		$scope.companyContactModel.IsEmployer = true;
        		$scope.individualContactModel.OwnerID = $scope.contactOwnerID;
        		$scope.individualContactModel.OwnerName = $scope.selContactOwner;
        		$scope.individualContactModel.ContactTierID = $scope.tier.tierId;
        		$scope.individualContactModel.ContactTierName = utility.getNameFromMultLangMasData($scope.tiers,$scope.individualContactModel.ContactTierID);
				$scope.individualContactModel.ContactSegmentID = $scope.segment.segmentId;
				$scope.individualContactModel.ContactSegmentName = utility.getNameFromMultLangMasData($scope.segments,$scope.individualContactModel.ContactSegmentID);
				$scope.individualContactModel.IsConfidential = $scope.isContactConfidential;
        		var	businessFldsArr = $filter('filter')($scope.companyContactModel.Fields, {ContactFieldCategoryID: $scope.dynamicFieldType.Business});
	        	angular.forEach(businessFldsArr, function (obj, key) {
	        		obj.FieldValue = '';
					});
	        	$scope.individualContactModel.ContactUserMappings = $scope.userSelectionList;
        	}

        	if ($scope.individualContactModel.FirstName.length > 0 && $scope.companyContactModel.CompanyName.length > 0) {
                $scope.individualContactModel.EmployerName = $scope.companyContactModel.CompanyName;
                $scope.individualContactModel.EmployerID = $scope.companyContactModel.ContactID;
                $scope.individualContactModel.EmployerDeviceObjID = $scope.companyContactModel.DeviceObjID;
				var realationTypes = contactService.constants().relationTypes;
 			    var relationshipTypeID = 0;
 				if($scope.individualContactModel.IsRepresentative)
					relationshipTypeID = realationTypes.RepresentativeOf; //EmployeOf
 				else
 					relationshipTypeID = realationTypes.EmployeeOf; // representativeOf

 				var inverseRelationshipTypeID  = utility.getContactInverseRelationType(relationshipTypeID);

                prepareRelationshipModel($scope.individualContactModel,$scope.companyContactModel,relationshipTypeID);
                prepareRelationshipModel($scope.companyContactModel,$scope.individualContactModel,inverseRelationshipTypeID)
        		//$scope.individualContactModel.ContactRelationshipMappings.push(prepareRelationshipModel($scope.individualContactModel,$scope.companyContactModel,relationshipTypeID));
        		//$scope.companyContactModel.ContactRelationshipMappings.push(prepareRelationshipModel($scope.companyContactModel,$scope.individualContactModel,inverseRelationshipTypeID));
        	};

        	// Check the empty object in Communication and correspondence array
        	contactService.deleteEmptyObjInSubArray($scope.individualContactModel);
        	contactService.deleteEmptyObjInSubArray($scope.companyContactModel);

			var dateStringInUTC = utility.getDateStringInUTC(new Date());
			if ($scope.editModeFlag == 0) {
				$scope.individualContactModel.CreatorID = lgnUser.UserID;
				$scope.individualContactModel.CreatedOn = dateStringInUTC;
				$scope.individualContactModel.CreatorName = lgnUser.UserName;
				$scope.individualContactModel.LastContactedDate = dateStringInUTC;
				$scope.individualContactModel.NextContactedDate = utility.getNextContactDate($scope.individualContactModel.ContactTierID);

				$scope.companyContactModel.CreatorID = lgnUser.UserID;
				$scope.companyContactModel.CreatedOn = dateStringInUTC;
				$scope.companyContactModel.CreatorName = lgnUser.UserName;
				$scope.companyContactModel.LastContactedDate = dateStringInUTC;
				$scope.companyContactModel.NextContactedDate = utility.getNextContactDate($scope.companyContactModel.ContactTierID);
			}
        	$scope.individualContactModel.ModifiedBy = lgnUser.UserID;
			$scope.individualContactModel.ModifiedOn = dateStringInUTC;
			//$scope.individualContactModel.LastContactedDate = dateStringInUTC;

			$scope.companyContactModel.ModifiedBy = lgnUser.UserID;
			$scope.companyContactModel.ModifiedOn = dateStringInUTC;
			//$scope.companyContactModel.LastContactedDate = dateStringInUTC;

            if ($scope.editModeFlag == 1) {
                //#TODO check ind contact present in db if Y then Edit in db else insert
                //#TODO check compnay contact present in db if Y then Edit in db else insert
                //#TODO in case of new Rep add it to the compnay array
                var isIndividualContactPresentInDB = $filter('filter')($scope.allDeviceObjIdsByLoginUserID, {DeviceObjID: $scope.individualContactModel.DeviceObjID});
                var isCompanyContactPresentInDB = $filter('filter')($scope.allDeviceObjIdsByLoginUserID, {DeviceObjID: $scope.companyContactModel.DeviceObjID});

                if(isIndividualContactPresentInDB.length > 0 && isCompanyContactPresentInDB.length > 0)
                {
                    // update($scope.individualContactModel,$scope.companyContactModel)
                     contactService.updateContactToSql($scope.individualContactModel,$scope.companyContactModel).then(function (result) {
                        contactService.addContactToServer($scope.individualContactModel,$scope.companyContactModel).then(function (result){
                            bindSelectedModels();
                           contactService.bindServerResponseModels(result).then(function (result) {
                                contactService.uploadAttachmentsToServer($scope.individualContactModel.DeviceObjID,$scope.companyContactModel.DeviceObjID,GENERAL_CONFIG.MODULES.Contact);
                                    $state.go('tab.contact');
                                }, function (error) { alert(error); });
                        }, function (error) {
                            alert(error);
                        });
                     }, function (error) {  });
                }else if(isIndividualContactPresentInDB.length == 0){
                    //insert($scope.individualContactModel,null)
                    contactService.addContactToSql($scope.individualContactModel,null).then(function (result) {
                         if ($scope.individualContactModel.IsRepresentative) {
                            // if new rep then insert into company rep array also
                            $scope.companyContactModel.Representatives.push($scope.individualContactModel);
                         };
                        //update(null,$scope.companyContactModel)
                        contactService.updateContactToSql(null,$scope.companyContactModel).then(function (result) {
                            //$state.go('tab.contact');
                            contactService.addContactToServer($scope.individualContactModel,$scope.companyContactModel).then(function (result){
                                bindSelectedModels();
                                contactService.bindServerResponseModels(result).then(function (result) {
                                    contactService.uploadAttachmentsToServer($scope.individualContactModel.DeviceObjID,$scope.companyContactModel.DeviceObjID,GENERAL_CONFIG.MODULES.Contact);
                                    $state.go('tab.contact');
                                }, function (error) { alert(error); });
                            }, function (error) {
                                alert(error);
                            });
                        }, function (error) {  });
                    }, function (error) {  });

                }else if(isCompanyContactPresentInDB.length == 0){
                    //insert($scope.companyContactModel,null)
                    contactService.addContactToSql(null,$scope.companyContactModel).then(function (result) {
                        //update(individualContactModel,null)
                        contactService.updateContactToSql($scope.individualContactModel,null).then(function (result) {
                            contactService.addContactToServer($scope.individualContactModel,$scope.companyContactModel).then(function (result){
                                bindSelectedModels();
                                contactService.bindServerResponseModels(result).then(function (result) {
                                    contactService.uploadAttachmentsToServer($scope.individualContactModel.DeviceObjID,$scope.companyContactModel.DeviceObjID,GENERAL_CONFIG.MODULES.Contact);
                                    $state.go('tab.contact');
                                }, function (error) { alert(error); });
                            }, function (error) {
                                alert(error);
                            });
                        }, function (error) {  });
                    }, function (error) {  });
                }
            }else{
                var isCompanyContactPresentInDB = $filter('filter')($scope.allDeviceObjIdsByLoginUserID, {DeviceObjID: $scope.companyContactModel.DeviceObjID});
                if(isCompanyContactPresentInDB.length == 0){
                    contactService.addContactToSql($scope.individualContactModel,$scope.companyContactModel).then(function (result) {
                        contactService.addContactToServer($scope.individualContactModel,$scope.companyContactModel).then(function (result){
                            contactService.bindServerResponseModels(result).then(function (result) {
                                    contactService.uploadAttachmentsToServer($scope.individualContactModel.DeviceObjID,$scope.companyContactModel.DeviceObjID,GENERAL_CONFIG.MODULES.Contact);
                                    $state.go('tab.contact');
                            }, function (error) { alert(error); });
                        }, function (error) {
                            alert(error);
                        });
                    }, function (error) {  });
                }else{
                    contactService.addContactToSql($scope.individualContactModel,null).then(function (result) {
                        //update
                        contactService.updateContactToSql(null,$scope.companyContactModel).then(function (result) {
                            contactService.addContactToServer($scope.individualContactModel,$scope.companyContactModel).then(function (result){
                                contactService.bindServerResponseModels(result).then(function (result) {
                                    contactService.uploadAttachmentsToServer($scope.individualContactModel.DeviceObjID,$scope.companyContactModel.DeviceObjID);
                                    $state.go('tab.contact');
                                }, function (error) { alert(error); });
                            }, function (error) {
                                alert(error);
                            });
                        }, function (error) {  });
                    }, function (error) {  });
                }
              }
            })
        };

        function bindSelectedModels(){
            var contactIndModel = contactService.getSelectedIndividualContact();
            if(contactIndModel != null){
                contactIndModel = utility.syncModelWithCollection($scope.individualContactModel,contactIndModel);
                contactIndModel.Communications = $scope.individualContactModel.Communications;
                contactIndModel.Correspondences = $scope.individualContactModel.Correspondences;
                contactIndModel.ContactRelationshipMappings = $scope.individualContactModel.ContactRelationshipMappings;
                contactIndModel.Attachments = $scope.individualContactModel.Attachments;
                contactIndModel.ContactUserMappings = $scope.individualContactModel.ContactUserMappings;
                contactIndModel.Fields = $scope.individualContactModel.Fields;
            }else{
                contactIndModel = $scope.individualContactModel;
            }
            var contactComModel = contactService.getSelectedCompanyContact();
            if(contactComModel != null){
                contactComModel = utility.syncModelWithCollection($scope.companyContactModel,contactComModel);
                contactComModel.Communications = $scope.companyContactModel.Communications;
                contactComModel.Correspondences = $scope.companyContactModel.Correspondences;
                contactComModel.ContactRelationshipMappings = $scope.companyContactModel.ContactRelationshipMappings;
                contactComModel.Attachments = $scope.companyContactModel.Attachments;
                contactComModel.ContactUserMappings = $scope.companyContactModel.ContactUserMappings;
                contactComModel.Fields = $scope.companyContactModel.Fields;
                contactComModel.Representatives = $scope.companyContactModel.Representatives;
            }else{
                contactComModel = $scope.companyContactModel;
            }
        };

        //////////////////////////////////////////////////////////////////////////////////////
        //=====================Attachment Document code Start By NiTiN========================
          $scope.attachSelected = ''; $scope.attachType = true;
          $scope.contactAttachments = [];

          $ionicModal.fromTemplateUrl('app/views/common/attachment.html', {
              scope: $scope,
              animation: 'slide-in-left'
          }).then(function (modal) {
              $scope.modalAttachment = modal;
          });

          $scope.openAttachment = function (val) {
             $scope.attachSelected = val;
             $scope.attachmentModule = "Contact";
             $scope.attachmentsLength = 1;
             if($scope.attachSelected == 'I'){
                //angular.copy($scope.individualContactModel.Attachments, $scope.contactAttachments);
                angular.forEach($scope.individualContactModel.Attachments, function (imgObj) {
                    $scope.downloadImagesFromServer(imgObj);
                });
                if($scope.individualContactModel.Attachments.length==0)
                   $scope.modalAttachment.show();
             }else if($scope.attachSelected == 'C'){
                //angular.copy($scope.companyContactModel.Attachments, $scope.contactAttachments);
                angular.forEach($scope.companyContactModel.Attachments, function (imgObj) {
                    $scope.downloadImagesFromServer(imgObj);
                    if(attachmentsLength == $scope.companyContactModel.Attachments.length)
                        $scope.modalAttachment.show();
                    else attachmentsLength++;
                });
                 if($scope.companyContactModel.Attachments.length==0)
                    $scope.modalAttachment.show();
             }

          };
          $scope.closeAttachment = function () {
              for(var i = 0; i < $scope.contactAttachments.length; i++) {
                  var obj = $scope.contactAttachments[i];
                  if(!obj.IsChecked){
                        var imgName = obj.FileName+obj.Extension;
                        $scope.removeFile(imgName);
                        $scope.contactAttachments.splice(i, 1);
                  }
              }
              $scope.modalAttachment.hide();
          };
          $scope.saveAttachment = function () {
                if($scope.attachSelected == 'I'){
                    $scope.individualContactModel.Attachments = [];
                }else if($scope.attachSelected == 'C'){
                    $scope.companyContactModel.Attachments = [];
                }
                for(var i = 0; i < $scope.contactAttachments.length; i++) {
                    var obj = $scope.contactAttachments[i];
                    if(!obj.IsChecked){
                          obj.IsChecked = true;
                          //utility.sqlAttachInsertData(obj);
                    }
                    if($scope.attachSelected == 'I'){
                        $scope.individualContactModel.Attachments.push(obj);
                    }else if($scope.attachSelected == 'C'){
                        $scope.companyContactModel.Attachments.push(obj);
                    }
                }
                $scope.modalAttachment.hide();
          };
          $scope.removeFile = function(imgFileEntry) {
                window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem){
                    fileSystem.getDirectory('contactImages', { create: false, exclusive: false }, function (dirEntry) {
                        dirEntry.getFile(imgFileEntry, {create:false}, function(fileEntry){
                            fileEntry.remove(function(file){
                                ////console.log("File removed!");
                            },function(){
                                //console.log("error deleting the file " + error.code);
                            });
                        },function(){
                            //console.log("file does not exist");
                        });
                    });
                    },function(evt){
                        //console.log(evt.target.error.code);
                });
          }
          //========================Attachment Document code End=================================
          /////////////////////////////////////camera////////////////////////////////////////////
           // Take picture from camera
          $scope.takePicture = function() {
              var options = {
                  destinationType : Camera.DestinationType.FILE_URI,
                  sourceType : Camera.PictureSourceType.CAMERA, // Camera.PictureSourceType.PHOTOLIBRARY
                  allowEdit : false,
                  encodingType: Camera.EncodingType.JPEG,
                  popoverOptions: CameraPopoverOptions,
              };
              $cordovaCamera.getPicture(options).then(function(imageData) {
                    $scope.saveImageLocally(imageData);
              }, function(err) {
                  //console.log(err);
              });
          }
          // Take picture from gallery
          $scope.takeGalleryPicture = function() {
              var options = {
                  quality: 50,
                  targetWidth: 500,
                  targetHeight: 500,
                  destinationType : Camera.DestinationType.FILE_URI,
                  sourceType : Camera.PictureSourceType.PHOTOLIBRARY, // Camera.PictureSourceType.CAMERA
                  allowEdit : false,
                  encodingType: Camera.EncodingType.JPEG,
                  popoverOptions: CameraPopoverOptions,
              };
              $cordovaCamera.getPicture(options).then(function(imageData) {
                    $scope.saveImageLocally(imageData);
              }, function(err) {
                  //console.log(err);
              });
          }
          $scope.getImagePath = function(item) {
             var imgPath = cordova.file.cacheDirectory + "contactImages/"+ item.FileName + item.Extension;
             return imgPath;
          };
          $scope.removePicture = function (d) {
              var removeId = d.DeviceObjID;
              for(var i = 0; i < $scope.contactAttachments.length; i++) {
                  var obj = $scope.contactAttachments[i];
                  if(removeId == obj.DeviceObjID) {
                      var imgName = obj.FileName+obj.Extension;
                      $scope.removeFile(imgName);
                      $scope.contactAttachments.splice(i, 1);
                  }
              }
          }
          // Show image in full width on popup over
          $scope.showImage = function (d) {
              $ionicModal.fromTemplateUrl('app/views/common/image-popover.html', function ($ionicModal) {
                  $scope.imageModal = $ionicModal;
                  $scope.imageSrc = $scope.getImagePath(d);
                  $scope.imageModal.show();
              }, {
                  // Use our scope for the scope of the modal to keep it simple
                  scope: $scope,
                  controller: 'contactController',
                  // The animation we want to use for the modal entrance
                  animation: 'slide-in-up'
              });
          }
         $scope.closeImgModal = function() {
           $scope.imageModal.remove();
         };

         //close add contact screen
         $scope.closeContact = function () {
             //$state.go('tab.contact');
             $window.history.back();
         }

         // File save on our local folder storage
         ////console.log(FileTransfer);
         $scope.saveImageLocally = function(imageData) {
              /*var docTypeName = "";
              for(var i = 0; i < $scope.docTypeData.length; i++) {
                   if($scope.docTypeData[i].ID == $scope.attachment.docType){
                       docTypeName = $scope.docTypeData[i].typeName;
                   }
              }*/
              onImageSuccess(imageData);
              function onImageSuccess(fileURI) {
                  createFileEntry(fileURI);
              }
              function createFileEntry(fileURI) {
                  window.resolveLocalFileSystemURL(fileURI, copyFile, fail);
              }
              function copyFile(fileEntry) {
                  var name = fileEntry.fullPath.substr(fileEntry.fullPath.lastIndexOf('/') + 1);
                  var newName = makeid() + name;
                  window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem2) {
                      fileSystem2.getDirectory('contactImages', { create: true, exclusive: false }, function (dirEntry) {
                          fileEntry.copyTo(dirEntry,newName,onCopySuccess,fail);
                      });
                  },fail);
              }
              function onCopySuccess(entry) {
                  $scope.$apply(function () {
                       var parentDevId = ''; var parentEntityId = null;
                       var attachCategoryArray = utility.getMultLangMasData(MASTER_TABLE.AtchCat);
                       var attachCatId = $filter('filter')(attachCategoryArray, {Name: "Attachments"});
                       var extensionType = entry.name.split(".");
                       var MIMEContentType = '';
                       if(extensionType[1] == "jpg" || extensionType[1] == "jpeg"){
                            MIMEContentType = "image/jpeg";
                       }else if(extensionType[1] == "png"){
                            MIMEContentType = "image/png";
                       }else if(extensionType[1] == "gif"){
                            MIMEContentType = "image/gif";
                       }
                       if($scope.attachSelected == 'I'){
                           parentDevId = $scope.individualContactModel.DeviceObjID;
                           parentEntityId = $scope.individualContactModel.ContactID;
                       }else if($scope.attachSelected == 'C'){
                           parentDevId = $scope.companyContactModel.DeviceObjID;
                           parentEntityId = $scope.companyContactModel.ContactID;
                       }
                       // create attachment object module
                       var contactAttachModel = utility.attachMod().attachObj;
                       contactAttachModel.AttachmentCategoryID = attachCatId[0].AttachmentCategoryID;
                       contactAttachModel.EntityID = parentEntityId;
                       contactAttachModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                       contactAttachModel.ParentDeviceObjID = parentDevId;
                       contactAttachModel.FileName = extensionType[0];
                       contactAttachModel.MIMEContentType = MIMEContentType;
                       contactAttachModel.Extension = "."+extensionType[1];
                       $scope.contactAttachments.push(contactAttachModel);
                  });
                  // console.log($scope.contactAttachments);
              }
              function fail(error) {
                  //console.log("fail: " + error.code);
              }
              function makeid() {
                  var text = "";
                  var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
                  for (var i=0; i < 5; i++) {
                      text += possible.charAt(Math.floor(Math.random() * possible.length));
                  }
                  return text;
              }
         };
         $scope.downloadImagesFromServer = function (imgObj) {
             // Check the image in local cache or download the image from server
             if(imgObj.ModuleID == GENERAL_CONFIG.MODULES.Contact){
                 var folderName = "contactImages";
             }
             var filename = imgObj.FileName + imgObj.Extension;
             if($scope.attachSelected == 'I'){
                var totalRecLength = $scope.individualContactModel.Attachments.length;
                var sourceCopyArray = $scope.individualContactModel.Attachments;
             }
             if($scope.attachSelected == 'C'){
                var totalRecLength = $scope.companyContactModel.Attachments.length;
                var sourceCopyArray = $scope.companyContactModel.Attachments;
             }

             $window.resolveLocalFileSystemURL(cordova.file.cacheDirectory, function(fileSystem2) {
                   fileSystem2.getDirectory(folderName, { create: true, exclusive: false }, function (dirEntry) {
                         dirEntry.getFile(filename, {create:false}, function(fileEntry){
                              if($scope.attachmentsLength == totalRecLength){
                                   angular.copy(sourceCopyArray, $scope.contactAttachments);
                                   $scope.modalAttachment.show();
                              }else{ $scope.attachmentsLength++; }
                         },function(){
                             contactService.getAttachmentsDownload(imgObj.AttachmentID).then(function (attachmentsRes) {
                                 var myImgBase64 = attachmentsRes.Base64String;
                                 var contentType = attachmentsRes.MIMEContentType;
                                 var actualImage = utility.b64toBlob(myImgBase64,contentType);
                                 var dirFolderPath = cordova.file.cacheDirectory + folderName;
                                 $window.resolveLocalFileSystemURL(dirFolderPath, function(dir) {
                                     dir.getFile(filename, {create:true}, function(file) {
                                         console.log("File created successfully.");
                                         file.createWriter(function(fileWriter) {
                                             console.log("Writing content to file");
                                             fileWriter.write(actualImage);
                                              if($scope.attachmentsLength == totalRecLength){
                                                 angular.copy(sourceCopyArray, $scope.contactAttachments);
                                                 $scope.modalAttachment.show();
                                              }else{ $scope.attachmentsLength++; }
                                         }, function(){
                                             alert('Unable to save file in path '+ folderpath);
                                         });
                                     });
                                 });
                             });
                         });
                   });
             });
         }
        //=====================Attachment Document code End By NiTiN========================
    }
})();
