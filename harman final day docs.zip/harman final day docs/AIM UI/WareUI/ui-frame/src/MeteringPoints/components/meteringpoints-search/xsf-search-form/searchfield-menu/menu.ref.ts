import { OverlayRef } from "@angular/cdk/overlay";
import { Observable } from "rxjs";
import { EventEmitter } from "@angular/core";

export class MeteringpointsSearchfieldMenuRef {
    private closedEventEmitter: EventEmitter<any> = new EventEmitter();
    closed$: Observable<any> = this.closedEventEmitter.asObservable();

    private defaultSearchFieldSelectEmitter: EventEmitter<string> = new EventEmitter();
    defaultSearchFieldSelect$: Observable<string> = this.defaultSearchFieldSelectEmitter.asObservable();

    backdropClick$!: Observable<any>;

    constructor(public overlay: OverlayRef) {
        this.backdropClick$ = overlay.backdropClick();
    }

    setDefaultSearchFieldSelected(defaultSearchField: string) {
        this.defaultSearchFieldSelectEmitter.emit(defaultSearchField);
    }

    close() {
        this.closedEventEmitter.emit();
        this.overlay.dispose();
    }

    isVisible() {
        return this.overlay && this.overlay.overlayElement;
    }

    getPosition() {
        return this.overlay.overlayElement.getBoundingClientRect();
    }
}
