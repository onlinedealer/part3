(function () {
    'use strict';

    angular.module('arm').controller('conversationParticipantList',
                ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate', conversationParticipantList]);

    function conversationParticipantList($scope, $state, $ionicModal, $ionicSideMenuDelegate) {
			
			$scope.messageDetail = function(messageId) {
			//console.log(messageId)
            $state.go('tab.conversationDetail', {
               //
            });
        }  
	};
})();







