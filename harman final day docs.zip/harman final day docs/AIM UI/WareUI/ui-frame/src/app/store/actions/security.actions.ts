import { createAction, props } from "@ngrx/store";

export const GetUserInfo = createAction("[Security] Get User Info");
export const GetUserInfoSuccess = createAction("[Security] Get User Info Success", props<{ response: any }>());
export const GetUserInfoFail = createAction(
    "[Security] Get User Info Fail",
    props<{
        error: any;
    }>()
);
export const UpdateSession = createAction("[Security] Update Session");
export const UpdateSessionSuccess = createAction("[Security] Update Session Success", props<{ response: any }>());
export const UpdateSessionFail = createAction("[Security] Update Session Fail", props<{ error: any }>());

export const ShowTimeoutDialog = createAction("[Security] Show Timeout Dialog");
export const ClosedTimeoutDialog = createAction("[Security] Closed Timeout Dialog");

export const Logout = createAction("[Security] Logout");
