import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ClubGenericErrorComponent } from '../shared/components/club-generic-error/club-generic-error.component';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AjaxUtilityService } from '../shared/utility/ajax-utility.service';
import { HttpResponse } from '@angular/common/http';
import * as _ from 'underscore';
import { Title } from '@angular/platform-browser';
import { RouteConfigurations } from '../shared/utility/club-constants.service';

@Component({
  selector: 'app-carepass-self-unenroll',
  templateUrl: './carepass-self-unenroll.component.html',
  styleUrls: ['./carepass-self-unenroll.component.scss']
})

export class CarepassSelfUnenrollComponent implements OnInit {

  serviceError = false;   // flag to show or hide service error  
  getCancellationInfoDetails: any; // variable to store response from getCancellationInfo service
  userDescription: string; // String to display user information message on screen
  cancellationSubmitted: boolean; // flag to display cancel initiation screen or cancel success screen
  cancelDescription: any = { // updateCancellation service req structure
    'nameTxt': '',
    'refundTxt': '',
    'rewardTxt': ''
  }
  public cancellationForm: FormGroup;


  constructor(
    private _activatedRoute: ActivatedRoute,
    private _fb: FormBuilder,
    private _ajaxUtility: AjaxUtilityService,
    private _title: Title
  ) {
    _title.setTitle(RouteConfigurations.carepassSelfUnenrollTitle);
  }

  ngOnInit() {
    /**
     * TODO: need to change logic once we have finalized UX
     */
    // Temporarily keeping '8005' as default value of cancellation dropdown.
    this.cancellationForm = this._fb.group({
      cancelEnrolmentReason: ['0'],
      cancelEnrolmentReasonDescription: ['', [Validators.maxLength(120)]]
    });
    this.getCancellationInfo();
  }

  /**
   * @function getCancellationInfo,
   * @argument none,
   * @description function call to be called on page initialization to initialize
   * page with cancellation details
   */
  getCancellationInfo() { // service call to get user and cancellation details
    this._activatedRoute.data.subscribe(
      (data: { getCancellationInfo: any }) => {
        if (data.hasOwnProperty('getCancellationInfo')
          && data.getCancellationInfo.hasOwnProperty('getCarePassCancellationInfoResponse')) {
          const response = data['getCancellationInfo']['getCarePassCancellationInfoResponse'];
          if (response.hasOwnProperty('header')
            && response.header.hasOwnProperty('statusCode')
            && '0000' === response.header.statusCode) {
            this.getCancellationInfoDetails = response.additionalDetails;
            if (response.hasOwnProperty('additionalDetails')
              && response.additionalDetails.hasOwnProperty('personalInfo')
              && response.additionalDetails.hasOwnProperty('subscriptionInfo')) {
              this.userDescription = response.additionalDetails.personalInfo['firstName']
                + ', if you cancel today, your membership benefits will expire on ' + response.additionalDetails.subscriptionInfo['benefitEligibilityDt']
                + '.';
                if(response.additionalDetails.subscriptionInfo['refundTotal']) {
                  this.userDescription += ' Your refund $' + response.additionalDetails.subscriptionInfo['refundTotal']
                  + ' for ' + response.additionalDetails.subscriptionInfo['refundMonths']
                  + ' month(s) will include taxes and fees and be issued within 3-7 business days.'
                }
            }
          } else {
            this.serviceError = true;
          }
        } else {
          this.serviceError = true;
        }
      },
      (err) => {
        console.error(err);
        this.serviceError = true;
      }
    );
  }

  /**
   * @function submitCancellation,
   * @argument none,
   * @description method to be called on submit of cancellation form
   * to initiate cancellation
   */
  submitCancellation() {
    const cancellationReq = { // Request structure for submitCancellation
      "updateCarePassEnrollmentRequest": {
        "requestType": 'Cancel',
        "reasonCode": this.cancellationForm.get('cancelEnrolmentReason').value,
        "reasonDescription": ''
      }
    }
    _.map(this.getCancellationInfoDetails.cancelReasonCodes, function(cancelReason, index) {
      if (this.cancellationForm.get('cancelEnrolmentReason').value === cancelReason['cancelReasonCode']) {
        cancellationReq.updateCarePassEnrollmentRequest.reasonDescription = cancelReason['cancelReasonDesc'];
      }
    }, this);

    if('0' === this.cancellationForm.get('cancelEnrolmentReason').value) {
      delete cancellationReq['updateCarePassEnrollmentRequest']['reasonCode'];
      if(this.cancellationForm.get('cancelEnrolmentReasonDescription').value.length) {
        cancellationReq.updateCarePassEnrollmentRequest.reasonDescription = this.cancellationForm.get('cancelEnrolmentReasonDescription').value;
      } else {
        delete cancellationReq['updateCarePassEnrollmentRequest']['reasonDescription'];        
      }
    } else {
      if(this.cancellationForm.get('cancelEnrolmentReasonDescription').value.length) {
        cancellationReq.updateCarePassEnrollmentRequest.reasonDescription += '-' + this.cancellationForm.get('cancelEnrolmentReasonDescription').value;
      }
    }
    console.info(cancellationReq);
    this.cancellationSubmitted = true;
    this._ajaxUtility.sendRequest('updateCarePassEnrollment', cancellationReq)
      .subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('updateCarePassEnrollmentResponse')) {
          response = data['updateCarePassEnrollmentResponse'];
          if (response.hasOwnProperty('header')
            && response.header.hasOwnProperty('statusCode')
            && '0000' === response.header.statusCode) {

            this.cancelDescription.nameTxt = response.additionalDetails.personalInfo['firstName']
              + ', you\'ve successfully unenrolled from CarePass';
            this.cancelDescription.refundTxt = response.additionalDetails.subscriptionInfo['refundTotal'] ? 'Your refund of $'
              + response.additionalDetails.subscriptionInfo['refundTotal']
              + ' for '
              + response.additionalDetails.subscriptionInfo['refundMonths']
              + ' month(s) will include taxes and fees and be issued within 3-7 business days.' : null;
            this.cancelDescription.rewardTxt = 'Your CarePass dashboard and any available rewards will remain active until the expiration date of '
              + response.additionalDetails.subscriptionInfo['benefitEligibilityDt'];
          } else {
            this.serviceError = true;
          }
        } else {
          this.serviceError = true;
        }
      },
      (err) => {
        console.error(err);
        this.serviceError = true;
      },
      () => {
      }
      );
  }

}
