/**
 * Entity card common component
 * Can be used to show -
 *    - card with header text
 *    - show table depending upon the inputs
 *    - show filters for the table
 *    - emit various events on table row selection or checkbox click
 * Examples ---
 *    `<p-connect-entity-card showFilter=true headerText="my header">
 *      </p-connect-entity-card>`
 */

import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { EntityCardHeaderModel } from '../entity-card-header.model';

/**
 * This component displays one table of information. That information can be filtered, sorted, and the dispaly columns can be customized.
 */

@Component({
  selector: 'discovery-png-entity-card',
  templateUrl: './entity-card.component.html',
  styleUrls: ['./entity-card.component.scss']
})
export class EntityCardComponent {
  /**
   * Filter fields
   */
  @Input() filterFields: string[];

  /**
   * Selected data from the table (through checkbox/tri-state checkbox)
   */
  @Input() selectedData: any[];

  /**
   * Empty table message
   */
  @Input() emptyMessage = 'png.entitySelector.card.noData';

  /**
   * Row selection event emitter
   */
  @Output() rowSelected = new EventEmitter<any>();

  /**
   * Checkbox data selection event emitter
   */
  @Output() dataSelected = new EventEmitter<any>();

  /**
   * Checkbox data unselected event emitter
   */
  @Output() dataUnselected = new EventEmitter<any>();

  /**
   * Header checkbox toggle selection event
   */
  @Output() selectAllRows = new EventEmitter<any>();

  /** Used to update the data shown. */
  @ViewChild('dataTable')
  /**
   * Data for display in the entity card.
   */
  dataTable: any;
  /**
   * Header text for the card
   */
  @Input() headerText: string;

  /**
   * Filter flag
   * Defaults to true
   */
  @Input() showFilter = true;

  /**
   * Placeholder text for the filter input
   */
  @Input() filterText: string;

  /**
   * Flag to allow row to be selected
   * Defaults to true which makes selection as multiple
   * when false, the selection is single
   */
  @Input() allowSelection = true;

  /**
   * headers for the primeng table
   */
  @Input() headers: Array<EntityCardHeaderModel>;

  /**
   * meta key field for primeng table
   */
  @Input() keyField?: string;

  /**
   * data to be displayed as a table
   */
  @Input() apiData = [];

  /**
   * Flag to show loader
   */
  @Input() isLoading = false;

  /**
   * flag to show/hide table row checkbox
   */
  @Input() showCheckBox?: boolean;

  /**
   * flag to show/hide table header checkbox
   */
  @Input() showSelectAllCheckBox?: boolean;

  /**
   * flag enables to use primeng tri-state checkbox
   */
  @Input() showTriState?: boolean;

  /**
   * primeng input for row hover state
   */
  @Input() rowHover?: boolean;

  /**
   * primeng input to enable/disable scrollable feature
   */
  @Input() scrollable?: boolean;

  /**
   * primeng input for table scroll height
   */
  @Input() scrollHeight?: string;

  /**
   * primeng input for virtual scroll height
   */
  @Input() virtualScroll?: boolean;

  /**
   * primeng input for row height
   */
  @Input() virtualRowHeight?: number;

  /**
   * primeng input for number of rows
   */
  @Input() numOfRows?: number;

  /**
   * primeng input for enabling/disabling lazy loading feature
   */
  @Input() lazy?: boolean;

  /**
   * primeng input for lazy loading data
   */
  lazyCallBack?(): any;

  /** @internal */
  // eslint-disable-next-line

  /** @internal */
  // eslint-disable-next-line

  /**
   * Depending upon the event type, allowSelection and showCheckbox parameters,
   * trigger CheckBox selection or RowSelection methods
   */
  rowSelection($event: any, rowData?: any) {
    let parentelem;
    // when we don't want to make any selection on table row
    if (!this.allowSelection && !this.showCheckBox) {
      this.stopPropagation($event);
      return;
    }
    if ($event.type === 'checkbox') {
      parentelem = $event.originalEvent?.target.parentElement.parentElement.parentElement.parentElement;
      this.updateRowStyle(parentelem, rowData);
    } else if ($event.target?.classList.toString().indexOf('p-checkbox') < 0) {
      parentelem = $event.target.parentElement;
      this.updateRowStyle(parentelem, rowData);
      return;
    }
    this.checkBoxSelection($event, rowData);
  }

  /**
   * Custom way to highlight clicked row and emit the event
   * This doesn't trigger on checkbox selection
   */
  updateRowStyle(parentElement: any, rowData?: any) {
    const allRows = parentElement?.parentElement?.querySelectorAll('tr');
    // remove all existing highlights
    if (allRows) {
      allRows.forEach((row) => row.classList.remove('p-highlight'));
    }
    // highlight current target row and emit the event
    parentElement?.classList?.add('p-highlight');
    if (rowData) {
      this.rowSelected.emit(rowData);
    }
  }

  /**
   * Checkbox select event
   */
  checkBoxSelection($event: any, rowData?: any) {
    this.stopPropagation($event);
    // custom logic to update selectedData for tri-state
    if (this.showTriState) {
      this.dataSelected.emit(rowData);
      return;
    }
    this.dataSelected.emit($event.data);
  }

  /**
   * Checkbox un-select event
   */
  checkBoxUnselect($event: any) {
    this.stopPropagation($event);
    this.dataUnselected.emit($event.data);
  }

  /**
   * Stop event propagation
   */
  stopPropagation(evt: any) {
    // there are events like on tri-state checks, we don't have original event
    // in the event, thus filling it up with the evt object itself
    if (!evt.originalEvent) {
      evt.originalEvent = evt;
    }
    evt.originalEvent.stopPropagation();
    evt.originalEvent.stopImmediatePropagation();
    evt.originalEvent.preventDefault();
  }

  /**
   * Filter data as per the input
   */
  filterData($event: string) {
    this.dataTable.filterGlobal($event, 'contains');
  }

  /**
   * Providing a hook, so that on toggle of header checkbox
   * user can do so some custom stuff
   * In the simple implementation when there is no tri-state
   * checkbox, the selection works automatically. However in case
   * of Tri-state checkbox, it doesn't. Thus a hook is provided, through
   * which a custom login can be written by the user for making row selections
   */
  selectAll($event: any) {
    $event.triState = this.showTriState;
    this.selectAllRows.emit($event);
  }

  /**
   * Update the row selected value with the tri-state change
   */
  triStateChange($evt: any, rowData: any) {
    rowData.selected = $evt;
  }
}
