import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ProgressIndicatorStateService } from '@shared/components/progress-indicator/progress-indicator-state.service';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { BaseComponent } from 'src/app/core/base.component';
import { Pipeline } from '../../../shared/pipeline';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { EventApiService } from '../../shared/event-api.service';
import { CreateTopicsSubjectsErrorsSidebarComponent } from '../create-topics-subjects-errors-sidebar/create-topics-subjects-errors-sidebar.component';
import { SUBJECT_TOPIC_SIDEBAR_CONST } from '../subject_topic_sidebar_constant';

@Component({
  selector: 'p-connect-create-topics-subjects-sidebar',
  templateUrl: './create-topics-subjects-sidebar.component.html'
})
export class CreateTopicsSubjectsSidebarComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(CreateTopicsSubjectsErrorsSidebarComponent) createTopicSubjectsErrorsSidebar: CreateTopicsSubjectsErrorsSidebarComponent;
  @Output() sendErrorToMappingOverwiew: EventEmitter<any> = new EventEmitter<any>();

  component: { createTopic: true };

  constructor(
    private readonly pipelineMappingService: PipelineMappingService,
    public router: Router,
    private readonly progressIndicatorStateService: ProgressIndicatorStateService,
    private eventApiService: EventApiService
  ) {
    super(router);
  }

  knobSize: number = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_KNOB_SIZE;
  knobStrokeWidth: number = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_KNOB_STROKE_SIZE;
  knobRangeColor: string = SUBJECT_TOPIC_SIDEBAR_CONST.KNOB_RANGE_COLOR;
  knobTextColor: string = SUBJECT_TOPIC_SIDEBAR_CONST.KNOB_TEXT_COLOR;
  totalTopicsSuccessCount: number = 0;
  totalSubjectsSuccessCount: number = 0;
  topicFailureErrors = false;
  subjectFailureErrors = false;
  errorMessage = [];
  totalTopicsValue: number = 0;
  totalSubjectsValue: number = 0;
  pollTopicStatus: any;
  pollSubjectStatus: any;
  progressLoader: boolean = false;
  topicProgressValueColor = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_VALUE_SUCCESS_COLOR;
  subjectProgressValueColor = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_VALUE_SUCCESS_COLOR;
  topicsStatusComplete = false;
  subjectsStatusComplete = false;

  @Input() pipeline: Pipeline;

  ngOnInit() {
    this.pipelineMappingService.mappingNextActionForSidebar.subscribe((res) => {
      this.handleTopicsSubjectsProgress(res.topicLength, res.subjectLength);
      this.open();
    });
    this.pipelineMappingService.openCreateTopicsSubjectsSidebar.subscribe(() => {
      this.open();
    });
  }

  ngOnDestroy(): void {
    clearInterval(this.pollSubjectStatus);
    clearInterval(this.pollTopicStatus);
    this.secondaryButton.isDisabled = true;
  }

  handleTopicsSubjectsProgress(topicLength: number, subjectLength: number) {
    if (topicLength === 0) {
      this.pipeline.createTopic = false;
    }
    if (subjectLength === 0) {
      this.pipeline.createSubject = false;
    }
  }

  secondaryButton: SidebarButton = {
    isDisabled: true,
    id: 'secondaryButton',
    text: 'pipelines.STAGES.MAPPING.CREATE_TOPIC_SUBJECTS_SIDEBAR.BUTTONS.CLOSE_BUTTON'
  };

  closeButtonClicked() {
    this.sidebarComponent?.close();
    if (this.pipeline.createTopic && this.pipeline.createSubject === false) {
      if ((this.totalTopicsSuccessCount * this.totalTopicsValue) / 100 === this.totalTopicsValue) {
        this.handleStepChange();
      }
    } else if (this.pipeline.createTopic === false && this.pipeline.createSubject) {
      if ((this.totalSubjectsSuccessCount * this.totalSubjectsValue) / 100 === this.totalSubjectsValue) {
        this.handleStepChange();
      }
    } else if (this.pipeline.createTopic && this.pipeline.createSubject) {
      if (
        (this.totalSubjectsSuccessCount * this.totalSubjectsValue) / 100 === this.totalSubjectsValue &&
        (this.totalTopicsSuccessCount * this.totalTopicsValue) / 100 === this.totalTopicsValue
      ) {
        this.handleStepChange();
      }
    }
    this.pipelineMappingService.refreshTableMappingGrid.next();
    this.subjectProgressValueColor = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_VALUE_SUCCESS_COLOR;
    this.topicProgressValueColor = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_VALUE_SUCCESS_COLOR;
    this.topicFailureErrors = false;
    this.subjectFailureErrors = false;
    this.secondaryButton.isDisabled = true;
    this.subjectsStatusComplete = false;
    this.topicsStatusComplete = false;
    clearInterval(this.pollSubjectStatus);
    clearInterval(this.pollTopicStatus);
  }

  handleStepChange() {
    this.navigateTo(`/pipelines/${this.pipeline.id}/edit/finalize`);
    this.progressIndicatorStateService.setActiveStepIndex(4);
    this.progressIndicatorStateService.setIsComplete(3, true);
  }

  open() {
    this.sidebarComponent.open();
    this.progressLoader = true;
    this.getStatusTopicAndSubjectsCreation();
  }

  onSeeErrorsClicked(event) {
    this.createTopicSubjectsErrorsSidebar?.open();
    if (event === SUBJECT_TOPIC_SIDEBAR_CONST.SUBJECT_EVENT) {
      this.getStatusOfSubjectCreation();
    } else {
      this.getStatusOfTopicCreation();
    }
  }
  getStatusTopicAndSubjectsCreation() {
    clearInterval(this.pollTopicStatus);
    clearInterval(this.pollSubjectStatus);
    if (this.pipeline?.createTopic) {
      this.pollTopicStatus = setInterval(() => {
        this.getStatusOfTopicCreation();
      }, SUBJECT_TOPIC_SIDEBAR_CONST.INTERVAL_TIME);
    }
    if (this.pipeline?.createSubject) {
      this.pollSubjectStatus = setInterval(() => {
        this.getStatusOfSubjectCreation();
      }, SUBJECT_TOPIC_SIDEBAR_CONST.INTERVAL_TIME);
    }
  }

  getStatusOfSubjectCreation() {
    this.eventApiService.getStatusOfSubjectsCreation(this.pipeline?.id).subscribe({
      next: (response: any) => {
        this.progressLoader = false;
        this.totalSubjectsSuccessCount = Math.trunc((response.successCount / response.totalCount) * 100);
        this.totalSubjectsValue = response.totalCount;
        if (response.status === SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_STATUS_COMPLETE) {
          clearInterval(this.pollSubjectStatus);
          this.subjectsStatusComplete = true;
        }
        if (response.failureCount > 0) {
          this.subjectFailureErrors = true;
          this.errorMessage = response.errResponse;
          this.eventApiService.emitSubjectFailureErrors(this.errorMessage);
          this.subjectProgressValueColor = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_VALUE_FAILURE_COLOR;
        }
        if (this.subjectsStatusComplete) {
          if (this.pipeline.createTopic && this.pipeline.createSubject && this.topicsStatusComplete) {
            this.enableSidebarCollapseButton();
          } else if (this.pipeline.createTopic === false) {
            this.enableSidebarCollapseButton();
          }
        }
      },
      error: (err: HttpErrorResponse) => {
        if (err.status === 422) {
          this.pipeline.createSubject = false;
          clearInterval(this.pollSubjectStatus);
        }
      }
    });
  }

  enableSidebarCollapseButton() {
    this.secondaryButton.isDisabled = false;
  }

  getStatusOfTopicCreation() {
    this.eventApiService.getStatusOfTopicsCreation(this.pipeline?.id).subscribe({
      next: (response: any) => {
        this.progressLoader = false;
        this.totalTopicsSuccessCount = Math.trunc((response.successCount / response.totalCount) * 100);
        this.totalTopicsValue = response.totalCount;
        if (response.status === SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_STATUS_COMPLETE) {
          clearInterval(this.pollTopicStatus);
          this.topicsStatusComplete = true;
        }
        if (response.failureCount > 0) {
          this.topicFailureErrors = true;
          this.errorMessage = response.errResponse;
          this.eventApiService.emitSubjectFailureErrors(this.errorMessage);
          this.topicProgressValueColor = SUBJECT_TOPIC_SIDEBAR_CONST.PROGRESS_VALUE_FAILURE_COLOR;
        }
        if (this.topicsStatusComplete) {
          if (this.pipeline.createSubject && this.pipeline.createTopic && this.subjectsStatusComplete) {
            this.enableSidebarCollapseButton();
          } else if (this.pipeline.createSubject === false) {
            this.enableSidebarCollapseButton();
          }
        }
      },
      error: (err: HttpErrorResponse) => {
        if (err.status === 422) {
          this.pipeline.createTopic = false;
          clearInterval(this.pollTopicStatus);
        }
      }
    });
  }
}
