export interface EntityCardHeaderModel {
  fieldName: string;
  displayName: string;
  sort?: boolean;
  isHidden?: boolean;
  hasIcon?: boolean;
}
