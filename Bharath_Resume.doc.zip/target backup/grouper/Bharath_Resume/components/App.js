import React from 'react'
import { MuiThemeProvider } from '@material-ui/core/styles'

import { BrowserRouter, Route, Switch } from 'react-router-dom'
import LaunchPage from './launchPage'
import muiTheme from '../config/themeConfig'
import LoginSuccess from './Login/LoginSuccess'

const App = () => (
  <MuiThemeProvider theme={muiTheme}>
    <BrowserRouter>
      <Switch>
        {/* Display SignInSuccess without Layout */}
        <Route exact path="/auth/login" component={LoginSuccess} />
        <Route component={LaunchPage} />
      </Switch>
    </BrowserRouter>
  </MuiThemeProvider>
)

export default App
