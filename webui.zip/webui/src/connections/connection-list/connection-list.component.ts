import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import {
  ConnectionsStatesModel,
  ConnectionModel,
  ConnectionService,
  SharedConstants,
  SecondaryNavItemsService
} from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { TranslocoService } from '@ngneat/transloco';
import { Table } from 'primeng/table';
import { ConfirmationService, MenuItem } from 'primeng/api';

@Component({
  selector: 'discovery-connection-list',
  templateUrl: './connection-list.component.html',
  styleUrls: ['./connection-list.component.css'],
  providers: [ConfirmationService]
})
export class ConnectionListComponent implements OnInit {
  /**
   *
   */
  @ViewChild('connectionTable') connectionTable: Table;

  /**
   *
   */
  connectionList: ConnectionModel[];
  items: MenuItem[];
  sidebarVisible: boolean;
  connectionType: string;
  configureId: string;
  configureViewType: string;
  isLoading = false;

  /**
   *
   */
  ConnectionsStatesModel: typeof ConnectionsStatesModel = ConnectionsStatesModel;

  /**
   *
   */
  testInProgress: Record<string, boolean> = {};

  /**
   * menu items for secondary navigation left sliding menu
   */
  navItems: MenuItem[];

  /**
   *
   * @param connectionService
   * @param toastrService
   * @param translateService
   * @param confirmationService
   */
  constructor(
    private connectionService: ConnectionService,
    private toastrService: ToastrService,
    private translocoService: TranslocoService,
    private confirmationService: ConfirmationService,
    private navItemService: SecondaryNavItemsService
  ) {}

  /**
   *
   */
  ngOnInit(): void {
    this.loadConnectionList();
    this.navItems = this.navItemService.getNavItems();
  }

  /**
   *
   * @param $event
   * @param contains
   */
  filterGlobal($event: Event, contains: string) {
    this.connectionTable.filterGlobal(($event.target as HTMLInputElement).value, contains);
  }

  /**
   *
   * @param connectionModel
   */
  testConnection(connectionModel: ConnectionModel) {
    this.testInProgress[connectionModel.id] = true;
    this.isLoading = true;
    this.connectionService.testConnectionByID(connectionModel.id).subscribe(
      (response) => {
        this.isLoading = false;
        this.testInProgress[connectionModel.id] = false;
        this.toastrService.success(
          this.translocoService.translate('discoveryConnections.connectionList.testSuccessful', {
            connectionName: connectionModel.name
          })
        );
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.isLoading = false;
        this.testInProgress[connectionModel.id] = false;
        if (httpErrorResponse.status === 404) {
          this.toastrService.error(
            this.translocoService.translate('discoveryConnections.connectionList.connectionNotFound')
          );
        } else {
          this.toastrService.error(
            this.translocoService.translate('discoveryConnections.connectionList.testFailed', {
              connectionName: connectionModel.name,
              serverMessage:
                httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                  ? httpErrorResponse.error.message
                  : ''
            })
          );
        }
      }
    );
  }

  /**
   *
   * @param connectionModel
   */
  deleteConnection(connectionModel: ConnectionModel) {
    this.confirmationService.confirm({
      message: this.translocoService.translate('discoveryConnections.connectionList.deleteMessage', {
        connectionName: connectionModel.name
      }),
      header: this.translocoService.translate('discoveryConnections.connectionList.deleteTitle'),
      icon: 'pi pi-info-circle',
      accept: () => {
        this.connectionService.deleteConnection(connectionModel.id).subscribe(
          (response) => {
            this.loadConnectionList();
          },
          (httpErrorResponse: HttpErrorResponse) => {
            let errorMsg = httpErrorResponse.error.message;
            if (httpErrorResponse.status === 404) {
              errorMsg = this.translocoService.translate('discoveryConnections.connectionList.connectionNotFound');
            }
            if (httpErrorResponse.status !== 403) {
              this.toastrService.error(errorMsg);
            }
          }
        );
      },
      reject: () => {
        console.log('Delete Cancel');
      }
    });
  }

  connectionContextMenu(rowData: ConnectionModel) {
    this.items = [
      {
        label: this.translocoService.translate('discoveryConnections.connectionList.testConnection'),
        command: (click) => this.testConnection(rowData)
      },
      { separator: true },
      {
        label: this.translocoService.translate('discoveryConnections.connectionList.editMenu'),
        command: (click) =>
          this.showConnectionConfigureSidebar(
            SharedConstants.connectionConfigureModes.EDIT,
            rowData.id,
            rowData.resourceConnectionType
          )
      },

      {
        label: this.translocoService.translate('discoveryConnections.connectionList.duplicateMenu'),
        command: (click) =>
          this.showConnectionConfigureSidebar(
            SharedConstants.connectionConfigureModes.COPY,
            rowData.id,
            rowData.resourceConnectionType
          )
      },
      {
        label: this.translocoService.translate('discoveryConnections.connectionList.deleteMenu'),
        command: (click) => this.deleteConnection(rowData)
      }
    ];
  }

  /**
   *
   */
  loadConnectionList() {
    this.isLoading = true;
    this.connectionService.getConnectionList().subscribe(
      (connectionModels: ConnectionModel[]) => {
        this.isLoading = false;
        this.connectionList = connectionModels;
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.isLoading = false;
        this.toastrService.error(httpErrorResponse.message);
      }
    );
  }

  createConnection(connectionType?: string) {
    if (connectionType) {
      this.connectionType = connectionType;
    }
    this.showConnectionConfigureSidebar(SharedConstants.connectionConfigureModes.ADD);
  }

  showConnectionConfigureSidebar(viewType: string, id?, resourceConnectionType?: string) {
    this.sidebarVisible = true;
    if (id) {
      this.configureId = id;
      this.connectionType = resourceConnectionType;
    }

    this.configureViewType = viewType;
  }
}
