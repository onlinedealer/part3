export interface Columns {
    columnId: string;
    columnName: string;
    showColumn: boolean;
    position: number;
    draggedColumn?: boolean;
    columnWidth: number;
    columnType?: string;
    tooltip?: string;
    contextMenu?: boolean;
}
