import { HttpClientTestingModule } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { AgentsApiService } from './agents-api.service';

describe('AgentsService', () => {
  let service: AgentsApiService;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(AgentsApiService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
