import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import { getCollectionMTAOptions, getCollectionMTAUOMOptions } from '../common/Utils/CommonUtils'
import IntegrationReactSelect from '../common/GrouperAutoComplete/IntegrationReactSelect'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormHelperText from '@material-ui/core/FormHelperText'
import FormControl from '@material-ui/core/FormControl'

const styles = theme => ({
  container: {
    padding: 10,
  },
  formControl: {
    // marginTop: 10,
    width: '100%',
  },
  field: {
    marginTop: 10,
  },
  uomField: {
    width: '140px',
    // marginLeft: '5px',
  },
  helperText: {
    margin: 0,
  },
})

export class CreateCollectionLoadMTAs extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      selectedMTAs: [],
      errors: [],
    }
  }

  componentWillMount () {
    this.setState({ selectedMTAs: this.props.step2FormData })
  }

    handleSelectChange = (id, value, uomOption) => {
      const { mtaList } = this.props
      const selectedMTAs = this.state.selectedMTAs
      const curIndex = _.findIndex(selectedMTAs, (n) => { return n.id === id })
      const curMTAList = _.find(mtaList, (n) => { return n.id === id })
      if (curIndex !== -1) { // check already present or not
        selectedMTAs.map((option, key) => {
          if (option.id === id) {
            if (value === '') {
              _.remove(selectedMTAs, function (n) { return n.id === id }) // remove from array when no value slected
            } else {
              if (uomOption) {
                selectedMTAs[key].attribute_uom_value = value // update the new uom value
              } else {
                const tempArr = []
                if (curMTAList.multi_valued_flag) {
                  value.map((opt) => {
                    let selectedAttrLov = ''
                    const attrLovObj = _.find(curMTAList.uda_item_type_lov_values_inners, (n) => { return n.uda_lov_value_name === opt })
                    selectedAttrLov = {
                      id: attrLovObj.uda_lov_value_id,
                      name: opt,
                    }
                    tempArr.push(selectedAttrLov)
                  })
                  selectedMTAs[key].values = tempArr // update the new value
                } else {
                  selectedMTAs[key].values[0].name = value
                }
              }
            }
          }
        })
      } else { // new placement to the array
        let selectedAttr = ''
        if (uomOption) {
          selectedAttr = {
            id: id,
            values: [],
            attribute_uom_value: value,
          }
        } else {
          const curValue = curMTAList.multi_valued_flag ? value[0] : value
          const attrLovObj = _.find(curMTAList.uda_item_type_lov_values_inners, (n) => { return n.uda_lov_value_name === curValue })
          const lovID = (attrLovObj) ? attrLovObj.uda_lov_value_id : ''
          selectedAttr = {
            id: id,
            values: [{
              id: lovID,
              name: curValue,
            }],
            attribute_uom_value: '',
          }
        }
        selectedMTAs.push(selectedAttr)
      }
      this.setState({ selectedMTAs })
      this.props.handleSelectChange(selectedMTAs)
    }

    handleTextChange = (id) => evt => {
      this.handleSelectChange(id, evt.target.value)
    }

    render () {
      const { classes, mtaList, RequiredMTAs } = this.props
      const { selectedMTAs, errors } = this.state
      return (
        <div>
          {mtaList.map((option, key) => {
            const curObj = _.find(selectedMTAs, (n) => { return n.id === option.id })
            let curValue = ''
            if (curObj) {
              if (option.multi_valued_flag) {
                let temArr = []
                curObj.values.map((opt) => {
                  temArr.push(opt.name)
                })
                curValue = temArr
              } else {
                curValue = curObj.values[0].name
              }
            }
            let curUOMValue = (curObj) ? curObj.attribute_uom_value : ''
            let uomMulti = false
            // Check error
            const curErrorObj = _.find(RequiredMTAs, (n) => { return n === option.id })
            if (option.attribute_value_type === 'LIST') {
              return (
                <Grid item xs={12} className={classes.field} key={key}>
                  <IntegrationReactSelect
                    currentValue={curValue}
                    column_id={option.id}
                    options={getCollectionMTAOptions(option.uda_item_type_lov_values_inners)}
                    isMultiOption={option.multi_valued_flag}
                    handleSelectChange={this.handleSelectChange}
                    labeledMsg={option.name}
                  />
                  {(curErrorObj) && <FormHelperText error className={classes.helperText}>please select {option.name}</FormHelperText>}
                </Grid>
              )
            } else {
              const textType = (option.attribute_value_type === 'TEXT' || option.attribute_value_type === 'NMTX') ? 'text' : 'number'
              const gridXsOpt = option.uda_has_uom ? 6 : 12
              let dispErrMsg = ''
              if (curValue === '' && curErrorObj) {
                dispErrMsg = 'please enter ' + option.name
              } else if (option.uda_has_uom && curErrorObj && curUOMValue === '') {
                dispErrMsg = 'please select UOM'
              }
              return (
                <Grid item xs={12} className={classes.field} key={key}>
                  <Grid container>
                    <Grid item xs={gridXsOpt} className={classes.field} key={key}>
                      <FormControl className={classes.formControl} aria-describedby="name-helper-text">
                        <InputLabel htmlFor="name-helper" required>{option.name}</InputLabel>
                        <Input id="name-helper" type={textType} value={curValue} onChange={this.handleTextChange(option.id)} required />
                        <FormHelperText error className={classes.helperText}>{errors.requiredMTAs}</FormHelperText>
                      </FormControl>
                    </Grid>
                    {option.uda_has_uom &&
                    <Grid item xs={gridXsOpt} className={classes.uomField} key={key}>
                      <IntegrationReactSelect
                        currentValue={curUOMValue}
                        column_id={option.id}
                        options={getCollectionMTAUOMOptions(option.uda_uom_relations_inners)}
                        isMultiOption={uomMulti}
                        handleSelectChange={this.handleSelectChange}
                        labeledMsg="UOM"
                      />
                    </Grid>
                    }
                    {(dispErrMsg) && <FormHelperText error className={classes.helperText}>{dispErrMsg}</FormHelperText>}
                  </Grid>
                </Grid>
              )
            }
          })
          }
        </div>
      )
    }
}

CreateCollectionLoadMTAs.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(CreateCollectionLoadMTAs)
