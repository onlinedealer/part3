#!/bin/bash

set -eu

if [[ $# -ne 1 ]]; then
    echo >&2 "[ERROR] Expected 1 argument (env: dev, qa, stg, prd) but received $#."
    exit 1
fi

env=$1

case "$env" in
    dev|qa|stg|prd)
        echo "[INFO] Environment: $env"
        ;;
    *)
        echo >&2 "[ERROR] Invalid environment specified: $env"
        exit 1
        ;;
esac

browser_list=(chrome edge chrome1 edge1)
tests_count_total=0
tests_passed_total=0
tests_failed_total=0
tests_duration_max=0

run_pipeline_history_ui()
{
    env=$1
    browser=$2

    report_path="$CI_PROJECT_DIR/e2e-pw/dob_ui_test/ui-testing/playwright/test-output/${browser}/test-report.xml"
    report_type="UI"

    java -jar Pipeline_history_UI_pw1.jar ${report_type} ${report_path} ${env}
}

for browser in ${browser_list[@]}; do
    report_values=$(run_pipeline_history_ui ${env} ${browser})
      echo ${browser}
	  echo $report_values
    tests_count=$(echo "${report_values}" | cut -d, -f1)
    tests_passed=$(echo "${report_values}" | cut -d, -f2)
    tests_failed=$(echo "${report_values}" | cut -d, -f3)
    tests_duration=$(echo "${report_values}" | cut -d, -f5)

    tests_count_total=$((tests_count_total+tests_count))
    tests_passed_total=$((tests_passed_total+tests_passed))
    tests_failed_total=$((tests_failed_total+tests_failed))

    if [[ ${tests_duration} -gt ${tests_duration_max} ]]; then
        tests_duration_max=${tests_duration}
    fi
done

tests_report_date=$(date "+%Y/%m/%d %T")

echo "Date: ${tests_report_date}"
echo "Total: ${tests_count_total}"
echo "Passed: ${tests_passed_total}"
echo "Failed: ${tests_failed_total}"
echo "Duration: ${tests_duration_max}"

java -jar pipeline_history_ui_data.jar \
    "${tests_report_date}" \
    "${tests_count_total}" \
    "${tests_passed_total}" \
    "${tests_failed_total}" \
    "${tests_duration_max}" \
    "${env}" \
    "All"
