(function () {
    'use strict';

    angular.module('arm').factory('homeService', ['serviceApi','$filter', 'SERVICE_TYPE', 'sqliteService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', '$rootScope', 'contactService', 'dealService', 'activityService','$timeout', homeService]);

    function homeService(serviceApi, $filter, SERVICE_TYPE, sqliteService, utility, MASTER_TABLE, GENERAL_CONFIG, $rootScope, contactService, dealService, activityService, $timeout) {

        var serArr = {};
        var date = $filter('date')(new Date(), 'yyyy-MM-dd');

        serArr.getHomeData = function () {
            //console.log("calling homeCTRL");

            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };


            var url = SERVICE_TYPE.DASHBOARDGRAPH + '/01/' + date;
            //console.log(dashboardGraphURL)
            return serviceApi.doGetWithoutData("getHomeDataService",
                url, headerconfig).then(function (response) {
                    return response;
                }, function (err) {
                    alert('web service error' + err);
                });
        }

        serArr.sqlGetDealData = function () {
            var dealQuery = "SELECT  * FROM (SELECT ROWID,* FROM (SELECT * from Deals WHERE date(ExpectedDealCloseDate) = date('" + date + "') AND (CampaignReferenceID = 0 OR CampaignReferenceID IS NULL) AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                            " UNION SELECT  * FROM(SELECT ROWID,* from Deals WHERE date(ExpectedDealCloseDate) > date('" + date + "') AND (CampaignReferenceID = 0 OR CampaignReferenceID IS NULL) AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                            " UNION SELECT  * FROM(SELECT ROWID,* from Deals WHERE date(ExpectedDealCloseDate) < date('" + date + "') AND (CampaignReferenceID = 0 OR CampaignReferenceID IS NULL) AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                             ") ORDER BY ROWID ASC LIMIT 5";

            return sqliteService.query(dealQuery).then(function (result) {
                return result;
            });
        }

        serArr.sqlGetContactData = function () {
            var conQuery = "SELECT  * FROM (SELECT * FROM (SELECT ROWID,* from Contacts WHERE ContactTypeID= 1 AND date(NextContactedDate) = date('" + date + "') AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                            " UNION SELECT  * FROM(SELECT ROWID,* from Contacts WHERE ContactTypeID= 1 AND date(NextContactedDate) > date('" + date + "') AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                            " UNION SELECT  * FROM(SELECT ROWID,* from Contacts WHERE ContactTypeID= 1 AND date(NextContactedDate) < date('" + date + "') AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                             ") ORDER BY ROWID ASC LIMIT 5";

            return sqliteService.query(conQuery).then(function (result) {
                return result;
            });
        }

        serArr.sqlGetActData = function () {
            var queryBindingsArr = [];
            var actQuery = "SELECT  * FROM (SELECT ROWID,* FROM (SELECT * from Activity WHERE ActivityStageID =1 AND date(ActivityDate) = date('" + date + "') AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                           " UNION SELECT  * FROM(SELECT ROWID,* from Activity WHERE ActivityStageID =1 AND date(ActivityDate) > date('" + date + "') AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                           " UNION SELECT  * FROM(SELECT ROWID,* from Activity WHERE ActivityStageID =1 AND date(ActivityDate) < date('" + date + "') AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                            ") ORDER BY ROWID ASC LIMIT 5";

            return sqliteService.query(actQuery).then(function (result) {
                return result;
            });

        }

        serArr.sqlGetCampData = function () {
            var dealQuery = "SELECT  * FROM (SELECT * FROM (SELECT ROWID,* from Deals WHERE date(ExpectedDealCloseDate) = date('" + date + "') AND (CampaignReferenceID != 0 AND CampaignReferenceID IS NOT NULL) AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                            " UNION SELECT  * FROM(SELECT ROWID,* from Deals WHERE date(ExpectedDealCloseDate) > date('" + date + "') AND (CampaignReferenceID != 0 AND CampaignReferenceID IS NOT NULL) AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                            " UNION SELECT  * FROM(SELECT ROWID,* from Deals WHERE date(ExpectedDealCloseDate) < date('" + date + "') AND (CampaignReferenceID != 0 AND CampaignReferenceID IS NOT NULL) AND LoggedInUserID=" + $rootScope.loggedInUserID + " LIMIT 5)" +
                             ") ORDER BY ROWID ASC LIMIT 5";

            return sqliteService.query(dealQuery).then(function (result) {
                return result;
            });
        }

        serArr.synchData = function () {
            $rootScope.languageID = 1;
            var url = SERVICE_TYPE.HOMELIST + $rootScope.loggedInUserID + '/' + $rootScope.languageID;
            serviceApi.headerConfg['WebServiceType'] = GENERAL_CONFIG.WebServiceType.HomeList;
            return serviceApi.doGetWithoutData("LOADHOMELIST",
                    url, serviceApi.headerConfg).then(function (response) {
                        return response;
                    });
        }

        serArr.IndividualContactList =[];
        serArr.dealList = [];
        serArr.actList = [];
        serArr.campList = [];
        serArr.syncServerRecords = function () {
            serArr.IndividualContactList = [];
            serArr.dealList = [];
            serArr.actList = [];
            serArr.campList = [];

            var allDeviceObjIdsByLoginUserID = []; var allActDevicesByLoginUserID = []; var allDealDevicesByLoginUserID = [];
            serArr.synchData().then(function (response) {
                var r = response;
                utility.busyCursorStart();

                var dealResponse = [];
                var campaignResponse = [];

                for(var i=0;i<response.Deals.length;i++){
                    if(response.Deals[i].CampaignReferenceID != 0 && response.Deals[i].CampaignReferenceID != 'null' && response.Deals[i].CampaignReferenceID != null){
                        campaignResponse.push(response.Deals[i]);
                    }else{
                        dealResponse.push(response.Deals[i]);
                    }
                }



                //syncContacts(response.Contacts);
                contactService.sqlGetAllDeviceObjIds().then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        allDeviceObjIdsByLoginUserID.push(result.rows.item(i));
                    }
                    contactService.syncServerContactFromOtherModule(response.Contacts, allDeviceObjIdsByLoginUserID);
                    if (serArr.IndividualContactList.length == 0) {
                        serArr.loadContacts(serArr.IndividualContactList);
                    }
                });

                // Update and insert into local device DB for Deal section
                // syncDealServerRecords(response);
                dealService.sqlGetAllDealDeviceObjIds().then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        allDealDevicesByLoginUserID.push(result.rows.item(i));
                    }
                    var obj = new Object();
                    obj.OverDue = 0;
                    dealService.syncDealServerRecords(dealResponse, serArr.dealList, obj, allDealDevicesByLoginUserID);
                    dealService.syncDealServerRecords(campaignResponse, serArr.campList, obj, allDealDevicesByLoginUserID);
                    if (serArr.dealList.length == 0 && serArr.campList.length == 0) {
                        serArr.loadDeals(serArr.dealList);
                        serArr.loadCamps(serArr.campList);
                    }

                });

                activityService.sqlGetAllActDeviceObjIds().then(function (result) {
                    for (var i = 0; i < result.rows.length; i++) {
                        allActDevicesByLoginUserID.push(result.rows.item(i));
                    }
                    var obj = new Object();
                    obj.OverDue = 0;
                    activityService.syncServerRecords(response.Activities, serArr.actList, obj, allActDevicesByLoginUserID);
                    if (serArr.actList.length == 0) {
                        serArr.loadActivities(serArr.actList);
                    }
                });


                $timeout(function () {
                    utility.busyCursorEnd();
                }, 4000);
            });
        }

        serArr.loadContacts = function (IndividualContactList) {
            serArr.sqlGetContactData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var individualObjList = contactService.models().contactModel;
                    individualObjList = utility.syncModelWithCollection(result.rows.item(i), individualObjList);
                    individualObjList.Priority = utility.getColorCodeForContact(individualObjList.NextContactedDate);
                    IndividualContactList.push(individualObjList);
                }
                ////console.log($scope.IndividualContactList);
            });
        }

        serArr.loadActivities = function (actList) {
            serArr.sqlGetActData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var srcObj = result.rows.item(i);
                    actList.push(activityService.activityMod().uiObject);
                    actList[i] = utility.syncModelWithCollection(srcObj, actList[i]);
                    actList[i].Priority = utility.getColorCode(result.rows.item(i)['ActivityDate'], result.rows.item(i)['ActivityTime'], result.rows.item(i)['ActivityStageID']);
                    actList[i].Notes = [];

                    loadNote(result.rows.item(i)['DeviceObjID'], actList[i].Notes);
                }
            },
            function (err) {
                //$scope.errorMessage = err;
            });
        }

        function loadNote(actId, objNote) {
            activityService.sqlGetNote(actId).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    objNote.Description = result.rows.item(i)['Description'];
                }
            });
        }

        serArr.loadDeals = function (dealList) {
            serArr.sqlGetDealData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var srcObj = result.rows.item(i);
                    dealList.push(dealService.dealMod().uiObject);
                    var dealStageModelID = utility.dealStageModelIDCheck(result.rows.item(i)['DealStageID']);
                    dealList[i].Priority = utility.getColorCodeForDeals(result.rows.item(i)['ExpectedDealCloseDate'], dealStageModelID);
                    dealList[i] = utility.syncModelWithCollection(srcObj, dealList[i]);

                    dealList[i].ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate(dealList[i].ExpectedDealCloseDate).toString();
                    dealList[i].OwnerNameToDisplay = utility.getNameByOrOwner(dealList[i]);
                }
            },
            function (err) {
                //$scope.errorMessage = err;
            });
        }

        serArr.loadCamps = function (campList) {
            serArr.sqlGetCampData().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var srcObj = result.rows.item(i);
                    campList.push(dealService.dealMod().uiObject);
                    var campaignStageModelID = utility.dealStageModelIDCheck(result.rows.item(i)['DealStageID']);
                    campList[i].Priority = utility.getColorCodeForDeals(result.rows.item(i)['ExpectedDealCloseDate'], campaignStageModelID);
                    campList[i] = utility.syncModelWithCollection(srcObj, campList[i]);

                    campList[i].ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate(campList[i].ExpectedDealCloseDate).toString();
                    campList[i].OwnerNameToDisplay = utility.getNameByOrOwner(campList[i]);
                }
            },
            function (err) {
                //$scope.errorMessage = err;
            });
        }

        return serArr;
    }

})();
