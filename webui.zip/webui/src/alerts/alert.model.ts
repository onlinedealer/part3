import { AlertMetricModel } from './alert-metric.model';

export class AlertModel {
  id: string;
  alertType: string;
  alertLevel: string;
  summary: string;
  assetName: number;
  assetNameClipped!: string;
  assetType: string;
  assetParentName: string;
  assetParentType: string;
  raisedAt: Date;
  confidence: number;
  assetUid: string;
  tableName: string;
  schema: string;
  source: string;
  sourceType: string;
  observer: string;
  alertConfiguration: string;
  columnType?: string;
  profileStartTime: Date;
  thresholdAlertMetrics: AlertMetricModel[];
  confidenceAlertMetrics: AlertMetricModel[];
  assetPopularityCount?: number;
  isAuthorizedForPopularity?: boolean;
}
