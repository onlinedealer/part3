import { AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ControlContainer, Form, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../shared/connection';
import { BaseConnectionForm } from '../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../base-connection-form/base-connection-form.component';
import { Server } from '../../../../servers/shared/server';
import { ConnectionFormValidators } from '../shared/connection-form-validators';
import { ConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component';

/**
 * connection parameters for the db2 connection
 */
export enum DB2_UDB_CONNECTION_PARAMETERS {
  DB2_UDB_PORT_NO = 'DB2_PORT_NUMBER'
}
/**
 * The db2 connection form
 */
@Component({
  selector: 'p-connect-db2-form',
  templateUrl: './db2-form.component.html'
})
export class Db2FormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy, AfterViewInit, BaseConnectionForm {
  /**
   * Selected Runtime Server
   */
  @Input() selectedRuntimeServer: Server;

  /**
   * Reference to the credentials child component
   */
  @ViewChild(ConnectionCredentialsFormComponent) credentialsComponent: ConnectionCredentialsFormComponent;

  /**
   * form group
   */
  db2ConnectionForm: FormGroup;

  constructor(private readonly controlContainer: ControlContainer, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }

  ngOnDestroy(): void {
    this.removeChildFormControls(this.db2ConnectionForm);
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.createForm();
  }

  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): Connection {
    const connection = this.credentialsComponent.getConnection(isTesting); // only populates the user & password properties
    connection.database = this.db2ConnectionForm.get('database').value;
    connection.port = this.db2ConnectionForm.get('databasePort').value;
    connection.parameters = [
      {
        key: DB2_UDB_CONNECTION_PARAMETERS.DB2_UDB_PORT_NO,
        value: this.db2ConnectionForm.get('databasePort').value
      }
    ];
    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   */
  set connection(connection: Connection) {
    this.db2ConnectionForm.patchValue({
      database: connection.database
    });

    this.credentialsComponent.connection = connection;
  }

  createForm(): void {
    this.db2ConnectionForm = this.controlContainer.control as FormGroup;
    this.db2ConnectionForm.addControl(
      'database',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.db2ConnectionForm.addControl(
      'databasePort',
      new FormControl('50000', [Validators.required, Validators.min(1024), Validators.max(65535), Validators.pattern('^[0-9]*$')])
    );

    this.db2ConnectionForm.addControl('dbmsVersion', new FormControl('-'));
    this.db2ConnectionForm.addControl('driverVersion', new FormControl('-'));
    this.db2ConnectionForm.addControl('gmtOffset', new FormControl('-'));
  }
}
