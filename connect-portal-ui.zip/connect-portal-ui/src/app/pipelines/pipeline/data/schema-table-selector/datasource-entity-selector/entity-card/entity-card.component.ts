/**
 * Entity card common component
 * Can be used to show -
 *    - card with header text
 *    - show table depending upon the inputs
 *    - show filters for the table
 *    - emit various events on table row selection or checkbox click
 * Examples ---
 *    `<p-connect-entity-card showFilter=true headerText="my header">
 *      </p-connect-entity-card>`
 */

import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { SchemaModel } from '../../schema-table-selector';
import { EntityDataModel } from './entity-data-model';
import { DropdownOptionsModel } from '../dropdown-options.model';
import { FilterService } from 'primeng/api';
import { BaseComponent } from 'src/app/core/base.component';
import { ErrorMessagesService } from '@precisely/prism-ng/cloud';

@Component({
  selector: 'p-connect-entity-card',
  templateUrl: './entity-card.component.html',
  styleUrls: ['./entity-card.component.scss']
})
export class EntityCardComponent extends BaseComponent implements OnInit {
  /**
   * the component id
   */
  @Input() id: string;

  /**
   * Header text for the card
   */
  @Input() headerText: string;

  /**
   * Filter flag
   * Defaults to true
   */
  @Input() showFilter = true;

  /**
   * Placeholder text for the filter input
   */
  @Input() filterPlaceHolder: string;

  /**
   * Flag to allow row to be selected
   * Defaults to true which makes selection as multiple
   * when false, the selection is single
   */
  @Input() allowSelection = true;

  /**
   * Collect Data to be shown into the card
   */
  @Input() cardDataModel: EntityDataModel;

  /**
   * data to be displayed as a table
   */
  @Input() apiData = [];

  /**
   * Flag to show loader
   */
  @Input() isLoading = false;

  /**
   * Filter fields
   */
  @Input() filterFields: string[];

  /**
   * Selected data from the table (through checkbox/tri-state checkbox)
   */
  @Input() selectedData: any[];

  /**
   * Empty table message
   */
  @Input() emptyMessage = 'Data not available';

  /**
   * Filter's no results found message
   */
  @Input() noResultsFoundMessage = 'No results were found using the current filter.';

  /**
   * Error message
   */
  @Input() errorMessage = '';

  @Input() dropdownModel: DropdownOptionsModel;

  /**
   * Row selection event emitter
   */
  @Output() rowSelected = new EventEmitter<any>();

  /**
   * Checkbox data selection event emitter
   */
  @Output() dataSelected = new EventEmitter<any>();

  /**
   * Checkbox data unselected event emitter
   */
  @Output() dataUnselected = new EventEmitter<any>();

  /**
   * Header checkbox toggle selection event
   */
  @Output() selectAllRows = new EventEmitter<any>();

  @ViewChild('dataTable')
  dataTable: any;

  /**
   * Message to be displayed when there are no records found
   * When filtering it's set to noResultsFoundMessage, otherwise it's set to emptyMessage
   */
  noRecordsFoundMessage: string;

  /**
   * Currently highlighted row
   */
  highlightedRow: SchemaModel;

  filteredItems: any[] = [];

  /**
   * @returns sort field name for single sort mode
   */
  get sortField(): string {
    return this.cardDataModel.sortMetaList && this.cardDataModel.sortMetaList.length > 0
      ? this.cardDataModel.sortMetaList[0].field
      : undefined;
  }

  /**
   * @returns sort order for single sort mode
   */
  get sortOrder(): number {
    return this.cardDataModel.sortMetaList && this.cardDataModel.sortMetaList.length > 0
      ? this.cardDataModel.sortMetaList[0].order
      : undefined;
  }

  /**
   * @returns sort model depending on sort meta list size
   */
  get sortMode(): string {
    return this.cardDataModel.sortMetaList && this.cardDataModel.sortMetaList.length > 1 ? 'multiple' : 'single';
  }

  get columnFields() {
    return this.cardDataModel.headers.filter((column) => !column.isHidden);
  }

  constructor(private readonly filterService: FilterService, public readonly errorMessagesService: ErrorMessagesService) {
    super();
  }

  /**
   * Initialize default table message
   */
  ngOnInit() {
    this.noRecordsFoundMessage = this.emptyMessage;

    if (this.dropdownModel && this.dropdownModel?.customFilter) {
      this.filterService.register(this.dropdownModel.customFilter.name, (value, filter): boolean =>
        this.dropdownModel.customFilter.filter(value, filter)
      );
    }
  }

  /**
   * Depending upon the event type, allowSelection and showCheckbox parameters,
   * trigger CheckBox selection or RowSelection methods
   */
  rowSelection($event: any, rowData?: any) {
    // when we don't want to make any selection on table row
    if (!this.allowSelection && !this.cardDataModel.showCheckBox) {
      this.stopPropagation($event);
      return;
    }
    if ($event.type !== 'checkbox' && $event.target.classList.toString().indexOf('p-checkbox') < 0) {
      this.updateRowStyle($event, rowData);
      return;
    }
    this.checkBoxSelection($event, rowData);
  }

  /**
   * Custom way to highlight clicked row and emit the event
   * This doesn't trigger on checkbox selection
   */
  updateRowStyle(evt: any, rowData?: any) {
    if (rowData && this.highlightedRow !== rowData) {
      this.highlightedRow = rowData;
      this.rowSelected.emit(rowData);
    }
  }

  /**
   * Checkbox select event
   */
  checkBoxSelection($event: any, rowData?: any) {
    this.stopPropagation($event);
    // custom logic to update selectedData for tri-state
    if (this.cardDataModel.showTriState) {
      this.dataSelected.emit(rowData);
      return;
    }

    this.dataSelected.emit(this.selectedData);
  }

  /**
   * Checkbox un-select event
   */
  checkBoxUnselect($event: any) {
    this.stopPropagation($event);
    this.dataUnselected.emit(this.selectedData);
  }

  /**
   * Stop event propagation
   */
  stopPropagation(evt: any) {
    // there are events like on tri-state checks, we don't have original event
    // in the event, thus filling it up with the evt object itself
    if (!evt.originalEvent) {
      evt.originalEvent = evt;
    }
    evt.originalEvent.stopPropagation();
    evt.originalEvent.stopImmediatePropagation();
    evt.originalEvent.preventDefault();
  }

  /**
   * Filter data as per the input
   */
  filterData($event: string) {
    this.dataTable.filterGlobal($event, 'contains');
    if ($event) {
      // we are currently filtering, change the no records found message
      // to the filter's no results found message
      this.noRecordsFoundMessage = this.noResultsFoundMessage;
    } else {
      // we are no longer filtering, change the no records found message to emptyMessage
      this.noRecordsFoundMessage = this.emptyMessage;
    }
  }

  /**
   * Providing a hook, so that on toggle of header checkbox
   * user can do so some custom stuff
   * In the simple implementation when there is no tri-state
   * checkbox, the selection works automatically. However in case
   * of Tri-state checkbox, it doesn't. Thus a hook is provided, through
   * which a custom login can be written by the user for making row selections
   */
  selectAll($event: any) {
    $event.triState = this.cardDataModel.showTriState;
    this.selectAllRows.emit($event);
    this.dataSelected.emit(this.selectedData);
  }

  /**
   * Update the row selected value with the tri-state change
   */
  triStateChange($evt: any, rowData: any) {
    rowData.selected = $evt;
  }

  onDropdownChange($event) {
    const filterValue = $event !== this.dropdownModel?.ignoredOption ? $event : '';
    const filterColumn = Object.keys(this.dropdownModel.filter)[0];
    this.dataTable.filter(filterValue, filterColumn, this.dropdownModel.customFilter.name);
    this.dataTable.filters[filterColumn] = [{ value: filterValue, matchMode: this.dropdownModel.customFilter.name }];
  }

  filterItems(event) {
    const query = event.query.toLowerCase();
    this.filteredItems = this.dropdownModel?.options.filter((item) => item.toLowerCase().indexOf(query) === 0);
  }
}
