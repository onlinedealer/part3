export class ObserverRulesModel {
  metricName: string;
  metricDescription: string;
  selected: boolean;
}
