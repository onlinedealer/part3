import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective } from '@angular/forms';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { OrderbyascPipe } from 'src/app/shared/pipes/dynamic-dropdown-sort.pipe';
import { ConnectionTestCredentialsFormComponent } from './connection-test-credentials-form.component';
import { ServiceInjector } from '../../../../../shared/services/service.injector';

describe('ConnectionTestCredentialsFormComponent', () => {
  let component: ConnectionTestCredentialsFormComponent;
  let fixture: ComponentFixture<ConnectionTestCredentialsFormComponent>;
  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  class mockInjector {
    get() {
      return {};
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [ConnectionTestCredentialsFormComponent, OrderbyascPipe],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    ServiceInjector.injector = new mockInjector();
    fixture = TestBed.createComponent(ConnectionTestCredentialsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('returning connnection object', () => {
    it('should return connection', () => {
      expect(component.getConnection(false)).toBeInstanceOf(Object);
    });
  });
});
