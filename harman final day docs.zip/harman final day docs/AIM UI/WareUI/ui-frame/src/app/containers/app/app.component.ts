import { Component, Renderer2, AfterViewInit, OnDestroy, OnInit, Output, EventEmitter } from "@angular/core";
import { Store } from "@ngrx/store";
import { Subscription, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { State } from "../../store/reducers";

import { WindowResizeService } from "../../services/window-resize.service";
import { ChangeUiConfigurationSettingsPayload } from "../../store/actions/configurations.actions";
import { NetworkConfigurationService } from "../../../Shared/services/network-configuration.service";
import { SecuritySelectors, UserSettingsSelectors, EnvironmentIndicatorSelector } from "../../store/selectors";
import { UIActions, SecurityActions, NetworkSpecificConfigActions, UserSettingsActions } from "../../store/actions";
import { TranslationsService } from "../../services/translations-service";

@Component({
    selector: "landisgyr-app-root",
    templateUrl: "./app.component.html",
    styleUrls: ["./app.component.scss"]
})
export class AppComponent implements OnInit, AfterViewInit, OnDestroy {
    private windowResizeSubscription!: Subscription;
    userMenuOpen = false;
    network$: Observable<string>;
    permissionsLoaded$: Observable<boolean> = this.store.select(SecuritySelectors.getUAMPermissionsLoaded);
    getUserFailedMessage$: Observable<any> = this.store.select(SecuritySelectors.getSecurityFailed).pipe(
        map((errorCode) => {
            return this.setErrorMessage(errorCode);
        })
    );

    getUserSettingFailedMessage$: Observable<any> = this.store.select(UserSettingsSelectors.userSettingFailedErrorCode).pipe(
        map((errorCode) => {
            return this.setErrorMessage(errorCode);
        })
    );

    environmentIndicatorTextColor$: Observable<string> = this.store.select(
        EnvironmentIndicatorSelector.getTestProductionEnvironmentIndicatorTextColor
    );
    environmentIndicatorBackgroundColor$: Observable<string> = this.store.select(
        EnvironmentIndicatorSelector.getTestProductionEnvironmentIndicatorTextBoxColor
    );

    private _directiveClose = false;
    environmentIndicatorSub!: Subscription;
    environmentType!: string;

    constructor(
        private renderer: Renderer2,
        private store: Store<State>,
        private windowResizeService: WindowResizeService,
        private networkConfiguration: NetworkConfigurationService,
        private translations: TranslationsService
    ) {
        this.windowResizeSubscription = this.windowResizeService.onResize$.subscribe((window: Window) => {
            this.store.dispatch(
                UIActions.WindowResized({
                    windowWidth: window.innerWidth,
                    windowHeight: window.innerHeight
                })
            );
        });
        this.network$ = this.networkConfiguration.getNetworkData().pipe(map((networkData) => networkData.networkName || ""));
    }

    userMenuVisibilityChanged() {
        this.userMenuOpen = !this.userMenuOpen;
    }

    settingsUpdated(event: ChangeUiConfigurationSettingsPayload): void {
        this.store.dispatch(UserSettingsActions.SetUserProfileSetting(event));
    }

    onLogout() {
        this.store.dispatch(SecurityActions.Logout());
    }

    ngOnInit() {
        this.store.dispatch(SecurityActions.UpdateSession());
        this.store.dispatch(SecurityActions.GetUserInfo());
        this.store.dispatch(NetworkSpecificConfigActions.LoadNetworkSpecificConfiguration());
        this.environmentIndicatorSub = this.store
            .select(EnvironmentIndicatorSelector.getTestProductionEnvironmentIndicatorText)
            .subscribe((data) => {
                this.environmentType = data;
            });
    }

    ngAfterViewInit() {
        this.store.dispatch(
            UIActions.WindowInitialized({
                windowWidth: window.innerWidth,
                windowHeight: window.innerHeight
            })
        );
        const applicationLoader = this.renderer.selectRootElement("#loader");
        this.renderer.setStyle(applicationLoader, "display", "none");
    }

    ngOnDestroy() {
        if (this.windowResizeSubscription) {
            this.windowResizeSubscription.unsubscribe();
        }
        if (this.environmentIndicatorSub) {
            this.environmentIndicatorSub.unsubscribe();
        }
    }

    /**
     * Changes user menu open state from emitted value
     *
     * @param $event is menu open or not
     */
    public changeOpenValue($event: boolean) {
        if ($event !== undefined) {
            this.userMenuOpen = $event;
            this._directiveClose = false;
        } else if (!$event && this.userMenuOpen === true) {
            if (this._directiveClose) {
                this.userMenuOpen = false;
            }
            this._directiveClose = true;
        }
    }

    setErrorMessage(errorCode: string) {
        if (errorCode) {
            return this.translations.getErrorTranslation(errorCode);
        }
    }
}
