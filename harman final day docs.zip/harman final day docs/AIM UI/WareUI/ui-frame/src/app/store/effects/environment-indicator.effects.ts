import { Injectable } from "@angular/core";
import { Actions, ofType, createEffect } from "@ngrx/effects";
import { of } from "rxjs";
import { map, switchMap, catchError } from "rxjs/operators";
import { EnvironmentIndicatorService } from "../../services/environment-indicator.service";
import { EnvironmentIndicatorActions, UserSettingsActions } from "../actions";
import { EnvironmentIndicator } from "../../models/environment-indicator.model";

@Injectable()
export class EnvironmentIndicatorEffects {
    constructor(private actions$: Actions, private testProductionEnvironmentIndicatorService: EnvironmentIndicatorService) {}

    LoadEnvironmentIndicator$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.GetUserSettingsSuccess),
            switchMap(() => {
                return this.testProductionEnvironmentIndicatorService.getEnvironmentIndicator().pipe(
                    map((environmentIndicator: EnvironmentIndicator) =>
                        EnvironmentIndicatorActions.LoadEnvironmentIndicatorSuccess({
                            response: environmentIndicator
                        })
                    ),
                    catchError((error) => of(EnvironmentIndicatorActions.LoadEnvironmentIndicatorFailure({ error: error })))
                );
            })
        )
    );
}
