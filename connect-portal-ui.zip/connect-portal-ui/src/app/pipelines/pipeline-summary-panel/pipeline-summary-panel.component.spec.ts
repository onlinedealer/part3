import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { ActivatedRoute } from '@angular/router';
import { TranslocoService } from '@ngneat/transloco';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { of } from 'rxjs';
import { ServersApiService } from 'src/app/servers/shared/servers-api.service';
import { AgentsApiService } from '../../agents/shared/agents-api.service';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { ResourcePermissionService } from '../../shared/services/resource-permission.service';
import { PipelineDetailsSidebarComponent } from '../pipeline-details-sidebar/pipeline-details-sidebar.component';
import { AlertsSidebarComponent } from '../alerts-sidebar/alerts-sidebar.component';
import { LogReadersApiService } from '../pipeline/data/shared/logreaders-api.service';
import { StartPipelinesSidebarComponent } from '../start-pipelines-sidebar/start-pipelines-sidebar.component';
import { StopPipelinesSidebarComponent } from '../stop-pipelines-sidebar/stop-pipelines-sidebar.component';
import { ConnectionDetailsSidebarComponent } from './connection-details-sidebar/connection-details-sidebar.component';
import { LogReaderMessagesSidebarComponent } from './log-reader-messages-sidebar/log-reader-messages-sidebar.component';
import { LogReaderDetailsSidebarComponent } from './logreader-details-sidebar/logreader-details-sidebar.component';
import { ManageCaptureSidebarComponent } from './manage-capture-sidebar/manage-capture-sidebar.component';
import { PipelineSummaryPanelComponent } from './pipeline-summary-panel.component';
import pipelinesJson from './pipelines-example.spec.json';
import { ClearBacklogSidebarComponent } from './shared/backlog-summary-details/clear-backlog-sidebar/clear-backlog-sidebar.component';
import { StartServerSidebarComponent } from './start-server-sidebar/start-server-sidebar.component';
import { StopServerSidebarComponent } from './stop-server-sidebar/stop-server-sidebar.component';
import { TableField } from '../../shared/components/generic-table/generic-table';

describe('PipelineSummaryPanelComponent', () => {
  let component: PipelineSummaryPanelComponent;
  let fixture: ComponentFixture<PipelineSummaryPanelComponent>;
  let logReadersApiService: LogReadersApiService;
  let agentApiService: AgentsApiService;
  let serversService: ServersApiService;
  let resourcePermissionService: ResourcePermissionService;
  let translocoService: TranslocoService;
  let featureFlagService: FeatureFlagService;

  let pipelines: any;
  let mockMonitoringObject: any;

  const menuItems: any = [
    { id: 'runtime-engine-process-start', label: 'Start', disabled: false },
    { id: 'runtime-engine-process-stop', label: 'Stop', disabled: true }
  ];

  @Component({
    selector: 'p-connect-manage-capture-sidebar',
    template: '',
    providers: [
      {
        provide: ManageCaptureSidebarComponent,
        useClass: MockManageCaptureSidebarComponent
      }
    ]
  })
  class MockManageCaptureSidebarComponent {
    open(_selectedPipeline: any) {}
  }

  const mockFeatureFlagService = {
    ldClient: {
      close: () => of(),
      identify: () => of(),
      variation: () => of()
    },
    isFeatureEnabled: (f) => f === 'FLAG1',
    isFeatureDisabled: (f) => f === 'FLAG2'
  };

  beforeEach(() => {
    pipelines = Object.assign([], pipelinesJson);
    mockMonitoringObject = Object.assign({}, pipelines[0]);
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, RouterTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [
        PipelineDetailsSidebarComponent,
        StartPipelinesSidebarComponent,
        StopPipelinesSidebarComponent,
        ClearBacklogSidebarComponent,
        PipelineSummaryPanelComponent,
        LogReaderDetailsSidebarComponent,
        LogReaderMessagesSidebarComponent,
        ConnectionDetailsSidebarComponent,
        StartServerSidebarComponent,
        StopServerSidebarComponent,
        MockManageCaptureSidebarComponent
      ],
      providers: [
        HttpClientModule,
        { provide: FeatureFlagService, useValue: mockFeatureFlagService },
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: {
                get: (projectName: string) => {
                  projectName: 'MyProject';
                }
              }
            }
          }
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipelineSummaryPanelComponent);
    logReadersApiService = TestBed.inject(LogReadersApiService);
    serversService = TestBed.inject(ServersApiService);
    agentApiService = TestBed.inject(AgentsApiService);
    resourcePermissionService = TestBed.inject(ResourcePermissionService);
    translocoService = TestBed.inject(TranslocoService);
    featureFlagService = TestBed.inject(FeatureFlagService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the summary panel', () => {
    component.open(pipelines, 'pipeline1');
    expect(component.showSummary).toBe(true);
  });

  xit('should open even when a pipeline source is null', () => {
    let customPipeline = Object.assign([], pipelines);
    customPipeline[0].source = null;
    component.open(customPipeline, 'pipeline1');
    expect(component.dataConnectionList).not.toBeUndefined();
  });

  it('should format a date from the API', () => {
    expect(component.getDateFromEpoch(1639131177).getFullYear()).toBe(2021);
  });

  it('should return the version info for a given server', () => {
    component.pipelinesMonitoringStatus = mockMonitoringObject;
    expect(component.getVersionInfo('localhost').committedVersion).toBe(4);
  });

  it('should return the source data connections', () => {
    component.pipelinesMonitoringStatus = mockMonitoringObject;
    expect(component.dataConnections.length).toBe(2);
  });

  it('should show log readers sidebar', () => {
    spyOn(component.logReaderDetailsSidebarComponent, 'open').and.returnValue();
    component.logReaderMenuItems[0].command();
    expect(component.logReaderDetailsSidebarComponent.open).toHaveBeenCalled();
  });

  it('should show alerts sidebar for a runtime engine', () => {
    component.alertsSidebarComponent = { open: () => {} } as AlertsSidebarComponent;
    spyOn(component.alertsSidebarComponent, 'open');
    component.runtimeEngineMenuItems[4].command();
    expect(component.alertsSidebarComponent.open).toHaveBeenCalled();
  });

  //** intermittant failure */
  xit('should show and hide log readers based on the connection type and log reader status', () => {
    spyOn(agentApiService, 'getAll').and.returnValue(
      of([
        {
          agentName: 'metis',
          agentId: 'abc'
        }
      ])
    );

    const pipelinesCopy = [...pipelines];
    component.open(pipelinesCopy, 'pipeline1');
    expect(component.showLogReaders).toBeTruthy();
    pipelinesCopy[0].logReaderStatus = 'NONE';
    component.open(pipelinesCopy, 'pipeline1');
    expect(component.showLogReaders).toBeFalsy();
  });

  it('should get log readers for DB2I connections', () => {
    spyOn(logReadersApiService, 'getDataFlows').and.callFake((connectionId, projectId, logReaderName) => {
      if (logReaderName === 'GISLARDJ/TSTJRN') {
        return of(['pipeline1']);
      } else if (logReaderName === 'GISLARDJ/TSTJRN2') {
        return of(['pipeline2']);
      } else {
        return of([]);
      }
    });

    spyOn(agentApiService, 'getAll').and.returnValue(
      of([
        {
          agentName: 'metis',
          agentId: 'abc'
        }
      ])
    );

    component.open(pipelines, 'pipeline1');
    expect(component.showLogReaders).toBeTrue();
    pipelines[0].logReaderStatus = 'NONE';
    component.open(pipelines, 'pipeline1');
    expect(component.showLogReaders).toBeFalsy();
  });

  describe('log readers for DB2I', () => {
    const pipelineStatuses = [
      { name: 'pipeline1', captureStatus: 'DISABLED' },
      { name: 'pipeline2', captureStatus: 'ENABLED' }
    ];

    beforeEach(() => {
      spyOn(logReadersApiService, 'getDataFlows').and.callFake((_connectionId, _projectId, logReaderName) => {
        if (logReaderName === 'GISLARDJ/TSTJRN') {
          return of(['pipeline1']);
        } else if (logReaderName === 'GISLARDJ/TSTJRN2') {
          return of(['pipeline2']);
        } else {
          return of([]);
        }
      });
    });

    it('should get pipeline 1', () => {
      pipelines[0].logReaderStatus = 'OK';
      component.open(pipelines, 'pipeline1', pipelineStatuses);
      expect(component.currentLogReaders).toEqual([
        {
          journal: 'UNKNOWN',
          library: 'abc',
          name: 'GISLARDJ/TSTJRN',
          sequence: 'UNKNOWN',
          status: 'UNKNOWN',
          pipelines: [{ pipelineName: 'pipeline1', captureStatus: 'DISABLED' }],
          dataConnection: 'LTIAS08',
          dataConnectionId: '61fb761a6c39433a2997f800',
          dataConnectionType: 'DB2I'
        }
      ]);
    });

    it('should get pipeline 2', () => {
      component.open(pipelines, 'pipeline2', pipelineStatuses);
      expect(component.currentLogReaders).toEqual([
        {
          journal: 'UNKNOWN',
          library: 'abc',
          name: 'GISLARDJ/TSTJRN2',
          sequence: 'UNKNOWN',
          status: 'UNKNOWN',
          pipelines: [{ pipelineName: 'pipeline2', captureStatus: 'ENABLED' }],
          dataConnection: 'LTIAS08',
          dataConnectionId: '61fb761a6c39433a2997f800',
          dataConnectionType: 'DB2I'
        }
      ]);
    });
  });

  it('should show start runtime engine process sidebar', () => {
    spyOn(component.startRuntimeEngineProcessSidebarComponent, 'open');
    component.pipelinesMonitoringStatus = {
      runtimeServers: [{ name: 'runtime server name' }],
      projectId: '123'
    };
    component.runtimeEngineMenuItems[1].command();
    expect(component.startRuntimeEngineProcessSidebarComponent.open).toHaveBeenCalled();
  });

  it('should show stop runtime engine process sidebar', () => {
    spyOn(component.stopRuntimeEngineProcessSidebarComponent, 'open');
    component.pipelinesMonitoringStatus = {
      runtimeServers: [{ name: 'runtime server name' }],
      projectId: '123'
    };
    component.rowActionSelectedItem = component.pipelinesMonitoringStatus;
    component.runtimeEngineMenuItems[2].command();
    expect(component.stopRuntimeEngineProcessSidebarComponent.open).toHaveBeenCalled();
  });

  it('should return specific runtime server', () => {
    spyOn(serversService, 'getByName').and.returnValue(
      of({
        name: 'docker',
        port: 1,
        hostname: 'test'
      })
    );
    component.open(pipelines, 'pipeline1');
    expect(serversService.getByName).toHaveBeenCalled();
    expect(component.server.name).toBe('docker');
    expect(component.server.port).toBe(1);
    expect(component.server.hostname).toBe('test');
  });

  it('should return all agents', () => {
    spyOn(agentApiService, 'getAll').and.returnValue(
      of([
        {
          agentName: 'metis',
          agentId: 'abc'
        }
      ])
    );
    component.getAllAgents('abc');
    expect(agentApiService.getAll).toHaveBeenCalled();
    expect(component.currentAgentName).toBe('metis');
  });

  it('should return empty list of agents', () => {
    spyOn(agentApiService, 'getAll').and.returnValue(
      of([
        {
          agentName: 'metis',
          agentId: 'a'
        }
      ])
    );
    component.getAllAgents('abc');
    expect(agentApiService.getAll).toHaveBeenCalled();
    expect(component.currentAgentName).toBe('');
  });

  describe('Pipeline actions', () => {
    it('should call pipelineDetailsSidebarComponent', () => {
      spyOn(component.pipelineDetailsSidebarComponent, 'open').and.stub();
      component.pipelineTableMenuItems[0].command();
      expect(component.pipelineDetailsSidebarComponent.open).toHaveBeenCalled();
    });

    it('should call startPipelinesSidebarComponent', () => {
      spyOn(component.startPipelinesSidebarComponent, 'open').and.stub();
      component.pipelineTableMenuItems[1].command();
      expect(component.startPipelinesSidebarComponent.open).toHaveBeenCalled();
    });

    // it('should call stopPipelinesSidebarComponent', () => {
    //     spyOn(component.stopPipelinesSidebarComponent, 'open').and.stub();
    //     component.pipelineTableMenuItems[2].command();
    //     expect(component.stopPipelinesSidebarComponent.open).toHaveBeenCalled();
    // });

    it('should call clearBacklogSidebarComponent', () => {
      spyOn(component.clearBacklogSidebarComponent, 'open').and.stub();
      component.pipelineTableMenuItems[4].command();
      expect(component.clearBacklogSidebarComponent.open).toHaveBeenCalled();
    });

    it('should call edit', () => {
      spyOn(component, 'navigateTo').and.stub();
      component.pipelinesMonitoringStatus = mockMonitoringObject;
      component.pipelinesMonitoringStatus.id = '61fb761a6c39433a2997f8aa';
      component.pipelineTableMenuItems[6].command();
      expect(component.navigateTo).toHaveBeenCalled();
    });

    it('should set deleteSidebarConfiguration visible state', () => {
      component.deleteSidebarConfiguration = {
        bodyText: '',
        sidebarTitle: '',
        isSidebarVisible: false,
        deleteButtonText: '',
        deleteFailedText: '',
        targetItemsTableData: [{}],
        targetItemsFieldList: [
          {
            header: 'test',
            name: 'test',
            isInDeleteModal: true
          } as TableField
        ],
        deleteCompletedEvent: of({ deletedFailed: [], deletedSuccess: [] }),
        deleteButtonClicked: () => {}
      };
      component.pipelinesMonitoringStatus = mockMonitoringObject;
      component.pipelineTableMenuItems[7].command();
      expect(component.deleteSidebarConfiguration.isSidebarVisible).toBeTrue();
    });

    it('should emit event when delete action is clicked to update content of delete pipeline sidebar', () => {
      component.pipelinesMonitoringStatus = mockMonitoringObject;
      component.deleteSidebarConfiguration = {
        bodyText: '',
        sidebarTitle: '',
        isSidebarVisible: false,
        deleteButtonText: '',
        deleteFailedText: '',
        targetItemsTableData: [{}],
        targetItemsFieldList: [
          {
            header: 'test',
            name: 'test',
            isInDeleteModal: true
          } as TableField
        ],
        deleteCompletedEvent: of({ deletedFailed: [], deletedSuccess: [] }),
        deleteButtonClicked: () => {}
      };
      spyOn(component.selectedPipelineRowItemEvent, 'emit');
      component.pipelineTableMenuItems[7].command();
      expect(component.selectedPipelineRowItemEvent.emit).toHaveBeenCalled();
    });
  });

  it('should show data connection details sidebar', () => {
    spyOn(component.connectionDetailsSidebarComponent, 'open').and.returnValue();
    component.pipelinesMonitoringStatus = mockMonitoringObject;
    component.rowActionSelectedItem = { name: 'LTIAS08' };
    component.connectionTableMenuItems[0].command();
    expect(component.connectionDetailsSidebarComponent.open).toHaveBeenCalled();
  });

  it('should hide runtime engine menu if the user is not signed in as operator', () => {
    spyOn(resourcePermissionService, 'hasResourcePermission').and.returnValue(false);
    component.getMenuItems(menuItems);
    expect(menuItems[0].visible).toEqual(false);
    expect(menuItems[1].visible).toEqual(false);
  });

  it('should hide logreader menu if the user is not signed in as operator', () => {
    spyOn(resourcePermissionService, 'hasResourcePermission').and.returnValue(false);
    component.getMenuItems(component.logReaderMenuItems);
    expect(component.logReaderMenuItems.find((menu) => menu.id === 'details').visible).toEqual(true);
    expect(component.logReaderMenuItems.find((menu) => menu.id === 'start').visible).toEqual(false);
    expect(component.logReaderMenuItems.find((menu) => menu.id === 'stop').visible).toEqual(false);
    expect(component.logReaderMenuItems.find((menu) => menu.id === 'log').visible).toEqual(false);
  });

  it('should toggle disabling start/stop menu action buttons based on runtime engine status', () => {
    component.rowActionSelectedItem = { name: 'docker', status: 'OK' };
    component.getMenuItems(menuItems);
    expect(menuItems[0].disabled).toEqual(true);
    expect(menuItems[1].disabled).toEqual(false);
  });

  it('should emit event to open the alerts modal', () => {
    spyOn(component.alertsButtonClickEvent, 'emit');
    component.alertsButtonClicked();
    expect(component.alertsButtonClickEvent.emit).toHaveBeenCalled();
  });

  it('should show log reader messages sidebar', () => {
    spyOn(component.logReaderMessagesSidebarComponent, 'open').and.returnValue();
    component.pipelinesMonitoringStatus = mockMonitoringObject;
    component.rowActionSelectedItem = { name: 'log1' };
    component.logReaderMenuItems[4].command();
    expect(component.logReaderMessagesSidebarComponent.open).toHaveBeenCalled();
  });

  it('should open manage capture component', () => {
    spyOn(component.manageCaptureSidebarComponent, 'open').and.returnValue();
    component.pipelinesMonitoringStatus = mockMonitoringObject;
    component.connectionTableMenuItems[1].command();
    expect(component.manageCaptureSidebarComponent.open).toHaveBeenCalled();
  });

  describe('Menu Items disable', () => {
    it('should disable pipeline stop/start actions', () => {
      const menuItems = [
        { disabled: false, id: 'startPipelineMenuItem', visible: true },
        { disabled: false, id: 'stopPipelineMenuItem', visible: true }
      ];
      component.pipelinesMonitoringStatus = mockMonitoringObject;

      component.pipelinesMonitoringStatus.overallStatus = 'STOPPED';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      expect(menuItems[1].disabled).toBe(true);

      component.pipelinesMonitoringStatus.overallStatus = 'COMPLETED';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      expect(menuItems[1].disabled).toBe(true);

      component.pipelinesMonitoringStatus.overallStatus = 'ACTION_REQUIRED';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      expect(menuItems[1].disabled).toBe(true);

      component.pipelinesMonitoringStatus.overallStatus = 'NONE_OF_THE_ABOVE';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(true);
      expect(menuItems[1].disabled).toBe(false);
    });

    it('should disable pipeline delete/edit actions', () => {
      const menuItems = [
        { disabled: false, id: 'deleteMenuItem', visible: true },
        { disabled: false, id: 'editMenuItem', visible: true }
      ];
      component.pipelinesMonitoringStatus = mockMonitoringObject;
      component.projectId = 'test';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      expect(menuItems[1].disabled).toBe(false);

      component.projectId = '';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(true);
      expect(menuItems[1].disabled).toBe(true);
    });

    it('should disable the manage capture menu item', () => {
      const menuItems = [{ disabled: false, id: 'manageCapture', visible: true }];
      component.pipelinesMonitoringStatus = mockMonitoringObject;
      component.pipelinesMonitoringStatus.dataFlowType = 'COPY';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(true);
      menuItems[0].disabled = false;
      component.pipelinesMonitoringStatus.overallStatus = undefined;
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(true);
      menuItems[0].disabled = false;
      component.pipelinesMonitoringStatus.overallStatus = 'IN_PROGRESS';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(true);
    });

    it('should disable the manage capture menu item', () => {
      const menuItems = [{ disabled: true, id: 'manageCapture', visible: true }];
      component.pipelinesMonitoringStatus = mockMonitoringObject;
      component.pipelinesMonitoringStatus.dataFlowType = 'SYNCHRONIZE';
      component.pipelinesMonitoringStatus.overallStatus = 'STOPPED';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      menuItems[0].disabled = true;
      component.pipelinesMonitoringStatus.dataFlowType = 'REPLICATE';
      component.pipelinesMonitoringStatus.overallStatus = 'COMPLETED';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      menuItems[0].disabled = true;
      component.pipelinesMonitoringStatus.overallStatus = 'OK';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      menuItems[0].disabled = true;
      component.pipelinesMonitoringStatus.overallStatus = 'ACTION_REQUIRED';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
      menuItems[0].disabled = true;
      component.pipelinesMonitoringStatus.overallStatus = 'ATTENTION';
      component.getMenuItems(menuItems);
      expect(menuItems[0].disabled).toBe(false);
    });
  });

  it('should close the new pipeline summary panel', () => {
    spyOn(component, 'navigateTo').and.stub();
    component.closePipelineSummaryPanel();
    expect(component.navigateTo).toHaveBeenCalled();
  });

  it('should check if pipeline has monitoring status values', () => {
    component.pipelinesMonitoringStatus = false;
    expect(component.hasMonitoringStatusValues()).toBe(false);
    component.pipelinesMonitoringStatus = {
      runtimeServers: [{ name: 'runtime server name' }],
      projectId: '123'
    };
    expect(component.hasMonitoringStatusValues()).toBe(false);
    component.pipelinesMonitoringStatus = {
      runtimeServers: [{ name: 'runtime server name' }],
      projectId: '123',
      replicationStatus: 'STOPPED'
    };
    expect(component.hasMonitoringStatusValues()).toBe(true);
  });

  it('should get the status icon', () => {
    let statusIcon = component.getStatusIcon('OK');
    expect(statusIcon).toBe('align-bottom png-icon-sm png-alert-open text-success');
    statusIcon = component.getStatusIcon('STOPPED');
    expect(statusIcon).toEqual('align-bottom png-icon-sm png-alert-stopped-solid text-danger');
    statusIcon = component.getStatusIcon('');
    expect(statusIcon).toBe('');
  });
});
