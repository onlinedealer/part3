import { ConfidenceBasedModel } from './confidence-based.model';
import { ThresholdBasedModel } from './threshold-based.model';

export class VolumeConfigureModel {
  configType: string;
  confidence: ConfidenceBasedModel;
  threshold: ThresholdBasedModel;
  constructor() {
    this.confidence = new ConfidenceBasedModel();
    this.threshold = new ThresholdBasedModel();
  }
}
