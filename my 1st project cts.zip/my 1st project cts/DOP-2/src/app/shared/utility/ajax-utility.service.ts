import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { UrlMakerService } from './url-maker.service';

@Injectable()
export class AjaxUtilityService {

  constructor( private _http: HttpClient, private _urlMaker: UrlMakerService) { }

  sendRequest(serviceName, payload?, optionalParams?) {
    return this._http.request(
      this._urlMaker.getServiceMethod(serviceName),
      this._urlMaker.getServiceUrl(serviceName),
      {
        body: payload,
        headers: this._urlMaker.getServiceHeaders(serviceName),
        withCredentials: true,
        params: optionalParams
      });
    }
}
