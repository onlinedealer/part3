import { PartyData } from "./partydata.model";

export interface Contract {
    id: number;
    customer: Customer;
    contractNo: string | null;
    contractType: string;
    contractTypeInUi: string;
    contractorNo?: number | null;
    customerNo: string | null;
    periodicity: Periodicity;
    validFrom: number;
    validTo?: number;
    productId?: number | null;
    meteringPointId: number;
    salesCompany?: string;
    balancingSuplies?: string;
    product?: Product;
    supplierPartyId?: number;
    supplierParty?: PartyData;
    balanceResponsiblePartyId?: number;
    balanceResponsibleParty?: PartyData;
}
interface Periodicity {
    id: number | null;
    interval: number;
    name: string;
    periodicity: string;
    startDate: number;
}

interface ProductComponentMeasuredUnit {
    measuredUnitId?: number;
}

interface MeasuredAttributeQuantity {
    measuredQuantityId?: number;
    identifier?: string;
    isInstanteneous?: number;
}

interface ProductComponentMeasuredAttribute {
    measuredAttributeId?: number;
    defaultForProfile?: boolean;
    identifier?: string;
    measuredQuantity?: MeasuredAttributeQuantity;
}

interface ProductComponent {
    id?: number;
    description?: string;
    name?: string;
    measuredUnit?: ProductComponentMeasuredUnit;
    measuredAttribute?: ProductComponentMeasuredAttribute;
}

interface Product {
    id: number | null;
    name: string | null;
    description?: string;
    productComponents?: ProductComponent[];
}

interface Customer {
    id: number | null;
    name: string | null;
    customerNo?: string;
    address: Address;
    email?: string | null;
    telephoneNumber?: string | null;
}

interface Address {
    streetName: string | null;
    streetNumber: number | null;
    streetNumberExtension?: string | null;
    apartment?: string | null;
    areaCode?: string | null;
    areaName?: string | null;
    postalCode: string | null;
    city: string | null;
    territory?: string | null;
    countryCode?: string | null;
    postOfficeBox?: string | null;
}

interface SummaryTableVO {
    readingDate: string;
    values: { value: number; time: string };
}
