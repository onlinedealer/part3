import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { firstValueFrom } from 'rxjs';
import { BaseComponent } from '../../core/base.component';
import { PipelineService } from '../../pipelines/pipeline/pipeline.service';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { ProjectsApiService } from '../../pipelines/pipeline/shared/projects-api.service';

@Component({
  selector: 'p-connect-pipelines-home',
  templateUrl: './pipelines-home.component.html'
})
export class PipelinesHomeComponent extends BaseComponent {
  constructor(
    public router: Router,
    private readonly pipelineService: PipelineService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly projectsApiService: ProjectsApiService
  ) {
    super(router);
  }

  async createPipelineClicked() {
    if (this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421')) {
      // we always need to set the project id, we cannot rely on the previous step('projects') to set it,
      // because it's not guaranteed that the user will create the project and pipeline in the same session
      const project = await firstValueFrom(this.projectsApiService.getDefaultProject());
      this.pipelineService.setProjectId(project.id);
    } else {
      // we need to create the project before we navigate to create pipeline
      await this.pipelineService.createProjectIfRequired();
    }
    this.navigateTo('pipelines/create');
  }
}
