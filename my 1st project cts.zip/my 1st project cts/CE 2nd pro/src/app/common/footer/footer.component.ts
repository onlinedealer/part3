import { Component, OnInit } from '@angular/core';
import {BrowserModule, DomSanitizer} from '@angular/platform-browser'

import { UtilityService } from '../../services/utility.service';
import { GlobalConfig } from '../../constants/constants';

@Component({
  selector: 'app-footer',
  templateUrl: './footer.component.html',
  styleUrls: ['./footer.component.scss']
})
export class FooterComponent implements OnInit {

  constructor(private utilityService:UtilityService, private sanitizer: DomSanitizer) { }

  footerContent;

  ngOnInit() {
      this.utilityService.getBccContent(GlobalConfig.BCC_FOOTER_ID).subscribe((response)=>{
        if(response && response['response']['header']['statusCode'] === '0000'){
          this.footerContent = this.sanitizer.bypassSecurityTrustHtml(atob(response['response']['details']['slotContent']));
        }
      },
      error =>{
        console.log(error);
      });
  }

}
