import { Component, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'p-connect-kafka-options',
  templateUrl: './kafka-options.component.html'
})
export class KafkaOptionsComponent implements OnInit {
  optionsForm: FormGroup;

  constructor(private readonly controlContainer: ControlContainer) {}

  ngOnInit(): void {
    this.createForm();
  }

  onBundlingChange(isBundlingEnabled: boolean) {
    if (isBundlingEnabled) {
      this.optionsForm.controls.bundlingLimit.setValidators([Validators.required]);
    } else {
      this.optionsForm.controls.bundlingLimit.clearValidators();
    }
    this.optionsForm.controls.bundlingLimit.updateValueAndValidity();
  }

  private readonly createForm = () => {
    this.optionsForm = this.controlContainer.control as FormGroup;
    this.optionsForm.addControl('enableBundling', new FormControl(false));
    this.optionsForm.addControl('bundlingLimit', new FormControl(1000));
  };
}
