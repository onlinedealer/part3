import { CommonModule } from '@angular/common';
import { EventEmitter } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslocoModule } from '@ngneat/transloco';
import { SharedModule } from 'discovery-shared';
import { SearchInputComponent } from './search-input.component';

describe('SearchInputComponent', () => {
  let component: SearchInputComponent;
  let fixture: ComponentFixture<SearchInputComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [SearchInputComponent],
      imports: [CommonModule, TranslocoModule, SharedModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SearchInputComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have default value for id', () => {
    expect(component.id).toBeDefined();
    expect(component.id).not.toBeNull();
  });

  it('should have default value for icons', () => {
    expect(component.searchIcon).toBeDefined();
    expect(component.searchIcon).not.toBeNull();
  });

  it('should have default value for placeholder text', () => {
    expect(component.filterPlaceholder).toBeDefined();
    expect(component.filterPlaceholder).not.toBeNull();
  });

  it('"filterChange" should be of Type Event ', () => {
    expect(component.filterChange).toBeInstanceOf(EventEmitter);
  });
});
