import {
  GET_MAINTENANCE_DETAILS,
  GET_ITEMS,
  SERVICE_FAIL,
  SAVE_ITEMS,
  SAVE_FAIL,
  CANCEL_UPDATE,
  UPDATE_MODE,
  TOGGLE_LOADING,
} from './actionType'
import config from '../../config/apiConfig'
import { showNotification } from './../notification/actionCreator'
import {
  getService,
  postService,
  getItemsService,
  saveItemsService,
} from './../../services/massItemMaintain'

// get Maintenance Types while loading the page
export function getMaintenanceDetails (memberOf, userId) {
  return dispatch => {
    return getService(config.massItemMaintain.getMaintenanceDetails, memberOf, userId)
      .then(resp => {
        dispatch({ data: resp, type: GET_MAINTENANCE_DETAILS })
      })
      .catch(({message, response}) => {
        let notification = 'Error Loading Item Data.'

        if (response) {
          notification += ` (${response.data.code})`
        } else {
          // No response from server: use axios error message
          notification += ` (${message})`
        }

        dispatch(showNotification(true, notification))
        dispatch({ message: response.data.message, type: SERVICE_FAIL })
      })
  }
  // return { data: {}, type: GET_MAINTENANCE_DETAILS }
}

// get Attribute meta details
export function getItems (value, memberOf, userId) {
  return dispatch => {
    return getItemsService(value, memberOf, userId)
      .then(resp => {
        dispatch({ data: resp, mode: 'jira ticket', type: GET_ITEMS })
      })
      .catch(({message, response}) => {
        let notification = 'Error Loading Item Data.'

        if (response) {
          notification += ` (${response.data.code})`
        } else {
          // No response from server: use axios error message
          notification += ` (${message})`
        }

        dispatch(showNotification(true, notification))
        dispatch({ message: response.data.message, type: SERVICE_FAIL })
      })
  }
  // return { data: {}, type: GET_ITEMS }
}

export function excelUpload (excelData, sendData, excelInfo, memberOf, userId) {
  const rowData = []
  let storeNewValue = ''
  excelData.map((rowObj, keyObj) => {
    if (keyObj > 0) {
      rowObj.map((rowObj2, key) => {
        rowData[keyObj - 1] = (rowData[keyObj - 1] !== undefined) ? rowData[keyObj - 1] : {}
        rowData[keyObj - 1]['index'] = (rowData[keyObj - 1]['index'] === undefined) ? keyObj : rowData[keyObj - 1]['index']
        if (excelInfo.template_mapping[key] === 'new_value') {
          const splittedValues = rowObj2.split('|')
          let newValueArray = []
          splittedValues.map((splitObj, keyIndex) => {
            newValueArray.push({
              'value': splitObj.trim(),
              'id': '',
              'uom': '',
            })
          })
          storeNewValue = newValueArray
        } else {
          storeNewValue = rowObj2
        }
        rowData[keyObj - 1][excelInfo.template_mapping[key]] = storeNewValue
      })
    }
  })
  sendData['item_list'] = rowData
  const submitType = excelInfo.grid_required ? GET_ITEMS : SAVE_ITEMS
  return dispatch => {
    return postService(sendData, excelInfo.service_name, memberOf, userId)
      .then(resp => {
        dispatch({ data: resp, mode: 'excel', type: submitType })
      })
      .catch(({message, response}) => {
        let notification = 'Error uploading Excel Item Data.'

        if (response) {
          notification += ` (${response.data.code})`
        } else {
          // No response from server: use axios error message
          notification += ` (${message})`
        }

        dispatch(showNotification(true, notification))
        dispatch({ message: response.data.message, type: SERVICE_FAIL })
      })
  }
}

export function getItemsFromTcins (sendData, serviceName, gridRequired, memberOf, userId) {
  return dispatch => {
    return postService(sendData, serviceName, memberOf, userId)
      .then(resp => {
        dispatch({ data: resp, mode: 'paste box', type: GET_ITEMS })
      })
      .catch(({message, response}) => {
        let notification = 'Error Loading Item Data.'

        if (response) {
          notification += ` (${response.data.code})`
        } else {
          // No response from server: use axios error message
          notification += ` (${message})`
        }

        dispatch(showNotification(true, notification))
        dispatch({ message: response.data.message, type: SERVICE_FAIL })
      })
  }
}

export function cancelUpdate () {
  return { type: CANCEL_UPDATE }
}

export function toggleLoading (status, message) {
  return { status, message, type: TOGGLE_LOADING }
}

export function changeUpdateMode (updateMode) {
  return { updateMode, type: UPDATE_MODE }
}

export function saveItems (itemList, commonFields, errorItems, memberOf, userId) {
  const sendObj = {'item_list': itemList, 'common_field': commonFields, 'errors': errorItems}
  return dispatch => {
    return saveItemsService(sendObj, memberOf, userId)
      .then(resp => {
        dispatch({ data: resp, type: SAVE_ITEMS })
      })
      .catch(({message, response}) => {
        let notification = 'Error Loading Item Data.'

        if (response) {
          notification += ` (${response.data.code})`
        } else {
          // No response from server: use axios error message
          notification += ` (${message})`
        }

        dispatch(showNotification(true, notification))
        dispatch({ message: response.data.message, type: SAVE_FAIL })
      })
  }
  // return { type: SAVE_ITEMS }
}
