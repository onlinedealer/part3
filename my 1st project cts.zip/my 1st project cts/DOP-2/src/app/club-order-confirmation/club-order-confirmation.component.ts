import { Component, OnInit } from '@angular/core';
import { ActiveModelService } from '../shared/models/active-model.service';
import { Router, NavigationEnd } from '@angular/router';
import { AjaxUtilityService } from '../shared/utility/ajax-utility.service';
import { HttpResponse, HttpParams } from '@angular/common/http';
import { OrderModel } from '../shared/models/order-model';
import { UtagService } from 'utag-module';
import { ClubConstantsService, RouteConfigurations } from '../shared/utility/club-constants.service';
import { Title, Meta } from '@angular/platform-browser';


@Component({
  selector: 'app-club-order-confirmation',
  templateUrl: './club-order-confirmation.component.html',
  styleUrls: ['./club-order-confirmation.component.scss']
})
export class ClubOrderConfirmationComponent implements OnInit {

  constructor(
    private _activeModel: ActiveModelService,
    private _router: Router,
    private _ajaxUtility: AjaxUtilityService,
    private _utag: UtagService,
    private _constants: ClubConstantsService,
    private _title: Title,
    private _meta: Meta
  ) {
    _title.setTitle(RouteConfigurations.clubOrderConfirmationTitle);
    _meta.removeTag("name='description'");    
    _meta.addTag({ name: 'description', content: RouteConfigurations.carepassOrderConfirmationDesc });    
    if (sessionStorage.getItem('clubStorageConf') && JSON.parse(sessionStorage.getItem('clubStorageConf'))['counter']) {
      sessionStorage.removeItem('clubStorageConf');
      window.location.reload(true);
    }
    _router.events.subscribe((event) => {
      if (event instanceof NavigationEnd && ('/' + RouteConfigurations.clubOrderConfirmation) !== event.urlAfterRedirects) {
        if (sessionStorage.getItem('clubStorage')) {
          sessionStorage.removeItem('clubStorage');
        }
      }
    });
   }

  orderSummary: any = {};
  date: Date = new Date();
  total: number;
  orderDetails = {};
  orderConfContent: any;

  ngOnInit() {
    document.getElementById('congratulationsBanner').focus();
    if (!sessionStorage.getItem('clubStorage') || !JSON.parse(sessionStorage.getItem('clubStorage'))['orderId']) {
      this.gotoDashboard();
    } else {
      try {
        this.getOrderDetails();
      } catch (error) {
        console.error(error);
      }
    }

    this.orderConfContent = this._constants.getOrderConfirmationContent();
  }

  getOrderDetails() {
    let orderId = '';
    try {
      orderId = JSON.parse(sessionStorage.getItem('clubStorage'))['orderId'];
    } catch (error) {
      console.error(error);
    }
    this._ajaxUtility.sendRequest('getOrder', {}, new HttpParams().set('orderId', orderId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          const orderObject = {};
          if ('0000' === response.header.statusCode) {
            if (response.hasOwnProperty('details') && response.details.hasOwnProperty('order')) {
            try {
              const utagObj = {
                'page_name': 'carepass:join cvs carepass',
                'flow': 'complete',
                'pageflag': ''
              };
              if (response.details.order.hasOwnProperty('carePassInformation') && response.details.order.carePassInformation.hasOwnProperty('carePassSubscriptionType')) {
                utagObj.pageflag = 'carepass:' + response.details.order.carePassInformation.carePassSubscriptionType.toLowerCase() + ':' + response.details.order.orderSummary.total;
              }
              setTimeout(() => {
                this._utag.view(utagObj);
              }, 2000);
            } catch (error) {}
              orderObject['shippingAddress'] = response.details.order.orderShippingInfo.shippingAddress;
              if (response.details.order.hasOwnProperty('orderBillingInfo') && response.details.order.orderBillingInfo.length > 0) {
                orderObject['orderBillingInfo'] = response.details.order.orderBillingInfo[0];
              }
              orderObject['externalId'] = response.details.order.externalId;
              orderObject['orderId'] = response.details.order.orderId;
              orderObject['orderSubmittedDate'] = response.details.order.orderSubmittedDate;
              orderObject['extracareCardNumber'] = response.details.order.extracareCardNumber;
              orderObject['orderSummary'] = response.details.order.orderSummary;
              this._activeModel.setOrder(this.orderDetails = new OrderModel(orderObject));
            }
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }

  getProfileDetails() {
    this._ajaxUtility.sendRequest('getDigitalProfile')
    .subscribe(
    (data: HttpResponse<any>) => {},
    (err) => {
      console.error(err);
    },
    () => {}
    );
  }

  gotoDashboard() {
    this._router.navigate(['/' + RouteConfigurations.clubDashboard]);
  }
}
