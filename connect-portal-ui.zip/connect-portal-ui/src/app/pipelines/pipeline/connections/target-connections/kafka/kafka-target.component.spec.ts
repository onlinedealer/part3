import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { AuthModule } from 'angular-auth-oidc-client';
import { of } from 'rxjs';
import { getTranslocoModule } from '../../../../../core/transloco-testing.module';
import { AccordionComponent } from '../../../../../shared/components/accordion/accordion.component';
import { FeatureFlagService } from '../../../../../shared/services/feature-flag.service';
import { SharedModule } from '../../../../../shared/shared.module';
import { KafkaTargetComponent } from './kafka-target.component';

describe('KafkaTargetComponent', () => {
  let component: KafkaTargetComponent;
  let fixture: ComponentFixture<KafkaTargetComponent>;
  let featureFlagService: FeatureFlagService;

  const mockFeatureFlagService = {
    ldClient: {
      close: () => of(),
      identify: () => of(),
      variation: () => of()
    },
    isFeatureEnabled: (f) => f === 'FLAG1',
    isFeatureDisabled: (f) => f === 'FLAG2'
  };
  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), SharedModule, AuthModule.forRoot({}), RouterModule.forRoot([])],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [KafkaTargetComponent, AccordionComponent],
      providers: [
        {
          provide: ControlContainer,
          useValue: fgd
        },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KafkaTargetComponent);
    component = fixture.componentInstance;
    featureFlagService = TestBed.inject(FeatureFlagService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('target connection parameters', () => {
    beforeEach(() => {
      const formGroup = component.kafkaForm.get('targetOptions') as FormGroup;
      formGroup.addControl('clientId', new FormControl('1'));
      formGroup.addControl('messageFormat', new FormControl('CSV'));
      formGroup.addControl('fieldDelimiter', new FormControl(','));
      formGroup.addControl('imagesToInclude', new FormControl('BOTH'));
      formGroup.addControl('messagePartitionBy', new FormControl('TABLE_NAME'));
      component.isFeatureEnabled = true;
    });

    it('should return target options for CSV message format', () => {
      component.kafkaForm.get('targetOptions.messageFormat').setValue('CSV');
      fixture.detectChanges();
      const param = component.targetConnectionParameters.find((parameter) => parameter.key === 'MESSAGE_FORMAT_FIELD_DELIMITER');
      expect(param.value).toBe(',');
    });

    it('should get message formats & if feature flag is false', () => {
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(false);
      component.ngOnInit();
      expect(true).toBeTrue();
    });

    it('should get message formats & if feature flag is true', () => {
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      component.ngOnInit();
      expect(true).toBeTrue();
    });

    it('should return target options for JSON message format', () => {
      component.kafkaForm.get('targetOptions.messageFormat').setValue('JSON');
      fixture.detectChanges();
      const param = component.targetConnectionParameters.find((parameter) => parameter.key === 'MESSAGE_FORMAT_FIELD_DELIMITER');
      expect(param).not.toBeDefined();
    });

    it('should not return target options when message format is not JSON or CSV', () => {
      component.kafkaForm.get('targetOptions.messageFormat').setValue('');
      fixture.detectChanges();
      const param = component.targetConnectionParameters.find((parameter) => parameter.key === 'MESSAGE_FORMAT_FIELD_DELIMITER');
      expect(param).not.toBeDefined();
    });

    it('should return target options for AVRO', () => {
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      component.kafkaForm.get('targetOptions.messageFormat').setValue('AVRO');
      fixture.detectChanges();
      let testParam = component.targetConnectionParameters.find((parameter) => parameter.key === 'SCHEMA_REGISTRY_ID');
      expect(testParam).toBeDefined();
      expect(component.kafkaForm.controls.targetOptions.get('schemaRegistries')).toBeDefined();
      testParam = component.targetConnectionParameters.find((parameter) => parameter.key === 'INCLUDE_IMAGE_OPTION');
      expect(testParam).toBeDefined();
    });

    it('should set target connection parameters', () => {
      component.kafkaForm.get('targetOptions.messageFormat').setValue('CSV');
      component.targetConnectionParameters = [
        { key: 'CLIENT_ID', value: '' },
        { key: 'MESSAGE_FORMAT', value: 'CSV' },
        { key: 'MESSAGE_FORMAT_FIELD_DELIMITER', value: ',' },
        { key: 'INCLUDE_IMAGE_OPTION', value: 'AFTER_ONLY' }
      ];
      fixture.detectChanges();
      const targetOptions = component.targetConnectionParameters;
      expect(targetOptions.find((d) => d.key === 'MESSAGE_FORMAT').value).toEqual('CSV');
    });

    it('should return row metadata', () => {
      const formGroup = component.kafkaForm.get('rowMetaData') as FormGroup;
      component.targetConnectionMetadata = [{ key: 'metadata1', value: 'INCLUDE' }];
      formGroup.addControl('rowMetaDataOptions', new FormControl(['metadata1']));
      const param = component.targetConnectionMetadata.find((parameter) => parameter.key === 'metadata1');
      expect(param.value).toBe('INCLUDE');
    });
  });

  describe('accordion state', () => {
    it('should collapse Target Options by default', () => {
      const cyId = 'kafkaTargetOptionsAccordion';
      const isHiddenState = getHiddenStateFor(cyId);
      expect(isHiddenState).toBe('true');
    });

    it('should collapse Options by default', () => {
      const cyId = 'kafkaOptionsAccordion';
      const isHiddenState = getHiddenStateFor(cyId);
      expect(isHiddenState).toBe('true');
    });

    it('should collapse Large Options by default', () => {
      const cyId = 'kafkaLargeOptionsAccordion';
      const isHiddenState = getHiddenStateFor(cyId);
      expect(isHiddenState).toBe('true');
    });
  });

  function getHiddenStateFor(cyId: string): string {
    const accordionComponent = fixture.debugElement.query(By.css(`[data-cy="${cyId}"]`));
    const isHiddenAttribute = accordionComponent.attributes['ng-reflect-is-hidden'];
    return isHiddenAttribute;
  }
});
