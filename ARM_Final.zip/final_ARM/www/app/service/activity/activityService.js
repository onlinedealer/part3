(function () {
    'use strict';

    angular.module('arm').factory('activityService',
            ['serviceApi', 'SERVICE_TYPE', 'sqliteService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', '$rootScope', '$filter', 'noteService', activityService]);

    function activityService(serviceApi, SERVICE_TYPE, sqliteService, utility, MASTER_TABLE, GENERAL_CONFIG, $rootScope, $filter, noteService) {

        var serArr = {};

        serArr.activityMod = function () {
            return {
                uiObject: {
                    DeviceObjID: utility.generateUUID(),
                    ModuleID: GENERAL_CONFIG.MODULES.Activity,
                    ActivityID: 0,
                    ContactDeviceObjID: '',
                    ContactID: 0,
                    ContactName: '',
                    ContactDisplayName: '',
                    CompanyName: '',
                    ActivityType: '',
                    ActivityTypeID: 0,
                    ActivitySubject: '',
                    ActivityDate: '',
                    ActivityTime: '',
                    ActivityDuration: '',
                    ActivityRemainderInterval: null,
                    IsActivityEvent: 0,
                    ActivityStageID: 0,
                    RepresentativeID: null,
                    CreatorName: '',
                    Correspondences: {
                        ModuleID: '',
                        DeviceObjID: '',
                        Address: '',
                        GoogleLat: '',
                        GoogleLong: ''
                    },
                    //objCorrespondence: {
                    //    ModuleID:'',
                    //    DeviceObjID: '',
                    //    Address: '',
                    //    GoogleLat: '',
                    //    GoogleLong:''
                    //},
                    ActivityAttendees: [],
                    ParInternal: [],
                    Fields: [],
                    Description: '',
                    Notes: [],
                    OwnerID: 0,
                    OwnerName: '',
                    ContactOwnerID: null,
                    ContactTypeID: null,
                    IsConfidential: 0,
                    IsDeleted: 0,
                    EmployerID: null,
                    CreatorID: 0,
                    CreatedOn: utility.getDateStringInUTC(new Date()),
                    ModifiedAt: '',
                    ModifiedBy: 0,
                    ModifiedByName: '',
                    ModifiedOn: utility.getDateStringInUTC(new Date()),
                    CreatedAt: '',
                    RepresentativeDeviceObjID: '',
                    ActivityDateForSort: utility.getDateStringInUTC(new Date()),
                    ContactTierID: null,
                    ContactTierName: '',
                    ContactSegmentID: null,
                    ContactSegmentName: '',
                    EmployerName: '',
                    RepresentativeName: '',
                    NextContactDate: '',
                    Address: '',
                    LocLat: '',
                    LocLog: ''

                }
            }
        };

        var activity, fields, notes, user, usrInternal;

        serArr.setActivity = function (a) {
            activity = [];
            activity = a;
        };

        serArr.getActivity = function () {
            return activity;
        };

        serArr.setFields = function (a) {
            fields = [];
            fields = a;
        };

        serArr.getFields = function () {
            return fields;
        };

        serArr.setNotes = function (a) {
            notes = [];
            notes = a;
        };

        serArr.getNotes = function () {
            return notes;
        };

        serArr.setParUser = function (a) {
            user = [];
            user = a;
        };

        serArr.getParUser = function () {
            return user;
        };

        serArr.setParInternal = function (a) {
            usrInternal = [];
            usrInternal = a;
        };

        serArr.getParInternal = function () {
            return usrInternal;
        };

        var actStatus;
        serArr.setActStatus = function (status) {
            actStatus = status;
        };

        serArr.getActStatus = function () {
            return actStatus;
        };

        var actHappendVal;
        serArr.setActHappendVal = function (val) {
            actHappendVal = val;
        };

        serArr.getActHappendVal = function () {
            return actHappendVal;
        };

        serArr.fieldSetting = utility.getMasterDataByKey(MASTER_TABLE.AccCatActFldSet);

        function CheckValue(val) {
            if (typeof val == 'undefined') {
                return '';
            }
            return val;
        }

        function CheckNull(val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return "NULL";
            }
            return val;
        }

        function CheckBitVal(val) {
            if (val == true) {
                return 1;
            }
            return 0;
        }

        serArr.sqlActAdd = function (objAct, objActUsrPar, type) {
            var queryBindingsArr = [];
            var actAddQuery = "INSERT INTO Activity (ActivityID,DeviceObjID,ContactDeviceObjID,ModuleID,ContactID,ContactName,ActivitySubject,ActivityDate,ActivityTime,ActivityDuration,ActivityRemainderInterval,IsActivityEvent," +
                                                "OwnerID,OwnerName,ContactTierID,ContactTierName,ContactSegmentID,ContactSegmentName,CompanyName,ActivityStageID,RepresentativeID,ActivityType,ActivityTypeID,CreatorName,LocLat,LocLog,Address,Notes," +
                                                "IsConfidential,IsDeleted,CreatorID,CreatedOn,CreatedAt,ContactTypeID,ContactDisplayName,RepresentativeDeviceObjID,ActivityDateForSort,LoggedInUserID,EmployerID,EmployerName,RepresentativeName)" +
                                " VALUES (" + CheckNull(objAct.ActivityID) + ",'" + objAct.DeviceObjID + "','" + objAct.ContactDeviceObjID + "'," + CheckNull(objAct.ModuleID) + "," + CheckNull(objAct.ContactID) + ",'" + objAct.ContactName + "','" + CheckValue(objAct.ActivitySubject) + "','" +
                                 objAct.ActivityDate + "','" + objAct.ActivityTime + "','" + objAct.ActivityDuration + "'," + CheckNull(objAct.ActivityRemainderInterval) + "," +
                                 CheckBitVal(objAct.IsActivityEvent) + "," + CheckNull(objAct.OwnerID) + ",'" + objAct.OwnerName + "'," + CheckNull(objAct.ContactTierID) + ",'" + CheckValue(objAct.ContactTierName) + "'," + CheckNull(objAct.ContactSegmentID) + ",'" + CheckValue(objAct.ContactSegmentName) + "','" + objAct.CompanyName + "'," + CheckNull(objAct.ActivityStageID) + "," +
                                 CheckNull(objAct.RepresentativeID) + ",'" + objAct.ActivityType + "'," + CheckNull(objAct.ActivityTypeID) + ",'" + objAct.CreatorName + "','" + CheckValue(objAct.LocLat) + "','" + CheckValue(objAct.LocLog) + "','" +
                                 CheckValue(objAct.Address) + "','" + CheckValue(objAct.Description) + "'," + CheckBitVal(objAct.IsConfidential) + "," + CheckBitVal(objAct.IsDeleted) + ",'" + objAct.CreatorID + "','" +
                                 objAct.CreatedOn + "','" + objAct.CreatedAt + "','" + CheckNull(objAct.ContactTypeID) + "','" + objAct.ContactDisplayName + "','" + objAct.RepresentativeDeviceObjID + "','" + objAct.ActivityDateForSort + "'," + $rootScope.loggedInUserID + "," + CheckNull(objAct.EmployerID) + ",'" + objAct.EmployerName + "','" + objAct.RepresentativeName + "')";

            queryBindingsArr.push(
                        {
                            'Query': actAddQuery,
                            'Bindings': ""
                        });
            var queryVal = '';

            if ((objAct.ActivityType == 'Call' || objAct.ActivityType == 'Meeting') && objAct.NextContactDate != '' && objAct.ActivityStageID == GENERAL_CONFIG.ActivityStage.Done) {
                var conNextCoQuery = "UPDATE Contacts SET  NextContactedDate ='" + objAct.NextContactDate + "'" +
                                                       " WHERE DeviceObjID ='" + objAct.ContactDeviceObjID + "'";

                queryBindingsArr.push(
                       {
                           'Query': conNextCoQuery,
                           'Bindings': ""
                       });
            }
            if (type == 'S') {//sync data from load more/pull down
                syncNotes(queryBindingsArr, objAct);
            }
            else {
                if (objAct.Notes.length > 0) {
                    angular.forEach(objAct.Notes, function (obj) {
                         queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
                    });
                    /*var noteQuery = utility.noteInsertQuery(objAct.Notes[0], objAct.DeviceObjID);
                    queryBindingsArr.push(
                           {
                               'Query': noteQuery,
                               'Bindings': ""
                           });
                    */
                }
            }
            for (var i = 0; i < objActUsrPar.length; i++) {
                queryVal += "'" + objActUsrPar[i].DeviceObjID + "'," + CheckNull(objActUsrPar[i].AttendeeID) + ",'" + objActUsrPar[i].UserName + "','" + objActUsrPar[i].ParentDeviceObjType + "','" +
                objAct.DeviceObjID + "','" + objActUsrPar[i].Type + "','" + objActUsrPar[i].AttendeeDeviceObjID + "','" + CheckNull(objActUsrPar[i].AccessCategoryID) + "',1," + $rootScope.loggedInUserID + "," + CheckNull(objActUsrPar[i].EntityAttendeeID);
                if (i < objActUsrPar.length - 1)
                    queryVal += "  UNION ALL SELECT ";
            }

            if (objActUsrPar.length > 0) {
                var actUsrQuery = "INSERT INTO Participients (DeviceObjID,AttendeeID,UserName,ParentType,ParentDeviceObjID,Type,AttendeeDeviceObjID,AccessCategoryID,IsChecked,LoggedInUserID,EntityAttendeeID)" + " SELECT " + queryVal;
                queryBindingsArr.push(
                        {
                            'Query': actUsrQuery,
                            'Bindings': ""
                        });
            }



            if (objAct.Fields.length > 0) {

                var dynamicFldQueryBidings = utility.prepareDynamicFldQuery(objAct);
                var actDynamicFldQuery = dynamicFldQueryBidings.Query
                var actDynamicFldBindings = dynamicFldQueryBidings.Bindings;
                queryBindingsArr.push(
                       {
                           'Query': actDynamicFldQuery,
                           'Bindings': actDynamicFldBindings
                       });
            }

            return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
            }, function (error) {
            });
        }

        serArr.sqlActUpdate = function (objAct, objActUsrPar, type) {
            var queryBindingsArr = [];

            var actUpdateQuery = "UPDATE Activity SET  ContactName ='" + objAct.ContactName + "'," + "ModuleID =" + CheckNull(objAct.ModuleID) + "," +
                                                   "ContactDeviceObjID ='" + objAct.ContactDeviceObjID + "'," +
                                                   "ActivitySubject ='" + objAct.ActivitySubject + "'," + " ActivityDate ='" + objAct.ActivityDate + "'," +
                                                   "ActivityTime ='" + objAct.ActivityTime + "'," + " ActivityDuration ='" + objAct.ActivityDuration + "'," +
                                                   "ActivityRemainderInterval =" + CheckNull(objAct.ActivityRemainderInterval) + "," + "IsActivityEvent =" + CheckBitVal(objAct.IsActivityEvent) + "," +
                                                   "OwnerID ='" + objAct.OwnerID + "'," + "OwnerName ='" + objAct.OwnerName + "'," +
                                                   "ContactTierID =" + CheckNull(objAct.ContactTierID) + "," + "ContactTierName ='" + CheckValue(objAct.ContactTierName) + "'," +
                                                   "ContactSegmentID =" + objAct.ContactSegmentID + "," + "ContactSegmentName ='" + CheckValue(objAct.ContactSegmentName) + "'," +
                                                   "CompanyName ='" + objAct.CompanyName + "'," + "ActivityStageID =" + CheckNull(objAct.ActivityStageID) + "," +
                                                   "RepresentativeID =" + CheckNull(objAct.RepresentativeID) + "," + "ActivityType ='" + objAct.ActivityType + "'," +
                                                   "ActivityTypeID =" + CheckNull(objAct.ActivityTypeID) + "," +
                                                   "CreatorName ='" + objAct.CreatorName + "'," + "LocLat ='" + CheckValue(objAct.LocLat) + "'," +
                                                   "LocLog ='" + CheckValue(objAct.LocLog) + "'," + "Address ='" + CheckValue(objAct.Address) + "'," +
                                                   "Notes ='" + CheckValue(objAct.Description) + "'," + "IsConfidential =" + CheckBitVal(objAct.IsConfidential) + "," +
                                                   "IsDeleted =" + CheckBitVal(objAct.IsDeleted) + "," +
                                                   "ModifiedBy =" + objAct.ModifiedBy + "," + "ModifiedOn ='" + objAct.ModifiedOn + "'," +
                                                   "ModifiedAt ='" + objAct.ModifiedAt + "'," +
                                                   "ContactTypeID =" + CheckNull(objAct.ContactTypeID) + "," + "ContactDisplayName ='" + objAct.ContactDisplayName + "'" +
                                                   "," + "ModifiedByName ='" + objAct.ModifiedByName + "'" +
                                                   " WHERE DeviceObjID ='" + objAct.DeviceObjID + "'";



            var actDeleteFieldsQuery = "DELETE FROM DynamicFields WHERE ParentDeviceObjID ='" + objAct.DeviceObjID + "'";
            var queryVal = '';
            var queryNoteVal = '';

            queryBindingsArr.push(
                        {
                            'Query': actUpdateQuery,
                            'Bindings': ""
                        },
                       {
                           'Query': actDeleteFieldsQuery,
                           'Bindings': ""
                       });

            if (type == 'S') {//sync data from load more/pull down
                syncParData(queryBindingsArr, objAct, objActUsrPar);
                syncNotes(queryBindingsArr, objAct);
            }
            else {
                if (objActUsrPar.length == 0) {
                    var actAllDeleteParQuery = "DELETE FROM Participients WHERE ParentDeviceObjID ='" + objAct.DeviceObjID + "'";
                    queryBindingsArr.push(
                         {
                             'Query': actAllDeleteParQuery,
                             'Bindings': ""
                         });

                }

                var delIds = '';
                if (objActUsrPar.length > 0) {
                    var objNewUserLst = [];
                    for (var i = 0; i < objActUsrPar.length; i++) {
                        if (objActUsrPar[i].EntityAttendeeID == null || objActUsrPar[i].EntityAttendeeID == 0) {
                            objNewUserLst.push(objActUsrPar[i]);
                        }
                        else {
                            delIds += "'" + objActUsrPar[i].DeviceObjID + "',";
                        }
                    }
                    for (var i = 0; i < objNewUserLst.length; i++) {
                        if (objNewUserLst[i].EntityAttendeeID == null || objNewUserLst[i].EntityAttendeeID == 0) {
                            queryVal += "'" + objNewUserLst[i].DeviceObjID + "'," + CheckNull(objNewUserLst[i].AttendeeID) + ",'" + objNewUserLst[i].UserName + "','" + objNewUserLst[i].ParentDeviceObjType + "','" +
                            objAct.DeviceObjID + "','" + objNewUserLst[i].Type + "','" + objNewUserLst[i].AttendeeDeviceObjID + "','" + CheckNull(objNewUserLst[i].AccessCategoryID) + "',1," + $rootScope.loggedInUserID + "," + CheckNull(objNewUserLst[i].EntityAttendeeID);
                            if (i < objNewUserLst.length - 1)
                                queryVal += "  UNION ALL SELECT ";
                        }
                    }
                    if (delIds != '') {
                        delIds = delIds.substring(0, delIds.length - 1);
                        var actDeleteParQuery = "DELETE FROM Participients WHERE ParentDeviceObjID ='" + objAct.DeviceObjID + "' AND DeviceObjID NOT IN (" + delIds + ")";
                        queryBindingsArr.push(
                             {
                                 'Query': actDeleteParQuery,
                                 'Bindings': ""
                             });
                    }
                    if (queryVal != '') {
                        var actUsrQuery = "INSERT INTO Participients (DeviceObjID,AttendeeID,UserName,ParentType,ParentDeviceObjID,Type,AttendeeDeviceObjID,AccessCategoryID,IsChecked,LoggedInUserID,EntityAttendeeID)" + " SELECT " + queryVal;
                        queryBindingsArr.push(
                         {
                             'Query': actUsrQuery,
                             'Bindings': ""
                         });
                    }

                }
                if (objAct.Notes.length > 0) {
                    angular.forEach(objAct.Notes, function (obj) {
                         queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
                    });
                    /*var noteQuery = utility.noteInsertQuery(objAct.Notes[0], objAct.DeviceObjID);
                    queryBindingsArr.push(
                         {
                             'Query': noteQuery,
                             'Bindings': ""
                         });
                    */
                }
            }

            if (objAct.Fields.length > 0) {
                var dynamicFldQueryBidings = utility.prepareDynamicFldQuery(objAct);
                var actDynamicFldQuery = dynamicFldQueryBidings.Query
                var actDynamicFldBindings = dynamicFldQueryBidings.Bindings;
                queryBindingsArr.push(
                        {
                            'Query': actDynamicFldQuery,
                            'Bindings': actDynamicFldBindings
                        });
            }


            return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
            }, function (error) {
            });
        }

        function syncParData(queryBindingsArr, objAct, objActUsrPar) {
            var queryVal = '';
            var actAllDeleteParQuery = "DELETE FROM Participients WHERE ParentDeviceObjID ='" + objAct.DeviceObjID + "'";
            queryBindingsArr.push(
                 {
                     'Query': actAllDeleteParQuery,
                     'Bindings': ""
                 });
            for (var i = 0; i < objActUsrPar.length; i++) {
                queryVal += "'" + objActUsrPar[i].DeviceObjID + "'," + CheckNull(objActUsrPar[i].AttendeeID) + ",'" + objActUsrPar[i].UserName + "','" + objActUsrPar[i].ParentDeviceObjType + "','" +
                objAct.DeviceObjID + "','" + objActUsrPar[i].Type + "','" + objActUsrPar[i].AttendeeDeviceObjID + "','" + CheckNull(objActUsrPar[i].AccessCategoryID) + "',1," + $rootScope.loggedInUserID + "," + CheckNull(objActUsrPar[i].EntityAttendeeID);
                if (i < objActUsrPar.length - 1)
                    queryVal += "  UNION ALL SELECT ";
            }
            if (queryVal != '') {
                var actUsrQuery = "INSERT INTO Participients (DeviceObjID,AttendeeID,UserName,ParentType,ParentDeviceObjID,Type,AttendeeDeviceObjID,AccessCategoryID,IsChecked,LoggedInUserID,EntityAttendeeID)" + " SELECT " + queryVal;
                queryBindingsArr.push(
                 {
                     'Query': actUsrQuery,
                     'Bindings': ""
                 });
            }
        }

        function syncNotes(queryBindingsArr, objAct) {
            var queryNoteVal = '';
            if (objAct.Notes.length > 0) {

                var actAllDeleteNoteQuery = "DELETE FROM Notes WHERE ParentDeviceObjID ='" + objAct.DeviceObjID + "'";
                queryBindingsArr.push(
                        {
                            'Query': actAllDeleteNoteQuery,
                            'Bindings': ""
                        });

                angular.forEach(objAct.Notes, function (obj) {
                     queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
                });

                /*for (var i = 0; i < objAct.Notes.length; i++) {
                    queryNoteVal += "'" + objAct.Notes[i].DeviceObjID + "'," + CheckNull(objAct.Notes[i].ModuleID) + "," + CheckNull(objAct.Notes[i].EntityID) + ",'" + objAct.DeviceObjID + "','" + objAct.Notes[i].Description + "','" +
                                            objAct.Notes[i].CreatedOn + "'," + CheckNull(objAct.Notes[i].CreatorID) + ",'" + objAct.Notes[i].CreatorName + "','" + objAct.Notes[i].CreatedAt + "','" + objAct.Notes[i].ModifiedBy + "','" +
                                            objAct.Notes[i].ModifiedOn + "','" + objAct.Notes[i].ModifiedAt + "'," + $rootScope.loggedInUserID + "," + CheckNull(objAct.Notes[i].NoteID);
                    if (i < objAct.Notes.length - 1)
                        queryNoteVal += "  UNION ALL SELECT ";
                }

                if (queryNoteVal != '') {
                    var actNotesQuery = "INSERT INTO Notes (DeviceObjID,ModuleID,EntityID,ParentDeviceObjID,Description,CreatedOn,CreatorID,CreatorName,CreatedAt,ModifiedBy,ModifiedOn,ModifiedAt,LoggedInUserID,NoteID)" + " SELECT " + queryNoteVal;
                    queryBindingsArr.push(
                     {
                         'Query': actNotesQuery,
                         'Bindings': ""
                     });
                }*/
            }
        }

        serArr.sqlActParAdd = function (objActUsrPar, parentDevId) {
            var queryVal = '';
            for (var i = 0; i < objActUsrPar.length; i++) {
                queryVal += "'" + objActUsrPar[i].AttendeeID + "','" + objActUsrPar[i].UserName + "','" + objActUsrPar[i].ParentDeviceObjType + "','" +
                parentDevId + "','" + objActUsrPar[i].Type + "','" + objActUsrPar[i].AccessCategoryID + "'," + $rootScope.loggedInUserID + "";
                if (i < objActUsrPar.length - 1)
                    queryVal += "  UNION ALL SELECT ";
            }

            return sqliteService.query("INSERT INTO Participients (AttendeeID,UserName,ParentType,ParentDeviceObjID,Type,AccessCategoryID,LoggedInUserID)" +
                               " SELECT " + queryVal
                               ).then(function (result) {
                                   //alert('sucess');
                                   return result;
                               });

        }

        serArr.sqlGetLastInsertedId = function () {
            return sqliteService.query('SELECT ROWID from Activity Where LoggedInUserID = ' + $rootScope.loggedInUserID + ' order by ROWID DESC').then(function (result) {
                return result;
            });
        }

        serArr.sqlDeleteAll = function () {
            return sqliteService.query('DELETE FROM Activity Where LoggedInUserID = ' + $rootScope.loggedInUserID + '').then(function (result) {
                return result;
            });
        }

        serArr.sqlActGetAll = function () {
            return sqliteService.query('SELECT * FROM Activity Where LoggedInUserID = ' + $rootScope.loggedInUserID).then(function (result) {
                return result;
            });
        }

        serArr.sqlSaveNotes = function (objNotes, objAct) {
            var queryBindingsArr = [];
            var actUpdateQuery = '';
            if (objAct.CreatedAt == '' || objAct.CreatedAt == 'null' || objAct.CreatedAt == null) {
                actUpdateQuery = "UPDATE Activity SET  ActivityStageID =" + CheckNull(objAct.ActivityStageID) + ",ActivityDate='" + objAct.ActivityDate + "',ActivityDateForSort='" + objAct.ActivityDateForSort +
                                                        "',ActivityTime='" + objAct.ActivityTime + "'"  +
                                                         ",ModifiedBy =" + objAct.ModifiedBy + "," + "ModifiedOn ='" + objAct.ModifiedOn + "'," +
                                                         "ModifiedByName ='" + objAct.ModifiedByName + "'" +
                                                        " WHERE DeviceObjID ='" + objAct.DeviceObjID + "'";
            }
            else {
                actUpdateQuery = "UPDATE Activity SET  ActivityStageID =" + CheckNull(objAct.ActivityStageID) + ",ActivityDate='" + objAct.ActivityDate + "',ActivityDateForSort='" + objAct.ActivityDateForSort +
                                                        "',ActivityTime='" + objAct.ActivityTime + "'" + ",LocLat='" + CheckValue(objAct.Correspondences[0].GoogleLat) + "'" +
                                                        ",LocLog='" + CheckValue(objAct.Correspondences[0].GoogleLong) + "',Address = '" + CheckValue(objAct.Correspondences[0].Address) + "'," +
                                                        "ModifiedBy =" + objAct.ModifiedBy + "," + "ModifiedOn ='" + objAct.ModifiedOn + "'," +
                                                        "ModifiedAt ='" + objAct.ModifiedAt + "'," +
                                                        "ModifiedByName ='" + objAct.ModifiedByName + "'" +
                                                        " WHERE DeviceObjID ='" + objAct.DeviceObjID + "'";
            }

            if ((objAct.ActivityType == 'Call' || objAct.ActivityType == 'Meeting') && objAct.NextContactDate != '' && objAct.ActivityStageID == GENERAL_CONFIG.ActivityStage.Done) {
                var conNextCoQuery = "UPDATE Contacts SET  NextContactedDate ='" + objAct.NextContactDate + "'" +
                                                       " WHERE DeviceObjID ='" + objAct.ContactDeviceObjID + "'";

                queryBindingsArr.push(
                       {
                           'Query': conNextCoQuery,
                           'Bindings': ""
                       });
            }
            if (objAct.ActivityStageID == GENERAL_CONFIG.ActivityStage.Done) {
                var conUpdateQuery = "UPDATE Contacts SET  LastContactedDate ='" + utility.getDateStringInUTC(new Date()) + "'" +
                                                      " WHERE DeviceObjID ='" + objAct.ContactDeviceObjID + "'";

                queryBindingsArr.push(
                        {
                            'Query': conUpdateQuery,
                            'Bindings': ""
                        });
            }

            queryBindingsArr.push(
                        {
                            'Query': actUpdateQuery,
                            'Bindings': ""
                        });
                        /*{
                            'Query': utility.noteInsertQuery(objNotes[0], objAct.DeviceObjID),
                            'Bindings': ""
                        });*/
            angular.forEach(objNotes, function (obj) {
                 queryBindingsArr.push(noteService.prepareNotesInsertQuery(obj));
            });

            return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
            }, function (error) {
            });

        }

        serArr.sqlGetNotesAll = function (actId) {
            return sqliteService.query(utility.noteSelectQuery(actId)).then(function (result) {
                return result;
            });
        }

        serArr.sqlGetNote = function (actId) {
            return sqliteService.query("SELECT ROWID,Description FROM Notes WHERE ParentDeviceObjID ='" + actId + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + " order by ROWID DESC LIMIT 1").then(function (result) {
                return result;
            });
        }

        serArr.sqlActGetDetails = function (actId) {
            return sqliteService.query("SELECT * FROM Activity WHERE DeviceObjID ='" + actId + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + "").then(function (result) {
                return result;
            });
        }

        serArr.sqlGetContacts = function (devId) {
            return sqliteService.query("SELECT * FROM Contacts WHERE DeviceObjID ='" + devId + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + "").then(function (result) {
                return result;
            });
        }

        serArr.sqlGetCommnications = function (devId) {
            return sqliteService.query("SELECT * FROM Communications WHERE ParentDeviceObjID ='" + devId + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + "").then(function (result) {
                return result;
            });
        }

        //serArr.sqlActUpdate = function (actId) {
        //    return sqliteService.query("SELECT * FROM Activity WHERE DeviceObjID ='" + actId + "'").then(function (result) {
        //        return result;
        //    });
        //}

        serArr.sqlGetAddFields = function (actId) {
            return sqliteService.query("SELECT * FROM DynamicFields WHERE ParentDeviceObjID ='" + actId + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + "").then(function (result) {
                return result;
            });
        }

        serArr.sqlGetParAll = function (actId) {
            return sqliteService.query("SELECT * FROM Participients WHERE ParentDeviceObjID ='" + actId + "' AND LoggedInUserID = " + $rootScope.loggedInUserID + "").then(function (result) {
                return result;
            });
        }

        serArr.PartContact = {
            ID: '',
            Name: ''
        }

        serArr.PartInternal = {
            ID: '',
            Name: ''
        }

        //serArr.sqlActSync = function (actId, devObjId) {
        //    return sqliteService.query("UPDATE Activity SET ActivityID = " + actId + " WHERE DeviceObjID ='" + devObjId + "'").then(function (result) {
        //        return result;
        //    });
        //}

        serArr.sqlActSync = function (resObj) {
            var queryArr = [];
            var actUpdate = "UPDATE Activity SET ActivityID = " + resObj.ActivityID + " WHERE DeviceObjID ='" + resObj.DeviceObjID + "'";
            queryArr.push(
                      {
                          'Query': actUpdate,
                          'Bindings': ""
                      });

            for (var i = 0; i < resObj.ActivityAttendees.length; i++) {
                var entId = resObj.ActivityAttendees[i].EntityAttendeeID;
                var devId = resObj.ActivityAttendees[i].DeviceObjID
                queryArr.push(
                       {
                           'Query': "UPDATE Participients SET EntityAttendeeID = " + entId + " WHERE DeviceObjID ='" + devId + "'",
                           'Bindings': ""
                       });

            }
            if (resObj.Notes.length > 0) {
                var noteUpdate = "UPDATE Notes SET NoteID = " + resObj.Notes[0].NoteID + " WHERE DeviceObjID ='" + resObj.Notes[0].DeviceObjID + "'";
                queryArr.push(
                          {
                              'Query': noteUpdate,
                              'Bindings': ""
                          });
            }
            return sqliteService.multipleQueries(queryArr).then(function (result) {
            }, function (error) {
            });
        }

        serArr.actAdd = function (obj) {
            //console.log("calling activityCTRL");

            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };

            var finalData = { "data": [obj] };
            return serviceApi.doPostWithData("activityAddService",
                    SERVICE_TYPE.ACTIVITYADD, finalData, headerconfig).then(function (response) {
                        return response;
                    });
        }

        serArr.actGetFieldSet = function () {
            return utility.getMasterDataByKey(MASTER_TABLE.ActFldSet);
        }

        serArr.refreshData = function (retrivalType, webSerType) {
            $rootScope.languageID = 1;
            var url = SERVICE_TYPE.ACTIVITYLIST + $rootScope.loggedInUserID + '/0/' + $rootScope.languageID + '/' + retrivalType;
            serviceApi.headerConfg['WebServiceType'] = webSerType;
            return serviceApi.doGetWithoutData("LOADACTIVITYLIST",
                    url, serviceApi.headerConfg).then(function (response) {
                        return response;
                    });
        }

        serArr.syncServerRecords = function (sourceArry, desArry, objOverDue, objDevIds) {

            angular.forEach(sourceArry, function (obj, key) {
                if (obj.DeviceObjID != null) {
                    var exitingLst = [];
                    if (objDevIds.length > 0) {
                        exitingLst = $filter('filter')(objDevIds, { DeviceObjID: obj.DeviceObjID });
                    }
                    else {
                        exitingLst = $filter('filter')(desArry, { DeviceObjID: obj.DeviceObjID });
                    }
                    if (exitingLst.length == 0) {
                        exitingLst = serArr.activityMod().uiObject;
                        utility.syncModelWithoutInnerCollection(obj, exitingLst);
                        checkOverDue(obj, exitingLst, 'A', objOverDue);
                        loadChild(obj, exitingLst, 'A');
                        desArry.push(exitingLst);
                        serArr.sqlActAdd(exitingLst, exitingLst.ActivityAttendees, 'S').then(function (result) {

                        });
                    }
                    else {
                        var extActLst = [];
                        if (objDevIds.length > 0) {
                            extActLst = serArr.activityMod().uiObject;
                        }
                        else {
                            extActLst = exitingLst[0];
                            checkOverDue(obj, extActLst, 'U', objOverDue);
                        }
                        utility.syncModelWithoutInnerCollection(obj, extActLst);
                        loadChild(obj, extActLst, 'U');
                        serArr.sqlActUpdate(extActLst, extActLst.ActivityAttendees, 'S').then(function (result) {
                        });
                    }
                }
            });

            //$scope.$apply();

        }

        function checkOverDue(selLst, tarLst, action, obj) {
            var updatePro = utility.getColorCode(selLst['ActivityDate'], selLst['ActivityTime'], selLst['ActivityStageID']);
            if (updatePro == 1 && action == 'A') {
                obj.OverDue++;
            }
            else {
                var existingP = utility.getColorCode(tarLst['ActivityDate'], tarLst['ActivityTime'], tarLst['ActivityStageID']);
                if (existingP == 1) {
                    if (updatePro > 1)
                        obj.OverDue--;
                }
                else {
                    if (updatePro == 1) {
                        obj.OverDue++;
                    }
                }
            }
        }

        function loadChild(selLst, tarLst, action) {
            if (tarLst.ContactTypeID == 1) {
                tarLst.ContactDisplayName = selLst.ContactName;
                //tarLst.ContactName = tarLst.contactName;
                if (typeof selLst.EmployerName == 'undefined' || selLst.EmployerName == null) {
                    tarLst.CompanyName = '';
                }
                else {
                    tarLst.CompanyName = selLst.EmployerName;
                }
            }
            else {
                tarLst.CompanyName = selLst.ContactName;
                if (typeof selLst.RepresentativeName == 'undefined' || selLst.RepresentativeName == null)
                    tarLst.ContactDisplayName = '';
                else {
                    tarLst.ContactDisplayName = selLst.RepresentativeName;

                }
            }
            tarLst.Priority = utility.getColorCode(tarLst['ActivityDate'], tarLst['ActivityTime'], tarLst['ActivityStageID']);
            loadLocation(selLst.Correspondences, tarLst, action);
            loadFields(selLst, tarLst.Fields, action);
            loadAttendees(selLst, tarLst.ActivityAttendees, action);
            loadNotes(selLst, tarLst, action);
            //loadNote(selLst.DeviceObjID, tarLst.Notes);
        }

        function loadLocation(selLst, tarLst, action) {
            tarLst.Correspondences=[];
            if (selLst.length == 0) { return };
            tarLst.Address = selLst[selLst.length - 1].Address;
            var objCor = new Object();
            tarLst.LocLat = selLst[selLst.length - 1].GoogleLat;
            tarLst.LocLog = selLst[selLst.length - 1].GoogleLong;

            objCor.ModuleID = GENERAL_CONFIG.MODULES.Activity;
            objCor.Address = selLst[selLst.length - 1].Address;
            objCor.GoogleLat = selLst[selLst.length - 1].GoogleLat;
            objCor.GoogleLong = selLst[selLst.length - 1].GoogleLong;
            tarLst.Correspondences.push(objCor);
            //tarLst.Correspondences.Address = selLst[selLst.length - 1].Address;
            //tarLst.Correspondences.ModuleID = GENERAL_CONFIG.MODULES.Activity;
            //tarLst.Correspondences.GoogleLat = selLst[selLst.length - 1].GoogleLat;
            //tarLst.Correspondences.GoogleLong = selLst[selLst.length - 1].GoogleLong;
        }

        function loadNotes(selLst, tarLst, action) {
            tarLst.Notes = [];
            if (selLst.Notes.length > 0) {
                tarLst.Notes.Description = selLst.Notes[selLst.Notes.length - 1].Description;
            }
            angular.forEach(selLst.Notes, function (obj, key) {
                // var devId = obj.DeviceObjID == null ? utility.generateUUID() : obj.DeviceObjID;
                if (typeof obj.Description != 'undefined') {
                    var noteObjModel = noteService.noteMod().noteModel;
                    noteObjModel.EntityID = selLst.ActivityID;
                    noteObjModel.ModuleID = GENERAL_CONFIG.MODULES.Activity;
                    noteObjModel.ParentDeviceObjID = selLst.DeviceObjID;
                    noteObjModel.Description = obj.Description;
                    noteObjModel.CreatorID = obj.CreatorID;
                    noteObjModel.NoteID = obj.NoteID;
                    noteObjModel.CreatorName = obj.CreatorName;
                    noteObjModel.CreatedOn = obj.CreatedOn;
                    noteObjModel.CreatedAt = obj.CreatedAt;
                    tarLst.Notes.push(noteObjModel);
                }
            });
        }

        function loadAttendees(selLst, tarLst, action) {
            angular.forEach(selLst.ActivityAttendees, function (obj, key) {
                var devId = obj.DeviceObjID == null ? utility.generateUUID() : obj.DeviceObjID;
                tarLst.push(
                    {
                        EntityAttendeeID: obj.EntityAttendeeID,//obj.ActivityAttendeeID,//didn't get this value right now..hardcoded 0
                        AttendeeID: obj.AttendeeID,
                        UserName: obj.AttendeeName,
                        Type: obj.IsContact == true ? 'CP' : 'UP',
                        ParentDeviceObjType: selLst.DeviceObjID,
                        DeviceObjID: devId,
                        IsContact: obj.IsContact,
                        IsChecked: 1,
                        AttendeeDeviceObjID: obj.AttendeeDeviceObjID
                    });
            });
        }

        function loadFields(sourceArr, desArr, action) {
            var count = 1;
            angular.forEach(sourceArr.Fields, function (obj, key) {
                desArr.push({
                    EntityID: sourceArr.ActivityID,
                    ModuleID: GENERAL_CONFIG.MODULES.Activity,
                    ParentDeviceObjID: sourceArr.DeviceObjID,
                    FieldLabel: '',
                    FieldName: obj.FieldName,
                    FieldValue: obj.FieldValue,
                    FieldID: obj.FieldID,
                    IsConfidential: 0,
                    IsMandatory: 0,
                    IsVisible: 0
                });
                count++;
            });
        }

        serArr.sqlGetAllActDeviceObjIds = function () {
            return sqliteService.query("SELECT DeviceObjID FROM Activity WHERE LoggedInUserID = " + $rootScope.loggedInUserID + " ").then(function (result) {
                return result;
            });
        }

        return serArr;
    }

})();
