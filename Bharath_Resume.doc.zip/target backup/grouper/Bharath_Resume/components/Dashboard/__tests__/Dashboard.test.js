import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../store/configureStore'
import Dashboard, { Dashboard as DashboardComponent } from '../Dashboard'

describe('Dashboard component', () => {
  let store, wrapper, wrapperBlock
  store = configureStore
  let grouperList = [{'group_id': 5, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534306000, 'department': {'department_id': 244, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962800000, 'status': 'Active'}]
  let props = {
    classes: {},
    grouperList: grouperList,
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }
  it('renders', () => {
    const div = document.createElement('div')
    shallow(
      <Provider store={store}>
        <Dashboard />
      </Provider>, div)
  })

  it('renders with props', () => {
    wrapper = mount(
      <Provider store={store}>
        <Dashboard {...props} />
      </Provider>)
    expect(wrapper).toHaveLength(1)
  })

  it('invoking resetFilter ', () => {
    wrapperBlock = shallow(
      <DashboardComponent
        {...props}
      />)
    wrapperBlock.instance().resetFilter()
    expect(wrapperBlock.instance().state.data).toEqual(props.grouperList)
  })

  it('invoking handleClick ', () => {
    wrapperBlock = shallow(
      <DashboardComponent
        {...props}
      />)
    wrapperBlock.instance().handleClick({}, props.grouperList[0].group_id, props.grouperList[0].group_type)
    expect(wrapperBlock.instance().state.dialogOpenStatus).toEqual(true)
  })

  it('invoking deleteConfirm ', (done) => {
    props.deleteGroup = jest.fn()
    props.closeSnackBar = jest.fn()
    wrapperBlock = shallow(
      <DashboardComponent
        {...props}
      />)
    wrapperBlock.instance().deleteConfirm(false)
    expect(wrapperBlock.instance().state.dialogOpenStatus).toEqual(false)

    wrapperBlock.instance().deleteConfirm(true)
    expect(props.deleteGroup.mock.calls.length).toEqual(1)
    setTimeout(() => {
      done(expect(props.closeSnackBar.mock.calls.length).toEqual(1))
    }, 3000)
  })

  it('invoking getFilter ', (done) => {
    wrapperBlock = shallow(
      <DashboardComponent
        {...props}
      />)
    wrapperBlock.instance().getFilter({ group_type: 'variation' })
    expect(wrapperBlock.instance().state.data.length).toEqual(1)
    wrapperBlock.instance().getFilter({ 'department,department_value': '244-null' })
    expect(wrapperBlock.instance().state.data.length).toEqual(1)
    wrapperBlock.instance().getFilter({ 'launch_date': 1406962800000 })
    expect(wrapperBlock.instance().state.data.length).toEqual(0)
  })

  it('invoking componentWillReceiveProps ', () => {
    props.grouperList = []
    wrapperBlock = shallow(
      <DashboardComponent
        {...props}
      />)
    wrapperBlock.setProps({ grouperList })
    expect(wrapperBlock.instance().state.data).toEqual(grouperList)
  })
})
