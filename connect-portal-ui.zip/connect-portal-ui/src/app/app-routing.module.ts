import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AutoLoginAllRoutesGuard } from 'angular-auth-oidc-client';
import { PIPELINE_ENTITY_TYPE } from './pipelines/pipeline/shared/pipeline';
import { NoConnectionGuard } from './shared/components/error/no-connection.guard';

const routes: Routes = [
  {
    path: 'data-integration/error',
    canActivate: [NoConnectionGuard],
    loadChildren: () => import('./shared/components/error/error.module').then((m) => m.ErrorModule)
  },
  {
    path: 'data-integration/agents',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./agents/agents.module').then((m) => m.AgentsModule)
  },
  {
    path: 'data-integration/servers',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./servers/servers.module').then((m) => m.ServersModule)
  },
  {
    path: 'data-integration/connections',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./connections/connections.module').then((m) => m.ConnectionsModule)
  },
  {
    path: 'data-integration/pipelines',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./pipelines/pipelines.module').then((m) => m.PipelinesModule)
  },
  {
    path: 'data-integration/pipelines/:name',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./pipelines/pipelines.module').then((m) => m.PipelinesModule)
  },
  {
    path: 'data-integration/metabases',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./metabases/metabases.module').then((m) => m.MetabasesModule)
  },
  {
    path: 'data-integration/bundles',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./bundles/bundles.module').then((m) => m.BundlesModule)
  },
  {
    path: 'data-integration/scheduled-pipelines',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./pipelines/pipelines.module').then((m) => m.PipelinesModule),
    data: { pipelineEntityType: PIPELINE_ENTITY_TYPE.SCHEDULED }
  },
  {
    path: 'data-integration/scheduled-pipelines/:name',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./pipelines/pipelines.module').then((m) => m.PipelinesModule),
    data: { pipelineEntityType: PIPELINE_ENTITY_TYPE.SCHEDULED }
  },
  {
    path: 'data-integration/projects',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./projects/projects.module').then((m) => m.ProjectsModule)
  },
  {
    path: 'data-integration',
    canActivate: [AutoLoginAllRoutesGuard],
    loadChildren: () => import('./home/home.module').then((m) => m.HomeModule)
  },
  {
    path: '',
    redirectTo: '/data-integration',
    pathMatch: 'full'
  },
  {
    path: '**',
    redirectTo: '/data-integration',
    pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { enableTracing: false })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
