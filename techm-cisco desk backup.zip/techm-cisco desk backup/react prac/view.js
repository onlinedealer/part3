import React from 'react';
import ReactDOM from 'react-dom';
import { Router, Route, Link, browserHistory, IndexRoute  } from 'react-router'


class view extends React.Component {
		constructor(props) {
		    super(props);

		    this.state = { formData: {fName: '', lName: '', empID: ''} };

		    this.fName = this.fName.bind(this);
		    this.lName = this.lName.bind(this);
		    this.empID = this.empID.bind(this);
		}
	
	  fName(event) {
	    this.state.formData.fName = event.target.value;
	  }
	
	  lName(event) {
	    this.state.formData.lName = event.target.value;
	  }
	
	  empID(event) {
	    this.state.formData.empID = event.target.value;
	  }	
	
	 

   render() {
      return (
         <div className="container-fluid">
			<div className="row">
			    <div className="col-lg-6">
			      <form onSubmit={this.handleSubmit}>
				      <h1>{props.name}</h1>
						<hr/>
				      <div className="form-group">
				        <label>First Name</label>
				        <input type="text" className="form-control" onChange={ this.fName } placeholder="first name"/>
				      </div>
				      <div className="form-group">
				        <label>Last Name</label>
				        <input type="text" className="form-control" onChange={ this.lName } placeholder="last name"/>
				      </div>
				      <div className="form-group">
				        <label>ID</label>
				        <input type="number" className="form-control" onChange={ this.empID } placeholder="Enter you ID"/>
				      </div>
			      </form>
			    </div>
			</div>
		</div>
      );
   }
}

export default view;