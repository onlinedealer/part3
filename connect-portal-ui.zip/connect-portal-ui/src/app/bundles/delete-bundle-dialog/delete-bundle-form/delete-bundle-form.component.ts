import { Component, Input } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';

/**
 * Form used to delete bundles
 */
@Component({
  selector: 'p-connect-delete-bundle-form',
  templateUrl: './delete-bundle-form.component.html'
})
export class DeleteBundleFormComponent {
  /**
   * The number of bundles selected
   */
  @Input() bundlesCount: number;

  /**
   * The number of bundles to be deleted
   */
  @Input() deletableBundlesCount: number;

  constructor(private readonly translocoService: TranslocoService) {}

  /**
   * Get the plural or singular verb
   */
  get pluralOrSingularVerb(): string {
    let verb = this.bundlesCount !== 1 ? 'bundles.STOP_BUNDLE.BUNDLES' : 'bundles.STOP_BUNDLE.BUNDLE';
    return this.translocoService.translate(verb);
  }
}
