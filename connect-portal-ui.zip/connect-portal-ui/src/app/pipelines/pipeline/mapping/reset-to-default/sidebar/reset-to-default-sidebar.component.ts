import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { SidebarComponent } from '../../../../../shared/components/sidebar/sidebar.component';
import { Pipeline, TableMapping } from '../../../shared/pipeline';
import { PipelineMappingService } from '../../pipeline-mapping.service';

@Component({
  selector: 'p-connect-reset-to-default-sidebar',
  templateUrl: './reset-to-default-sidebar.component.html'
})
export class ResetToDefaultSidebarComponent {
  @Input() pipeline: Pipeline;
  @Input() checkedItems;
  @Output() resetBtnClicked = new EventEmitter();
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  resetToDefaultButton: SidebarButton = {
    id: 'resetToDefaultResetButton',
    text: 'pipelines.STAGES.MAPPING.RESET_TO_DEFAULT.RESET_BUTTON'
  };
  cancelButton: SidebarButton = {
    id: 'resetToDefaultCancelButton',
    text: 'pipelines.STAGES.MAPPING.RESET_TO_DEFAULT.CANCEL'
  };
  selectedMappingListData;
  sourceDataCount: number;
  resetTarget = true;
  resetFields = false;
  checkboxDisable = false;
  schemaRegistryAvailable: boolean;
  constructor(private readonly mappingService: PipelineMappingService, private readonly featureFlagService: FeatureFlagService) {}

  open(data) {
    this.schemaRegistryAvailable = this.pipeline.target.parameters?.find((ele) => ele.key === 'SCHEMA_REGISTRY_ID') ? true : false;
    this.selectedMappingListData = data[0];
    this.sourceDataCount = data[1];
    this.sidebarComponent.open();
    this.disableCheckbox();
    this.saveTableMapping();
  }

  cancelSidebarButtonClicked() {
    this.sidebarComponent.close();
  }

  onCheck() {
    this.disableCheckbox();
    if (!this.resetTarget && !this.resetFields) {
      this.resetToDefaultButton.isDisabled = true;
    } else {
      this.resetToDefaultButton.isDisabled = false;
    }
  }

  resetButtonClicked() {
    if (this.resetTarget) {
      this.resetBtnClicked.emit({ resetField: this.resetFields, resetTable: this.resetTarget });
    }
    if (this.resetFields) {
      let table = this.filterTableMapping(this.checkedItems, this.pipeline.tableMapping);
      this.mappingService.bulkResetToDefault(this.pipeline.id, this.resetFields, this.resetTarget, table).subscribe({
        next: () => {
          this.sidebarComponent.close();
          this.checkedItems.forEach((element) => {
            element.hasCustomColMappings = false;
          });
        },
        error: (errorMessage: HttpErrorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorMessage);
        }
      });
    }
    this.sidebarComponent.close();
  }

  saveTableMapping() {
    this.sidebarComponent.isProcessingRequest = true;
    this.mappingService.saveTableMapping(this.pipeline.id, this.pipeline.tableMapping).subscribe({
      next: () => {
        this.sidebarComponent.isProcessingRequest = false;
      },
      error: (errorResponse: HttpErrorResponse) => {
        this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        this.sidebarComponent.isProcessingRequest = false;
      }
    });
  }

  filterTableMapping(checkedItems, tableMappings: TableMapping[]): TableMapping[] {
    let result: TableMapping[] = [];
    checkedItems.forEach((checkedItem) => {
      result.push(
        tableMappings.find((element) => {
          return checkedItem.id === element.id;
        })
      );
    });
    return result;
  }

  disableCheckbox() {
    if (this.schemaRegistryAvailable) {
      this.checkboxDisable = true;
      if (this.resetTarget) {
        this.resetFields = true;
      } else {
        this.resetFields = false;
      }
    }
  }
}
