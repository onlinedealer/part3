import { MeteringPointEventsDefinitionsResponse } from "../event.model";

export const event = {
    meteringPointId: 1,
    id: 1
};

export const eventDefinitionsResponse: MeteringPointEventsDefinitionsResponse = {
    types: [{ eventType: 1, name: "alarm", description: "Alarms from Metering devices", classes: [] }],
    classes: [
        {
            eventClassId: 1,
            description: "Power alarms",
            displaySequenceNo: 1,
            identifier: "Power Alarm",
            name: "Power ALarm",
            eventType: 1,
            definitions: []
        },
        {
            eventClassId: 2,
            description: "Alarms that indicate an internal fault in the metering device",
            displaySequenceNo: 3,
            identifier: "AlmInternalFaultAlarm",
            name: "Internal fault alarm",
            eventType: 1,
            definitions: []
        }
    ],
    definitions: [
        {
            displaySequenceNo: 1,
            eventClassId: 1,
            eventDefinitionId: 1,
            eventLevel: 2,
            identifier: "AlmPowerOut",
            name: "Power Out",
            description: "Power Outtagestarted",
            parameters: [{ index: 1, type: 1, usage: 0, name: "phase", description: "all phases" }]
        },
        {
            displaySequenceNo: 2,
            eventClassId: 1,
            eventDefinitionId: 2,
            eventLevel: 3,
            identifier: "AlmPowerOut",
            name: "Power resumed",
            description: "Power Outtagestarted",
            parameters: [{ index: 1, type: 1, usage: 0, name: "phase", description: "all phases" }]
        },
        {
            displaySequenceNo: 3,
            eventClassId: 1,
            eventDefinitionId: 3,
            eventLevel: 2,
            identifier: "AlmPhaseOut",
            name: "Power resumed",
            description: "Power Outtage started in phase %1",
            parameters: [{ index: 1, type: 1, usage: 0, name: "phase", description: "The phase in which power went out" }]
        }
    ]
};

// export const eventTypesEntities: EventTypeEntities = {
//     1: {
//         eventType: 1,
//         name: "alarm",
//         description: "Alarms from Metering devices",
//         classes: [1, 2]
//     }
// };
// export const eventClassesEntities: EventClassEntities = {
//     1: {
//         eventClassId: 1,
//         description: "Power alarms",
//         displaySequenceNo: 1,
//         identifier: "Power Alarm",
//         name: "Power ALarm",
//         eventType: 1,
//         definitions: [1, 2, 3]
//     },
//     2: {
//         eventClassId: 2,
//         description: "Alarms that indicate an internal fault in the metering device",
//         displaySequenceNo: 3,
//         identifier: "AlmInternalFaultAlarm",
//         name: "Internal fault alarm",
//         eventType: 1,
//         definitions: []
//     }
// };

// export const eventDefinitionsEntities: EventDefinitionEntities = {
//     1: {
//         displaySequenceNo: 1,
//         eventClassId: 1,
//         eventDefinitionId: 1,
//         eventLevel: 2,
//         identifier: "AlmPowerOut",
//         name: "Power Out",
//         description: "Power Outtagestarted",
//         parameters: [{ index: 1, type: 1, usage: 0, name: "phase", description: "all phases" }]
//     },
//     2: {
//         displaySequenceNo: 2,
//         eventClassId: 1,
//         eventDefinitionId: 2,
//         eventLevel: 3,
//         identifier: "AlmPowerOut",
//         name: "Power resumed",
//         description: "Power Outtagestarted",
//         parameters: [{ index: 1, type: 1, usage: 0, name: "phase", description: "all phases" }]
//     },
//     3: {
//         displaySequenceNo: 3,
//         eventClassId: 1,
//         eventDefinitionId: 3,
//         eventLevel: 2,
//         identifier: "AlmPhaseOut",
//         name: "Power resumed",
//         description: "Power Outtage started in phase %1",
//         parameters: [{ index: 1, type: 1, usage: 0, name: "phase", description: "The phase in which power went out" }]
//     }
// };
export const eventTypesTreeVO: any[] = [
    {
        name: "alarm",
        id: 1,
        classes: [
            {
                id: 1,
                name: "Power ALarm",
                definitions: [{ id: 1, name: "Power Out" }, { id: 2, name: "Power resumed" }, { id: 3, name: "Power resumed" }]
            },
            { id: 2, name: "Internal fault alarm", definitions: [] }
        ]
    }
];
export const events = [event, eventDefinitionsResponse];
