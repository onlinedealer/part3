import merge from 'lodash/merge'

const commonConfig = {
  auth: {
    authorizationPath: '/auth/oauth/v2/authorize',
    logoutPath: '/login/responses/logoff.html',
    popupOptions: { width: 482, height: 680 },
    redirectUri: `${window.location.origin}/auth/login`,
    responseType: 'token id_token',
    scope: ['openid profile email'],
    storageType: 'localStorage',
    tokenType: 'Bearer',
  },
}

const envConfigs = {
  qa: {
    auth: {
      host: 'https://oauth.iam.perf.target.com',
      logoutHost: 'https://logonservices.iam.perf.target.com',
      clientId: 'grouper_npe_im',
      nonce: '1234',
      accessDeniedHost: 'https://logonservices.iam.perf.target.com/login/responses/accessdenied.html',
      adGroup: 'APP-LPP-STG-Mass-Maintain',
    },
    lpLinks: {
      home: 'https://xycpre-launchpad.target.com/',
      search: 'https://xycpre-launchpad.target.com/item-search/base',
      help: 'https://xycpre-launchpad.target.com/help-center',
    },
    grouper: {
      // commonPath: 'https://item-grouper-stage.us-central-1.test.core.k8s.tgt/grouper/v1/',
      // commonPath: 'https://item-grouper.test.k8s.target.com/grouper/v1/',
      commonPath: 'https://apitemgrouperv1.dev.target.com/grouper/v1/',
      // commonPath: 'http://localhost:8180/grouper/v1/',
      // commonPath: 'https://apitemgrouperv1-development.dev.target.com/grouper/v1/',
      getGrouperList: 'grouplist',
      getGrouperTypes: 'group_types',
      getItemTypes: 'item_type',
      getThemes: 'themes',
      group: 'group',
      deleteMultiple: 'groupsdelete',
      getCollectionItemTypes: 'item_type_collection',
      getCollectionMtas: 'collection_mta_details',
      getVariationItemTypes: 'all_item_types',
      getFixedThemes: 'get_fixed_themes',
      publishGroup: 'publishUnPublishGroups',
      getGrouperListPagination: 'groups',
      getStatusList: 'group_status_list',
      itemTypeOfFirstTcin: 'item_type_of_first_tcin',
    },
  },
  preprod: {
    auth: {
      host: 'https://oauth.iam.perf.target.com',
      logoutHost: 'https://logonservices.iam.perf.target.com',
      clientId: 'grouper_npe_im',
      nonce: '1234',
      accessDeniedHost: 'https://logonservices.iam.perf.target.com/login/responses/accessdenied.html',
      adGroup: 'APP-LPP-STG-Mass-Maintain',
    },
    lpLinks: {
      home: 'https://xycpre-launchpad.target.com/',
      search: 'https://xycpre-launchpad.target.com/item-search/base',
      help: 'https://xycpre-launchpad.target.com/help-center',
    },
    grouper: {
      commonPath: 'https://apitemgrouperv1-development.dev.target.com/grouper/v1/',
      getGrouperList: 'grouplist',
      getGrouperTypes: 'group_types',
      getItemTypes: 'item_type',
      getThemes: 'themes',
      group: 'group',
      deleteMultiple: 'groupsdelete',
      getCollectionItemTypes: 'item_type_collection',
      getCollectionMtas: 'collection_mta_details',
      getVariationItemTypes: 'all_item_types',
      getFixedThemes: 'get_fixed_themes',
      publishGroup: 'publishUnPublishGroups',
      getGrouperListPagination: 'groups',
      getStatusList: 'group_status_list',
      itemTypeOfFirstTcin: 'item_type_of_first_tcin',
    },
  },
  prod: {
    auth: {
      host: 'https://oauth.iam.target.com',
      logoutHost: 'https://logonservices.iam.target.com',
      clientId: 'grouper_prod_im',
      nonce: '1234',
      accessDeniedHost: 'https://logonservices.iam.target.com/login/responses/accessdenied.html',
      adGroup: 'APP-LPP-STG-Mass-Maintain',
    },
    lpLinks: {
      home: 'https://launchpad.target.com/',
      search: 'https://launchpad.target.com/item-search/base',
      help: 'https://launchpad.target.com/help-center',
    },
    grouper: {
      commonPath: 'https://apitemgrouperv1.prod.target.com/grouper/v1/',
      getGrouperList: 'grouplist',
      getGrouperTypes: 'group_types',
      getItemTypes: 'item_type',
      getThemes: 'themes',
      group: 'group',
      deleteMultiple: 'groupsdelete',
      getCollectionItemTypes: 'item_type_collection',
      getCollectionMtas: 'collection_mta_details',
      getVariationItemTypes: 'all_item_types',
      getFixedThemes: 'get_fixed_themes',
      publishGroup: 'publishUnPublishGroups',
      getGrouperListPagination: 'groups',
      getStatusList: 'group_status_list',
      itemTypeOfFirstTcin: 'item_type_of_first_tcin',
    },
  },
}

// env.js sets APP_ENV
const appEnv = process.env.APP_ENV
const config = envConfigs[appEnv]
const apiConfig = merge(commonConfig, config)

export default apiConfig
