import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve, RouterStateSnapshot } from '@angular/router';
import { FirstTimeUserService } from 'app/first-time-user.service';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ResolveHomeService implements Resolve<boolean> {
  constructor(private firstTimeUserService: FirstTimeUserService) {}
  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {
    this.firstTimeUserService.showHeaderMenu(false);
    return true;
  }
}
