import { Mocks, Spies } from 'discovery-test';
import { ResultsComponent } from './results.component';
import { TreePath } from '../tree-path.model';
import { TreeTableModel } from '../tree-table.model';
import { ProfileResultsTableModel } from '../profile-results-table.model';
import { of, throwError } from 'rxjs';

describe('ResultsComponent', () => {
  let component: ResultsComponent;

  beforeEach(() => {
    Spies.init();
    component = new ResultsComponent(
      Spies.TranslateService,
      Spies.ProfileResultsService,
      Spies.ToastrService,
      Spies.eventBusService,
      Spies.HttpUtilService
    );
    component.treePath = new TreePath();
    component.treePath.treeData = new TreeTableModel();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('ngOnInit be called', () => {
    component.ngOnInit();
    expect(component.treePath.treeData).toBeDefined();
  });

  it('should check toggleEmptyTable function for table view', () => {
    component.treePath.tableName.name = 'CUSTOMER_DATA_SEMANTIC';
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 0;
    component.loadData();
    expect(component.header.name).toBe('CUSTOMER_DATA_SEMANTIC');
  });

  it('should check loadTableView function', () => {
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'PHONE_TABLE' as any;
    component.treePath.treeData.data = Mocks.MockTableStats.tables[0];
    Spies.ProfileResultsService.getTableStats.and.returnValue(of(Mocks.MockTableStatistics));
    component.loadData();
    expect(component.showResults).toBe(true);
    expect(component.visitedTables.length).toBe(1);
  });

  it('should not call loadTableView function on table level error', () => {
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'PHONE_TABLE' as any;
    component.treePath.treeData.data.errorMessage = 'error';
    const spy = spyOn<any>(component, 'loadTableView');
    Spies.ProfileResultsService.getTableStats.and.returnValue(of(Mocks.MockTableStatistics));
    component.loadData();
    expect(spy.calls.count()).toBe(0);
  });

  it('should check loadTableView function failed with status 404', () => {
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'PHONE_TABLE' as any;
    component.treePath.treeData.data = Mocks.MockTableStats.tables[0];
    Spies.ProfileResultsService.getTableStats.and.returnValue(throwError({ status: 404 }));
    component.loadData();
    expect(component.failureMessages.length).toBe(1);
  });

  it('should check loadTableView function failed with status 400', () => {
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'PHONE_TABLE' as any;
    component.treePath.treeData.data = Mocks.MockTableStats.tables[0];
    Spies.ProfileResultsService.getTableStats.and.returnValue(throwError({ status: 400 }));
    component.loadData();
    expect(component.failureMessages.length).toBe(1);
  });

  it('should check loadTableView function failed with status other than 400 and 404', () => {
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'PHONE_TABLE' as any;
    component.treePath.treeData.data = Mocks.MockTableStats.tables[0];
    Spies.ProfileResultsService.getTableStats.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[2]));
    component.loadData();
    expect(component.failureMessages.length).toBe(1);
  });

  it('should check loadColumnView function', () => {
    component.profileMetadata = {
      host: 'host',
      source: 'source',
      sourceType: 'sourceType',
      db: 'db',
      schema: 'schema'
    };
    component.treePath.columnView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'CUSTOMER_ADDRESS' as any;
    component.treePath.columnName = 'CA_SUITE_NUMBER' as any;
    Spies.ProfileResultsService.getTableStats.and.returnValue(of(Mocks.MockTableStatistics.columns[0]));
    component.loadData();
    expect(component.showResults).toBe(true);
    expect(component.visitedColumns.length).toBe(1);
  });

  it('should not call loadColumnView function in case of column-level error', () => {
    component.treePath.columnView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 50000000;
    component.treePath.treeData.data.errorMessage = 'error';
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'CUSTOMER_ADDRESS' as any;
    component.treePath.columnName = 'CA_SUITE_NUMBER' as any;
    Spies.ProfileResultsService.getTableStats.and.returnValue(of(Mocks.MockTableStatistics.columns[0]));
    const spy = spyOn<any>(component, 'loadColumnView');
    component.loadData();
    expect(spy.calls.count()).toBe(0);
  });

  it('should check loadColumnView function failed with status 404', () => {
    component.treePath.columnView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'CUSTOMER_ADDRESS' as any;
    component.treePath.columnName = 'CA_SUITE_NUMBER' as any;
    Spies.ProfileResultsService.getColumnStats.and.returnValue(throwError({ status: 404 }));
    component.loadData();
    expect(component.failureMessages.length).toBe(1);
  });

  it('should check loadColumnView function failed with status 404', () => {
    component.treePath.columnView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'CUSTOMER_ADDRESS' as any;
    component.treePath.columnName = 'CA_SUITE_NUMBER' as any;
    Spies.ProfileResultsService.getColumnStats.and.returnValue(throwError({ status: 400 }));
    component.loadData();
    expect(component.failureMessages.length).toBe(1);
  });

  it('should check loadColumnView function failed with status other than 404 and 400', () => {
    component.treePath.columnView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 50000000;
    component.treePath.runId = 'runId-1';
    component.treePath.tableName = 'CUSTOMER_ADDRESS' as any;
    component.treePath.columnName = 'CA_SUITE_NUMBER' as any;
    Spies.ProfileResultsService.getColumnStats.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[2]));
    component.loadData();
    expect(component.failureMessages.length).toBe(1);
  });

  it('should render table data in case already api called', () => {
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = 50000000;
    component.treePath.tableName = {
      name: 'CUSTOMER_ADDRESS',
      displayName: 'CUSTOMER_ADDRESS',
      type: 'STRING'
    };
    component.visitedTables.push(Mocks.MockTableStats.tables[0]);
    component.loadData();
    expect(component.treePath.treeData.data.status).toBe('SUCCESS');
  });

  it('should check toggleEmptyTable function for column view', () => {
    component.treePath.columnName.name = 'CC';
    component.treePath.columnName.type = 'STRING';
    component.treePath.columnView = true;
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 0;
    component.loadData();
    expect(component.header.name).toBe('CC (STRING)');
  });

  it('should render column data in case already api called', () => {
    const obj = {
      name: 'CA_SUITE_NUMBER',
      type: 'STRING',
      statistics: [
        { type: 'CompletenessStatistics', completeCount: 48499750, nullCount: 1500250, blankCount: 0 },
        {
          type: 'TextPatternStatistics',
          patterns: {
            '"Aaaaa 9"': { '"[A-Z][a-z]{4}\\\\s[0-9]"': 485702 }
          }
        }
      ],
      tableName: 'CUSTOMER_ADDRESS'
    };
    component.visitedColumns.push(obj);
    component.treePath.columnView = true;
    component.treePath.tableName.name = 'CUSTOMER_ADDRESS';
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = 50000000;
    component.treePath.columnName = {
      name: 'CA_SUITE_NUMBER',
      type: 'STRING',
      displayName: 'CA_SUITE_NUMBER (STRING)'
    };
    component.loadData();
    expect(component.treePath.treeData.data.name).toBe('CA_SUITE_NUMBER');
  });
  it('should check modalView function', () => {
    component.treePath.modelName = 'dummy';
    component.treePath.modelView = true;
    component.loadData();
    expect(component.header.name).toBe('dummy');
  });
  it('should emit trends sideba open event for total records on launchTrendsSidebar', () => {
    component.launchTrendsSidebar('Total Records');
    expect(Spies.eventBusService['emit']).toHaveBeenCalled();
  });
});
