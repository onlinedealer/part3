import { CommonModule } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslocoModule } from '@ngneat/transloco';
import { SecondaryNavItemsService } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { SortEvent } from 'primeng/api';
import { DialogService as PrimeNgDialogService } from 'primeng/dynamicdialog';
import { of } from 'rxjs';
import { AlertModel } from '../alert.model';
import { AlertsListingComponent } from './alerts-listing.component';

describe('AlertsListingComponent', () => {
  const mockSecNav = jasmine.createSpyObj('SecondaryNavItemsService', ['getNavItems']);
  let component: AlertsListingComponent;
  let alertMockService: any;
  let mockObserverService: any;
  let mockAlertCount: any;
  let mockAlert, mockAlert2: AlertModel;
  let mockEvent: SortEvent;
  let dialogService: PrimeNgDialogService;

  beforeEach(() => {
    mockAlert = {
      id: '1',
      alertType: 'VOLUME',
      alertLevel: 'WARNING',
      summary: 'summary',
      assetName: 1,
      assetNameClipped: 'ABC',
      assetType: 'TABLE',
      raisedAt: new Date('2022-06-01T00:00:00Z'),
      confidence: 43.7767,
      assetUid: '12938102qsjkldhal',
      tableName: 'customers',
      schema: 'customers',
      source: 'snowflake',
      sourceType: 'database',
      observer: 'obsv32',
      alertConfiguration: 'Confidence Based Alerts',
      profileStartTime: new Date('2022-06-01T00:00:00Z'),
      thresholdAlertMetrics: [
        {
          metricType: 'VALUE_MIN',
          metricName: 'Minimum Value',
          metricDetails: [
            {
              currentMetric: '130',
              comparisonMetric: '10',
              alertLevel: 'CRITICAL',
              percentageChange: 99.0,
              alertAgainst: 'MOVING_AVERAGE'
            }
          ]
        }
      ],
      confidenceAlertMetrics: [
        {
          metricType: 'VALUE_MIN',
          metricName: 'Minimum Value',
          metricDetails: [
            {
              currentMetric: '130',
              comparisonMetric: '10',
              alertLevel: 'CRITICAL',
              probability: 99.0,
              sampleKey: 'JPY'
            }
          ]
        }
      ]
    };

    mockAlert2 = {
      id: '2',
      alertType: 'Data Drift',
      alertLevel: 'WARNING',
      summary: 'summary',
      assetName: 1,
      assetNameClipped: 'ABC',
      assetType: 'TABLE',
      assetParentName: 'parent',
      assetParentType: 'table',
      raisedAt: new Date('2022-06-01T00:00:00Z'),
      confidence: 43.7767,
      assetUid: '12938102qsjkldhal',
      tableName: 'customers',
      schema: 'customers',
      source: 'snowflake',
      sourceType: 'database',
      observer: 'obsv32',
      alertConfiguration: 'Confidence Based Alerts',
      profileStartTime: new Date('2022-06-01T00:00:00Z'),
      thresholdAlertMetrics: [
        {
          metricType: 'VALUE_MIN',
          metricName: 'Minimum Value',
          metricDetails: [
            {
              currentMetric: '130',
              comparisonMetric: '10',
              alertLevel: 'CRITICAL',
              percentageChange: 99.0,
              alertAgainst: 'MOVING_AVERAGE'
            }
          ]
        }
      ],
      confidenceAlertMetrics: [
        {
          metricType: 'VALUE_MIN',
          metricName: 'Minimum Value',
          metricDetails: [
            {
              currentMetric: '130',
              comparisonMetric: '10',
              alertLevel: 'CRITICAL',
              probability: 99.0,
              sampleKey: 'JPY'
            }
          ]
        }
      ]
    };

    mockAlertCount = [
      { category: 'Volume', warningCount: 10, crticalCount: 5, total: 15 },
      { category: 'Data Drift', warningCount: 20, crticalCount: 5, total: 25 }
    ];

    TestBed.configureTestingModule({
      declarations: [AlertsListingComponent],
      imports: [CommonModule, TranslocoModule, RouterTestingModule],
      providers: [{ provide: SecondaryNavItemsService, useValue: mockSecNav, PrimeNgDialogService }]
    });
    mockSecNav.getNavItems.and.returnValue(of([]));
    alertMockService = jasmine.createSpyObj('AlertService', [
      'getAlerts',
      'getAlertDetail',
      'getAlertsCount',
      'selectAlert',
      'getTotalAlertsCount'
    ]);

    mockObserverService = jasmine.createSpyObj('ObserverService', ['getObserverList']);
    dialogService = jasmine.createSpyObj('PrimeNgDialogService', ['open']);
    mockObserverService.getObserverList.and.returnValue(of(Mocks.MockObserverListModels));
    alertMockService.getAlerts.and.returnValue(of([mockAlert]));
    alertMockService.getAlertDetail.and.returnValue(of(mockAlert));
    alertMockService.getAlertsCount.and.returnValue(of(mockAlertCount));
    alertMockService.getTotalAlertsCount.and.returnValue(of({ count: 1 }));
    component = new AlertsListingComponent(
      mockSecNav,
      alertMockService,
      Spies.ToastrService,
      mockObserverService,
      Spies.TranslateService,
      dialogService,
      Spies.launchDarklyService,
      Spies.eventBusService,
      Spies.Router,
      Spies.ActivatedRoute
    );
    Spies.Router.url = 'http://localhost:4200/data-observability';
    component.ngOnInit();
  });

  beforeEach(() => {
    alertMockService = null;
    mockObserverService = null;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Alerts should be shown', () => {
    expect(component.showAlerts()).toBeTrue();
  });

  it('Alert Count should be accurate', () => {
    expect(component.getAlertCount('VOLUME')).toBe(15);
    expect(component.getAlertCount('DATA DRIFT')).toBe(25);
    expect(component.getAlertCount('VOLUME', 'WARNING')).toBe(10);
  });

  it('Alert Percent should be accurate', () => {
    expect(component.getAlertPercent('DATA DRIFT')).toBe(20);
  });

  it('Custom Sort should sort correctly', () => {
    mockEvent = { data: [mockAlert, mockAlert2], field: 'alertLevel', order: 1 };
    component.customSort(mockEvent);
    expect(mockEvent.data[0]).toBe(mockAlert);

    mockAlert2.alertLevel = 'CRITICAL';
    component.customSort(mockEvent);
    expect(mockEvent.data[0]).toBe(mockAlert);

    mockEvent.order = -1;
    component.customSort(mockEvent);
    expect(mockEvent.data[0]).toBe(mockAlert2);

    mockEvent = { data: [mockAlert, mockAlert2], field: 'alertType', order: 1 };
    component.customSort(mockEvent);
    expect(mockEvent.data[0]).toBe(mockAlert2);
  });

  it('Update Options should not throw error', () => {
    expect(component.updateOptions());
  });

  it('should not call getAlerts if alert count is zero', () => {
    let alertMockService = jasmine.createSpyObj('AlertService', ['getTotalAlertsCount', 'getAlerts']);
    alertMockService.getTotalAlertsCount.and.returnValue(of({ count: 0 }));
    expect(alertMockService.getAlerts).not.toHaveBeenCalled();
  });

  it('should show list of alerts related to observer', () => {
    Spies.Router.url =
      'http://localhost:4200/data-observability/observers/observer-detail/2c9c80877cb6daee017cb71851a00001/alerts';
    component.ngOnInit();
    expect(component.initialSetupLoading).toBe(false);
  });
});
