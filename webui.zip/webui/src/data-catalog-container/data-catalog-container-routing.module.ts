import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DataCatalogContainerComponent } from './data-catalog-container.component';

const routes: Routes = [
  {
    path: '',
    component: DataCatalogContainerComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DataCatalogContainerRoutingModule {}
