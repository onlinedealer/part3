import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DeleteCatalogSidebarComponent } from './delete-catalog-sidebar.component';
import { MockSidebarComponent } from '../../../../shared/components/sidebar/mock-sidebar.component.spec';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { CatalogApiService } from '../../shared/catalog-api.service';
import { of, throwError } from 'rxjs';

describe('DeleteCatalogSidebarComponent', () => {
  let component: DeleteCatalogSidebarComponent;
  let fixture: ComponentFixture<DeleteCatalogSidebarComponent>;
  let catalogApiService: CatalogApiService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } }],
      declarations: [DeleteCatalogSidebarComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteCatalogSidebarComponent);
    catalogApiService = TestBed.inject(CatalogApiService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the sidebar', () => {
    spyOn(component.sidebarComponent, 'open');
    component.open();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should close the sidebar when cancel button is clicked', () => {
    spyOn(component.sidebarComponent, 'close');
    component.onCancelButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should delete the catalog when delete button is clicked', () => {
    spyOn(component.sidebarComponent, 'close');
    spyOn(catalogApiService, 'deleteCatalog').and.returnValue(of({}));
    component.onPrimaryButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should show error when delete button is clicked and an error is returned from the API', () => {
    spyOn(component.sidebarComponent, 'close');
    spyOn(catalogApiService, 'deleteCatalog').and.returnValue(throwError({}));
    component.onPrimaryButtonClicked();
    expect(component.sidebarComponent.close).not.toHaveBeenCalled();
  });
});
