import { Component, Inject, OnInit, OnDestroy } from "@angular/core";
import { MAT_DIALOG_DATA, MatDialog, MatDialogRef } from "@angular/material/dialog";
import { TranslationsService } from "../../../../app/services/translations-service";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { Store } from "@ngrx/store";
import { SetRelayUsageSelectors, DeviceRelaysSelectors, MeteringPointsSelectors, MeterConnectionSelectors } from "../../../store/selectors";
import { Observable, Subscription } from "rxjs";
import { Relays } from "../../../models/relay.model";
import { SetRelayUsageActions } from "../../../store/actions";
// tslint:disable-next-line: max-line-length
import { SetRelayUsageDialogsComponent } from "../../../components/meteringpoint-devices/set-relay-usage-dialogs/set-relay-usage-dialogs.component";

@Component({
    selector: "landisgyr-set-relay-usage",
    templateUrl: "./set-relay-usage.component.html",
    styleUrls: ["./set-relay-usage.component.scss"]
})
export class SetRelayUsageComponent implements OnInit, OnDestroy {
    loading!: boolean | undefined;
    public data: any = null;
    meteringPointIdSub!: Subscription;
    deviceIdSub!: Subscription;
    meterConnectionIdSub!: Subscription;
    meteringPointId!: number | undefined;
    deviceId!: number | undefined;
    meterConnectionId!: number | undefined;
    error!: number;
    getLoadingValueSub!: Subscription;

    getUsageList$: Observable<string[]> = this.store.select(SetRelayUsageSelectors.getAllUsages);
    existingRelayTypes$: Observable<(string | undefined)[]> = this.store.select(DeviceRelaysSelectors.getSelectedMeteringPointRelayIds);
    existingRelayUsages$: Observable<(string | undefined)[]> = this.store.select(DeviceRelaysSelectors.getSelectedMeteringPointRelayUsage);
    getRelayTypesList$: Observable<any> = this.store.select(SetRelayUsageSelectors.getAllRelayTypesList);
    getSetRelayUsageErrorCodeValue$: Observable<number[]> = this.store.select(SetRelayUsageSelectors.getErrorCode);

    constructor(
        public dialog: MatDialog,
        private store: Store<MeteringPointsFeatureState>,
        public translations: TranslationsService,
        public dialogRef: MatDialogRef<SetRelayUsageDialogsComponent>,
        @Inject(MAT_DIALOG_DATA) data: any
    ) {
        this.data = data;
    }

    ngOnInit() {
        this.meteringPointIdSub = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointId).subscribe((data) => {
            this.meteringPointId = data;
        });
        this.deviceIdSub = this.store.select(MeterConnectionSelectors.getSelectedDeviceMeterId).subscribe((data) => {
            this.deviceId = data;
        });
        this.meterConnectionIdSub = this.store.select(MeterConnectionSelectors.getSelectedMeterConnectionId).subscribe((data) => {
            this.meterConnectionId = data;
        });
    }

    getLoadingValue(): void {
        this.getLoadingValueSub = this.store.select(SetRelayUsageSelectors.getLoadingState).subscribe((data) => {
            this.loading = data;
        });
    }

    statusOfRelayOperation(operation: string) {
        setTimeout(() => {
            this.getLoadingValue();
            if (this.loading === false) {
                this.dialog.closeAll();
            } else if (this.loading && (operation === "add" || operation === "edit")) {
                this.dialogRef.updateSize("600px", "430px");
            } else if (this.loading && operation === "delete") {
                this.dialogRef.updateSize("600px", "305px");
            }
        }, 500);
    }

    addRelayInformation(data: any): Relays {
        const relayType = data.controls.relayTypes.value.toString().split(" ");
        const addRelayData: Relays = {
            meteringPointId: this.meteringPointId,
            deviceMeterId: this.deviceId,
            meterConnectionId: this.meterConnectionId,
            relayNr: relayType[1] ? relayType[1] : 0,
            relayType: relayType[0],
            usage: data.controls.relayUages.value,
            reverted: data.controls.controlLogicType.value
        };
        return addRelayData;
    }

    editRelayInformation(data: any): Relays {
        const relayType = data.controls.relayTypes.value.toString().split(" ");
        const editRelayData: Relays = {
            relayId: this.data.relay.relayIdValue,
            relayType: relayType[0],
            usage: data.controls.relayUages.value,
            reverted: data.controls.controlLogicType.value
        };
        return editRelayData;
    }

    onAddClick(data: any) {
        const relay = this.addRelayInformation(data);
        if (data) {
            this.store.dispatch(SetRelayUsageActions.CreateRelayData({ relay }));
            this.statusOfRelayOperation(this.data.operation);
        }
    }

    onDeleteClick(relay: any) {
        this.store.dispatch(SetRelayUsageActions.DeleteRelayData({ relayId: this.data.relay.relayIdValue }));
        this.statusOfRelayOperation(this.data.operation);
    }

    onEditClick(data: any) {
        const relay = this.editRelayInformation(data);
        this.store.dispatch(SetRelayUsageActions.UpdateRelayData({ relay }));
        this.statusOfRelayOperation(this.data.operation);
    }

    ngOnDestroy() {
        if (this.meteringPointIdSub) {
            this.meteringPointIdSub.unsubscribe();
        }
        if (this.deviceIdSub) {
            this.deviceIdSub.unsubscribe();
        }
        if (this.meterConnectionIdSub) {
            this.meterConnectionIdSub.unsubscribe();
        }
        if (this.getLoadingValueSub) {
            this.getLoadingValueSub.unsubscribe();
        }
    }
}
