import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA, Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup, FormControl, FormGroupDirective, FormsModule, ReactiveFormsModule, ControlContainer } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { OrderbyascPipe } from '../../../../shared/pipes/dynamic-dropdown-sort.pipe';
import { Connection } from '../../../shared/connection';
import { Db2iFormComponent, DB2I_CONNECTION_PARAMETERS } from './db2i-form.component';
import { Server } from '../../../../servers/shared/server';
import { ServiceInjector } from '../../../../shared/services/service.injector';
import { MockConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component.spec';

describe('Db2iFormComponent', () => {
  let component: Db2iFormComponent;
  let fixture: ComponentFixture<Db2iFormComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  const runtimeServer = {
    id: '1',
    hostname: 'test'
  } as Server;

  class mockInjector {
    get() {
      return {};
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule, DropdownModule, CheckboxModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ],
      declarations: [Db2iFormComponent, OrderbyascPipe, MockConnectionCredentialsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    ServiceInjector.injector = new mockInjector();
    fixture = TestBed.createComponent(Db2iFormComponent);
    jasmine.getEnv().allowRespy(true);
    component = fixture.componentInstance;
    component.selectedRuntimeServer = runtimeServer;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should enable IASP values if IASP equals YES', () => {
    component.enableIASPDropDownChange({ value: 'YES' });
    expect(component.db2iConnectionForm.get('iaspName').enabled).toBe(true);
    expect(component.db2iConnectionForm.get('rdbName').enabled).toBe(true);
  });

  it('should disable IASP values if IASP equals NO', () => {
    component.enableIASPDropDownChange({ value: 'NO' });
    expect(component.db2iConnectionForm.get('iaspName').enabled).toBe(false);
    expect(component.db2iConnectionForm.get('rdbName').enabled).toBe(false);
  });

  it('should enable database control if set to Remote', () => {
    component.remoteDatabase = 'test';
    component.databaseLocationDropDownChange({ value: 'REMOTE' });
    expect(component.db2iConnectionForm.get('database').enabled).toBe(true);
    expect(component.db2iConnectionForm.get('database').value).toBe('test');
  });

  it('should disable database control if not set to Remote', () => {
    component.selectedRuntimeServer = runtimeServer;
    component.databaseLocationDropDownChange({ value: 'RUNTIME' });
    expect(component.db2iConnectionForm.get('database').enabled).toBe(false);
  });

  describe('returning connnection object', () => {
    const dataConnection = {
      accessFromServer: { id: '1' },
      database: 'test',
      parameters: [
        { key: DB2I_CONNECTION_PARAMETERS.DB2_I_LIBRARY_INSTALLATION, value: 'SHARE' },
        { key: DB2I_CONNECTION_PARAMETERS.DB2_I_ENABLE_IASP, value: 'yes' },
        { key: DB2I_CONNECTION_PARAMETERS.DB2_I_IASP_NAME, value: 'iasp' },
        { key: DB2I_CONNECTION_PARAMETERS.DB2_I_RDB_NAME, value: 'rdb' }
      ]
    } as Connection;

    it('should return connection and set database if control is enabled', () => {
      component.selectedRuntimeServer = runtimeServer;
      component.connection = dataConnection;
      expect(component.db2iConnectionForm.get('database').value).toBe('test');
    });
  });

  it('should return connection', () => {
    component.db2iConnectionForm.patchValue({
      database: 'test',
      installationLibrary: 'test',
      enableIASP: 'NO',
      iaspName: '',
      rdbName: '',
      testUser: 'user',
      testPassword: 'pwd'
    });
    const connection: Connection = component.getConnection(true);
    expect(connection.database).toBe('test');
  });

  it('should return connection with IASP enabled', () => {
    component.db2iConnectionForm.patchValue({
      database: 'test',
      installationLibrary: 'test',
      enableIASP: 'YES',
      iaspName: 'myIASP',
      rdbName: 'myRDB',
      testUser: 'user',
      testPassword: 'pwd'
    });
    const connection: Connection = component.getConnection(false);
    expect(connection.parameters.find((parameter) => parameter.key === 'DB2_I_IASP_NAME').value).toBe('myIASP');
    expect(connection.parameters.find((parameter) => parameter.key === 'DB2_I_RDB_NAME').value).toBe('myRDB');
  });

  it('should set whether the password changed or not', () => {
    component.hasRdbNameChanged = false;
    component.iaspNameChanged({ target: { value: 'myIASP' } });
    expect(component.db2iConnectionForm.get('rdbName').value).toBe('myIASP');
    component.hasRdbNameChanged = true;
    component.iaspNameChanged({ target: { value: 'myIASP2' } });
    expect(component.db2iConnectionForm.get('rdbName').value).toBe('myIASP');
  });
});
