(function() {
    'use strict';

    fileuploader.controller("dashboardCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', dashboardCtrl]);

    function dashboardCtrl($scope, $ajaxFactory, $rootScope, uiRouters) {



        $scope.dropdownselect1 = $rootScope.dropdownselect;

        $scope.textoutput = "";
        $scope.uploadpreview = "";
        $scope.fetchpreviewData = "";
        $scope.inputPreview = false;


        // pdf related code
        // $scope.pdfUrl = './apps/pdf/DEP1.PDF';
        $scope.scroll = 0;
        //$scope.loading = 'loading';

        $scope.getNavStyle = function(scroll) {
            if (scroll > 100) return 'pdf-controls fixed';
            else return 'pdf-controls';
        };
        $scope.onError = function(error) {
            console.log(error);
        };
        $scope.onLoad = function() {
            $scope.loading = '';
        };
        $scope.onProgress = function(progress) {};

        $scope.selectedTemplate = $rootScope.dropdownSelect;
        var dropdrop = $rootScope.selectedId;
        console.log(dropdrop)

        // Function to Preview the uploaded file
        $scope.fetchpreviewData = function() {
            var filename = $rootScope.textPdf;
            var valid = /(\.jpg|\.jpeg|\.png|\.PNG|\.TIFF|\.tiff|\.JPEG|\.JPG)$/i;
            console.log(valid.exec(filename))
            if (valid.exec(filename)) {
                var id = $rootScope.globalId;

                var url = "http://localhost:8080/ocr/rest/v1/service/get/tiffimage/tiff/file/" + id + "/filename/" + filename;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                console.log(url)
                promise.then(function(data) {
                    var outputimage = data;
                    var output = "data:image/tiff;base64," + outputimage.inputdata;
                    $scope.uploadpreview = output;
                    //console.log($scope.uploadpreview)
                });

                promise.catch(function(data) {
                    console.log('catch block executed', data);
                    return data;
                });
            } else {
                var id = $rootScope.globalId;
                var url = "http://localhost:8080/ocr/rest/v1/service/get/originalimage/file/" + id + "/filename/" + filename;
                console.log(url)
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                promise.then(function(data) {
                    // check whether you want data or url to display pdf in UI
                    $scope.pdfUrl = data;
                    $scope.pdfUrl = url;
                });

                promise.catch(function(data) {
                    console.log('catch block executed', data);
                    return data;
                });

            }

        };
        $scope.fetchpreviewData();


        $scope.fetchoutputData = function() {

            var id = $rootScope.globalId;

            var url = "http://localhost:8080/ocr/rest/v1/service/get/text/tiff/file/" + id;

            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            promise.then(function(d) {
                $scope.textoutput = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);

            });

        };

        $scope.fetchoutputData();

        $scope.exportdoc = function() {
            var template = $rootScope.templateapplied;
            console.log(template)
            $scope.getId = $rootScope.globalId;
            console.log($scope.getId)
            var id = $rootScope.globalId;
            if (template == 'Other') {
                var url = "http://localhost:8080/ocr/rest/v1/service/get/report/text/file/" + id;
                console.log(url)
                $scope.url = url;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                promise.then(function(d) {});
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });


            } else {
                var url = "http://localhost:8080/ocr/rest/v1/service/get/report/excel/file/" + id;
                console.log(url)
                $scope.url = url;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                promise.then(function(d) {});
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
            }
        };
    }
})();
