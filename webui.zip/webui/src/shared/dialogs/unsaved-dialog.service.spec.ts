import { LogManagerService } from '../log/log-manager.service';
import { UnsavedDialogService } from './unsaved-dialog.service';

describe('UnsavedDialogService', () => {
  let service: UnsavedDialogService;
  let modal: any;

  beforeEach(() => {
    service = new UnsavedDialogService({} as any, new LogManagerService());
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
