import { TestBed } from '@angular/core/testing';
import { Spies } from 'discovery-test';
import { ChartModule } from 'primeng/chart';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { HistogramChartComponent } from './histogram-chart.component';

describe('HistogramChartComponent', () => {
  let component: HistogramChartComponent;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [HistogramChartComponent],
      imports: [ChartModule]
    }).compileComponents();
  });
  beforeEach(() => {
    Spies.init();
    component = new HistogramChartComponent();
    component.data = {
      labels: [],
      datesets: [
        {
          data: [],
          backgroundColor: ProfilingConstants.FREQUENCYCHARTCOLORS[0],
          barPercentage: 0.97,
          categoryPercentage: 1,
          minBarLength: 2
        }
      ]
    };
    component.treePath = new TreePath();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with HistogsramStatistics', () => {
    component.statistics = {
      type: 'HistogramStatistics',
      frequency: {
        '111111.1111-1111110.1111': 8,
        '11111111.1111-11111111.1111': 1,
        '11111112.1111-11111112.1111': 1
      }
    } as any;
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.data.datasets[0].data[0]).toEqual(component.statistics['frequency']['111111.1111-1111110.1111']);
    expect(component.data.datasets[0].data[1]).toEqual(
      component.statistics['frequency']['11111111.1111-11111111.1111']
    );
    expect(component.data.datasets[0].data[2]).toEqual(
      component.statistics['frequency']['11111112.1111-11111112.1111']
    );
  });
});
