import { Injectable } from '@angular/core';
import { Router, Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { AjaxUtilityService } from '../utility/ajax-utility.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';

@Injectable()
export class GetCancellationInfoResolver implements Resolve<any> {

  constructor(private _ajax: AjaxUtilityService) { }

  resolve(route: ActivatedRouteSnapshot): Observable<any> | boolean {
    return this._ajax.sendRequest('carePassCancellation')
    .catch((err) => {
      // if service does not respond use the catch block
      return Observable.of({'status': 'Fail', 'statusCode': '404'});
    });
  }
}
