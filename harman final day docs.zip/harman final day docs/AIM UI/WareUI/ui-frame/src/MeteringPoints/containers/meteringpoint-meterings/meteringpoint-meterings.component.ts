import { Component, Input, OnDestroy, AfterViewInit } from "@angular/core";
import { FormControl } from "@angular/forms";
import { map } from "rxjs/operators";
import { Metering } from "../../models/metering.model";
import { MeteringDataChartActions, MeteringDataUIActions, MeteringsActions } from "../../store/actions";
import { MeteringPoint } from "../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../store/reducers";
import {
    MeteringsSelectors,
    MeteringRegisterSelectors,
    ProfileDataSelectors,
    PeriodicDataSelectors,
    RegistersSelectors
} from "../../store/selectors";
import { MeteringVO } from "../../models/view-objects/metering-vo.model";
import { Observable, Subscription } from "rxjs";
import { RouterSelectors } from "../../../app/store/selectors";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../app/services/translations-service";

@Component({
    selector: "landisgyr-meteringpoint-meterings",
    templateUrl: "./meteringpoint-meterings.component.html",
    styleUrls: ["./meteringpoint-meterings.component.scss"]
})
export class MeteringPointMeteringsComponent implements AfterViewInit, OnDestroy {
    allMeterings$: Observable<MeteringVO[]> = this.store.select(MeteringRegisterSelectors.getSelectedMeteringPointMeteringsVOsWithStates);

    pageLoading$: Observable<boolean> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);
    meteringsLoading$: Observable<boolean> = this.store.select(RegistersSelectors.getRegistersLoading);

    productComponentMeterings$: Observable<Metering[]> = this.store.select(
        MeteringsSelectors.getSelectedMeteringPointProductComponentMeterings
    );

    activeEnergyAndPowerMeterings$: Observable<MeteringVO[]> = this.allMeterings$.pipe(
        map((meterings) => meterings.filter(this.isActiveEnergyAndPower))
    );

    reactiveEnergAndPowerMeterings$: Observable<MeteringVO[]> = this.allMeterings$.pipe(
        map((meterings) => meterings.filter(this.isReactiveEnergyAndPower))
    );

    apparentEnergyAndPowerMeterings$: Observable<MeteringVO[]> = this.allMeterings$.pipe(
        map((meterings) => meterings.filter(this.isApparentEnergyAndPower))
    );

    multiEnergyMeterings$: Observable<MeteringVO[]> = this.allMeterings$.pipe(map((meterings) => meterings.filter(this.isMultiEnergy)));

    QOSMeterings$: Observable<MeteringVO[]> = this.allMeterings$.pipe(map((meterings) => meterings.filter(this.isQoSEnergy)));

    otherMeterings$: Observable<MeteringVO[]> = this.allMeterings$.pipe(map((meterings) => meterings.filter(this.isOther)));

    otherIsOnlyMeteringType$: Observable<boolean> = this.allMeterings$.pipe(
        map((meterings) => {
            if (meterings.length === meterings.filter(this.isOther).length) {
                return true;
            } else {
                return false;
            }
        })
    );
    showInactiveMeterings$ = this.store.select(MeteringsSelectors.getShowInactiveMeterings);

    // tslint:disable-next-line: max-line-length
    activeEnergyAndPowerMeteringsTitle = $localize`:|Title of active energy and power meterings@@ssMeterings.activeEnergyAndPowerMeteringsTitle:Active energy and power`;
    // tslint:disable-next-line: max-line-length
    reactiveEnergAndPowerMeteringsTitle = $localize`:|Title of reactive energy and power meterings@@ssMeterings.reactiveEnergAndPowerMeteringsTitle:Reactive energy and power`;
    // tslint:disable-next-line: max-line-length
    apparentEnergyAndPowerMeteringsTitle = $localize`:|Title of apparent energy and power meterings@@ssMeterings.apparentEnergyAndPowerMeteringsTitle:Apparent energy and power`;

    multiEnergyMeteringsTitle = $localize`:|Title of multi energy meterings@@ssMeterings.multiEnergyMeteringsTitle:Multi energy`;

    QOSMeteringsTitle = $localize`:|Title of QOS meterings@@ssMeterings.QOSMeteringsTitle:Quality of supply`;

    otherMeteringsTitle = $localize`:|Title of other meterings@@ssMeterings.otherMeteringsTitle:Other`;

    infoMessage: string = $localize`:|Title for the 'No meterings' -toast notification@@meterings.noMeteringsMessage:No meterings`;

    preDefinedSets: string = $localize`:|Title for predefined set section@@ssMeterings.preDefinedSets:Predefined sets`;

    selectedMetering$: Observable<Metering | undefined> = this.store.select(MeteringsSelectors.getSelectedMetering);

    inactiveMeteringToggleSubscription!: Subscription;

    inactiveMeteringToggle: FormControl = new FormControl(false);

    @Input()
    meteringPoint!: MeteringPoint;

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {
        this.inactiveMeteringToggleSubscription = this.showInactiveMeterings$.subscribe((showInactive) => {
            this.inactiveMeteringToggle.setValue(showInactive, { onlySelf: true, emitEvent: false });
        });
    }

    ngOnDestroy() {
        this.inactiveMeteringToggleSubscription.unsubscribe();
    }
    onSelectMetering(meteringPointMeteringIdAndType: { meteringPointId: number; meteringId: number; meteringType: string }) {
        this.store.dispatch(MeteringsActions.SelectMetering(meteringPointMeteringIdAndType));
    }

    isActiveEnergyAndPower(meterings: MeteringVO): boolean {
        return meterings.energyType === "ACTIVE_ENERGY_AND_POWER";
    }

    isReactiveEnergyAndPower(meterings: MeteringVO): boolean {
        return meterings.energyType === "REACTIVE_ENERGY_AND_POWER";
    }

    isApparentEnergyAndPower(meterings: MeteringVO): boolean {
        return meterings.energyType === "APPARENT_ENERGY_AND_POWER";
    }

    isMultiEnergy(meterings: MeteringVO): boolean {
        return meterings.energyType === "MULTI_ENERGY";
    }

    isQoSEnergy(meterings: MeteringVO): boolean {
        return meterings.energyType === "QOS_ENERGY";
    }

    isOther(meterings: MeteringVO): boolean {
        return meterings.energyType === "OTHER";
    }

    onChangeOfToggleButton(value: { source: any; checked: boolean }) {
        this.store.dispatch(MeteringsActions.SetShowInactive({ showInactive: value.checked }));
    }

    onProductComponentClicked(productComponentMeterings: Metering[]) {
        this.store.dispatch(
            MeteringDataChartActions.SelectProductComponentMeterings({ meteringPointId: this.meteringPoint.id, productComponentMeterings })
        );
    }

    ngAfterViewInit() {
        setTimeout(() => this.checkURLForSecondarySideview());
    }

    openMeteringDataSecondarySideview(
        meteringType: string,
        view: string,
        meteringPointId: string | undefined,
        meteringId: string | undefined
    ) {
        if (meteringPointId && meteringId) {
            this.store.dispatch(
                MeteringsActions.SelectMetering({
                    meteringPointId: Number(meteringPointId),
                    meteringId: Number(meteringId),
                    meteringType
                })
            );
        }

        if (view === "table" || view === "chart") {
            this.store.dispatch(MeteringDataUIActions.SetActiveView({ view }));
        }
    }

    checkURLForSecondarySideview() {
        this.store
            .select(RouterSelectors.getSegmentsWithParams)
            .subscribe((segmentsWithParams) => {
                const segments = segmentsWithParams.segments;
                const params = segmentsWithParams.params;
                const activeView = segmentsWithParams.segments[segmentsWithParams.segments.length - 1];
                const meteringPointId = params ? params.meteringPointId : undefined;
                const meteringId = params ? params.meteringId : undefined;

                if (segments.includes("profile")) {
                    this.openMeteringDataSecondarySideview("profile", activeView, meteringPointId, meteringId);
                } else if (segments.includes("periodic")) {
                    this.openMeteringDataSecondarySideview("periodic", activeView, meteringPointId, meteringId);
                }
            })
            .unsubscribe();
    }
}
