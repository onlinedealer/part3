import { Component, ChangeDetectionStrategy, OnInit } from "@angular/core";
import { Metering } from "../../../models/metering.model";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { MeteringPointsSelectors, MeteringsSelectors, MeteringDataUISelectors, ProfileDataSelectors } from "../../../store/selectors";
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../../app/services/translations-service";
import { MeteringDataUIActions, MeteringDataActions, MeteringsActions } from "../../../store/actions";

@Component({
    selector: "landisgyr-ss-metering",
    templateUrl: "./ss-metering.component.html",
    styleUrls: ["./ss-metering.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSMeteringComponent implements OnInit {
    activeView$: Observable<string> = this.store.select(MeteringDataUISelectors.getActiveView);
    metering$: Observable<Metering | undefined> = this.store.select(MeteringsSelectors.getSelectedMetering);
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    isProfileDataEdited$: Observable<boolean> = this.store.select(ProfileDataSelectors.getIsProfileDataEdited);
    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {}

    onActiveViewSelection(view: string) {
        this.store.dispatch(MeteringDataUIActions.SetActiveView({ view }));
    }

    ngOnInit() {
        this.store.dispatch(MeteringDataActions.CheckMeteringDataFetchingNeed());
    }

    openMeteringDataSecondarySideview(
        meteringType: string,
        view: string,
        meteringPointId: string | undefined,
        meteringId: string | undefined
    ) {
        if (meteringPointId && meteringId) {
            this.store.dispatch(
                MeteringsActions.SelectMetering({
                    meteringPointId: Number(meteringPointId),
                    meteringId: Number(meteringId),
                    meteringType
                })
            );
        }

        if (view === "table" || view === "chart") {
            this.store.dispatch(MeteringDataUIActions.SetActiveView({ view }));
        }
    }
}
