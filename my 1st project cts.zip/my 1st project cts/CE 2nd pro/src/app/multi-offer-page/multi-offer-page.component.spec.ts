import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MultiOfferPageComponent } from './multi-offer-page.component';

describe('MultiOfferPageComponent', () => {
  let component: MultiOfferPageComponent;
  let fixture: ComponentFixture<MultiOfferPageComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MultiOfferPageComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MultiOfferPageComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
