 (function() {
    'use strict';

    fileuploader.controller("viewTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$location', '$route', '$window', '$http', viewTemplateCtrl]);

    function viewTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, $location, $route, $http) {

        $scope.uploadPreviewTemplate = "";
        //$rootScope.globalListTempData = "";
        var rowData = $rootScope.globalTemplateD;
        console.log(rowData)
/*
        $scope.fetchpreviewData = function() {
            var id = rowData.tiffid;
            var url = "/ocr/rest/v1/service/get/tiffimageString/tiff/file/" + id;
            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
            $scope.getId = id;
            promise.then(function(data) {
                var outputimage = data;
                $scope.templateViewData = data;
                var output = "data:image/tiff;base64," + outputimage.inputdata;
                $scope.uploadPreviewTemplate = output;
                //$rootScope.globalImgPreview = $scope.uploadPreviewTemplate;
                //console.log($scope.uploadpreview)
            });
            promise.catch(function(data) {
                console.log('catch block executed', data);
                return data;
            });
        };
        $scope.fetchpreviewData();
*/

        $scope.fetchpreviewData = function() {
            //var rowData = $rootScope.globalTemplateUpResp;
            var id = rowData.tiffid;
            //var id = rowData.ORIGIONAL_ID;

            //console.log(id)
            var url = "/ocr/rest/v1/service/get/tiffimageconverted/tiff/file/" + id;
            ///ocr/rest/v1/service/get/tiffimage/tiff/file/
            //var url = "/ocr/rest/v1/service/get/tiffimage/tiff/file/" + id;
            //console.log(url)
            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            $scope.getId = id;
            promise.then(function(data) {
                //console.log(data)
                var outputimage = data;
                $scope.templateRespOnImg = data
                var output = "data:image/jpg;base64," + outputimage.inputdata;
                    //console.log(output)
                $scope.uploadPreviewTemplate = output;
                //console.log($scope.uploadPreviewTemplate)
                //$rootScope.globalImgPreview = $scope.uploadPreviewTemplate;
                //console.log($scope.uploadPreviewTemplate)
            });

            promise.catch(function(data) {
                console.log('catch block executed', data);
                return data;
            });
        };
        $scope.fetchpreviewData();

        $scope.dataOfRowFun = function() {
            var tempData = $rootScope.globalListTempData;
            for (var i = tempData.length - 1; i >= 0; i--) {
                var obj = tempData[i]
                if (obj._id == rowData._id) {
                    //obj = $scope.ViewImageArray;
                        $scope.ViewImageArray = obj;
                        var head = $scope.ViewImageArray;
                        $scope.ViewHeadData = head.headers;
                        console.log($scope.ViewHeadData)
                }
            }
        };
        $scope.dataOfRowFun();
        
        var dataOfRow = $rootScope.globalTemplateD;
        //var rows = [{"x":8,"y":167,"h":466,"w":68}];
        /*var dimenstions = $scope.templateViewData;
        console.log($scope.templateViewData)*/
        var rows = dataOfRow.rows;
        $(document).ready(function() {
            var d_canvas = document.getElementById('canvas');
            var context = d_canvas.getContext('2d');
            var background = document.getElementById('background');
            context.drawImage(background, 0, 0);

            for (var i = 0; i < rows.length; i++) {
                var x = (rows[i].x);
                var y = (rows[i].y);
                var h = (rows[i].h);
                var w = (rows[i].w);
                context.strokeRect(rows[i].x, rows[i].y, rows[i].h, rows[i].w);
            }

        });

    }

})();
