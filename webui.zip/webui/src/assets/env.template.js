(function (window) {
  window.env = window.env || {};

  // Environment variables
  window['env']['configUrl'] = '${CONFIG_SERVER_URL}';
  window['env']['metricsUrl'] = '${METRICS_URL}';
  window['env']['doConfigUrl'] = '${DO_CONFIG_URL}';
  window['env']['exportUrl'] = '${EXPORTEXCEL_URL}';
})(this);
