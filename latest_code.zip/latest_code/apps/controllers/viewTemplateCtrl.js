 (function() {
     'use strict';

     fileuploader.controller("viewTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$location', '$route', '$window', '$http', '$uibModal', viewTemplateCtrl]);

     function viewTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, $location, $route, $http, $uibModal) {

         $scope.uploadPreviewTemplate = "";
         $scope.viewImgRespData = "";
         var rowData = $rootScope.globalTemplateD;
         $rootScope.ImgWidth = "";
         $rootScope.ImgHeight = "";

         //function for calling image from server
         $scope.fetchpreviewData = function() {
             var id = rowData.origionalid;
             var url = "/ocr/rest/v1/service/get/tiffimageconverted/tiff/file/" + id;
             var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
             $scope.getId = id;
             promise.then(function(data) {
                 var outputimage = data;
                 $scope.templateRespOnImg = data
                 var output = "data:image/jpg;base64," + outputimage.inputdata;
                 $scope.uploadPreviewTemplate = output;
                 $rootScope.ImgWidth = outputimage.imagewidth;
                 $rootScope.ImgHeight = outputimage.imageheight;
                 console.log($scope.ImgHeight)
             });
             promise.catch(function(data) {
                 console.log('catch block executed', data);
                 return data;
             });
         };
         $scope.fetchpreviewData();

         $scope.dataOfRowFun = function() {
             var tempData = $rootScope.globalListTempData;
             for (var i = tempData.length - 1; i >= 0; i--) {
                 var obj = tempData[i]
                 if (obj._id == rowData._id) {
                     //obj = $scope.ViewImageArray;
                     $scope.ViewImageArray = obj;
                     var head = $scope.ViewImageArray;
                     $scope.ViewHeadData = head.headers;
                 }
             }
         };
         $scope.dataOfRowFun();

         //on click re-direct to the list of templates page
         $scope.backBtnFun = function() {
             $location.url(uiRouters.templateTable);
         };


         // function calling for deleting particular templates
         $scope.deleteTempFun = function() {

             var tempVar = $rootScope.globalTemplateD;
             var templateName = tempVar.templateName;
             var url = "/ocr/rest/v1/service/remove/template/" + templateName;
             var promise = $ajaxFactory.getDataFromServer(url, 'POST', {});
             promise.then(function(d) {
                 $rootScope.globalDelteTemp = d;
                 indicatorStop();
                 alert("Template Deleted Successfully")
                 $location.url(uiRouters.templateTable);
             });
             promise.catch(function(d) {
                 console.log('catch block executed', d);
                 return d;
             });
         };

         var dataOfRow = $rootScope.globalTemplateD;
         var width = $rootScope.ImgWidth;
         var height = $rootScope.ImgHeight;
         var rows = dataOfRow.rows;
         console.log(rows)

         $(document).ready(function() {
             var d_canvas = document.getElementById('canvas');
             var context = d_canvas.getContext('2d');
             var background = document.getElementById('background');
             context.drawImage(background, 0, 0);

             for (var i = 0; i < rows.length; i++) {
                 var x = ((rows[i].x) / 100) * 600;
                 var y = ((rows[i].y) / 100) * 700;
                 var h = ((rows[i].h) / 100) * 700;
                 var w = ((rows[i].w) / 100) * 600;
                 console.log(x, y, w, h)
                 context.strokeRect(x, y, h, w);
             }
         });
     };
     fileuploader.controller('ControllerDelete', ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$uibModalInstance', '$route', '$location', '$window', '$http', ControllerDelete]);

     function ControllerDelete($scope, $ajaxFactory, $rootScope, uiRouters, $uibModalInstance, $route, $location, $window, $http) {

         $scope.successMsgOfTempCreated = $rootScope.globalDelteTemp;
         $scope.clickFunForSuccess = function() {
             //$window.location.reload();
             $uibModalInstance.dismiss('cancel');
             $location.url(uiRouters.templateTable);
             //$window.location.reload();
         }
     }

 })();
