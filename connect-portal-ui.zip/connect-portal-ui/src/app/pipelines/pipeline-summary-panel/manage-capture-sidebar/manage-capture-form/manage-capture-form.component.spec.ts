import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { Component } from '@angular/core';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { ManageCaptureFormComponent } from './manage-capture-form.component';
import { TranslocoService, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { HttpClientModule } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ManageCaptureSidebarComponent } from '../manage-capture-sidebar.component';
import { DataFlowsEntity, PipelinesMonitoringStatus } from '../../../shared/pipelines-monitoring-status';

describe('ManageCaptureFormComponent', () => {
  let component: ManageCaptureFormComponent;
  let fixture: ComponentFixture<ManageCaptureFormComponent>;
  let translocoService: TranslocoService;

  @Component({
    selector: 'p-connect-manage-capture-sidebar',
    template: '',
    providers: [
      {
        provide: ManageCaptureSidebarComponent,
        useClass: MockManageCaptureSidebarComponent
      }
    ]
  })
  class MockManageCaptureSidebarComponent {
    open(): void {}
  }

  const mockPipelinesMonitoringStatus: PipelinesMonitoringStatus = {
    type: 'monitoringProjectStatus',
    projectId: '61ae6e1abfb2cd1777a98edd',
    id: '61ae6e1abfb2cd1777a98edd',
    changes: 'UP_TO_DATE',
    generationTimestamp: 1638824922,
    currentEmailRuntimeServer: '',
    dataFlows: [{ name: 'test', captureStatus: 'OK' } as DataFlowsEntity]
  };

  const mockSelectedPipeline: any = {
    projectId: '61ae6e1abfb2cd1777a98edd',
    backlogRows: {
      timestamp: 0,
      pendingTransactions: 0,
      pendingRows: 0
    },
    captureStatus: 'UNKNOWN',
    copyPhase: true,
    dataFlowType: 'COPY',
    logReaderStatus: 'NONE',
    name: 'test',
    overallStatus: 'OK',
    replicationStatus: 'OK',
    runtimeServerStatus: 'OK',
    runtimeServers: [
      {
        dataConnections: [
          {
            connectionType: 'KAFKA',
            logReaders: [],
            name: 'H11(2)',
            source: false,
            target: true
          },
          {
            connectionType: 'DB2I',
            logReaders: [],
            name: 'LTIAS08',
            source: true,
            target: false
          }
        ],
        hasChange: false,
        logReaderStatus: 'NONE',
        name: 'Docker',
        replicationStatus: 'OK',
        state: 'NONE',
        stats: {
          apply: {
            bytes: 0,
            lastReported: 1649892055,
            rows: 0,
            skippedRows: 0,
            transactions: 0
          },
          averageCaptureLatency: 0,
          captureLatency: 0,
          retrieve: {
            bytes: 0,
            lastReported: 1649892055,
            rows: 0,
            skippedRows: 0,
            transactions: 0
          },
          send: {
            bytes: 0,
            lastReported: 1649892055,
            rows: 0,
            skippedRows: 0,
            transactions: 0
          },
          statisticEstimationWindow: '0'
        },
        status: 'OK'
      }
    ],
    stats: {
      apply: {
        bytes: 0,
        lastReported: 1649892055,
        rows: 0,
        skippedRows: 0,
        transactions: 0
      },
      averageCaptureLatency: 0,
      captureLatency: 0,
      retrieve: {
        bytes: 0,
        lastReported: 1649892055,
        rows: 0,
        skippedRows: 0,
        transactions: 0
      },
      send: {
        bytes: 0,
        lastReported: 1649892055,
        rows: 0,
        skippedRows: 0,
        transactions: 0
      },
      statisticEstimationWindow: '0'
    },
    tableMappings: [
      {
        mappingDetails: [
          {
            captureStatus: 'ENABLED',
            source: {
              schema: 'GISJ01',
              table: 'CMINST800'
            },
            target: {
              schema: 'GISJ01',
              table: 'CMINST800'
            }
          },
          {
            captureStatus: 'DISABLED',
            source: {
              schema: 'GISJ01',
              table: 'LICENSES'
            },
            target: {
              schema: 'GISJ01',
              table: 'LICENSES'
            }
          },
          {
            captureStatus: 'DISABLED',
            source: {
              schema: 'GISJ01',
              table: 'OERUNCMD'
            },
            target: {
              schema: 'GISJ01',
              table: 'OERUNCMD'
            }
          },
          {
            captureStatus: 'ENABLED',
            source: {
              schema: 'GISJ02',
              table: 'LICENSES'
            },
            target: {
              schema: 'GISJ02',
              table: 'LICENSES'
            }
          },
          {
            captureStatus: 'DISABLED',
            source: {
              schema: 'GISJ02',
              table: 'LVJMPROP'
            },
            target: {
              schema: 'GISJ02',
              table: 'LVJMPROP'
            }
          },
          {
            captureStatus: 'ENABLED',
            source: {
              schema: 'GISLARDJ',
              table: 'TEST'
            },
            target: {
              schema: 'GISLARDJ',
              table: 'TEST'
            }
          }
        ],
        source: {
          connectionType: 'DB2I',
          name: 'LTIAS08'
        },
        target: {
          connectionType: 'KAFKA',
          name: 'H11(2)'
        }
      }
    ],
    source: {
      dataConnection: { name: 'IBM', connectionType: 'IBMI' }
    }
  };
  const mockSelectedPipelineSQL: any = {
    projectId: '61ae6e1abfb2cd1777a98edd',
    backlogRows: {
      timestamp: 0,
      pendingTransactions: 0,
      pendingRows: 0
    },
    captureStatus: 'UNKNOWN',
    copyPhase: true,
    dataFlowType: 'COPY',
    logReaderStatus: 'NONE',
    name: 'test',
    overallStatus: 'OK',
    replicationStatus: 'OK',
    runtimeServerStatus: 'OK',
    runtimeServers: [
      {
        dataConnections: [
          {
            connectionType: 'KAFKA',
            name: 'KFK',
            source: false,
            target: true
          },
          {
            connectionType: 'SQLSERVER',
            name: 'BOSTEST3',
            source: true,
            target: false
          }
        ],
        hasChange: false,
        logReaderStatus: 'NONE',
        name: 'Docker',
        replicationStatus: 'OK',
        state: 'NONE',
        stats: {
          apply: {
            bytes: 0,
            lastReported: 1649892055,
            rows: 0,
            skippedRows: 0,
            transactions: 0
          },
          averageCaptureLatency: 0,
          captureLatency: 0,
          retrieve: {
            bytes: 0,
            lastReported: 1649892055,
            rows: 0,
            skippedRows: 0,
            transactions: 0
          },
          send: {
            bytes: 0,
            lastReported: 1649892055,
            rows: 0,
            skippedRows: 0,
            transactions: 0
          },
          statisticEstimationWindow: '0'
        },
        status: 'OK'
      }
    ],
    stats: {
      apply: {
        bytes: 0,
        lastReported: 1649892055,
        rows: 0,
        skippedRows: 0,
        transactions: 0
      },
      averageCaptureLatency: 0,
      captureLatency: 0,
      retrieve: {
        bytes: 0,
        lastReported: 1649892055,
        rows: 0,
        skippedRows: 0,
        transactions: 0
      },
      send: {
        bytes: 0,
        lastReported: 1649892055,
        rows: 0,
        skippedRows: 0,
        transactions: 0
      },
      statisticEstimationWindow: '0'
    },
    tableMappings: [
      {
        mappingDetails: [
          {
            captureStatus: 'ENABLED',
            source: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable'
            },
            target: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable'
            }
          },
          {
            captureStatus: 'DISABLED',
            source: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_1'
            },
            target: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_1'
            }
          },
          {
            captureStatus: 'DISABLED',
            source: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_2'
            },
            target: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_2'
            }
          },
          {
            captureStatus: 'ENABLED',
            source: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_3'
            },
            target: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_3'
            }
          },
          {
            captureStatus: 'DISABLED',
            source: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_4'
            },
            target: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'NewTable_4'
            }
          },
          {
            captureStatus: 'ENABLED',
            source: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'TEST'
            },
            target: {
              catalog: 'DBHARSHA',
              schema: 'dbo',
              table: 'TEST'
            }
          }
        ],
        source: {
          connectionType: 'SQLSERVER',
          name: 'BOSTEST3'
        },
        target: {
          connectionType: 'KAFKA',
          name: 'KFK'
        }
      }
    ],
    source: {
      dataConnection: { name: 'BOSTEST3', connectionType: 'SQLSERVER' }
    }
  };
  const selectedRows = [
    {
      schema: 'GISJ01',
      table: 'CMINST800',
      captureStatus: 'ENABLED_PENDING',
      newStatus: ''
    },
    {
      schema: 'GISJ02',
      table: 'LVJMPROP',
      captureStatus: 'DISABLED_PENDING',
      newStatus: ''
    },
    {
      schema: 'GISLARDJ',
      table: 'TEST',
      captureStatus: 'ENABLED_PENDING',
      newStatus: ''
    }
  ];
  const selectedRowsSQL = [
    {
      database: 'DBHARSHA',
      schema: 'dbo',
      table: 'NewTable_3',
      captureStatus: 'ENABLED_PENDING',
      newStatus: ''
    },
    {
      database: 'DBHARSHA',
      schema: 'dbo',
      table: 'NewTable_2',
      captureStatus: 'DISABLED_PENDING',
      newStatus: ''
    },
    {
      database: 'DBHARSHA',
      schema: 'dbo',
      table: 'TEST',
      captureStatus: 'ENABLED_PENDING',
      newStatus: ''
    }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ManageCaptureFormComponent, MockManageCaptureSidebarComponent],
      imports: [getTranslocoModule(), HttpClientTestingModule],
      providers: [HttpClientModule, { provide: TRANSLOCO_SCOPE, useValue: { scope: '' } }]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(ManageCaptureFormComponent);
    component = fixture.componentInstance;
    translocoService = TestBed.inject(TranslocoService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open and populate the table', fakeAsync(() => {
    component.open(mockSelectedPipeline);
    tick();
    fixture.whenStable().then(() => {
      expect(component.tableData.length).toBe(6);
      expect(component.dataConnection).toBe(mockSelectedPipeline.tableMappings[0].source.name);
      expect(component.pipelineName).toBe(mockSelectedPipeline.name);
    });
  }));

  it('should open and populate the table for SQLServer', fakeAsync(() => {
    component.open(mockSelectedPipelineSQL);
    tick();
    fixture.whenStable().then(() => {
      expect(component.tableData.length).toBe(6);
      expect(component.dataConnection).toBe(mockSelectedPipelineSQL.tableMappings[0].source.name);
      expect(component.pipelineName).toBe(mockSelectedPipelineSQL.name);
    });
  }));

  it('should disable the Enable Capture button', () => {
    component.open(mockSelectedPipelineSQL);
    component.selectedRows = [];
    expect(component.isEnableCaptureButtonDisabled()).toBe(true);
    component.selectedRows = [selectedRowsSQL[0]];
    expect(component.isEnableCaptureButtonDisabled()).toBe(true);
    const selectedPipeline = { ...mockSelectedPipelineSQL };
    selectedPipeline.replicationStatus = 'IN_PROGRESS';
    component.open(selectedPipeline);
    component.selectedRows = selectedRowsSQL;
    expect(component.isEnableCaptureButtonDisabled()).toBe(true);
  });

  it('should enable the Enable Capture button', () => {
    const selectedPipeline = { ...mockSelectedPipeline };
    component.open(selectedPipeline);
    component.selectedRows = selectedRows;
    expect(component.isEnableCaptureButtonDisabled()).toBe(false);
    selectedPipeline.replicationStatus = 'STOPPED';
    component.open(selectedPipeline);
    component.selectedRows = selectedRows;
    expect(component.isEnableCaptureButtonDisabled()).toBe(false);
    selectedPipeline.replicationStatus = 'COMPLETED';
    component.open(selectedPipeline);
    component.selectedRows = selectedRows;
    expect(component.isEnableCaptureButtonDisabled()).toBe(false);
  });

  it('should disable the Disable Capture button', () => {
    component.open(mockSelectedPipeline);
    component.selectedRows = [];
    expect(component.isDisableCaptureButtonDisabled()).toBe(true);
    component.selectedRows = [selectedRows[1]];
    expect(component.isDisableCaptureButtonDisabled()).toBe(true);
    const selectedPipeline = { ...mockSelectedPipeline };
    selectedPipeline.replicationStatus = 'IN_PROGRESS';
    component.open(selectedPipeline);
    component.selectedRows = selectedRows;
    expect(component.isDisableCaptureButtonDisabled()).toBe(true);
  });

  it('should enable the Disable Capture button', () => {
    const selectedPipeline = { ...mockSelectedPipeline };
    component.open(selectedPipeline);
    component.selectedRows = selectedRows;
    expect(component.isDisableCaptureButtonDisabled()).toBe(false);
    selectedPipeline.replicationStatus = 'STOPPED';
    component.open(selectedPipeline);
    component.selectedRows = selectedRows;
    expect(component.isDisableCaptureButtonDisabled()).toBe(false);
    selectedPipeline.replicationStatus = 'COMPLETED';
    component.open(selectedPipeline);
    component.selectedRows = selectedRows;
    expect(component.isDisableCaptureButtonDisabled()).toBe(false);
  });

  it('should enable the selected tables when the Enable Capture button is clicked', fakeAsync(() => {
    component.open(mockSelectedPipeline);
    tick();
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    component.selectedRows = [selectedRows[1]];
    component.enableCaptureButtonClicked();
    expect(component.selectedRows.length).toBe(0);
    expect(component.tablesEnabled.length).toBe(1);
    expect(component.tablesDisabled.length).toBe(0);
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    expect(component.tablesEnabled).toEqual(['GISJ02.LVJMPROP']);
  }));

  it('should enable the selected tables when the Enable Capture button is clicked for SQLSERVER', fakeAsync(() => {
    component.open(mockSelectedPipelineSQL);
    tick();
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    component.selectedRows = [selectedRowsSQL[1]];
    component.enableCaptureButtonClicked();
    expect(component.selectedRows.length).toBe(0);
    expect(component.tablesEnabled.length).toBe(1);
    expect(component.tablesDisabled.length).toBe(0);
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    expect(component.tablesEnabled).toEqual(['DBHARSHA.dbo.NewTable_2']);
  }));

  it('should disable the selected tables when the Disable Capture button is clicked for SQLSERVER', fakeAsync(() => {
    component.open(mockSelectedPipelineSQL);
    tick();
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    component.selectedRows = [selectedRowsSQL[0]];
    component.disableCaptureButtonClicked();
    expect(component.selectedRows.length).toBe(0);
    expect(component.tablesEnabled.length).toBe(0);
    expect(component.tablesDisabled.length).toBe(1);
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    expect(component.tablesDisabled).toEqual(['DBHARSHA.dbo.NewTable_3']);
  }));

  it('should disable the selected tables when the Disable Capture button is clicked', fakeAsync(() => {
    component.open(mockSelectedPipeline);
    tick();
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    component.selectedRows = [selectedRows[0]];
    component.disableCaptureButtonClicked();
    expect(component.selectedRows.length).toBe(0);
    expect(component.tablesEnabled.length).toBe(0);
    expect(component.tablesDisabled.length).toBe(1);
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    expect(component.tablesDisabled).toEqual(['GISJ01.CMINST800']);
  }));

  it('should get the status icon', () => {
    let statusIcon = component.getCaptureStatusIcon('ATTENTION');
    expect(statusIcon).toEqual(['png-alert-attention-solid', 'text-warning']);
    statusIcon = component.getCaptureStatusIcon('ENABLED_PENDING');
    expect(statusIcon).toEqual(['png-alert-inprogress', 'text-success']);
    statusIcon = component.getCaptureStatusIcon('DISABLED_PENDING');
    expect(statusIcon).toEqual(['png-alert-inprogress', 'text-muted']);
    statusIcon = component.getCaptureStatusIcon('');
    expect(statusIcon).toEqual([]);
  });

  it('should filter the table when the selected schema changes', fakeAsync(() => {
    component.open(mockSelectedPipeline);
    tick();
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 6, enabledCount: 3, disabledCount: 3 });
    component.manageCaptureTableConfiguration.caption.dropdown.onDropdownChange({ label: 'GISJ01', value: 'GISJ01' });
    expect(component.selectedSchema.value).toBe('GISJ01');
    expect(component.manageCaptureTableConfiguration.caption.templateContext).toEqual({ totalCount: 3, enabledCount: 1, disabledCount: 2 });
  }));

  it('should filter the schemas when the filter is used', fakeAsync(() => {
    component.open(mockSelectedPipeline);
    tick();
    component.manageCaptureTableConfiguration.caption.dropdown.completeMethod({ query: 'GIS' });
    expect(component.manageCaptureTableConfiguration.caption.dropdown.options.length).toBe(3);
    component.manageCaptureTableConfiguration.caption.dropdown.completeMethod({ query: 'GISLARD' });
    expect(component.manageCaptureTableConfiguration.caption.dropdown.options.length).toBe(1);
  }));

  it('should select the checked rows', () => {
    const checkedItems = [{ schema: 'schema1', table: 'table1', captureStatus: 'ENABLED', compositeKey: 'schema1.table1' }];
    component.manageCaptureTableConfiguration.rowSelectionChangedEvent(checkedItems);
    expect(component.selectedRows).toEqual(checkedItems);
  });

  it('should get the status tooltip', () => {
    let tooltip = component.getCaptureStatusTooltip('ATTENTION');
    expect(tooltip).toEqual('pipelines.PIPELINE_STATUS.CAPTURE_STATUS_TOOLTIP.ATTENTION');
    tooltip = component.getCaptureStatusTooltip('ENABLED_PENDING');
    expect(tooltip).toEqual('pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TOOLTIP.ENABLED_PENDING');
    tooltip = component.getCaptureStatusTooltip('DISABLED_PENDING');
    expect(tooltip).toEqual('pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TOOLTIP.DISABLED_PENDING');
    tooltip = component.getCaptureStatusTooltip('ENABLED');
    expect(tooltip).toEqual('pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TOOLTIP.ENABLED');
    tooltip = component.getCaptureStatusTooltip('DISABLED');
    expect(tooltip).toEqual('pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TOOLTIP.DISABLED');
  });

  it('should get the status text', () => {
    let statusText = component.getCaptureStatusText('ATTENTION');
    expect(statusText).toEqual('pipelines.PIPELINE_STATUS.ATTENTION');
    statusText = component.getCaptureStatusText('ENABLED_PENDING');
    expect(statusText).toEqual('pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TEXT.ENABLED_PENDING');
    statusText = component.getCaptureStatusText('DISABLED_PENDING');
    expect(statusText).toEqual('pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TEXT.DISABLED_PENDING');
  });

  it('should enable the selected tables when the Enable Capture button is clicked', fakeAsync(() => {
    component.open(mockSelectedPipeline);
    tick();
    component.selectedRows = [selectedRows[1]];
    component.captureStatus = 'ACTION_REQUIRED';
    component.enableCaptureButtonClicked();
    expect(component.errorMessage).toBe('pipelines.SHARED.MANAGE_CAPTURE.MESSAGES.ERROR_DURING_CAPTURE');
    component.captureStatus = '';
    // TODO: need to check if project is stopped, currently the status API does not return project status
    /*component.overallStatus = 'STOPPED';
    component.enableCaptureButtonClicked();
    expect(component.errorMessage).toBe('pipelines.SHARED.MANAGE_CAPTURE.MESSAGES.PROJECT_IS_STOPPED');
    component.overallStatus = '';*/
    component.replicationStatus = 'IN_PROGRESS';
    component.enableCaptureButtonClicked();
    expect(component.errorMessage).toBe('pipelines.SHARED.MANAGE_CAPTURE.MESSAGES.REPLICATION_PROCESS_MUST_BE_STOPPED');
    component.replicationStatus = '';
    component.captureStatus = 'UNKNOWN';
    component.enableCaptureButtonClicked();
    expect(component.errorMessage).toBe('');
  }));
});
