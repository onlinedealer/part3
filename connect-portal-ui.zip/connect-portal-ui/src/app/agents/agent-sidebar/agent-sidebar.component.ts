import { AfterViewInit, ChangeDetectorRef, Component, EventEmitter, Input, OnDestroy, Output, ViewChild } from '@angular/core';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { BaseComponent } from '../../core/base.component';
import { SidebarButton } from '../../shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';
import { Agent } from '../shared/agent';
import { AgentsApiService } from '../shared/agents-api.service';
import { AgentFormComponent } from './agent-form/agent-form.component';

@Component({
  selector: 'p-connect-agent-sidebar',
  templateUrl: './agent-sidebar.component.html'
})
export class AgentSidebarComponent extends BaseComponent implements OnDestroy, AfterViewInit {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(AgentFormComponent) agentFormComponent: AgentFormComponent;

  @Input() isVisible: boolean;
  @Input() baseZIndex = 10000;

  @Output() isVisibleChanged = new EventEmitter<boolean>();
  @Output() agentSavedEvent = new EventEmitter();

  primaryButton: SidebarButton = {
    id: 'agentSaveButton',
    text: 'agents.AGENT_FORM.BUTTONS.SAVE'
  };

  cancelButton: SidebarButton = {
    id: 'agentCancelButton',
    text: 'agents.AGENT_FORM.BUTTONS.CANCEL'
  };

  formValueChangesSubscription: Subscription;

  constructor(private readonly agentsApiService: AgentsApiService, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }

  ngOnDestroy(): void {
    this.formValueChangesSubscription.unsubscribe();
  }

  ngAfterViewInit() {
    this.changeDetectorRef.detectChanges();
    this.formValueChangesSubscription = this.agentFormComponent.agentFormGroup.valueChanges.subscribe(() =>
      this.updateButtonDisabledState()
    );
  }

  cancelAgentButtonClicked(): void {
    this.isVisible = false;
    this.isVisibleChanged.emit(false);
    this.agentFormComponent.agentFormGroup.reset(this.agentFormComponent.initialFormGroupValue);
  }

  setAgent(agent: Agent): void {
    this.agentFormComponent.agentFormGroup.patchValue(agent);
  }

  saveAgentButtonClicked(): void {
    this.sidebarComponent.isProcessingRequest = true;

    this.agentsApiService
      .update(this.agentFormComponent.agentFormGroup.getRawValue())
      .pipe(first())
      .subscribe({
        next: () => {
          this.agentSavedEvent.emit();
          this.cancelAgentButtonClicked();
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  private updateButtonDisabledState(): void {
    this.primaryButton.isDisabled = !this.agentFormComponent.agentFormGroup.valid;
  }

  sideBarHidden($event: boolean) {
    this.isVisible = $event;
    this.isVisibleChanged.emit($event);
  }
}
