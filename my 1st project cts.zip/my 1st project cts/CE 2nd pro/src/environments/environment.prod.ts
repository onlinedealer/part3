export const environment = {
  production: true,
  apiKey: "a2ff75c6-2da7-4299-929d-d670d827ab4a",
  apiSecret: "a8df2d6e-b11c-4b73-8bd3-71afc2515dae",
  retailurl: "https://services.cvs.com/minuteClinic/retailWebContent?appName=CVS_WEB&channelName=WEB&contentType=BCC&deviceID=device12345&deviceToken=BLNK&deviceType=DESKTOP&lineOfBusiness=RETAIL&operationName=retailWebContent&serviceCORS=False&serviceName=webContent&version=1.0&apiKey=a2ff75c6-2da7-4299-929d-d670d827ab4a&apiSecret=a8df2d6e-b11c-4b73-8bd3-71afc2515dae&contentId=",
  env: 'prod',
  headerconfigurlMobile: "/retail/HeaderService?serviceName=HeaderService&operationName=getGlobalHeaders&version=2.0&xmlFormat=False&serviceCORS=False&appName=CVS_WEB&channelName=MOBILE&lineOfBusiness=RETAIL&deviceType=OTH_MOBILE&deviceToken=BLNK&apiKey=a2ff75c6-2da7-4299-929d-d670d827ab4a&apiSecret=a8df2d6e-b11c-4b73-8bd3-71afc2515dae&pageName=drstc",
  headerconfigurlDesktop: "/retail/HeaderService?serviceName=HeaderService&operationName=getGlobalHeaders&version=2.0&xmlFormat=False&serviceCORS=False&appName=CVS_WEB&channelName=WEB&lineOfBusiness=RETAIL&deviceType=DESKTOP&deviceToken=BLNK&apiKey=a2ff75c6-2da7-4299-929d-d670d827ab4a&apiSecret=a8df2d6e-b11c-4b73-8bd3-71afc2515dae&pageName=drstc",
  headerconfigurlMobileMultiOffer: "/assets/mock-services/headerService.json", 
  headerconfigurlDesktopMultiOffer: "/assets/mock-services/headerService.json", 
  imagePath : '/webcontent/ng-extracare/extracare_leanNg6/assets/images/',
  cvsHealthHost: 'https://services.cvshealth.com'
};
