




  /*angular.module('arm').controller('tabCtrl',
                                   ['$rootScope','$cordovaNetwork','$scope','authService','GENERAL_CONFIG','MASTER_TABLE','$ionicSideMenuDelegate', '$ionicActionSheet', '$timeout', tabCtrl]);

  function tabCtrl($rootScope,$cordovaNetwork,$scope,authService,GENERAL_CONFIG,MASTER_TABLE,$ionicSideMenuDelegate, $ionicActionSheet, $timeout) {
  */

  /*
 (function () {
  'use strict';
  angular.module('arm').controller('tabCtrl', function ($scope,$rootScope, $ionicActionSheet, $state,$timeout, $q, $ionicSideMenuDelegate,) {

        $scope.openMenu = function () {
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.otherUsers = [];
            authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.LoggedInAsUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var newObj = result.rows.item(i);
                    $scope.otherUsers.push(newObj);
                }
            })
   }
 });
})();
*/

(function () {
    'use strict';

    angular.module('arm').controller('tabCtrl', function ($scope, $rootScope, $ionicActionSheet, $state,$timeout, $q, $ionicSideMenuDelegate, authService, GENERAL_CONFIG, tabService, $cordovaDialogs) {


    $scope.otherUsers = [];
    $scope.openMenu = function () {
        // if (!$ionicSideMenuDelegate.isOpen()) {
        //     loadLoggodInAsUsers();
        // }else
        // {
        //     $scope.otherUsers = [];
        // }
        // $ionicSideMenuDelegate.toggleLeft();
    }


    function loadLoggodInAsUsers()
    {
            $scope.otherUsers = [];

                    authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.LoggedInAsUsers).then(function (result) {
                        for (var i = 0; i < result.rows.length; i++) {
                            var newObj = result.rows.item(i);
                            $scope.otherUsers.push({'UserName':'ABC'});
                        }

                    });
    }
    $scope.userGroups = [
        { userName: 'Maria David', id: 1,avatarIcon:'avatar.png', deg:'Manager (LOB)' },
        { userName: 'Alan Russo', id: 2,avatarIcon:'avatar.png', deg:'Sr. Manager (LOB)' },
        { userName: 'Ed Rony', id: 3,avatarIcon:'avatar.png', deg:'Director (LOB)' },
    ];


    $scope.selected = 0;
    $scope.activeUser = '';
    $scope.select= function(index, userName) {
       $scope.selected = index;
       $scope.activeUser = userName;
       $rootScope.newUser =  $scope.activeUser;
    };
    $rootScope.newUser = "Antony Lewis";
    $rootScope.$watch('newUser', function(newVal, oldVal) {
        if(newVal !== oldVal) {
            //console.log(newVal);
        }
    });

    $scope.goContactList = function(){
        $state.go('tab.contact');
    }

    $scope.goActivityList = function () {
        $state.go('tab.activity');
    }

    $scope.goDealList = function(){
        $state.go('tab.deal');
    }

    $scope.syncContacts = function(){
        $cordovaDialogs.confirm('Are you sure you want to copy the contacts to the phonebook ?', 'SalesARM', ['Yes','No'])
            .then(function(buttonIndex) {
                if(buttonIndex == 1){
                    tabService.sqlSelectContacts().then(function (result) {
                        for (var i = 0; i < result.rows.length; i++) {
                            tabService.sqlSelectCommunications(result.rows.item(i)).then(function (communicationres) {
                                function onSuccess(contact) {
                                    console.log("Save Success");
                                };

                                function onError(contactError) {
                                    console.log("Error = " + contactError.code);
                                };

                                function onSuccessFind(contacts) {
                                    console.log("Contacts Length"+contacts.length);
                                    if(contacts.length == 0){
                                        contact.save(onSuccess,onError);
                                    }
                                };

                                function onErrorFind(contactError) {
                                   console.log("Error = " + contactError.code);
                                };

                                // create a new contact object
                                var contact = navigator.contacts.create();
                                
                                // populate some fields
                                var name = new ContactName();
                                if(communicationres[0].ContactTypeID == 1){
                                    name.givenName = communicationres[0].FirstName;
                                    name.middleName = communicationres[0].MiddleName;
                                    name.familyName = communicationres[0].LastName;
                                    contact.name = name;
                                }else if(communicationres[0].ContactTypeID == 2){
                                    name.givenName = "";
                                    name.middleName = "";
                                    name.familyName = communicationres[0].CompanyName;
                                    contact.name = name;
                                }

                                var phoneNumbers = [];
                                var emailData = [];

                                var phoneNumberExist = "";
                                var emailIdExists = "";

                                for(var j=0; j<communicationres[1].rows.length; j++){
                                    if(communicationres[1].rows.item(j).CommunicationCategoryID == 1){
                                        phoneNumbers.push(new ContactField('mobile',communicationres[1].rows.item(j).CommunicationData, false));
                                        phoneNumberExist = communicationres[1].rows.item(j).CommunicationData;
                                    }else if(communicationres[1].rows.item(j).CommunicationCategoryID == 2){
                                        emailData.push(new ContactField('work',communicationres[1].rows.item(j).CommunicationData, false));
                                        emailIdExists = communicationres[1].rows.item(j).CommunicationData;
                                    }
                                    // save to device
                                    if(j == communicationres[1].rows.length-1){
                                        var options = new ContactFindOptions();
                                        if(phoneNumberExist != ""){
                                            options.filter = phoneNumberExist;
                                        }else if(emailIdExists != ""){
                                            options.filter = emailIdExists;
                                        }else{
                                            options.filter = "";
                                        }
                                        var fields = [navigator.contacts.fieldType.phoneNumbers, navigator.contacts.fieldType.emails];
                                        contact.phoneNumbers = phoneNumbers;
                                        contact.emails = emailData;

                                        navigator.contacts.find(fields, onSuccessFind, onErrorFind, options);
                                    }
                                }
                            });
                        }

                    });
                }
        });

    }

    $rootScope.user = $scope.activeUser;

        $scope.fntabmore = function (menuItem) {
            $ionicActionSheet.show({
                buttons: [
                { text: '<i class="icon icon-circle-xl icon-dashboard-circle"></i> Dashboard' },
                { text: '<i class="icon icon-circle-xl icon-products-circle"></i> Products' },
                //{ text: '<i class="icon icon-circle-xl icon-messages-circle"></i> Messages' },
                { text: '<i class="icon icon-circle-xl ion-calculator"></i> DBR Calculator' },
                { text: '<i class="icon icon-circle-xl ion-ios-calculator"></i>SME Banking Calculator' },
                { text: '<i class="icon icon-circle-xl icon-sync-circle"></i> Copy Contacts To PhoneBook' },
                { text: '<i class="icon icon-circle-xl ion-android-exit"></i> Logout' },
                /*{ text: '<i class="icon icon-circle-xl icon-plan-circle"></i> Help Me plan' },
                { text: '<i class="icon icon-circle-xl icon-note-circle"></i> Note' },
                { text: '<i class="icon icon-circle-xl icon-messages-circle"></i> Messages' },
                { text: '<i class="icon icon-circle-xl icon-search-circle"></i> Adv. Search' },
                { text: '<i class="icon icon-circle-xl icon-notification-circle"></i> Notification'},
                { text: '<i class="icon icon-circle-xl icon-settings-circle"></i> Settings' },*/
               
                /*{ text: '<i class="icon icon-circle-xl icon-help-circle"></i> Help' },*/
                /*{ text: '<i class="icon icon-circle-xl icon-dashboard-circle"></i> Reset all data' },
                { text: '<i class="icon icon-circle-xl icon-dashboard-circle"></i> Logout' }*/
                { text: '<i class="icon icon-circle-xl icon-messages-circle"></i> Messages' }
                ],

                destructiveText: '',
                titleText: '',
                cancelText: ' ',

                cancel: function () {
                    // add cancel code...
                },

                buttonClicked: function (index) { //Handle Respective Module Conditions

                        if (index === GENERAL_CONFIG.MoreMenuOptions.Dashboard) {
                            $state.go('tab.dashboardGraph', {
                                         });
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.Products) {
                           $state.go('tab.product', {
                           });
                        }else
                         if (index === GENERAL_CONFIG.MoreMenuOptions.Messages) {
                           $state.go('tab.conversationList', {
                           });
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.DBRCalculator) {
                          $state.go('tab.calculator', {
                           });
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.SMEBankingCalculator) {
                           $state.go('tab.smecalculator', {
                           });
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.Logout) {
                           $state.go('signin', {

                                     });
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.HelpMePlan) {
                           
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.Note) {
                           
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.AdvSearch) {
                          
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.Notification) {
                          
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.Settings) {
                           
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.Sync) {
                            $scope.syncContacts();
                           
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.Help) {
                          
                        }else
                        if (index === GENERAL_CONFIG.MoreMenuOptions.ResetAllData) {

                        }
                },

                destructiveButtonClicked: function () {
                    // add delete code..
                }

            });
            //
        }
    });

})();
