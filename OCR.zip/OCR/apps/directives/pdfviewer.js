(function() {
    'use strict';
    // Header
    fileuploader.directive('pdfviewer', ['uiRouters', pdfviewer]);

    function pdfviewer(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/viewpdf.html',
            
            
        }
    }
    
  
    
})();
