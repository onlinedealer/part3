import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import {
  ScheduleConfigModel,
  ScheduleWeeklyModel,
  ScheduleDailyModel,
  ScheduleOccurenceTypeEnum
} from 'discovery-core';
import {
  Helper,
  SharedConstants as ProfilingConstants,
  ValidationMessage,
  ValidationMessageTypeModel
} from 'discovery-shared';
import { TranslocoService } from '@ngneat/transloco';
@Component({
  selector: 'discovery-schedule',
  templateUrl: './schedule.component.html',
  styleUrls: ['./schedule.component.css']
})
export class ScheduleComponent implements OnInit {
  @Output() schedulerChange: EventEmitter<ScheduleConfigModel> = new EventEmitter<ScheduleConfigModel>();
  @ViewChild('scheduleForm') scheduleForm: NgForm;
  scheduleOccurenceType: ScheduleOccurenceTypeEnum;
  patterns: Array<{ name; value }> = [];
  dayList: Array<{ name; value }> = [];
  switchScheduler: boolean = false;
  scheduleDailyModel = new ScheduleDailyModel();
  scheduleWeeklyModel = new ScheduleWeeklyModel();
  isSubmitted: boolean = false;
  failureMessage: any[] = [];
  ValidationMessageType: ValidationMessageTypeModel;
  isEdit = false;
  watchedCount: number = 0;
  occurences = ProfilingConstants.OCCURENCES;
  profileConfig: any;

  private _scheduleEnabled: boolean;

  get scheduleEnabled(): boolean {
    return this._scheduleEnabled;
  }

  @Input()
  set scheduleEnabled(val: boolean) {
    this._scheduleEnabled = val;
    this.switchScheduler = this.scheduleEnabled ? true : false;
  }

  constructor(private translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.initialize();
  }
  onSubmit(): boolean {
    this.isSubmitted = true;
    if (this.scheduleForm.form.valid) {
      this.isSubmitted = false;
      this.updateSchedulerChange();
      return true;
    }
    return false;
  }
  toggleSchedule(): void {
    this.watchedCount++;
    this.failureMessage.length = 0;
    if (this.isEdit && !this.switchScheduler && !this.scheduleForm.form.valid) {
      this.loadScheduleSettings(this.profileConfig, true);
      this.switchScheduler = false;
      this.ValidationMessageType = ValidationMessageTypeModel.Warning;
      this.failureMessage = [
        new ValidationMessage(
          this.translocoService.translate('discoveryShared.scheduleProfile.errorMessages.warningInvalidData')
        )
      ];
    }
  }

  onTimeChanged(e): void {
    e.preventDefault();
    if (!this.isFormatValid(e.target.value, 'time')) {
      this.scheduleForm.form.controls.runAtTime?.setErrors({ invalidDate: true });
    } else {
      this.scheduleForm.form.controls.runAtTime?.setErrors(null);
    }
  }

  //To set time format in hh:mm for request
  setTimeFormat(inputTime: Date): Array<string> {
    let time: Array<string> = null;
    if (inputTime) {
      const date = new Date(inputTime);
      const timeFormat = Helper.getTimeFormat(date.getHours());
      const { hours, minutes } = Helper.getFormattedHrsAndMins(date);
      time = [hours, minutes, timeFormat];
    }
    return time;
  }
  //to check if date format is in valid format
  isFormatValid = (val: string, type: 'dateTime' | 'date' | 'time'): boolean => {
    const regex = ProfilingConstants.PROFILING_REGEX;
    return type === 'date' ? regex.DATE_FORMAT_REGEX.test(val) : regex.TIME_FORMAT_REGEX.test(val);
  };
  //fn call from its recent parent for EDIT mode
  loadScheduleSettings(profileConfigureModel, isEdit: boolean) {
    this.profileConfig = profileConfigureModel;
    this.isEdit = isEdit;
    this.watchedCount++;
    const scheduleConfig = profileConfigureModel.scheduleConfig;
    this.switchScheduler = scheduleConfig?.enabled;
    this.scheduleOccurenceType = scheduleConfig?.schedule?.occurence;
    let hrsAndMins = null;
    if (!Helper?.isEmpty(scheduleConfig?.schedule?.runAtTime)) {
      hrsAndMins = Helper?.convertUTCtoLocalTimezone(scheduleConfig?.schedule?.runAtTime);
    }
    const model = {
      daysOfWeek: scheduleConfig?.schedule?.daysOfWeek,
      runAtTime: hrsAndMins
    };
    if (scheduleConfig?.schedule?.occurence === this.occurences.WEEKLY) {
      this.scheduleWeeklyModel = new ScheduleWeeklyModel(model);
    } else {
      this.scheduleDailyModel = new ScheduleDailyModel(model);
    }
  }
  private initialize(): void {
    this.patterns = [
      { name: 'discoveryShared.scheduleProfile.daily', value: this.occurences.DAILY },
      { name: 'discoveryShared.scheduleProfile.weekly', value: this.occurences.WEEKLY }
    ];
    this.dayList = [
      { name: 'M', value: 'MON' },
      { name: 'T', value: 'TUE' },
      { name: 'W', value: 'WED' },
      { name: 'Th', value: 'THU' },
      { name: 'F', value: 'FRI' },
      { name: 'S', value: 'SAT' },
      { name: 'Su', value: 'SUN' }
    ];
    this.scheduleOccurenceType = this.patterns[0].value;
  }
  //to trigger the complete change for api request
  private updateSchedulerChange(): void {
    const scheduleData: ScheduleConfigModel = new ScheduleConfigModel(null);
    scheduleData.enabled = this.switchScheduler;
    if (this.watchedCount || this.scheduleEnabled) {
      let modelData;
      scheduleData.schedule.occurence = this.scheduleOccurenceType;
      if (this.scheduleOccurenceType === this.occurences.WEEKLY) {
        modelData = this.scheduleWeeklyModel;
      } else if (this.scheduleOccurenceType === this.occurences.DAILY) {
        modelData = this.scheduleDailyModel;
      }
      scheduleData.schedule.daysOfWeek = modelData?.daysOfWeek;
      scheduleData.schedule.timezone = Intl.DateTimeFormat().resolvedOptions().timeZone;
      const runAttime = this.setTimeFormat(modelData?.runAtTime);
      scheduleData.schedule.runAtTime = runAttime
        ? { hour: runAttime[0], minute: runAttime[1], meridiemIndicator: runAttime[2] }
        : { hour: null, minute: null, meridiemIndicator: null };
    }
    const scheduler: ScheduleConfigModel = new ScheduleConfigModel(scheduleData);
    this.schedulerChange.emit(scheduler);
  }
}
