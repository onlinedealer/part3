﻿(function () {

    angular.module('arm').factory('authInterceptorService',
        ['$q', 'localStorageService', 'MASTER_TABLE', '$injector','$rootScope','$cordovaDialogs','GENERAL_CONFIG','ALERT_MESSAGE', function ($q, localStorageService, MASTER_TABLE,$injector,$rootScope,$cordovaDialogs,GENERAL_CONFIG,ALERT_MESSAGE) {
            var authInterceptorServiceFactory = {};

            authInterceptorServiceFactory.request = function (config) {

                config.headers = config.headers || {};

                var lgnData = localStorageService.get(MASTER_TABLE.LoggedInUserInfo);
                if (lgnData) {
                    var authData = lgnData.Token;
                    if (authData) {
                        config.headers.Authorization = 'Bearer ' + authData.token;
                    }
                }

                return config;
            }

            authInterceptorServiceFactory.responseError = function (error, status, headers, config) {

                if (error.status == -1) {
                    $rootScope.httpErrorMessage = 'Local file not found';
                    return $q.reject(error);
                }
                if  (error.status === GENERAL_CONFIG.ServerStatusCode.Unauthorized) {                    
                    authInterceptorServiceFactory.verifyTokenValidity(error.data, status, headers, config);
                }else
                {
                    $rootScope.httpErrorMessage = error.data;
                    $cordovaDialogs.alert($rootScope.httpErrorMessage, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                            .then(function () {
                    });
                }
                return $q.reject(error);
            }

            authInterceptorServiceFactory.verifyTokenValidity = function(error, status, headers, config)
                {
                    $rootScope.httpErrorMessage = "Unauthorized";
                    /*var dcrptRes = authInterceptorServiceFactory.decrypt(error);
                    if(dcrptRes.results == null)
                    {   
                        $rootScope.httpErrorMessage = ALERT_MESSAGE.DECRYPTION_ERROR;
                        $cordovaDialogs.alert(ALERT_MESSAGE.DECRYPTION_ERROR, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                            .then(function () {
                        });
                        return;
                    } //111 112 106 110
                    //$rootScope.httpErrorMessage = dcrptRes.results.message*/
                    
                    
                    $rootScope.token = '';
                    $rootScope.loggedInUserID = 0;
                    $cordovaDialogs.alert($rootScope.httpErrorMessage, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                            .then(function () {
                    });
                    $injector.get('$state').go('signin');
                }
                
            //decrypt the data
                authInterceptorServiceFactory.decrypt = function (encryptedData) {
            
                    var key = CryptoJS.enc.Utf8.parse('AMINHAKEYTEM32NYTES1234567891234');
                    var iv = CryptoJS.enc.Utf8.parse('7061737323313233');

                    var decryptedText = null;
                    try {
                        var decrypted = CryptoJS.AES.decrypt(encryptedData.finalData, "a16byteslongkey!a16byteslongkey!", key,
                        {
                            keySize: 128,
                            iv: iv,
                            mode: CryptoJS.mode.CBC,
                            padding: CryptoJS.pad.Pkcs7
                        });
                        return angular.fromJson(decrypted.toString(CryptoJS.enc.Utf8));
                    }
                    catch (err) {
                        return "";
                    }
                }
            
            return authInterceptorServiceFactory;
    }]);

    angular.module('arm').config(['$httpProvider', function ($httpProvider) {
        $httpProvider.interceptors.push('authInterceptorService');
    }]);

})();