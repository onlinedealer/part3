import { TestBed } from '@angular/core/testing';

import { FirstTimeUserService } from './first-time-user.service';

describe('FirstTimeUserService', () => {
  let service: FirstTimeUserService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FirstTimeUserService);
  });

  it('show header be true', () => {
    service.showHeaderMenu(true);
    expect(service.showHeader).toBe(true);
  });
  it('show header to be false', () => {
    service.showHeaderMenu(false);
    expect(service.showHeader).toBe(false);
  });
});
