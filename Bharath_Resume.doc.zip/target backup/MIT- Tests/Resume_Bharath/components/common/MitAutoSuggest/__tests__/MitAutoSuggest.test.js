import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../../store/configureStore'
import MitAutoSuggest, { MitAutoSuggest as MitAutoSuggestComponent} from '../MitAutoSuggest'

describe('MIT AutoSuggest component', () => {
  let store, wrapper, props, wrapperBlock
  store = configureStore()
  props = {
    groupList: [[{
      'tcin': '21409248',
      'dpci': '907-30-0981',
      'barcode': '499073009810',
      'product_title': 'Bath Towel RED - Threshold',
      'attribute': 'cost',
      'old_value': [
        '5.0',
      ],
      'new_value': null,
      'vendor_id': '1166383',
      'vendor_name': 'DUMMY MASTER DOM1',
      'alternate_id': '521552370',
      'vos': '1',
    }]],
    getSuggestionCallback: jest.fn(),
    column_id: 'vendor_id',
    column_name: 'vendor Id',
    filter_name: 'Vendor',
    concatWith: 'vendor_name',
    clearField: 'No',
    id: 'loadLovs',
  }

  it('renders', () => {
    const div = document.createElement('div')
    shallow(
      <Provider store={store}>
        <MitAutoSuggest {...props} />
      </Provider>, div)
  })

  it('renders Elements', () => {
    wrapper = mount(
      <Provider store={store}>
        <MitAutoSuggest {...props} />
      </Provider>
    )
    expect(wrapper.find('Autosuggest').length).toEqual(1)
  })

  it('invoking getSuggestionValue calls getSuggestionCallback', () => {
    wrapperBlock = shallow(
      <MitAutoSuggestComponent
        {...props}
      />
    )
    wrapperBlock.instance().getSuggestionValue()
    expect(props.getSuggestionCallback.mock.calls.length).toEqual(1)
  })
})
