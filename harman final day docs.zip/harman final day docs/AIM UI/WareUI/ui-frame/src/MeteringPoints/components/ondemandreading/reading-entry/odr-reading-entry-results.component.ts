import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import {
    OnDemandReadingRequestSelectedVO,
    OnDemandReadingRequestResult,
    OnDemandReadingService,
    OnDemandReadingRequestType
} from "../../../models/ondemandreading.model";
import { TranslationsService } from "../../../../app/services/translations-service";
import * as _ from "lodash";
import { ProfileDataGroup } from "./profile-data-table/profile-data-table.component";
import { SorterService } from "../../../../Shared/services/sorter.service";
import { MeasuredUnit } from "../../../models/measuredunit.model";
import { OdrTypeTranslations } from "../../../translations/odr-type.translations";

@Component({
    selector: "landisgyr-ondemandreading-reading-entry-results",
    templateUrl: "./odr-reading-entry-results.component.html",
    styleUrls: ["./odr-reading-entry-results.component.scss"]
})
export class OnDemandReadingReadingEntryResultsComponent implements OnChanges {
    @Input()
    requestType!: string;

    @Input()
    onDemandReadingServices!: OnDemandReadingService[];
    @Input()
    selectedOnDemandReadingquest!: OnDemandReadingRequestSelectedVO;

    @Input()
    tableCaption!: string;
    @Input()
    navigateButtonTitle!: string;

    @Output()
    linkClick: EventEmitter<{
        requestType: string;
        meteringId: number | undefined;
        from: number | undefined;
        until: number | undefined;
    }> = new EventEmitter();

    defaultColumns: any[] = [];
    columnsWithoutMeteringName: any[] = [];
    _results: OnDemandReadingRequestResult[] = [];
    _resultGroups: ProfileDataGroup[] = [];
    _hasMultipleReadings = false;

    TABLE_COLUMN_TITLES: any = {
        metering: this.translations.getTranslation("Metering"),
        register: this.translations.getTranslation("Register"),
        value: this.translations.getTranslation("Value"),
        status: this.translations.getTranslation("Status"),
        valueEndTime: this.translations.getTranslation("End time"),

        feature: $localize`:|Table column title for reading results@@odrReadingEntryResults.feature:Feature`,

        measuredUnit: this.translations.getTranslation("Measurement unit"),

        phase: this.translations.getTranslation("Phase"),
        // tslint:disable-next-line: max-line-length
        cumulativeValue: $localize`:|Table column title for cumulativeValue (ReadPeriodicData)@@odrReadingEntryResults.cumulativeValue:Cumulative value`,
        valueWithUnit: this.translations.getTranslation("Value"),
        time: this.translations.getTranslation("Time"),
        description: this.translations.getTranslation("Description")
    };

    constructor(
        public translations: TranslationsService,
        private sorterService: SorterService,
        private odrTranslations: OdrTypeTranslations
    ) {}

    navigateToDetails() {
        const requestType = this.selectedOnDemandReadingquest.requestType;
        const meteringId = this.selectedOnDemandReadingquest.results[0].meteringId;
        const from = this.selectedOnDemandReadingquest.dates.valueStart;
        const until = this.selectedOnDemandReadingquest.dates.valueEnd;

        this.linkClick.emit({
            requestType,
            meteringId,
            from,
            until
        });
    }

    navigateToDetailsFromMultipleReadings(data: ProfileDataGroup) {
        const requestType = this.selectedOnDemandReadingquest.requestType;
        const meteringId = data && data.meterings.length > 0 ? data.meterings[0].meteringId : undefined;
        const from = this.selectedOnDemandReadingquest.dates.valueStart;
        const until = this.selectedOnDemandReadingquest.dates.valueEnd;

        if (requestType && meteringId && from && until) {
            this.linkClick.emit({
                requestType,
                meteringId,
                from,
                until
            });
        }
    }

    groupVisibilityChanges(group: ProfileDataGroup) {
        this._resultGroups = this._resultGroups.map((resultGroup) => {
            if (resultGroup.id !== group.id) {
                return resultGroup;
            }
            return group;
        });
    }
    ngOnChanges(changes: SimpleChanges) {
        this.defaultColumns = [
            { key: "name", header: this.TABLE_COLUMN_TITLES["metering"] },
            { key: "value", header: this.TABLE_COLUMN_TITLES["value"] },
            { key: "valueEndTime", header: this.TABLE_COLUMN_TITLES["valueEndTime"] }
        ];
        this.columnsWithoutMeteringName = [
            { key: "valueEndTime", header: this.TABLE_COLUMN_TITLES["valueEndTime"], forceSize: "135px" },
            { key: "value", header: this.TABLE_COLUMN_TITLES["value"], forceSize: "90px" },

            { key: "status", header: this.TABLE_COLUMN_TITLES["status"], useStatus: true, forceSize: "160px" }
        ];
        if (this.selectedOnDemandReadingquest) {
            const groupedResults: OnDemandReadingRequestResult[] = this.sorterService.sortByMeteringType(
                this.selectedOnDemandReadingquest.results,
                true
            );

            this._hasMultipleReadings = groupedResults.length > 1;
            const arrayToUse = Array.isArray(this.selectedOnDemandReadingquest.results[0])
                ? (this.selectedOnDemandReadingquest.results[0] as OnDemandReadingRequestResult[])
                : this.selectedOnDemandReadingquest.results;
            if (
                this.selectedOnDemandReadingquest.requestType !== OnDemandReadingRequestType.ReadPeriodicData &&
                this.selectedOnDemandReadingquest.requestType !== OnDemandReadingRequestType.ReadInstantaneousValue &&
                this.selectedOnDemandReadingquest.requestType !== OnDemandReadingRequestType.ReadTransformerRatio
            ) {
                this._results = this.sorterService.sortByValueTimes(arrayToUse).reverse();
            } else {
                this._results = this.sorterService.sortByName(arrayToUse);
                if (this.selectedOnDemandReadingquest.requestType === OnDemandReadingRequestType.ReadTransformerRatio) {
                    this._results[0] = {
                        ...this._results[0],
                        name: this.odrTranslations.getReadingTypeTranslation("ReadTransformerRatio")
                    };
                }
            }
            this._resultGroups = !this._hasMultipleReadings
                ? []
                : groupedResults.map((result, index) => {
                      const group: ProfileDataGroup = {
                          id: index,
                          name: result.name || "no name",
                          meterings: this._results
                              .filter((resultSet) => resultSet.name === result.name)
                              .map((metering) => this.removeMeasuredUnitFromName(metering, result.measuredUnit)),
                          groupIsVisible: index === 0,
                          groupIsCreated: index === 0,
                          linkTitle: $localize`:|@@odr.meteringDetailsViewLink:Metering view`,
                          dateRangeString: this.tableCaption,
                          meteringMeasuredUnitName: result.measuredUnit ? result.measuredUnit.name : ""
                      };
                      return group;
                  });
        }
    }

    private removeMeasuredUnitFromName(result: OnDemandReadingRequestResult, measuredUnit: MeasuredUnit | undefined) {
        if (!measuredUnit) {
            return result;
        }
        if (result.measuredUnit && result.value && result.value.toString().includes(measuredUnit.name)) {
            return {
                ...result,
                value: result.value.toString().replace(measuredUnit.name, "").trim()
            };
        }
        return result;
    }
}
