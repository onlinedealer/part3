(function() {
    'use strict';

    FirstApp.controller("dashboardCtrl", ['$scope', '$ajaxFactory', '$rootScope', dashboardCtrl]);

    function dashboardCtrl($scope, $ajaxFactory, $rootScope) {

 
    }


})();
