export class AddDatabase {
  dataConnectionId?: string;
  userDataBaseNames?: any;
  adminUserId?: string;
  adminUserPassword?: string;
}
