import { Component, Input, OnInit, Output, EventEmitter, ChangeDetectionStrategy, OnChanges, SimpleChanges } from "@angular/core";
import {
    OnDemandReading,
    OnDemandReadingRequestType,
    OnDemandReadingService,
    OnDemandReadingVO
} from "../../../models/ondemandreading.model";
import { OdrTypeTranslations } from "../../../translations/odr-type.translations";
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { DateFormats } from "../../../../Shared/services/date-format.service";
import { OnDemandReadingsSelectors } from "../../../store/selectors";
import { MeteringPointsFeatureState } from "../../../store/reducers";

@Component({
    selector: "landisgyr-ondemandreading-reading-entry",
    templateUrl: "./odr-reading-entry.component.html",
    styleUrls: ["./odr-reading-entry.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OnDemandReadingReadingEntryComponent implements OnInit, OnChanges {
    @Input()
    onDemandReadingRequest!: OnDemandReadingVO;
    @Input()
    onDemandReadingServices!: OnDemandReadingService[];
    @Input()
    dateFormat: DateFormats = DateFormats.DATETIME;
    @Output()
    selectEntry = new EventEmitter<OnDemandReading>();
    @Input()
    index!: number;

    resultLinkAvailable!: boolean;
    showDetailedError = false;
    requestTypeString: string | undefined;
    selectedOnDemandMultiReadingsStatus$: Observable<any | undefined> = this.store.select(
        OnDemandReadingsSelectors.getOnDemandMultiReadingsStatus
    );
    isScheduled = false;

    constructor(protected translations: OdrTypeTranslations, protected store: Store<MeteringPointsFeatureState>) {}

    ngOnInit() {
        if (this.onDemandReadingRequest) {
            this.requestTypeString = this.translations.getReadingTypeTranslation(this.onDemandReadingRequest.requestType);
            this.isScheduled = this.isScheduledRequest(this.onDemandReadingRequest);
        } else {
            this.requestTypeString = "";
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.onDemandReadingRequest !== undefined && this.onDemandReadingRequest.results !== undefined) {
            if (this.onDemandReadingRequest.requestType === OnDemandReadingRequestType.ReadEventData) {
                this.resultLinkAvailable =
                    this.onDemandReadingRequest.results[0] !== undefined &&
                    this.onDemandReadingRequest.results[0].events !== undefined &&
                    this.onDemandReadingRequest.results[0].events.length > 0;
            } else {
                this.resultLinkAvailable = this.onDemandReadingRequest.results.length > 0;
            }
        }
        if (this.onDemandReadingRequest && changes.onDemandReadingServices) {
            this.requestTypeString = this.translations.getReadingTypeTranslation(this.onDemandReadingRequest.requestType);
            this.isScheduled = this.isScheduledRequest(this.onDemandReadingRequest);
        }
    }
    onSelectEntry() {
        this.selectEntry.emit(this.onDemandReadingRequest);
    }

    private isScheduledRequest(onDemandReadingRequest: OnDemandReading): boolean {
        return (
            !!onDemandReadingRequest.requests &&
            onDemandReadingRequest.requests.length > 0 &&
            !!onDemandReadingRequest.requests[0] &&
            !!onDemandReadingRequest.requests[0].expectedReadingTime &&
            onDemandReadingRequest.requests[0].expectedReadingTime > 0
        );
    }
}
