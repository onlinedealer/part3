import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ComponentRef,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { BaseComponent } from '../../../core/base.component';
import { Server } from '../../../servers/shared/server';
import { ServersApiService } from '../../../servers/shared/servers-api.service';
import { DynamicHostDirective } from '@shared/directives/dynamic-host.directive';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { Connection } from '../../shared/connection';
import { Db2FormComponent } from './db2-connection-form/db2-form.component';
import { Db2iFormComponent } from './db2i-connection-form/db2i-form.component';
import { Db2zFormComponent } from './db2z-connection-form/db2z-form.component';
import { KafkaFormComponent } from './kafka-connection-form/kafka-form.component';
import { OracleFormComponent } from './oracle-connection-form/oracle-form.component';
import { SchemaRegistryFormComponent } from './schema-registry-form/schema-registry-form.component';
import { SqlServerFormComponent } from './sqlserver-connection-form/sqlserver-form.component';

/**
 * Form component that is used to capture information about a data connection
 */
@Component({
  selector: 'p-connect-connection-form',
  templateUrl: './connection-form.component.html',
  styleUrls: ['./connection-form.component.scss']
})
export class ConnectionFormComponent extends BaseComponent implements OnInit, OnChanges, AfterViewInit, OnDestroy {
  /**
   * List of supported connection types
   */
  @Input() connectionTypes: string[] = [];

  supportedConnectionTypes: { label: string; value: string }[] = [];

  /**
   * The main form group for the data connection
   */
  connectionFormGroup: FormGroup;

  /**
   * Subscriptions that are used in this component
   */
  subscriptions: Subscription[] = [];

  /**
   * The host directive that is a pointer to where we will add the child component
   */
  @ViewChild(DynamicHostDirective, { static: true })
  dynamicHostDirective: DynamicHostDirective;

  /**
   * Reference to the child connection form
   */
  childComponentReference: ComponentRef<any>;

  /**
   * Lookup that links the connection type to its corresponding component
   */
  connectionChildFormComponentList: { connectionType: string; component: any }[] = [
    { connectionType: 'ORACLE', component: OracleFormComponent },
    { connectionType: 'DB2I', component: Db2iFormComponent },
    { connectionType: 'DB2ZOS', component: Db2zFormComponent },
    { connectionType: 'KAFKA', component: KafkaFormComponent }
  ];

  /**
   * Controls the visibility of the server sidebar component, used to add a new server for the connection
   */
  isServerSidebarVisible = false;

  /**
   * List of Runtime Servers to display
   */
  runtimeServerDropdownList: { label: string; value: Server }[] = [];

  /**
   * Controls the visibility of the runtime server controls
   */
  // currently all connections display the controls
  isRuntimeServerVisible = true;

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly serversApiService: ServersApiService,
    private readonly featureFlagService: FeatureFlagService
  ) {
    super();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.connectionTypes) {
      this.updateConnectionTypeOptions();

      if (this.connectionFormGroup) {
        this.connectionFormGroup.get('connectionType').setValue(this.connectionTypes[0]);
      }
    }
  }

  ngOnInit(): void {
    this.checkForFeatureFlagsAndAddNewConnections();
    this.createFormGroup();
    this.updateConnectionTypeOptions();
    this.getRuntimeServersList();
    this.loadChildConnectionComponent();
    this.listenForConnectionTypeValueChanges();
  }

  checkForFeatureFlagsAndAddNewConnections() {
    if (this.featureFlagService.isFeatureEnabled('CDCKafkaSchemaRegistryTemp20220628')) {
      this.connectionChildFormComponentList.push({ connectionType: 'SCHEMAREGISTRY', component: SchemaRegistryFormComponent });
    }
    if (this.featureFlagService.isFeatureEnabled('CDCEnableDB2LUWTemp20220407')) {
      this.connectionChildFormComponentList.push({ connectionType: 'DB2', component: Db2FormComponent });
    }
    if (this.featureFlagService.isFeatureEnabled('CDCEnableSQLTemp20220407')) {
      this.connectionChildFormComponentList.push({ connectionType: 'SQLSERVER', component: SqlServerFormComponent });
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  getRuntimeServersList(id?: string) {
    this.serversApiService
      .getAll()
      .pipe(first())
      .subscribe({
        next: (servers: Server[]) => {
          this.runtimeServerDropdownList = servers
            .filter((server: Server) => server.serverType === 'REPLICATION')
            .map((server: Server) => ({ label: server.name, value: server }));

          if (id) {
            this.selectRuntimeServer(id);
          }
        }
      });
  }

  updateServerListAndSelectNewServer(server: { id: string }) {
    this.getRuntimeServersList(server.id);
  }

  /**
   * The data connection derived from the form control values
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting = true): Connection {
    const connection: Connection = this.childComponentReference.instance.getConnection(isTesting);
    connection.id = this.connectionFormGroup.get('id').value;
    connection.name = this.connectionFormGroup.get('name').value;
    connection.description = this.connectionFormGroup.get('description').value;
    connection.connectionType = this.connectionFormGroup.get('connectionType').value;
    connection.accessMethod = this.hasAccessMethods() ? this.connectionFormGroup.get('accessMethod').value : '';
    connection.accessFromServer = this.connectionFormGroup.get('runtimeServer').value;
    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   * @param connection the connection object
   */
  set connection(connection: Connection) {
    this.connectionFormGroup.patchValue({
      id: connection.id,
      name: connection.name,
      description: connection.description,
      connectionType: connection.connectionType
    });
    this.selectRuntimeServer(connection.accessFromServer.id);
    this.connectionFormGroup.get('connectionType').disable();

    setTimeout(() => {
      this.childComponentReference.instance.connection = connection;
    });
  }

  /**
   * Check to see if we need to display the access method
   */
  hasAccessMethods(): boolean {
    // as per UX requirement, we are just going to hide the controls for now
    // because they are not sure if it will be needed later on
    return false;
    // return (
    //  this.checkEnvironmentForAccessMethods(environment.supportedSourceConnectionTypes) ||
    //  this.checkEnvironmentForAccessMethods(environment.supportedTargetConnectionTypes)
    //);
  }

  /**
   * Updates labels on child forms following a successful test
   */
  updateTestValues(testResponse): void {
    if (testResponse.dbmsVersion) {
      this.connectionFormGroup.get('connectionDetails').patchValue({
        dbmsVersion: testResponse.dbmsVersion,
        driverVersion: testResponse.driverVersion,
        gmtOffset: testResponse.gmtOffset
      });
    }
  }

  /**
   * Called from the connection sidebar to re-initialise the form and child component after sidebar has previously been closed.
   */
  setupFormAndChildComponent() {
    this.createFormGroup();
    this.loadChildConnectionComponent();
    this.listenForConnectionTypeValueChanges();
  }

  /**
   * Updates the options in the connection type dropdown form control
   */
  private updateConnectionTypeOptions() {
    this.supportedConnectionTypes = this.connectionTypes.map((connection) => {
      return {
        label: `connections.CONNECTION_TYPES.${connection}`,
        value: connection
      };
    });
  }

  /**
   * Checks the environment settings for access methods for the connection type formcontrol value
   * @param environmentSetting connection settings in the enviroment.ts file
   * @returns true if connection type is found and has access methods
   */
  private checkEnvironmentForAccessMethods(environmentSetting): boolean {
    return (
      this.connectionFormGroup.get('connectionType') &&
      environmentSetting.some(
        (connectionSetting) =>
          connectionSetting.connectionType === this.connectionFormGroup.get('connectionType').value &&
          connectionSetting.accessMethods.length > 0
      )
    );
  }

  /**
   * Creates the main form group, child form controls are added to the connectionDetails group
   */
  private createFormGroup(): void {
    this.connectionFormGroup = this.formBuilder.group(
      {
        id: null,
        name: new FormControl('', Validators.required),
        description: new FormControl('', Validators.maxLength(500)),
        connectionType: new FormControl(this.connectionTypes[0]),
        accessMethod: 'JDBC',
        runtimeServer: new FormControl('', Validators.required),
        connectionDetails: this.formBuilder.group({})
      },
      {
        validators: [this.connectionNameValidator()],
        updateOn: 'blur'
      }
    );

    this.subscriptions.push(
      this.connectionFormGroup.valueChanges.subscribe(() => {
        this.changeDetectorRef.markForCheck();
      })
    );
  }

  /**
   * Validates the connection name
   * @returns an object containing the error or null
   */
  private connectionNameValidator() {
    return (formGroup: FormGroup) => {
      const nameControl = formGroup.get('name');
      if (!/^[-0-9a-zA-Z]*$/.test(nameControl.value)) {
        return { connectionNameIsInvalid: true };
      }
      return null;
    };
  }

  /**
   * Listen for changes on the connection type, when there is a change the new component is loaded
   */
  private listenForConnectionTypeValueChanges() {
    this.subscriptions.push(
      this.connectionFormGroup.get('connectionType').valueChanges.subscribe({
        next: () => {
          if (this.connectionFormGroup.get('connectionType').value) {
            this.loadChildConnectionComponent();
          }
        }
      })
    );
  }

  /**
   * Dynamically loads a component containing the connection type form
   */
  private loadChildConnectionComponent(): void {
    const viewContainerRef = this.dynamicHostDirective.viewContainerRef;
    viewContainerRef.clear();

    const connection = this.connectionFormGroup.get('connectionType').value;
    const childConnectionComponent = this.connectionChildFormComponentList.find((obj) => obj.connectionType === connection);

    if (childConnectionComponent) {
      if (this.runtimeServerDropdownList.length === 1) {
        // if there is only one runtime server, select it
        this.selectRuntimeServer(this.runtimeServerDropdownList[0].value.id);
      }
      this.childComponentReference = viewContainerRef.createComponent(childConnectionComponent.component);
    }
  }

  /**
   * Displays the server sidebar when a runtime server is added
   */
  addRuntimeServer(): void {
    this.isServerSidebarVisible = true;
  }

  /**
   * Event handler for when the runtime server changes
   */
  runtimeServerChanged(selectedRuntimeServer): void {
    setTimeout(() => {
      this.childComponentReference.instance.selectedRuntimeServer = selectedRuntimeServer;
    });
  }

  /**
   * Selects the runtime server that matches the given id
   */
  private selectRuntimeServer(id: string) {
    const selectedServer = this.runtimeServerDropdownList.find((server) => server.value.id === id).value;
    this.connectionFormGroup.patchValue({
      runtimeServer: selectedServer
    });
    this.runtimeServerChanged(selectedServer);
  }
}
