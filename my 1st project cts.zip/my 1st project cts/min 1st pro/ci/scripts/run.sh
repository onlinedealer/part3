#!/bin/bash
function parse_yaml {
   local prefix=$2
   local s='[[:space:]]*' w='[a-zA-Z0-9_]*' fs=$(echo @|tr @ '\034')
   sed -ne "s|^\($s\):|\1|" \
        -e "s|^\($s\)\($w\)$s:$s[\"']\(.*\)[\"']$s\$|\1$fs\2$fs\3|p" \
        -e "s|^\($s\)\($w\)$s:$s\(.*\)$s\$|\1$fs\2$fs\3|p"  $1 |
   awk -F$fs '{
      indent = length($1)/2;
      vname[indent] = $2;
      for (i in vname) {if (i > indent) {delete vname[i]}}
      if (length($3) > 0) {
         vn=""; for (i=0; i<indent; i++) {vn=(vn)(vname[i])("_")}
         printf("%s%s%s=\"%s\"\n", "'$prefix'",vn, $2, $3);
      }
   }'
}

cwd=$(pwd)
cwd_scripts="$(dirname "$0")"

###############################   defaults     ##############################
if [ ! -f $cwd'/'$cwd_scripts/build-settings.yaml ]; then
       echo -e 'Configurations file is missing/ \n'
    else
      echo -e 'Using configurations file at / \n'
      echo $cwd'/'$cwd_scripts/build-settings.yaml
      eval $(parse_yaml $cwd'/'$cwd_scripts'/build-settings.yaml')
fi


#########################################################################################
###############################     SEARCH AND REPLACE     ##############################
#########################################################################################
  if [ -z "$replace_wrongpath" ]; then
    echo -e ' Nothing to replace ...\n'
  else
    echo -e ' Search and replace path ...\n'
    echo -e "grep -rl $replace_wrongpath $cwd/build/deployment/dist | xargs sed -i '' -e 's/minuteclinic\/minuteclinic/minuteclinic/g'"
    if grep -rl $replace_wrongpath $cwd/build/deployment/dist | xargs sed -i '' -e 's/minuteclinic\/minuteclinic/minuteclinic/g'; then
      echo -e 'Done search and replace.\n'
    else
      echo -e 'Faild search and replace.\n' && grep -rl $replace_wrongpath $cwd/build/deployment/dist && echo -e
    fi
  fi

  echo -e "grep -rl 'href=\"favicon.ico\"' $cwd/build/deployment/dist | xargs sed -i '' -e 's/href=\"favicon.ico\"/href=\"/minuteclinic\/mcwebcontent\/ui\/dist\/favicon.ico\"/g'"
  if grep -rl 'href=\"favicon.ico\"' $cwd/build/deployment/dist | xargs sed -i '' -e 's/href=\"favicon.ico\"/href="\/minuteclinic\/mcwebcontent\/ui\/dist\/favicon.ico"/g'; then
    echo -e 'Done search and replacefavicon link.\n'
  else
    echo -e 'Faild search and replace favicon link.\n'
  fi

  # do the same on svn directory
  if [ -z "$replace_wrongpath" ]; then
    echo -e ' Nothing to replace ...\n'
  else
    echo -e ' Search and replace path ...\n'
    echo -e "grep -rl $replace_wrongpath $cwd/build/svn/dist | xargs sed -i '' -e 's/minuteclinic\/minuteclinic/minuteclinic/g'"
    if grep -rl $replace_wrongpath $cwd/build/svn/dist | xargs sed -i '' -e 's/minuteclinic\/minuteclinic/minuteclinic/g'; then
      echo -e 'Done search and replace.\n'
    else
      echo -e 'Faild search and replace.\n' && grep -rl $replace_wrongpath $cwd/build/deployment/dist && echo -e
    fi
  fi
