import { Component, ChangeDetectionStrategy, OnInit } from "@angular/core";
import { MatIconRegistry } from "@angular/material/icon";
import { DomSanitizer } from "@angular/platform-browser";

@Component({
    selector: "landisgyr-sidenav",
    templateUrl: "./sidenav.component.html",
    styleUrls: ["./sidenav.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SidenavComponent implements OnInit {
    constructor(private iconRegistry: MatIconRegistry, private sanitizer: DomSanitizer) {}

    ngOnInit() {
        this.iconRegistry.addSvgIcon(
            $localize`:|@@sidenav.meteringPoints:Metering points`,
            this.sanitizer.bypassSecurityTrustResourceUrl("assets/icons_sidenav/nav-icon-devices.svg")
        );
        this.iconRegistry.addSvgIcon(
            $localize`:|@@sidenav.tasks:Tasks`,
            this.sanitizer.bypassSecurityTrustResourceUrl("assets/icons_sidenav/nav-icon-devices.svg")
        );
    }
}
