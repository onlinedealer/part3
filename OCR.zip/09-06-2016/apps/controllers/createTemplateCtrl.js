(function() {
    'use strict';

    fileuploader.controller("createTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', createTemplateCtrl]);

    function createTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.rows = [];
        $scope.imageArray = [];
        $scope.tempArray = [];
        $scope.tempTemplateAreaName = [];
        $scope.jsonRowData = [];
        $scope.uploadPreviewTemplate = "";
        $scope.templateRespOnImg = "";

        $scope.fetchpreviewData = function() {
            var rowData = $rootScope.globalTemplateUpResp;
            var id = rowData.TIFF_ID;
            var url = "/ocr/rest/v1/service/get/tiffimageconverted/tiff/file/" + id;
            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            $scope.getId = id;
            promise.then(function(data) {
                var outputimage = data;
                $scope.templateRespOnImg = data
                var output = "data:image/jpg;base64," + outputimage.inputdata;
                $scope.width = outputimage.imagewidth;
                $scope.height = outputimage.imageheight;
                console.log($scope.width, $scope.height)
                $scope.uploadPreviewTemplate = output;
            });
            promise.catch(function(data) {
                console.log('catch block executed', data);
                return data;
            });
        };
        $scope.fetchpreviewData();

        $scope.addRow = function() {
            if ($scope.templateAreaName == null && $scope.custTemplateName == null) {
                alert("All Fields are Required")
            } else {
                for (var i = 0; i < $scope.tempArray.length; i++) {

                    $scope.imageArray.push($scope.tempArray[i]);
                    $scope.tempTemplateAreaName.push($scope.templateAreaName);
                }
                $scope.tempArray = [];
                $scope.templateAreaName = [];
                var tempAreaName = [];
                tempAreaName = $scope.templateAreaName;
            }
        };

        $scope.fileuploadPopUp = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: uiRouters.directivesHtmlPath + '/success.html',
                controller: 'InstanceControllerSuccess',
            });
        };

        $scope.saveTemplate = function(totalData) {
            indicatorStart("Creating Template....Please wait");
            var uploadDataInfo = $rootScope.globalTemplateUpResp;
            var tiffid = uploadDataInfo.ORIGIONAL_ID;
            var origionalid = uploadDataInfo.TIFF_ID;
            var obj = {};
            var d = new Date();
            var curr_day = d.getDate();
            var curr_month = d.getMonth();
            var curr_year = d.getFullYear();
            $scope.SaveTime = curr_year + "-" + curr_month + "-" + curr_day;
            var rowsDa = $scope.imageArray;
            obj['createdby'] = "Admin";
            obj['templateName'] = $scope.custTemplateName;
            obj['rows'] = rowsDa;   /*here i getting the "$$hashKey": "object:608" for every obj*/
            obj['headers'] = $scope.tempTemplateAreaName;
            obj['createdtime'] = $scope.SaveTime;
            obj['tiffid'] = tiffid;
            obj['origionalid'] = origionalid;
            obj['fileName'] = $rootScope.globalFileName;
            console.log(obj)
            var url = "/ocr/rest/v1/service/create/template";
            var promise = $ajaxFactory.getDataFromServer(url, 'POST', obj);
            promise.then(function(d) {
                $rootScope.globalDataofSuccessTemp = d;
                indicatorStop();
                $scope.fileuploadPopUp();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
        }

        $('#target').Jcrop({
            onSelect: showCords,
        });

        function showCords(c) {
            var obj = {};
            var width = $scope.width;
            var height = $scope.height;
            obj['x'] = ((c.x) / width) * 100;
            obj['y'] = ((c.y) / height) * 100;
            obj['h'] = ((c.w) / height) * 100;
            obj['w'] = ((c.h) / width) * 100;
            $scope.tempArray.push(obj);
            //console.log(obj)
            $scope.$apply(function() {

            });
        }
    };

    fileuploader.controller('InstanceControllerSuccess', ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$uibModalInstance', '$route', '$location', '$window', '$http', InstanceControllerSuccess]);

    function InstanceControllerSuccess($scope, $ajaxFactory, $rootScope, uiRouters, $uibModalInstance, $route, $location, $window, $http) {

        $scope.successMsgOfTempCreated = $rootScope.globalDataofSuccessTemp;
        $scope.clickFunForSuccess = function() {
            //$window.location.reload();
            $uibModalInstance.dismiss('cancel');
            $location.url(uiRouters.templateTable);
            //$window.location.reload();
        }
    }

})();
