import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';


@Component({
  selector: 'app-beauty-club',
  templateUrl: './beauty-club.component.html',
  styleUrls: ['./beauty-club.component.scss']
})
export class BeautyClubComponent implements OnInit {

  imagesPaths:Object = ImagePaths;

  @Input() data: any;

  constructor(public utilityService:UtilityService) { }

  ngOnInit() {
  }

}
