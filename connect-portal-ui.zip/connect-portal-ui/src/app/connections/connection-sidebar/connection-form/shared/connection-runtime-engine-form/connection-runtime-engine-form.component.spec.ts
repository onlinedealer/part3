import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { Server } from 'src/app/servers/shared/server';
import { OrderbyascPipe } from 'src/app/shared/pipes/dynamic-dropdown-sort.pipe';
import { ConnectionRuntimeEngineFormComponent } from './connection-runtime-engine-form.component';
import { ServiceInjector } from '../../../../../shared/services/service.injector';

describe('ConnectionRuntimeEngineFormComponent', () => {
  let component: ConnectionRuntimeEngineFormComponent;
  let fixture: ComponentFixture<ConnectionRuntimeEngineFormComponent>;
  const runtimeServer = {
    id: '1',
    hostname: 'test'
  } as Server;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  class mockInjector {
    get() {
      return {};
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule, DropdownModule, CheckboxModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ],
      declarations: [ConnectionRuntimeEngineFormComponent, OrderbyascPipe]
    }).compileComponents();
  });

  beforeEach(() => {
    ServiceInjector.injector = new mockInjector();
    fixture = TestBed.createComponent(ConnectionRuntimeEngineFormComponent);
    component = fixture.componentInstance;
    component.runtimeServerDropdownList = [{ label: 'test', value: runtimeServer }];
    fixture.detectChanges();
  });

  it('should not remove formgroup controls if the fomrgroup has not been defined', () => {
    component.removeChildFormControls(null);
    expect(true).toBeTruthy(); // no expectations necessary
  });

  it('should emit event when adding a server', () => {
    spyOn(component.addServerButtonClickedEvent, 'emit').and.returnValue(null);
    component.addRuntimeServer();
    expect(component.addServerButtonClickedEvent.emit).toHaveBeenCalled();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
