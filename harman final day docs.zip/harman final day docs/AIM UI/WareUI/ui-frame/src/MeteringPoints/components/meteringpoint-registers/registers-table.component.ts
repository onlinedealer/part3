import { Component, Input, ChangeDetectionStrategy, OnChanges, SimpleChanges } from "@angular/core";
import { RegisterVO } from "../../models/view-objects/register-vo.model";
import { slideCloseOpenAnimation } from "../../../Shared/Animations/slide-close-open.animation";
import { TranslationsService } from "../../../app/services/translations-service";
import { RegistersSorter } from "./registers-sorter";

@Component({
    selector: "landisgyr-registers-table",
    templateUrl: "./registers-table.component.html",
    styleUrls: ["./registers-table.component.scss"],
    animations: slideCloseOpenAnimation(),
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class RegistersTableComponent implements OnChanges {
    @Input()
    registers!: RegisterVO[];

    @Input() loading!: boolean;
    @Input() tableDataLoading!: boolean;
    @Input() refreshDataLoading!: boolean;

    contentOpen = "open";

    infoMessage = $localize`:|@@ssRegisters.noRegistersMessage:No registers`;

    registersSorter = new RegistersSorter();
    sortedRegisters$ = this.registersSorter.getSortedRegisters();

    ngOnChanges(changes: SimpleChanges) {
        this.registersSorter.setRegisters(this.registers);
    }

    toggleContent() {
        this.contentOpen = this.contentOpen === "open" ? "closed" : "open";
    }

    isCollapsed() {
        return this.contentOpen === "closed";
    }

    constructor(public translations: TranslationsService) {}
}
