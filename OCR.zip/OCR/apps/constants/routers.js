(function() {
    'use strict';
    fileuploader.constant('uiRouters', {
        filepath: 'apps/datafiles',
	
        directivesHtmlPath: 'apps/views',
        home: '/home/',
        dashboard: '/dashboard/',
        contests: '/contests',
    });
})();
