import { Component, ViewChild } from '@angular/core';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { LogReaderDetails } from '../../shared/pipelines-monitoring-status';
import { SidebarButton } from '../../../shared/components/sidebar/sidebar-button';
import { BaseComponent } from '../../../core/base.component';
import { LogReaderMessagesFormComponent } from './log-reader-messages-form/log-reader-messages-form.component';

@Component({
  selector: 'p-connect-log-reader-messages-sidebar',
  templateUrl: './log-reader-messages-sidebar.component.html',
  styleUrls: ['./log-reader-messages-sidebar.component.scss']
})
export class LogReaderMessagesSidebarComponent extends BaseComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(LogReaderMessagesFormComponent) logReaderMessagesFormComponent: LogReaderMessagesFormComponent;

  cancelButton: SidebarButton = {
    id: 'logReaderMessagesSidebarCancelButton',
    text: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.CLOSE'
  };

  constructor() {
    super();
  }

  /**
   * Open the log reader messages sidebar
   * @param pipelinesMonitoringStatus the data flow object
   * @param logReader an object containing the log reader name and the data connection name
   */
  open(pipelinesMonitoringStatus, logReader: LogReaderDetails, projectName?: string) {
    this.logReaderMessagesFormComponent.logReader = logReader;
    this.logReaderMessagesFormComponent.projectId = pipelinesMonitoringStatus.projectId;
    this.logReaderMessagesFormComponent.logReaderStatus = pipelinesMonitoringStatus.logReaderStatus;
    this.logReaderMessagesFormComponent.replicationStatus = pipelinesMonitoringStatus.replicationStatus;
    this.logReaderMessagesFormComponent.selectedRecentLogEntries = 50;
    this.logReaderMessagesFormComponent.getLogs();
    this.logReaderMessagesFormComponent.renderTable = false;
    this.logReaderMessagesFormComponent.projectName = projectName;
    setTimeout(() => {
      this.sidebarComponent.open();
      this.logReaderMessagesFormComponent.renderTable = true;
    });
  }

  handleServiceError(error) {
    this.sidebarComponent.parseHttpClientResponseMessage('error', error);
  }
}
