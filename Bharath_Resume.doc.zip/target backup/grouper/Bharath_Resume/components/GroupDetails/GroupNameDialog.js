import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Button from '@material-ui/core/Button'
import Grid from '@material-ui/core/Grid'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormHelperText from '@material-ui/core/FormHelperText'
import FormControl from '@material-ui/core/FormControl'
import * as Constants from '../common/Utils/Constants'
import CircularProgress from '@material-ui/core/CircularProgress'

const styles = theme => ({
  heading: {
    fontSize: 18,
    fontWeight: 500,
    paddingBottom: '16px',
  },
  helperText: {
    marginTop: 8,
  },
  formControl: {
    marginTop: 24,
    width: '100%',
  },
  field: {
    marginTop: 24,
    width: '100%',
  },
  textHead1: {
    fontSize: 13,
    fontWeight: 500,
  },
  textSmall: {
    fontSize: 11,
    fontWeight: 300,
    fontStyle: 'italic',
  },
  actionContainer: {
    padding: '24px 16px',
  },
  updateButtonStyle: {
    color: '#fff',
    float: 'right',
    background: '#1976d2',
    fontWeight: 300,
    marginLeft: 10,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  content: {
    /* minHeight: '490px', */
    overflowY: 'visible',
  },
  dialog: {
    width: '328px',
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
})
class GroupNameDialog extends React.Component {
  constructor (props) {
    super(props)

    this.state = {

      errorText: '',
      formData: {
        groupName: props.groupDetails.group_name,
      },
      errors: {

      },
    }
  }

  handleChange = name => event => {
    const formData = { ...this.state.formData }
    const errors = { ...this.state.errors }
    if (name === 'group_name') {
      if (!event.target.value) {
        formData.groupName = event.target.value
        errors.name = Constants.ERROR_GROUP_NAME_REQ
      } else if (event.target.value.length <= 150) {
        formData.groupName = event.target.value
        errors.name = ''
      } else {
        errors.name = Constants.GROUP_NAME_EXCEED_TEXT
      }
    }
    this.setState({ formData, errors })
  }

  validateSubmit = () => {
    const formData = { ...this.state.formData }
    const errors = { ...this.state.errors }
    const { groupDetails, auth } = this.props
    let payload = {}
    payload.group_name_updated = false
    payload.theme_updated = false
    let isValid = true
    if (!formData.groupName) {
      errors.name = Constants.ERROR_GROUP_NAME_REQ
      isValid = false
    } else {
      if (groupDetails.group_name !== formData.groupName) {
        payload.group_name_updated = true
      }
      payload.group_name = formData.groupName
      errors.name = ''
    }

    if (isValid && groupDetails && groupDetails.group_id) {
      payload.description = groupDetails.description
      payload.group_type = groupDetails.group_type
      payload.group_id = groupDetails.group_id
      payload.group_type_id = groupDetails.group_type_id
      payload.status = groupDetails.status
      payload.item_type_id = groupDetails.item_type_id
      payload.item_type = groupDetails.item_type
      payload.themes = groupDetails.themes
      payload.tcin_data = []
      payload.update_request_for_variation = true
      payload.collection_end_date = groupDetails.collection_end_date
      payload.launch_date = groupDetails.launch_date
      this.props.updateGroupName(payload, auth.memberOf, auth.lanId)
    } else {
      this.setState({ errors })
    }
  }

  changeGroupNameVariation = () => {
    this.props.updateVariationGroupName(this.state.formData.groupName)
  }

  render () {
    const { classes, closeDrawer, groupDetails, loadingBtnStatus } = this.props
    const { formData, errors } = this.state

    let saveDisableState = true
    if (groupDetails.group_name !== formData.groupName) {
      saveDisableState = false
    }
    let btnText = groupDetails.group_id ? 'Save' : 'Change'
    let btnClickEvent = groupDetails.group_id ? this.validateSubmit : this.changeGroupNameVariation
    return (
      <div>
        <Grid container>
          <Grid item xs={12}>
            <h4>Edit Product Title Group Name</h4>
          </Grid>
          <Grid item xs={12}>
            <FormControl className={classes.formControl} aria-describedby="name-helper-text">
              <InputLabel htmlFor="name-helper" required>Product Title/Group Name</InputLabel>
              <Input id="name-helper" value={formData.groupName} onChange={this.handleChange('group_name')} required />
              {(errors.name) ? <FormHelperText error className={classes.helperText}>{errors.name}</FormHelperText>
                : <FormHelperText id="name-helper-text">150 character max</FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12} className={classes.actionContainer}>
            <Button onClick={btnClickEvent} color="primary" className={classes.updateButtonStyle} disabled={saveDisableState}>
              {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Save') &&
                <CircularProgress
                  className={classes.progress}
                  size={25}
                />
              }
              {btnText}
            </Button>
            <Button onClick={closeDrawer} color="primary" className={classes.cancelButtonStyle} >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </div>
    )
  }
}

export default withStyles(styles)(GroupNameDialog)
