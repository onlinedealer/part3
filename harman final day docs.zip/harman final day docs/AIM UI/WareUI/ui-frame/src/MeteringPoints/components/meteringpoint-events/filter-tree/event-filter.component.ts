import { Component, Input, Output, EventEmitter } from "@angular/core";
import { ComponentPortal } from "@angular/cdk/portal";
import { EventFilterTreeComponent } from "./event-filter-tree.component";

@Component({
    selector: "landisgyr-event-filter",
    templateUrl: "./event-filter.component.html",
    styleUrls: ["./event-filter.component.scss"]
})
export class EventFilterComponent {
    @Output() closeFilter: EventEmitter<void> = new EventEmitter();
    @Input() showCategories!: boolean;
    eventsFilterTreePortal: ComponentPortal<EventFilterTreeComponent> = new ComponentPortal(EventFilterTreeComponent);
    constructor() {}
    closeTreeView() {
        this.closeFilter.emit();
    }
}
