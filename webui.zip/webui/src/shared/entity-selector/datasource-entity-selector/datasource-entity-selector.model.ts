import { EntityCardHeaderModel } from '../entity-card-header.model';

/** Model used by the Datasource Entity Selector */

export class DatasourceEntitySelectorModel {
  /**
   * list of column headers
   */
  headers: EntityCardHeaderModel[];

  /**
   * list of data objects
   */
  data: object[];

  /**
   * placeholder text for filter box
   */
  filterPlaceholder: string;

  /**
   * (optional) card header text
   */
  cardHeader?: string;

  /**
   * (optional) list of data objects to be checked
   */
  selectedData?: object[];

  /**
   * Helps in setting up the row selection type
   * When false, the row selection would be 'single'
   * and 'multiple' when true
   */
  enableSelection?: boolean;

  /**
   * list of field names for the filter box to work upon
   */
  filterFields?: string[];

  /**
   * key field name for data object list
   */
  keyField?: string;

  /**
   * to display/not display filter box
   */
  showFilter?: boolean;

  /**
   * to display the checkbox in table header for selecting all rows
   */
  showSelectAllCheckBox?: boolean;

  /**
   * to display the primeng tri-state checkbox
   */
  showTriState?: boolean;

  /**
   * enable checkbox selection feature
   */
  showCheckBox?: boolean;

  /**
   * enable row highlighting on hover
   */
  rowHover?: boolean;

  /**
   * enable table row-scrolling feature
   */
  scrollable?: boolean;

  /**
   * scroll height if row-scrolling is enabled
   */
  scrollHeight?: string;

  /**
   * enable virtual scroll
   */
  virtualScroll?: boolean;

  /**
   * row height in case virtual scroll is enabled
   */
  virtualRowHeight?: number;

  /**
   * number of rows
   */
  numOfRows?: number;

  /**
   * Message shown when the table has no data
   */
  noDataMessage?: string;

  /**
   * enable lazy loading
   */
  lazy?: boolean;

  /**
   * callback to return the value, if the data is currently being loaded
   */
  loadingFlag?(): boolean;

  /**
   * callback for lazy loading
   */
  lazyCallBack?(): any;

  /**
   * callback when a row is selected
   * @param selectedRow currently selected row
   */
  rowSelect?(selectedRow: object): void;

  /**
   * callback when a row is checked
   * @param checkedRow currently checked rows
   */
  rowCheck?(checkedRow: object): void;

  /**
   * callback when a row in un-checked
   * @param unCheckedRow
   */
  rowUnChecked?(unCheckedRow: object): void;

  /**
   * callback when all rows are selected
   * @param selectedRows
   */
  selectAllRows?(checked: boolean): void;

  /**
   * Constructor
   * @param headers list of data headers
   * @param data list of data objects
   * @param filterPlaceholder placeholder text for filter box
   */
  // eslint-disable-next-line @typescript-eslint/member-ordering
  constructor(headers: EntityCardHeaderModel[], data: object[], filterPlaceholder: string) {
    this.filterPlaceholder = filterPlaceholder;
    this.headers = headers;
    this.data = data;
  }
}
