<div width="100%" align="center">
    <h1>Connect Portal UI</h1>
    <p>
        <img height="120" width="120" class="img-fluid" role="none" src="./src/assets/images/Icon-Dark-Product-Connect-64.png">
    </p>
      <p>
    <a href="https://gitlab.com/preciselydata/data-integration/connect-portal-ui"><strong>preciselydata/data-integration/connect-portal-ui</strong></a>
    <br>
  </p>
    <p>        
    <a href="https://gitlab.com/preciselydata/data-integration/connect-portal-ui/-/jobs/artifacts/master/file/sources/ui/dist/connect-ui-doc/index.html?job=build">API Documentation</a>
    ·
    <a href="https://sonarqube/dashboard?id=connect-portal-ui">Code Analysis</a>
    ·
    <a href="https://precisely.app.blackduck.com/api/projects/3a631723-0de9-4894-b121-a500d2582420/versions/97401212-2875-4465-8b9f-70db356038f0/components?offset=0&limit=100&filter=bomReviewStatus%3Anot_reviewed&filter=securityRisk%3Acritical&filter=securityRisk%3Ahigh&filter=securityRisk%3Amedium&sort=projectName%20ASC">Blackduck</a>
    ·
    <a href="https://checkmarx.precisely.engineering/cxwebclient/portal#/projectState/21951/Summary">Checkmarx</a>
  </p>
  
</div>

#

The Connect Portal UI is a web application within the DI suite that provides the ability to create replication pipelines to move data between data sources.

## Installation

Before cloning and working with this repository you will need to setup your local environment to work with the connect-infra docker-compose file. Please refer to the setup instructions <a href="https://gitlab.com/preciselydata/data-integration/devops/connect-infra">here</a>.

You will also to need to have downloaded and setup Connect CDC. Please refer to this link https://docs.precisely.services/docs/sftw/disc/en/webhelp/DISuite/DataIntegration/ReplicationAgent/runtime-env-setup/c-download-a-rep-engine.html

## Running the project

Once the connect-infra docker setup is configured you can start the development server by running the following;

```shell
..\source\ui>npm run start
```

Once running you should be able to browse to the http://localhost:4202

Logging into the application is done through keycloak that is part of the connect-infra deployment.

<b>Note</b><br/>
As the development server runs on 4202 you will need to add this port to the keycloak server otherwise you will receive a redirect error.

<ol>
<li>browse to http://127.0.0.1:8080, username: admin, password: admin.</li>
<li>From the menu on the left, under configure, select Clients.</li>
<li>Click OIDC-Connect</li>
<li>Scroll down to the Valid Redirect URI section</li>
<li>Add and entry for http://localhost:4202/* and click save</li>
</ol>

## Testing the application

To run the unit tests and linting for the application you can run the following;

```shell
..\source\ui>npm run check
```

Tests are also ran when pushing changes to the repository.

## Documentation

Compodoc is a documentation generator for Angular projects. It is used to document all publicly available components, directive & services in the connect portal UI application/

Compodoc artifacts as part of our GitLab CI/CD pipeline. The latest documentation for the main branch can always be found here: <a href="https://gitlab.com/preciselydata/data-integration/connect-portal-ui/-/jobs/artifacts/master/file/sources/ui/dist/connect-ui-doc/index.html?job=build">API Documentation</a>

## Static Code Analysis

Sonarqube is used within the project to check for unit test code coverage, code smells as well as detecting known bugs. This is ran as part of the CI pipeline, results of which can be found <a href="https://sonarqube/dashboard?id=connect-portal-ui">here</a>.

## Security scans

The application uses blackduck and checkmarx to perform security scans of the code as part of the CI pipeline. The results for the blackduck scan can be found <a href="https://precisely.app.blackduck.com/api/projects/3a631723-0de9-4894-b121-a500d2582420/versions/97401212-2875-4465-8b9f-70db356038f0/components?offset=0&limit=100&filter=bomReviewStatus%3Anot_reviewed&filter=securityRisk%3Acritical&filter=securityRisk%3Ahigh&filter=securityRisk%3Amedium&sort=projectName%20ASC">here</a> and the checkmarx scan can be found <a href="https://checkmarx.precisely.engineering/cxwebclient/portal#/projectState/21951/Summary">here</a>.

## SLO of the service

SLO details [SLO](sli-slo.md).
