import { Component, Input, ElementRef } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { TranslationsService } from "../../../../../app/services/translations-service";

@Component({
    selector: "landisgyr-periodic-form",
    templateUrl: "./periodic-form.component.html",
    styleUrls: ["periodic-form.component.scss"]
})
export class ODROperationFormPeriodicComponent {
    @Input() parent!: FormGroup;
    @Input() show!: boolean;
    @Input() isDisabled!: boolean;
    ellipsisPresent = false;

    constructor(public elementRef: ElementRef, public translations: TranslationsService) {}

    checkEllipsis(value: any) {
        if (value.length > 19) {
            this.ellipsisPresent = true;
        } else {
            this.ellipsisPresent = false;
        }
    }
}
