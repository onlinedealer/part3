(function() {
    'use strict';

    fileuploader.controller("dashboardCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', dashboardCtrl]);

    function dashboardCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.dropdownselect1 = $rootScope.dropdownselect;
        $scope.textoutput = "";
        $scope.uploadpreview = "";
        $rootScope.globalImgPreview = $scope.uploadpreview;
        $scope.fetchpreviewData = "";
        $scope.inputPreview = false;
        $scope.fortextfile = false;
        $scope.forexcelfile = false;
        $scope.disablebtns = $rootScope.templateapp;
        $scope.UserName = $rootScope.globalUserName;

        $scope.buttonFun = function() {
            var Tdata = $rootScope.GlobalTdata;
            if (Tdata.template == 'GenerateText') {
                $scope.fortextfile = true;
                //$scope.forexcelfile = false;
            } else {

                $scope.forexcelfile = true;
                $scope.fortextfile = false;
            }
        };
        $scope.buttonFun();

        // pdf related code
        $scope.scroll = 0;
        //$scope.loading = 'loading';

        $scope.getNavStyle = function(scroll) {
            if (scroll > 100) return 'pdf-controls fixed';
            else return 'pdf-controls';
        };
        $scope.onError = function(error) {
            console.log(error);
        };
        $scope.onLoad = function() {
            $scope.loading = '';
        };
        $scope.onProgress = function(progress) {};

        $scope.selectedTemplate = $rootScope.dropdownSelect;
        var dropdrop = $rootScope.selectedId;
        console.log(dropdrop)

        // Function to Preview the uploaded file
        $scope.fetchpreviewData = function() {
            var filename = $rootScope.textPdf;
            $scope.templateontable = $rootScope.globaltabledata;
            var valid = /(\.jpg|\.jpeg|\.png|\.PNG|\.TIFF|\.tiff|\.JPEG|\.JPG)$/i;
            console.log(valid.exec(filename))
            if (valid.exec(filename)) {
                var id = $rootScope.originalid;
                $scope.inputPreview = true;

                var url = "/ocr/rest/v1/service/get/tiffimage/tiff/file/" + id;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                console.log(url)
                $scope.getId = id;
                promise.then(function(data) {
                    var outputimage = data;
                    var output = "data:image/tiff;base64," + outputimage.inputdata;
                    $scope.uploadpreview = output;
                    $rootScope.globalImgPreview = $scope.uploadpreview;
                    //console.log($scope.uploadpreview)
                });

                promise.catch(function(data) {
                    console.log('catch block executed', data);
                    return data;
                });
            } else {
                var id = $rootScope.originalid;
                var url = "/ocr/rest/v1/service/get/input/pdf/file/" + id;
                console.log(url)
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                promise.then(function(data) {
                    // check whether you want data or url to display pdf in UI
                    $scope.pdfUrl = data;
                    $scope.pdfUrl = url;
                });

                promise.catch(function(data) {
                    console.log('catch block executed', data);
                    return data;
                });
            }
        };
        $scope.fetchpreviewData();

        $scope.openLightboxModal = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: uiRouters.directivesHtmlPath + '/imgpopup.html',
                controller: 'ModalInstanceImgController',
            });
        };

        $scope.fetchoutputData = function() {

            var id = $rootScope.globalId;
            var url = "/ocr/rest/v1/service/get/text/tiff/file/" + id;
            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
            promise.then(function(d) {
                $scope.textoutput = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
            });
        };

        $scope.fetchoutputData();

        $scope.exportdoc = function() {
            var template = $rootScope.templateapplied;
            console.log(template)
            $scope.getId = $rootScope.globalId;
            console.log($scope.getId)
            var id = $rootScope.globalId;
            if (template == 'GenerateText') {
                //$scope.fortextfile = true;
                $scope.forexcelfile = false;
                var url = "/ocr/rest/v1/service/get/report/text/file/" + id;
                console.log(url)
                $scope.url = url;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                promise.then(function(d) {});
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
            } else {
                //$scope.forexcelfile = true;
                $scope.forexcelfile = true;
                var url = "/ocr/rest/v1/service/get/report/excel/file/" + id;
                console.log(url)
                $scope.url = url;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                promise.then(function(d) {});
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
            }
        };
    }

    fileuploader.controller('ModalInstanceImgController', ['$scope', '$rootScope', 'uiRouters', '$uibModalInstance', ModalInstanceImgController]);

    function ModalInstanceImgController($scope, $rootScope, uiRouters, $uibModalInstance) {

        $scope.uploadpreview = $rootScope.globalImgPreview;
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
    }
})();