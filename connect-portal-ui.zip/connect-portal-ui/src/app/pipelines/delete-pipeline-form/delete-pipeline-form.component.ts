import { Component, EventEmitter, Input, Output } from '@angular/core';

/**
 * Delete pipeline form
 * This is added to the content of the shared delete sidebar
 */
@Component({
  selector: 'p-connect-delete-pipeline-form',
  templateUrl: './delete-pipeline-form.component.html'
})
export class DeletePipelineFormComponent {
  /**
   * Selected pipeline
   */
  @Input() selectedPipeline: any;

  /**
   * Event emitted when the stop pipeline button is clicked
   */
  @Output() stopPipelineButtonClickEvent = new EventEmitter();

  /**
   * Event emitted when the manage capture button is clicked
   */
  @Output() manageCaptureButtonClickEvent = new EventEmitter();

  /**
   * Event emitted when the clear backlog button is clicked
   */
  @Output() clearBacklogButtonClickEvent = new EventEmitter();

  /**
   * Stop pipeline button clicked
   */
  stopPipelineButtonClicked() {
    this.stopPipelineButtonClickEvent.emit();
  }

  /**
   * Manage capture button clicked
   */
  manageCaptureButtonClicked() {
    this.manageCaptureButtonClickEvent.emit();
  }

  /**
   * Clear backlog button clicked
   */
  clearBacklogButtonClicked() {
    this.clearBacklogButtonClickEvent.emit();
  }
}
