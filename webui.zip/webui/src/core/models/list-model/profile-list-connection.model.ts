export class ProfileListConnectionModel {
  id: string;
  name: string;
  readonly: boolean;
  resourceConnectionType: string;
}
