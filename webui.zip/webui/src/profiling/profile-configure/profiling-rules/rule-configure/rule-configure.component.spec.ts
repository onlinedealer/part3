import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ProfileRuleOptionModel } from 'profiling/profile-rule-option.model';
import { ProfileRuleModel } from 'profiling/profile-rule.model';

import { RuleConfigureComponent } from './rule-configure.component';

describe('RuleConfigureComponent', () => {
  let component: RuleConfigureComponent;
  let fixture: ComponentFixture<RuleConfigureComponent>;

  beforeEach(() => {
    component = new RuleConfigureComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('test save profile rule configuration with single option having configured value of type string', () => {
    component.ruleModelForConfiguration = new ProfileRuleModel();
    component.ruleModelForConfiguration.ruleConfigurationOptions = [];
    const ruleConfigurationOption = new ProfileRuleOptionModel();
    ruleConfigurationOption.id = 'dummyId';

    component.ruleModelForConfiguration.ruleConfigurationOptions.push(ruleConfigurationOption);

    component.configuredOptionValues.set('dummyId', 'dummyConfiguredValue');
    spyOn(component.showRuleSettingsSideBarChange, 'emit');
    spyOn(component.ruleModelForConfigurationChange, 'emit');
    component.save();
    expect(component.ruleModelForConfiguration.ruleConfigurationOptions[0].configuredOptionValue).toEqual(
      'dummyConfiguredValue'
    );
    expect(component.showRuleSettingsSideBarChange.emit).toHaveBeenCalledWith(false);
    expect(component.ruleModelForConfigurationChange.emit).toHaveBeenCalled();
  });

  it('test cancel', () => {
    component.configuredOptionValues.set('dummyOptionId', 'dummyValue');
    spyOn(component.showRuleSettingsSideBarChange, 'emit');
    component.cancel();
    expect(component.configuredOptionValues.size).toEqual(0);
    expect(component.showRuleSettingsSideBarChange.emit).toHaveBeenCalledWith(false);
  });
});
