import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { SharedConstants } from './shared.constant';

@Injectable({ providedIn: 'root' })
export class ObserveFeatureFlagGuard implements CanActivate {
  constructor(private router: Router, private launchDarklyService: LaunchDarklyService) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.OBSERVER)
      ? true
      : this.router.parseUrl('/data-observability/invalid-account');
  }
}
