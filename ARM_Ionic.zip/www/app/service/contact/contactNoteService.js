(function() {
    'use strict';

    angular.module('arm').factory('contactNoteService', ['serviceApi', 'noteService', '$rootScope', '$filter', 'SERVICE_TYPE', 'sqliteService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', contactNoteService]);

    function contactNoteService(serviceApi, noteService, $rootScope, $filter, SERVICE_TYPE, sqliteService, utility, MASTER_TABLE, GENERAL_CONFIG) {

        var serArr = {};

        serArr.addContactNoteToServer = function(obj) {      
            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };
            var finalData = {
                "Data": [obj]
            };
            //console.log(finalData);
            return serviceApi.doPostWithData("NoteAddService",
                SERVICE_TYPE.CONTACTNOTE, finalData, headerconfig).then(function(response) {
                return response;
            });  
        }

        serArr.contactAdd = function() {
            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };
            var date = $filter('date')(new Date(), 'yyyy-MM-dd');
            //console.log(date);
            var contactGraphURL = SERVICE_TYPE.CONTACTGRAPH + '/' + $rootScope.loggedInUserID + '/' + "1" + "/" + "null" + "/" + date;
            console.log(contactGraphURL)
            return serviceApi.doGetWithoutData("contactAddService",
                contactGraphURL, headerconfig).then(function(response) {
                return response;
            }, function(err) {
                alert('web service error' + err);
            });
        }

        serArr.contactGraphFilterAdd = function(link) {
            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };
            var contactGraphURL = SERVICE_TYPE.CONTACTGRAPH + link;
            console.log(contactGraphURL)
            return serviceApi.doGetWithoutData("contactGraphFilterService",
                contactGraphURL, headerconfig).then(function(response) {
                return response;
            }, function(err) {
                alert('web service error' + err);
            });
        }

        serArr.addContactNoteToSql = function(objNote) { 
            var queryBindingsArr = [];
            var notesQuery = serArr.prepareNotesInsertQuery(objNote);
            var notesBinding = '';

            queryBindingsArr.push({
                'Query': notesQuery,
                'Bindings': notesBinding
            });
            return sqliteService.multipleQueries(queryBindingsArr).then(function(result) {}, function(error) {});
        }

        serArr.prepareNotesInsertQuery = function(objNote) {
            var queryVal = "('" + objNote.DeviceObjID + "','" + objNote.EntityID + "','" + objNote.ModuleID + "','" + objNote.NoteID + "','" + objNote.AddedFromSource + "','" + objNote.Description + "','" +
                objNote.ContactID + "','" + objNote.ContactObjID + "','" + objNote.CreatedBy + "','" + objNote.CreatedAt + "','" + objNote.EntityObjID + "','" + objNote.RepresentativeID + "','" + objNote.RepresentativeObjID + "'," + $rootScope.loggedInUserID + ")";

            var notesConcatenatedQuery = "INSERT INTO Notes (DeviceObjID, EntityID, ModuleID, NoteID, ParentDeviceObjID, Description, CreatorID, CreatorName, CreatedOn, CreatedAt, ModifiedBy, ModifiedOn, ModifiedAt,LoggedInUserID) VALUES" + queryVal;

            return notesConcatenatedQuery;
        };
        serArr.updateContactNotesQuery = function(objUpdateNote) {
            return sqliteService.query("UPDATE Notes SET NoteID = " + objUpdateNote.Data.NoteID +
                " WHERE DeviceObjID ='" + objUpdateNote.Data.DeviceObjID + "'").then(function(result) {
                return result;
            });
        };
        return serArr;
    }
})();
