(function () {
    'use strict';

    angular.module('arm').controller('activityHappenCntrl',
                    ['$rootScope', '$scope', '$state', '$stateParams', '$ionicPopup', '$ionicSideMenuDelegate', 'activityService', 'contactService', 'utility', 'GENERAL_CONFIG', 'MASTER_TABLE', 'ALERT_MESSAGE', '$filter', '$cordovaDialogs', 'noteService', activityHappenCntrl]);

    function activityHappenCntrl($rootScope, $scope, $state, $stateParams, $ionicPopup, $ionicSideMenuDelegate, activityService, contactService, utility, GENERAL_CONFIG, MASTER_TABLE, ALERT_MESSAGE, $filter, $cordovaDialogs, noteService) {

        var deviceObjID = $stateParams.devObjId;
        var actStatge = $stateParams.actStatgeType;
        var actScreenType = $stateParams.screenType;
        var actType = $stateParams.actType;

        $scope.statusArr = [];
        var checkCount = 0;
        var modelObj;

        //master date controls data
        $scope.actDates = [
            { Date: "6", Month: 'MAY', Year: '2016', Day: 'TODAY', Key: 'C' },
            { Date: "7", Month: 'MAY', Year: '2016', Day: 'TOMORROW', Key: 'M' },
            { Date: "13", Month: 'MAY', Year: '2016', Day: 'NEXT WEEK', Key: 'S' },
            { Date: "6", Month: 'JUNE', Year: '2016', Day: 'NEXT MONTH', Key: 'E' }
        ];

        function init() {
            $scope.actModel = [];
            var cmpModel = [];
            var indModel = [];
            modelObj = [];
            $scope.modelSelectedStage = '';
            if (actScreenType == GENERAL_CONFIG.ScreenType.ContactList || actScreenType == GENERAL_CONFIG.ScreenType.ContactDetail || actScreenType == GENERAL_CONFIG.ScreenType.HomeContact) {
                $scope.actModel = activityService.activityMod().uiObject;
                if (contactService.getSelectWhathappened() == contactService.constants().contactType.Individual) {
                    indModel = contactService.getSelectedIndividualContact();
                    if (indModel.IsRepresentative == false) {
                        $scope.actModel.EmployerID = indModel.EmployerID;
                        $scope.actModel.EmployerName = indModel.EmployerName;
                        $scope.actModel.ContactDisplayName = indModel.FirstName + ' ' + indModel.LastName;
                        $scope.actModel.CompanyName = $scope.actModel.EmployerName;
                        $scope.actModel.ContactName = $scope.actModel.ContactDisplayName;
                        $scope.actModel.ContactID = indModel.ContactID;
                        $scope.actModel.ContactTypeID = indModel.ContactTypeID;
                        $scope.actModel.OwnerID = indModel.OwnerID;
                        $scope.actModel.OwnerName = indModel.OwnerName;
                        $scope.actModel.ContactTierID = indModel.ContactTierID;
                        $scope.actModel.ContactTierName = indModel.ContactTierName;
                        $scope.actModel.ContactSegmentID = indModel.ContactSegmentID;
                        $scope.actModel.ContactSegmentName = indModel.ContactSegmentName;
                        $scope.actModel.ContactDeviceObjID = indModel.DeviceObjID;
                    }
                    else {
                        setCmpModel(cmpModel, indModel);
                    }
                }
                else {
                    setCmpModel(cmpModel, indModel);
                }
                loadActivityData();
            }
            else {
                modelObj = activityService.getActivity();
                if (modelObj.length > 0) {
                    $scope.actModel = angular.copy(modelObj[0]);
                }
                if (typeof modelObj === 'undefined') {
                    activityService.sqlGetCommnications($scope.activityDet.ContactDeviceObjID).then(function (result) {
                        $scope.actModel.ContactTierID = result.ContactTierID;
                        $scope.actModel.ContactTierName = result.ContactTierName;
                        $scope.actModel.ContactSegmentID = result.ContactSegmentID;
                        $scope.actModel.ContactSegmentName = result.ContactSegmentName;
                    });
                }
            }

            //$scope.actModel = angular.copy(utility.getObjData($scope.actList, 'DeviceObjID', activitiesId)[0]);
            $scope.actModel.Description = '';
            if (actStatge == 'D') {
                $scope.modelSelectedStage = GENERAL_CONFIG.ActivityStage.Done;
            }
            else {
                $scope.modelSelectedStage = GENERAL_CONFIG.ActivityStage.Cancel;
            }

            getCurrentLoc();
            if ($rootScope.previousState.name == 'tab.activityAdd') {
                $scope.actModel.Description = activityService.getActHappendVal();
            }
            else {
                activityService.setActHappendVal('');
            }

        }

        function setCmpModel(cmpModel, indModel) {
            cmpModel = contactService.getSelectedCompanyContact();
            indModel = contactService.getSelectedIndividualContact();
            $scope.actModel.RepresentativeID = indModel.ContactID;
            $scope.actModel.RepresentativeDeviceObjID = indModel.DeviceObjID;
            $scope.actModel.RepresentativeName = indModel.FirstName + ' ' + indModel.LastName;
            $scope.actModel.ContactDisplayName = indModel.FirstName + ' ' + indModel.LastName;
            $scope.actModel.CompanyName = cmpModel.CompanyName;
            $scope.actModel.ContactName = cmpModel.CompanyName;
            $scope.actModel.ContactID = cmpModel.ContactID;
            $scope.actModel.ContactTypeID = cmpModel.ContactTypeID;
            $scope.actModel.OwnerID = cmpModel.OwnerID;
            $scope.actModel.OwnerName = cmpModel.OwnerName;
            $scope.actModel.ContactTierID = cmpModel.ContactTierID;
            $scope.actModel.ContactTierName = cmpModel.ContactTierName;
            $scope.actModel.ContactSegmentID = cmpModel.ContactSegmentID;
            $scope.actModel.ContactSegmentName = cmpModel.ContactSegmentName;
            $scope.actModel.ContactDeviceObjID = cmpModel.DeviceObjID;
        }

        function loadActivityData() {
            loadActTypes();
            loadFields();
            //SetCalDate($scope.actDates[0]['Date'], $scope.actDates[0]['Month'], $scope.actDates[0]['Year']);
            //$scope.actModel.ActivityTime = $scope.actTimes[0]['Time'];
            $scope.actModel.ActivityDuration = $scope.actDurations[0]['Duration'];
            $scope.selDateAMPM = $scope.actTimes[0]['Meridiem'];
            $scope.actModel.Correspondences.DeviceObjID = utility.generateUUID();
            $scope.actModel.Correspondences.ModuleID = GENERAL_CONFIG.MODULES.Activity;
            $scope.actModel.IsActivityEvent = 0;//task
            //$scope.actModel.ActivityDuration == "0"
            loadCurDate()
            loadSubject();

        }

        function addZero(i) {
            if (i < 10) {
                i = "0" + i;
            }
            return i;
        }

        function loadDateFilter(date) {
            var day = date.getDate();
            var monthIndex = date.getMonth();
            var year = date.getFullYear();
            var m = monthIndex + 1;
            $scope.selDate = year + '-' + m + '-' + day;

        }

        function loadSubject() {
            if ($scope.actModel.ContactName == '')
                return '';
            var obj = new Object();
            obj.ContactName = $scope.actModel.ContactDisplayName;
            obj.CompanyName = $scope.actModel.CompanyName;
            obj.ContactTypeID = $scope.actModel.ContactTypeID;
            obj.ActivityType = $scope.actModel.ActivityType + ' ';
            obj.RepresentativeName = $scope.actModel.RepresentativeName;
            obj.Type = 'A';
            $scope.actModel.ActivitySubject = utility.getSubject(obj);

        }

        //set the cal date for displayed the textbox
        function SetCalDate(val, month, year) {
            var dt = new Date();
            dt.setDate(val);
            dt.setMonth((utility.monthNameToNum(month) - 1));
            dt.setFullYear(year);
            $scope.selDate = utility.getDateInDisplayFormat(dt);
        }

        //load all the master data
        function loadActTypes() {
            $scope.actTypes = utility.getMasterDataByKey(MASTER_TABLE.ActType);
            $scope.actTimes = utility.getMasterDataByKey(MASTER_TABLE.ActTime);
            $scope.actDurations = utility.getMasterDataByKey(MASTER_TABLE.ActDur);
            $scope.fieldSet = utility.getMasterDataByKey(MASTER_TABLE.ActFldSet);
            //debugger
            $scope.TierList = utility.getMasterDataByKey(MASTER_TABLE.Tier);
            $scope.actModel.ActivityTypeID = $scope.actTypes[0].ActivityTypeID;
            checkActivityType();
            var actStages = utility.getMasterDataByKey(MASTER_TABLE.ActStag);
            $scope.actModel.ActivityStageID = actStages[0].ActivityStageID;
        }

        function checkActivityType() {
            angular.forEach($scope.actTypes, function (obj, key) {
                if (actType == obj.Name) {
                    $scope.actModel.ActivityType = obj.Name;
                    $scope.actModel.ActivityTypeID = obj.ActivityTypeID;
                }
            });
        }

        //date calculate
        function loadDates(date, val, indx, type) {
            var retDt;
            if (val == 0) {
                retDt = date;
            }
            else {
                retDt = utility.dateCal(date, val, type);
            }

            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            $scope.actDates[indx]["Date"] = retDt.getDate();
            $scope.actDates[indx]["Month"] = monthNames[retDt.getMonth()];
            $scope.actDates[indx]["Year"] = retDt.getFullYear();
            return retDt;
        }

        function loadFields() {
            $scope.fields = [];
            for (var i = 0; i < $scope.fieldSet.length; i++) {
                $scope.actModel.Fields.push({
                    EntityID: $scope.actModel.ActivityID,
                    ModuleID: $scope.actModel.ModuleID,
                    ParentDeviceObjID: $scope.actModel.DeviceObjID,
                    FieldLabel: $scope.fieldSet[i].FieldLabel,
                    FieldName: $scope.fieldSet[i].FieldName,
                    FieldValue: '',
                    FieldID: $scope.fieldSet[i].FieldID,
                    IsConfidential: $scope.fieldSet[i].IsConfidential,
                    IsMandatory: $scope.fieldSet[i].IsMandatory,
                    IsVisible: $scope.fieldSet[i].IsVisible
                });
            }

            angular.copy($scope.actModel.Fields, $scope.fields);
        }

        function addActivityBackGroud() {
            activityService.sqlActAdd($scope.actModel, $scope.actModel.ActivityAttendees, 'E').then(function (result) {
                //$scope.actModel.Correspondences = [$scope.actModel.Correspondences];
                activityService.actAdd($scope.actModel).then(function (res) {
                    activityService.sqlActSync(res[0].Data).then(function (result) {
                        $scope.actModel.ActivityID = res[0].Data.ActivityID;
                        //modelObj[0].ActivityStageID = $scope.modelSelectedStage;
                        $scope.closeHappend();
                    });

                },
                    function (err) {
                        $scope.errorMessage = err;
                    });
            });
        }

        init();

        function getCurrentLoc() {
            var curAt = '';
            var options = {
                enableHighAccuracy: true,
                timeout: 3000,
                maximumAge: 0
            };
            utility.busyCursorStart();
            navigator.geolocation.getCurrentPosition(function (position) {
                curAt = position.coords.latitude + ' ' + position.coords.longitude;
                $scope.actModel.CreatedAt = curAt;
                $scope.actModel.ModifiedAt = curAt;
                GetAddress(position.coords.latitude, position.coords.longitude);
            }, function () { utility.busyCursorEnd(); }, options);
        }

        function GetAddress(lat, log) {
            var latlng;
            latlng = new google.maps.LatLng(lat, log); // New York, US

            new google.maps.Geocoder().geocode({ 'latLng': latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    var city, state, country, zipcode = '';
                    for (var ac = 0; ac < results[0].address_components.length; ac++) {
                        var component = results[0].address_components[ac];

                        switch (component.types[0]) {
                            case 'locality':
                                city = component.long_name;
                                break;
                            case 'administrative_area_level_1':
                                state = component.long_name;
                                break;
                            case 'country':
                                country = component.long_name;
                                break;
                            case 'postal_code':
                                zipcode = component.long_name;
                                break;
                        }
                    }

                    var loc = GetText(city) + GetText(state) + GetText(country);
                    // Assign value to address feild
                    $scope.actModel.Address = loc.replace(/,\s*$/, "");
                }
                utility.busyCursorEnd();
            });
        }

        function GetText(val) {
            if (val == '' || val == 'undefined' || val == null) return "";
            return val + ', ';
        }

        $scope.nextActivity = function () {
            activityService.setActHappendVal($scope.actModel.Description);
            $state.go('tab.activityAdd', { actId: deviceObjID, editModeFlag: 0, screenType: actScreenType });
        }


        $scope.closeHappend = function () {
            if (actScreenType == GENERAL_CONFIG.ScreenType.ActivtyList) {
                $state.go('tab.activity');
            }
            else if (actScreenType == GENERAL_CONFIG.ScreenType.ContactList) {
                $state.go('tab.contact');
            }
            else if (actScreenType == GENERAL_CONFIG.ScreenType.ContactDetail) {
                $state.go('tab.contactDetails');
            }
            else if (actScreenType == GENERAL_CONFIG.ScreenType.ActivityDetail) {
                $state.go('tab.activityDetail', { activitiesId: deviceObjID, screenType: 'List' });
            }
            else if (actScreenType == GENERAL_CONFIG.ScreenType.HomeContact || actScreenType == GENERAL_CONFIG.ScreenType.HomeActivity) {
                $state.go('tab.home');
            }


        };


        $scope.actionHappend = function () {
            var valActFlag = true;
            //valActFlag = utility.commonValidationStatic($scope.actModel.Description, valActFlag, 'notes', 'some details.');
            valActFlag = utility.commonValidation($scope.actModel.Description, valActFlag, 'some details.');
            if (!valActFlag) return false;

            if (activityService.getActStatus() == 'S') {
                updateStatus();
            }
            else {
                var confirmPopup = $ionicPopup.confirm({
                    title: 'Confirm',
                    template: 'Are you sure, You want to exit without next activity?'
                });
                confirmPopup.then(function (res) {
                    if (res) {
                        updateStatus();
                    } else {
                        //console.log('You are not sure');
                    }
                });
            }
        }

        function loadCurDate() {
            var curDt = new Date();
            //loadDateFilter(curDt);
            $scope.actModel.ActivityDate = $filter('date')(new Date(curDt), 'yyyy-MM-dd');//utility.getDateInServerFormat(actDate);
            var actTime = $filter('date')(new Date(curDt), 'hh:mm a');
            $scope.actModel.ActivityTime = utility.convertTime24Format(actTime);
            $scope.actModel.ActivityDateForSort = $scope.actModel.ActivityDate;
        }

        function updateStatus() {
            $scope.actModel.Correspondences = [];
            var objCor = new Object();

            var locArr = $scope.actModel.CreatedAt.split(' ');
            if (locArr.length > 0) {
                objCor.DeviceObjID = utility.generateUUID();
                objCor.ModuleID = GENERAL_CONFIG.MODULES.Activity;
                objCor.Address = $scope.actModel.Address;
                objCor.GoogleLat = locArr[0];
                objCor.GoogleLong = locArr[1];
            }
            if ($scope.actModel.CreatedAt != '')
                $scope.actModel.Correspondences.push(objCor);
            //$scope.actModel.Correspondences.GoogleLat = $scope.actModel.CreatedAt;
            //$scope.actModel.Correspondences.GoogleLong = $scope.actModel.CreatedAt;
            $scope.actModel.ActivityStageID = $scope.modelSelectedStage;
            $scope.actModel.Notes = [];
            $scope.actModel.ModifiedOn = utility.getDateStringInUTC(new Date());
            $scope.actModel.CreatedOn = utility.getDateStringInUTC(new Date());
            var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            $scope.actModel.CreatorID = lgnUser.UserID;
            $scope.actModel.ModifiedBy = lgnUser.UserID;
            $scope.actModel.CreatorName = lgnUser.FullName;
            $scope.actModel.ModifiedByName = lgnUser.FullName;


            var noteObjModel = noteService.noteMod().noteModel;
            noteObjModel.EntityID = $scope.actModel.ActivityID;
            noteObjModel.ModuleID = GENERAL_CONFIG.MODULES.Activity;
            noteObjModel.ParentDeviceObjID = $scope.actModel.DeviceObjID;
            noteObjModel.Description = $scope.actModel.Description;
            noteObjModel.CreatorID = lgnUser.UserID;
            noteObjModel.CreatorName = lgnUser.FullName;
            noteObjModel.CreatedOn = utility.getDateStringInUTC(new Date());
            noteObjModel.CreatedAt = $scope.actModel.CreatedAt;
            $scope.actModel.Notes.push(noteObjModel);

            if (($scope.actModel.ActivityType == 'Call' || $scope.actModel.ActivityType == 'Meeting') && $scope.actModel.ContactTierID != '')
                $scope.actModel.NextContactDate = utility.getNextContactDate($scope.actModel.ContactTierID);
            if (actScreenType == GENERAL_CONFIG.ScreenType.ContactList || actScreenType == GENERAL_CONFIG.ScreenType.ContactDetail || actScreenType == GENERAL_CONFIG.ScreenType.HomeContact) {
                $scope.actModel.DeviceObjID = utility.generateUUID();
                $scope.actModel.OwnerID = lgnUser.UserID;
                $scope.actModel.OwnerName = lgnUser.FullName;
                addActivityBackGroud();
            }
            else {
                loadCurDate();

                activityService.sqlSaveNotes($scope.actModel.Notes, $scope.actModel).then(function (result) {
                    //$scope.actModel.Correspondences = [$scope.actModel.Correspondences];
                    activityService.actAdd($scope.actModel).then(function (res) {
                        activityService.sqlActSync(res[0].Data).then(function (result) {
                            //if (actScreenType == GENERAL_CONFIG.ScreenType.ContactList || actScreenType == GENERAL_CONFIG.ScreenType.ContactDetail) {
                            //    $scope.actModel.ActivityStageID = $scope.modelSelectedStage;
                            //}
                            //else {

                            //}
                            modelObj[0].ActivityStageID = $scope.modelSelectedStage;
                            modelObj[0].ActivityDate = $scope.actModel.ActivityDate;
                            modelObj[0].ActivityTime = $scope.actModel.ActivityTime;
                            modelObj[0].Priority = 2;
                            if ($scope.actModel.Correspondences.length > 0) {
                                if ($scope.actModel.Correspondences[0].Address != '')
                                    modelObj[0].Address = $scope.actModel.Correspondences[0].Address;
                            }

                            $scope.closeHappend();
                        });

                    },
                   function (err) {
                       $scope.errorMessage = err;
                   });

                });
            }

        }

    };

})();
