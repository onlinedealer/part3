export interface MeasurementType {
    measurementTypeId: number;
    baseUnitId?: number;
    commodity?: string;
    directionOfFlow?: string;
    kind?: string;
    meteringMode?: string;
    obisA?: number;
    obisB?: number;
    obisC?: number;
    obisD?: number;
    obisE?: number;
    obisF?: number;
    phase?: string;
    tou?: string;
}
