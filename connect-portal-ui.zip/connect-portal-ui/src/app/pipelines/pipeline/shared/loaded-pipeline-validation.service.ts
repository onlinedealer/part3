import { Injectable } from '@angular/core';
import { Pipeline } from './pipeline';

/**
 * Verifies which parts of a loaded pipeline are considered valid at the time the pipeline has been loaded.
 *
 * Important: this service isn't to be used by the individual components of the pipeline to check if a step is valid whilst the user is altering a pipeline.
 * That task is handled by the individual components.
 *
 */
@Injectable({
  providedIn: 'root'
})
export class LoadedPipelineValidationService {
  private pipeline: Pipeline;
  constructor() {}

  setPipeline(pipeline: Pipeline): void {
    this.pipeline = pipeline;
  }

  isGeneralStepValid(): boolean {
    // This is always true as the user cannot save a pipeline without the General step being valid.
    return true;
  }

  isConnectionsStepValid(): boolean {
    return typeof this.pipeline.source?.dataConnection !== 'undefined' && typeof this.pipeline.target?.dataConnection !== 'undefined';
  }

  isDataStepValid(): boolean {
    return this.pipeline.source?.selectedTables?.length > 0;
  }

  isMappingStepValid(): boolean {
    return this.pipeline.tableMapping?.length > 0;
  }
}
