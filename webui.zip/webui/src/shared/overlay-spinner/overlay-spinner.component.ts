import { Component } from '@angular/core';

@Component({
  selector: 'discovery-overlay-spinner',
  templateUrl: './overlay-spinner.component.html',
  styleUrls: ['./overlay-spinner.component.css']
})
export class OverlaySpinnerComponent {
  //Its a pure component
}
