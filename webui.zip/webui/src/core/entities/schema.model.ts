import { TableModel } from './table.model';

export class SchemaModel {
  name: string;
  count: string | number;
  selected: boolean;
  children: TableModel[];
  connectionId?: string;

  constructor(schema?: SchemaModel) {
    this.selected = schema && schema.selected;
    this.children = [];
    if (schema) {
      this.name = schema.name;
      this.count = schema.count;
      this.connectionId = schema.connectionId;
      if (schema.children) {
        for (const table of schema.children) {
          this.children.push(new TableModel(table));
        }
      }
    }
  }
}

export interface ISchemas {
  name: string;
  value: string;
}
