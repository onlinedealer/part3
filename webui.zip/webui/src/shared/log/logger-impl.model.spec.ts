import { LogManagerService } from './log-manager.service';
import { Logger } from './logger.model';

describe('LoggerImpl', () => {
  let logManager: LogManagerService;
  let log: Logger;

  beforeEach(() => {
    spyOn(window.console, 'debug').and.callThrough();
    spyOn(window.console, 'info').and.callThrough();
    spyOn(window.console, 'warn').and.callThrough();
    spyOn(window.console, 'error').and.callThrough();
    logManager = new LogManagerService();
    log = logManager.getLogger('LoggerSpec');
  });

  it('should be created', () => {
    expect(log).toBeTruthy();
  });

  describe('TRACE log level', () => {
    beforeEach(() => {
      logManager.setLevel('TRACE');
    });

    it('should output trace msg', () => {
      log.trace('test');
      expect(window.console.debug).toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output debug msg', () => {
      log.debug('test');
      expect(window.console.debug).toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output info msg', () => {
      log.info('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output warn msg', () => {
      log.warn('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output error msg', () => {
      log.error('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).toHaveBeenCalled();
    });
  });

  describe('DEBUG log level', () => {
    beforeEach(() => {
      logManager.setLevel('DEBUG');
    });

    it('should output debug msg', () => {
      log.debug('test');
      expect(window.console.debug).toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output info msg', () => {
      log.info('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output warn msg', () => {
      log.warn('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output error msg', () => {
      log.error('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).toHaveBeenCalled();
    });
  });

  describe('INFO log level', () => {
    beforeEach(() => {
      logManager.setLevel('INFO');
    });

    it('should not output debug msg', () => {
      log.debug('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output info msg', () => {
      log.info('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output warn msg', () => {
      log.warn('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output error msg', () => {
      log.error('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).toHaveBeenCalled();
    });
  });

  describe('WARN log level', () => {
    beforeEach(() => {
      logManager.setLevel('WARN');
    });

    it('should not output debug msg', () => {
      log.debug('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should not output info msg', () => {
      log.info('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output warn msg', () => {
      log.warn('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output error msg', () => {
      log.error('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).toHaveBeenCalled();
    });
  });

  describe('ERROR log level', () => {
    beforeEach(() => {
      logManager.setLevel('ERROR');
    });

    it('should not output debug msg', () => {
      log.debug('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should not output info msg', () => {
      log.info('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should not output warn msg', () => {
      log.warn('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should output error msg', () => {
      log.error('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).toHaveBeenCalled();
    });
  });

  describe('OFF log level', () => {
    beforeEach(() => {
      logManager.setLevel('OFF');
    });

    it('should not output debug msg', () => {
      log.debug('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should not output info msg', () => {
      log.info('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should not output warn msg', () => {
      log.warn('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });

    it('should not output error msg', () => {
      log.error('test');
      expect(window.console.debug).not.toHaveBeenCalled();
      expect(window.console.info).not.toHaveBeenCalled();
      expect(window.console.warn).not.toHaveBeenCalled();
      expect(window.console.error).not.toHaveBeenCalled();
    });
  });
});
