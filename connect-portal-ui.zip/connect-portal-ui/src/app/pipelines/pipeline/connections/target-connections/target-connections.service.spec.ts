import { TestBed } from '@angular/core/testing';

import { TargetConnectionsService } from './target-connections.service';

describe('TargetConnectionsService', () => {
  let service: TargetConnectionsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(TargetConnectionsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return map', (done) => {
    service.get().subscribe((result) => {
      expect(result).toBeDefined();
      done();
    });
  });
});
