export interface LocalSavedColumnConfigurations {
    viewName: string;
    viewId: string;
    tableDefinitions: TableConfigurations;
}
export interface TableConfigurations {
    tableName: string;
    tableId: string;
    columnDefinitions: ColumnConfigurations;
}
export interface ColumnConfigurations {
    columnName: string;
    columnWidth: number;
    columnId: string;
    position: string;
}
export interface LocalSavedTableColumnConfigurations {
    viewName: string;
    viewId: string;
    tableDefinitions: TableColumnConfigurations;
}
export interface TableColumnConfigurations {
    tableId: string;
    tableName: string;
    columnDefinitions: ColumnConfigurations[];
}

export interface EditColumnConfiguration {
    tableId: string;
    columnDefinitions: ColumnDetails[];
}
export interface ColumnDetails {
    showColumn: boolean;
    columnName: string;
    columnWidth: number;
    columnId: string;
    position: string;
}
