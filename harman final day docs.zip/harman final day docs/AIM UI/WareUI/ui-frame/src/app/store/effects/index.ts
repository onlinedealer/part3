import { RouterEffects } from "./router.effect";
import { SecurityEffects } from "./security.effect";
import { SessionActivityEffects } from "./session-activity.effects";
import { ConfigurationEffects } from "./configurations.effects";
import { UserSettingsEffects } from "./user-settings.effects";
import { NetworkSpecificConfigurationEffects } from "./network-specific-config.effects";
import { EnvironmentIndicatorEffects } from "./environment-indicator.effects";

export const effects: any[] = [
    RouterEffects,
    SecurityEffects,
    SessionActivityEffects,
    ConfigurationEffects,
    UserSettingsEffects,
    NetworkSpecificConfigurationEffects,
    EnvironmentIndicatorEffects
];
