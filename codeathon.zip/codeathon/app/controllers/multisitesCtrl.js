(function() {
    'use strict';
    /* MultiSites List */
    codeathonApp.controller("multisitesCtrl", ['$scope', '$ajaxFactory', 'uiRouters', multisitesCtrl]);

    function multisitesCtrl($scope, $ajaxFactory, uiRouters) {
        indicatorStart("Loading....");
        $scope.multisitesDataSource = [];
        $scope.itemData = {};
        $scope.isEditOrAddPage = false;
        $scope.isAddPage = false;
        $scope.multisitesName = "";
        $scope.description = "";
        $scope.url1 = "";
        $scope.url2 = "";
        $scope.url3 = "";
        $scope.buttonText = "";
        $scope.headerText = "";
        var userId = "";
        var multisitesId = "";
        var url = "";

        // redirecting to /login page
        if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        }

        $scope.editItem = function(item) {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = false;
            $scope.itemData = item;
            $scope.multisitesName = item.name;
            $scope.description = item.description;
            $scope.url1 = item.logo1;
            $scope.url2 = item.logo1;
            $scope.url3 = item.color;
            $scope.buttonText = "Update";
            $scope.headerText = "Edit";
            multisitesId = item.id;
        };

        $scope.addItem = function() {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = true;
            $scope.multisitesName = "";
            $scope.description = "";
            $scope.url1 = "";
            $scope.url2 = "";
            $scope.url3 = "";
            $scope.buttonText = "Add";
            $scope.headerText = "Create";
        };
		
		 // redirecting to /login page
        if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        }

        $scope.removeItem = function(multisitesId) {
            indicatorStart("Deleting Domain..");
			
            url = "/delete/multisite/"+multisitesId+"/user/"+userId+"/";
			var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'POST', {});
			
            //var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/multisites/data.json', 'POST', {});

            promise.then(function(d) {
                $scope.multisitesDataSource = d;	
				$scope.fetchDataSource();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.saveData = function(e) {
            if (Codeathon.utils.isNullOrEmpty($scope.multisitesName) || Codeathon.utils.isNullOrEmpty($scope.description) || Codeathon.utils.isNullOrEmpty($scope.url1) || Codeathon.utils.isNullOrEmpty($scope.url2) || Codeathon.utils.isNullOrEmpty($scope.url3)) {
                alert("All Fields Required");
                return;
            } else {
                var obj = {}
                obj.name = $scope.multisitesName;
                obj.description = $scope.description;
				obj.logo1 = $scope.url1;
				obj.logo2 = $scope.url2;
				obj.color = $scope.url3;

                // if isAddPage true : Adding New multisites
                // if isAddPage False : Editing multisites
                if ($scope.isAddPage) {
                    indicatorStart("Adding Domain..");
					alert("Adding Domain..");
                    //url = uiRouters.filepath + '/multisites/data.json';
                    url = uiRouters.urlpath + "/add/multisite/user/"+userId+"/";

                } else {
                    indicatorStart("Updating Domain..");
					//url = uiRouters.filepath + '/multisites/data.json';
                    url = uiRouters.urlpath+"/modify/multisite/"+multisitesId+"/user/"+userId+"/";

                }
                var promise = $ajaxFactory.getDataFromServer(url, 'POST', obj);

                promise.then(function(d) {
                    $scope.multisitesDataSource = d;
                    $scope.isEditOrAddPage = false;
                    $scope.isAddPage = false;
                    console.log('Success');

                    var obj = {};
                    obj.message = "Domain";
                    obj.content = "Success";
                    obj.eventObj = e;
                    $scope.$emit('openPopupEvent', obj);	
					$scope.fetchDataSource();
					
                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
                promise.finally(function(d) {
                    console.log('finally block executed', d);
                    indicatorStop();
                });

            }

        }
        $scope.cancel = function() {
            $scope.isEditOrAddPage = false;
            $scope.isAddPage = false;
        }

        $scope.fetchDataSource = function() {
			
			url = "/get/list/of/multisite/user/"+userId+"/";
           //var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/multisites/data.json', 'GET', {});
           var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.multisitesDataSource = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        }
        $scope.fetchDataSource();
    }

})();
