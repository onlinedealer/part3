﻿(function () {
    'use strict';
    angular.module('arm').controller('forgotCtrl', ['$scope', '$state', forgotController]);
    function forgotController($scope, $state) {

        $scope.email = {};

        var regExEmail = /^([0-9a-zA-Z]+[-._+&amp;])*[0-9a-zA-Z]+@([-0-9a-zA-Z]+[.])+[a-zA-Z]{2,6}$/;

        $scope.docheckPassword = function () {
            if (!regExEmail.test($scope.email.resetEmail)) {
                //$cordovaDialogs.alert("Email address is invalid");
                return false;
            };
        };

    }
})();
