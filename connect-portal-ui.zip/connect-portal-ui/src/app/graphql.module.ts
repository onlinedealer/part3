import { NgModule } from '@angular/core';
import { ApolloModule, APOLLO_OPTIONS } from 'apollo-angular';
import { HttpLink } from 'apollo-angular/http';
import { InMemoryCache, ApolloLink } from '@apollo/client/core';
import { setContext } from '@apollo/client/link/context';
import { OpenIdConnectService } from '@precisely/prism-ng/angular-auth-oidc-client';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

export function createApollo(httpLink: HttpLink, httpUtilService: HttpUtilService, oidc: OpenIdConnectService) {
  let uri;
  let config = {
    app: 'gateway',
    namespace: 'dqcore',
    path: 'catalog/v1/graphql'
  };
  uri = httpUtilService.isLocal(config.app, config.namespace)
    ? httpUtilService.getAssetUrl(config.app, config.namespace, config.path)
    : httpUtilService.getUrl(config.app, config.namespace, config.path);

  const auth = setContext((_operation, _context) => {
    return oidc.getToken() === null
      ? {}
      : {
          headers: {
            Authorization: `Bearer ${oidc.getToken()}`
          }
        };
  });

  const link = ApolloLink.from([auth, httpLink.create({ uri })]);
  const cache = new InMemoryCache();
  // for now error policy is set to all. Client component should check for "error" property in the response
  const defaultOptions = {
    watchQuery: {
      fetchPolicy: 'no-cache',
      errorPolicy: 'all'
    }
  };

  return {
    link,
    cache,
    defaultOptions
  };
}

@NgModule({
  exports: [ApolloModule],
  providers: [
    {
      provide: APOLLO_OPTIONS,
      useFactory: createApollo,
      deps: [HttpLink, HttpUtilService, OpenIdConnectService]
    }
  ]
})
export class GraphQLModule {}
