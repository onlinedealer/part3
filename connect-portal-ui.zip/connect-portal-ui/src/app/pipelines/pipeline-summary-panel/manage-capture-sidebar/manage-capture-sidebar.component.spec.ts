import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of, throwError } from 'rxjs';
import { ManageCaptureSidebarComponent } from './manage-capture-sidebar.component';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { ManageCaptureFormComponent } from './manage-capture-form/manage-capture-form.component';
import { PipelinesMonitoringApiService } from '../../shared/pipelines-monitoring-api.service';

describe('ManageCaptureSidebarComponent', () => {
  let component: ManageCaptureSidebarComponent;
  let fixture: ComponentFixture<ManageCaptureSidebarComponent>;

  const pipelinesMonitoringApiService = jasmine.createSpyObj<Partial<PipelinesMonitoringApiService>>('mockPipelinesMonitoringApiService', [
    'enableTableCapture',
    'disableTableCapture'
  ]);

  @Component({
    selector: 'p-connect-sidebar',
    template: '',
    providers: [
      {
        provide: SidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    parseHttpClientResponseMessage() {}
    open() {}
    close() {}
  }

  @Component({
    selector: 'p-connect-manage-capture-form',
    template: '',
    providers: [
      {
        provide: ManageCaptureFormComponent,
        useClass: MockManageCaptureFormComponent
      }
    ]
  })
  class MockManageCaptureFormComponent {
    open() {}
    get tablesEnabled(): string[] {
      return ['GISJ02.LVJMPROP'];
    }
    get tablesDisabled(): string[] {
      return ['GISJ01.CMINST800'];
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ManageCaptureSidebarComponent, MockSidebarComponent, MockManageCaptureFormComponent],
      providers: [{ provide: PipelinesMonitoringApiService, useValue: pipelinesMonitoringApiService }]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(ManageCaptureSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the sidebar', () => {
    spyOn(component.manageCaptureFormComponent, 'open');
    spyOn(component.sidebarComponent, 'open');
    component.open({
      tableMappings: [{ source: { name: 'LTIAS08' } }],
      captureStatus: 'OK'
    });
    expect(component.manageCaptureFormComponent.open).toHaveBeenCalled();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should close the sidebar', () => {
    spyOn(component.sidebarComponent, 'close');
    component.cancelSidebarButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should display the alerts sidebar', () => {
    component.displayAlertsCheckbox.onChangeCheckBox({ checked: true });
    expect(component.isDisplayAlertsEnabled).toBe(true);
  });

  it('should enable capture for the selected tables', fakeAsync(() => {
    spyOn(pipelinesMonitoringApiService, 'enableTableCapture').and.returnValue(of({}));
    spyOn(pipelinesMonitoringApiService, 'disableTableCapture').and.returnValue(of({}));
    component.projectId = 'abc';
    component.pipelineName = 'pipeline1';
    component.primaryButtonClicked();
    tick();
    fixture.whenStable().then(() => {
      expect(pipelinesMonitoringApiService.enableTableCapture).toHaveBeenCalled();
    });
  }));

  it('should handle enableTableCapture error', fakeAsync(() => {
    const errorResponse = { error: { detailedMessage: 'enableTableCapture failed' } };
    spyOn(pipelinesMonitoringApiService, 'enableTableCapture').and.returnValue(throwError(errorResponse));
    spyOn(pipelinesMonitoringApiService, 'disableTableCapture').and.returnValue(of({}));
    spyOn(component, 'parseHttpClientResponseMessage');
    component.projectId = 'abc';
    component.pipelineName = 'pipeline1';
    component.enableCapture();
    tick();
    fixture.whenStable().then(() => {
      expect(component.parseHttpClientResponseMessage).toHaveBeenCalled();
    });
  }));

  it('should disable capture for the selected tables', fakeAsync(() => {
    spyOn(pipelinesMonitoringApiService, 'enableTableCapture').and.returnValue(of({}));
    spyOn(pipelinesMonitoringApiService, 'disableTableCapture').and.returnValue(of({}));
    component.projectId = 'abc';
    component.pipelineName = 'pipeline1';
    component.primaryButtonClicked();
    tick();
    fixture.whenStable().then(() => {
      expect(pipelinesMonitoringApiService.disableTableCapture).toHaveBeenCalled();
    });
  }));

  it('should handle disableTableCapture error', fakeAsync(() => {
    const errorResponse = { error: { detailedMessage: 'disableCapture failed' } };
    spyOn(pipelinesMonitoringApiService, 'enableTableCapture').and.returnValue(of({}));
    spyOn(pipelinesMonitoringApiService, 'disableTableCapture').and.returnValue(throwError(errorResponse));
    spyOn(component, 'parseHttpClientResponseMessage');
    component.projectId = 'abc';
    component.pipelineName = 'pipeline1';
    component.disableCapture();
    tick();
    fixture.whenStable().then(() => {
      expect(component.parseHttpClientResponseMessage).toHaveBeenCalled();
    });
  }));

  it('should display the alerts sidebar', fakeAsync(() => {
    spyOn(pipelinesMonitoringApiService, 'enableTableCapture').and.returnValue(of({}));
    spyOn(pipelinesMonitoringApiService, 'disableTableCapture').and.returnValue(of({}));
    spyOn(component.displayAlertsEvent, 'emit');
    component.projectId = 'abc';
    component.pipelineName = 'pipeline1';
    component.isDisplayAlertsEnabled = true;
    component.primaryButtonClicked();
    tick();
    fixture.whenStable().then(() => {
      expect(component.displayAlertsEvent.emit).toHaveBeenCalled();
    });
  }));

  it('should enable the save button if there are pending changes', () => {
    component.pendingChanges(true);
    expect(component.primaryButton.isDisabled).toBe(false);
  });

  it('should disable the save button if there are no pending changes', () => {
    component.pendingChanges(false);
    expect(component.primaryButton.isDisabled).toBe(true);
  });
});
