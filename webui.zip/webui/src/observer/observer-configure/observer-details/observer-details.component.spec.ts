import { NgForm } from '@angular/forms';
import { Spies } from 'discovery-test';
import { ObserverDetailsComponent } from './observer-details.component';
import { ScheduleComponent } from 'discovery-shared';

describe('ObserverDetailsComponent', () => {
  let component: ObserverDetailsComponent;

  beforeEach(() => {
    Spies.init();
    component = new ObserverDetailsComponent(Spies.launchDarklyService);
    component.observerDetailForm = new NgForm([], []);
    component.observeScheduleComponent = new ScheduleComponent(Spies.TranslateService);
    Spies.launchDarklyService.variation.and.returnValue(false);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('validation failed name null', () => {
    component.observeScheduleComponent.scheduleForm = new NgForm([], []);
    const errors = component.validate();
    expect(errors.size).toBe(1);
    expect(errors.has('discoveryObserver.observerDetails.missingName')).toBe(true);
  });

  it('validation failed name blank', () => {
    component.observeScheduleComponent.scheduleForm = new NgForm([], []);
    component.observerName = '   ';
    const errors = component.validate();
    expect(errors.size).toBe(1);
    expect(errors.has('discoveryObserver.observerDetails.missingName')).toBe(true);
  });

  it('validation failed name invalid', () => {
    component.observeScheduleComponent.scheduleForm = new NgForm([], []);
    component.observerName = '123@#!InvalidName';
    const errors = component.validate();
    expect(errors.size).toBe(1);
    expect(errors.has('discoveryObserver.observerDetails.invalidName')).toBe(true);
  });

  it('validate observer Name ', () => {
    component.observerName = '456@InvalidName';
    component.validateobserverName();
    expect(component.observerNameError.invalidName).toBe(true);
  });

  it('validation success', () => {
    component.observeScheduleComponent.scheduleForm = new NgForm([], []);
    component.observerName = 'Valid Name-123';
    const errors = component.validate();
    expect(errors.size).toBe(0);
  });

  it('test observer name changed', () => {
    spyOn(component.observerNameChange, 'emit');
    component.observerNameChanged();
    expect(component.observerNameChange.emit).toHaveBeenCalled();
  });

  it('test observer description changed', () => {
    spyOn(component.observerDescriptionChange, 'emit');
    component.observerDescriptionChanged();
    expect(component.observerDescriptionChange.emit).toHaveBeenCalled();
  });

  it('test emit scheduler change', () => {
    spyOn(component.schedulerChange, 'emit');
    component.getSchedulerChange('dummy');
    expect(component.schedulerChange.emit).toHaveBeenCalled();
  });

  it('should return `true` if flag is enabled', () => {
    Spies.launchDarklyService.variation.and.returnValue(true);
    expect(component.emailNotificationFlag).toBeTruthy();
  });

  it('should return `false` if flag is disabled', () => {
    Spies.launchDarklyService.variation.and.returnValue(false);
    expect(component.emailNotificationFlag).toBeFalsy();
  });
});
