import { Component, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { TreePath } from 'profiling/profile-results/tree-path.model';

@Component({
  selector: 'discovery-donut-chart',
  templateUrl: './donut-chart.component.html',
  styleUrls: ['./donut-chart.component.css']
})
export class DonutChartComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, any>;
  @Input() showTrendsIndicator: boolean;
  data: any;
  basicOptions: any;
  totalRows: number;
  chartWidth: string = '20vw';

  constructor(private translocoService: TranslocoService) {}

  ngOnInit() {
    this.data = {
      labels: [],
      datasets: [
        {
          data: [],
          backgroundColor: [
            ProfilingConstants.FREQUENCYCHARTCOLORS[0],
            ProfilingConstants.FREQUENCYCHARTCOLORS[1],
            ProfilingConstants.FREQUENCYCHARTCOLORS[2],
            ProfilingConstants.FREQUENCYCHARTCOLORS[3]
          ],
          hoverBackgroundColor: ['#39006Bcc', '#8017E1cc', '#E5007Ecc', '#FAB512cc']
        }
      ]
    };

    this.basicOptions = {
      plugins: {
        legend: {
          display: this.showTrendsIndicator ? false : true,
          align: 'start',
          position: 'right',
          onClick: (event: any, legendItem: any) => {
            // alert(legendItem.text);
          },
          onHover: (e: any) => {
            e.native.target.style.cursor = 'pointer';
          },
          labels: {
            boxWidth: 10
          }
        },
        tooltip: { enabled: false }
      },
      cutout: '80%'
    };
    if (this.treePath) {
      this.generateDataLabel();
    }
  }
  selectData(event: any): void {}

  private generateDataLabel(): void {
    this.chartWidth = this.showTrendsIndicator ? '10vw' : '20vw';
    if (this.treePath.tableView) {
      this.totalRows = this.treePath.treeData.data.totalRows;
      const inCompleteCount = this.totalRows - this.statistics['completeCount'];
      this.data.datasets[0].data = [inCompleteCount, this.statistics['completeCount']];
      this.data.labels[0] =
        this.translocoService.translate('discoveryProfiling.results.inCompleteRows') +
        ' ' +
        '(' +
        ((inCompleteCount / this.totalRows) * 100).toFixed(2) +
        '%)';
      this.data.labels[1] =
        this.translocoService.translate('discoveryProfiling.results.completeRows') +
        ' ' +
        '(' +
        ((this.statistics['completeCount'] / this.totalRows) * 100).toFixed(2) +
        '%)';
    }
    if (this.treePath.columnView) {
      if (this.treePath.treeData && this.treePath.treeData.parent) {
        this.totalRows = this.treePath.treeData.parent.data.totalRows;
        this.data.datasets[0].data = [
          this.statistics['completeCount'],
          this.statistics['nullCount'],
          this.statistics['blankCount']
        ];
        this.data.labels[0] =
          this.translocoService.translate('discoveryProfiling.results.complete') +
          ' ' +
          '(' +
          ((this.statistics['completeCount'] / this.totalRows) * 100).toFixed(2) +
          '%)';
        this.data.labels[1] =
          this.translocoService.translate('discoveryProfiling.results.null') +
          ' ' +
          '(' +
          ((this.statistics['nullCount'] / this.totalRows) * 100).toFixed(2) +
          '%)';
        this.data.labels[2] =
          this.translocoService.translate('discoveryProfiling.results.blankCount') +
          ' ' +
          '(' +
          ((this.statistics['blankCount'] / this.totalRows) * 100).toFixed(2) +
          '%)';
      }
    }
  }
}
