import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { MockSidebarComponent } from '../../../../../shared/components/sidebar/mock-sidebar.component.spec';
import { ExcludeusersSidebarComponent } from './excludeusers-sidebar.component';

describe('ExcludeusersSidebarComponent', () => {
  let component: ExcludeusersSidebarComponent;
  let fixture: ComponentFixture<ExcludeusersSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [ExcludeusersSidebarComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcludeusersSidebarComponent);
    component = fixture.componentInstance;
    component.usersExcludedFromCapture = ['user1', 'user2'];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should open sidebar when exclude users button is clicked', () => {
    const openSidebar = spyOn(component.sidebarComponent, 'open').and.returnValue();
    component.open();
    expect(openSidebar).toHaveBeenCalled();
  });
  it('should close sidebar when close button is clicked', () => {
    const closeSidebar = spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.cancelSidebarButtonClicked();
    expect(closeSidebar).toHaveBeenCalled();
  });
  it('should close sidebar when save button is clicked', () => {
    const closeSidebar = spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.primaryButtonClicked();
    expect(closeSidebar).toHaveBeenCalled();
  });
});
