import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { BaseConnectionFormComponent } from './base-connection-form.component';
import { ServiceInjector } from '../../../../shared/services/service.injector';

describe('BaseFormComponent', () => {
  let component: BaseConnectionFormComponent;
  let fixture: ComponentFixture<BaseConnectionFormComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BaseConnectionFormComponent],
      imports: [HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'servers' } }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BaseConnectionFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    fg.get('control').setValue('');
  });

  it('should not remove formgroup controls if the fomrgroup has not been defined', () => {
    component.removeChildFormControls(null);
    expect(true).toBeTruthy(); // no expectations necessary
  });

  it('should emit event when adding a server', () => {
    spyOn(component.addServerButtonClickedEvent, 'emit').and.returnValue(null);
    component.addRuntimeServer();
    expect(component.addServerButtonClickedEvent.emit).toHaveBeenCalled();
  });

  /*   describe('Service injector not set', () => {
    beforeEach(() => {
      ServiceInjector.injector = null;
      fixture = TestBed.createComponent(BaseConnectionFormComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      fg.get('control').setValue('');
    });
  }); */
});
