import { Component, Input, Output, EventEmitter, OnChanges, ViewChild, SimpleChanges, OnInit } from "@angular/core";
import { FormGroup, FormBuilder } from "@angular/forms";
import { MatOption } from "@angular/material/core";

@Component({
    selector: "landisgyr-meteringpoint-power-quality-filter",
    templateUrl: "./meteringpoint-power-quality-filter.component.html",
    styleUrls: ["./meteringpoint-power-quality-filter.component.scss"]
})
export class MeteringpointPowerQualityFilterComponent implements OnInit, OnChanges {
    @ViewChild("allFilterSelected") private allFilterSelected!: MatOption;

    @Input() pqiFilterData!: any;
    @Input() event!: any;
    @Input() filter!: string;
    @Input() showUndo!: boolean;

    @Output() selectedFilterList: EventEmitter<any> = new EventEmitter();
    @Output() undoClicked: EventEmitter<any> = new EventEmitter();

    pqiFormGroup!: FormGroup;
    selected!: any[];

    // TODO
    undoTooltipText = $localize`:|Undo the latest filter change.@@eventsView.undoLatestChange:Undo the latest filter change`;

    constructor(private fb: FormBuilder) {
        this.pqiFormGroup = this.fb.group({
            pqiFormControl: [""]
        });
    }

    ngOnInit() {
        this.emitSelectedFilterList(this.pqiFilterData);
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.filter && changes.filter.currentValue !== undefined) {
            if (changes.filter.currentValue === "show") {
                this.selected = [{ name: this.event.type }];

                this.emitSelectedFilterList(this.selected);
            } else if (changes.filter.currentValue === "hide") {
                this.selected = this.pqiFilterData.filter((item: any) => {
                    if (changes.event) {
                        return item.name !== changes.event.currentValue.type;
                    } else {
                        return item.name !== this.event.type;
                    }
                });

                this.emitSelectedFilterList(this.selected);
            }
        }

        if (changes.pqiFilterData && changes.pqiFilterData.currentValue) {
            this.pqiFormGroup.patchValue({
                pqiFormControl: [...this.pqiFilterData, 0]
            });
        }
    }

    onOneFilterSelect() {
        const control = this.pqiFormGroup.get(["pqiFormControl"]);
        if (!control) {
            return false;
        }
        if (this.allFilterSelected.selected) {
            this.allFilterSelected.deselect();
            this.emitSelectedFilterList(control.value);
            return false;
        }
        if (control.value.length === this.pqiFilterData.length) {
            this.allFilterSelected.select();
        }
        this.emitSelectedFilterList(control.value);
    }

    onAllFilterSelect() {
        const control = this.pqiFormGroup.get(["pqiFormControl"]);
        if (!control) {
            return false;
        }
        if (this.allFilterSelected.selected) {
            control.patchValue([...this.pqiFilterData.map((item: any) => item), 0]);
        } else {
            control.setValue([]);
        }
        this.emitSelectedFilterList(control.value);
    }

    compare(value: any, option: any) {
        return value.name === option.name;
    }

    emitSelectedFilterList(filterList: any) {
        this.selectedFilterList.emit(filterList);
    }

    onUndoClick() {
        this.pqiFormGroup.patchValue({
            pqiFormControl: [...this.pqiFilterData, 0]
        });
        this.selectedFilterList.emit(this.pqiFilterData);
        this.undoClicked.emit();
    }
}
