import { TenantGuard } from './tenant.guard';

describe('TenantGuard', () => {
  let guard: TenantGuard;
  let router: any;
  let oidc: any;

  beforeEach(() => {
    router = jasmine.createSpyObj('Router', ['parseUrl']);
    oidc = jasmine.createSpyObj('OpenIdConnectService', ['getCurrentWorkspaceId']);
    guard = new TenantGuard(router, oidc);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });

  it('should return true when valid tenant exists', () => {
    oidc.getCurrentWorkspaceId.and.returnValue('foo');
    expect(guard.canActivate(undefined, undefined)).toBe(true);
    expect(router.parseUrl).not.toHaveBeenCalled();
  });

  it('should redirect when invalid tenant exists', () => {
    oidc.getCurrentWorkspaceId.and.returnValue(undefined);
    guard.canActivate(undefined, undefined);
    expect(router.parseUrl).toHaveBeenCalled();
  });
});
