import React from 'react';


class About extends React.Component {
		
   render() {
      return (
         <div>
			
			<h2>About Page</h2>
		</div>
      );
   }
}

export default About;