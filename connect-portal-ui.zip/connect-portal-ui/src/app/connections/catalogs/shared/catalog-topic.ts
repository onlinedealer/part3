export interface CatalogTopic {
  lastCompleted: string;
  topic: string;
  status: string;
  triggeredAt: string;
}
