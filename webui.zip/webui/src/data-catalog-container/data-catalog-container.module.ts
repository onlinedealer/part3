import { NgModule } from '@angular/core';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { DatasetsModule } from 'dqcore-catalog';
import { DataCatalogContainerComponent } from './data-catalog-container.component';
import { DataCatalogContainerRoutingModule } from './data-catalog-container-routing.module';
import { SharedModule } from 'discovery-shared';
import { catalogLoader, dataCatalogLoader, sharedLoader } from 'core/i18n-loaders';

@NgModule({
  declarations: [DataCatalogContainerComponent],
  imports: [SharedModule, DataCatalogContainerRoutingModule, DatasetsModule],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'discoveryDataCatalog', loader: dataCatalogLoader },
        { scope: 'discoveryShared', loader: sharedLoader },
        { scope: 'catalog', loader: catalogLoader }
      ]
    }
  ]
})
export class DataCatalogContainerModule {}
