import { AfterViewInit, Component, EventEmitter, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { of, Subscription } from 'rxjs';
import { mergeMap } from 'rxjs/operators';
import { SidebarButton } from '../../shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';
import { ProjectCommitResponse } from '../pipeline/shared/project-commit-response';
import { ProjectsApiService } from '../pipeline/shared/projects-api.service';
import { DeployInfo } from '../shared/deploy-configuration-form/deploy-info';
import { PipelinesMonitoringApiService } from '../shared/pipelines-monitoring-api.service';
import { ValidateConfigurationSidebarComponent } from '../shared/validate-configuration-sidebar/validate-configuration-sidebar.component';
import { ResourcePermissionService } from '../../shared/services/resource-permission.service';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { DeployConfigurationFormComponent } from '../shared/deploy-configuration-form/deploy-configuration-form.component';
import { Project } from '../pipeline/shared/project';
import { PipelineService } from '../pipeline/pipeline.service';

/**
 * Component that is used to apply or deploy project configuration changes
 */
@Component({
  selector: 'p-connect-apply-configuration-sidebar',
  templateUrl: './apply-configuration-sidebar.component.html'
})
export class ApplyConfigurationSidebarComponent implements OnInit, OnDestroy, AfterViewInit {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(ValidateConfigurationSidebarComponent) validateConfigurationSidebarComponent: ValidateConfigurationSidebarComponent;
  @ViewChild(DeployConfigurationFormComponent) deployConfigurationFormComponent: DeployConfigurationFormComponent;
  @Output() isAlertsVisibleChange = new EventEmitter<boolean>();

  /**
   * Tempoary flag used to determine if the incremental commit feature is enabled
   */
  isIncrementalCommitFeatureEnabled = false;

  primaryButton: SidebarButton = {
    id: 'applyButton',
    text: 'pipelines.APPLY_CONFIGURATION_SIDEBAR.BUTTONS.APPLY',
    isDisabled: false
  };

  cancelButton: SidebarButton = {
    id: 'cancelButton',
    text: 'pipelines.APPLY_CONFIGURATION_SIDEBAR.BUTTONS.CANCEL'
  };

  applyConfigurationFormGroup: FormGroup;
  applyFormValueChanges$: Subscription;
  anyPipelinesComitted = false;
  containsDB2ZOSSources = false;
  projectName = '';
  projectDescription = '';
  private projectId = '';

  /**
   * Is stage changes checkbox checked
   */
  get stageChanges(): boolean {
    return this.applyConfigurationFormGroup.get('stageChanges')?.value;
  }

  /**
   * @Internal
   * @param formBuilder Form builder used to create the form
   * @param projectsApiService Projects API service
   * @param pipelinesMonitoringApiService Pipelines monitoring API service
   * @param resourcePermissionService  Resource permission service
   * @param featureFlagService Feature flag service
   */
  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly projectsApiService: ProjectsApiService,
    private readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService,
    private readonly resourcePermissionService: ResourcePermissionService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly pipelineService: PipelineService
  ) {}

  /**
   * @Internal
   */
  ngOnDestroy(): void {
    this.applyFormValueChanges$.unsubscribe();
  }

  /**
   * @Internal
   */
  ngOnInit(): void {
    this.pipelineService?.deployProjectApplyConfiguration?.subscribe((response) => {
      this.handleCommitCompletedEvent(response.projectId, response.commitResponse);
    });
    this.createForm();
  }

  /**
   * @Internal
   */
  ngAfterViewInit(): void {
    this.isIncrementalCommitFeatureEnabled = this.featureFlagService.isFeatureEnabled('CDCIncrementalCommitTemp20220822');
    this.applyFormValueChanges$ = this.applyConfigurationFormGroup.valueChanges.subscribe({
      next: () => {
        const invalidDeployForm =
          this.applyConfigurationFormGroup.controls.deployChangesFormGroup.invalid &&
          this.applyConfigurationFormGroup.controls.deployChangesFormGroup.get('makeChangesActive').value;
        const allOptionsDisabled =
          !this.applyConfigurationFormGroup.get('stageChanges')?.value &&
          !this.applyConfigurationFormGroup.controls.deployChangesFormGroup.get('makeChangesActive').value;
        this.primaryButton.isDisabled = invalidDeployForm || allOptionsDisabled;
      }
    });
  }

  /**
   * Creates the form that contains the settings for the apply configuration sidebar
   */
  createForm(): void {
    this.applyConfigurationFormGroup = this.formBuilder.group({
      stageChangesFormGroup: this.formBuilder.group({}),
      deployChangesFormGroup: this.formBuilder.group({})
    });
  }

  /**
   * Opens the apply configuration sidebar
   * @param pipelines The pipelines where changes are being applied
   * @param project The project where changes are being applied
   */
  open(pipelines: any[], project: Project): void {
    this.projectName = project.name;
    this.projectDescription = project.description;
    this.projectId = project.id;
    this.containsDB2ZOSSources = pipelines.some((pipeline) => this.checkForDb2zConnections(pipeline));
    this.anyPipelinesComitted = pipelines.some((pipeline) => pipeline.hasOwnProperty('runtimeServerStatus'));
    if (this.resourcePermissionService.hasResourcePermission('PIPELINE.DEPLOY')) {
      this.deployConfigurationFormComponent.open();
    }
    this.sidebarComponent.open();
  }

  /**
   * Primary button click handler
   */
  primaryButtonClicked(): void {
    this.sidebarComponent.isProcessingRequest = true;
    let projectId;
    this.projectsApiService
      .getDefaultProject()
      .pipe(
        mergeMap((project) => {
          projectId = project.id;

          // need a better way here of handling these requests, for example if commit is disabled but deploy isn't
          if (this.resourcePermissionService.hasResourcePermission('PIPELINE.STAGE') && this.stageChanges) {
            if (this.isIncrementalCommitFeatureEnabled) {
              return this.projectsApiService.commit(projectId, false, this.applyConfigurationFormGroup.get('setStage').value);
            } else {
              return this.projectsApiService.commit(projectId);
            }
          } else {
            return of({ isCommited: true });
          }
        })
      )
      .subscribe({
        next: async (commitResponse: ProjectCommitResponse) => {
          if (
            this.featureFlagService.isFeatureEnabled('CDCAsyncCommitTemp20221110') &&
            this.resourcePermissionService.hasResourcePermission('PIPELINE.STAGE') &&
            this.stageChanges
          ) {
            this.getCommitStatus(projectId);
          } else {
            this.handleCommitCompletedEvent(projectId, commitResponse);
          }
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
          this.sidebarComponent.isProcessingRequest = false;
        }
      });
  }

  /**
   * Handles the cancel button click event
   */
  cancelButtonClicked(): void {
    this.sidebarComponent.close();
  }

  downloadJclCompleted(errorResponse): void {
    if (errorResponse) {
      this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
    }
  }

  /**
   * Gets the commit status for a project - Part of the async commit feature
   * @param projectId The project ID
   */
  private getCommitStatus(projectId: string) {
    this.sidebarComponent.isProcessingRequest = false;
    this.validateConfigurationSidebarComponent.openCommitValidationAsync(projectId, '');
  }

  /**
   * Handles the commit completed event
   * @param projectId The project ID
   * @param commitResponse The commit response
   */
  private async handleCommitCompletedEvent(projectId: string, commitResponse: any): Promise<void> {
    if (!commitResponse.isCommited) {
      this.sidebarComponent.isProcessingRequest = false;
      this.sidebarComponent.close();
      this.validateConfigurationSidebarComponent.open(commitResponse, this.projectName, this.projectDescription, this.projectId);
    } else {
      const deployForm = this.applyConfigurationFormGroup.controls.deployChangesFormGroup;
      const deployInfo: DeployInfo = {
        queueTimeoutInMinutes: deployForm.get('backlogEmpty').value,
        tableCaptureTimeoutInMinutes: deployForm.get('tableCaptureDisabled').value,
        stopRequestTimeoutInMinutes: deployForm.get('replicationStopped').value,
        forceDeploy: deployForm.get('forceDeploy').value
      };
      if (
        this.resourcePermissionService.hasResourcePermission('PIPELINE.DEPLOY') &&
        deployForm.enabled &&
        deployForm.get('makeChangesActive').value
      ) {
        await this.pipelinesMonitoringApiService
          .deploy(projectId, deployInfo)
          .toPromise()
          .then(() => {
            this.sidebarComponent.isProcessingRequest = false;
            this.sidebarComponent.close();

            if (deployForm.get('monitorProgress').value) {
              this.isAlertsVisibleChange.emit(true);
            }
          })
          .catch((errorResponse) => {
            this.sidebarComponent.isProcessingRequest = false;
            this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
          });
      }

      this.sidebarComponent.isProcessingRequest = false;
      this.sidebarComponent.close();
    }
  }

  /**
   * Checks if a pipeline contains DB2 for z/OS connections
   * @param pipeline The pipeline to check for DB2 for z/OS connections
   * @returns true if the pipeline contains DB2 for z/OS connections
   */
  private checkForDb2zConnections(pipeline): boolean {
    // check for db2z for pipelines that have not been deleted and so are in the dataflows API (config)
    const isReplicationPipeline = pipeline.dataFlowType !== 'COPY';
    if (pipeline.hasOwnProperty('source')) {
      return pipeline.source.dataConnection?.connectionType === 'DB2ZOS' && isReplicationPipeline;
    }

    // check for db2z on pipelines that are in monitoring API only
    if (pipeline.hasOwnProperty('runtimeServers')) {
      return pipeline.runtimeServers.some((runtimeServer) => {
        return runtimeServer.dataConnections.some((dataConnection) => dataConnection.connectionType === 'DB2ZOS') && isReplicationPipeline;
      });
    }

    return false; // default return false
  }
}
