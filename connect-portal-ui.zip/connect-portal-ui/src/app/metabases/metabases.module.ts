import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { MetabasesComponent } from './metabases.component';
import { MetabaseSidebarComponent } from './metabase-sidebar/metabase-sidebar.component';
import { MetabasesRoutingModule } from './metabases-routing.module';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DeleteMetabaseSidebarComponent } from './delete-metabase-sidebar/delete-metabase-sidebar.component';
import { DialogModule } from 'primeng/dialog';
import { DB2IMetabaseFormComponent } from './metabase-sidebar/metabase-form/db2i-metabase-form/db2i-metabase-form.component';
import { MetabaseFormComponent } from './metabase-sidebar/metabase-form/metabase-form.component';
import { OracleMetabaseFormComponent } from './metabase-sidebar/metabase-form/oracle-metabase-form/oracle-metabase-form.component';
import { DB2MetabaseFormComponent } from './metabase-sidebar/metabase-form/db2-metabase-form/db2-metabase-form.component';
import { SqlServerMetabaseFormComponent } from './metabase-sidebar/metabase-form/sqlserver-metabase-form/sqlserver-metabase-form.component';
import { MetabaseDetailsSidebarComponent } from './metabase-details-sidebar/metabase-details-sidebar.component';
import { MetabaseDetailsFormComponent } from './metabase-details-sidebar/metabase-details-form/metabase-details-form.component';
import { commonLoader, connectionsLoader, metabasesLoader } from '../i18n-loaders';
import { UpgradeMetabaseSidebarComponent } from './upgrade-metabase-sidebar/upgrade-metabase-sidebar.component';
import { UpgradeMetabaseFormComponent } from './upgrade-metabase-sidebar/upgrade-metabase-form/upgrade-metabase-form.component';
import { TooltipModule } from 'primeng/tooltip';
import { DeleteMetabaseFormComponent } from './delete-metabase-sidebar/delete-metabase-form/delete-metabase-form.component';

@NgModule({
  declarations: [
    MetabaseSidebarComponent,
    MetabasesComponent,
    OracleMetabaseFormComponent,
    MetabaseFormComponent,
    DB2IMetabaseFormComponent,
    DeleteMetabaseSidebarComponent,
    DB2MetabaseFormComponent,
    SqlServerMetabaseFormComponent,
    MetabaseDetailsSidebarComponent,
    MetabaseDetailsFormComponent,
    UpgradeMetabaseSidebarComponent,
    UpgradeMetabaseFormComponent,
    DeleteMetabaseFormComponent
  ],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'connections', loader: connectionsLoader },
        { scope: 'metabases', loader: metabasesLoader }
      ]
    }
  ],
  imports: [
    MetabasesRoutingModule,
    CommonModule,
    SharedModule,
    TranslocoModule,
    FormsModule,
    ReactiveFormsModule,
    DropdownModule,
    CheckboxModule,
    DialogModule,
    RadioButtonModule,
    TooltipModule
  ],
  exports: [MetabaseSidebarComponent]
})
export class MetabasesModule {}
