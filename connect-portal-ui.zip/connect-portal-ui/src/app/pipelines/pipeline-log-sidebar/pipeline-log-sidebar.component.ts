import { Component, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { AirbyteApiService } from '../pipeline/shared/airbyte-api.service';
import { TranslocoService } from '@ngneat/transloco';
import { MessageService } from 'primeng/api';

@Component({
  selector: 'p-connect-pipeline-log-sidebar',
  templateUrl: './pipeline-log-sidebar.component.html'
})
export class PipelineLogSidebarComponent {
  pipelineLogs: string;
  isLoading = true;

  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  primaryButton: SidebarButton = {
    isHidden: true
  };

  cancelButton: SidebarButton = {
    id: 'PipelineLogSidebarCloseButton',
    text: 'pipelines.PIPELINE_LOG_SIDEBAR.BUTTONS.CLOSE_BUTTON'
  };

  constructor(
    private readonly airbyteApiService: AirbyteApiService,
    private readonly translocoService: TranslocoService,
    private messageService: MessageService
  ) {}

  open(pipelineId: string, runId?: string): void {
    this.airbyteApiService.getLogs(pipelineId, runId).subscribe({
      next: (res) => {
        const enc = new TextDecoder('utf-8');
        this.pipelineLogs = enc.decode(res);
        this.isLoading = false;
      },
      error: () => {
        const errMsg: string = this.translocoService.translate('pipelines.PIPELINE_LOG_SIDEBAR.LOG_NOT_FOUND');
        this.messageService.add({ severity: 'error', detail: errMsg });
        this.sidebarComponent.close();
      }
    });

    this.sidebarComponent.open();
  }

  closeButtonClicked() {
    this.sidebarComponent.close();
  }
}
