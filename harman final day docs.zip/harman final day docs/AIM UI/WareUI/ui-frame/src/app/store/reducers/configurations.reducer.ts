import { Action, createReducer, on } from "@ngrx/store";
import { ConfigurationsActions } from "../actions";
import { ChangeUiConfigurationSettingsPayload, SetSystemTimeZonePayload } from "../actions/configurations.actions";
import { environment } from "../../../environments/environment";

export const configurationAvailableDateFormats = new Map<string, { format: string; separator: string }>([
    ["DD/MM/YYYY", { format: "DD/MM/YYYY", separator: "/" }],
    ["DD.MM.YYYY", { format: "DD.MM.YYYY", separator: "." }],
    ["DD-MM-YYYY", { format: "DD-MM-YYYY", separator: "-" }]
]);
export interface DateFormatConfiguration {
    dateFormatWithTime: string;
    dateFormatWithTimeWithoutYear: string;
    dateFormatWithoutTime: string;
    dateFormatWithoutYearTime: string;
    dateFormatWithoutSeconds: string;
    timeFormat: string;
    timeFormatNoSeconds: string;
    dateFormatWithoutDate: string;
    dateFormatWithOnlyYear: string;
    dateWithOnlyMonth: string;
    default: string;
}

export interface UiConfiguration {
    userLocale?: string;
    systemLocale: string;
    dateFormat: { separator: string; format: string };
    timeFormat: string;
    hours: "12" | "24";
    timeZoneInUse?: string;
    redirectingLocale?: string;
}

export interface TimeZoneConfiguration {
}

export interface ConfigurationsState {
    gettingWindowDefinedConfiguration: boolean;
    userSettingsUrl: string;
    windowConfigurationProvided: UiConfiguration | undefined;
    uiConfiguration: UiConfiguration;
}

export const initialState: ConfigurationsState = {
    gettingWindowDefinedConfiguration: false,
    windowConfigurationProvided: undefined,
    userSettingsUrl: `${environment.change_pass_word_url}changePassword?successUrl=${environment.application_url}`,
    uiConfiguration: {
        systemLocale: "en",
        dateFormat: { format: "DD/MM/YYYY", separator: "/" },
        timeFormat: "H:mm:ss",
        hours: "24",
        timeZoneInUse: ""
    }
};

const configurationsReducer = createReducer(
    initialState,
    on(ConfigurationsActions.UIConfigurationNeedsLocaleRedirection, (state, action) => {
        return { ...state, redirectingLocale: action.newLocale };
    }),
    on(ConfigurationsActions.SetSystemTimeZone, setSystemTimeZoneInformation),
    on(ConfigurationsActions.LoadWindowDefinedConfiguration, loadWindowConfiguration),
    on(ConfigurationsActions.LoadWindowDefinedConfigurationFailed, loadWindowConfigurationFailed),
    on(ConfigurationsActions.LoadWindowDefinedConfigurationSuccess, loadWindowConfigurationSuccess),
    on(ConfigurationsActions.ChangeUiConfigurationSettings, changeUiSettings)
);

export function reducer(state: ConfigurationsState = initialState, action: Action): ConfigurationsState {
    return configurationsReducer(state, action);
}

function loadWindowConfiguration(state: ConfigurationsState): ConfigurationsState {
    return {
        ...state,
        gettingWindowDefinedConfiguration: true
    };
}

function loadWindowConfigurationFailed(state: ConfigurationsState): ConfigurationsState {
    return {
        ...state,
        gettingWindowDefinedConfiguration: false
    };
}

function loadWindowConfigurationSuccess(state: ConfigurationsState, payload: ChangeUiConfigurationSettingsPayload): ConfigurationsState {
    const copied = { ...payload };
    delete (copied as any).type;
    return {
        ...state,
        gettingWindowDefinedConfiguration: false,
        uiConfiguration: {
            ...state.uiConfiguration,
            ...copied
        }
    };
}

function setSystemTimeZoneInformation(state: ConfigurationsState, payload: SetSystemTimeZonePayload): ConfigurationsState {
    return {
        ...state,
        uiConfiguration: {
            ...state.uiConfiguration
        }
    };
}

function changeUiSettings(state: ConfigurationsState, payload: ChangeUiConfigurationSettingsPayload): ConfigurationsState {
    const copied = { ...payload };
    delete (copied as any).type;
    return {
        ...state,
        uiConfiguration: {
            ...state.uiConfiguration,
            ...copied
        }
    };
}
