import { Component, Input, OnInit } from '@angular/core';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { EventBusService } from 'core/eventBusService';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-donut-custom-legends',
  templateUrl: './donut-custom-legends.component.html',
  styleUrls: ['./donut-custom-legends.component.scss']
})
export class DonutCustomLegendsComponent implements OnInit {
  @Input()
  legendDetails: string[];
  legendsData: Array<{ label: string; color: string; key: string }> = [];
  @Input()
  keys: string[];

  constructor(private eventBusService: EventBusService, public httpUtil: HttpUtilService) {}

  ngOnInit(): void {
    for (const [index, legend] of this.legendDetails.entries()) {
      this.legendsData.push({
        label: legend,
        color: ProfilingConstants.FREQUENCYCHARTCOLORS[index],
        key: legend.split(' (')[0]
      });
    }
  }

  launchTrendsSidebar(stat: string) {
    this.eventBusService.emit('TrendsSidebarToggle', { flag: true, stat: stat });
  }
}
