import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import FormHelperText from '@material-ui/core/FormHelperText'
import Tooltip from '@material-ui/core/Tooltip'
import RemoveIcon from '@material-ui/icons/RemoveCircle'
import IconButton from '@material-ui/core/IconButton'
import AddCircle from '@material-ui/icons/AddCircle'
import { getThemesOptions, getFixedThemesOptions } from '../Utils/CommonUtils'
import Button from '@material-ui/core/Button'
import IntegrationReactSelect from '../GrouperAutoComplete/IntegrationReactSelect'
import UpIcon from '@material-ui/icons/KeyboardArrowUp'
import DownIcon from '@material-ui/icons/KeyboardArrowDown'

const styles = theme => ({
  themeRoot: {
    width: '100%',
  },
  helperText: {
    marginTop: 8,
  },
  IconButton: {
    width: '100%',
    height: '100%',
    '&:hover': {
      background: 'transparent',
    },
  },
  iconColor: {
    color: '#1976d2',
  },
  addThemeIcon: {
    color: '#1976d2',
    width: 15,
    paddingRight: 5,
  },
  addThemeButtonStyle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#1976d2',
    padding: 0,
    '&:hover': {
      background: 'none',
    },
  },
  iconButton: {
    marginLeft: '5px',
    marginTop: '5px',
    height: 24,
    width: 24,
    color: '#1976d2',
    verticalAlign: 'top',
    display: 'block',
  },
  saveIconDisabled: {
    color: '#ccc',
  },
  curIndexBlock: {
    paddingTop: 30,
    flexBasis: '5%',
  },
})

function ThemeFieldUpdate (props) {
  const isMultiple = false
  const fixedThemeColumId = props.id + '-fixed_theme_id'
  const mtaColumnId = props.id + '-id'
  return (
    <div className={props.classes.themeRoot}>
      <Grid item xs={12} className={props.classes.field}>
        <Grid container style={{flexDirection: 'row'}}>
          <Grid item xs={1} className={props.classes.curIndexBlock}>
            {props.curTheme}
          </Grid>
          <Grid item xs={9} style={{flexBasis: '25%'}}>
            <IntegrationReactSelect
              currentValue={props.fixedValue}
              column_id={fixedThemeColumId}
              options={getFixedThemesOptions(props.fixedThemes)}
              isMultiOption={isMultiple}
              handleSelectChange={props.handleSelectChange}
              labeledMsg={props.fixedThemePlaceholder}
              pageFrom="theme update"
            />
          </Grid>
          <Grid item xs={9} style={{flexBasis: '52%', marginLeft: 5}}>
            <IntegrationReactSelect
              currentValue={props.value}
              column_id={mtaColumnId}
              options={getThemesOptions(props.themes)}
              isMultiOption={isMultiple}
              handleSelectChange={props.handleSelectChange}
              labeledMsg={props.placeholder}
              pageFrom="theme update"
            />
          </Grid>
          <Grid item xs={1}>
            {props.firstNode ? (
              <IconButton color="inherit" className={props.classes.iconButton} component="div"><UpIcon className={props.classes.saveIconDisabled} /></IconButton>
            ) : (
              <IconButton color="inherit" className={props.classes.iconButton} component="div" onClick={(e) => props.moveTheme('Up', props.value)}><UpIcon className={props.classes.saveIcon} /></IconButton>
            )}
            {props.lastNode ? (
              <IconButton color="inherit" className={props.classes.iconButton} component="div"><DownIcon className={props.classes.saveIconDisabled} /></IconButton>
            ) : (
              <IconButton color="inherit" className={props.classes.iconButton} component="div" onClick={(e) => props.moveTheme('Down', props.value)}><DownIcon className={props.classes.saveIcon} /></IconButton>
            )}
          </Grid>
          { props.isRemoveRequired && <Grid item xs={1} >
            <Tooltip id="tooltip-icon" title="Remove Theme">
              <IconButton color="primary" aria-label="remove" className={props.classes.IconButton} onClick={(e) => props.removeThemesField(props.id)} >
                <RemoveIcon className={props.classes.iconColor} />
              </IconButton>
            </Tooltip>
          </Grid>}
        </Grid>
        {(props.id === 'theme1' && props.errors.theme1) && <FormHelperText error className={props.classes.helperText}>{props.errors.theme1}</FormHelperText>}
      </Grid>
      { props.isAddRequired &&
        <Grid item xs={12} style={{flexBasis: '2%'}}>
          <Button className={props.classes.addThemeButtonStyle} onClick={props.addThemesField}>
            <AddCircle className={props.classes.addThemeIcon} /> ADD THEME
          </Button>
        </Grid>
      }
    </div>
  )
}

export default withStyles(styles)(ThemeFieldUpdate)
