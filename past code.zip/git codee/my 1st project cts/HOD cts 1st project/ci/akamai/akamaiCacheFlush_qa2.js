#! /usr/bin/env node

path = require('path'),
  os = require('os'),
  prettyJSON = require('prettyjson'),
  argv = require('minimist')(process.argv.slice(2));

// Akamai EdgeGrid signing library
var EdgeGrid = require('edgegrid');

// Optional command-line arguments
var debug = argv.debug ? true : false;
var verbose = argv.verbose ? true : false;
var headers = argv.headers ? argv.headers : {};

// The path to the .edgerc file to use for authentication
var edgercPath = argv.edgeRc ? argv.edgeRc : path.join(os.homedir(), '/.edgerc');

// The section of the .edgerc file to use for authentication
var sectionName = 'default';

// Create a new instance of the EdgeGrid signing library
var eg = new EdgeGrid({
  path: edgercPath,
  section: sectionName,
  debug: debug
});

/**
 * Adds item to be invalidated.
 */
function invalidate() {

  purgeObj = {
    'objects': [
      'https://www-qa4.cvs.com/minuteclinic/index.html',
      'https://m-qa4.cvs.com/minuteclinic/index.html'
    ]
  };

  console.info('Adding data to queue: ' + JSON.stringify(purgeObj));

  eg.auth({
    path: '/ccu/v3/invalidate/url',
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: purgeObj
  });

  eg.send(function(data) {
    data = JSON.parse(data);
    console.info('Response: ', data);
  });
}

invalidate();
