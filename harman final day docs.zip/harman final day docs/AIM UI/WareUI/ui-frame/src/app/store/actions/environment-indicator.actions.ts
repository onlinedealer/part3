import { createAction, props } from "@ngrx/store";
import { EnvironmentIndicator } from "../../models/environment-indicator.model";

export const LoadEnvironmentIndicator = createAction("[Test/Production Environment Indicator] Load Test/Production Environment Indicator");
export const LoadEnvironmentIndicatorSuccess = createAction(
    "[Test/Production Environment Indicator] Load Test/Production Environment Indicator Success",
    props<{ response: EnvironmentIndicator }>()
);
export const LoadEnvironmentIndicatorFailure = createAction(
    "[Test/Production Environment Indicator] Load Test/Production Environment Indicator Failure",
    props<{ error: any }>()
);
