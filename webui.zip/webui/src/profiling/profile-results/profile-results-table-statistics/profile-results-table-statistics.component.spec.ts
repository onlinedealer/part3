/* eslint-disable quote-props */
import { Spies } from 'discovery-test';
import { SortEvent } from 'primeng/api';
import { TreePath, Types } from './../tree-path.model';
import { ProfileResultsTableStatisticsComponent } from './profile-results-table-statistics.component';

describe('ProfileResultsTableStatisticsComponent', () => {
  let component: ProfileResultsTableStatisticsComponent;
  let mockEvent: SortEvent;
  let mockResult;
  let mockItem1, mockItem2, mockItem3: { column: string; count: number };

  beforeEach(() => {
    Spies.init();
    component = new ProfileResultsTableStatisticsComponent(Spies.TranslateService);
    mockItem1 = {
      column: '97.16',
      count: 6
    };
    mockItem2 = {
      column: '1097.16',
      count: 2
    };
    mockItem3 = {
      column: '96.602',
      count: 1
    };
    mockResult = [
      {
        column: '96.602',
        count: 1
      },
      {
        column: '197.16',
        count: 1
      },
      {
        column: '1097.16',
        count: 2
      },
      {
        column: '99.176',
        count: 2
      },
      {
        column: '96.44',
        count: 4
      },
      {
        column: '97.16',
        count: 6
      }
    ];
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with FrequencyStatistics', () => {
    component.defaultSort = 'count';
    component.statistics = {
      type: 'FrequencyStatistics',
      frequency: {
        'Suite S': 971566,
        'Suite G': 971090
      }
    } as any;
    component.treePath = new TreePath();
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.data.length).toEqual(2);
    expect(component.data[0].column).toMatch('Suite S');
    expect(component.data[0].count).toEqual(971566);
  });

  it('Initialize ngOnInit with StringLengthFrequencyStatistics', () => {
    component.defaultSort = 'count';
    component.statistics = {
      type: 'StringLengthFrequencyStatistics',
      frequency: {
        '7': 24738741,
        '9': 19395182,
        '8': 4365827
      }
    } as any;

    component.treePath = new TreePath();
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.data.length).toEqual(3);
    expect(component.data[0].length).toMatch('7');
    expect(component.data[0].count).toEqual(24738741);
  });

  it('Initialize ngOnInit with ScriptDistributionStatistics', () => {
    component.defaultSort = 'count';
    component.statistics = {
      type: 'ScriptDistributionStatistics',
      frequency: {
        Han: 10,
        Latin: 9,
        Common: 5
      }
    } as any;

    component.treePath = new TreePath();
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.data.length).toEqual(3);
    expect(component.data[0].script).toMatch('Han');
    expect(component.data[0].count).toEqual(10);
  });
  it('Custom Sort should sort correctly', () => {
    mockEvent = { data: mockResult, field: 'count', order: 1 };
    component.customSort(mockEvent);
    expect(mockEvent.data[0]).toEqual(mockItem1);

    mockEvent.order = -1;
    component.customSort(mockEvent);
    expect(mockEvent.data[0]).toEqual(mockItem3);

    mockEvent = { data: mockResult, field: 'column', order: 1 };
    component.customSort(mockEvent);
    expect(mockEvent.data[0]).toEqual(mockItem2);
  });
});
