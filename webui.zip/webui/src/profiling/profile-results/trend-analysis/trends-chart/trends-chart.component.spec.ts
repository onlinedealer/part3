import { Spies } from 'discovery-test';
import { TrendsChartComponent } from './trends-chart.component';

describe('TrendsChartComponent', () => {
  let component: TrendsChartComponent;

  beforeEach(() => {
    component = new TrendsChartComponent(Spies.TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load chart Options and chart Data on init', () => {
    component.ngOnInit();
    expect(component.data).toBeDefined();
    expect(component.options).toBeDefined();
  });

  it('should check loadChartData', () => {
    component.stat = 'Incomplete Rows';
    component.trends = [
      {
        startTime: '2022-08-08T06:43:53.764Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T11:14:45.386Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T12:15:54.707Z',
        value: '0.0'
      }
    ];
    component.loadChartData();
    expect(component.data.labels.length).toEqual(3);
  });

  it('should check loadChartOptions', () => {
    component.trends = [
      {
        startTime: '2022-08-08T06:43:53.764Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T11:14:45.386Z',
        value: '0.0'
      },
      {
        startTime: '2022-08-08T12:15:54.707Z',
        value: '0.0'
      }
    ];
    component.stat = 'Complete';
    component.ngOnInit();
    expect(component.options.scales.y.title.text).toBe(component.stat);
  });
});
