import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomePageComponent } from './home-page/home-page.component';
import { MultiOfferPageComponent } from './multi-offer-page/multi-offer-page.component';

const routes: Routes = [
  { path: 'extracare/home', component: HomePageComponent, data: {
      title: "Extracare Homepage",
      metatags: {
          'description': 'Extracare home page',
          'keywords': 'extracare',
      }
    } 
   },
   { path: 'webcontent/ng-extracare/extracare_leanNg6', component: HomePageComponent, data: {
      title: "Extracare Homepage",
      metatags: {
          'description': 'Extracare home page',
          'keywords': 'extracare',
      }
    } 
   },
  { path: 'webcontent/components/DRStC/src/dist', component: MultiOfferPageComponent , data: {
      title: "Extracare offerspage",
      metatags: {
          'description': 'Multiple coupon page',
          'keywords': 'multiple coupon',
      }
    } 
  },
  { path: '**', redirectTo: '' }
];
@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
