export interface EntityCardHeaderModel {
  fieldName: string;
  displayName: string;
  sortable?: boolean;
}
