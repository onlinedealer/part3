(function() {
    'use strict';

    FirstApp.controller("homeCtrl", ['$scope', '$ajaxFactory', '$rootScope', homeCtrl]);

    function homeCtrl($scope, $ajaxFactory, $rootScope) {

 
    }


})();
