import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PipelineConnectionsComponent } from './pipeline-connections.component';
import { DropdownModule } from 'primeng/dropdown';
import { ConnectionsApiService } from '../../../connections/shared/connections-api.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { PipelineConnectionsRoutingModule } from './pipeline-connections-routing.module';
import { PipelineConnectionsFormComponent } from './pipeline-connections-form/pipeline-connections-form.component';
import { KafkaTargetComponent } from './target-connections/kafka/kafka-target.component';
import { KafkaTargetOptionsComponent } from './target-connections/kafka/kafka-target-options/kafka-target-options.component';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { ConnectionsModule } from '../../../connections/connections.module';
import { SharedModule } from '../../../shared/shared.module';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { KafkaLargeObjectsComponent } from './target-connections/kafka/kafka-large-objects/kafka-large-objects.component';
import { KafkaOptionsComponent } from './target-connections/kafka/kafka-options/kafka-options.component';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { CatalogsModule } from 'src/app/connections/catalogs/catalogs.module';
import { ConnectionCatalogStatusComponent } from './pipeline-connections-form/shared/connection-catalog-status.component';
import { commonLoader, serversLoader, connectionsLoader, pipelinesLoader } from '../../../i18n-loaders';
import { TooltipModule } from 'primeng/tooltip';
import { ConnectionDropdownModule } from 'dqcore-catalog';

@NgModule({
  declarations: [
    PipelineConnectionsComponent,
    PipelineConnectionsFormComponent,
    KafkaTargetComponent,
    KafkaTargetOptionsComponent,
    KafkaOptionsComponent,
    KafkaLargeObjectsComponent,
    ConnectionCatalogStatusComponent
  ],
  providers: [
    ConnectionsApiService,
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'servers', loader: serversLoader },
        { scope: 'connections', loader: connectionsLoader },
        { scope: 'pipelines', loader: pipelinesLoader }
      ]
    }
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    DropdownModule,
    TranslocoModule,
    PipelineConnectionsRoutingModule,
    SharedModule,
    RadioButtonModule,
    CheckboxModule,
    TooltipModule,
    ConnectionsModule,
    AutoCompleteModule,
    CatalogsModule,
    ConnectionDropdownModule
  ],
  exports: [PipelineConnectionsComponent, ConnectionCatalogStatusComponent]
})
export class PipelineConnectionsModule {}
