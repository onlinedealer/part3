import { AlertProfileMetricsService } from './alert.profilemetrics.services';
import { Spies } from 'discovery-test';

describe('AlertProfileMetricsService', () => {
  let service: AlertProfileMetricsService;

  beforeEach(() => {
    Spies.init();
    service = new AlertProfileMetricsService(Spies.HttpClient, Spies.AuthenticationService, Spies.HttpUtilService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('can get account', () => {
    let trends: any;
    service
      .getTrendsHistory('1', 'Row Count', new Date('2022-3-12'), new Date('2022-3-18'))
      .subscribe((x) => (trends = x));

    expect(trends).toBeDefined();
  });
});
