import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { ExcludeusersFormComponent } from './excludeusers-form.component';

describe('ExcludeusersFormComponent', () => {
  let component: ExcludeusersFormComponent;
  let fixture: ComponentFixture<ExcludeusersFormComponent>;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [ExcludeusersFormComponent],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'logreaders' } }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ExcludeusersFormComponent);
    component = fixture.componentInstance;
    component.usersExcludedFromCapture = ['user1', 'user2', 'user3'];
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should add users to the usersExcludedFromCapture list', () => {
    component.users = 'user4';
    component.addButtonClicked();
    expect(component.usersExcludedFromCapture).toEqual(['user1', 'user2', 'user3', 'user4']);
  });
  it('should throw error if first character is a number', () => {
    component.users = '1user';
    const result = component.checkFirstCharacter();
    expect(result).toBe(true);
  });
  it('should throw error if user name already exists', () => {
    component.users = 'user1';
    const result = component.checkRepeatedUsers();
    expect(result).toBe(true);
  });
  it('should remove multiple items from userExcludedFromCapture', () => {
    component.selectedUsers = ['user1', 'user3'];
    component.removeButtonClicked();
    expect(component.usersExcludedFromCapture).toEqual(['user2']);
  });
});
