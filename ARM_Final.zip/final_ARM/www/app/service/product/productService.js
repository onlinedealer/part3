(function() {
	'use strict';

	angular.module('arm').factory('productService', ['serviceApi', 'SERVICE_TYPE', 'localStorageService', 'sqliteService', 'utility','GENERAL_CONFIG','$rootScope','$cordovaDialogs','ALERT_MESSAGE', productService]);

	function productService(serviceApi, SERVICE_TYPE, localStorageService, sqliteService, utility, GENERAL_CONFIG,$rootScope,$cordovaDialogs,ALERT_MESSAGE) {
		var serArr = {};

    serArr.productFamilyMod = function() {
      return {
        uiObject : {
          CreatedAt: null,
          CreatedBy: null,
          CreatedOn: null,
          IsDefault: false,
          IsDeleted: false,
          ModifiedAt: null,
          ModifiedBy: null,
          ModifiedOn: null,
          Sequence: null,
          Description: null,
          LobList: null,
          ModuleID: null,
          Name: "",
          Name_OL1: null,
          Name_OL2: null,
          OrganisationID: null,
          ProductFamilyID: 1,
          Products:[],
          ServerDateTime: "",
          UserID: null
        }
      }
    };

    serArr.productMod = function() {
      return {
        uiObject : {
          CreatedAt: null,
          CreatedBy: 1,
          CreatedOn: "",
          IsDefault: false,
          IsDeleted: false,
          ModifiedAt: null,
          ModifiedBy: 3,
          ModifiedOn: "",
          Sequence: null,
          AddedAttachments: [],
          Attachments:[],
          Description: "",
          Family: {
            CreatedAt: null,
            CreatedBy: null,
            CreatedOn: null,
            IsDefault: false,
            IsDeleted: false,
            ModifiedAt: null,
            ModifiedBy: null,
            ModifiedOn: null,
            Sequence: null,
            Description: null,
            LobList: null,
            ModuleID: null,
            Name: null,
            Name_OL1: null,
            Name_OL2: null,
            OrganisationID: null,
            ProductFamilyID: null,
            Products: null,
            ServerDateTime: null,
            UserID: null
          },
          IsActive: true,
          Name: "",
          Name_OL1: null,
          Name_OL2: null,
          OrganisationID: 0,
          ProductDocuments: [],
          ProductFamilyID: 1,
          ProductFamilyName: "",
          ProductID: 1,
          ProductImages: [],
          ProductOwnerEmail: null,
          ServerDateTime: null,
          UpdatedAttachments: []
        }
      }
    };

    serArr.productAttachmentMod = function() {
      return {
        uiObject : {
          CreatedAt: null,
          CreatedBy: 3,
          CreatedOn: "",
          IsDefault: false,
          IsDeleted: false,
          ModifiedAt: null,
          ModifiedBy: null,
          ModifiedOn: null,
          AddedFromSource: 0,
          AttachmentCategoryID: 1,
          AttachmentID: 4,
          AttachmentSize: "",
          Base64String: null,
          Contents: null,
          DeviceObjID: null,
          DocumentID: null,
          EntityID: 1,
          Extension: "",
          FileName: "",
          FilePath: "",
          IsShareable: false,
          MIMEContentType: "",
          ModuleID: 2,
          ParentDeviceObjID: null
        }
      }
    };

    // Adding All Product Family

    serArr.getProductFamily = function() {
            var headerconfig = {
                headers:
                          {
                              'ProductDateTime': utility.getDateStringInUTC(new Date())
                          }
            };

            var productFamilyURL = SERVICE_TYPE.PRODUCTFAMILY+'/'+$rootScope.loggedInUserID+'/1/1/NULL/1';

            return serviceApi.doGetWithoutData("LoadProductFamily",
                    productFamilyURL, headerconfig).then(function (response) {
                      return response;
                    });
    }

    // Getting All Attachments

    serArr.getAttachments = function(attachmentID) {
            var headerconfig = {
                headers:
                          {
                              'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                          }
            };

            var getAttachmentsURL = SERVICE_TYPE.GETATTACHMENT+'/'+attachmentID;

            return serviceApi.doGetWithoutData("LoadGetAttachments",
                    getAttachmentsURL, headerconfig).then(function (response) {
                      return response;
                    });
    }

    serArr.sqlProductFamilyAdd = function (objDealProdFamily) {
            var queryArr = [];

            var productFamilyDeleteQuery = "DELETE FROM ProductFamily";

            queryArr.push(
                  {
                      'Query': productFamilyDeleteQuery,
                      'Bindings': ""
                  });

            var queryVal = '';
            for (var i = 0; i < objDealProdFamily.length; i++) {
                if(i!=0)
                queryVal += ',';
                queryVal += "('" + objDealProdFamily[i].CreatedAt + "','" + objDealProdFamily[i].CreatedBy + "','" + objDealProdFamily[i].CreatedOn + "','" + objDealProdFamily[i].IsDefault + "','" + objDealProdFamily[i].IsDeleted + "','" + objDealProdFamily[i].ModifiedAt + "','" + objDealProdFamily[i].ModifiedBy + "','" + objDealProdFamily[i].ModifiedOn + "','" + objDealProdFamily[i].Description + "','" + objDealProdFamily[i].ModuleID + "','" + objDealProdFamily[i].Name + "','" + objDealProdFamily[i].Name_OL1 + "','" + objDealProdFamily[i].Name_OL2 + "','" + objDealProdFamily[i].OrganisationID + "','" + objDealProdFamily[i].ProductFamilyID + "','" + objDealProdFamily[i].UserID + "'," + $rootScope.loggedInUserID + ")";
            }

            var productFamilyQuery = "INSERT INTO ProductFamily (CreatedAt, CreatedBy, CreatedOn, IsDefault, IsDeleted, ModifiedAt, ModifiedBy, ModifiedOn, Description, ModuleID, Name, Name_OL1, Name_OL2, OrganisationID, ProductFamilyID, UserID, LoggedInUserID) VALUES" + queryVal;

            queryArr.push(
                  {
                      'Query': productFamilyQuery,
                      'Bindings': ""
                  });

            return sqliteService.multipleQueries(queryArr).then(function (result) {
            }, function (error) {
            });

        }

        // Adding Products

        serArr.sqlProductsAdd = function (objDealProdFamily) {
            var queryArr = [];

            var productsDeleteQuery = "DELETE FROM Products";

            queryArr.push(
                  {
                      'Query': productsDeleteQuery,
                      'Bindings': ""
                  });

            var queryVal = '';
            for (var i = 0; i < objDealProdFamily.length; i++) {
              for(var j=0;j<objDealProdFamily[i].Products.length;j++){
                if(queryVal!='')
                queryVal += ',';
                queryVal += "('" + objDealProdFamily[i].Products[j].CreatedAt + "','" + objDealProdFamily[i].Products[j].CreatedBy + "','" + objDealProdFamily[i].Products[j].CreatedOn + "','" + objDealProdFamily[i].Products[j].IsDefault + "','" + objDealProdFamily[i].Products[j].IsDeleted + "','" + objDealProdFamily[i].Products[j].ModifiedAt + "','" + objDealProdFamily[i].Products[j].ModifiedBy + "','" + objDealProdFamily[i].Products[j].ModifiedOn + "','" + objDealProdFamily[i].Products[j].Description + "','" + objDealProdFamily[i].Products[j].IsActive + "','" + objDealProdFamily[i].Products[j].Name + "','" + objDealProdFamily[i].Products[j].Name_OL1 + "','" + objDealProdFamily[i].Products[j].Name_OL2 + "','" + objDealProdFamily[i].Products[j].OrganisationID + "','" + objDealProdFamily[i].Products[j].ProductFamilyID + "','" + objDealProdFamily[i].Products[j].ProductFamilyName + "','" + objDealProdFamily[i].Products[j].ProductID + "','" + objDealProdFamily[i].Products[j].ProductOwnerEmail + "'," + $rootScope.loggedInUserID + ")";
              }
            }

            var productsQuery = "INSERT INTO Products (CreatedAt, CreatedBy, CreatedOn, IsDefault, IsDeleted, ModifiedAt, ModifiedBy, ModifiedOn, Description, IsActive, Name, Name_OL1, Name_OL2, OrganisationID, ProductFamilyID, ProductFamilyName, ProductID, ProductOwnerEmail, LoggedInUserID) VALUES" + queryVal;

            queryArr.push(
                  {
                      'Query': productsQuery,
                      'Bindings': ""
                  });

            return sqliteService.multipleQueries(queryArr).then(function (result) {
            }, function (error) {
            });

        }

        // Adding Attachments

        serArr.sqlProductAttachmentsAdd = function (objDealProdFamily) {
            var queryArr = [];

            for (var i = 0; i < objDealProdFamily.length; i++) {
              for(var j=0;j<objDealProdFamily[i].Products.length;j++){
                for(var k=0;k<objDealProdFamily[i].Products[j].Attachments.length;k++){

            var productsAttachmentsQuery = "INSERT INTO Attachments (CreatedAt, CreatedBy, CreatedOn, IsDefault, IsDeleted, ModifiedAt, ModifiedBy, ModifiedOn, AddedFromSource, AttachmentCategoryID, AttachmentID, AttachmentSize, Base64String, DeviceObjID, DocumentID, EntityID, Extension, FileName, IsShareable, MIMEContentType, ModuleID, ParentDeviceObjID, LoggedInUserID)"+
            "SELECT '" + objDealProdFamily[i].Products[j].Attachments[k].CreatedAt + "','" + objDealProdFamily[i].Products[j].Attachments[k].CreatedBy + "','" + objDealProdFamily[i].Products[j].Attachments[k].CreatedOn + "','" + objDealProdFamily[i].Products[j].Attachments[k].IsDefault + "','" + objDealProdFamily[i].Products[j].Attachments[k].IsDeleted + "','" + objDealProdFamily[i].Products[j].Attachments[k].ModifiedAt + "','" + objDealProdFamily[i].Products[j].Attachments[k].ModifiedBy + "','" 
            + objDealProdFamily[i].Products[j].Attachments[k].ModifiedOn + "','" + objDealProdFamily[i].Products[j].Attachments[k].AddedFromSource + "','" + objDealProdFamily[i].Products[j].Attachments[k].AttachmentCategoryID + "','" + objDealProdFamily[i].Products[j].Attachments[k].AttachmentID + "','" + objDealProdFamily[i].Products[j].Attachments[k].AttachmentSize + "','" + objDealProdFamily[i].Products[j].Attachments[k].Base64String + "','" + objDealProdFamily[i].Products[j].Attachments[k].DeviceObjID + "','" + objDealProdFamily[i].Products[j].Attachments[k].DocumentID + "','" + objDealProdFamily[i].Products[j].Attachments[k].EntityID + "','" + objDealProdFamily[i].Products[j].Attachments[k].Extension + "','" + objDealProdFamily[i].Products[j].Attachments[k].FileName + "','" + objDealProdFamily[i].Products[j].Attachments[k].IsShareable + "','" + objDealProdFamily[i].Products[j].Attachments[k].MIMEContentType + "','" + objDealProdFamily[i].Products[j].Attachments[k].ModuleID + "','" + objDealProdFamily[i].Products[j].Attachments[k].ParentDeviceObjID + "'," + $rootScope.loggedInUserID +
            " WHERE NOT EXISTS (SELECT 1 FROM Attachments WHERE AttachmentID ='" + objDealProdFamily[i].Products[j].Attachments[k].AttachmentID + "' )";;

            queryArr.push(
                  {
                      'Query': productsAttachmentsQuery,
                      'Bindings': ""
                  });
                }
              }
            }

            return sqliteService.multipleQueries(queryArr).then(function (result) {
            }, function (error) {
            });

        }

        // Getting All Product Family

        serArr.sqlGetAllProductFamily = function () {
            return sqliteService.query('SELECT * from ProductFamily WHERE LoggedInUserID= '+ $rootScope.loggedInUserID ).then(function (result) {
                return result;
            });
        }

        // Getting Products

        serArr.sqlGetAllProducts = function (productFamily, index) {
            var returnArr = [index];
            return sqliteService.query('SELECT * from Products WHERE ProductFamilyID="' + productFamily.ProductFamilyID + '" AND LoggedInUserID= '+ $rootScope.loggedInUserID).then(function (result) {
                returnArr.push(result);
                return returnArr;
            });
        }

         // Getting Attachments

        serArr.sqlGetAllAttachments = function (products, index1, index2) {
            var returnArr = [index1, index2];
            return sqliteService.query('SELECT * from Attachments WHERE EntityID="' + products.ProductID + '" AND LoggedInUserID= '+ $rootScope.loggedInUserID).then(function (result) {
                returnArr.push(result);
                return returnArr;
            });
        }

        // Update Attachments File Path

        serArr.sqlUpdateAttachmentPath = function (filePath, attachmentId) {

        var attachmentUpdateQuery = "UPDATE Attachments SET FilePath ='" + filePath + "'" +
                       " WHERE AttachmentID =" + attachmentId;

          return sqliteService.query(attachmentUpdateQuery
                             ).then(function (result) {
                                 //alert('sucess');
                                 return result;
                             });

      }

    // Set Selected Deal
    var selectedProduct = null;
    serArr.setSelectedProduct = function(product){
         selectedProduct = product;
    };

    // Get Selected Deal
    serArr.getSelectedProduct = function(){
         return selectedProduct;
    };

		return serArr;
	}

})();
