import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { UpgradeMetabaseFormComponent } from './upgrade-metabase-form/upgrade-metabase-form.component';
import { UpgradeMetabaseSidebarComponent } from './upgrade-metabase-sidebar.component';
import { MetadataApiService } from '../../pipelines/pipeline/data/schema-table-selector/metadata-api.service';

describe('UpgradeMetabaseSidebarComponent', () => {
  let component: UpgradeMetabaseSidebarComponent;
  let fixture: ComponentFixture<UpgradeMetabaseSidebarComponent>;
  let metabasesApiService: MetabasesApiService;
  let metadataApiService: MetadataApiService;

  @Component({
    selector: 'p-connect-upgrade-metabase-form',
    template: '',
    providers: [
      {
        provide: UpgradeMetabaseFormComponent,
        useClass: MockUpgradeMetabaseFormComponent
      }
    ]
  })
  class MockUpgradeMetabaseFormComponent {
    displayErrorMessage;
    open(selectedMetabase) {}
    upgradeMetabaseForm = new FormGroup({
      adminUserId: new FormControl('SYS'),
      adminUserPassword: new FormControl('')
    });
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      declarations: [UpgradeMetabaseSidebarComponent, MockUpgradeMetabaseFormComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UpgradeMetabaseSidebarComponent);
    metabasesApiService = TestBed.inject(MetabasesApiService);
    metadataApiService = TestBed.inject(MetadataApiService);
    spyOn(metabasesApiService, 'upgradeMetabase').and.returnValue(of([{ response: 'Upgraded metabase', id: '1' }]));
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the sidebar', () => {
    spyOn(component.upgradeMetabaseFormComponent, 'open').and.returnValue();
    spyOn(component.sidebarComponent, 'open').and.returnValue();
    component.open({});
    expect(component.upgradeMetabaseFormComponent.open).toHaveBeenCalled();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should close the sidebar and reset form', () => {
    spyOn(component.upgradeMetabaseFormComponent.upgradeMetabaseForm, 'reset');
    spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.cancelMetabaseButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
    expect(component.upgradeMetabaseFormComponent.displayErrorMessage).toBe(false);
    expect(component.errorMessage).toEqual('');
    expect(component.upgradeMetabaseFormComponent.upgradeMetabaseForm.reset).toHaveBeenCalled();
    expect(component.cancelButton.text).toEqual('common.BUTTONS.CANCEL');
  });

  it('should handle upgrading metabase successfully', fakeAsync(() => {
    spyOn(component.metabaseUpgradeEvent, 'emit').and.returnValue();
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    component.upgradeMetabaseFormComponent.selectedMetabase = {
      dataConnection: { id: '1', connectionType: 'ORACLE', accessFromServer: { name: 'MyServer' } }
    };
    component.upgradeMetabaseButtonClicked();
    tick();
    expect(metabasesApiService.upgradeMetabase).toHaveBeenCalled();
    expect(component.metabaseUpgradeEvent.emit).toHaveBeenCalled();
  }));

  it('should handle error when upgrading metabase', fakeAsync(() => {
    jasmine.getEnv().allowRespy(true);
    spyOn(metabasesApiService, 'upgradeMetabase').and.returnValue(
      throwError({ error: { detailedMessage: 'Installed metabase is already the latest version.' } })
    );
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    component.upgradeMetabaseFormComponent.selectedMetabase = {
      dataConnection: { id: '1', connectionType: 'DB2I', accessFromServer: { name: 'MyServer' } }
    };
    component.upgradeMetabaseButtonClicked();
    tick();
    expect(component.upgradeMetabaseFormComponent.displayErrorMessage).toBe(true);
    expect(component.primaryButton.isHidden).toBe(true);
    expect(component.cancelButton.text).toEqual('common.BUTTONS.CLOSE');
    expect(component.errorMessage).toEqual('Installed metabase is already the latest version.');
  }));

  it('should handle error encrypting password', fakeAsync(() => {
    jasmine.getEnv().allowRespy(true);
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(throwError({ error: '{"detailedMessage": "test failed" }' }));
    component.upgradeMetabaseFormComponent.selectedMetabase = {
      dataConnection: { id: '1', connectionType: 'ORACLE', accessFromServer: { name: 'MyServer' } }
    };
    component.upgradeMetabaseButtonClicked();
    tick();
    expect(component.upgradeMetabaseFormComponent.displayErrorMessage).toBe(true);
    expect(component.primaryButton.isHidden).toBe(true);
    expect(component.cancelButton.text).toEqual('common.BUTTONS.CLOSE');
  }));
});
