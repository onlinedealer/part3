import { CardListItemModel } from './card-list-item-model';

export class DigitalProfileModel {
    public firstName: string;
    public lastName: string;
    public ecMatchProfileCount: number;
    public email: string;
    public profileId: string;
    public carePassEnrollmentStatus: string;
    public rxTied: boolean;
    public extracareCardNumber: string;
    public ecTied: boolean;
    public ecMatchAccounts: string[] = [];
    public cardList: CardListItemModel[] = [];

    constructor(details: any) {
        const profile = details;
        this.firstName = profile.firstName;
        this.lastName = profile.lastName;
        this.ecMatchProfileCount = profile.ecMatchProfileCount;
        this.email = profile.email;
        this.profileId = profile.profileId;
        this.carePassEnrollmentStatus = profile.carePassEnrollmentStatus;
        this.rxTied = profile.rxTied;
        this.extracareCardNumber = profile.extracareCardNumber;
        this.ecTied = profile.ecTied;
        this.ecMatchAccounts = profile.ecMatchAccounts;

        if (profile.hasOwnProperty('cardList')) {
            profile['cardList'].forEach((listItem) => {
                this.cardList.push(new CardListItemModel(listItem));
            });
        }
    }
}
