import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormBuilder } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';

import { ChangeColumnMappingChangesTabComponent } from './change-column-mapping-changes-tab.component';

describe('ChangeColumnMappingChangesTabComponent', () => {
  let component: ChangeColumnMappingChangesTabComponent;
  let fixture: ComponentFixture<ChangeColumnMappingChangesTabComponent>;

  const changeMetaMockData = [
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'EXCLUDE',
      isChecked: true
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'EXCLUDE',
      isChecked: false
    }
  ];
  const changeMetaMockDataAllIncludedAndChecked = [
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true
    }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [ChangeColumnMappingChangesTabComponent],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } }, FormBuilder]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeColumnMappingChangesTabComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get Bulk Change Payload', () => {
    const getBulkChangePayload = spyOn(component, 'processMetaDataBulkChangePayload').and.returnValue();
    component.getBulkChangePayload();
    expect(getBulkChangePayload).toHaveBeenCalled();
  });

  it('should disable SaveButton If Unchecked all meta data and index is 0', () => {
    component.activeTabIndex = 0;
    const getBulkChangePayload = spyOn(component, 'getBulkChangePayload').and.returnValue({
      payload: [],
      mapColumns: ''
    });
    spyOn(component.disableSaveButton, 'emit');
    component.disableSaveButtonIfUnchecked();
    expect(getBulkChangePayload).toHaveBeenCalled();
    expect(component.disableSaveButton.emit).toHaveBeenCalled();
  });

  it('should disable SaveButton If Unchecked all meta data and index is 1', () => {
    component.activeTabIndex = 1;
    spyOn(component.disableSaveButton, 'emit');
    component.disableSaveButtonIfUnchecked();
    expect(component.disableSaveButton.emit).toHaveBeenCalled();
  });

  it('should enable UpdateDefaults button', () => {
    expect(component).toBeTruthy();
    spyOn(component.enableUpdateDefaultsButton, 'emit');
    component.enableUpdateDefaultsBtn();
    expect(component.enableUpdateDefaultsButton.emit).toHaveBeenCalled();
  });

  it('should check call row meta data checkbox', () => {
    component.changeMetaData = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'EXCLUDE',
        isChecked: true
      }
    ];
    component.changeMetaData.length = 1;
    component.rowMetaDataCheckAll();
    expect(component.changeMetaData[0].isChecked).toBe(true);
    expect(component.changeMetaData[0].cdcRowMetadataType).toBe('INCLUDE');
  });

  it('should emit dropdown values when it changes to select row metadata is select metadata', () => {
    const mockDropdownOption = { value: 'SELECT_ROW_METADATA', name: 'TEST' };
    component.changesTabFormGroup.controls.rowMetaDataDropdown.setValue(mockDropdownOption);
    component.changeMetaData = changeMetaMockDataAllIncludedAndChecked;
    const rowMetaDataCheckAllMethod = spyOn(component, 'rowMetaDataCheckAll').and.returnValue();
    component.onChangeDropDown();
    expect(component.changesTabFormGroup.controls.rowMetaDataDropdown.value).toEqual(mockDropdownOption);
    expect(component.metaDataCheckboxField).toBe(true);
    expect(rowMetaDataCheckAllMethod).toHaveBeenCalled();
    expect(component.changeMetaData.length).toEqual(changeMetaMockDataAllIncludedAndChecked.length);
  });

  it('should emit dropdown values when it changes to no row meta data', () => {
    component.changesTabFormGroup.value.rowMetaDataDropdown.value = 'NO_ROW_METADATA';
    component.changeMetaData = changeMetaMockData;
    const rowMetaDataCheckAll = spyOn(component, 'rowMetaDataCheckAll').and.returnValue();
    component.onChangeDropDown();
    expect(component.metaDataCheckboxField).toBe(false);
    expect(rowMetaDataCheckAll).toHaveBeenCalled();
    expect(component.changeMetaData[2].isChecked).toBe(false);
  });

  it('should emit dropdown values when it changes to row meta data', () => {
    component.changesTabFormGroup.value.rowMetaDataDropdown.value === 'SELECT_ROW_METADATA';
    component.onChangeDropDown();
    expect(component.metaDataCheckboxField).toBe(false);
  });

  it('should get ChangeTab Emitted Data', () => {
    component.getChangeTabEmittedData(changeMetaMockData);
    expect(component.changeMetaData).toEqual(changeMetaMockData);
  });

  it('should create MetaData Payload when click of Save button', () => {
    component.changeMetaData = changeMetaMockData;
    const mockRowMetaData = {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
      value: 'SELECT_ROW_METADATA'
    };
    component.changesTabFormGroup.controls[`rowMetaDataDropdown`].setValue(mockRowMetaData);
    component.processMetaDataPayload();
    expect(component.payloadForChanges['METADATA_USER_ID']).toEqual('EXCLUDE');
  });

  it('should create MetaData Payload when click of Save button when dropdown values is no row metadata', () => {
    component.changeMetaData = changeMetaMockData;
    const mockRowMetaData = {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_RO_METADATA',
      value: 'NO_ROW_METADATA'
    };
    component.changesTabFormGroup.controls[`rowMetaDataDropdown`].setValue(mockRowMetaData);
    component.processMetaDataPayload();
    expect(component.payloadForChanges['METADATA_USER_ID']).toEqual('EXCLUDE');
  });

  it('should create MetaData Payload when click of Save button for Bulk Change Payload', () => {
    component.changeMetaData = changeMetaMockData;
    component.payloadForBulkChanges = [];
    const mockRowMetaData = {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
      value: 'SELECT_ROW_METADATA'
    };
    component.changesTabFormGroup.controls[`rowMetaDataDropdown`].setValue(mockRowMetaData);
    component.processMetaDataBulkChangePayload();
    expect(component.payloadForChanges['METADATA_USER_ID']).toEqual(undefined);
  });

  it('should create MetaData Payload when click of Save button when dropdown values is no row metadata for Bulk Change Payload', () => {
    component.changeMetaData = changeMetaMockData;
    component.payloadForBulkChanges = [];
    const mockRowMetaData = {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_RO_METADATA',
      value: 'NO_ROW_METADATA'
    };
    component.changesTabFormGroup.controls[`rowMetaDataDropdown`].setValue(mockRowMetaData);
    component.processMetaDataBulkChangePayload();
    expect(component.payloadForChanges['METADATA_USER_ID']).toEqual(undefined);
  });

  it('should create MapColumns Key and selected values is Column name', () => {
    component.isTargetExists = true;
    component.changesTabFormGroup.value.mapColumnsByDropdown.value = 'COLUMN_NAME';
    expect(component.processMapColumnsKey()).toBe('Column name');
  });

  it('should create MapColumns Key and selected values is Column order', () => {
    component.isTargetExists = true;
    component.changesTabFormGroup.value.mapColumnsByDropdown.value = 'COLUMN_ORDER';
    expect(component.processMapColumnsKey()).toBe('Column order');
  });

  it('should create MapColumns Key and selected values is Use default', () => {
    component.isTargetExists = true;
    component.changesTabFormGroup.value.mapColumnsByDropdown.value = 'USE_DEFAULT';
    expect(component.processMapColumnsKey()).toBe('Column name');
  });

  it('should create MapColumns Key and selected and target value is false', () => {
    component.isTargetExists = false;
    component.changesTabFormGroup.value.mapColumnsByDropdown.value = 'USE_DEFAULT';
    expect(component.processMapColumnsKey()).toBe(undefined);
  });

  it('should make metadata fields template hidden through a flag when loading changes tab', () => {
    component.loadChangesTab();
    expect(component.metaDataCheckboxField).toBeFalse();
  });
});
