import { Injectable } from '@angular/core';
import { Resolve }  from '@angular/router';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';

import { AjaxUtilityService } from '../utility/ajax-utility.service';

@Injectable()

export class ValidateProfileEmailResolver implements Resolve<any>{
    constructor(private _ajaxUtility: AjaxUtilityService){}
    validateEmailReqObj = {"request":{"actionType":"profileCompletionFlow","profileInfo": window["location"]["href"].split('profid1=')[1]}}

    // The resolve method will check if the service resolves on page load and then
    // either send the resolved data or in catch send a message
    resolve(){            
            return this._ajaxUtility.sendRequest("validateEnrollmentEmail", this.validateEmailReqObj).catch(() => {
                // if service does not respond use the catch block
                return Observable.of({"status":"Fail"});
              });
        }
    }