import React from 'react'
import { object } from 'prop-types'
import { connect } from 'react-redux'
import { Helmet } from 'react-helmet'
import { withStyles } from '@material-ui/core/styles'
import HeaderTitle from '../Header/HeaderTitle'
import GridEntry from './GridEntry'

const styles = theme => ({
  homePage: {
    textAlign: 'center',
    minHeight: '90vh',
  },
})

class MassItemMaintain extends React.Component {
  static propTypes = {
    classes: object,
  }

  render () {
    const { classes, headerTitle } = this.props

    return (
      <div className={this.props.sideNavIsOpen ? 'side-nav-open' : 'side-nav-close'}>
        <div className={classes.homePage}>
          <HeaderTitle title="Mass Item Maintain" />
          <Helmet>
            <title>{headerTitle}</title>
          </Helmet>
          <GridEntry auth={this.props.auth} />
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => ({
  headerTitle: state.getIn(['layout', 'headerTitle']),
  sideNavIsOpen: state.getIn(['layout', 'sideNavIsOpen']),
  auth: state.get('auth').toJS(),
})

export default connect(mapStateToProps)(withStyles(styles)(MassItemMaintain))
