import { MetricDetailsModel } from './metric-details.model';

export class AlertMetricModel {
  metricType: string;
  metricName: string;
  metricDetails: MetricDetailsModel[];
}
