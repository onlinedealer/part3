import { Component, HostBinding, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SecondaryNavItemsService } from 'discovery-shared';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'discovery-data-catalog-container',
  templateUrl: './data-catalog-container.component.html'
})
export class DataCatalogContainerComponent implements OnInit {
  @HostBinding('class') hostClasses = ['d-block'];

  navItems: MenuItem[];
  activeItem: MenuItem;

  constructor(private translocoService: TranslocoService, private navItemsService: SecondaryNavItemsService) {}

  ngOnInit(): void {
    this.navItems = this.navItemsService.getNavItems();
    this.activeItem = this.navItemsService.getActiveNav('dq-data-catalogs');
  }
}
