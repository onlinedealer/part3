import { Spies } from 'discovery-test';
import { SemanticDonutChartComponent } from './semantic-donut-chart.component';

describe('SemanticDonutChartComponent', () => {
  let component: SemanticDonutChartComponent;

  beforeEach(async () => {});

  beforeEach(() => {
    Spies.init();
    component = new SemanticDonutChartComponent(Spies.TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with Column', () => {
    component.statistic = {
      type: 'ValidityStatistics',
      validCount: 3060007,
      invalidCount: 6
    } as any;
    component.ngOnInit();
    expect(component.data.datasets[0].data[0]).toBe(component.statistic['validCount']);
    expect(component.data.datasets[0].data[1]).toBe(component.statistic['invalidCount']);
  });

  it('populate confidence labels on confidence stats', () => {
    component.name = 'confidence';
    component.statistic = {
      validCount: 3060007,
      invalidCount: 6
    } as any;
    component.ngOnInit();
    expect(component.data.labels.length).toBe(1);
  });

  it('populate validity labels on validity stats', () => {
    component.name = 'validity';
    component.statistic = {
      validCount: 3060007,
      invalidCount: 6
    } as any;
    component.ngOnInit();
    expect(component.data.labels.length).toBe(2);
  });

  it('should have set chartWidth according to showTrendsindicator flag', () => {
    (component.name = 'validity'),
      (component.statistic = {
        validCount: 3060007,
        invalidCount: 6
      } as any);
    component.showTrendsIndicator = true;
    component.ngOnInit();
    expect(component.chartWidth).toBe('10vw');
    component.showTrendsIndicator = false;
    component.ngOnInit();
    expect(component.chartWidth).toBe('20vw');
  });
});
