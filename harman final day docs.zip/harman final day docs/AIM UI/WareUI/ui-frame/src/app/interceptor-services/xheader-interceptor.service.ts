import { Injectable, Inject, LOCALE_ID } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from "@angular/common/http";
import { Observable, of } from "rxjs";
import { SecurityState } from "../store/reducers/security.reducer";
import { Store } from "@ngrx/store";
import { ConfigurationsState } from "../store/reducers/configurations.reducer";
import { withLatestFrom, concatMap } from "rxjs/operators";
import * as fromSecuritySelectors from "../store/selectors/security.selectors";
import * as fromConfigSelectors from "../store/selectors/configurations.selectors";

@Injectable()
export class XHeaderInterceptorService implements HttpInterceptor {
    constructor(
        private securityStore: Store<SecurityState>,
        private configStore: Store<ConfigurationsState>,
        @Inject(LOCALE_ID) private localeId: string
    ) {}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        return of("").pipe(
            withLatestFrom(
                this.securityStore.select(fromSecuritySelectors.getToken),
                this.configStore.select(fromConfigSelectors.getTimeZoneInUse),
                this.configStore.select(fromConfigSelectors.getUiLocale),
                this.configStore.select(fromConfigSelectors.getUserCountry)
            ),
            concatMap(([, securityToken, userTimeZone, userCountry]) => {
                if (!securityToken) {
                    return next.handle(req);
                }
                let newHeaders = req.headers.set("X-User-Defined-TimeZone", userTimeZone || "");
                newHeaders = newHeaders.set("X-User-Defined-Region", userCountry);
                newHeaders = newHeaders.set("X-User-Defined-Language", this.localeId);
                const definedRequest = req.clone({
                    headers: newHeaders,
                    withCredentials: req.withCredentials
                });
                return next.handle(definedRequest);
            })
        );
    }
}
