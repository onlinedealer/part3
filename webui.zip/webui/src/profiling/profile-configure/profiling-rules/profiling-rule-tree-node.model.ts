import { TreeNode } from 'primeng/api';
import { ProfileRuleModel } from '../../profile-rule.model';

export class ProfilingRuleTreeNodeModel implements TreeNode {
  /**
   *
   */
  data: ProfileRuleModel;

  /**
   *
   */
  children: ProfilingRuleTreeNodeModel[];

  /**
   *
   */
  parent: ProfilingRuleTreeNodeModel;

  /**
   *
   * @param profileRule
   * @param index
   * @param parent
   */
  constructor(profileRule: ProfileRuleModel, index: number, parent?: ProfilingRuleTreeNodeModel) {
    if (profileRule) {
      this.data = profileRule;
      this.data.uniqueKey = parent ? parent.data.uniqueKey + '_' + index : index.toString();
      this.data.selected = this.data.selected === false ? null : this.data.selected;
      this.parent = parent;

      if (profileRule.children && profileRule.children.length > 0) {
        this.children = [];
        for (const [childIndex, ruleChildNode] of profileRule.children.entries()) {
          this.children.push(new ProfilingRuleTreeNodeModel(ruleChildNode, childIndex, this));
        }
      }
    }
  }
}
