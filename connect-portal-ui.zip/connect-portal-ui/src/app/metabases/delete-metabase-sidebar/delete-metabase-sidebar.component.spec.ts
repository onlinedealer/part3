import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { Component } from '@angular/core';
import { FormsModule, ReactiveFormsModule, FormControl, FormGroup } from '@angular/forms';
import { of } from 'rxjs';
import { Project } from '../../pipelines/pipeline/shared/project';
import { ProjectsApiService } from '../../pipelines/pipeline/shared/projects-api.service';
import { Metabase } from '../shared/metabase.model';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { DeleteMetabaseSidebarComponent } from './delete-metabase-sidebar.component';
import { MetadataApiService } from '../../pipelines/pipeline/data/schema-table-selector/metadata-api.service';
import { EncryptionService } from '../../shared/services/encryption.service';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';
import { DeleteMetabaseFormComponent } from './delete-metabase-form/delete-metabase-form.component';

describe('DeleteMetabaseDialogComponent', () => {
  let component: DeleteMetabaseSidebarComponent;
  let fixture: ComponentFixture<DeleteMetabaseSidebarComponent>;
  let projectsApiService: ProjectsApiService;
  let metabasesApiService: MetabasesApiService;
  let metadataApiService: MetadataApiService;
  let encryptionService: EncryptionService;

  @Component({
    selector: 'p-connect-delete-metabase-form',
    template: '',
    providers: [
      {
        provide: DeleteMetabaseFormComponent,
        useClass: MockDeleteMetabaseFormComponent
      }
    ]
  })
  class MockDeleteMetabaseFormComponent {
    metabaseCredentialsForm = new FormGroup({
      adminUserId: new FormControl(''),
      password: new FormControl(''),
      removeConfigOnly: new FormControl('')
    });
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, ReactiveFormsModule],
      declarations: [DeleteMetabaseSidebarComponent, MockSidebarComponent, MockDeleteMetabaseFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeleteMetabaseSidebarComponent);
    projectsApiService = TestBed.inject(ProjectsApiService);
    metabasesApiService = TestBed.inject(MetabasesApiService);
    metadataApiService = TestBed.inject(MetadataApiService);
    encryptionService = TestBed.inject(EncryptionService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close sidebar', () => {
    spyOn(component.sidebarComponent, 'close');
    component.cancelButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should delete Oracle metabase', fakeAsync(() => {
    spyOn(component.metabaseDeletedEvent, 'emit');
    spyOn(component.sidebarComponent, 'close');
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(metabasesApiService, 'deleteMetabase').and.returnValue(of({}));
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    component.metabase = { dataConnection: { id: 'abcd', connectionType: 'ORACLE', accessFromServer: { name: 'myServer' } } } as Metabase;
    component.deleteButtonClicked();
    tick();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
    expect(component.metabaseDeletedEvent.emit).toHaveBeenCalled();
  }));

  it('should hide metabase deletion popup & spinner if agent is down', fakeAsync(() => {
    spyOn(encryptionService, 'encrypt').and.returnValue(Promise.reject({ error: { detailedMessage: 'AgentDownException' } }));
    spyOn(component.sidebarComponent, 'close');
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    component.metabase = { dataConnection: { id: 'abcd', connectionType: 'ORACLE', accessFromServer: { name: 'myServer' } } } as Metabase;
    component.deleteButtonClicked();
    tick();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  }));

  it('should delete IBMi metabase', fakeAsync(() => {
    spyOn(component.metabaseDeletedEvent, 'emit');
    spyOn(component.sidebarComponent, 'close');
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(metabasesApiService, 'deleteMetabase').and.returnValue(of({}));
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    component.metabase = { dataConnection: { id: 'abcd', connectionType: 'DB2I', accessFromServer: { name: 'myServer' } } } as Metabase;
    component.deleteButtonClicked();
    tick();
    expect(component.metabaseDeletedEvent.emit).toHaveBeenCalled();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  }));
});
