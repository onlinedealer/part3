import { TableModel } from 'discovery-core';
import { ProfileListConnectionModel } from 'discovery-core';

export class ProfileListModel {
  id: string;
  name: string;
  runSuggestion: boolean;
  connection: ProfileListConnectionModel;
  tables: TableModel[];
  recordsCount: number;
  status: string;
  runByUser: string;
  lastRun: string;
  duration: string;
  createByUser: string;
  completenessPercentage: string;
  message: string;
  lastRunId: string;
}
