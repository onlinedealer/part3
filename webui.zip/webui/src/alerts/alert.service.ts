import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { ReportStatusModel } from 'alerts/report-status.model';
import { AuthenticationService, ServerSentEventsService } from 'discovery-shared';
import { concatMap, map, Observable } from 'rxjs';
import { AlertModel } from './alert.model';
import { AlertCountsModel, TotalAlertCount } from './alertcounts.model';
import { AlertConstants } from './alerts-listing/alert-constants';
@Injectable({
  providedIn: 'root'
})
export class AlertService {
  baseUrl: string;
  reportBaseUrl: string;

  constructor(
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    httpUtil: HttpUtilService,
    private sseService: ServerSentEventsService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('dataobservabilityconfig', 'profiling', 'api/v1/');
    this.reportBaseUrl = httpUtil.getAssetUrl('dobreporting', 'profiling', 'api/v1/');
  }

  getAlerts(includeNonAlerts?: boolean, observerId?: string): Observable<AlertModel[]> {
    if (includeNonAlerts === null || includeNonAlerts === undefined) {
      includeNonAlerts = false;
    }
    let queryParams = new HttpParams();
    if (observerId) {
      queryParams = queryParams.append('observerId', observerId);
    }

    return this.httpClient.get(this.baseUrl + 'alerts/' + includeNonAlerts, {
      headers: this.authenticationService.getHttpHeaders(),
      params: queryParams
    }) as Observable<AlertModel[]>;
  }

  getAlertDetail(alertId: string): Observable<AlertModel> {
    return this.httpClient.get(this.baseUrl + 'alerts' + '/' + 'alertdetails' + '/' + alertId, {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<AlertModel>;
  }

  getAlertsCount(observerId?: string): Observable<AlertCountsModel[]> {
    let queryParams = new HttpParams();
    if (observerId) {
      queryParams = queryParams.append('observerId', observerId);
    }
    return this.httpClient.get(this.baseUrl + 'alerts/counts', {
      headers: this.authenticationService.getHttpHeaders(),
      params: queryParams
    }) as Observable<AlertCountsModel[]>;
  }

  getTotalAlertsCount(observerId?: string): Observable<TotalAlertCount> {
    let queryParams = new HttpParams();
    if (observerId) {
      queryParams = queryParams.append('observerId', observerId);
    }
    return this.httpClient.get(this.baseUrl + 'alerts/totalcount', {
      headers: this.authenticationService.getHttpHeaders(),
      params: queryParams
    }) as Observable<TotalAlertCount>;
  }

  reportGenerationRequest(exportReportModel) {
    return this.httpClient.post(this.reportBaseUrl + 'report/excel', exportReportModel, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  getExcel(jobId: string): Observable<Blob> {
    return this.httpClient.get(this.reportBaseUrl + 'report/excel/download?jobId=' + jobId, {
      headers: this.authenticationService.getHttpHeaders(),
      responseType: 'blob'
    });
  }

  getExcelStatus(jobId, assetName) {
    let url = this.reportBaseUrl + 'report/excel/status?jobId=' + jobId;

    return this.sseService.getServerSentEvent(url).pipe(
      concatMap((report) => {
        const reportStatus: ReportStatusModel = report;
        if (reportStatus.status === AlertConstants.EXPORT_REPORT_PROCESS_COMPLETE) {
          this.sseService.closeSSEConnection(url);
          return this.getExcel(jobId).pipe(
            map((data) => {
              let blobFile = new Blob([data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
              });
              const file = window.URL.createObjectURL(blobFile);
              let link = document.createElement('a');
              link.href = file;
              link.download = assetName ? assetName + '_' + jobId : jobId;
              // this is necessary as link.click() does not work on the latest firefox
              link.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));

              setTimeout(function () {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(file);
                link.remove();
              }, 100);
              return data;
            })
          );
        }
      })
    );
  }
}
