import { FormControl } from '@angular/forms';

export class ConnectionFormValidators {
  static noWhiteSpaceValidator(control: FormControl) {
    const isWhiteSpace = (control.value || '').trim().length === 0;
    const isValid = !isWhiteSpace;
    return isValid ? null : { whitespace: true };
  }
}
