import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { DropdownModule } from 'primeng/dropdown';
import { SidebarModule } from 'primeng/sidebar';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { PipelineService } from '../../pipeline.service';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { FiltersFormComponent } from '../filters-form/filters-form.component';
import { FiltersSidebarComponent } from './filters-sidebar.component';
describe('FiltersSidebarComponent', () => {
  let component: FiltersSidebarComponent;
  let fixture: ComponentFixture<FiltersSidebarComponent>;
  const mockPipelineService = jasmine.createSpyObj<Partial<PipelineService>>('PipelineService', ['savePipeline']);
  const mockPipelineEntityService = jasmine.createSpyObj<Partial<PipelineEntityService>>('PipelineEntityService', [
    'addFilter',
    'removeLatestFilter',
    'editFilter'
  ]);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, getTranslocoModule(), SidebarModule, DropdownModule, HttpClientTestingModule],
      declarations: [FiltersSidebarComponent, FiltersFormComponent, SidebarComponent],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'filters' } },
        { provide: PipelineService, useValue: mockPipelineService },
        { provide: PipelineEntityService, useValue: mockPipelineEntityService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltersSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set showFiltersComponent to false', () => {
    spyOn(component.filterFormComponent.filterFormGroup, 'reset').and.returnValue();
    component.cancelFilterButtonClicked();
    expect(component.isVisible).toBe(false);
    expect(component.filterFormComponent.filterFormGroup.reset).toHaveBeenCalled();
  });

  it('should disable primaryButton', () => {
    component.filterFormComponent.filterFormGroup.patchValue({ schema: 'schema1' });
    component.filterFormComponent.filterFormGroup.patchValue({ table: 'table1' });
    expect(component.primaryButton.isDisabled).toBe(false);
  });

  describe('addFilter()', () => {
    beforeAll(() => {
      jasmine.getEnv().allowRespy(true);
    });
    describe('when save succeeds', () => {
      it('should hide side bar', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        component.isVisible = true;
        component.addFilter();
        tick();
        expect(component.isVisible).toBe(false);
      }));
      it('should emit "isVisibleChanged" event', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        spyOn(component.isVisibleChanged, 'emit');
        component.addFilter();
        tick();
        expect(component.isVisibleChanged.emit).toHaveBeenCalledWith(false);
      }));
      it('should reset form group', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        spyOn(component.filterFormComponent.filterFormGroup, 'reset').and.stub();
        component.addFilter();
        tick();
        expect(component.filterFormComponent.filterFormGroup.reset).toHaveBeenCalled();
      }));
      it('should display and hide progress indicator when performing successful save', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        component.sidebarComponent.isProcessingRequest = false;
        component.addFilter();
        expect(component.sidebarComponent.isProcessingRequest).toBe(true);
        tick();
        expect(component.sidebarComponent.isProcessingRequest).toBe(false);
      }));
      it('should add filter to the Pipeline Entity', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        component.addFilter();
        tick();
        expect(mockPipelineEntityService.addFilter).toHaveBeenCalled();
      }));
    });

    describe('when save fails', () => {
      it('should display and hide progress indicator when performing a failed save', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.reject({ id: 'abc' }));
        expect(component.sidebarComponent.isProcessingRequest).toBe(false);
        component.sidebarComponent.isProcessingRequest = false;
        component.addFilter();
        expect(component.sidebarComponent.isProcessingRequest).toBe(true);
        tick();
        expect(component.sidebarComponent.isProcessingRequest).toBe(false);
      }));
      it('should remove/revert the added filter if the save fails', fakeAsync(() => {
        mockPipelineService.savePipeline.and.returnValue(Promise.reject({}));
        component.addFilter();
        tick();
        expect(mockPipelineEntityService.removeLatestFilter).toHaveBeenCalled();
      }));
    });
  });

  describe('editFilter()', () => {
    const originalFilter = {
      schema: 'schema1',
      table: 'table1',
      expression: 'col1 > col2'
    };

    beforeAll(() => {
      jasmine.getEnv().allowRespy(true);
    });
    beforeEach(() => {
      component.setFilter(originalFilter);
    });
    describe('when save changes succeeds', () => {
      it('should hide side bar', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        component.isVisible = true;
        component.editFilter();
        tick();
        expect(component.isVisible).toBe(false);
      }));
      it('should emit "isVisibleChanged" event', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        spyOn(component.isVisibleChanged, 'emit');
        component.editFilter();
        tick();
        expect(component.isVisibleChanged.emit).toHaveBeenCalledWith(false);
      }));
      it('should reset form group', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        spyOn(component.filterFormComponent.filterFormGroup, 'reset').and.stub();
        component.editFilter();
        tick();
        expect(component.filterFormComponent.filterFormGroup.reset).toHaveBeenCalled();
      }));
      it('should display and hide progress indicator when performing successful save changes', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        component.sidebarComponent.isProcessingRequest = false;
        component.editFilter();
        expect(component.sidebarComponent.isProcessingRequest).toBe(true);
        tick();
        expect(component.sidebarComponent.isProcessingRequest).toBe(false);
      }));
      it('should edit existing filter in the Pipeline Entity', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.resolve({ id: 'abc' }));
        const editedFilter = {
          id: 'def',
          schema: 'schema2',
          table: 'table2',
          expression: 'col2 > col1'
        };
        component.filterFormComponent.filterFormGroup.patchValue(editedFilter);
        component.editFilter();
        tick();
        expect(mockPipelineEntityService.editFilter).toHaveBeenCalledWith(originalFilter, editedFilter);
      }));
    });

    describe('when save changes fails', () => {
      it('should display and hide progress indicator when performing a failed save changes', fakeAsync(() => {
        spyOn(mockPipelineService, 'savePipeline').and.returnValue(Promise.reject({ id: 'abc' }));
        expect(component.sidebarComponent.isProcessingRequest).toBe(false);
        component.sidebarComponent.isProcessingRequest = false;
        component.editFilter();
        expect(component.sidebarComponent.isProcessingRequest).toBe(true);
        tick();
        expect(component.sidebarComponent.isProcessingRequest).toBe(false);
      }));
      it('should restore the original filter if the save changes fails', fakeAsync(() => {
        mockPipelineService.savePipeline.and.returnValue(Promise.reject({}));
        const editedFilter = {
          id: 'def',
          schema: 'schema2',
          table: 'table2',
          expression: 'col2 > col1'
        };
        component.filterFormComponent.filterFormGroup.patchValue(editedFilter);
        component.editFilter();
        tick();
        expect(mockPipelineEntityService.editFilter).toHaveBeenCalledWith(editedFilter, originalFilter);
      }));
    });
  });
});
