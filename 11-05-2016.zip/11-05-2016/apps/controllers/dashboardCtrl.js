(function() {
    'use strict';

    fileuploader.controller("dashboardCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', dashboardCtrl]);

    function dashboardCtrl($scope, $ajaxFactory, $rootScope, uiRouters) {

        $scope.dropdownselect1 = $rootScope.dropdownselect;

        $scope.textoutput = "";
        $scope.uploadpreview = "";
		$scope.fetchpreviewData = "";
		
		
		

        $scope.selectedTemplate = $rootScope.dropdownSelect;
        var dropdrop = $rootScope.selectedId;
        console.log(dropdrop)

        // Function to Preview the uploaded file
        $scope.fetchpreviewData = function() {

            var id = $rootScope.globalId;
            
            var url = "http://localhost:8080/ocr/rest/v1/service/get/tiffimage/tiff/file/" + id;
		   
            console.log(url)

            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            promise.then(function(data) {
                var outputimage = data;
				var output = "data:image/tiff;base64," + outputimage.inputdata;
                      					 
					 $scope.uploadpreview = output;
					 
				
				console.log($scope.uploadpreview)
				
				
				
            });
            promise.catch(function(data) {
                console.log('catch block executed', data);
                return data;
            });
            promise.finally(function(data) {
                console.log('finally block executed', data);

            });

        };
		$scope.fetchpreviewData();
		
		/*$scope,loadimgheader = function(){
			var imagUrl = $rootScope.uploadpreview;
			return{
				'background': 'url('+ imagUrl +') top left no-repeate', 'background-size': 'contain', 'width': '100px', 'height': '100px'
			}
		};*/
		
		
		
		
		

        // function to display the out as the text in textarea
        $scope.fetchoutputData = function() {

            var id = $rootScope.globalId;

            var url = "http://localhost:8080/ocr/rest/v1/service/get/text/tiff/file/" + id;
            console.log(url)

            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            promise.then(function(d) {
                $scope.textoutput = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);

            });

        }
        $scope.fetchoutputData();


        /*// Function for dropdown
      $scope.fetchdropdownData = function() {

            //var url = "/get/list/of/data/for/" + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/template.json', 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.testdropdown = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });

        }
    $scope.fetchdropdownData();*/


        $scope.exportdoc = function() {
			$scope.getId = $rootScope.globalId;
			console.log($scope.getId)
            var id = $rootScope.globalId;

            var url = "http://localhost:8080/ocr/rest/v1/service/get/report/excel/file/" + id;
            console.log(url)

            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            promise.then(function(d) {
							
				
                
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);

            });
			
			


        }

/*

$http({
    url: 'your/webservice',
    method: "POST",
    data: json, //this is your json data string
    headers: {
       'Content-type': 'application/json'
    },
    responseType: 'arraybuffer'
}).success(function (data, status, headers, config) {
    var blob = new Blob([data], {type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});
    var objectUrl = URL.createObjectURL(blob);
    window.open(objectUrl);
}).error(function (data, status, headers, config) {
    //upload failed
});
*/
		
		
		

        var data = [
            ["", "Ford", "Volvo", "Toyota", "Honda", "Volvo", "Toyota", "Honda"],
            ["2016", 10, 11, 12, 13],
            ["2017", 20, 11, 14, 13],
            ["2018", 30, 15, 12, 13]
        ];

        var container = document.getElementById('example1grid');
        var hot = new Handsontable(container, {
            data: data,
            rowHeaders: true,
            colHeaders: true
        });


    }


})();