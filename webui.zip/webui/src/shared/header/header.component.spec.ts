import { ProductCard } from '@precisely/prism-ng/api';
import { Account } from '@precisely/prism-ng/cloud';
import { Spies } from 'discovery-test';
import { of } from 'rxjs';
import { HeaderComponent } from './header.component';

describe('HeaderComponent', () => {
  let component: HeaderComponent;
  let httpUtil: any;
  let account: Account;
  let productCardsService: any;
  let products: ProductCard[];

  beforeEach(() => {
    products = [];
    account = {
      id: '1',
      accountName: 'test account',
      companyName: 'some company',
      owner: 'foo@bar.com',
      linkedAccountId: 'abc'
    };
    Spies.init();
    httpUtil = jasmine.createSpyObj('HttpUtilService', ['getUrl']);
    httpUtil.getUrl.and.returnValue('http://test');
    productCardsService = jasmine.createSpyObj('ProductCardsService', ['all']);
    productCardsService.all.and.returnValue(of(products));
    component = new HeaderComponent(Spies.FirstTimeUserService, Spies.oidc, httpUtil, productCardsService);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
    expect(component.user).toBeUndefined();
  });

  it('can get acct mgmt urls', () => {
    component.ngOnInit();
    expect(component.manageUsersUrl).toBe('http://test');
    expect(component.manageSubsUrl).toBe('http://test');
  });

  it('can get products', (done) => {
    component.ngOnInit();
    component.products.subscribe((p) => {
      expect(p).toBe(products);
      done();
    });
  });

  it('ngOnInit initializes user info', () => {
    component.ngOnInit();
    expect(component.user).toBeDefined();
    expect(component.user.firstName).toBe('Test');
    expect(component.user.lastName).toBe('User');
    expect(component.user.email).toBe('test@mailinator.com');
    component.logout();
  });
});
