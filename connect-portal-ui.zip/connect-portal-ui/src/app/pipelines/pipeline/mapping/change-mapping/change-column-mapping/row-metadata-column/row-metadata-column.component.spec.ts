import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { getTranslocoModule } from '../../../../../../core/transloco-testing.module';
import { RowMetadataColumnComponent } from './row-metadata-column.component';

describe('RowMetadataColumnComponent', () => {
  let component: RowMetadataColumnComponent;
  let fixture: ComponentFixture<RowMetadataColumnComponent>;

  const defaultMockData = [
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'EXCLUDE',
      isChecked: true
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true
    }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } }],
      declarations: [RowMetadataColumnComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(RowMetadataColumnComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should defaults MetaData Checkbox Changed to checked', () => {
    const event = {
      key: 'METADATA_ROW_JOB_NAME',
      value: 'sv_job_name',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: false
    };
    component.metaData = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'INCLUDE',
        isChecked: false
      },
      {
        key: 'METADATA_ROW_JOB_NAME',
        value: 'sv_job_name',
        cdcRowMetadataType: 'INCLUDE',
        isChecked: true
      },
      {
        key: 'METADATA_ROW_JOB_USER',
        value: 'sv_job_user',
        cdcRowMetadataType: 'INCLUDE',
        isChecked: true
      }
    ];
    component.onChangeMetaDataCheckbox(event);
    expect(component.metaData[0].cdcRowMetadataType).toEqual('INCLUDE');
  });

  it('should defaults MetaData Checkbox Changed to unchecked', () => {
    const event = {
      key: 'METADATA_ROW_JOB_NAME',
      value: 'sv_job_name',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: false
    };
    component.metaData = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'EXCLUDE',
        isChecked: false
      },
      {
        key: 'METADATA_ROW_JOB_NAME',
        value: 'sv_job_name',
        cdcRowMetadataType: 'EXCLUDE',
        isChecked: false
      },
      {
        key: 'METADATA_ROW_JOB_USER',
        value: 'sv_job_user',
        cdcRowMetadataType: 'INCLUDE',
        isChecked: true
      }
    ];
    component.onChangeMetaDataCheckbox(event);
    expect(component.metaData[1].cdcRowMetadataType).toEqual('EXCLUDE');
  });
});
