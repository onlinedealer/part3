import {
    Component,
    Input,
    EventEmitter,
    Output,
    ChangeDetectionStrategy,
    ViewChild,
    ElementRef,
    SimpleChanges,
    OnChanges,
    AfterViewInit,
    TemplateRef
} from "@angular/core";
import { MeteringPointSearchResultVO } from "../../../models/view-objects/meteringpoint-searchresult-vo.model";
import { Store } from "@ngrx/store";
import { MatDialog } from "@angular/material/dialog";
import { MeteringPointState } from "../../../store/reducers/meteringpoints.reducer";
import { Observable } from "rxjs";
import { CdkVirtualScrollViewport } from "@angular/cdk/scrolling";
import { TranslationsService } from "../../../../app/services/translations-service";
import { EditColumnDialogComponent } from "../../edit-column-dialog/edit-column-dialog.component";
import { MeteringPointsUISelectors, XSFSearchSelectors, MeteringPointsSelectors } from "../../../store/selectors";
import { XSFSearchActions } from "../../../store/actions";
import { cloneDeep, map } from "lodash";
import { ExportDialogComponent } from "../../export-dialog/export-dialog.component";
import { ExportDataColHeaderService } from "../../../services";

@Component({
    selector: "landisgyr-meteringpoints-search-results",
    templateUrl: "./meteringpoints-search-results.html",
    styleUrls: ["./meteringpoints-search-results.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringPointsSearchResultsComponent implements OnChanges, AfterViewInit {
    @ViewChild(CdkVirtualScrollViewport) virtualScrollViewport!: CdkVirtualScrollViewport;
    @ViewChild("table", { static: true }) table!: ElementRef;
    @ViewChild("statusIndicator") statusIndicator!: TemplateRef<any>;
    @ViewChild("statesIndicator") statesIndicator!: TemplateRef<any>;
    @Input() mpSearchDetailsColConfig: {
        columnId: string;
        columnName: string;
        showColumn: boolean;
        draggedColumn: boolean;
        columnWidth: number;
        columnType?: string;
    }[] = [];
    @Input() sortedColumn!: { property: string; direction: string };
    @Input() results!: MeteringPointSearchResultVO[];
    @Input() sideVisible!: boolean;
    @Input() selectedId!: number;
    @Input() checkedMeteringPointIds!: number[];
    @Input() selectAllCheckbox!: boolean;
    @Output()
    select: EventEmitter<{ [key: string]: MeteringPointSearchResultVO }> = new EventEmitter();
    @Output() allMeteringPointsCheck: EventEmitter<boolean> = new EventEmitter();
    @Output() checkboxChecked: EventEmitter<number> = new EventEmitter();
    @Output() meteringPointExportDataClick: EventEmitter<null> = new EventEmitter();
    pagesCount$: Observable<number> = this.store.select(XSFSearchSelectors.getPagesCount);
    pageNumber$: Observable<number> = this.store.select(XSFSearchSelectors.getPageNumber);
    isOrdering$: Observable<boolean> = this.store.select(XSFSearchSelectors.isOrdering);
    sideViewVisible$: Observable<boolean> = this.store.select(MeteringPointsUISelectors.getMeteringPointsSideviewVisible);
    getMeteringPointsSelected$:  Observable<number[]> = this.store.select(MeteringPointsSelectors.getMeteringPointsSelected);

    @Input() windowHeightSub!: any;
    scrollVisible!: boolean;

    displayedColumnCollection: any[] = [
        {
            columnId: "statusIndicator",
            columnName: "Status",
            columnType: "icons",
            visible: true,
            interNationalizationText: "@@commonTranslations.status:Status"
        },
        {
            columnId: "name",
            columnName: "Metering point",
            columnType: "text",
            visible: true,
            interNationalizationText: "@@commonTranslations.meteringPoint:Metering point"
        },
        {
            columnId: "address",
            columnName: "Address",
            columnType: "text",
            visible: true,
            interNationalizationText: "@@commonTranslations.address:Address"
        },
        {
            columnId: "transformerArea",
            columnName: "Transformer area",
            columnType: "text",
            visible: true,
            interNationalizationText: "@@commonTranslations.transformerArea:Transformer area"
        },
        {
            columnId: "gsrn",
            columnName: "GSRN",
            columnType: "text",
            visible: true,
            interNationalizationText: "@@commonTranslations.gsrn:GSRN"
        },
        {
            columnId: "customerNumber",
            columnName: "Customer number",
            columnType: "text",
            visible: true,
            interNationalizationText: "@@commonTranslations.customerNumber:Customer number"
        },
        {
            columnId: "customerName",
            columnName: "Customer name",
            columnType: "text",
            visible: true,
            interNationalizationText: "@@commonTranslations.customerName:Customer name"
        },
        {
            columnId: "meteringPointStates",
            columnName: "States",
            columnType: "icons",
            visible: true,
            interNationalizationText: "@@commonTranslations.states:States"
        },
        { columnId: "Menu", columnName: "", columnType: "menu", visible: true, interNationalizationText: "" }
    ];

    columns: { header: string; sortable: boolean; hideIfSideVisible: boolean; showColumn: boolean }[] = [
        // Column order and values for property 'header' come from array const mpDetailsColumnConfigData
        { header: "", sortable: true, hideIfSideVisible: false, showColumn: true },
        { header: "", sortable: true, hideIfSideVisible: false, showColumn: true },
        { header: "", sortable: true, hideIfSideVisible: true, showColumn: true },
        { header: "", sortable: true, hideIfSideVisible: true, showColumn: true },
        { header: "", sortable: false, hideIfSideVisible: true, showColumn: true },
        { header: "", sortable: false, hideIfSideVisible: true, showColumn: true },
        { header: "", sortable: false, hideIfSideVisible: true, showColumn: true }
    ];

    sortableColumns = ["Metering point", "Address", "Transformer area", "GSRN", "Customer number", "Customer name", "States"];
    sortKeys: Map<string, string> = new Map([
        ["name", "Name"],
        ["address", "StreetAddress"],
        ["transformerArea", "TransformerArea"],
        ["gsrn", "GSRN"],
        ["customerNumber", "Contract.CustomerNumber"],
        ["customerName", "Customer.Name"],
        ["meteringPointStates", "MeteringPointState.Name"]
    ]);

    constructor(
        private store: Store<MeteringPointState>,
        private dialog: MatDialog,
        private translations: TranslationsService,
        private exportDataColHeaderService: ExportDataColHeaderService
    ) {}

    ngAfterViewInit(): void {
        if (this.windowHeightSub) {
            this.checkTableScroll();
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        this.checkTableScroll();
    }

    getTableColumns() {
        for (let i = 0; i < this.columns.length; i++) {
            this.columns[i].header = this.mpSearchDetailsColConfig[i].columnName;
            this.columns[i].showColumn = this.mpSearchDetailsColConfig[i].showColumn;
            if (this.sortableColumns.indexOf(this.columns[i].header) !== -1) {
                this.columns[i].sortable = true;
            } else {
                this.columns[i].sortable = false;
            }
        }
        if (this.sideVisible) {
            let visibleColumn = 0;
            for (let i = 0; i < this.columns.length; i++) {
                if (this.columns[i].showColumn) {
                    visibleColumn++;
                }
                if (visibleColumn > 2) {
                    this.columns[i].showColumn = false;
                }
            }
        }
        return this.columns;
    }

    checkAllMeteringPoints(): void {
        this.allMeteringPointsCheck.emit();
    }

    isRowCheked(id: number): boolean {
        return this.checkedMeteringPointIds.includes(id);
    }

    selectClass(id: number): { [key: string]: boolean } {
        if ((id === this.selectedId && this.checkedMeteringPointIds.includes(id)) || id === this.selectedId) {
            return { selected: true, nothing: false, checked: false };
        } else if (this.checkedMeteringPointIds.includes(id)) {
            return { selected: false, checked: true, nothing: false };
        } else {
            return { nothing: true, selected: false, checked: false };
        }
    }

    onChangeSelect(item: MeteringPointSearchResultVO) {
        this.select.emit({ item });
    }

    onCheckboxSelect(id: number): void {
        this.checkboxChecked.emit(id);
    }

    onPageChange(pageNumber: number) {
        this.store.dispatch(XSFSearchActions.ChangeXSFSearchResultsPage({ pageNumber: pageNumber + 1 }));
        if (this.virtualScrollViewport) {
            this.virtualScrollViewport.scrollToIndex(0, "smooth");
        }
    }

    sortData(event: any) {
        const sortKey = this.sortKeys.get(event.active);
        if (sortKey) {
            this.store.dispatch(
                XSFSearchActions.SetXSFSearchOrderBy({
                    orderBy: {
                        property: sortKey,
                        direction: event.direction.toUpperCase()
                    }
                })
            );
        }
    }

    getActiveSortColumn(event: any) {
        return this.sortedColumn ? this.sortedColumn.property : undefined;
    }

    getActiveSortDirection(event: any) {
        return this.sortedColumn ? this.sortedColumn.direction.toLowerCase() : undefined;
    }

    checkStatesIcon(data: any[]) {
        const value: any = [];
        const statesItems: { [id: string]: { name: string } } = {};
        if (data.length > 0) {
            data.forEach((element) => {
                if (element.identifier === "Comment") {
                    if (!("icon-chat_bubble_outline" in statesItems)) {
                        statesItems["icon-chat_bubble_outline"] = {
                            name: element.name
                        };
                    }
                }
                if (element.identifier === "Reminder") {
                    if (!("icon-schedule" in statesItems)) {
                        statesItems["icon-schedule"] = {
                            name: element.name
                        };
                    }
                }
                if (element.identifier && (element.identifier !== "Reminder" || element.identifier !== "Comment")) {
                    if (!(element.name in value)) {
                        value.push(element.name);
                    }
                    if ("icon-error_outline" in statesItems) {
                        statesItems["icon-error_outline"].name = value.join("<br/>");
                    } else {
                        statesItems["icon-error_outline"] = {
                            name: value.join("<br/>")
                        };
                    }
                }
            });
        }
        return statesItems;
    }

    openExportDialog() {
        this.meteringPointExportDataClick.emit();
    }

    openEditColumnDialog() {
        this.dialog.open(EditColumnDialogComponent, {
            width: "550px",
            maxWidth: "550px",
            height: "620px",
            maxHeight: "620px",
            disableClose: true,
            data: {
                results: [],
                header: this.mpSearchDetailsColConfig,
                tabSelectionFlag: "mpSearchTable"
            }
        });
    }

    checkTableScroll() {
        const tableContentHeight = this.results.length * 40;
        // if (tableContentHeight / this.table.nativeElement.offsetHeight >= 1) {
        this.scrollVisible = true;
        // } else {
        //     this.scrollVisible = false;
        // }
    }
}
