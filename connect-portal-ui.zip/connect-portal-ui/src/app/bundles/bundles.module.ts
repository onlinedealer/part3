import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { BundlesComponent } from './bundles.component';
import { ButtonModule } from 'primeng/button';
import { SharedModule } from '@shared/shared.module';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { TooltipModule } from 'primeng/tooltip';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DialogModule } from 'primeng/dialog';
import { BundlesRoutingModule } from './bundles.routing.module';
import { bundlesLoader, commonLoader, homeLoader, pipelinesLoader, pngLoader } from '../i18n-loaders';
import { CreateBundleSidebarComponent } from './create-bundle-sidebar/create-bundle-sidebar.component';
import { CreateBundleFormComponent } from './create-bundle-sidebar/create-bundle-form/create-bundle-form.component';
import { MessagesModule } from 'primeng/messages';
import { ToastModule } from 'primeng/toast';
import { StopBundleDialogComponent } from './stop-bundle-dialog/stop-bundle-dialog.component';
import { StopBundleFormComponent } from './stop-bundle-dialog/stop-bundle-form/stop-bundle-form.component';
import { DeleteBundleDialogComponent } from './delete-bundle-dialog/delete-bundle-dialog.component';
import { DeleteBundleFormComponent } from './delete-bundle-dialog/delete-bundle-form/delete-bundle-form.component';
import { BundleDetailsSidebarComponent } from './bundle-details-sidebar/bundle-details-sidebar.component';
import { BundleDetailsFormComponent } from './bundle-details-sidebar/bundle-details-form/bundle-details-form.component';
import { TableModule } from 'primeng/table';

@NgModule({
  declarations: [
    BundlesComponent,
    CreateBundleSidebarComponent,
    CreateBundleFormComponent,
    StopBundleDialogComponent,
    StopBundleFormComponent,
    DeleteBundleDialogComponent,
    DeleteBundleFormComponent,
    BundleDetailsSidebarComponent,
    BundleDetailsFormComponent
  ],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'home', loader: homeLoader },
        { scope: 'pipelines', loader: pipelinesLoader },
        { scope: 'bundles', loader: bundlesLoader },
        { scope: 'png', loader: pngLoader }
      ]
    },
    DatePipe
  ],
  imports: [
    CommonModule,
    SharedModule,
    BundlesRoutingModule,
    TranslocoModule,
    ButtonModule,
    TooltipModule,
    FormsModule,
    ReactiveFormsModule,
    MessagesModule,
    // ToastModule needed to add static content to Messages component. Bug raised for this issue: https://github.com/primefaces/primeng/issues/9033
    ToastModule,
    DialogModule,
    TableModule
  ]
})
export class BundlesModule {}
