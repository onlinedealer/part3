import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { OpenIdConnectService } from '@precisely/prism-ng/angular-auth-oidc-client';

/**
 * Guards against access by a user that is not associated with a DI Suite account.
 *
 * MFE Note:  A similar guard is already applied to every federated module route in the shell application.
 */
@Injectable({
  providedIn: 'root'
})
export class TenantGuard implements CanActivate {
  constructor(private router: Router, private oidc: OpenIdConnectService) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return !!this.oidc.getCurrentWorkspaceId() ? true : this.router.parseUrl('/invalid-account');
  }
}
