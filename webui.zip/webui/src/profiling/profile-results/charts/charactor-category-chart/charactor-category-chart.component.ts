import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { Component, Input, OnInit } from '@angular/core';
import { TreePath } from 'profiling/profile-results/tree-path.model';

@Component({
  selector: 'discovery-charactor-category-chart',
  templateUrl: './charactor-category-chart.component.html',
  styleUrls: ['./charactor-category-chart.component.css']
})
export class CharactorCategoryChartComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, any>;
  @Input()
  index: number;
  barData: any;
  horizontalOptions: any;
  ngOnInit(): void {
    this.barData = {
      labels: [],
      datasets: [
        {
          label: '',
          backgroundColor: ProfilingConstants.FREQUENCYCHARTCOLORS[this.index],
          data: [],
          barThickness: 20,
          maxBarThickness: 20
        }
      ]
    };
    this.horizontalOptions = {
      indexAxis: 'y',
      plugins: {
        legend: {
          display: false
        }
      },
      scales: {
        x: {
          ticks: {
            color: ProfilingConstants.CHARTFONTSCOLORS.TICKS,
            beginAtZero: true,
            precision: 0
          },
          grid: {
            color: ProfilingConstants.CHARTFONTSCOLORS.GRID
          }
        },
        y: {
          ticks: {
            color: ProfilingConstants.CHARTFONTSCOLORS.TICKS
          },
          grid: {
            color: ProfilingConstants.CHARTFONTSCOLORS.GRID
          }
        }
      }
    };
    this.getBarDataLabel();
  }
  private getBarDataLabel(): void {
    // eslint-disable-next-line guard-for-in
    for (const key in this.statistics['frequency']) {
      this.barData.labels.push(String(key).match(/.{1,18}\b/g));
      this.barData.datasets[0].data.push(this.statistics['frequency'][key]);
    }
  }
}
