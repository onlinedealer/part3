import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../store/configureStore'
import GridUpdate, { GridUpdate as GridUpdateComponent } from '../GridUpdate'

describe('GridUpdate Page component', () => {
  let store, wrapper, props, wrapperBlock
  store = configureStore()
  props = {
    listStatus: true,
    classes: {},
    commonFields: {
      jira_id: 'cr-11789',
      maintenance_type: 'cost',
      user_id: null,
    },
    columnInfo: [{
      column_id: 'tcin',
      column_name: 'TCIN',
      editable: true,
      field_type: 'Number',
      multi_value: false,
      values: [],
      send_in_response: true,
      filterable: true,
      filter_name: 'dummy',
    }],
    listItems: [{
      'tcin': '21448960',
      'dpci': '907-30-1933',
      'barcode': '499073019338',
      'product_title': 'Bath Towel Red - Threshold',
      'attribute': 'cost',
      'old_value': [
        '5.0',
      ],
      'new_value': null,
      'vendor_id': '1166383',
      'vendor_name': 'DUMMY MASTER DOM1',
      'alternate_id': '411500265',
      'vos': '2',
    }],
    gridText: {
      grid_text_left: 'left content',
      grid_text_right: 'right content',
    },
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }

  it('renders', () => {
    const div = document.createElement('div')
    shallow(
      <Provider store={store}>
        <GridUpdate />
      </Provider>, div)
  })

  it('renders Elements', () => {
    wrapper = mount(
      <Provider store={store}>
        <GridUpdate {...props} />
      </Provider>
    )
    expect(wrapper.find('TextField').length).toEqual(1)
    expect(wrapper.find('Button').length).toEqual(4)
  })

  it('invoking updateToAll calls updateCallBack', () => {
    props.updateCallBack = jest.fn()
    wrapperBlock = shallow(
      <GridUpdateComponent
        {...props}
      />
    )
    wrapperBlock.setState({ newValue: '123' })
    wrapperBlock.instance().updateToAll()
    expect(props.updateCallBack.mock.calls.length).toEqual(1)
  })

  it('invoking handleRefChange calls setFilterCallBack', () => {
    props.setFilterCallBack = jest.fn()
    wrapperBlock = shallow(
      <GridUpdateComponent
        {...props}
      />
    )
    wrapperBlock.instance().handleRefChange('vos', '2-name')
    expect(props.setFilterCallBack.mock.calls.length).toEqual(1)
  })
})
