import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { CatalogMetadataApiService } from './catalog-metadata-api.service';

describe('CatalogMetadataApiService', () => {
  let service: CatalogMetadataApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(CatalogMetadataApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return schema information', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/catalog/api/v1/schemas?connection_id=aaa&project_id=bbb';
    let returnedData;
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getSchemas('aaa', 'bbb').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return table information', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/catalog/api/v1/tables?connection_id=aaa&project_id=bbb&schema_name=test';
    let returnedData;
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getTables('aaa', 'bbb', 'test').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return column information', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/catalog/api/v1/table?connection_id=aaa&project_id=bbb&schema_name=test&table_name=table1';
    let returnedData;
    const mockApiResponse = {
      columns: [
        { columName: 'A', dataType: 'string' },
        { name: 'B', dataType: 'string' }
      ]
    };
    service.getColumns('aaa', 'bbb', 'test', 'table1').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return a list of topics', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/catalog/api/v1/topics?connection_id=aaa&project_id=bbb';
    let returnedData;
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getTopics('aaa', 'bbb').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return a list of journals', () => {
    let returnedData;
    service.getJournals('aaa', 'bbb').subscribe((response) => {
      returnedData = response;
    });
    expect(returnedData.length).toEqual(0);
  });
});
