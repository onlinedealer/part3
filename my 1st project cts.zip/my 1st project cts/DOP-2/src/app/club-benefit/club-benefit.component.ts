import { Component, OnInit } from '@angular/core';
import { BccComponent } from '../shared/bcc/bcc.component';
import { Router } from '@angular/router';
import { AjaxUtilityService } from '../shared/utility/ajax-utility.service';
import { UtagService } from 'utag-module';
import { CookieUtilityService } from '../shared/utility/cookie-utility.service';
import { UtilityService } from '../shared/utility/utility.service';
import { ClubGenericErrorComponent } from '../shared/components/club-generic-error/club-generic-error.component';
import { HttpResponse, HttpParams } from '@angular/common/http';
import { ModalOpenerService } from '../shared/utility/modal-opener.service';
import { TermsAndConditionsModalComponent } from '../terms-and-conditions-modal/terms-and-conditions-modal.component';
import { DomSanitizer } from '@angular/platform-browser';
import { ScriptLoaderService } from '../shared/utility/script-loader.service';
import { Title, Meta } from '@angular/platform-browser';
import { RouteConfigurations } from '../shared/utility/club-constants.service';

@Component({
  selector: 'app-club-benefit',
  templateUrl: './club-benefit.component.html',
  styleUrls: ['./club-benefit.component.scss']
})
export class ClubBenefitComponent implements OnInit {

  isEnrolled: boolean;
  serviceError: boolean;
  isLoggedIn: boolean;
  businessContent: any;
  modalBusinessContent: any;
  scriptsToLoad = [];
  loadAPI: Promise<any>;
  isApp: boolean;

  constructor(private _router: Router,
    private _ajaxUtility: AjaxUtilityService,
    private _utag: UtagService,
    private _cookieService: CookieUtilityService,
    private _utility: UtilityService,
    private _modalService: ModalOpenerService,
    private _sanitizer: DomSanitizer,
    private _scriptLoader: ScriptLoaderService,
    private _title: Title,
    private _meta: Meta
  ) {
    _title.setTitle(RouteConfigurations.clubBenefitsTitle);
    _meta.removeTag("name='description'");    
    _meta.addTag({ name: 'description', content: RouteConfigurations.carepassBenefitsDesc });    
  }

  ngOnInit() {
    try {
      this.isApp = (<any>window).native ? true : false;
    } catch (error) {
      this.isApp = false;
      console.error(error);
    }
    this.loadDynamicScripts(30444);
  }


  fetchDigitalProfile() {
    this._ajaxUtility.sendRequest('getDigitalProfile')
      .subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('getDigitalProfileResponse')) {
          response = data['getDigitalProfileResponse'];
          if (response.hasOwnProperty('header') && response.header.hasOwnProperty('statusCode') && '0000' === response.header.statusCode) {
            this.isEnrolled = 'ENROLLED' === response.additionalDetails.carePassEnrollmentStatus;
            this.triggerTag(this.isEnrolled);
            this.fetchBCCContents(
              this._utility.getUserAgent().indexOf('_MOBILE') !== -1,
              response.additionalDetails.carePassEnrollmentStatus
            );
          } else {
            this.serviceError = true;
          }
        } else {
          this.serviceError = true;
        }
      },
      (err) => {
        console.error(err);
        this.serviceError = true;
      },
      () => {}
      );
  }


  fetchBCCContents(isMobile, status) {
    if ('ENROLLED' === status) {
      !isMobile ? this.fetchBusinessContent(30450) : this.fetchBusinessContent(30449)
    } else {
      !isMobile ? this.fetchBusinessContent(30443) : this.fetchBusinessContent(30442)
    }
  }

  triggerTag(isEnrolled) {
    // calling utag.view on page load
    const utagObj = {
      'page_name': '',
      'pageflag': ''
    };

    if (isEnrolled) {
      utagObj.page_name = 'carepass:cvs carepass faq';
      utagObj.pageflag = 'carepass:y';
    } else {
      utagObj.page_name = 'carepass:promo non-member';
      utagObj.pageflag = 'carepass:n';
    }

    setTimeout(() => {
      this._utag.view(utagObj);
    }, 2000);
    
  }

  fetchBusinessContent(contentId) {
    this._ajaxUtility.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            try {
              this.businessContent = this._sanitizer.bypassSecurityTrustHtml(this._utility.getDecrypted(response.details.slotContent));              
            } catch (error) {
              this.businessContent = this._sanitizer.bypassSecurityTrustHtml(this._utility.getDecrypted(response.details.slotContent));              
            }
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }


    /**
   * Logic to open Terms and conditions modal - start
   */

  openAgreementModal() {
    this.fetchTermsContent('30454');
  }

  openTermsModal() {
    if (this.modalBusinessContent) {
      this._modalService.openModal(TermsAndConditionsModalComponent,
        { windowClass: 'terms-conditions-modal' },
        this.modalBusinessContent).result.then(
        (result) => {},
        (reason) => {}
      );
    }
  }
  /**
   * @method fetchPageContent - method to make BCC service call
   * @param contentId - BCC content id
   */

  fetchTermsContent(contentId) {
    this._ajaxUtility.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            this.modalBusinessContent = this._sanitizer.bypassSecurityTrustHtml(this._utility.getDecrypted(response.details.slotContent));
            this.openTermsModal();
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }

  /**
   * Logic to open Terms and conditions modal - end
   */


  /**
   * Logic to dynamically load scripts that are needed for accordion operation - start
   */

     /**
   * @method loadDynamicScripts - method to make BCC service call
   * @param contentId - BCC content id
   */

  loadDynamicScripts(contentId) {
    this._ajaxUtility.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            this.scriptsToLoad = JSON.parse(this._utility.getDecrypted(response.details.slotContent))['scriptsToLoad'];
            this.loadAPI = new Promise((resolve) => {
              this._scriptLoader.loadScript(this.scriptsToLoad);
              resolve(true);
            });
            this._cookieService.exists('SCC_COOKIE') ? this.fetchDigitalProfile() : this.isEnrolled = false;
            if (!this._cookieService.exists('SCC_COOKIE')) {
              this.triggerTag(false);
              this.fetchBCCContents(
                this._utility.getUserAgent().indexOf('_MOBILE') !== -1,
                'NOT_ENROLLED'
              );
            }
          }
        }
      },
      (err) => {
        this.serviceError = true;
        console.error(err);
      }
    );
  }

    /**
   * Logic to dynamically load scripts that are needed for accordion operation - end
   */
}
