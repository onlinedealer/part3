import { Component, EventEmitter, Output, Input } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { SharedConstants } from './../../../shared.constant';

@Component({
  selector: 'discovery-connection-button',
  templateUrl: './connection-button.component.html',
  styleUrls: ['./connection-button.component.css']
})
export class ConnectionButtonComponent {
  @Input() cssClass: string;
  @Output() connectionType: EventEmitter<string> = new EventEmitter<string>();
  get dataBrickFeatureFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.DATABRICK);
  }

  constructor(private translocoService: TranslocoService, private launchDarklyService: LaunchDarklyService) {}

  onButtonClick(type: string): void {
    this.connectionType.emit(type);
  }
}
