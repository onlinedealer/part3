import { SharedConstants } from '../shared.constant';
/**
 * Provides common operations.  This is not an angular service since all methods are static.
 */
export class Helper {
  /**
   * @internal
   */

  /**
   * This method returns give the time format
   */
  public static getTimeFormat(hours: number): string {
    return hours < 12 ? SharedConstants.MERIDIEM_INDICATOR.AM : SharedConstants.MERIDIEM_INDICATOR.PM;
  }

  /**
   * check empty object
   */
  public static isEmpty(obj): boolean {
    for (const x in obj) {
      if (obj[x]) {
        return false;
      }
    }
    return true;
  }

  /**
   * This method returns getFormattedHrsAndMins
   */
  public static getFormattedHrsAndMins(date: Date): { hours: string; minutes: string } {
    return {
      hours:
        (date.getHours() % 12 || 12).toString().length === 1
          ? '0' + (date.getHours() % 12 || 12).toString()
          : (date.getHours() % 12 || 12).toString(),
      minutes:
        date.getMinutes().toString().length === 1 ? '0' + date.getMinutes().toString() : date.getMinutes().toString()
    };
  }

  /**
   * This method returns convertUTCtoLocalTimezone
   */
  public static convertUTCtoLocalTimezone({ hour, minute, meridiemIndicator }): Date {
    const date = new Date();
    const time = this.convertTime12To24Hr(`${hour}:${minute} ${meridiemIndicator}`);
    const [hours, minutes] = time.split(':');
    return new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate(), Number(hours), Number(minutes), 0));
  }

  /**
   * This method returns convertTime12To24Hr
   */
  public static convertTime12To24Hr(timeStr: string): string {
    const [time, modifier] = timeStr.split(' ');
    const hrsAndMins = time.split(':');
    if (Number(hrsAndMins[0]) === 12) {
      hrsAndMins[0] = '00';
    }
    if (modifier === SharedConstants.MERIDIEM_INDICATOR.PM) {
      hrsAndMins[0] = (parseInt(hrsAndMins[0], 10) + 12).toString();
    }
    return `${hrsAndMins[0]}:${hrsAndMins[1]}`;
  }

  /**
   * This method returns camelcase string and remove spaces as per variable rule.
   */
  public static getCamcelCaseString(val) {
    return val.toLowerCase().replace(/\s+(\w)?/gi, (match, letter) => letter.toUpperCase());
  }

  public static getTitleCaseString(val) {
    return val
      .toLowerCase()
      .split(' ')
      .map((s) => s.charAt(0).toUpperCase() + s.substring(1))
      .join(' ');
  }

  // this function will populate values for tooltip from tooltip
  public static getConvertedDateOnToolTip(dateVal: string) {
    const formateDate = new Date(dateVal);
    const date = formateDate.getDate();
    const longMonth = formateDate.toLocaleString('default', { month: 'long' });
    const shortMonth = formateDate.toLocaleString('default', { month: 'short' });
    const year = formateDate.getFullYear();
    const hour = String(formateDate.getHours()).padStart(2, '0');
    const min = String(formateDate.getMinutes()).padStart(2, '0');
    const sec = String(formateDate.getSeconds()).padStart(2, '0');
    return { date, shortMonth, longMonth, year, hour, min, sec };
  }

  public static getFromDate(timeframe: string, date: Date): Date {
    let numericalTimeFrame: number = 0;
    let fromDate: Date = new Date(date?.toUTCString());
    if (timeframe === 'all') {
      fromDate = null;
    } else {
      numericalTimeFrame = this.getDaysInTimeframe(timeframe);
      fromDate?.setDate(fromDate.getDate() - numericalTimeFrame);
    }

    return fromDate;
  }

  public static getFilteredAuthorizedPopularity(data) {
    return data.statistics.filter(
      (stats) => stats.type === SharedConstants.STATS.POPULARITY && stats.isAuthorizedForPopularity
    );
  }

  private static getDaysInTimeframe(timeframe: string): number {
    if (timeframe === 'month') {
      return 30;
    } else if (timeframe === 'year') {
      return 365;
    } else {
      return 7;
    }
  }
}
