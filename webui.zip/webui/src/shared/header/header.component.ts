import { Component, OnInit } from '@angular/core';
import { OpenIdConnectService } from '@precisely/prism-ng/angular-auth-oidc-client';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { User } from '@precisely/prism-ng/user-account';
import { FirstTimeUserService } from 'app/first-time-user.service';
import { first, Observable } from 'rxjs';
import { ProductCardsService } from '@precisely/prism-ng/di-suite';
import { ProductCard } from '@precisely/prism-ng/api';

@Component({
  selector: 'discovery-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  user: User;
  manageUsersUrl: string;
  manageSubsUrl: string;
  products: Observable<ProductCard[]>;

  constructor(
    public firstTimeUserService: FirstTimeUserService,
    public oidc: OpenIdConnectService,
    private httpUtil: HttpUtilService,
    private productCardsService: ProductCardsService
  ) {}

  get activeApp(): string {
    return window.location.pathname === '/' ? 'Overview' : 'Discovery';
  }

  get activeLabel(): string {
    return window.location.pathname === '/'
      ? 'discoveryShared.header.overview-context-menu-label'
      : 'discoveryShared.header.app-context-menu-label';
  }

  ngOnInit() {
    this.manageUsersUrl = this.httpUtil.getUrl('shell', 'dis', 'account-management/users');
    this.manageSubsUrl = this.httpUtil.getUrl('shell', 'dis', 'account-management/subscriptions');
    this.user = {
      firstName: this.oidc.getFirstName(),
      lastName: this.oidc.getLastName(),
      email: this.oidc.getEmail()
    };
    this.products = this.productCardsService
      .all(this.oidc.getCurrentWorkspaceId(), this.oidc.getToken(), this.oidc.getUsername())
      .pipe(first());
  }

  logout() {
    this.oidc.logoff();
  }
}
