import { Spies } from 'discovery-test';
import { DatabrickConnectionConfigureComponent } from './databrick-connection.component';
import { SharedConstants } from 'discovery-shared';
import { ConnectionModel } from '../connection.model';
import { NgForm } from '@angular/forms';

describe('ConnectionConfigureComponent', () => {
  let component: DatabrickConnectionConfigureComponent;

  beforeEach(() => {
    Spies.init();
    component = new DatabrickConnectionConfigureComponent(Spies.TranslateService);
    component.connectionModel = new ConnectionModel();
    component.databricksForm = new NgForm([], []);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('validate Connection Name ', () => {
    component.connectionModel.name = '456@InvalidName';
    component.validateConnectionName();
    expect(component.nameError.invalidName).toBe(true);
  });

  it('should check validate connection name failure', () => {
    component.connectionModel.name =
      'test connectionqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq';
    component.validateConnectionName();
    expect(component.nameError.invalidName).toBe(true);
  });

  it('should test getters setters', () => {
    component.connectionNameRefData = jasmine.createSpyObj('connectionNameRefData', ['nativeElement']);
    const url = 'jdbc:databricks://<Server Hostname>:433;HttpPath=<Http Path>[;property=value[;property=value]]';
    const password = 'password';
    component.url = url;
    component.password = password;
    component.buttonTypeClicked = 'connection-save';
    component.formViewType = SharedConstants.connectionConfigureModes.ADD;
    expect(component.formViewType).toBe(SharedConstants.connectionConfigureModes.ADD);
    expect(component.buttonTypeClicked).toBe('connection-save');
    expect(component.databricksForm.valid).toBe(true);
  });

  it('should emit event on form valid', () => {
    spyOn(component.setFormValidProp, 'emit');
    component.url = 'jdbc:databricks://<Server Hostname>:433;HttpPath=<Http Path>[;property=value[;property=value]]';
    component.password = 'password';
    expect(component.setFormValidProp.emit).toHaveBeenCalled();
  });

  it('should reset form on close', () => {
    const spy = spyOn(component.databricksForm, 'resetForm');
    component.connectionNameRefData = jasmine.createSpyObj('connectionNameRefData', ['nativeElement']);
    console.log(component.connectionNameRefData);
    component.resetFormData = true;
    expect(spy).toHaveBeenCalled();
    expect(component.connectionNameRefData.nativeElement.required).toBe(false);
  });

  it('should set value of resourceType', () => {
    component.connectionModel.resourceConnectionType = '';
    component.ngOnInit();
    expect(component.connectionModel.resourceConnectionType).toBe(SharedConstants.connectionConfigureType.DATABRICKS);
  });
});
