import {
    MeteringPoint,
    StateType,
    Customer,
    Address,
    MeteringPointState,
    Party,
    Region,
    Source,
    MeteringPointsSearchResponse,
    MeteringPointsSearchResponseParameters,
    CustomerType,
    CustomerGroup,
    TypeCurve,
    MeteringPointDetails,
    MeteringPointStates,
    Classification
} from "../meteringpoint.model";

const address: Address = {
    apartment: "string",
    areaName: "string",
    city: "string",
    countryCode: "string",
    postalCode: "string",
    streetName: "string",
    streetNumber: 1,
    streetNumberExtension: "string",
    areaCode: "string",
    territory: "string"
};

const meteringPointStates: MeteringPointStates = {
    name: "string",
    mpLifeCycleStateIdentifier: "string",
    reasonCategoryIdentifier: "string"
};
const customer: Customer = {
    address: address,
    id: 1,
    name: "string",
    customerNo: "A123"
};

const classification: Classification = {
    classificationId: 1,
    extensible: 1,
    identifier: "string",
    name: "string"
};

const customerType: CustomerType = {
    classId: 1,
    identifier: "string",
    classification: classification,
    modifiable: 1,
    name: "string"
};
const customerGroup: CustomerGroup = {
    classId: 1,
    classification: classification,
    identifier: "string",
    modifiable: 1,
    name: "string"
};
const typeCurve: TypeCurve = {
    classId: 1,
    classification: classification,
    identifier: "string",
    modifiable: 1,
    name: "string"
};

const stateType: StateType = {
    displaySequenceNo: 1,
    identifier: "string",
    modifiable: 1,
    mpLifeCycleStateIdentifier: "string",
    mpLifecycleClassName: "string",
    name: "string",
    objectType: 1,
    reasonCategoryClassId: 1,
    reasonCategoryIdentifier: "string",
    stateTypeId: 1,
    usage: 1
};

const meteringpointState: MeteringPointState = {
    commentBy: "string",
    commentTime: "string",
    comments: "string",
    endTime: "string",
    meteringPointStateId: 1,
    startTime: "string",
    stateType: stateType,
    stateValue: "string"
};

const meteringpointStates: MeteringPointState[] = [meteringpointState];

const party: Party = {
    abbreviation: "string",
    allowAperakRequests: 1,
    name: "string",
    partyId: 1
};

const region: Region = {
    childRegionIds: [1, 2, 3],
    name: "string",
    regionId: 1
};

const source: Source = {
    identifier: "string",
    name: "string",
    sourceId: 1,
    sourceType: 1,
    partyId: 1
};

export const meteringpoint: MeteringPointDetails = {
    address: address,
    customer: customer,
    fuseSize: 1,
    id: 1,
    name: "string",
    gsrn: 1,
    xCoordinate: "string",
    yCoordinate: "string",
    controlDate: 0,
    meteringPointStates: meteringpointStates,
    party: party,
    phase: 1,
    region: region,
    remoteConnectable: true,
    source: source,
    transformerArea: "string",
    description: "string",
    meteringPointType: "string",
    customerType: customerType,
    customerGroup: customerGroup,
    typeCurve: typeCurve,
    parentName: "string",
    contractNo: "string",
    productName: "string",
    contractValidFrom: 0
};

export const meteringpoints: MeteringPointDetails[] = [meteringpoint];

export const meteringpointsSearchResponseParameters: MeteringPointsSearchResponseParameters = {
    query: "string",
    type: 1
};

export const meteringpointsSearchResponse: any = {
    parameters: meteringpointsSearchResponseParameters,
    data: meteringpoints
};
