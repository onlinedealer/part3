import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Connection } from '../../../connections/shared/connection';
import { Pipeline, TableMapping } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { MetadataApiService } from '../data/schema-table-selector/metadata-api.service';
import { throwError, of } from 'rxjs';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { RouterTestingModule } from '@angular/router/testing';
import { PipelineMappingComponent } from './pipeline-mapping.component';
import { PipelineMappingService } from './pipeline-mapping.service';
import { DataTableComponent } from './../../pipeline/mapping/data-table/data-table.component';
import { CatalogMetadataApiService } from '../data/schema-table-selector/catalog-metadata-api.service';
import { ConnectionsApiService } from 'src/app/connections/shared/connections-api.service';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogSchema } from 'src/app/connections/catalogs/shared/catalog-schema';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { EventApiService } from './shared/event-api.service';

const mockPipeline = {
  projectId: 'abcd',
  source: {
    dataConnection: { id: 'abcd', connectionType: 'ORACLE' }
  },
  target: {
    dataConnection: { id: 'abcd', connectionType: 'KAFKA' }
  }
} as Pipeline;

describe('PipelineMappingComponent', () => {
  let component: PipelineMappingComponent;
  let fixture: ComponentFixture<PipelineMappingComponent>;
  let pipelineEntityService: PipelineEntityService;
  let mappingService: PipelineMappingService;
  let featureFlagService: FeatureFlagService;
  let connectionsService: ConnectionsApiService;
  let patchPipeline;
  let catalogMetadataApiService: CatalogMetadataApiService;
  let catalogApiService: CatalogApiService;
  let eventApiService: EventApiService;

  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['initiateProgressSteps', 'setActiveStepByRouterLink', 'setIsValid', 'setActiveStepIndex']
  );
  const mockConnections = [{ id: '1', name: 'name1', connectionType: 'SCHEMAREGISTRY' }];

  const mockFeatureFlagService = {
    ldClient: {
      close: () => of(),
      identify: () => of(),
      variation: () => of()
    },
    isFeatureEnabled: (f) => f === 'FLAG1',
    isFeatureDisabled: (f) => f === 'FLAG2'
  };

  beforeEach(async () => {
    TestBed.overrideComponent(PipelineMappingComponent, {
      set: {
        providers: [{ provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService }]
      }
    });
    connectionsService = jasmine.createSpyObj('ConnectionsApiService', ['getAll']);
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, getTranslocoModule(), HttpClientTestingModule],
      providers: [
        { provide: FeatureFlagService, useValue: mockFeatureFlagService },
        { provide: ConnectionsApiService, useValue: connectionsService }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [PipelineMappingComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(PipelineMappingComponent);
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    mappingService = TestBed.inject(PipelineMappingService);
    featureFlagService = TestBed.inject(FeatureFlagService);
    catalogMetadataApiService = TestBed.inject(CatalogMetadataApiService);
    patchPipeline = spyOn(pipelineEntityService, 'patchPipeline');
    eventApiService = TestBed.inject(EventApiService);
    catalogApiService = TestBed.inject(CatalogApiService);

    const mockCatalogStatusReponse = { status: 'complete', schemas: [{ schema: 'test1' } as CatalogSchema] } as CatalogStatus;
    spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatusReponse));
    spyOn(connectionsService, 'getAll').and.returnValue(of(mockConnections));

    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockPipeline);
    spyOn(catalogMetadataApiService, 'getTopics').and.returnValue(of([{ name: 'topic' }]));
    spyOn(mappingService, 'getSelectedTables').and.returnValue(
      of([
        {
          schema: 'schema',
          table: 'table',
          topic: {
            name: '',
            mappingIcon: '',
            iconTooltip: '',
            class: ''
          },
          subject: {
            mappingIcon: ''
          }
        }
      ])
    );
    spyOn(mappingService, 'getColumnHeaders').and.returnValue([{ header: 'Topic', name: 'topic' }]);
    component = fixture.componentInstance;
    component.sourceDataConnection = { connectionType: 'ORACLE' } as Connection;
    component.targetDataConnection = { connectionType: 'DB2i' } as Connection;
    component.pipeline = {
      projectId: 'abcd',
      source: {
        dataConnection: { id: 'abcd' }
      },
      target: {
        dataConnection: { id: 'abcd' }
      },
      tableMapping: []
    } as Pipeline;

    fixture.detectChanges();
    component.dataTableComponent = jasmine.createSpyObj<DataTableComponent>(['emitSelectedData', 'resetSelectedSourceData']);
    spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(false);
    jasmine.getEnv().allowRespy(true);
  });

  it('should create', () => {
    spyOn(featureFlagService, 'isFeatureDisabled').and.returnValue(false);
    expect(component).toBeTruthy();
  });

  it('should run the component execution when feature is enabled', () => {
    spyOn(featureFlagService, 'isFeatureDisabled').and.returnValue(false);
    // spyOn(mappingService, 'getColumnHeaders').and.returnValue([{ header: 'Topic', name: 'topic', isKey: true }]);
    component.ngOnInit();
    expect(component).toBeTruthy();
    // expect(component.pipeline).toBeDefined();
  });

  it('should not run the component execution when feature is disabled', () => {
    spyOn(featureFlagService, 'isFeatureDisabled').and.returnValue(true);
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should check default mapping with exact match topic present', () => {
    const topics = ['topic'];
    component.topics = topics;
    component.tableData = [
      {
        id: 1,
        schema: 'Uxtesting1',
        table: 'topic',
        isButtonEnabled: true,
        topic: {
          name: '',
          mappingIcon: '',
          iconTooltip: '',
          class: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];
    component.pipeline.tableMapping = [
      {
        id: 'mapping_1abc',
        key: 'topic',
        value: 'topic',
        hasCustomColMappings: true,
        type: 'targetDoesNotExist',
        columnMappings: [
          {
            sourceColumnName: 'string',
            sourceColType: 'string',
            action: 'string',
            isKey: true,
            targetColumnName: 'string',
            targetColType: 'string',
            isExpression: false,
            state: 'SOURCE_COLUMN_SUPPORTED'
          }
        ]
      }
    ];
    component.pipeline.tableMapping.length = 1;

    component.defaultMapping(topics);
    expect(component.tableData).toEqual([
      {
        id: 1,
        schema: 'Uxtesting1',
        table: 'topic',
        isButtonEnabled: true,
        topic: {
          name: 'topic',
          mappingIcon: '',
          iconTooltip: '',
          class: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ]);
  });

  it('should add type as TargetDoesNotExist when no targetName is there', () => {
    component.tableData = [
      {
        id: 1,
        schema: 'Uxtesting1',
        table: 'topic',
        isButtonEnabled: true,
        topic: {
          name: '',
          mappingIcon: 'ATTENTION',
          iconTooltip: '',
          class: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];
    component.formMappingDataArr(component.tableData);
    const spy = spyOn(component, 'formMappingDataArr').and.returnValue([
      {
        key: 'Uxtesting1.topic',
        value: '',
        type: 'TargetDoesNotExist'
      }
    ]);
    expect(spy).toHaveBeenCalledTimes(0);
  });

  it('for SQLSERVEER should add type as TargetDoesNotExist when no targetName is there', () => {
    component.sourceDataConnection = { connectionType: 'SQLSERVER' } as Connection;
    component.tableData = [
      {
        id: 1,
        schema: 'Uxtesting1',
        table: 'topic.data',
        isButtonEnabled: true,
        topic: {
          name: '',
          mappingIcon: 'ATTENTION',
          iconTooltip: '',
          class: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];
    component.formMappingDataArr(component.tableData);
    const spy = spyOn(component, 'formMappingDataArr').and.returnValue([
      {
        key: 'Uxtesting1.topic',
        value: '',
        type: 'TargetDoesNotExist'
      }
    ]);
    expect(spy).toHaveBeenCalledTimes(0);
  });

  it('should add type as TargetExistsWithoutMatch when no targetName is there', () => {
    component.tableData = [
      {
        id: 1,
        schema: 'Uxtesting1',
        table: 'topic',
        isButtonEnabled: true,
        topic: {
          name: 'topic12',
          mappingIcon: 'ATTENTION_BLUE',
          iconTooltip: '',
          class: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];
    component.formMappingDataArr(component.tableData);
    const spy = spyOn(component, 'formMappingDataArr').and.returnValue([
      {
        key: 'Uxtesting1.topic',
        value: '',
        type: 'TargetExistsWithoutMatch'
      }
    ]);
    expect(spy).toHaveBeenCalledTimes(0);
  });

  it('should check default mapping with no exact match topic present', () => {
    const topics = ['topic121'];
    component.tableData = [
      {
        id: 1,
        schema: 'Uxtesting1',
        table: 'topic',
        topic: {
          name: '',
          mappingIcon: '',
          iconTooltip: '',
          class: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];
    component.pipeline.tableMapping = [
      {
        id: 'mapping_1abc',
        key: 'topic',
        value: 'topic',
        hasCustomColMappings: true,
        type: 'targetDoesNotExist',
        columnMappings: [
          {
            sourceColumnName: 'string',
            sourceColType: 'string',
            action: 'string',
            isKey: true,
            targetColumnName: 'string',
            targetColType: 'string',
            isExpression: false,
            state: 'SOURCE_COLUMN_SUPPORTED'
          }
        ]
      }
    ];
    component.pipeline.tableMapping.length = 1;

    component.defaultMapping(topics);
    expect(component.tableData[0].placeholder).toEqual('topic');
  });

  it('should add New icon if topic name matches the table name and it also doesnt exist', () => {
    const row = {
      id: 1,
      schema: 'Uxtesting1',
      table: 'topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: '',
        class: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    const topic = 'topic';
    component.topics = ['xyz', 'topic11'];
    component.setTopicDetails(row, topic);
    expect(row.topic.mappingIcon).toEqual('ATTENTION');
  });

  it('should add Mismatch icon if topic exists but doesnt match the added topic', () => {
    const row = {
      id: 1,
      schema: 'Uxtesting1',
      table: 'topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: '',
        class: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    const topic = 'topic123';
    component.topics = ['topic123', 'topic11'];
    component.setTopicDetails(row, topic);
    expect(row.topic.mappingIcon).toEqual('ATTENTION_BLUE');
  });

  it('should add New icon if topic name doesnt match the table name and also doesnt exist', () => {
    const row = {
      id: 1,
      schema: 'Uxtesting1',
      table: 'topic',
      topic: {
        name: '',
        mappingIcon: '',
        iconTooltip: '',
        class: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    const topic = 'topic123';
    component.topics = ['topic12', 'topic11'];
    component.setTopicDetails(row, topic);
    expect(row.topic.mappingIcon).toEqual('ATTENTION');
  });

  it('should clear mapping icon when match found with refresh mapping', () => {
    const row = {
      id: 1,
      schema: 'Uxtesting1',
      table: 'topic',
      topic: {
        name: '',
        mappingIcon: 'ACTION_REQUIRED',
        iconTooltip: '',
        class: ''
      },
      subject: {
        mappingIcon: ''
      }
    };
    const topic = 'topic';
    component.topics = ['topic'];
    component.setTopicDetails(row, topic);
    expect(row.topic.mappingIcon).toEqual('');
  });

  it('should keep track of selected items', () => {
    const checkdItem = [{ id: 'abcd', topic: { name: '' } }];
    component.tableConfiguration.rowSelectionChangedEvent(checkdItem);
    expect(component.checkedItems).toEqual(checkdItem);
  });

  it('should get All Selected source Data', () => {
    component.getAllSelectedData();
    expect(component.dataTableComponent.emitSelectedData).toHaveBeenCalled();
  });

  it('should enable restToDefault button', () => {
    const booleanValue = true;
    component.enableOverviewButtons(booleanValue);
    component.enableBtn = booleanValue;
    expect(component.enableBtn).toBeTruthy();
  });

  it('should reset topic table data', () => {
    component.checkedItems = [
      {
        id: 1,
        schema: 'Uxtesting1',
        table: 'topic',
        topic: {
          name: '',
          mappingIcon: 'ATTENTION_SELECTION',
          iconTooltip: '',
          style: { border: 'none' }
        },
        subject: {
          name: '',
          mappingIcon: ''
        }
      }
    ];
    component.topics = ['topic'];
    component.subjects = ['subjects'];
    const event = {};
    component.isSchemaRegistryThere = true;
    component.resetSideBarBtnClick(event);
    expect(component.dataTableComponent.resetSelectedSourceData).toHaveBeenCalled();
    expect(component.checkedItems[0].topic.name).toBe('topic');
    expect(component.checkedItems[0].subject.name).toBe('');
  });

  it('should throw err if failed to fetch Kafkatopics from API', () => {
    spyOn(catalogMetadataApiService, 'getTopics').and.returnValue(throwError('error'));
    component.getExistingKafkaTopics();
    component.topics = ['topic'];
    expect(component.topics.length).toBe(1);
  });

  describe('Schema Registry', () => {
    const mockConnectionsSchemaRegsitry = [{ id: '1', connectionType: 'SCHEMAREGISTRY', accessMethod: '', name: 'SCHEMAREGISTRY' }];
    beforeEach(() => {
      connectionsService = TestBed.inject(ConnectionsApiService);
    });

    it('should get Existing subjects by calling getSubjects API and when subject name is not empty', () => {
      component.subjects = ['sub'];
      const row = {
        schema: 'schema',
        table: 'table',
        topic: {
          name: 'top',
          mappingIcon: '',
          iconTooltip: ''
        },
        subject: {
          name: 'sub',
          mappingIcon: '',
          iconTooltip: ''
        }
      };

      spyOn(mappingService, 'getSubjectsFromCatalog');
      spyOn(mappingService, 'getMappingIcon').and.returnValue({
        icon: '',
        tooltip: ''
      });
      component.getSubjectDetails(row, component.subjects);
      expect(component.subjects.length).toEqual(1);
    });

    it('should get Existing subjects by calling getSubjects API and when subject name is empty', () => {
      component.subjects = ['sub'];
      const row = {
        schema: 'schema',
        table: 'table',
        topic: {
          name: 'sub',
          mappingIcon: '',
          iconTooltip: ''
        },
        subject: {
          name: '',
          mappingIcon: '',
          iconTooltip: ''
        }
      };
      spyOn(mappingService, 'getMappingIcon').and.returnValue({
        icon: 'ATTENTION',
        tooltip: 'pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1'
      });
      spyOn(mappingService, 'getSubjectsFromCatalog');
      component.getSubjectDetails(row, component.subjects);
      expect(component.subjects.length).toEqual(1);
    });

    // Tests for subjects type conditionally
    it('should get BOTH_TARGET_AND_SUBJECT_EXISTS_WITH_MATCH type for when subject and topic are perfect match', () => {
      const row = {
        topic: {
          mappingIcon: ''
        },
        subject: {
          mappingIcon: ''
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('BOTH_TARGET_AND_SUBJECT_EXISTS_WITH_MATCH');
    });

    it('should get BOTH_TARGET_AND_SUBJECT_DOES_NOT_EXIST type for when subject and topic are new', () => {
      const row = {
        topic: {
          mappingIcon: 'ATTENTION'
        },
        subject: {
          mappingIcon: 'ATTENTION'
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('BOTH_TARGET_AND_SUBJECT_DOES_NOT_EXIST');
    });

    it('should get TARGET_DOES_NOT_EXIST_AND_SUBJECT_EXISTS_WITHOUT_MATCH type for when subject exists and topic not', () => {
      const row = {
        topic: {
          mappingIcon: 'ATTENTION'
        },
        subject: {
          mappingIcon: 'ATTENTION_BLUE'
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('TARGET_DOES_NOT_EXIST_AND_SUBJECT_EXISTS_WITHOUT_MATCH');
    });

    it('should get TARGET_EXISTS_WITHOUT_MATCH_AND_SUBJECT_DOES_NOT_EXIST type for when topic exists and subject not', () => {
      const row = {
        topic: {
          mappingIcon: 'ATTENTION_BLUE'
        },
        subject: {
          mappingIcon: 'ATTENTION'
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('TARGET_EXISTS_WITHOUT_MATCH_AND_SUBJECT_DOES_NOT_EXIST');
    });

    it('should get TARGET_EXISTS_WITH_MATCH_AND_SUBJECT_DOES_NOT_EXIST type for when topic exists and subject not', () => {
      const row = {
        topic: {
          mappingIcon: ''
        },
        subject: {
          mappingIcon: 'ATTENTION'
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('TARGET_EXISTS_WITH_MATCH_AND_SUBJECT_DOES_NOT_EXIST');
    });

    it('should get TARGET_EXISTS_WITH_MATCH_AND_SUBJECT_EXISTS_WITHOUT_MATCH type for when topic exists and subject also but without match', () => {
      const row = {
        topic: {
          mappingIcon: ''
        },
        subject: {
          mappingIcon: 'ATTENTION_BLUE'
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('TARGET_EXISTS_WITH_MATCH_AND_SUBJECT_EXISTS_WITHOUT_MATCH');
    });

    it('should get TARGET_DOES_NOT_EXIST_AND_SUBJECT_EXISTS_WITH_MATCH type for when subject exists and topic not', () => {
      const row = {
        topic: {
          mappingIcon: 'ATTENTION'
        },
        subject: {
          mappingIcon: ''
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('TARGET_DOES_NOT_EXIST_AND_SUBJECT_EXISTS_WITH_MATCH');
    });

    it('should get TARGET_EXISTS_WITHOUT_MATCH_AND_SUBJECT_EXISTS_WITH_MATCH type for when topic exists wihtout match and subjects not', () => {
      const row = {
        topic: {
          mappingIcon: 'ATTENTION_BLUE'
        },
        subject: {
          mappingIcon: ''
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('TARGET_EXISTS_WITHOUT_MATCH_AND_SUBJECT_EXISTS_WITH_MATCH');
    });

    it('should get BOTH_TARGET_AND_SUBJECT_EXISTS_WITHOUT_MATCH type for when topic adn subject exists wihtout match', () => {
      const row = {
        topic: {
          mappingIcon: 'ATTENTION_BLUE'
        },
        subject: {
          mappingIcon: 'ATTENTION_BLUE'
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getTypeofTargetforPayload(row);
      expect(result).toBe('BOTH_TARGET_AND_SUBJECT_EXISTS_WITHOUT_MATCH');
    });

    it('should concatenate topic and subject value if both present', () => {
      const row = {
        topic: {
          name: 'topic',
          mappingIcon: ''
        },
        subject: {
          name: 'subject',
          mappingIcon: ''
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getValueofPayload(row);
      expect(result).toBe('topic||subject');
    });

    it('should concatenate topic if only that is present', () => {
      const row = {
        topic: {
          name: 'topic',
          mappingIcon: ''
        },
        subject: {
          name: '',
          mappingIcon: ''
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getValueofPayload(row);
      expect(result).toBe('topic||');
    });

    it('should concatenate subject if only that is present', () => {
      const row = {
        topic: {
          name: '',
          mappingIcon: ''
        },
        subject: {
          name: 'subject',
          mappingIcon: ''
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getValueofPayload(row);
      expect(result).toBe('||subject');
    });
    it('should return empty string if none of the topic and subject is present', () => {
      const row = {
        topic: {
          name: '',
          mappingIcon: ''
        },
        subject: {
          name: '',
          mappingIcon: ''
        }
      };
      component.isSchemaRegistryThere = true;
      var result = component.getValueofPayload(row);
      expect(result).toBe('');
    });

    it('should getSubjects from catalog', () => {
      const connectionId = 'abc';
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      spyOn(mappingService, 'getSubjectsFromCatalog').and.returnValue(of([{ name: 'subjects' }]));
      component.getSubjects(connectionId);
      expect(component.subjects.length).toEqual(1);
    });

    it('should getSubjects', () => {
      const connectionId = 'abc';
      spyOn(mappingService, 'getSubjectsFromCatalog').and.returnValue(of([{ name: 'subjects' }]));
      component.getSubjects(connectionId);
      expect(component.subjects.length).toEqual(1);
    });

    it('should getSchemaRegistry details from catalog when dataconnection is present', () => {
      component.isSchemaRegistryThere = true;
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      expect(component.setTargetAsperFeatureFlagAndSchemaRegistry()).toEqual('SCHEMAREGISTRY');
    });

    it('should setSubjects if SchemaRegistry present', () => {
      const row = {
        id: 1,
        schema: 'Uxtesting1',
        table: 'abc',
        topic: {
          name: '',
          mappingIcon: '',
          iconTooltip: '',
          class: ''
        },
        subject: {
          name: '',
          mappingIcon: ''
        }
      };
      const topic = 'abc';
      component.isSchemaRegistryThere = true;
      component.setTopicDetails(row, topic, ['abc']);
      expect(row.subject.name).toEqual('abc');
    });

    it('should call get subjects if schema registry', () => {
      component.isSchemaRegistryThere = true;
      spyOn(mappingService, 'getSubjectsFromCatalog').and.returnValue(of([{ name: 'subjects' }]));
      component.getExistingKafkaTopics();
      expect(component.subjects.length).toBe(1);
    });

    it('should throw err if failed to fetch subjects from API', () => {
      spyOn(mappingService, 'getSubjectsFromCatalog').and.returnValue(throwError('error'));
      const connectionId = 'abc';
      component.getSubjects(connectionId);
      expect(component.subjects.length).toBe(0);
    });

    it('should handle topic checkbox change', () => {
      component.tableData = [
        {
          table: 'topic',
          topic: {
            name: '',
            mappingIcon: 'ACTION_REQUIRED',
            iconTooltip: ''
          }
        }
      ];
      component.topics = ['topic'];
      component.onTopicCheckBoxChange(true);
      expect(component.tableData[0].topic.name).toBe('topic');
    });

    it('should handle subject checkbox change', () => {
      component.tableData = [
        {
          table: 'topic',
          topic: {
            name: '',
            mappingIcon: 'ATTENTION_SELECTION'
          },
          subject: {
            name: '',
            mappingIcon: 'ACTION_REQUIRED',
            iconTooltip: ''
          }
        }
      ];
      component.subjects = ['sub'];
      component.onSubjectCheckBoxChange(true);
      expect(component.tableData[0].subject.mappingIcon).toBe('ATTENTION_SELECTION');
    });

    it('should handle with no table name topic checkbox change', () => {
      component.tableData = [
        {
          table: '',
          topic: {
            name: '',
            mappingIcon: 'ACTION_REQUIRED',
            iconTooltip: ''
          }
        }
      ];
      component.topics = ['topic'];
      component.onTopicCheckBoxChange(true);
      expect(component.tableData[0].topic.mappingIcon).toBe('ATTENTION_SELECTION');
    });

    it('should handle when checkbox is unchecked', () => {
      component.tableData = [
        {
          table: '',
          topic: {
            name: '',
            mappingIcon: 'ATTENTION_SELECTION'
          },
          subject: {
            name: '',
            mappingIcon: 'ATTENTION_SELECTION',
            iconTooltip: ''
          }
        }
      ];
      component.onTopicCheckBoxChange(true);
      expect(component.tableData[0].topic.mappingIcon).toBe('ACTION_REQUIRED');
    });
  });

  describe('scalable commit', () => {
    beforeEach(() => {
      spyOn(catalogMetadataApiService, 'getTopics').and.returnValue(of([{ name: 'topic' }]));
      component.sourceDataConnection.connectionType = 'ORACLE';
      const mockCatalogStatus = {
        workspaceId: 'Precisely',
        connectionId: '62e8ec862c4a613ed190b24d',
        schemas: [
          {
            schema: 'DEMO_USER',
            tablesCount: 2,
            tablesCompleted: 1,
            tablesStatus: [
              {
                table: 'TABLE1',
                columnsCount: 1,
                columnsCompleted: 1,
                status: 'complete',
                triggeredAt: '2022-08-02T09:25:55.66Z',
                lastUpdated: '2022-08-02T09:25:55.66Z',
                lastCompleted: '2022-08-02T09:21:34Z'
              },
              {
                table: 'TABLE2',
                columnsCount: 1,
                columnsCompleted: 1,
                status: 'complete',
                triggeredAt: '2022-08-02T09:25:55.662Z',
                lastUpdated: '2022-08-02T09:26:15.461Z',
                lastCompleted: '2022-08-02T09:26:15.461Z'
              }
            ],
            status: 'complete',
            triggeredAt: '2022-08-02T09:25:53.688Z',
            lastUpdated: '2022-08-02T09:26:15.466Z',
            lastCompleted: '2022-08-02T09:26:15.466Z'
          }
        ],
        status: 'complete'
      } as CatalogStatus;

      spyOn(catalogApiService, 'status').and.returnValue(of(mockCatalogStatus));

      const mockGetSelectedTables = [
        {
          id: 'mapping_gdlntujqxuy1',
          schema: 'TEST2 ',
          table: 'TABLE1',
          topic: {
            name: '',
            mappingIcon: 'ACTION_REQUIRED',
            iconTooltip: 'Topic does not exist on target and must be manually created.',
            class: null
          },
          undefined: {
            mappingIcon: '',
            iconTooltip: ''
          },
          hasSchema: true,
          hasTable: true,
          placeholder: 'TABLE1',
          isButtonEnabled: false
        },
        {
          id: 'mapping_gdlntujqxuy2',
          schema: 'DEMO_USER ',
          table: 'TABLE1',
          topic: {
            name: '',
            mappingIcon: 'ACTION_REQUIRED',
            iconTooltip: 'Topic does not exist on target and must be manually created.',
            class: null
          },
          undefined: {
            mappingIcon: '',
            iconTooltip: ''
          },
          hasSchema: true,
          hasTable: true,
          placeholder: 'TABLE1',
          isButtonEnabled: false
        }
      ];
      spyOn(mappingService, 'getSelectedTables').and.returnValue(of(mockGetSelectedTables));
    });

    it('should get the correct metadata service', () => {
      component.getExistingKafkaTopics();
      expect(catalogMetadataApiService.getTopics).toHaveBeenCalled();
    });

    it('should indicate missing schemas', async () => {
      await component.getSelectedTables();
      expect(component.tableData[0].hasSchema).toBe(false);
    });

    it('should handle errors from the catlaog service', async () => {
      spyOn(catalogApiService, 'status').and.returnValue(throwError('error'));
      component.getExistingKafkaTopics();
      await component.getSelectedTables();
      expect(component.catalogStatus).toBe(null);
    });

    it('for DB2 as a source connection mapping', async () => {
      const mockGetSelectedTablesDB2 = [
        {
          id: 'mapping_gdlntujqxuy1',
          library: 'SUPER',
          table: 'TABLE1',
          topic: {
            name: '',
            mappingIcon: 'ACTION_REQUIRED',
            iconTooltip: 'Topic does not exist on target and must be manually created.',
            class: null
          },
          undefined: {
            mappingIcon: '',
            iconTooltip: ''
          },
          hasSchema: true,
          hasTable: true,
          placeholder: 'TABLE1',
          isButtonEnabled: false
        }
      ];

      const mockCatalogStatus: CatalogStatus = {
        workspaceId: 'Precisely',
        connectionId: '62e8ec862c4a613ed190b24d',
        schemas: [
          {
            schema: 'SUPER',
            tablesCount: 1,
            tablesCompleted: 1,
            tablesStatus: [
              {
                table: 'TABLE1',
                columnsCount: 1,
                columnsCompleted: 1,
                status: 'complete',
                triggeredAt: '2022-08-02T09:25:55.66Z',
                lastUpdated: '2022-08-02T09:25:55.66Z',
                lastCompleted: '2022-08-02T09:21:34Z',
                errorMessage: ''
              }
            ],
            status: 'complete',
            triggeredAt: '2022-08-02T09:25:53.688Z',
            lastUpdated: '2022-08-02T09:26:15.466Z',
            lastCompleted: '2022-08-02T09:26:15.466Z'
          }
        ],
        status: 'complete'
      };

      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      spyOn(mappingService, 'getSelectedTables').and.returnValue(of(mockGetSelectedTablesDB2));
      component.sourceDataConnection.connectionType = 'DB2';
      component.catalogStatus = mockCatalogStatus;
      component.handleSelectedTableData(mockGetSelectedTablesDB2);
      expect(component.catalogStatus.connectionId).toEqual('62e8ec862c4a613ed190b24d');
    });

    it('for SQLSERVER as a source connection mapping', async () => {
      const mockGetSelectedTablesSQL = [
        {
          id: 'mapping_gdlntujqxuy1',
          database: 'SUPER',
          table: 'TABLE1',
          topic: {
            name: '',
            mappingIcon: 'ACTION_REQUIRED',
            iconTooltip: 'Topic does not exist on target and must be manually created.',
            class: null
          },
          undefined: {
            mappingIcon: '',
            iconTooltip: ''
          },
          hasSchema: true,
          hasTable: true,
          placeholder: 'TABLE1',
          isButtonEnabled: false
        }
      ];

      const mockCatalogStatusSQL: CatalogStatus = {
        workspaceId: 'Precisely',
        connectionId: '62e8ec862c4a613ed190b24d',
        schemas: [
          {
            schema: 'SUPER',
            tablesCount: 1,
            tablesCompleted: 1,
            tablesStatus: [
              {
                table: 'dbo.TABLE1',
                columnsCount: 1,
                columnsCompleted: 1,
                status: 'complete',
                triggeredAt: '2022-08-02T09:25:55.66Z',
                lastUpdated: '2022-08-02T09:25:55.66Z',
                lastCompleted: '2022-08-02T09:21:34Z',
                errorMessage: ''
              }
            ],
            status: 'complete',
            triggeredAt: '2022-08-02T09:25:53.688Z',
            lastUpdated: '2022-08-02T09:26:15.466Z',
            lastCompleted: '2022-08-02T09:26:15.466Z'
          }
        ],
        status: 'complete'
      };

      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      spyOn(mappingService, 'getSelectedTables').and.returnValue(of(mockGetSelectedTablesSQL));
      component.sourceDataConnection.connectionType = 'SQLSERVER';
      component.catalogStatus = mockCatalogStatusSQL;
      component.handleSelectedTableData(mockGetSelectedTablesSQL);
      expect(component.catalogStatus.connectionId).toEqual('62e8ec862c4a613ed190b24d');
    });
  });

  it('should update tableMapping information', () => {
    const event = { subject: { name: 'abc' }, version: 1 };
    component.tableData = [
      {
        table: '',
        topic: { name: '' },
        subject: { name: 'abc' },
        schemaVersion: ''
      },
      {
        table: '',
        topic: { name: '' },
        subject: { name: 'abc' },
        schemaVersion: ''
      },
      {
        table: '',
        topic: { name: '' },
        subject: { name: 'abc1' },
        schemaVersion: ''
      }
    ];
    component.tableMappingUpdateChange(event);
    expect(component.tableData[0].schemaVersion).toBe(1);
    expect(component.tableData[1].schemaVersion).toBe(1);
    expect(component.tableData[2].schemaVersion).toBe('');
  });

  it('should handle cancelling create metabase', () => {
    spyOn(component, 'navigateTo');
    component.addUserDBCancelButtonClicked(true);
    expect(component.navigateTo).toHaveBeenCalledWith(`/pipelines/${mockPipeline.id}/edit/data`);
    expect(mockProgressIndicatorStateService.setActiveStepIndex).toHaveBeenCalledWith(1);
  });
});
