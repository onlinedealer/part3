import { BehaviorSubject, Observable, combineLatest } from "rxjs";
import { Contract } from "../../../models/contract.model";
import { map } from "rxjs/operators";
import { isNil, isNumber } from "lodash";

export class ContractsSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: string }> = new BehaviorSubject({
        active: "validTo",
        direction: "desc"
    });

    public getSortedContracts(contracts$: Observable<Contract[]>): Observable<Contract[]> {
        return combineLatest([this.sortingSubject.asObservable(), contracts$]).pipe(
            map(([sortingValues, contracts]) => (sortingValues.direction === "" ? contracts : [...contracts].sort(this.contractComparator)))
        );
    }

    public onSortEvent(event: { active: string; direction: string }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    contractComparator = (c1: Contract, c2: Contract): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "contractNo":
                return this.sortByString(c1.contractNo, c2.contractNo, directionMultiplier);
            case "contractType":
                return this.sortByString(c1.contractType, c2.contractType, directionMultiplier);
            case "supplierParty":
                return this.sortByString(
                    c1.supplierParty ? c1.supplierParty.name : null,
                    c2.supplierParty ? c2.supplierParty.name : null,
                    directionMultiplier
                );
            case "periodicity":
                return this.sortByString(
                    c1.periodicity ? c1.periodicity.name : null,
                    c2.periodicity ? c2.periodicity.name : null,
                    directionMultiplier
                );
            case "validFrom":
                return c1.validFrom > c2.validFrom ? directionMultiplier : -1 * directionMultiplier;
            case "validTo":
                return this.sortByValidityOfDates(c1, c2, directionMultiplier);
            case "product":
                return this.sortByString(c1.product ? c1.product.name : null, c2.product ? c2.product.name : null, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByString(value1: string | null, value2: string | null, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }

        return directionMultiplier;
    }

    sortByValidityOfDates(m1: Contract, m2: Contract, directionMultiplier: number) {
        if (isNumber(m1.validTo) && isNumber(m2.validTo)) {
            return m1.validTo > m2.validTo ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(m1.validTo) && isNil(m2.validTo)) {
            return m1.validFrom > m2.validFrom ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(m1.validTo)) {
            return directionMultiplier;
        }

        if (isNil(m2.validTo)) {
            return -1 * directionMultiplier;
        }

        return 0;
    }
}
