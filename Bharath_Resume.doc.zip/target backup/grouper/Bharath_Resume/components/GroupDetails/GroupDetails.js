import React from 'react'
import _ from 'lodash'
import LoadingHOC from '../common/HOC/LoadingHOC'
import GroupHeader from './GroupHeader'
import GroupFooter from './GroupFooter'
import GroupItems from './GroupItems'
import GrouperDialog from '../common/GrouperDialog/GrouperDialog'

class GroupDetails extends React.Component {
  constructor (props) {
    super(props)
    let groupData = { ...props.groupDetails }
    let groupTcinData = []
    if (!props.groupDetails.group_id) {
      groupTcinData = props.variationPage1Data.tcin_data
    } else if (props.groupDetails.items) {
      props.groupDetails.items.map((grpItem) => {
        const curAction = grpItem.newelyAdded ? 'ADDED' : 'UPDATED'
        groupTcinData.push({ tcin: grpItem.tcin, sort_order: grpItem.sort_order, action: curAction })
      })
    }

    let themeTcinStateValue = []
    if (!props.groupDetails.group_id) {
      props.variationPage1Data.tcin_data.map((tcinObj) => {
        let tempTcinObj = { ...tcinObj }
        tempTcinObj.var_theme_value_list = []
        props.variationPage1Data.themes.map((themeObj) => {
          let tempThemeObj = {
            id: themeObj.id,
            fixed_theme_id: themeObj.fixed_theme_id,
            fixed_theme_name: themeObj.fixed_theme_name,
            value: '',
          }
          tempTcinObj.var_theme_value_list.push(tempThemeObj)
        })
        themeTcinStateValue.push(tempTcinObj)
      })
    }

    this.state = {
      groupData,
      isSaveDisabled: true,
      selected: [],
      dialogOpenStatus: false,
      selectedTcin: [],
      themeTcinStateValue,
      groupTcinData,
      editThemeValueStatus: false,
      themeUpdatedFlag: false,
      pipelineDialogOpenStatus: false,
    }
  }

  componentWillMount () {
    if (this.props.collectionMTAs.length === 0 && this.props.groupDetails.group_type === 'collection') {
      this.props.getCollectionMtas(this.props.groupDetails.item_type_id)
    }
  }

  componentWillReceiveProps = (nextProps) => {
    const { requestType, groupDetails, variationPage1Data } = nextProps
    // if (requestType === 'GROUP_DETAILS' && groupDetails) {
    if (groupDetails) {
      this.setState({ groupData: { ...groupDetails } })
      this.props.clearActionTypes()
    } else if (requestType === 'ORDER_UPDATED') {
      this.setState({ isSaveDisabled: true })
    }

    // update gropup tcin data
    let groupTcinData = []
    if (!groupDetails.group_id) {
      groupTcinData = variationPage1Data.tcin_data
    } else if (groupDetails.items) {
      groupDetails.items.map((grpItem) => {
        const curAction = grpItem.newelyAdded ? 'ADDED' : 'UPDATED'
        groupTcinData.push({ tcin: grpItem.tcin, sort_order: grpItem.sort_order, action: curAction })
      })
    }
    this.setState({ groupTcinData })

    if (!groupDetails.group_id) {
      // Update themeTcinStateValue - create flow
      let tempThemeTcinStateValue = []
      const { themeTcinStateValue } = this.state
      variationPage1Data.tcin_data.map((tcinObj) => {
        let tempTcinObj = { ...tcinObj }
        tempTcinObj.var_theme_value_list = []
        variationPage1Data.themes.map((themeObj) => {
          let curValue = ''
          const curTcinRow = _.find(themeTcinStateValue, (e) => { return parseInt(e.tcin) === parseInt(tcinObj.tcin) })
          if (curTcinRow) {
            const curTcinIndex = _.findIndex(curTcinRow.var_theme_value_list, (e) => { return parseInt(e.id) === parseInt(themeObj.id) })
            curValue = curTcinIndex !== -1 ? curTcinRow.var_theme_value_list[curTcinIndex].value : ''
          }
          let tempThemeObj = {
            id: themeObj.id,
            fixed_theme_id: themeObj.fixed_theme_id,
            fixed_theme_name: themeObj.fixed_theme_name,
            value: curValue,
          }
          tempTcinObj.var_theme_value_list.push(tempThemeObj)
        })
        tempThemeTcinStateValue.push(tempTcinObj)
      })
      this.setState({ themeTcinStateValue: tempThemeTcinStateValue })
      // end of Update themeTcinStateValue - create flow
    } else if (groupDetails.group_id && groupDetails.group_type === 'variation' && groupDetails.items) {
      // Update themeTcinStateValue - update flow
      let tempThemeTcinStateValue = []
      const { themeTcinStateValue } = this.state
      groupDetails.items.map((tcinObj) => {
        const curAction = tcinObj.newelyAdded ? 'ADDED' : 'UPDATED'
        let tempTcinObj = {
          tcin: tcinObj.tcin,
          action: curAction,
          sort_order: tcinObj.sort_order,
          var_theme_value_list: [],
        }
        groupDetails.themes.map((themeObj) => {
          let curValue = ''
          const curTcinRow = _.find(themeTcinStateValue, (e) => { return parseInt(e.tcin) === parseInt(tcinObj.tcin) })
          if (curTcinRow) {
            const curTcinIndex = _.findIndex(curTcinRow.var_theme_value_list, (e) => { return parseInt(e.id) === parseInt(themeObj.id) })
            curValue = curTcinIndex !== -1 ? curTcinRow.var_theme_value_list[curTcinIndex].value : ''
          }
          if (curValue === '') {
            /* const curThemeValue = tcinObj.variation_theme_values[themeObj.attribute]
            curValue = curThemeValue.substring(1, curThemeValue.length - 1) */
            curValue = tcinObj.variation_theme_values[themeObj.attribute]
          }
          let tempThemeObj = {
            id: themeObj.id,
            fixed_theme_id: themeObj.fixed_theme_id,
            fixed_theme_name: themeObj.fixed_theme_name,
            value: curValue,
          }
          tempTcinObj.var_theme_value_list.push(tempThemeObj)
        })
        tempThemeTcinStateValue.push(tempTcinObj)
      })
      this.setState({ themeTcinStateValue: tempThemeTcinStateValue })
      // end of Update themeTcinStateValue - update flow
    }
  }

    moveItemUp = (item) => {
      let curGroupTcinData = this.state.groupTcinData
      const sortValue = item.sort_order
      curGroupTcinData.map((data) => {
        if (data.tcin === item.tcin) {
          data.sort_order = data.sort_order - 1
        } else if (data.sort_order === (sortValue - 1)) {
          data.sort_order = sortValue
        }
      })

      // udpate groupData
      let curGroupData = this.state.groupData
      curGroupData.items.map((data) => {
        const curGroupTcinDataObj = _.find(curGroupTcinData, (e) => { return parseInt(e.tcin) === parseInt(data.tcin) })
        data.sort_order = curGroupTcinDataObj.sort_order
      })

      this.setState({ groupTcinData: curGroupTcinData, groupData: curGroupData, isSaveDisabled: false })
    }

    moveItemDown = (item) => {
      let curGroupTcinData = this.state.groupTcinData
      const sortValue = item.sort_order
      curGroupTcinData.map((data) => {
        if (data.tcin === item.tcin) {
          data.sort_order = data.sort_order + 1
        } else if (data.sort_order === (sortValue + 1)) {
          data.sort_order = sortValue
        }
      })

      // udpate groupData
      let curGroupData = this.state.groupData
      curGroupData.items.map((data) => {
        const curGroupTcinDataObj = _.find(curGroupTcinData, (e) => { return parseInt(e.tcin) === parseInt(data.tcin) })
        data.sort_order = curGroupTcinDataObj.sort_order
      })

      this.setState({ groupTcinData: curGroupTcinData, groupData: curGroupData, isSaveDisabled: false })
    }

    validateUpdate = () => {
      const { groupDetails, auth, variationPage1Data } = this.props
      const { groupData, groupTcinData } = this.state
      if (groupDetails && groupDetails.group_id) {
        if (groupTcinData.length > 0) {
          let payload = {
            tcin_data: groupTcinData,
          }
          payload.description = groupDetails.description
          payload.group_name = groupDetails.group_name
          payload.group_type = groupDetails.group_type
          payload.group_id = groupDetails.group_id
          payload.group_type_id = groupDetails.group_type_id
          payload.status = groupDetails.status
          payload.item_type_id = groupDetails.item_type_id
          payload.item_type = groupDetails.item_type
          payload.themes = groupDetails.themes
          payload.sort_order_updated = true
          payload.update_request_for_variation = true
          this.props.updateItemsOrder(payload, groupData, auth.memberOf, auth.lanId)
        } else {
          this.setState({ isSaveDisabled: true })
        }
      } else {
        let tempGroupDetails = groupDetails
        let tempPage1Data = variationPage1Data
        tempGroupDetails.tcin_data = groupTcinData
        tempPage1Data.tcin_data = groupTcinData
        this.props.setVariationDetails(tempPage1Data, tempGroupDetails)
      }
      this.setState({ isSaveDisabled: true })
    }

    removeSelected = (listTcins) => {
      this.setState({ selected: listTcins })
    }

    removeMultipleConfirmCheck = () => {
      this.setState({dialogOpenStatus: true, selectedTcin: this.state.selected})
    }

    contentPipelineCheck = () => {
      // this.setState({pipelineDialogOpenStatus: true, selectedTcin: this.state.selected})
      const { groupDetails, auth } = this.props
      const tcinsList = [groupDetails.parent_tcin]
      groupDetails.items.map((itemObj) => {
        tcinsList.push(itemObj.tcin)
      })
      const pipelineUrl = 'https://pipeline.prod.k8s.target.com/images/manage?navigationAction=manageImages&userId=' + auth.lanId + '&tcins=' + tcinsList
      window.open(pipelineUrl)
    }

    removeMultipleConfirm = (status) => {
      let count = 1
      let tcinData = []
      const { groupDetails, auth, variationPage1Data } = this.props
      if (status) {
        if (groupDetails.group_id) {
          groupDetails.items.map((data, key) => {
            if (this.state.selected.indexOf(data.tcin) === -1) {
              tcinData.push({ tcin: data.tcin, sort_order: count, action: 'UPDATED' })
              count++
            } else {
              tcinData.push({ tcin: data.tcin, action: 'DELETED' })
            }
          })

          let payload = {
            tcin_data: tcinData,
          }
          payload.description = groupDetails.description
          payload.group_name = groupDetails.group_name
          payload.group_type = groupDetails.group_type
          payload.group_id = groupDetails.group_id
          payload.group_type_id = groupDetails.group_type_id
          payload.status = groupDetails.status
          payload.item_type_id = groupDetails.item_type_id
          payload.item_type = groupDetails.item_type
          payload.themes = groupDetails.themes
          payload.update_request_for_variation = true
          this.props.removeTcins(payload, auth.memberOf, auth.lanId)
        } else {
          let tempGroupDetails = groupDetails
          let tempPage1Data = variationPage1Data
          let tcinDataItems = []
          groupDetails.items.map((data, key) => {
            if (this.state.selected.indexOf(data.tcin) === -1) {
              tcinData.push({ tcin: data.tcin, sort_order: count, action: 'CREATED' })
              tcinDataItems.push(data)
              count++
            }
          })
          tempGroupDetails.tcin_data = tcinData
          tempGroupDetails.items = tcinDataItems
          tempPage1Data.tcin_data = tcinData

          this.props.setVariationDetails(tempPage1Data, tempGroupDetails)
        }
      }
      this.setState({dialogOpenStatus: false, selectedGroup: '', selectedGroupType: '', selected: []})
    }

    contentPipelineConfirm = (status) => {
      if (status) {
        const lanId = this.props.auth.lanId
        const pipelineUrl = 'https://pipeline.prod.k8s.target.com/images/manage?navigationAction=manageImages&userId=' + lanId + '&tcins=' + this.state.selected
        window.open(pipelineUrl)
      }
      this.setState({pipelineDialogOpenStatus: false, selectedGroup: '', selectedGroupType: '', selected: []})
    }

    createVariationGroup = () => {
      let { variationPage1Data, groupDetails } = this.props
      variationPage1Data.first_page_variation_request = false
      variationPage1Data.items = groupDetails.items
      variationPage1Data.tcin_data.map((tcinObj) => {
        const tcinValueObj = _.find(this.state.themeTcinStateValue, (e) => { return e.tcin === tcinObj.tcin })
        tcinObj.var_theme_value_list = tcinValueObj.var_theme_value_list
      })
      variationPage1Data.launch_date = groupDetails.launch_date
      variationPage1Data.department_id = groupDetails.department_id
      variationPage1Data.department_name = groupDetails.department_name
      this.props.addGroup(variationPage1Data)
    }

    updateThemeValue = (themeValue) => {
      this.setState({ themeTcinStateValue: themeValue })
    }

    editThemeValues = () => {
      this.setState({ editThemeValueStatus: !this.state.editThemeValueStatus })
    }

    themeUpdatedFlag = (flagUpdatedSatus) => {
      if (flagUpdatedSatus) {
        this.setState({ editThemeValueStatus: true, themeUpdatedFlag: true })
      }
    }

    sendThemeValue = () => {
      const { groupDetails, auth } = this.props
      groupDetails.tcin_data = this.state.themeTcinStateValue
      groupDetails.update_request_for_variation = true
      groupDetails.theme_updated = true
      this.props.sendUpdateGroupVariationDetails(groupDetails, 'Update Theme Value', auth.memberOf, auth.lanId)
      setTimeout(() => {
        this.editThemeValues()
      }, 1000)
    }

    changeCollectionPublishStatus = (eventType) => {
      const { groupDetails } = this.props
      const sendData = {
        group_ids: [{
          group_id: groupDetails.group_id,
          parent_tcin: groupDetails.parent_tcin,
          group_type: groupDetails.group_type,
        }],
      }
      this.props.changeCollectionPublishStatus(sendData, eventType)
    }
    render () {
      const { auth, groupDetails, itemThemes, removeTcins, requestType, updateGroupName, clearActionTypes, getItemThemes, collectionMTAs, loadingBtnStatus, history } = this.props
      const { groupData, isSaveDisabled, dialogOpenStatus, groupTcinData, editThemeValueStatus, themeTcinStateValue, pipelineDialogOpenStatus } = this.state
      const isRemoveDisabled = (this.state.selected.length === 0)
      let haveImageStatus = false
      this.state.selectedTcin.map((opt) => {
        const itemObj = _.find(groupDetails.items, (n) => { return n.tcin === opt })
        if (itemObj.image_base_url) {
          haveImageStatus = true
        }
      })
      let dialogContent = `Are you sure to add content pipeline images for ${this.state.selectedTcin.length} TCIN(s)? : ${this.state.selectedTcin}`
      let dialogNote = ''
      if (haveImageStatus) {
        dialogNote = 'Note: some TCINs already image assiociated'
      }
      return (
        <div>
          <GroupHeader
            groupDetails={groupDetails}
            auth={auth}
            updateGroupName={updateGroupName}
            requestType={requestType}
            clearActionTypes={clearActionTypes}
            itemThemes={itemThemes}
            getItemThemes={getItemThemes}
            collectionMTAs={collectionMTAs}
            loadingBtnStatus={loadingBtnStatus}
            history={history}
            updateVariationGroupName={this.props.updateVariationGroupName}
            fixedThemes={this.props.fixedThemes}
            variationPage1Data={this.props.variationPage1Data}
            updateVariationDetails={this.props.updateVariationDetails}
            editThemeValueStatus={editThemeValueStatus}
            editThemeValuesCB={this.editThemeValues}
            setGroupDetails={this.props.setGroupDetails}
            themeUpdatedFlagCB={this.themeUpdatedFlag}
            changeCollectionPublishStatusCB={this.changeCollectionPublishStatus}
          />
          <GroupItems
            groupDetails={groupData}
            auth={auth}
            removeTcins={removeTcins}
            moveItemUp={this.moveItemUp}
            moveItemDown={this.moveItemDown}
            groupDetailsErrorTcins={this.props.groupDetailsErrorTcins}
            removeSelectedCB={this.removeSelected}
            defaultSelected={this.state.selected}
            collectionMTAs={collectionMTAs}
            variationPage1Data={this.props.variationPage1Data}
            setVariationDetails={this.props.setVariationDetails}
            updateThemeValueCB={this.updateThemeValue}
            groupTcinData={groupTcinData}
            editThemeValueStatus={editThemeValueStatus}
            themeTcinStateValue={themeTcinStateValue}
          />
          <GroupFooter
            groupDetails={groupDetails}
            isSaveDisabled={isSaveDisabled}
            validateUpdate={this.validateUpdate}
            isRemoveDisabled={isRemoveDisabled}
            removeMultipleConfirmCB={this.removeMultipleConfirmCheck}
            loadingBtnStatus={this.props.loadingBtnStatus}
            createVariationGroupCB={this.createVariationGroup}
            themeTcinStateValue={themeTcinStateValue}
            editThemeValueStatus={editThemeValueStatus}
            sendThemeValueCB={this.sendThemeValue}
            themeUpdatedFlag={this.state.themeUpdatedFlag}
            contentPipelineCB={this.contentPipelineCheck}
          />
          <GrouperDialog
            openStatus={dialogOpenStatus}
            deleteConfirmCallback={this.removeMultipleConfirm}
            title="Remove TCIN(s)"
            message={`Are you sure to remove ${this.state.selectedTcin.length} TCIN(s)? : ${this.state.selectedTcin}`}
            disAgreeText="Cancel"
            agreeText="Remove"
          />
          <GrouperDialog
            openStatus={pipelineDialogOpenStatus}
            deleteConfirmCallback={this.contentPipelineConfirm}
            title="Content Pipeline"
            message={dialogContent}
            disAgreeText="Cancel"
            agreeText="Send"
            dialogNote={dialogNote}
          />
        </div>
      )
    }
}

export default LoadingHOC(['groupDetails'])(GroupDetails)
