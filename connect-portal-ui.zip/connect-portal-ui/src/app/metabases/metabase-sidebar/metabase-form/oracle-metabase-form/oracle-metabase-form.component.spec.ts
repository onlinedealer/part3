import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { AuthModule } from 'angular-auth-oidc-client';
import { Connection } from '../../../../connections/shared/connection';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { SharedModule } from '../../../../shared/shared.module';
import { OracleMetabaseFormComponent } from './oracle-metabase-form.component';

describe('OracleMetabaseFormComponent', () => {
  let component: OracleMetabaseFormComponent;
  let fixture: ComponentFixture<OracleMetabaseFormComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [OracleMetabaseFormComponent],
      imports: [
        getTranslocoModule(),
        FormsModule,
        ReactiveFormsModule,
        SharedModule,
        HttpClientTestingModule,
        AuthModule.forRoot({}),
        RouterModule.forRoot([])
      ],
      providers: [
        {
          provide: TRANSLOCO_SCOPE,
          useValue: { scope: 'metabases' }
        },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OracleMetabaseFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the database server control value if a data connection is passed', () => {
    component.dataConnection = { database: 'test', port: 30000 } as Connection;
    component.ngOnInit();
    expect(component.oracleMetabaseForm.get('databaseServer').value).toBe('test:30000');
  });

  it('should NOT set the database server control value if a data connection is NOT passed', () => {
    component.ngOnInit();
    expect(component.oracleMetabaseForm.get('databaseServer').value).toBe('');
  });

  it('should return a metabase object from the form', () => {
    component.ngOnInit();
    component.oracleMetabaseForm.patchValue({
      userID: 'sa',
      password: '',
      replicationUserID: '',
      replicationPassword: '',
      metabaseName: '',
      tablespaceName: '',
      dataFile: '',
      dataFileSize: '',
      temporaryTablespaceName: '',
      temporaryDataFile: '',
      temporaryDataFileSize: ''
    });
    component.oracleMetabaseForm.addControl('dataConnection', new FormControl('1'));
    const metabase = component.metabase;
    expect(metabase.adminUserId).toBe('sa');
    expect(metabase.parameters.length).toBe(8);
  });

  it('should update fields when metabase name changes', () => {
    component.ngOnInit();
    component.oracleMetabaseForm.addControl('dataConnection', new FormControl('1'));
    component.oracleMetabaseForm.patchValue({ replicationUserID: 't' });
    const event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });

    const oracleReplicationUserIDInput = fixture.debugElement.query(By.css('[data-cy="oracleReplicationUserID"]'));
    oracleReplicationUserIDInput.nativeElement.dispatchEvent(event);
    oracleReplicationUserIDInput.nativeElement.value = 't';
    fixture.detectChanges();

    expect(component.oracleMetabaseForm.get('dataFile').value).toBe('REP1_t.dat');
    expect(component.oracleMetabaseForm.get('tablespaceName').value).toBe('REP1_t');
  });

  it('should update data file when tablespace name changes', () => {
    component.ngOnInit();
    component.oracleMetabaseForm.addControl('dataConnection', new FormControl('1'));
    component.oracleMetabaseForm.patchValue({ tablespaceName: 't' });
    const event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });
    const oracleTablespaceNameInput = fixture.debugElement.query(By.css('[data-cy="oracleTablespaceName"]'));
    oracleTablespaceNameInput.nativeElement.dispatchEvent(event);
    oracleTablespaceNameInput.nativeElement.value = 't';
    fixture.detectChanges();
    expect(component.oracleMetabaseForm.get('dataFile').value).toBe('t.dat');
  });

  it('should update temporary DataFile  when temporaryTablespaceName name changes', () => {
    component.oracleMetabaseForm.addControl('dataConnection', new FormControl('1'));
    component.oracleMetabaseForm.patchValue({ temporaryTablespaceName: 't' });
    const event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });
    const oracleTemporaryTablespaceNameInput = fixture.debugElement.query(By.css('[data-cy="oracleTemporaryTablespaceName"]'));
    oracleTemporaryTablespaceNameInput.nativeElement.dispatchEvent(event);
    oracleTemporaryTablespaceNameInput.nativeElement.value = 't';
    fixture.detectChanges();
    expect(component.oracleMetabaseForm.get('temporaryDataFile').value).toBe('t.dat');
  });
});
