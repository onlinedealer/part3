import { CdkDragDrop, moveItemInArray } from "@angular/cdk/drag-drop";
import { cloneDeep, isEqual } from "lodash";
import { Component, OnInit, Inject } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../../src/app/services/translations-service";
import * as eventsColumnConfig from "../../store/selectors/ui.selectors";
import * as changeLogColumnConfig from "../../../Tasks/store/selectors/ui.selectors";
import { LocalStorageKeys } from "../../../app/services/local-storage.service";
import { LocalStorageService } from "../../../app/services/local-storage.service";

@Component({
    selector: "landisgyr-edit-column-dialog",
    templateUrl: "./edit-column-dialog.component.html",
    styleUrls: ["./edit-column-dialog.component.scss"]
})
export class EditColumnDialogComponent implements OnInit {
    public columnData: any = null;
    public columns: any[] = [];
    public draggedColumns: any[] = [];
    tabSelection!: string;
    editColumnSaveButton = true;
    isLocationChanged = false;
    restoreDefaultSettingsLinkEnable: any;
    expansion!: boolean;

    eventsColumnConfigInitial$: Observable<any> = this.store.select(eventsColumnConfig.getEventsColumnConfigInitial);
    pqiColumnConfigInitial$: Observable<any> = this.store.select(eventsColumnConfig.getPqiColumnConfigInitial);
    prepaymentColumnConfigInitial$: Observable<any> = this.store.select(eventsColumnConfig.getPrepaymentConfigInitial);
    prepaymentCollapsedColumnConfigInitial$: Observable<any> = this.store.select(
        eventsColumnConfig.getPrepaymentCollapsedColumnConfigInitial
    );
    MPDetailsColumnConfigInitial$: Observable<any> = this.store.select(eventsColumnConfig.getMPDetailsColumnConfigInitial);
    profilePeriodicColumnConfigInitial$: Observable<any> = this.store.select(eventsColumnConfig.getProfilePeriodicColumnConfigInitial);
    profilePeriodicCollapsedColumnConfigInitial$: Observable<any> = this.store.select(
        eventsColumnConfig.getProfilePeriodicCollapsedColumnConfigInitial
    );
    changeLogColumnConfigInitial$: Observable<any> = this.store.select(changeLogColumnConfig.getChangeLogColumnConfigInitial);

    constructor(
        public dialog: MatDialog,
        public dialogRef: MatDialogRef<EditColumnDialogComponent>,
        private store: Store<MeteringPointsFeatureState>,
        public translations: TranslationsService,
        private localStorage: LocalStorageService,
        @Inject(MAT_DIALOG_DATA) dialogData: any
    ) {
        this.columnData = dialogData;
    }

    ngOnInit() {
        this.columns = cloneDeep(this.columnData.header);
        this.draggedColumns = cloneDeep(this.columns);
        this.tabSelection = cloneDeep(this.columnData.tabSelectionFlag);
        this.expansion = cloneDeep(this.columnData.Expansion);
        this.removeHighlightingColumn();
        this.restoreDefaultSettingsLinkEnable = this.checkRestoreLinkEnable();
        this.dialogRef.updateSize("550px", ((this.columns.length + 1) * 37 + 150).toString() + "px");
    }

    removeHighlightingColumn() {
        this.columns.forEach((element) => {
            element.draggedColumn = false;
        });
    }

    // checking atleast one checkbox checked or not, if not disabling save button
    enableDisableSaveButton() {
        let checkBoxCount = 0;
        this.columns.forEach((element) => {
            if (element.showColumn === true) {
                checkBoxCount++;
            }
        });
        const columnEqualityCheck = isEqual(this.columns, this.draggedColumns);
        if (columnEqualityCheck || checkBoxCount === 0) {
            this.editColumnSaveButton = true;
        } else {
            this.editColumnSaveButton = false;
        }
    }

    checkColumnChange(index: number) {
        this.columns.forEach((ele, i) => {
            if (
                this.columns[i].columnName !== this.draggedColumns[i].columnName ||
                this.columns[i].showColumn !== this.draggedColumns[i].showColumn
            ) {
                this.columns[i].draggedColumn = true;
            } else {
                this.columns[i].draggedColumn = false;
            }
        });

        this.enableDisableSaveButton();
        this.restoreDefaultSettingsLinkEnable = this.checkRestoreLinkEnable();
    }

    dropColumnItem(event: CdkDragDrop<string[]>) {
        moveItemInArray(this.columns, event.previousIndex, event.currentIndex);
        this.checkColumnChange(event.currentIndex);
    }
    columnChangeCheck(Values: Observable<any>) {
        let count = 0;
        Values.subscribe((defaultValues) => {
            defaultValues.forEach((ele: any, index: any) => {
                if (ele.columnName === this.columns[index].columnName && this.columns[index].showColumn === true) {
                    count++;
                }
            });
        });

        if (count === this.columns.length) {
            return false;
        } else {
            return true;
        }
    }

    // Restore to default
    checkRestoreLinkEnable() {
        let checkValue: boolean;
        if (this.tabSelection === LocalStorageKeys.mpSearchTable) {
            checkValue = this.columnChangeCheck(this.MPDetailsColumnConfigInitial$);
        } else if (this.tabSelection === LocalStorageKeys.eventTime) {
            checkValue = this.columnChangeCheck(this.eventsColumnConfigInitial$);
        } else if (this.tabSelection === LocalStorageKeys.changeLogs) {
            checkValue = this.columnChangeCheck(this.changeLogColumnConfigInitial$);
        } else if (this.tabSelection === LocalStorageKeys.pqiTable) {
            checkValue = this.columnChangeCheck(this.pqiColumnConfigInitial$);
        } else if (
            this.tabSelection === LocalStorageKeys.prepaymentTableCollapsed ||
            this.tabSelection === LocalStorageKeys.prepaymentTable
        ) {
            if (this.expansion) {
                checkValue = this.columnChangeCheck(this.prepaymentColumnConfigInitial$);
            } else {
                checkValue = this.columnChangeCheck(this.prepaymentCollapsedColumnConfigInitial$);
            }
        } else if (
            this.tabSelection === LocalStorageKeys.meteringDataTableCollapsed ||
            this.tabSelection === LocalStorageKeys.meteringDataTable
        ) {
            if (this.expansion) {
                checkValue = this.columnChangeCheck(this.profilePeriodicColumnConfigInitial$);
            } else {
                checkValue = this.columnChangeCheck(this.profilePeriodicCollapsedColumnConfigInitial$);
            }
        } else {
            checkValue = false;
        }
        return checkValue;
    }

    onClickSave() {
        // Based on the tab selection the key will be assigned to the below method
        // here the key will be passed as the unique id for all the table
        // and also the same id has to be updated in LocalStorageKeys enum also
        if (this.tabSelection === LocalStorageKeys.eventTime) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.eventTime, this.columns);
        } else if (this.tabSelection === LocalStorageKeys.pqiTable) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.pqiTable, this.columns);
        } else if (this.tabSelection === LocalStorageKeys.meteringDataTableCollapsed) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.meteringDataTableCollapsed, this.columns);
        } else if (this.tabSelection === LocalStorageKeys.meteringDataTable) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.meteringDataTable, this.columns);
        } else if (this.tabSelection === LocalStorageKeys.prepaymentTable) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.prepaymentTable, this.columns);
        } else if (this.tabSelection === LocalStorageKeys.prepaymentTableCollapsed) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.prepaymentTableCollapsed, this.columns);
        } else if (this.tabSelection === LocalStorageKeys.mpSearchTable) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.mpSearchTable, this.columns);
        } else if (this.tabSelection === LocalStorageKeys.changeLogs) {
            this.localStorage.setColumnConfiguration(LocalStorageKeys.changeLogs, this.columns);
        }

        this.dialogRef.close();
    }

    defaultSave(Values: Observable<any>) {
        Values.subscribe((defaultValues) => {
            defaultValues.forEach((ele: any, index: any) => {
                this.columns[index].draggedColumn = defaultValues[index].draggedColumn;
                this.columns[index].columnId = defaultValues[index].columnId;
                this.columns[index].columnName = defaultValues[index].columnName;
                this.columns[index].showColumn = defaultValues[index].showColumn;
                this.columns[index].columnType = defaultValues[index].columnType;
            });
        });
        this.checkingChanges();
    }

    restoreDefaultSettings() {
        this.restoreDefaultSettingsLinkEnable = false;
        if (this.tabSelection === LocalStorageKeys.eventTime) {
            this.defaultSave(this.eventsColumnConfigInitial$);
        } else if (this.tabSelection === LocalStorageKeys.pqiTable) {
            this.defaultSave(this.pqiColumnConfigInitial$);
        } else if (this.tabSelection === LocalStorageKeys.changeLogs) {
            this.defaultSave(this.changeLogColumnConfigInitial$);
        } else if (
            this.tabSelection === LocalStorageKeys.prepaymentTable ||
            this.tabSelection === LocalStorageKeys.prepaymentTableCollapsed
        ) {
            if (this.expansion) {
                this.defaultSave(this.prepaymentColumnConfigInitial$);
            } else {
                this.defaultSave(this.prepaymentCollapsedColumnConfigInitial$);
            }
        } else if (
            this.tabSelection === LocalStorageKeys.meteringDataTable ||
            this.tabSelection === LocalStorageKeys.meteringDataTableCollapsed
        ) {
            if (this.expansion) {
                this.defaultSave(this.profilePeriodicColumnConfigInitial$);
            } else {
                this.defaultSave(this.profilePeriodicCollapsedColumnConfigInitial$);
            }
        } else if (this.tabSelection === LocalStorageKeys.mpSearchTable) {
            this.defaultSave(this.MPDetailsColumnConfigInitial$);
        }
        this.enableDisableSaveButton();
    }

    checkingChanges() {
        this.columns.forEach((ele, index) => {
            if (
                this.columns[index].columnName !== this.draggedColumns[index].columnName ||
                this.columns[index].showColumn !== this.draggedColumns[index].showColumn
            ) {
                this.columns[index].draggedColumn = true;
            }
        });
    }

    onClickCancel() {
        this.dialogRef.close();
    }
}
