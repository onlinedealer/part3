import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AirbyteApiService } from '../pipeline/shared/airbyte-api.service';
import { MessageService } from 'primeng/api';

import { PipelineLogSidebarComponent } from './pipeline-log-sidebar.component';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';

describe('PipelineLogSidebarComponent', () => {
  let component: PipelineLogSidebarComponent;
  let fixture: ComponentFixture<PipelineLogSidebarComponent>;

  let airbyteApiService;
  let messageService;

  beforeEach(async () => {
    airbyteApiService = jasmine.createSpyObj('pipelinesLogsApiService', ['getLogs']);
    airbyteApiService.getLogs.and.returnValue(of(new Uint16Array([1, 2, 3]).buffer));

    messageService = jasmine.createSpyObj('MessageService', ['add']);
    messageService.add.and.callThrough();
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [PipelineLogSidebarComponent, MockSidebarComponent],
      providers: [
        { provide: AirbyteApiService, useValue: airbyteApiService },
        { provide: MessageService, useValue: messageService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipelineLogSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should Open Sidebar', () => {
    expect(component.isLoading).toBe(true);

    spyOn(component.sidebarComponent, 'open');
    component.open('123', '123');

    expect(component.sidebarComponent.open).toHaveBeenCalled();
    expect(component.isLoading).toBe(false);
  });

  it('should Close Sidebar', () => {
    spyOn(component.sidebarComponent, 'close');
    component.closeButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should display error message', () => {
    airbyteApiService.getLogs.and.returnValue(throwError(() => new Error('404')));

    spyOn(component.sidebarComponent, 'close');
    spyOn(component.sidebarComponent, 'open');
    component.open('123', '123');

    expect(component.sidebarComponent.close).toHaveBeenCalled();
    expect(messageService.add).toHaveBeenCalled();
    expect(messageService.add).toHaveBeenCalledWith({ severity: 'error', detail: 'pipelines.PIPELINE_LOG_SIDEBAR.LOG_NOT_FOUND' });
  });
});
