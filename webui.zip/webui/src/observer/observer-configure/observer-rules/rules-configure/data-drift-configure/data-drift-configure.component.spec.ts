import { Spies } from 'discovery-test';
import { DataDriftConfigureComponent } from './data-drift-configure.component';
import { DataDriftType } from './data-drift-type.enum';

describe('DataDriftConfigureComponent', () => {
  let component: DataDriftConfigureComponent;

  beforeEach(() => {
    Spies.init();
    component = new DataDriftConfigureComponent(Spies.ObserverService, Spies.eventBusService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should run ngOnInit', () => {
    component.savedConfig = {
      confidence: {
        warningAlerts: { minimum: 60, maximum: 80 },
        numericData: [
          DataDriftType.VALUE_MIN,
          DataDriftType.VALUE_MAX,
          DataDriftType.VALUE_MEAN,
          DataDriftType.VALUE_STDEV
        ],
        textualData: [DataDriftType.TEXT_LENGTH_MIN, DataDriftType.TEXT_LENGTH_MAX],
        detailDrift: [DataDriftType.CARDINALITY_DETAIL],
        uniqueValueCount: true
      }
    };
    component.ngOnInit();
    expect(component.confidenceSliderSettings.sliderVisible).toBe(true);
    expect(component.numericData.length).toBe(4);
  });

  it('should run getThresholdUpdate fn with 100 values', () => {
    component.savedConfig = {
      confidence: {
        warningAlerts: { minimum: 60, maximum: 80 },
        numericData: [
          DataDriftType.VALUE_MIN,
          DataDriftType.VALUE_MAX,
          DataDriftType.VALUE_MEAN,
          DataDriftType.VALUE_STDEV
        ],
        textualData: [DataDriftType.TEXT_LENGTH_MIN, DataDriftType.TEXT_LENGTH_MAX],
        detailDrift: [DataDriftType.CARDINALITY_DETAIL],
        uniqueValueCount: true
      }
    };
    component.validationCheck = setTimeout(() => {
      //a dummy test timeout
    }, 500);
    const event = { minimum: 100, maximum: 100 };
    jasmine.clock().install();
    component.initialize();
    component.getThresholdUpdate(event);
    jasmine.clock().tick(500);
    expect(component.confidenceSliderSettings.rangeValues[0]).toBe(60);
    jasmine.clock().uninstall();
  });

  it('should set default values', () => {
    component.savedConfig = { confidence: { warningAlerts: {} } };
    component.ngOnInit();
    expect(component.dataDriftModel.confidence.uniqueValueCount).toBe(true);
  });

  it('should call save event', () => {
    const event = { minimum: 20, maximum: 45 };
    jasmine.clock().install();
    component.initialize();
    component.getThresholdUpdate(event);
    jasmine.clock().tick(500);
    spyOn(component.dataDriftSidebarVisible, 'emit');
    component.saveChanges();
    expect(component.dataDriftSidebarVisible.emit).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should call cancel event', () => {
    spyOn(component.dataDriftSidebarVisible, 'emit');
    component.cancelCreate();
    expect(component.dataDriftSidebarVisible.emit).toHaveBeenCalled();
  });
});
