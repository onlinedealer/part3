import { TestBed } from '@angular/core/testing';
import { Spies } from 'discovery-test';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { NumericalAnalysisComponent } from './numerical-analysis.component';

describe('NumericalAnalysisComponent', () => {
  let component: NumericalAnalysisComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NumericalAnalysisComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    Spies.init();
    component = new NumericalAnalysisComponent(Spies.TranslateService, Spies.eventBusService, Spies.HttpUtilService);
    component.treePath = new TreePath();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with MinMaxValueStatistics', () => {
    component.statistics = [
      {
        type: 'MinMaxValueStatistics',
        group: 'NUMERICAL_ANALYSIS',
        min: '1',
        max: '9'
      }
    ] as any;
    component.treePath.columnView = true;
    component.ngOnInit();

    expect(component.objNumericalAnalysis.length).toEqual(1);
    expect(component.objNumericalAnalysis[0][0].data).toBe(Number(component.statistics[0]['min']));
    expect(component.objNumericalAnalysis[0][1].data).toBe(Number(component.statistics[0]['max']));
  });

  it('Initialize ngOnInit with DateTypeStatistics', () => {
    component.statistics = [
      {
        type: 'MinMaxValueStatistics',
        group: 'DATE_ANALYSIS',
        min: '1970-01-01',
        max: '2021-09-18'
      }
    ] as any;
    component.treePath.columnView = true;
    component.ngOnInit();

    expect(component.objNumericalAnalysis.length).toEqual(1);
    expect(component.objNumericalAnalysis[0][0].data).toBe(component.statistics[0]['min']);
    expect(component.objNumericalAnalysis[0][1].data).toBe(component.statistics[0]['max']);
  });

  it('Initialize ngOnInit with NumericalStatistics', () => {
    component.statistics = [
      {
        type: 'MinMaxValueStatistics',
        group: 'NUMERICAL_ANALYSIS',
        min: '9',
        max: '98'
      },
      {
        type: 'NumericalStatistics',
        group: 'NUMERICAL_ANALYSIS',
        avg: 4996.392831,
        stddev: 2883,
        variance: 8316588
      }
    ] as any;
    component.treePath.columnView = true;
    component.ngOnInit();

    expect(component.objNumericalAnalysis.length).toEqual(2);
    expect(component.objNumericalAnalysis[0][0].data).toBe(Number(component.statistics[0]['min']));
    expect(component.objNumericalAnalysis[0][1].data).toBe(Number(component.statistics[0]['max']));
  });

  it('should emit trends sidebar open event on launchTrendsSidebar', () => {
    component.launchTrendsSidebar('Average');
    expect(Spies.eventBusService['emit']).toHaveBeenCalled();
  });
});
