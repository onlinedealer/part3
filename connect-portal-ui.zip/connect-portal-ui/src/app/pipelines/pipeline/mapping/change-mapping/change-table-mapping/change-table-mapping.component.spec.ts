import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../../../../core/transloco-testing.module';
import { PipelineService } from '../../../pipeline.service';
import { ChangeTableMappingComponent } from './change-table-mapping.component';

describe('ChangeTableMappingComponent', () => {
  let component: ChangeTableMappingComponent;
  let fixture: ComponentFixture<ChangeTableMappingComponent>;
  let pipelineService: PipelineService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      declarations: [ChangeTableMappingComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChangeTableMappingComponent);
    pipelineService = TestBed.inject(PipelineService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit sidebar cancel event', () => {
    spyOn(component.cancelClicked, 'emit');
    component.onCancel();
    expect(component.cancelClicked.emit).toHaveBeenCalled();
    expect(component.cancelClicked.emit).toHaveBeenCalledWith('close');
  });

  it('should trigger sidebar Apply event if pattern is selected', () => {
    component.patchPipeline = () => {};
    component.selectedPattern = [
      { code: 'abc', name: 'abc' },
      { code: 'schema', name: 'schema' },
      { code: 'dataset', name: 'dataset' }
    ];
    component.checkedItems = [
      {
        schema: 'Uxtesting1',
        table: 'Table_topic',
        topic: {
          name: '',
          mappingIcon: '',
          iconTooltip: ''
        }
      }
    ];
    component.setTargetDetails = (row, topic) => {};
    component.onApply();
    expect(component.selectedPattern).toEqual([]);
  });

  it('should trigger sidebar Apply event if pattern is not selected', () => {
    component.patchPipeline = () => {};
    component.selectedPattern = [];
    component.selectedTopic = 'topic';
    component.checkedItems = [
      {
        schema: 'Uxtesting1',
        table: 'Table_topic',
        topic: {
          name: '',
          mappingIcon: '',
          iconTooltip: ''
        }
      }
    ];
    component.topics = ['topic'];
    component.setTargetDetails = (row, topic) => {};
    component.onApply();
    expect(component.selectedPattern).toEqual([]);
  });

  it('should trigger pattern condition', () => {
    const event = { value: 'USE_A_PATTERN' };
    component.onChangeTopicDropdown(event);
    expect(component.patternDropdown).toBe(true);
  });

  it('should trigger topic condition', () => {
    const event = { value: 'SELECT_ENTER_TOPIC' };
    component.onChangeTopicDropdown(event);
    expect(component.patternDropdown).toBe(false);
  });

  it('should filter Topic and Pattern on Input Change', () => {
    component.topics = ['topic'];
    component.patternDropdownItems = [{ code: 't', name: 't' }];
    const event = { query: 't' };
    const event1 = { code: 't', name: 't', query: 't' };
    component.filterTopic(event);
    component.filterPattern(event1);
    expect(component.filteredTopics.length).toBe(1);
    expect(component.filteredPatterns.length).toBe(1);
  });

  it('should update selected Topic', () => {
    const event = 'eve';
    component.onSelectTopic(event);
    expect(component.selectedTopic).toEqual(event);
  });

  it('should handle focus in pattern input', () => {
    const event = { target: { value: '' } };
    component.selectedPattern = null;
    component.handleFocus(event);
    expect(component.selectedTopic).toEqual(event.target.value);
  });

  it('should add a chip on focus in pattern input', () => {
    const event = { target: { value: 'somthing' } };
    component.selectedPattern = [{ code: 'omthing', value: 'somthing' }];
    component.handleFocus(event);
    expect(component.selectedTopic).toEqual(event.target.value);
  });

  it('should handle special characters in pattern input', () => {
    const event = { target: { value: '!' }, which: 13 };
    component.keyChangeTopic(event);
    component.selectedPattern = null;
    component.keyChangePattern(event);
    component.handleFocus(event);
    expect(component.selectedTopic).toEqual(event.target.value);
  });
  it('should update selected Pattern or topic on input change', () => {
    const event = { target: { value: '' }, which: 13 };
    component.keyChangeTopic(event);
    component.selectedPattern = null;
    component.keyChangePattern(event);
    expect(component.selectedTopic).toEqual(event.target.value);
  });

  it('should add a chip on enter new Pattern', () => {
    const event = { target: { value: 'somthing' }, which: 13 };
    component.keyChangeTopic(event);
    component.selectedPattern = [{ code: 'omthing', value: 'somthing' }];
    component.keyChangePattern(event);
    expect(component.selectedPattern.length).toBeGreaterThan(0);
  });

  it('should handle togglecase', () => {
    const casedTargetColumn = component.convertTopicAsCaseSpecified('TOGGLE_CASE', 'target');
    expect(casedTargetColumn).toBe('tARGET');
  });
  it('should handle capitalization', () => {
    const casedTargetColumn = component.convertTopicAsCaseSpecified('CAP_EACH_WORD', 'target');
    expect(casedTargetColumn).toBe('Target');
  });
  it('should handle lowercase', () => {
    const casedTargetColumn = component.convertTopicAsCaseSpecified('LOWER_CASE', 'TARGET');
    expect(casedTargetColumn).toBe('target');
  });
  it('should handle uppercase', () => {
    const casedTargetColumn = component.convertTopicAsCaseSpecified('UPPER_CASE', 'target');
    expect(casedTargetColumn).toBe('TARGET');
  });
  it('should handle sentence casing', () => {
    const casedTargetColumn = component.convertTopicAsCaseSpecified('SENTENCE_CASE', 'target column');
    expect(casedTargetColumn).toBe('Target Column');
  });

  it('should get apply button details', () => {
    const object = {
      id: '',
      text: '',
      isDisabled: true
    };
    component.getPrimaryObject(object);
    expect(component.primaryObject).toBe(object);
  });
});
