import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClubBenefitDashboardComponent } from './club-benefit-dashboard.component';

describe('ClubBenefitDashboardComponent', () => {
  let component: ClubBenefitDashboardComponent;
  let fixture: ComponentFixture<ClubBenefitDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClubBenefitDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClubBenefitDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
