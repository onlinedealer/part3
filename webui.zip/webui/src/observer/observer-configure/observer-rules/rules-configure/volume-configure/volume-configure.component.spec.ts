import { Spies } from 'discovery-test';
import { VolumeConfigureComponent } from './volume-configure.component';
import { AlertAgainstTypeEnum } from './alert-against-type.enum';

describe('VolumeConfigureComponent', () => {
  let component: VolumeConfigureComponent;
  beforeEach(() => {
    Spies.init();
    component = new VolumeConfigureComponent(Spies.ObserverService, Spies.eventBusService, {} as any);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run ngOnInit', () => {
    component.ngOnInit();
    expect(component.confidenceSliderSettings.sliderVisible).toBe(true);
    expect(component.thresholdSliderSettings.sliderVisible).toBe(false);
  });
  it('should run ngOnInit with saved data threshold based without moving average value', () => {
    component.savedConfig = { configType: 'threshold', threshold: { warningAlerts: { minimum: 3, maximum: 8 } } };
    component.ngOnInit();
    expect(component.volumeModel.threshold.movingAverage).toBe(7);
    expect(component.thresholdSliderSettings.sliderVisible).toBe(false);
  });
  it('should run ngOnInit with saved data threshold based with moving average value', () => {
    component.savedConfig = {
      configType: 'threshold',
      threshold: {
        alertAgainst: AlertAgainstTypeEnum.LAST_PROFILE_RUN,
        movingAverage: 9,
        warningAlerts: { minimum: 3, maximum: 8 }
      }
    };
    component.ngOnInit();
    expect(component.volumeModel.threshold.movingAverage).toBe(9);
    expect(component.thresholdSliderSettings.sliderVisible).toBe(false);
  });
  it('should run ngOnInit with saved data confidence based', () => {
    component.savedConfig = { configType: 'confidence', confidence: { warningAlerts: { minimum: 3, maximum: 8 } } };
    component.ngOnInit();
    expect(component.confidenceSliderSettings.sliderVisible).toBe(true);
  });

  it('should run getThresholdUpdate fn with 100 values', () => {
    component.validationCheck = setTimeout(() => {
      //a dummy test timeout
    }, 500);
    const event = { minimum: 100, maximum: 100 };
    jasmine.clock().install();
    component.initialize();
    component.getThresholdUpdate(event);
    jasmine.clock().tick(500);
    expect(component.confidenceSliderSettings.rangeValues[0]).toBe(60);
    jasmine.clock().uninstall();
  });

  it('should run onTabOpen fn with confidence', () => {
    const event = { index: 0 };
    component.onTabOpen(event);
    expect(component.volumeModel.configType).toBe('confidence');
  });

  it('should run onTabOpen fn with threshold', () => {
    const event = { index: 1 };
    component.onTabOpen(event);
    expect(component.volumeModel.configType).toBe('threshold');
  });
  it('should call save event with type confidence', () => {
    component.volumeThresholds = { minimum: 60, maximum: 85 };
    component.volumeModel = {
      configType: 'confidence',
      confidence: {
        warningAlerts: { minimum: 21, maximum: 25 }
      },
      threshold: {
        warningAlerts: { minimum: 21, maximum: 25 },
        movingAverage: 7,
        alertAgainst: AlertAgainstTypeEnum.MOVING_AVERAGE
      }
    };

    spyOn(component.configVolumeSidebarVisible, 'emit');
    component.saveChanges();
    expect(component.volumeModel.confidence.warningAlerts.minimum).toBe(60);
    expect(component.volumeModel.threshold.movingAverage).toBe(7);
    expect(component.configVolumeSidebarVisible.emit).toHaveBeenCalled();
  });
  it('should call save event with type threshold', () => {
    component.volumeThresholds = { minimum: 60, maximum: 85 };
    component.volumeModel = {
      configType: 'threshold',
      confidence: {
        warningAlerts: { minimum: 21, maximum: 25 }
      },
      threshold: {
        warningAlerts: { minimum: 21, maximum: 25 },
        movingAverage: 7,
        alertAgainst: AlertAgainstTypeEnum.LAST_PROFILE_RUN
      }
    };
    spyOn(component.configVolumeSidebarVisible, 'emit');
    component.saveChanges();
    expect(component.volumeModel.threshold.warningAlerts.maximum).toBe(85);
    expect(component.volumeModel.threshold.movingAverage).toBe(null);
    expect(component.configVolumeSidebarVisible.emit).toHaveBeenCalled();
  });
});
