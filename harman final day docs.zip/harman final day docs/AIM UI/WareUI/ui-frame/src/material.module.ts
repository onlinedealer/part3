import { NgModule } from "@angular/core";
import { DomSanitizer } from "@angular/platform-browser";
import { DragDropModule } from "@angular/cdk/drag-drop";
import { LandisGyrDateAdapterService } from "./Shared/services/landis-gyr-date-adapter.service";
import { MatAutocompleteModule } from "@angular/material/autocomplete";
import { MatBadgeModule } from "@angular/material/badge";
import { MatButtonModule } from "@angular/material/button";
import { MatButtonToggleModule } from "@angular/material/button-toggle";
import { MatCardModule } from "@angular/material/card";
import { MatCheckboxModule } from "@angular/material/checkbox";
import { MatChipsModule } from "@angular/material/chips";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { MatDialogModule } from "@angular/material/dialog";
import { MatExpansionModule } from "@angular/material/expansion";
import { MatIconModule, MatIconRegistry } from "@angular/material/icon";
import { MatInputModule } from "@angular/material/input";
import { MatListModule } from "@angular/material/list";
import { MatMenuModule } from "@angular/material/menu";
import { MatMomentDateModule } from "@angular/material-moment-adapter";
import { MatNativeDateModule, MatOptionModule, DateAdapter, RippleGlobalOptions, MAT_RIPPLE_GLOBAL_OPTIONS } from "@angular/material/core";
import { MatProgressBarModule } from "@angular/material/progress-bar";
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";
import { MatRadioModule } from "@angular/material/radio";
import { MatSelectModule } from "@angular/material/select";
import { MatSidenavModule } from "@angular/material/sidenav";
import { MatSlideToggleModule } from "@angular/material/slide-toggle";
import { MatSnackBarModule } from "@angular/material/snack-bar";
import { MatSortModule } from "@angular/material/sort";
import { MatTableModule } from "@angular/material/table";
import { MatTabsModule } from "@angular/material/tabs";
import { MatToolbarModule } from "@angular/material/toolbar";
import { MatTooltipModule } from "@angular/material/tooltip";
import { MatTreeModule } from "@angular/material/tree";
import { ScrollingModule } from "@angular/cdk/scrolling";

const globalRippleConfig: RippleGlobalOptions = {
    disabled: true,
    animation: {
        enterDuration: 0,
        exitDuration: 0
    }
};

@NgModule({
    imports: [
        DragDropModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatChipsModule,
        MatDatepickerModule,
        MatDialogModule,
        MatExpansionModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        MatMenuModule,
        MatMomentDateModule,
        MatMomentDateModule,
        MatNativeDateModule,
        MatOptionModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRadioModule,
        MatSelectModule,
        MatSidenavModule,
        MatSlideToggleModule,
        MatSnackBarModule,
        MatSortModule,
        MatTableModule,
        MatTabsModule,
        MatToolbarModule,
        MatTooltipModule,
        MatTreeModule,
        ScrollingModule
    ],
    exports: [
        DragDropModule,
        MatAutocompleteModule,
        MatBadgeModule,
        MatButtonModule,
        MatButtonToggleModule,
        MatCardModule,
        MatCheckboxModule,
        MatChipsModule,
        MatDatepickerModule,
        MatDialogModule,
        MatExpansionModule,
        MatIconModule,
        MatInputModule,
        MatListModule,
        MatMenuModule,
        MatMomentDateModule,
        MatOptionModule,
        MatProgressBarModule,
        MatProgressSpinnerModule,
        MatRadioModule,
        MatSelectModule,
        MatSidenavModule,
        MatSlideToggleModule,
        MatSnackBarModule,
        MatSortModule,
        MatTableModule,
        MatTabsModule,
        MatToolbarModule,
        MatTooltipModule,
        MatTreeModule,
        ScrollingModule
    ],
    providers: [
        LandisGyrDateAdapterService,
        {
            provide: DateAdapter,
            useClass: LandisGyrDateAdapterService
        },
        { provide: MAT_RIPPLE_GLOBAL_OPTIONS, useValue: globalRippleConfig }
    ]
})
export class MaterialModule {
    constructor(private iconRegistry: MatIconRegistry, private sanitizer: DomSanitizer) {
        iconRegistry.addSvgIcon(
            "icon-notification-alert",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-notification-02.svg")
        );
        iconRegistry.addSvgIcon("logo", sanitizer.bypassSecurityTrustResourceUrl("assets/logo.svg"));
        iconRegistry.addSvgIcon("icon-info", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-info.svg"));
        iconRegistry.addSvgIcon("icon-user", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-person.svg"));
        iconRegistry.addSvgIcon("icon-close", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-close.svg"));
        iconRegistry.addSvgIcon("icon-signout", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-signout.svg"));
        iconRegistry.addSvgIcon("icon-help", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-help.svg"));
        iconRegistry.addSvgIcon("icon-search", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-search.svg"));
        iconRegistry.addSvgIcon("icon-arrow", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-arrow.svg"));
        iconRegistry.addSvgIcon("icon-remove", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-remove.svg"));
        iconRegistry.addSvgIcon(
            "icon-arrow-back",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/baseline-arrow_back-24px.svg")
        );
        iconRegistry.addSvgIcon("icon-drop-down", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-drop-down.svg"));
        iconRegistry.addSvgIcon("icon-drop-up", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-drop-up.svg"));
        iconRegistry.addSvgIcon("icon-calendar", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-calendar.svg"));
        iconRegistry.addSvgIcon("icon-assign", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-assign.svg"));
        iconRegistry.addSvgIcon("icon-save", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-save.svg"));
        iconRegistry.addSvgIcon("icon-print", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-print.svg"));
        iconRegistry.addSvgIcon("icon-ping", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-ping.svg"));
        iconRegistry.addSvgIcon("icon-plus", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-plus.svg"));
        iconRegistry.addSvgIcon("icon-tag", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-tag.svg"));
        iconRegistry.addSvgIcon("icon-minus", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-minus.svg"));

        iconRegistry.addSvgIcon("icon-edit", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-edit.svg"));
        iconRegistry.addSvgIcon("icon-external", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-external.svg"));
        iconRegistry.addSvgIcon("icon-refresh", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/baseline-refresh-24px.svg"));
        iconRegistry.addSvgIcon("icon-magnifier", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-magnifier.svg"));
        iconRegistry.addSvgIcon("icon-check", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-check.svg"));
        iconRegistry.addSvgIcon(
            "icon-notification-circle",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-notification-01.svg")
        );
        iconRegistry.addSvgIcon(
            "icon-notification-error",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-notification-error.svg")
        );
        iconRegistry.addSvgIcon(
            "icon-notification-confirmation",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-notification-confirmation.svg")
        );
        iconRegistry.addSvgIcon(
            "icon-notification-info",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-notification-info.svg")
        );
        iconRegistry.addSvgIcon(
            "icon-bar-chart",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/baseline-bar_chart-24px.svg")
        );
        iconRegistry.addSvgIcon(
            "icon-dashboard",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/baseline-dashboard-24px.svg")
        );
        iconRegistry.addSvgIcon("icon-grid-on", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/baseline-grid_on-24px.svg"));
        iconRegistry.addSvgIcon("icon-comment", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-comment.svg"));
        iconRegistry.addSvgIcon("icon-delete", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-delete.svg"));
        iconRegistry.addSvgIcon("icon-failed", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-failed.svg"));
        iconRegistry.addSvgIcon("icon-export", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-export.svg"));
        iconRegistry.addSvgIcon(
            "icon-notification-warning",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-notification-warning.svg")
        );
        iconRegistry.addSvgIcon("icon-star", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-star.svg"));
        iconRegistry.addSvgIcon(
            "icon-remove-forever",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-remove-forever.svg")
        );
        iconRegistry.addSvgIcon("icon-schedule", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-schedule.svg"));
        iconRegistry.addSvgIcon(
            "icon-error_outline",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-error_outline.svg")
        );
        iconRegistry.addSvgIcon(
            "icon-chat_bubble_outline",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-chat_bubble_outline.svg")
        );

        iconRegistry.addSvgIcon(
            "icon-nav-meteringpoint",
            sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/nav-icon-meteringpoints.svg")
        );
        iconRegistry.addSvgIcon("icon-nav-tasks", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/nav-icon-tasks.svg"));
        iconRegistry.addSvgIcon("icon-tiles", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-tiles.svg"));
        iconRegistry.addSvgIcon("icon-line-chart", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-line-chart.svg"));
        iconRegistry.addSvgIcon("icon-list", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-list.svg"));
        iconRegistry.addSvgIcon("icon-dots", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-dots.svg"));
        iconRegistry.addSvgIcon("icon-alert", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-alert.svg"));
        iconRegistry.addSvgIcon("icon-filter", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-filter.svg"));
        iconRegistry.addSvgIcon("icon-math", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-math.svg"));
        iconRegistry.addSvgIcon("icon-interpolate", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-interpolate.svg"));
        iconRegistry.addSvgIcon("icon-rewind", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-rewind.svg"));
        iconRegistry.addSvgIcon("icon-stop", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-stop.svg"));
        iconRegistry.addSvgIcon("icon-play", sanitizer.bypassSecurityTrustResourceUrl("assets/icons_general/icon-play.svg"));
    }
}
