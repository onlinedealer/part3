import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-searchbar',
  templateUrl: './searchbar.component.html',
  styleUrls: ['./searchbar.component.scss']
})
export class SearchbarComponent implements OnInit {

  enterPress(event) {
    if(event.key === 'Enter') {
      alert('Entered');
    }
  }
  search() {
    alert('clicked');
  }
  userEntered() {
    let search = document.querySelector('input');
    if(search.value !== '' || search.value === null) {
      console.log('typing');
    }
  }
  constructor() { }

  ngOnInit() {

  }

}
