import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseConnectApiService } from '../../core/base-connect-api.service';
import { Connection } from './connection';

@Injectable({
  providedIn: 'root'
})
export class ConnectionsApiService extends BaseConnectApiService<Connection> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient, 'dataconnections');
  }

  verify(connection: Connection) {
    return this.httpClient.post(this.serviceURL + '/verify', connection);
  }
}
