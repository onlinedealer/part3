import { Component, Input, OnInit } from '@angular/core';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-percentile-chart',
  templateUrl: './percentile-chart.component.html',
  styleUrls: ['./percentile-chart.component.css']
})
export class PercentileChartComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, string>;

  data: any;
  keys: any[];
  values: any[];

  basicOptions: any;

  ngOnInit() {
    this.data = {
      labels: [],
      datasets: [
        {
          data: [],
          fill: false,
          borderColor: ProfilingConstants.FREQUENCYCHARTCOLORS[0]
        }
      ]
    };
    this.basicOptions = {
      scales: {
        y: {
          ticks: {
            beginAtZero: true
          }
        },
        x: {
          ticks: {
            beginAtZero: true
          }
        }
      },
      plugins: {
        legend: {
          display: false,
          align: 'center',
          position: 'bottom'
        }
      }
    };
    if (this.treePath) {
      this.generateDataLabel();
    }
  }

  private generateDataLabel(): void {
    if (this.treePath.columnView) {
      this.values = Object.keys(this.statistics['percentiles']).map((key) => this.statistics['percentiles'][key]);
      this.keys = Object.keys(this.statistics['percentiles']);

      this.data.datasets[0].data = this.keys.map((keyField) => parseFloat(keyField));
      this.data.labels = this.values;
    }
  }
}
