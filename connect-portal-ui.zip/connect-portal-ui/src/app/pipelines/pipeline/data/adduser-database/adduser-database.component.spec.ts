import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { AdduserDatabaseComponent } from './adduser-database.component';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';
import { AddDatabaseFormComponent } from './add-database-form/add-database-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { AddDatabaseApiService } from './shared/addDatabase-api.service';
import { of, throwError } from 'rxjs';
import { Connection } from 'src/app/connections/shared/connection';
import { EncryptionService } from '@shared/services/encryption.service';
import { MetadataApiService } from '../schema-table-selector/metadata-api.service';

describe('AdduserDatabaseComponent', () => {
  let component: AdduserDatabaseComponent;
  let fixture: ComponentFixture<AdduserDatabaseComponent>;
  let addDatabaseApiService: AddDatabaseApiService;
  let encryptionApiService: EncryptionService;
  let metadataApiService: MetadataApiService;

  const mockAddDatabase = {
    dataConnectionId: '1',
    userDataBaseNames: ['AUDSYS', 'DBTESTER'],
    adminUserId: 'sa',
    adminUserPassword: '***'
  };

  const mockedSourceConnection = {
    id: '1',
    connectionType: 'SQLSERVER',
    accessFromServer: { name: 'myServer' }
  } as Connection;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, FormsModule, ReactiveFormsModule, getTranslocoModule()],
      declarations: [AdduserDatabaseComponent, MockSidebarComponent, AddDatabaseFormComponent],
      providers: [Clipboard]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdduserDatabaseComponent);
    component = fixture.componentInstance;
    encryptionApiService = TestBed.inject(EncryptionService);
    addDatabaseApiService = TestBed.inject(AddDatabaseApiService);
    metadataApiService = TestBed.inject(MetadataApiService);
    component.sourceDataConnection = mockedSourceConnection;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the sidebar', () => {
    spyOn(component.sidebarComponent, 'open');
    component.open();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should close the sidebar when cancel button is clicked', () => {
    spyOn(component.sidebarComponent, 'close');
    component.onCancelButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should close the sidebar when close button is triggered on success', () => {
    spyOn(component.sidebarComponent, 'close');
    component.onCloseButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should call the addDatabaseButton clicked with failed', fakeAsync(() => {
    const jsonString = '{"DB1":"Success","DB2":"Success","DB3":"Error"}';
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(component.addDatabaseFormComponent, 'getDatabaseObject').and.returnValue(mockAddDatabase);
    spyOn(addDatabaseApiService, 'add').and.returnValue(throwError({ error: { detailedMessage: jsonString } }));
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    encryptionApiService.encrypt('myServer', 'pwd');
    component.addDatabaseButtonClicked();
    tick();
    fixture.whenStable().then(() => {
      expect(component.addDatabaseFormComponent.displayErrorMessage).toBeTrue();
    });
  }));

  it('should call the addDatabaseButton clicked with success', fakeAsync(async () => {
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(component.addDatabaseFormComponent, 'getDatabaseObject').and.returnValue(mockAddDatabase);
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    encryptionApiService.encrypt('myServer', 'pwd');
    spyOn(addDatabaseApiService, 'add').and.returnValue(of({ success: true }));
    component.addDatabaseButtonClicked();
    tick(10000);
    fixture.whenStable().then(() => {
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
    });
  }));

  it('should copy empty error to clipboard', () => {
    const clipSpy = spyOn(component.clipboard, 'copy').and.returnValue(true);
    component.errorMessage = '';
    component.copyClipboard();
    expect(clipSpy).toHaveBeenCalled();
  });

  it('should copy error message to clipboard', () => {
    const clipSpy = spyOn(component.clipboard, 'copy').and.returnValue(true);
    component.errorMessage = 'Error';
    component.copyClipboard();
    expect(clipSpy).toHaveBeenCalled();
  });
});
