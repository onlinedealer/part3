(function() {
    'use strict';

    fileuploader.controller("viewTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$location', '$route', '$window', '$http', viewTemplateCtrl]);

    function viewTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, $location, $route, $http) {

        $scope.uploadPreviewTemplate = "";
        $scope.fetchpreviewData = function() {
                var rowData = $rootScope.globalTemplateUpResp;
                var id = rowData.TIFF_ID;
                console.log(id)
                
            
                var url = "/ocr/rest/v1/service/get/tiffimageString/tiff/file/" + id;
                var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
                console.log(url)
                $scope.getId = id;
                promise.then(function(data) {
                    var outputimage = data;
                    var output = "data:image/tiff;base64," + outputimage.inputdata;
                    $scope.uploadPreviewTemplate = output;
                    //$rootScope.globalImgPreview = $scope.uploadPreviewTemplate;
                    //console.log($scope.uploadpreview)
                });

                promise.catch(function(data) {
                    console.log('catch block executed', data);
                    return data;
                });
        };
        $scope.fetchpreviewData();

    }

})();
