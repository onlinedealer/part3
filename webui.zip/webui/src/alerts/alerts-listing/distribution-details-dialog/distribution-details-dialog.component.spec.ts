import { CommonModule, DatePipe } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslocoModule, TranslocoService, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';
import { AlertProfileMetricsService } from 'alerts/alert.profilemetrics.services';
import { TrendsMetricModel } from 'alerts/alertcounts.model';
import { alertsLoader, sharedLoader } from 'core/i18n-loaders';
import { AuthenticationService, Helper, SharedModule } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { ToastrService } from 'ngx-toastr';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { of } from 'rxjs';
import { getChartConfig } from './chart-config';
import { DistributionDetailsDialogComponent } from './distribution-details-dialog.component';

const config = {
  data: Mocks.MockDistributionDetails
} as DynamicDialogConfig;

const metricsList: TrendsMetricModel[] = Mocks.MockMetricsDetails;

describe('DistributionDetailsDialogComponent', () => {
  let component: DistributionDetailsDialogComponent;
  let fixture: ComponentFixture<DistributionDetailsDialogComponent>;
  let mockProfileService: any;
  let translocoService;
  let toasterService;
  mockProfileService = jasmine.createSpyObj('AlertProfileMetricsService', ['getTrendsHistory']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DistributionDetailsDialogComponent],
      imports: [CommonModule, TranslocoModule, TranslocoLocaleModule.forRoot(), HttpClientTestingModule, SharedModule],
      providers: [
        DatePipe,
        DynamicDialogRef,
        { provide: DynamicDialogConfig, useValue: config },
        { provide: AuthenticationService, useValue: Spies.AuthenticationService },
        { provide: AlertProfileMetricsService, useValue: mockProfileService },
        { provide: ToastrService },
        { TranslocoService, useValue: Spies.TranslateService },
        {
          provide: TRANSLOCO_SCOPE,
          useValue: [
            { scope: 'discoveryAlerts', loader: alertsLoader },
            { scope: 'discoveryShared', loader: sharedLoader }
          ]
        }
      ],
      schemas: [NO_ERRORS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    mockProfileService.getTrendsHistory.and.returnValue(of(metricsList));
    toasterService = TestBed.inject(ToastrService);
    spyOn(toasterService, 'error');
    fixture = TestBed.createComponent(DistributionDetailsDialogComponent);
    component = fixture.componentInstance;
    translocoService = TestBed.inject(TranslocoService);
    spyOn(translocoService, 'translate');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should pass data to component ', () => {
    expect(component.assetName).toBeTruthy();
    expect(component.assetName).toBe('EMAIL');
    expect(component.metric).toBeTruthy();
    expect(component.probability).toBeTruthy();
    expect(component.probability).toBe('100.00');
    expect(component.alertLevel).toBeTruthy();
    expect(component.alertLevel).toBe('CRITICAL');
  });

  it('should severity to 100.00 based on value passed ', () => {
    expect(component.severityText).toBe('critical 100.00%');
  });

  it('should severity to "danger" based on value passed ', () => {
    expect(component.severity).toBe('danger');
  });

  it('should preselect the passed metrics ', () => {
    const distrbutionList = component.selectedDistribution
      .map(({ label }) => label)
      .sort()
      .join(',');
    const selectedSampleKeys = component.selectedSampleKeys.split(',').sort().join(',');
    component.setSelectedDataset();
    const allChecked = component.selectedDistribution.every((item) => item.isChecked);
    expect(distrbutionList).toBe(selectedSampleKeys);
    expect(allChecked).toBeTruthy();
  });

  it('should return matched records with search label ', () => {
    const searcText = (component.searchText = 'l1shew0@mozilla.or');
    component.onSearch(searcText);
    const filteredList = component.filteredDistributionList;
    const shouldContainText = filteredList.every(({ label }) => label.includes(searcText));
    expect(shouldContainText).toBeTruthy();
  });

  it('should return no records if no match is made ', () => {
    const searcText = (component.searchText = 'test');
    component.onSearch(searcText);
    const filteredList = component.filteredDistributionList;
    expect(filteredList.length).toBe(0);
  });

  it('should return all records if search value is empty ', () => {
    const count = component.distributionList.length;
    const searcText = (component.searchText = '');
    component.onSearch(searcText);
    const filteredList = component.filteredDistributionList;
    expect(filteredList.length).toBe(count);
  });

  it('should display top 10 records ', () => {
    component.updateFilter(component.filterOptions.top);
    expect(component.selectedDistribution.length).toBe(10);
  });

  it('should sort records in ascending order when Top 10 is clicked ', () => {
    component.updateFilter(component.filterOptions.top);
    const list = component.filteredDistributionList;
    const alength = list.length - 1;
    const isSorted = component.filteredDistributionList.every((v, i) => {
      if (i < alength) {
        return v.percentage >= list[i + 1].percentage;
      } else {
        return true; // for the last record we dont have to compare
      }
    });
    expect(isSorted).toBeTruthy();
  });

  it('should display bottom 10 records ', () => {
    component.updateFilter(component.filterOptions.bottom);
    expect(component.selectedDistribution.length).toBe(10);
  });

  it('should sort records in descending order when bottom 10 is clicked ', () => {
    component.updateFilter(component.filterOptions.bottom);
    const list = component.filteredDistributionList;
    const alength = list.length - 1;
    const isSorted = component.filteredDistributionList.every((v, i) => {
      if (i < alength) {
        return v.percentage <= list[i + 1].percentage;
      } else {
        return true; // for the last record we dont have to compare
      }
    });
    expect(isSorted).toBeTruthy();
  });

  it('max 10 can only be selected ', () => {
    component.selectedDistribution = Array(10).fill(1);
    const output = component.isMaxSelectLimit({
      label: 'newLabel',
      isChecked: false,
      startTime: '',
      totalCount: 0,
      percentage: 0
    });
    expect(output).toBeTruthy();
  });

  it('should clear all selected distribution records ', () => {
    component.updateFilter(component.filterOptions.clear);
    const allUnchecked = component.selectedDistribution.every(({ isChecked }) => !isChecked);
    expect(allUnchecked).toBeTruthy();
    expect(component.graphData.datasets.length).toBe(0);
  });

  it('should get fresh records when timeframe is changed ', () => {
    component.onUpdateTimeFrame('year');
    expect(component.selectedTimeFrame).toBe('year');
    expect(mockProfileService.getTrendsHistory).toHaveBeenCalled();
  });

  it('should display error if dialog is closed and no item selected', () => {
    component.selectedDistribution = [];
    component.onSaveChanges();
    expect(toasterService.error).toHaveBeenCalled();
  });

  it('should return sample keys comma separated', () => {
    const mockArray = (component.selectedDistribution = Array(10).fill({ label: 'test' }));
    const output = component.getSelectedSampleKeys();
    expect(output).toBe(mockArray.map(({ label }) => label).join(','));
  });

  it('should add all colors to the color array pool and has length 10', () => {
    component.addAllColorsToAvailableColorPool();
    expect(component.availableColorsPool.length).toBe(10);
  });

  it('should add released color to color array pool', () => {
    const mockDataset = {
      label: 'test',
      backgroundColor: '#f0f0f0'
    };
    component.availableColorsPool = [];
    component.selectedDistribution = [];
    component.graphData.datasets = [mockDataset];
    component.onRowSelectUnselect({ data: mockDataset }, 'uncheck');
    expect(component.availableColorsPool.length).toBe(1);
  });

  it('should create Graph Data sets', () => {
    const graphData = getChartConfig('Time', 'DistributonCount', component.metric, component.alert, true);
    expect(graphData).toBeDefined();
  });

  it('should return null if "all" is passed', () => {
    const outputWeekDate = Helper.getFromDate('all', new Date('2022-09-26T13:03:59.384Z'));
    expect(outputWeekDate).toBe(null);
  });

  it('should show value in percentage', () => {
    component.percentageChartData = {
      labels: [
        '2022-12-16T07:32:46.549Z',
        '2022-12-17T07:32:46.519Z',
        '2022-12-18T07:32:52.852Z',
        '2022-12-19T07:32:58.331Z',
        '2022-12-21T07:32:54.476Z',
        '2022-12-22T07:32:58.599Z',
        '2022-12-23T07:32:54.435Z'
      ],
      values: [
        {
          label: '101',
          value: ['1', '1', '1', '1', '1', '1', '2']
        },
        {
          label: '100',
          value: ['1', '1', '1', '1', '1', '1', '1']
        }
      ],
      alertDate: '2022-12-22T18:30:00.000Z',
      trendTotalCountArray: [2, 2, 2, 2, 2, 2, 3],
      isNew: false
    };
    component.metric = {
      metricType: 'CARDINALITY_DETAIL',
      metricName: 'Distribution of value count',
      metricDetails: [
        {
          currentMetric: '2',
          comparisonMetric: '1',
          alertLevel: 'CRITICAL',
          alertReason: 'ALERT_RULE_CONSTANT_HISTORY_TO_NEW_VALUE',
          probability: 100,
          sampleKey: '101,100',
          isSampled: false,
          isNew: false
        }
      ]
    };
    component.isShowPercentage = true;
    component.showLegendInPercentage();
  });
});
