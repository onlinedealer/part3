import { Component } from '@angular/core';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { environment } from '../../../environments/environment';
import { ProgressIndicatorStateService } from '../../shared/components/progress-indicator/progress-indicator-state.service';

@Component({
  selector: 'p-connect-servers-home',
  templateUrl: './servers-home.component.html'
})
export class ServersHomeComponent {
  isServerSidebarVisible = false;
  replicationEngineHelpURL = environment.replicationEngineHelpURL;

  constructor(
    private readonly progressIndicatorStateService: ProgressIndicatorStateService,
    private readonly featureFlagService: FeatureFlagService
  ) {}

  get isMultipleProjectsFeatureEnabled(): boolean {
    return this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421');
  }

  serverSavedEvent() {
    this.progressIndicatorStateService.setIsValid(1, true);
  }
}
