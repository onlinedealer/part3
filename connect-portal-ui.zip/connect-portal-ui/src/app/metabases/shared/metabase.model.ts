import { Connection } from '../../connections/shared/connection';

export interface Metabase {
  id?: string;
  name?: string;
  owner?: string;
  adminUserId?: string;
  adminUserPassword?: string;
  dataConnection?: Connection;
  // project?: Project;
  version?: string;
  parameters?: { key: string; value: string }[];
}
