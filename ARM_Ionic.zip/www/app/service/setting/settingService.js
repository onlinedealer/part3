﻿(function () {
    'use strict';

    angular.module('arm').factory('settingService', function ($scope) {

    });

})();