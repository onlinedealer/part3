﻿(function () {
    'use strict';

    angular.module('arm').controller('settingCtrl',
                ['$scope', '$state', '$translate', settingCtrl]);
    function settingCtrl($scope, $state, $translate) {
        $scope.setLang = function (langKey) {
            // You can change the language during runtime
            $translate.use(langKey);
        };
    };

})();