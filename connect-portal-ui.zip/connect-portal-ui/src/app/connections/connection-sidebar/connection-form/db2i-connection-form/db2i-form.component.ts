import { AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ControlContainer, Form, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../shared/connection';
import { BaseConnectionForm } from '../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../base-connection-form/base-connection-form.component';
import { Server } from '../../../../servers/shared/server';
import { ConnectionFormValidators } from '../shared/connection-form-validators';
import { ConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component';

/**
 * connection parameters for the db2 ibmi connection
 */
export enum DB2I_CONNECTION_PARAMETERS {
  DB2_I_LIBRARY_INSTALLATION = 'DB2_I_LIBRARY_INSTALLATION',
  DB2_I_ENABLE_IASP = 'DB2_I_ENABLE_IASP',
  DB2_I_IASP_NAME = 'DB2_I_IASP_NAME',
  DB2_I_RDB_NAME = 'DB2_I_RDB_NAME'
}

/**
 * The db2i connection form
 */
@Component({
  selector: 'p-connect-db2i-form',
  templateUrl: './db2i-form.component.html'
})
export class Db2iFormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy, AfterViewInit, BaseConnectionForm {
  /**
   * Selected Runtime Server
   */
  @Input() selectedRuntimeServer: Server;

  /**
   * Reference to the credentials child component
   */
  @ViewChild(ConnectionCredentialsFormComponent) credentialsComponent: ConnectionCredentialsFormComponent;

  /**
   * form group
   */
  db2iConnectionForm: FormGroup;

  /**
   * Enable IASP dropdown options
   */
  enableIASPOptions = [
    { label: 'connections.CONNECTION_FORM.DB2I.ENABLE_IASP_OPTIONS.YES', value: 'YES' },
    { label: 'connections.CONNECTION_FORM.DB2I.ENABLE_IASP_OPTIONS.NO', value: 'NO' }
  ];

  /**
   * Database location dropdown options
   */
  databaseLocationOptions = [
    { label: 'connections.CONNECTION_FORM.DB2I.DATABASE_LOCATION_OPTIONS.REMOTE', value: 'REMOTE' },
    { label: 'connections.CONNECTION_FORM.DB2I.DATABASE_LOCATION_OPTIONS.RUNTIME', value: 'RUNTIME' }
  ];

  remoteDatabase = '';
  hasRdbNameChanged: boolean;

  constructor(private readonly controlContainer: ControlContainer, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }

  ngOnDestroy(): void {
    this.removeChildFormControls(this.db2iConnectionForm);
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.hasRdbNameChanged = false;
    this.createForm();
  }

  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): Connection {
    const connection = this.credentialsComponent.getConnection(isTesting); // only populates the user & password properties
    connection.database = this.db2iConnectionForm.get('database').value;
    const IASPOptionSelected = this.db2iConnectionForm.get('enableIASP').value;
    connection.parameters = [
      {
        key: DB2I_CONNECTION_PARAMETERS.DB2_I_LIBRARY_INSTALLATION,
        value: this.db2iConnectionForm.get('installationLibrary').value
      },
      {
        key: DB2I_CONNECTION_PARAMETERS.DB2_I_ENABLE_IASP,
        value: IASPOptionSelected
      }
    ];

    if (IASPOptionSelected === 'YES') {
      connection.parameters.push({
        key: DB2I_CONNECTION_PARAMETERS.DB2_I_IASP_NAME,
        value: this.db2iConnectionForm.get('iaspName').value
      });
      connection.parameters.push({
        key: DB2I_CONNECTION_PARAMETERS.DB2_I_RDB_NAME,
        value: this.db2iConnectionForm.get('rdbName').value
      });
    }

    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   */
  set connection(connection: Connection) {
    this.db2iConnectionForm.patchValue({
      database: connection.database,
      installationLibrary: this.getParameterValue(connection.parameters, DB2I_CONNECTION_PARAMETERS.DB2_I_LIBRARY_INSTALLATION),
      enableIASP: this.getParameterValue(connection.parameters, DB2I_CONNECTION_PARAMETERS.DB2_I_ENABLE_IASP),
      iaspName: this.getParameterValue(connection.parameters, DB2I_CONNECTION_PARAMETERS.DB2_I_IASP_NAME),
      rdbName: this.getParameterValue(connection.parameters, DB2I_CONNECTION_PARAMETERS.DB2_I_RDB_NAME)
    });
    this.credentialsComponent.connection = connection;

    // database location is not being saved as part of the connection
    // we need to determine it by comparing the database and selected runtime server
    // if they are the same then database location is 'Runtime server'
    this.remoteDatabase = connection.database;
    const IASPDisable = this.getParameterValue(connection.parameters, DB2I_CONNECTION_PARAMETERS.DB2_I_ENABLE_IASP);
    this.enableIASPDropDownChange({ value: IASPDisable });
    const isRuntimeServer = connection.accessFromServer.hostname === connection.database;
    const databaseLocation = isRuntimeServer ? 'RUNTIME' : 'REMOTE';
    this.db2iConnectionForm.get('databaseLocation').setValue(databaseLocation);
    this.databaseLocationDropDownChange({ value: databaseLocation });
  }

  createForm(): void {
    this.db2iConnectionForm = this.controlContainer.control as FormGroup;
    this.db2iConnectionForm.addControl('databaseLocation', new FormControl('REMOTE'));
    this.db2iConnectionForm.addControl(
      'database',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.db2iConnectionForm.addControl(
      'installationLibrary',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.db2iConnectionForm.addControl('enableIASP', new FormControl('NO'));
    this.db2iConnectionForm.addControl('iaspName', new FormControl({ value: '', disabled: true }));
    this.db2iConnectionForm.addControl('rdbName', new FormControl({ value: '', disabled: true }));
    this.db2iConnectionForm.addControl('dbmsVersion', new FormControl('-'));
    this.db2iConnectionForm.addControl('driverVersion', new FormControl('-'));
    this.db2iConnectionForm.addControl('gmtOffset', new FormControl('-'));
  }

  /**
   * Enables or disables the IASP Name and RDB Name based on whether IASP is enabled
   * @param selectedValue YES or NO
   */
  enableIASPDropDownChange(selectedValue) {
    if (selectedValue.value === 'NO') {
      this.db2iConnectionForm.get('iaspName').disable();
      this.db2iConnectionForm.get('rdbName').disable();
    } else {
      this.db2iConnectionForm.get('iaspName').enable();
      this.db2iConnectionForm.get('rdbName').enable();
    }
  }

  /**
   * Event handler for the database location dropdown
   */
  databaseLocationDropDownChange(selectedValue) {
    if (selectedValue.value === 'RUNTIME') {
      this.remoteDatabase = this.db2iConnectionForm.get('database').value;
      this.db2iConnectionForm.get('database').disable();
      this.db2iConnectionForm.get('database').setValue(this.selectedRuntimeServer.hostname);
    } else {
      this.db2iConnectionForm.get('database').enable();
      this.db2iConnectionForm.get('database').setValue(this.remoteDatabase);
    }
  }

  /**
   * Event handler for the IASP name
   */
  iaspNameChanged(event) {
    if (!this.hasRdbNameChanged) {
      this.db2iConnectionForm.get('rdbName').setValue(event.target.value);
    }
  }
}
