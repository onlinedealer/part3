import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarepassSelfUnenrollComponent } from './carepass-self-unenroll.component';

describe('CarepassSelfUnenrollComponent', () => {
  let component: CarepassSelfUnenrollComponent;
  let fixture: ComponentFixture<CarepassSelfUnenrollComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarepassSelfUnenrollComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarepassSelfUnenrollComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
