import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { map } from 'rxjs/operators';
import { BaseCatalogApiService } from 'src/app/core/base-catalog-api.service';
import { ColumnModel } from './schema-table-selector';

/**
 * Service to retrieve the catalog metadata
 */
@Injectable({
  providedIn: 'root'
})
export class CatalogMetadataApiService extends BaseCatalogApiService<any> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient, 'api/v1');
  }

  /**
   * Gets the list of schemas from the catalog
   * @param connectionId The connection id to use for the catalog
   * @param projectId The project id to use for the catalog
   * @param headers Additional HttpHeaders
   * @returns
   */
  getSchemas(connectionId: string, projectId?: string, headers?: HttpHeaders) {
    const params = {
      connection_id: connectionId
    };

    if (projectId) {
      params['project_id'] = projectId;
    }

    return this.httpClient.get(`${this.serviceURL}/schemas`, { params, headers });
  }

  /**
   * Gets the list of tables for a given schema from the catalog
   * @param connectionId The connection id to use for the catalog
   * @param projectId The project id to use for the catalog
   * @param schemaName The schema name to use for the catalog
   * @param headers Additional HttpHeaders
   * @returns
   */
  getTables(connectionId: string, projectId?: string, schemaName?: string, headers?: HttpHeaders) {
    let params = new HttpParams();

    params = params.append('connection_id', connectionId);

    if (projectId) {
      params = params.append('project_id', projectId);
    }

    if (schemaName) {
      params = params.append('schema_name', schemaName);
    }

    return this.httpClient.get(`${this.serviceURL}/tables`, { params, headers });
  }

  /**
   * Gets the columns from the table details for a given schema and table from the catalog
   * @param connectionId The connection id to use for the catalog
   * @param projectId The project id to use for the catalog
   * @param schemaName The schema name to use for the catalog
   * @param tableName The table name to use for the catalog
   * @param headers Additional HttpHeaders
   * @returns
   */
  getColumns(connectionId: string, projectId: string, schemaName: string, tableName: string, headers?: HttpHeaders) {
    // TODO: get the primary key once it's implementeed, currently the keys array is empty
    return this.getTableDetails(connectionId, projectId, schemaName, tableName, headers).pipe(
      map((response: any) => {
        return response.columns.map((column) => {
          return {
            dataType: column.dataType,
            isPrimaryKey: false,
            name: column.columnName
          } as ColumnModel;
        });
      })
    );
  }

  /**
   * Gets the table details for a given schema and table from the catalog
   * @param connectionId The connection id to use for the catalog
   * @param projectId The project id to use for the catalog
   * @param schemaName The schema name to use for the catalog
   * @param tableName The table name to use for the catalog
   * @param headers Additional HttpHeaders
   * @returns
   */
  getTableDetails(connectionId: string, projectId: string, schemaName: string, tableName: string, headers?: HttpHeaders) {
    const params = {
      connection_id: connectionId,
      project_id: projectId,
      schema_name: schemaName,
      table_name: tableName
    };

    return this.httpClient.get(`${this.serviceURL}/table`, { params, headers });
  }

  /**
   * Gets the list of topics from the catalog
   * @param connectionId The connection id to use for the catalog
   * @param projectId The project id to use for the catalog
   * @param headers Additional HttpHeaders
   * @returns
   */
  getTopics(connectionId: string, projectId?: string, headers?: HttpHeaders) {
    let params = new HttpParams();

    params = params.append('connection_id', connectionId);

    if (projectId) {
      params = params.append('project_id', projectId);
    }

    return this.httpClient.get(`${this.serviceURL}/topics`, { params, headers });
  }

  /**
   * Gets the list of journals from the catalog
   * @param connectionId The connection id to use for the catalog
   * @param projectId The project id to use for the catalog
   * @param headers Additional HttpHeaders
   * @returns
   */
  getJournals(connectionId: string, projectId: string, headers?: HttpHeaders) {
    // TODO: the API is not implemented yet, return an empty array for now to avoid errors
    /*
    const params = {
      connection_id: connectionId,
      project_id: projectId
    };

    return this.httpClient.get(`${this.serviceURL}/journalList`, { params, headers });*/
    return of([]);
  }
}
