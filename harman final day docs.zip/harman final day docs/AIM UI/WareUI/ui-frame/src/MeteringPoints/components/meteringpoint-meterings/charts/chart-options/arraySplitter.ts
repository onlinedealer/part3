import { FormArray } from "@angular/forms";
import { clone } from "lodash";

export const splitArray = (meterings: FormArray) => {
    const controls = clone(meterings.controls);
    const arrayExtra = controls.length % 3;
    const arrayDivided = (controls.length - arrayExtra) / 3;

    let array1Extra = 0;
    let array2Extra = 0;

    if (arrayExtra === 1) {
        array1Extra = 1;
    } else if (arrayExtra === 2) {
        array1Extra = 1;
        array2Extra = 1;
    }

    const array1 = controls.splice(0, arrayDivided + array1Extra);
    const array2 = controls.splice(0, arrayDivided + array2Extra);
    const array3 = controls.splice(0, arrayDivided);
    const arrays = [array1, array2, array3];

    return arrays;
};
