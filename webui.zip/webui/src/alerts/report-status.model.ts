export class ReportStatusModel {
  status: string;
  message: string;
  jobId: string;
}
