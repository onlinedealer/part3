(function() {
    'use strict';

    codeathonApp.controller("hostCtrl", ['$scope', '$ajaxFactory', 'uiRouters', '$location', hostCtrl]);

    function hostCtrl($scope, $ajaxFactory, uiRouters, $location) {
        $scope.hostDataSource = [];
        $scope.itemData = {};
        $scope.isEditOrAddPage = false;
        $scope.isAddPage = false;
        $scope.hostName = "";
        $scope.description = "";
        $scope.parentHostName = "";
        $scope.subHostName = "";
        $scope.buttonText = "";
        $scope.headerText = "";
        $scope.parentHostData = [];
        var userId = "";
        var hostId = "";
        var url = "";

        // redirecting to /login page
        if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        }

        $scope.editItem = function(item) {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = false;
            $scope.itemData = item;
            $scope.hostName = item.name;
            $scope.description = item.description;
            $scope.parentHostName = $scope.parentHostData[0].value;
            $scope.subHostName = "";
            $scope.buttonText = "Update";
            $scope.headerText = "Edit";
            hostId = item.id;
        };

        $scope.addItem = function() {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = true;
            $scope.hostName = "";
            $scope.description = "";
            $scope.parentHostName = $scope.parentHostData[0].value;
            $scope.subHostName = "";
            $scope.buttonText = "Add";
            $scope.headerText = "Create";
        };

        $scope.removeItem = function(hostId) {
            indicatorStart("Deleting Host..");
            url = "/delete/host/" + hostId + "/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'POST', {});

            promise.then(function(d) {
                $scope.hostDataSource = d;
                console.log('Delete Success');
				 $scope.fetchDataSource();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.saveData = function(e) {
            if (Codeathon.utils.isNullOrEmpty($scope.hostName) || Codeathon.utils.isNullOrEmpty($scope.description)) {
                alert("All Fields Required");
                return;
            } else {
                var obj = {}
                obj.name = $scope.hostName;
                obj.description = $scope.description;
				obj.parentHost = $scope.parentHostName;

                // if isAddPage true : Adding New Host
                // if isAddPage False : Editing Host
                if ($scope.isAddPage) {
                    indicatorStart("Adding Host..");
                    url = uiRouters.urlpath + "/add/new/host/user/" + userId + "/";

                } else {
                    indicatorStart("Updating Host..");
                    url = uiRouters.urlpath + "/modify/host/" + hostId + "/user/" + userId + "/";
                }
                var promise = $ajaxFactory.getDataFromServer(url, 'POST', obj);

                promise.then(function(d) {
                    $scope.hostDataSource = d;
                    $scope.isEditOrAddPage = false;
                    $scope.isAddPage = false;
                    console.log('Success');

                    var obj = {};
                    obj.message = "Host";
                    obj.content = "Success";
                    obj.eventObj = e;
                    $scope.$emit('openPopupEvent', obj);
					 $scope.fetchDataSource();
                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
                promise.finally(function(d) {
                    console.log('finally block executed', d);
                    indicatorStop();
                });

            }
        }

        $scope.cancel = function() {
            $scope.isEditOrAddPage = false;
            $scope.isAddPage = false;
        }

        $scope.fetchDataSource = function() {
           var url = "/get/list/of/host/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/host/data.json', 'GET', {});
         //   var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.hostDataSource = d;
                $scope.parentHostData = Codeathon.utils.getListByProperty(d, 'id', 'name');
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        }
        $scope.fetchDataSource();
    }

})();
