import React from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Route } from 'react-router-dom'
import Layout from './Layout/Layout'
import apiConfig from '../config/apiConfig'
import qs from 'querystring'
import { getPayload } from 'react-oauth-openid'
import * as userActions from '../store/auth'

class LaunchPage extends React.Component {
  componentWillMount () {
    if (window.localStorage.length > 0) {
      const idPayload = getPayload('id_token')
      this.props.userActions.signInSuccess(idPayload)
    } else {
      this.loadPage(this.props)
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.userInfo.popupType !== 'logout') {
      this.loadPage(nextProps)
    }
  }

  loadPage (getProps) {
    const { userInfo } = getProps
    if (!userInfo.isAuthorized) {
      const params = {
        client_id: apiConfig.auth.clientId,
        nonce: apiConfig.auth.nonce,
        redirect_uri: apiConfig.auth.redirectUri,
        response_type: apiConfig.auth.responseType,
        scope: apiConfig.auth.scope,
        token_type: apiConfig.auth.tokenType,
      }
      const authorizationUrl = `${apiConfig.auth.host}${apiConfig.auth.authorizationPath}`
      const loginUrl = `${authorizationUrl}?${qs.stringify(params)}`
      window.location.replace(loginUrl)
      /* } else if (userInfo.memberOf.indexOf(apiConfig.auth.adGroup) === -1) {
      window.location.replace(apiConfig.auth.accessDeniedHost) */
    }
  }

  render () {
    if (this.props.userInfo.isAuthorized) {
      return (<Route path="/" component={Layout} />)
    } else {
      return null
    }
  }
}

function mapStateToProps (state) {
  return {
    userInfo: state.get('auth').toJS(),
  }
}

function mapDispatchToProps (dispatch) {
  return {
    userActions: bindActionCreators(userActions, dispatch),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(LaunchPage)
