export class Statistics {
  id: string;
  label: string;
  chartType: string;
  groupName: string;
}

export class StatsGroup {
  group: string;
  listStats: Statistics[];
}
