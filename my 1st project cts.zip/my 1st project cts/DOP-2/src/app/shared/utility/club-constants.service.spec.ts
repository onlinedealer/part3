import { TestBed, inject } from '@angular/core/testing';

import { ClubConstantsService } from './club-constants.service';

describe('ClubConstantsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ClubConstantsService]
    });
  });

  it('should be created', inject([ClubConstantsService], (service: ClubConstantsService) => {
    expect(service).toBeTruthy();
  }));
});
