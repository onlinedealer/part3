export interface MeasuredUnit {
    measuredUnitId: number;
    baseUnit?: Unit;
    baseUnitId?: number;
    ediQualifier?: string;
    factor: number;
    name: string;
}

export interface Unit {
    baseUnitId?: number;
    factor: number;
    measuredUnitId: number;
    name: string;
}
