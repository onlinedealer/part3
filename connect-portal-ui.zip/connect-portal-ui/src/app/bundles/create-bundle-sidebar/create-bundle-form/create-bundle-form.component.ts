import { Component, Input, OnChanges, OnInit, SimpleChanges } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { Connection, CONNECTION_TYPE } from 'src/app/connections/shared/connection';
import { Project } from 'src/app/pipelines/pipeline/shared/project';

@Component({
  selector: 'p-connect-create-bundle-form',
  templateUrl: './create-bundle-form.component.html'
})
export class CreateBundleFormComponent implements OnInit, OnChanges {
  createBundleForm: FormGroup;
  @Input() date = '';
  @Input() project: Project;
  @Input() listOfSourceConnectionsInProject: Connection[];
  @Input() bundleLocation = '';
  @Input() agentName = '';

  constructor(private readonly formBuilder: FormBuilder) {}

  get isProjectComitted(): boolean {
    return this.project && this.project.id ? true : false;
  }

  get areIBMIConnectionsUsedInProject(): boolean {
    return this.listOfSourceConnectionsInProject?.filter((connection) => connection.connectionType === CONNECTION_TYPE.DB2I).length
      ? true
      : false;
  }

  get projectName(): string {
    return this.project ? this.project.name : '';
  }

  ngOnInit(): void {
    this.createForm();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.date?.currentValue && this.createBundleForm) {
      this.createBundleForm.get('bundleName').setValue('Diagnostic_Bundle_' + changes.date.currentValue);
    }
  }

  private createForm(): void {
    this.createBundleForm = this.formBuilder.group({
      bundleName: new FormControl(''),
      bundleDescription: new FormControl(this.date)
    });
  }
}
