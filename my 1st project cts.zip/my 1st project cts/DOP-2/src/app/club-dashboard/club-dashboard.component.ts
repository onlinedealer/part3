import { Component, OnInit } from '@angular/core';
import { ClubBenefitDashboardComponent } from '../club-benefit-dashboard/club-benefit-dashboard.component';
import { RouterLink, Router } from '@angular/router';
import { AjaxUtilityService } from '../shared/utility/ajax-utility.service';
import { HttpResponse, HttpParams } from '@angular/common/http';
import { ActiveModelService } from '../shared/models/active-model.service';
import { DigitalProfileModel } from '../shared/models/digital-profile-model';
import { UtilityService } from '../shared/utility/utility.service';
import * as _ from 'underscore';
import { DomSanitizer } from '@angular/platform-browser';
import { ModalOpenerService } from '../shared/utility/modal-opener.service';
import { TermsAndConditionsModalComponent } from '../terms-and-conditions-modal/terms-and-conditions-modal.component';
import { ClubGenericErrorComponent } from '../shared/components/club-generic-error/club-generic-error.component';
import { CookieUtilityService } from '../shared/utility/cookie-utility.service';
import { UtagService } from 'utag-module';
import { ClubConstantsService, RouteConfigurations } from '../shared/utility/club-constants.service';
import { Title, Meta } from '@angular/platform-browser';

@Component({
  selector: 'app-club-dashboard',
  templateUrl: './club-dashboard.component.html',
  styleUrls: ['./club-dashboard.component.scss']
})
export class ClubDashboardComponent implements OnInit {

  welcomeTxt = 'Welcome back, ';
  fName: string;
  rxLinked: boolean;
  help = '';
  cardInfo: object;
  unit = 'month';
  digitalProfile: DigitalProfileModel;
  businessContent: any;
  businessContentModal: any;
  cardExpiryTitle: string;
  cpnAmount: number;
  enrollmentStat = false;
  showDisclaimer: boolean;
  isApp: boolean;
  creditAvailablity = {
    title: '',
    subTitle: '',
    link: '',
    action: '',
    creditAvailable: false
  };
  subscriptionType = {
    'title': '',
    'subTitle': ''
  };
  serviceError = false;

  clubPaymentDetails: any = {
    'defaultCard': {
      'lastFourDigits': '',
      'cardType': '',
      'expirationDateIndicator': ''
    }
  };

  getDigitalProfileReq = {
    'getDigitalProfileRequest': {
      'idType': 'email',
      'idValue': 'samar.chowdhury@cvscaremark.com',
      'operation': 'fullprofile',
      'extracareCardNum': '4878075301355'
    }
  };

  getDigitalProfileResponse: object;
  dashboardData: object;

  getPaymentTitleSubtitle(paymentDetail): object {
    if (paymentDetail.hasOwnProperty('paymentInformation')) {
      return {
        'title': 'Payment infromation',
        'subTitle': paymentDetail['paymentInformation']['cardType'] + ' ending in ' + paymentDetail['paymentInformation']['cardNumber']
      };
    } else if (paymentDetail.hasOwnProperty('membershipPlan')) {
      return {
        'title': 'CVS Club membership plan',
        'subTitle': paymentDetail['membershipPlan']['yearlyPlan'] ? 'Yearly ($12.98 / month)' : 'Monthly ($3.99 / month)'
      };
    }
  }

  constructor(
    private _ajaxUtility: AjaxUtilityService,
    private _activeModel: ActiveModelService,
    private _utility: UtilityService,
    private _sanitizer: DomSanitizer,
    private _modalService: ModalOpenerService,
    private _router: Router,
    private _cookieService: CookieUtilityService,
    private _utag: UtagService,
    private _constants: ClubConstantsService,
    private _title: Title,
    private _meta: Meta
  ) {
    _title.setTitle(RouteConfigurations.clubDashboardTitle);
    _meta.removeTag("name='description'");    
    _meta.addTag({ name: 'description', content: RouteConfigurations.carepassDashboardDesc });    
  }

  ngOnInit() {
    try {
      this.isApp = (<any>window).native ? true : false;
    } catch (error) {
      this.isApp = false;
      console.error(error);
    }
    if (this._cookieService.exists('SCC_COOKIE')) {
      this.fetchDigitalProfile();
    } else {
      this._router.navigate(['/' + RouteConfigurations.clubBenefits]);
    }
    this.fetchPageContent(this._utility.getUserAgent().indexOf('_MOBILE') !== -1 ? '30414' : '30415');
  }

  /**
   * @method fetchPageContent - method to make BCC service call
   * @param contentId - BCC content id
   */

  fetchPageContent(contentId) {
    this._ajaxUtility.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            this.businessContent = JSON.parse(this._utility.getDecrypted(response.details.slotContent));
            try {
              this.businessContent.rxDelivery = this._sanitizer.bypassSecurityTrustHtml(this.businessContent.rxDelivery);
              this.businessContent.freeShippingContent = this._sanitizer.bypassSecurityTrustHtml(this.businessContent.freeShippingContent);
              this.businessContent.freeNextDayDeliveryContent = this._sanitizer.bypassSecurityTrustHtml(this.businessContent.freeNextDayDeliveryContent);
              this.businessContent.pharmacyHotlineContent = this._sanitizer.bypassSecurityTrustHtml(this.businessContent.pharmacyHotlineContent);
              this.businessContent.discountContent = this._sanitizer.bypassSecurityTrustHtml(this.businessContent.discountContent);
              this.businessContent.savingContent = this._sanitizer.bypassSecurityTrustHtml(this.businessContent.savingContent);
              this.showDisclaimer = this.businessContent.disclaimer ? true : false;
              this.businessContent.disclaimer = this._sanitizer.bypassSecurityTrustHtml(this.businessContent.disclaimer);
            } catch (error) {
            }
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }

  fetchDigitalProfile() {
    this._ajaxUtility.sendRequest('getDigitalProfile')
      .subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('getDigitalProfileResponse')) {

          response = data['getDigitalProfileResponse'];
          if (response.hasOwnProperty('header') && response.header.hasOwnProperty('statusCode') && '0000' === response.header.statusCode) {
            this.serviceError = false;
            this.dashboardData = response.additionalDetails;
            if (!this.dashboardData['ecTied']) {
              this._router.navigate(['/' + RouteConfigurations.clubRegistration]);
            } else {
              try {
                const utagObj = {
                  'page_name': 'carepass:dashboard'
                };
                setTimeout(() => {
                  this._utag.view(utagObj);
                }, 2000);
              } catch (error) {}
            }

            if (response.additionalDetails.hasOwnProperty('carePassCreditAvailable')
            && response.additionalDetails.carePassCreditAvailable
            && response.additionalDetails.hasOwnProperty('carePassCpns')
            && response.additionalDetails.carePassCpns.length
            && response.additionalDetails.carePassCpns[0]) {
              this.cpnAmount = response.additionalDetails.carePassCpns[0].cpnAmount;
              this.creditAvailablity.title = '$' + this.cpnAmount + ' promotional reward still available';
              this.creditAvailablity.subTitle = 'Use it by ' + response.additionalDetails.carePassCpns[0]['expirationDate'];
              this.creditAvailablity.link = 'Shop now';
              this.creditAvailablity.creditAvailable = true;
              this.creditAvailablity.action = '/shop';
            } else {
              if (response.additionalDetails.hasOwnProperty('carePassCpns')) {
                this.cpnAmount = response.additionalDetails.carePassCpns[0].cpnAmount;
                //this.creditAvailablity.title = 'More CVS Club credit coming soon';
                this.creditAvailablity.title = 'Check back soon!';
                this.creditAvailablity.subTitle = 'You\'ve redeemed this month\'s promotional reward. Look for your next reward around ' + response.additionalDetails.benefitEligibilityDt + '.';
                this.creditAvailablity.link = 'How rewards work';
                this.creditAvailablity.action = '/carepass/join';
                this.creditAvailablity.creditAvailable = false;
              }
            }

            if (response.additionalDetails.hasOwnProperty('subscriptionPrice')) {
              this.subscriptionType.title = 'Your next payment $' + response.additionalDetails.subscriptionPrice + ' is scheduled for ' +response.additionalDetails.billingDate;
            }

            if (response.additionalDetails.hasOwnProperty('carePassCpns') && response.additionalDetails.carePassCpns.length > 0) {
              this.cardExpiryTitle = 'You have '
              + response.additionalDetails.carePassCpns[0].daysToExpire
              + ' days left to use your Club credit this month!';
            }

            if (response.additionalDetails.hasOwnProperty('carePassEnrollDt')) {
              this.help = response.additionalDetails.carePassEnrollDt;
            }

            if (response.additionalDetails.hasOwnProperty('carePassEnrollmentStatus')
            && ('ENROLLED' !== response.additionalDetails.carePassEnrollmentStatus && 'CANCEL_INITIATED' !== response.additionalDetails.carePassEnrollmentStatus)) {
              this._router.navigate(['/' + RouteConfigurations.clubBenefits]);
            }
            if (response.additionalDetails.hasOwnProperty('carePassEnrollmentStatus')) {
              this.enrollmentStat = ['enrolled', 'on_hold', 'cancel_initiated'].indexOf(response.additionalDetails.carePassEnrollmentStatus.toLowerCase()) >= 0;
            }

            this._activeModel.setProfile(this.digitalProfile = new DigitalProfileModel(this.dashboardData));
            this.fName = this.digitalProfile.firstName;
            this.rxLinked = this.digitalProfile.rxTied;
            this.unit = this.dashboardData['carePassSubscriptionType'] === 'MONTHLY' ? 'month' : 'year';
            /*
          this.clubPaymentDetails = this.digitalProfile.hasOwnProperty('cardList') && this.digitalProfile.cardList.length ? [
              {
                'paymentInformation': {
                  'cardNumber': this.digitalProfile.cardList[0].token.substring(12),
                  'cardType': this.digitalProfile.cardList[0].creditCardType
                }
              }, {
                'membershipPlan': {
                  'yearlyPlan': true// false - monthly, true - yearly
                }
              }
            ] : []; */

          if (this.digitalProfile.hasOwnProperty('cardList') && this.digitalProfile.cardList.length) {
            let enrolledCardIndex: number;
            _.map(this.digitalProfile.cardList, function(card, index) {
              if (card['carePassEnrolled']) {
                enrolledCardIndex = index;
              }
            });
            if (typeof enrolledCardIndex !== 'undefined') {
              this.clubPaymentDetails['defaultCard']['lastFourDigits'] = this.digitalProfile.cardList[enrolledCardIndex]['token'].substr(this.digitalProfile.cardList[enrolledCardIndex]['token'].length - 4);
              this.clubPaymentDetails['defaultCard']['cardType'] = this.updateCardType(this.digitalProfile.cardList[enrolledCardIndex]['creditCardType']);
              this.clubPaymentDetails['defaultCard']['expirationDateIndicator'] = this.digitalProfile.cardList[enrolledCardIndex]['expirationDateIndicator'];
              this.clubPaymentDetails['defaultCard']['expirationDate'] = this.digitalProfile.cardList[enrolledCardIndex]['expirationMonth']+'/'+this.digitalProfile.cardList[enrolledCardIndex]['expirationYear'].substr(this.digitalProfile.cardList[enrolledCardIndex]['expirationYear'].length - 2);
            }
          }
          } else {
            this.serviceError = true;
          }
        } else {
          this.serviceError = true;
        }
      },
      (err) => {
        console.error(err);
        this.serviceError = true;
      },
      () => {
      }
      );
  }

  updateCardType(cardType): string {
    // masterCard, visa, discover, americanExpress, dinersClub, jcb
    let updatedCardType = cardType;
    const modifiedCardTitles = [
      {type: 'masterCard', assignDiffType: false},
      {type: 'visa', assignDiffType: false},
      {type: 'discover', assignDiffType: false},
      {type: 'americanExpress', assignDiffType: false},
      {type: 'dinersClub', assignDiffType: true},
      {type: 'jcb', assignDiffType: true}
    ];
    _.map(modifiedCardTitles, function(cardToChange) {
      if (cardType === cardToChange.type) {
        switch (cardType) {
          case 'masterCard':
          updatedCardType = 'Mastercard';
              break;
          case 'visa':
          updatedCardType = 'Visa';
              break;
          case 'americanExpress':
          updatedCardType = 'American Express';
              break;
          case 'discover':
          updatedCardType = 'Discover';
              break;
          default:
          updatedCardType = 'Discover';
      }
      }
    }, this);

    return updatedCardType;
  }

  callService() {}

  /**
   * Logic to open Terms and conditions modal - start
   */

  openAgreementModal() {
    this.fetchTermsContent('30454');
  }

  openTermsModal() {
    if (this.businessContentModal) {
      this._modalService.openModal(TermsAndConditionsModalComponent,
        { windowClass: 'terms-conditions-modal' },
        this.businessContentModal).result.then(
        (result) => {},
        (reason) => {}
      );
    }
  }
  /**
   * @method fetchPageContent - method to make BCC service call
   * @param contentId - BCC content id
   */

  fetchTermsContent(contentId) {
    this._ajaxUtility.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            try {
              this.businessContentModal = this._sanitizer.bypassSecurityTrustHtml(this._utility.getDecrypted(response.details.slotContent));
              this.openTermsModal();
            } catch (error) {}
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }

  /**
   * Logic to open Terms and conditions modal - end
   */

  triggerLinkTag(src) {
    if ('savings' === src) {
      this._utag.link({
        'page_name': 'carepass dashboard:start saving now tile',
        'link_name': 'custom:carepass dashboard:start saving now tile'
      });
    } else if ('expiry' === src) {
      this._utag.link({
        'page_name': 'carepass dashboard:expiring deals tile',
        'link_name': 'custom:carepass dashboard:expiring deals tile'
      });
    } else if ('cardExp' === src) {
      this._utag.link({
        'page_name': 'carepass dashboard:expire:update payment information link',
        'link_name': 'custom:carepass dashboard:expire:update payment information link'
      });
    } else if ('shopOnline' === src) {
      this._utag.link({
        'page_name': this.creditAvailablity.creditAvailable ? 'carepass:dashboard:shop online credit available link' : 'carepass:dashboard:how carepass credits work link',
        'link_name': this.creditAvailablity.creditAvailable ? 'custom:carepass:dashboard:shop online credit available link' : 'custom:carepass:dashboard:how carepass credits work link'
      });
    } else {}
  }

}
