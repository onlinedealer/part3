import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LockedCebsComponent } from './locked-cebs.component';

describe('LockedCebsComponent', () => {
  let component: LockedCebsComponent;
  let fixture: ComponentFixture<LockedCebsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LockedCebsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LockedCebsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should be expandable', () => {
    expect(component.showExpandedView).toBeTruthy();
  });

  it('should be collapsable from the expanded view', () => {
    expect(component.hideFromExpanded).toBeTruthy();
  });
    it('should render a headline in an h3 tag', async(() => {
    const fixture = TestBed.createComponent(LockedCebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('h3').textContent).toContain('ExtraBucks<sup>®</sup> Rewards');
  }));
    it('should render a description', async(() => {
    const fixture = TestBed.createComponent(LockedCebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('span').textContent).toContain(this.data.webDsc);
  }));
    it('should render the threshhold quantity/dollar left', async(() => {
    const fixture = TestBed.createComponent(LockedCebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('p').textContent).toContain(this.data.ptsToNextThreshldQty);
  }));
   it('should render a shop to unlock action in a span tag', async(() => {
    const fixture = TestBed.createComponent(LockedCebsComponent);
    fixture.detectChanges();
    const compiled = fixture.debugElement.nativeElement;
    expect(compiled.querySelector('span').textContent).toContain('Shop to unlock');
  }));
});
