import { Component, Input } from "@angular/core";
import { FormGroup } from "@angular/forms";

@Component({
  selector: "landisgyr-metering-line-graph",
  templateUrl: "./metering-line-graph.component.html",
  styleUrls: ["./metering-line-graph.component.scss"]
})
export class MeteringLineGraphComponent {
  @Input() views: any;
  @Input() schemes: any;
  @Input() result: any;
  @Input() gradients: any;
  @Input() xAxisshow: any;
  @Input() yAxisshow: any;
  @Input() legends: any;
  @Input() showXAxisLabels: any;
  @Input() showYAxisLabels: any;
  @Input() xAxisLabels: any;
  @Input() yAxisLabels: any;
  @Input() parents!: FormGroup;

  constructor() { }

}
