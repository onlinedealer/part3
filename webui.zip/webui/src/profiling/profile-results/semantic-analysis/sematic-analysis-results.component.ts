import { Component, Input } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { TreePath } from '../tree-path.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-sematic-analysis-results',
  templateUrl: './sematic-analysis-results.component.html',
  styleUrls: ['./sematic-analysis-results.component.css']
})
export class SematicAnalysisResultsComponent {
  _treePath: TreePath;
  _semanticStats: any = [];
  isMultiSemanticInfo = false;
  get treePath(): TreePath {
    return this._treePath;
  }

  @Input()
  set treePath(val: TreePath) {
    this._treePath = val;
    this.loadData();
  }

  get semanticStats(): Record<string, unknown> {
    return this._semanticStats;
  }

  @Input()
  set semanticStats(val: Record<string, unknown>) {
    this._semanticStats = val;
    this.loadData();
  }
  semanticTables = [];
  multiSemanticInfoTables = [];
  semanticDonuts = [];
  multipleSemantic = false;
  constructor(private translocoService: TranslocoService) {}

  getTableChartWidth(length): number {
    if (length > 1) {
      return 6;
    } else {
      return 12;
    }
  }

  getDonutChartWidth(): number {
    let totalCharts = 0;
    totalCharts = this.semanticDonuts.length;
    if (totalCharts >= 3) {
      return 4;
    } else if (totalCharts === 2) {
      return 6;
    } else {
      return 12;
    }
  }

  loadData(): void {
    this.clearStatistics();
    this.checkMultipleSemantic();
    this.isMultiSemanticInfo = false;
    if (this.semanticStats.length) {
      if (this.multipleSemantic) {
        this.multipleSemanticTableConfig(this.semanticStats);
      } else {
        this.singleSemanticTableConfig();
      }
    }
  }
  onMultiSemanticTableRowClick = (value) => {
    this.multiSemanticInfoTables = [];
    const { isInfo, data } = value;
    this.isMultiSemanticInfo = isInfo;
    for (const key of Object.keys(data)) {
      const tableType = [];
      const tableHeaders = [];
      if (data[key] && data[key]['type'] === 'FrequencyStatistics') {
        for (const key1 of Object.keys(data[key]['frequency'])) {
          tableType.push({ [key]: key1, count: data[key]['frequency'][key1] });
        }
        tableHeaders.push(
          { field: key, header: this.translocoService.translate('discoveryProfiling.results.columnValue') },
          {
            field: 'count',
            header: this.translocoService.translate('discoveryProfiling.results.countColumn')
          }
        );
        this.multiSemanticInfoTables.push({ cols: tableHeaders, data: tableType, name: key, defaultSort: 'count' });
      }
    }
  };

  private singleSemanticTableConfig = () => {
    for (const semanticStat of this._semanticStats) {
      if (semanticStat['type']) {
        switch (semanticStat['type']) {
          case ProfilingConstants.STATS.CONFIDENCE:
            const donut = this.createDonut(
              'confidence',
              semanticStat,
              semanticStat['semanticType'],
              semanticStat['displayName']
            );
            this.semanticDonuts.push(donut);
            break;
        }
      }
      for (const key of Object.keys(semanticStat)) {
        const statistic = semanticStat[key];
        switch (statistic['type']) {
          case ProfilingConstants.STATS.FREQUENCY:
            const table = this.createTable(key, statistic, semanticStat['semanticType']);
            this.semanticTables.push(table);
            break;
          case ProfilingConstants.STATS.VALIDITY:
            const donut = this.createDonut(key, statistic, semanticStat['semanticType'], semanticStat['displayName']);
            this.semanticDonuts.push(donut);
            break;
        }
      }
    }
  };
  private multipleSemanticTableConfig = (data: Record<string, unknown>) => {
    const table = this.createTable(
      ProfilingConstants.SEMANTICSTATSFREQUENCY.MULTIPLE_SEMANTIC,
      data,
      ProfilingConstants.SEMANTICSTATSFREQUENCY.MULTIPLE_SEMANTIC
    );
    this.semanticTables.push(table);
  };

  private clearStatistics(): void {
    this.multipleSemantic = false;
    this.semanticTables = [];
    this.semanticDonuts = [];
  }

  private createTable(key: string, statistic: any, type: string) {
    const table = {};
    table['name'] = key;
    table['data'] = statistic;
    table['type'] = type;
    if (this._treePath.tableView) {
      table['totalRows'] = this._treePath.treeData.data.totalRows;
    } else if (this._treePath.columnView) {
      table['totalRows'] = this._treePath.treeData.parent.data.totalRows;
    }
    return table;
  }
  private createDonut(key: string, statistic: any, type: string, displayName: string) {
    const donut = {};
    donut['name'] = key;
    donut['data'] = statistic;
    donut['type'] = type;
    donut['displayName'] = displayName;
    if (this._treePath.tableView) {
      donut['totalRows'] = this._treePath.treeData.data.totalRows;
    } else if (this._treePath.columnView) {
      donut['totalRows'] = this._treePath.treeData.parent.data.totalRows;
    }
    return donut;
  }

  private checkMultipleSemantic() {
    const types = [...new Set(this._semanticStats.map((stat) => stat.semanticType))];
    this.multipleSemantic = types.length > 1;
  }
}
