(function (window) {
  window['env'] = window['env'] || {};

  // Environment variables
  window['env']['configUrl'] = '';
  window['env']['metricsUrl'] = '';
  window['env']['doConfigUrl'] = '';
  window['env']['exportUrl'] = '';
})(this);
