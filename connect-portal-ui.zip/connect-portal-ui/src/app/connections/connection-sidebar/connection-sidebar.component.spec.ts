import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA, SimpleChange, SimpleChanges } from '@angular/core';
import { ComponentFixture, fakeAsync, flush, TestBed, tick } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { MetadataApiService } from '../../pipelines/pipeline/data/schema-table-selector/metadata-api.service';
import { MockSidebarComponent } from '../../shared/components/sidebar/mock-sidebar.component.spec';
import { FeatureFlagService } from '../../shared/services/feature-flag.service';
import { ConnectionsApiService } from '../shared/connections-api.service';
import { ConnectionFormComponent } from './connection-form/connection-form.component';
import { ConnectionSidebarComponent } from './connection-sidebar.component';

describe('ConnectionSidebarComponent', () => {
  let component: ConnectionSidebarComponent;
  let fixture: ComponentFixture<ConnectionSidebarComponent>;
  let connectionsService: ConnectionsApiService;
  let metadataApiService: MetadataApiService;

  const mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

  @Component({
    selector: 'p-connect-connection-form',
    template: '',
    providers: [
      {
        provide: ConnectionFormComponent,
        useClass: MockConnectionFormComponent
      }
    ]
  })
  class MockConnectionFormComponent {
    supportedConnectionTypes = [{ label: 'ORACLE', value: 'ORACLE' }];
    childComponentReference = {
      instance: {
        connection: { connectionType: 'DB2ZOS' }
      },
      destroy: () => {}
    };
    getConnection() {
      return { parameters: [] };
    }
    set connection(connection) {}
    connectionFormGroup = new FormGroup({
      id: new FormControl('1'),
      connectionType: new FormControl(''),
      connectionDetails: new FormGroup({
        username: new FormControl(''),
        password: new FormControl(''),
        testUser: new FormControl(''),
        testPassword: new FormControl(''),
        runtimeServer: new FormControl('myServer')
      })
    });
    getRuntimeServersList() {}
    updateTestValues() {}
    setupFormAndChildComponent() {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ],
      declarations: [ConnectionSidebarComponent, MockSidebarComponent, MockConnectionFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectionSidebarComponent);
    component = fixture.componentInstance;
    connectionsService = TestBed.inject(ConnectionsApiService);
    metadataApiService = TestBed.inject(MetadataApiService);
    fixture.detectChanges();

    jasmine.getEnv().allowRespy(true);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('primary button text', () => {
    it('should be SAVE if scalable commit feature is not enabled', () => {
      component.ngOnInit();
      expect(component.primaryButton.text).toBe('connections.CONNECTION_FORM.BUTTONS.SAVE_AND_CONTINUE');
    });
  });

  describe('changes to component', () => {
    it('should not do anything if changes does not contain isVisible property', () => {
      spyOn(component, 'ngOnDestroy').and.callThrough();
      const changesObj: SimpleChanges = { something: new SimpleChange('1', null, true) };
      component.ngOnChanges(changesObj);
      expect(component.ngOnDestroy).not.toHaveBeenCalled();
    });

    it('should destroy conmponent if sidebar is closed', () => {
      component.isVisible = false;
      spyOn(component, 'ngOnDestroy').and.callThrough();
      const changesObj: SimpleChanges = { isVisible: new SimpleChange(true, false, false) };
      component.ngOnChanges(changesObj);
      expect(component.ngOnDestroy).toHaveBeenCalled();
    });

    it('should check if the test user credentials were entered', fakeAsync(() => {
      component.isVisible = true;
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({ connectionType: 'DB2ZOS' });
      spyOn(component.connectionFormComponent, 'setupFormAndChildComponent');
      const changesObj: SimpleChanges = { isVisible: new SimpleChange(true, false, false) };
      component.ngOnChanges(changesObj);
      component.connectionFormComponent.connectionFormGroup.patchValue({
        id: 1,
        connectionDetails: { testUser: 'test', testPassword: 'pwd' }
      });
      tick();
      fixture.whenStable().then(() => {
        expect(component.connectionFormComponent.setupFormAndChildComponent).toHaveBeenCalled();
      });
    }));
  });

  describe('cancel button', () => {
    it('should hide the sidebar by setting isVisible to false', () => {
      spyOn(component.connectionFormComponent.childComponentReference, 'destroy').and.returnValue();
      component.cancelConnectionButtonClicked();
      expect(component.isVisible).toBe(false);
    });

    it('should reset button styles', () => {
      spyOn(component.connectionFormComponent.childComponentReference, 'destroy').and.returnValue();
      component.cancelConnectionButtonClicked();
      expect(component.primaryButton.buttonClassName).toBe('');
      expect(component.cancelButton.text).toEqual('connections.CONNECTION_FORM.BUTTONS.CANCEL');
      expect(component.cancelButton.buttonClassName).toBe('');
    });

    it('should show catalog warning message if user clicks finish button once and start cataloging button is not clicked', () => {
      component.activeStepIndex = 1;
      component.isStartCatalogButtonClicked = false;
      component.cancelConnectionButtonClicked();
      expect(component.finishButtonClickCount).toEqual(1);
      expect(component.showCatalogWarning).toBe(true);
    });

    it('should hide catalog warning message & close sidebar if user clicks finish button more than once and start cataloging button is not clicked', () => {
      spyOn(component, 'closeSidebarAndResetForm').and.returnValue();
      component.activeStepIndex = 1;
      component.isStartCatalogButtonClicked = false;
      component.finishButtonClickCount = 1;
      component.cancelConnectionButtonClicked();
      expect(component.finishButtonClickCount).toEqual(0);
      expect(component.showCatalogWarning).toBe(false);
      expect(component.closeSidebarAndResetForm).toHaveBeenCalled();
    });

    it('should close sidebar if user clicks finish button and start cataloging button was clicked', () => {
      spyOn(component, 'closeSidebarAndResetForm').and.returnValue();
      component.activeStepIndex = 1;
      component.isStartCatalogButtonClicked = true;
      component.cancelConnectionButtonClicked();
      expect(component.showCatalogWarning).toBe(false);
      expect(component.closeSidebarAndResetForm).toHaveBeenCalled();
    });

    it('should hide catalog warning message & close sidebar if user clicks finish button more than once and no schemas/topics cataloged', () => {
      spyOn(component, 'closeSidebarAndResetForm').and.returnValue();

      component.activeStepIndex = 1;
      component.isStartCatalogButtonClicked = false;
      component.finishButtonClickCount = 1;
      component.cancelConnectionButtonClicked();
      expect(component.finishButtonClickCount).toEqual(0);
      expect(component.showCatalogWarning).toBe(false);
      expect(component.closeSidebarAndResetForm).toHaveBeenCalled();
      expect(component.isStartCatalogButtonClicked).toBe(false);
    });
  });

  describe('update sidebar', () => {
    it('should update sidebar when esc key press', () => {
      spyOn(component.isVisibleChanged, 'emit');
      component.updateVisibility(false);
      expect(component.isVisibleChanged.emit).toHaveBeenCalled();
    });
  });

  describe('opening existing connection', () => {
    it('should call API and update form', fakeAsync(() => {
      const connectionSpy = spyOnProperty(component.connectionFormComponent, 'connection', 'set').and.callThrough();
      spyOn(connectionsService, 'get').and.returnValue(of({}));
      component.openConnection('1');
      tick();
      expect(connectionSpy).toHaveBeenCalled();
      flush();
    }));

    it('should be able to handle errors from API', fakeAsync(() => {
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      spyOn(component.connectionFormComponent.connectionFormGroup, 'getRawValue').and.returnValue({});
      spyOn(connectionsService, 'get').and.returnValue(throwError({ error: { detailedMessage: 'test failed' } }));
      component.openConnection('1');
      tick();
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
      flush();
    }));
  });

  describe('saving changes to connection', () => {
    beforeEach(() => {
      component.activeStepIndex = 0;
      component.isVisible = true;
      component.connectionId = '1';
      component.connectionFormComponent.connectionFormGroup.patchValue({
        connectionDetails: { runtimeServer: 'myServer' }
      });
    });

    describe('when scalable commit feature is enabled', () => {
      beforeEach(() => {
        component.activeStepIndex = 0;
      });

      it('should move back to the connection stage if on catalog', fakeAsync(() => {
        component.activeStepIndex = 1;
        component.primaryButtonClicked();
        tick();
        expect(component.activeStepIndex).toBe(0);
      }));

      it('should reset button style & hide catalog warning message if moving back to connection stage', fakeAsync(() => {
        component.activeStepIndex = 1;
        component.primaryButtonClicked();
        tick();
        expect(component.primaryButton.buttonClassName).toBe('');
        expect(component.cancelButton.text).toEqual('connections.CONNECTION_FORM.BUTTONS.CANCEL');
        expect(component.finishButtonClickCount).toEqual(0);
        expect(component.isStartCatalogButtonClicked).toBe(false);
      }));

      it('should set connection id if creating a new connection', fakeAsync(() => {
        component.connectionId = null;
        component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1, name: 'test' });
        spyOn(connectionsService, 'create').and.returnValue(of({ id: '1' }));
        component.primaryButtonClicked();
        tick();
        expect(component.connectionId).toBe('1');
      }));

      it('should change button style if creating a new connection', fakeAsync(() => {
        component.connectionId = null;
        component.isEditingConnection = false;
        component.connectionFormComponent.connectionFormGroup.patchValue({ id: null, name: 'test' });
        spyOn(connectionsService, 'create').and.returnValue(of({ id: '1' }));
        component.primaryButtonClicked();
        tick();
        expect(component.primaryButton.buttonClassName).toEqual('btn-page-secondary');
        expect(component.cancelButton.text).toEqual('connections.CONNECTION_FORM.BUTTONS.FINISH');
        expect(component.cancelButton.buttonClassName).toEqual('btn-page-primary');
      }));

      it('should move to catalog step on wizard', fakeAsync(() => {
        component.connectionId = null;
        component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1, name: 'test' });
        spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
          accessFromServer: { name: 'myServer' },
          connectionType: 'DB2ZOS',
          username: 'test',
          password: 'pwd'
        });
        spyOn(connectionsService, 'update').and.returnValue(of({}));
        component.primaryButtonClicked();
        tick();
        expect(component.activeStepIndex).toBe(0);
      }));

      it('should encrypt Oracle pluggable connection container password', fakeAsync(() => {
        spyOn(component.connectionFormComponent.connectionFormGroup, 'reset').and.returnValue();
        component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1, name: 'test' });
        spyOn(component.connectionFormComponent.connectionFormGroup, 'getRawValue').and.returnValue({});
        spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
          accessFromServer: { name: 'myServer' },
          connectionType: 'ORACLE',
          parameters: [{ key: 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD', value: 'pwd' }]
        });
        spyOn(connectionsService, 'update').and.returnValue(of({ success: true }));
        spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
        component.primaryButtonClicked();
        tick();
        expect(metadataApiService.getPublicKey).toHaveBeenCalled();
        expect(component.activeStepIndex).toBe(1);
      }));

      it('should close the sidebar if editting a connection', fakeAsync(() => {
        spyOn(component.connectionFormComponent.connectionFormGroup, 'reset').and.returnValue();
        spyOn(component.connectionFormComponent.connectionFormGroup, 'getRawValue').and.returnValue({});
        spyOn(connectionsService, 'update').and.returnValue(of({ id: '1' }));
        spyOn(component.connectionSavedEvent, 'emit').and.returnValue();
        spyOn(component, 'cancelConnectionButtonClicked').and.returnValue();
        component.isEditingConnection = true;
        component.primaryButtonClicked();
        expect(component.connectionSavedEvent.emit).toHaveBeenCalled();
        expect(component.cancelConnectionButtonClicked).toHaveBeenCalled();
      }));
    });

    it('should reset connection id when creating a new connection', fakeAsync(() => {
      component.connectionId = null;
      component.connectionFormComponent.connectionFormGroup.patchValue({ id: null, name: 'test' });
      spyOn(connectionsService, 'create').and.returnValue(of({ id: '1' }));
      component.primaryButtonClicked();
      tick();
      expect(connectionsService.create).toHaveBeenCalled();
    }));

    it('should keep credentials for DB2ZOS connection types and return successfully', fakeAsync(() => {
      spyOn(component.connectionFormComponent.connectionFormGroup, 'reset').and.returnValue();
      component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1, name: 'test' });
      spyOn(component.connectionFormComponent.connectionFormGroup, 'getRawValue').and.returnValue({});
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
        accessFromServer: { name: 'myServer' },
        connectionType: 'DB2ZOS',
        username: 'test',
        password: 'pwd'
      });
      spyOn(connectionsService, 'update').and.returnValue(of({ success: true }));
      spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
      component.primaryButtonClicked();
      tick();
      expect(component.isVisible).toBe(true);
      expect(component.connectionFormComponent.connectionFormGroup.reset).toHaveBeenCalled;
    }));

    it('should not encrypt an empty password for DB2ZOS', fakeAsync(() => {
      spyOn(component.connectionFormComponent.connectionFormGroup, 'reset').and.returnValue();
      component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1, name: 'test' });
      spyOn(component.connectionFormComponent.connectionFormGroup, 'getRawValue').and.returnValue({});
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
        accessFromServer: { name: 'myServer' },
        connectionType: 'DB2ZOS',
        username: 'test',
        password: ''
      });
      spyOn(connectionsService, 'update').and.returnValue(of({ success: true }));
      spyOn(metadataApiService, 'getPublicKey');
      component.primaryButtonClicked();
      tick();
      expect(metadataApiService.getPublicKey).not.toHaveBeenCalled();
    }));

    it('should encrypt Oracle pluggable connection container password', fakeAsync(() => {
      spyOn(component.connectionFormComponent.connectionFormGroup, 'reset').and.returnValue();
      component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1, name: 'test' });
      spyOn(component.connectionFormComponent.connectionFormGroup, 'getRawValue').and.returnValue({});
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
        accessFromServer: { name: 'myServer' },
        connectionType: 'ORACLE',
        parameters: [{ key: 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD', value: 'pwd' }]
      });
      spyOn(connectionsService, 'update').and.returnValue(of({ success: true }));
      spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
      component.primaryButtonClicked();
      tick();
      expect(component.isVisible).toBe(true);
      expect(metadataApiService.getPublicKey).toHaveBeenCalled();
      expect(component.connectionFormComponent.connectionFormGroup.reset).toBeTruthy(true);
    }));

    it('should clear credentials and return successfully', fakeAsync(() => {
      spyOn(component.connectionFormComponent.connectionFormGroup, 'reset').and.returnValue();
      component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1, name: 'test' });
      spyOn(component.connectionFormComponent.connectionFormGroup, 'getRawValue').and.returnValue({});
      spyOn(connectionsService, 'update').and.returnValue(of({ success: true }));
      spyOn(component.connectionSavedEvent, 'emit');
      component.primaryButtonClicked();
      expect(component.connectionSavedEvent.emit).toHaveBeenCalled();
      expect(component.isVisible).toBe(true);
      expect(component.connectionFormComponent.connectionFormGroup.reset).toBeTruthy(true);
    }));
  });

  describe('test button', () => {
    it('should be enabled if test credentials have been entered', fakeAsync(() => {
      component.isVisible = true;
      const changesObj: SimpleChanges = { isVisible: new SimpleChange(false, true, false) };
      component.ngOnChanges(changesObj);
      component.connectionFormComponent.connectionFormGroup.patchValue({ testUser: 'test', testPassword: 'pwd' });
      tick();
      fixture.whenStable().then(() => {
        expect(component.secondaryButton.isDisabled).toBe(true);
        flush();
      });
    }));

    it('should be enabled if test credentials do not exist', fakeAsync(() => {
      component.connectionFormComponent.connectionFormGroup.removeControl('connectionDetails');
      component.isVisible = true;
      const changesObj: SimpleChanges = { isVisible: new SimpleChange(false, true, false) };
      component.ngOnChanges(changesObj);
      component.connectionFormComponent.connectionFormGroup.patchValue({ id: 1 });
      tick();
      fixture.whenStable().then(() => {
        expect(component.secondaryButton.isDisabled).toBe(false);
        component.connectionFormComponent.connectionFormGroup.addControl(
          '',
          new FormGroup({
            testUser: new FormControl(''),
            testPassword: new FormControl('')
          })
        );
        flush();
      });
    }));
  });

  describe('adding a new a connection', () => {
    it('should return successfully', fakeAsync(() => {
      spyOn(component.connectionFormComponent.connectionFormGroup, 'reset').and.returnValue();
      spyOn(connectionsService, 'create').and.returnValue(of({ success: true }));
      spyOn(component.connectionSavedEvent, 'emit');
      component.connectionFormComponent.connectionFormGroup.get('id').setValue(null);
      component.primaryButtonClicked();
      fixture.whenStable().then(() => {
        expect(component.connectionSavedEvent.emit).toHaveBeenCalled();
        expect(component.connectionFormComponent.connectionFormGroup.reset).toBeTruthy(true);
      });
    }));

    it('should be able to handle errors', fakeAsync(() => {
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      spyOn(connectionsService, 'update').and.returnValue(throwError({ error: { detailedMessage: 'test failed' } }));
      spyOn(metadataApiService, 'getPublicKey').and.returnValue(throwError({ error: '{"detailedMessage": "test failed" }' }));
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
        accessFromServer: { name: 'myServer' },
        connectionType: 'DB2ZOS',
        username: 'test',
        password: 'pwd',
        id: null
      });
      fixture.whenStable().then(() => {
        component.primaryButtonClicked();
        tick();
        expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
      });
    }));

    it('should add a connection', () => {
      component.openConnection(null);
      expect(component.isEditingConnection).toBeFalse();
      expect(component.connectionId).toBe('');
    });

    it('should handle manage catalog error', () => {
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      component.handleManageCatalogError({ error: { detailedMessage: 'test failed' } });
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
    });
  });

  describe('testing a connection', () => {
    it('should return successfully', fakeAsync(() => {
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      spyOn(connectionsService, 'verify').and.returnValue(of({ success: true }));
      spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
      component.secondaryButtonClicked();
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
    }));

    it('should be able to handle errors', fakeAsync(() => {
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      spyOn(connectionsService, 'verify').and.returnValue(throwError({ error: { detailedMessage: 'test failed' } }));
      spyOn(metadataApiService, 'getPublicKey').and.returnValue(throwError({ error: '{"detailedMessage": "test failed" }' }));
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
        accessFromServer: { name: 'myServer' },
        connectionType: 'DBI',
        username: 'test',
        password: 'pwd',
        parameters: []
      });
      fixture.whenStable().then(() => {
        component.secondaryButtonClicked();
        tick();
        expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
      });
    }));

    it('should encrypt Oracle pluggable connection container password', fakeAsync(() => {
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({
        accessFromServer: { name: 'myServer' },
        connectionType: 'ORACLE',
        parameters: [{ key: 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD', value: 'pwd' }]
      });
      spyOn(connectionsService, 'verify').and.returnValue(of({ success: true }));
      spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
      spyOn(component.connectionFormComponent, 'updateTestValues');
      component.secondaryButtonClicked();
      tick();
      expect(component.connectionFormComponent.updateTestValues).toHaveBeenCalled();
    }));
  });

  describe('when schema registry feature is enabled', () => {
    beforeEach(() => {
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
    });

    it('should be enabled if schema registry URL is valid', fakeAsync(() => {
      component.isVisible = true;
      spyOn(component.connectionFormComponent, 'getConnection').and.returnValue({ name: 'SR', connectionType: 'SCHEMAREGISTRY' });
      const changesObj: SimpleChanges = { isVisible: new SimpleChange(false, true, false) };
      component.ngOnChanges(changesObj);
      component.connectionFormComponent.connectionFormGroup.patchValue({
        id: 1,
        connectionDetails: { schemaRegistryUrl: 'validUrl' }
      });
      tick();
      fixture.whenStable().then(() => {
        expect(component.secondaryButton.isDisabled).toBe(true);
        flush();
      });
    }));
  });
});
