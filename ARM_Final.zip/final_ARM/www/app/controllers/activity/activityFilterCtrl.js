﻿(function () {
    'use strict';

    angular.module('arm').controller('activityFilterCtrl',
                    ['$scope', activityFilterCtrl]);

    function activityFilterCtrl($scope) {

    };

})();