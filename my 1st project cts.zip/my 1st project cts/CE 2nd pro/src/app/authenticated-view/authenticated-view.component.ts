import { Component, OnInit } from '@angular/core';
import { UtilityService } from '../services/utility.service';

@Component({
  selector: 'app-authenticated-view',
  templateUrl: './authenticated-view.component.html',
  styleUrls: ['./authenticated-view.component.scss']
})
export class AuthenticatedViewComponent implements OnInit {


  couponList:any = [];
  //manufactureCpn: any = [];
  serviceUrls:Object;
  activeState:String = 'alldeals';
  subscriber:any;
  isGetCustomerRespRcvd:Boolean = false;

  constructor(public utilityService: UtilityService) { }

  ngOnInit() {
    this.getServiceUrls();
    console.log('Authenticated View');
  }

  ngOnDestroy() {
    this.subscriber.unsubscribe();
  }

  getServiceUrls(){
    this.subscriber = this.utilityService.serviceUrlsObservable$.subscribe((data) => {
      if(!this.utilityService.isEmpty(data) && !data.hasOwnProperty('error')){
        this.serviceUrls = data['config']['serviceUrls'];
        if(this.serviceUrls){              
            this.getCustomerProfile();
        }
      }else if(data.hasOwnProperty('error')){

      }
    });
  }

  getCustomerProfile(){
    let payload = {
    };

    let header = {
      // Access-Control-Allow-Origin: *
    };
    this.utilityService.sendRequest(this.serviceUrls['getCustomerProfile'],payload, header).subscribe((response)=>{
        if(response.hasOwnProperty('cusInfResp') && response['cusInfResp'].hasOwnProperty('xtraCard') && response['cusInfResp'].hasOwnProperty('cpns') && !this.utilityService.isEmpty(response['cusInfResp']['cpns'])){ 
            this.couponList = response['cusInfResp'];
            this.isGetCustomerRespRcvd = true;
        }else{
          console.log('error');
        }
      },
      error =>{
        console.log(error);
      });
  }

  changeRightView(activeState){
    this.activeState = activeState;
  }

}
