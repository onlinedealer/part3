import { TreeTableModel } from './tree-table.model';

export class TreePath {
  tableView: boolean;
  columnView: boolean;
  modelView: boolean;
  profileName: string;
  sequenceNumber: string;
  modelName: string;
  tableName: Types;
  columnName: Types;
  treeData: TreeTableModel;
  profileID: string;
  runId: string;

  constructor() {
    this.tableView = false;
    this.columnView = false;
    this.modelView = false;
    this.profileName = '';
    this.sequenceNumber = '';
    this.modelName = '';
    this.tableName = new Types('', '', '');
    this.columnName = new Types('', '', '');
    this.treeData = undefined;
    this.profileID = '';
    this.runId = '';
  }
}

export class Types {
  name: string = '';
  type: string = '';
  displayName: string = '';
  constructor(name: string, type: string, display: string) {
    this.name = name;
    this.type = type;
    this.displayName = '';
  }
}
