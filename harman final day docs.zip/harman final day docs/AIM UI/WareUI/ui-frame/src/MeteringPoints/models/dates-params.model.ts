export interface DatesParams {
    from: number;
    until: number;
    interval?: "day" | "week" | "month" | "year";
}
