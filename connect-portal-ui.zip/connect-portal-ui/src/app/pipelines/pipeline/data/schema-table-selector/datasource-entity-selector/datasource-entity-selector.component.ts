import { Component, Input } from '@angular/core';
import { DatasourceEntitySelectorModel } from './datasource-entity-selector.model';

@Component({
  selector: 'p-connect-datasource-entity-selector',
  templateUrl: './datasource-entity-selector.component.html'
})
export class DatasourceEntitySelectorComponent {
  /**
   *  card configuration to display schema list
   */
  @Input() schemaCardConfiguration: DatasourceEntitySelectorModel;

  /**
   *  card configuration to display table list
   */
  @Input() tableCardConfiguration: DatasourceEntitySelectorModel;

  /**
   *  card configuration to display column list
   */
  @Input() columnCardConfiguration: DatasourceEntitySelectorModel;
}
