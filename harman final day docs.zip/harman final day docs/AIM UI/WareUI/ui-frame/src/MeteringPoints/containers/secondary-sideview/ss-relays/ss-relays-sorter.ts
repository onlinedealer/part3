import { BehaviorSubject, Observable, combineLatest } from "rxjs";
import { DeviceRelayVO } from "../../../models/view-objects/device-relay-vo.model";
import { map } from "rxjs/operators";
import { isNil, isNumber, isString } from "lodash";

export class SSRelaysSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: string }> = new BehaviorSubject({
        active: "relayId",
        direction: "asc"
    });

    public setDeviceRelays(relays$: Observable<DeviceRelayVO[]>) {
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedRelaysData(relays$: Observable<DeviceRelayVO[]>): Observable<DeviceRelayVO[]> {
        return combineLatest([this.sortingSubject.asObservable(), relays$]).pipe(
            map(([sortingValues, relays]) => (sortingValues.direction === "" ? relays : [...relays].sort(this.relaysComparator)))
        );
    }

    public onSortEvent(event: { active: string; direction: string }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    relaysComparator = (relay1: any, relay2: any): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "relayId":
                return this.sortByString(relay1.relayId, relay2.relayId, directionMultiplier);
            case "usage":
                return this.sortByString(relay1.usage, relay2.usage, directionMultiplier);
            case "reversed":
                return this.sortByString((relay1.reversed).toString(), (relay2.reversed).toString(), directionMultiplier);
            case "relayState":
                return this.sortByString(relay1.relayState, relay2.relayState, directionMultiplier);
            case "loadState":
                return this.sortByString(relay1.loadState, relay2.loadState, directionMultiplier);
            case "relayStateTime":
                return this.sortByDate(relay1, relay2, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByString(value1: string | null | undefined, value2: string | null | undefined, directionMultiplier: number) {
        if (value1 === value2 || isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }
        return directionMultiplier;
    }

    sortByNumber(value1: number | undefined, value2: number | undefined, directionMultiplier: number) {
        if (isNumber(value1) && isNumber(value2)) {
            return value1 > value2 ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNumber(value1) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && isNumber(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value1) || isNil(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value2) || isNil(value1)) {
            return -1 * directionMultiplier;
        }
        return 0;
    }

    sortByDate(r1: DeviceRelayVO, r2: DeviceRelayVO, directionMultiplier: number) {
        if (isNumber(r1.relayStateTime) && isNumber(r2.relayStateTime)) {
            return r1.relayStateTime > r2.relayStateTime ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(r1.relayStateTime) && isNil(r2.relayStateTime)) {
            return this.sortByString(r1.relayId, r2.relayId, 1);
        }

        if (isNil(r1.relayStateTime)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.relayStateTime)) {
            return directionMultiplier;
        }
        return 0;
    }
}
