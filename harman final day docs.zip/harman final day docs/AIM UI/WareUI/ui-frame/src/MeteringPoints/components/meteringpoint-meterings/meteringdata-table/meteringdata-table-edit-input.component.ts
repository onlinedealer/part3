import { Component, Input, OnInit } from "@angular/core";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { Store } from "@ngrx/store";
import { debounceTime, distinctUntilChanged } from "rxjs/operators";
import { State } from "../../../../app/store/reducers";

import { ValueType, EditProfileDataService } from "../../../services";
import { ProfileDataActions } from "../../../store/actions";

@Component({
    selector: "landisgyr-metering-data-table-edit-input",
    templateUrl: "./meteringdata-table-edit-input.component.html",
    styleUrls: ["./meteringdata-table-edit-input.component.scss"]
})
export class MeteringDataTableEditInputComponent implements OnInit {
    @Input() index!: number;
    @Input() valueSelected!: boolean;
    @Input() valueType!: ValueType;
    @Input() rowIndex!: number;
    @Input() value!: number;
    @Input() selectedMeteringId!: number;
    @Input() discontinuity!: boolean;
    @Input() valueManuallyEdited!: boolean;
    @Input() valueAutoEdited!: boolean;
    @Input() valueHigh!: boolean;
    @Input() valueLow!: boolean;
    @Input() set disabled(disabled: boolean) {
        this.disableInput = disabled;
        if (this.editForm && disabled) {
            this.editForm.controls["editValue"].disable({ emitEvent: false });
        } else if (this.editForm && !disabled) {
            this.editForm.controls["editValue"].enable({ emitEvent: false });
        }
    }

    editForm!: FormGroup;
    disableInput!: boolean;

    constructor(private store: Store<State>, private editProfileDataService: EditProfileDataService, private fb: FormBuilder) {}

    ngOnInit(): void {
        this.editForm = this.fb.group({
            editValue: [{ value: this.value, disabled: this.disableInput }, Validators.required]
        });

        this.editForm.controls["editValue"].valueChanges.pipe(debounceTime(400), distinctUntilChanged()).subscribe((value) => {
            this.store.dispatch(
                ProfileDataActions.EditValues({
                    change: [{ value: +value, index: this.index }],
                    valueType: this.valueType
                })
            );
        });
    }

    select(event: any, selected: boolean, index: number, valueType: ValueType) {
        if (!this.disableInput) {
            event.preventDefault();
            this.store.dispatch(
                ProfileDataActions.SelectValue({
                    selectedMeteringId: this.selectedMeteringId,
                    index: index,
                    selected: selected,
                    valueType: valueType
                })
            );
        }
    }

    tooltipText() {
        return this.editProfileDataService.getTooltipText(
            this.discontinuity,
            this.valueHigh,
            this.valueLow,
            this.valueManuallyEdited,
            this.valueAutoEdited
        );
    }
}
