import { Spies } from 'discovery-test';
import { TrendsTableComponent } from './trends-table.component';

describe('TrendsTableComponent', () => {
  let component: TrendsTableComponent;

  beforeEach(() => {
    component = new TrendsTableComponent(Spies.TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should have table columns defined on ngOnInit', () => {
    component.stat = 'Complete';
    component.ngOnInit();
    expect(component.cols.length).toBe(2);
  });
});
