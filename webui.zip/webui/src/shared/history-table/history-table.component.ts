import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { SharedConstants } from '../shared.constant';
import { HistoryDataModel } from './history-data-model';
import { HistoryTableSettingModel } from './history-table-setting.model';

@Component({
  selector: 'discovery-history-table',
  templateUrl: './history-table.component.html',
  styleUrls: ['./history-table.component.css']
})
export class HistoryTableComponent implements OnInit {
  @Output() historyRunId: EventEmitter<string> = new EventEmitter<string>();
  _historyDetails = new HistoryTableSettingModel();
  scrollCount = 0;
  historyData: HistoryDataModel[] = [];
  get historyDetails(): HistoryTableSettingModel {
    return this._historyDetails;
  }

  @Input()
  set historyDetails(val: HistoryTableSettingModel) {
    this._historyDetails = val;
  }

  ngOnInit(): void {
    if (this.historyDetails?.tableData?.length) {
      this.loadData();
    }
  }
  //passing the id so that parent can navigte to relevent route
  navigateHistoryWithParam(id: string): void {
    this.historyRunId.emit(id);
  }

  loadData(): void {
    const tableData: HistoryDataModel[] = [];
    this.historyData = [...this.historyDetails.tableData];
  }
}
