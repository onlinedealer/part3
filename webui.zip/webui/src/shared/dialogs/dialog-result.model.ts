// eslint-disable-next-line no-shadow
export enum DialogResult {
  Yes = 'yes',
  No = 'no',
  Cancel = 'cancel'
}
