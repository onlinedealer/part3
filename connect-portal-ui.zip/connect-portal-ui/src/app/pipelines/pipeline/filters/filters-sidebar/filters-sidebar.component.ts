import { AfterViewInit, Component, EventEmitter, Input, OnDestroy, Output, ViewChild } from '@angular/core';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { Subscription } from 'rxjs';
import { BaseComponent } from '../../../../core/base.component';
import { SidebarButton } from '../../../../shared/components/sidebar/sidebar-button';
import { PipelineService } from '../../pipeline.service';
import { SelectedTables } from '../../shared/pipeline';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { FiltersFormComponent } from '../filters-form/filters-form.component';
import { Filter } from '../filter';

@Component({
  selector: 'p-connect-filters-sidebar',
  templateUrl: './filters-sidebar.component.html'
})
export class FiltersSidebarComponent extends BaseComponent implements AfterViewInit, OnDestroy {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * Reference to the filterFormComponent child component
   */
  @ViewChild(FiltersFormComponent) filterFormComponent: FiltersFormComponent;

  /**
   * Set to true to display the sidebar component
   */
  @Input() isVisible: boolean;

  /**
   * Event that is triggered when the sidebar visible state changes internally
   */
  @Output() isVisibleChanged = new EventEmitter<boolean>();

  /**
   * List of schemas and tables for use in the filter
   */
  @Input() schemasAndTables: SelectedTables[] = [];

  primaryButton: SidebarButton = {
    id: 'filterAddButton',
    isDisabled: true,
    text: 'filters.BUTTONS.ADD'
  };

  cancelButton: SidebarButton = {
    id: 'cancelButton',
    text: 'filters.BUTTONS.CANCEL'
  };

  private formValueChangesSubscription: Subscription;
  originalFilter: Filter = null;

  cancelFilterButtonClicked() {
    this.resetSidebar();
  }

  constructor(private readonly pipelineEntityService: PipelineEntityService, private readonly pipelineService: PipelineService) {
    super();
  }

  ngOnDestroy(): void {
    this.formValueChangesSubscription.unsubscribe();
  }

  ngAfterViewInit(): void {
    this.formValueChangesSubscription = this.filterFormComponent.filterFormGroup.valueChanges.subscribe(() =>
      this.updateButtonDisabledState()
    );
  }

  isEditing() {
    return this.originalFilter !== null;
  }

  addFilter() {
    if (!this.isEditing()) {
      this.sidebarComponent.isProcessingRequest = true;
      this.pipelineEntityService.addFilter(this.filterFormComponent.filterFormGroup.value);
      this.pipelineService
        .savePipeline()
        .then(() => {
          this.resetSidebar();
        })
        .catch((apiResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', apiResponse);
          // Remove the most recently added filter as it can no longer be considered
          // associated with the pipeline.
          this.pipelineEntityService.removeLatestFilter();
        })
        .finally(() => {
          this.sidebarComponent.isProcessingRequest = false;
        });
    } else {
      this.editFilter();
    }
  }

  editFilter() {
    this.sidebarComponent.isProcessingRequest = true;
    this.pipelineEntityService.editFilter(this.originalFilter, this.filterFormComponent.filterFormGroup.value);
    this.pipelineService
      .savePipeline()
      .then(() => {
        this.resetSidebar();
      })
      .catch((apiResponse) => {
        this.sidebarComponent.parseHttpClientResponseMessage('error', apiResponse);
        // restore the original filter since there was an error saving the edited one
        this.pipelineEntityService.editFilter(this.filterFormComponent.filterFormGroup.value, this.originalFilter);
      })
      .finally(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  setFilter(selectedFilter: Filter): void {
    this.originalFilter = selectedFilter;
    this.filterFormComponent.filterFormGroup.patchValue(selectedFilter);
    this.primaryButton.text = 'filters.BUTTONS.SAVE';
  }

  private updateButtonDisabledState(): void {
    this.primaryButton.isDisabled = !this.filterFormComponent.filterFormGroup.valid;
  }

  private resetSidebar(): void {
    this.isVisible = false;
    this.isVisibleChanged.emit(false);
    this.filterFormComponent.filterFormGroup.reset();
    this.primaryButton.text = 'filters.BUTTONS.ADD';
    this.originalFilter = null;
  }
}
