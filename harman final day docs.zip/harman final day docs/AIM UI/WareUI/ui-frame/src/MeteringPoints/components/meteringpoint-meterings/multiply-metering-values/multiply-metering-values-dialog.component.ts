import { Component, Input, ViewChild, ElementRef, EventEmitter, Output, OnInit } from "@angular/core";
import { MatDialog, MatDialogRef } from "@angular/material/dialog";
import { MatButtonToggleChange } from "@angular/material/button-toggle";
import { Store } from "@ngrx/store";

import { State } from "../../../../app/store/reducers";
import { TranslationsService } from "../../../../app/services/translations-service";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { MultiplyMeteringValuesVO } from "../../../models/view-objects/meteringdata-vo.model";
import { ProfileDataActions } from "../../../store/actions";
import { FormBuilder, FormGroup, Validators } from "@angular/forms";
import { debounceTime, distinctUntilChanged } from "rxjs/operators";

@Component({
    selector: "landisgyr-multiply-metering-values-dialog",
    templateUrl: "./multiply-metering-values-dialog.component.html",
    styleUrls: ["./multiply-metering-values-dialog.component.scss"]
})
export class MultiplyMeteringValuesDialogComponent implements OnInit {
    @Input()
    dialogTitle!: string;
    @Input()
    timeSeries!: MultiplyMeteringValuesVO[];
    @Input()
    dataEdited!: boolean;
    @Input()
    dialogValueDigitLength!: any[];

    @Output() editedTimeSeries = new EventEmitter<MultiplyMeteringValuesVO[]>();
    @Output() sortChangeEventToContainer: EventEmitter<SortOrder> = new EventEmitter();
    @ViewChild("applyConstantRef") applyConstant!: ElementRef;

    requestedOperation = "Addition";
    selectedConstant!: string;
    inputError = "";
    constantPopulatedOnce = false;
    constantForm!: FormGroup;

    constructor(
        public dialog: MatDialog,
        public dialogRef: MatDialogRef<MultiplyMeteringValuesDialogComponent>,
        public translations: TranslationsService,
        private store: Store<State>,
        private fb: FormBuilder
    ) {}

    ngOnInit(): void {
        this.constantForm = this.fb.group({
            constant: [{ value: "" }, Validators.required]
        });

        this.constantForm.controls["constant"].valueChanges.pipe(debounceTime(400), distinctUntilChanged()).subscribe((value) => {
            this.constantPopulatedOnce = true;
            this.inputError = this.validateConstant(this.requestedOperation, value !== null ? +value : value);
            this.applyOperation(+value);
        });
    }

    onSortEventToContainer(event: SortOrder) {
        this.sortChangeEventToContainer.emit(event);
    }

    onGroupingSelectionToggleChange(selection: MatButtonToggleChange) {
        this.requestedOperation = selection.value;
        if (this.constantPopulatedOnce) {
            this.selectedConstant = this.applyConstant.nativeElement.value;
            this.inputError = this.validateConstant(this.requestedOperation, this.selectedConstant !== "" ? +this.selectedConstant : null);
            this.applyOperation(this.constantForm.get("constant")?.value);
        }
    }

    applyOperation(selectedConstant: number) {
        if (!this.inputError) {
            this.store.dispatch(
                ProfileDataActions.EditMultiplyDialogData({
                    requestedOperation: this.requestedOperation,
                    selectedConstant: selectedConstant
                })
            );
        } else {
            this.store.dispatch(ProfileDataActions.ClearMultiplyDialogDataOperation());
        }
    }

    validateConstant(operation: string, constant: number | null): string {
        if (constant === null) {
            return $localize`:|@@meteringsList.constantCannotBeEmpty:Constant cannot be empty`;
        }
        if (operation === "Division" && constant === 0) {
            return $localize`:|@@meteringsList.divisionByZroIsNotPossible:Division by zero is not possible`;
        }
        return "";
    }

    onCancel() {
        this.store.dispatch(ProfileDataActions.CancelMultiplyDialogData());
        this.dialogRef.close();
    }

    onApply() {
        this.store.dispatch(ProfileDataActions.ApplyMultiplyDialogData());
        this.dialogRef.close();
    }
}
