import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Connection } from 'src/app/connections/shared/connection';
import { BaseComponent } from 'src/app/core/base.component';
import { Pipeline } from 'src/app/pipelines/pipeline/shared/pipeline';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
@Component({
  selector: 'p-connect-column-mapping-overview',
  templateUrl: './column-mapping-overview.component.html',
  styleUrls: ['column-mapping-overview.component.scss']
})
export class ColumnMappingOverviewComponent extends BaseComponent implements OnInit {
  @Input() rowData: any;
  @Input() sourceDataConnection: Connection;
  @Input() targetDataConnection: Connection;
  @Input() hasCustomColumnMappings: boolean;
  @Input() versionsList: { key: string; value: string }[] = [];
  @Input() pipeline: Pipeline;
  @Input() schemaRegistryAvailable: boolean;
  @Output() versionChange = new EventEmitter<any>();
  selectedVersion: { key: string; value: string };
  sourceConnectionTypeFriendlyName: string;
  targetConnectionTypeFriendlyName: string;
  sourceHeaders: any;
  targetHeaders: any;
  iconClass: string;
  constructor(private readonly mappingService: PipelineMappingService) {
    super();
  }

  ngOnInit(): void {
    this.sourceConnectionTypeFriendlyName = `connections.CONNECTION_TYPES.${this.sourceDataConnection.connectionType}`;
    this.targetConnectionTypeFriendlyName = `connections.CONNECTION_TYPES.${this.targetDataConnection.connectionType}`;
    this.sourceHeaders = this.mappingService.getColumnHeaders(this.sourceDataConnection.connectionType);
    this.targetHeaders = this.mappingService.getColumnHeaders(this.targetDataConnection.connectionType);
  }

  onDropdownChange(event) {
    this.versionChange.emit(event);
  }

  open() {
    if (this.versionsList?.length) {
      this.selectedVersion = this.versionsList[0];
    }
  }
}
