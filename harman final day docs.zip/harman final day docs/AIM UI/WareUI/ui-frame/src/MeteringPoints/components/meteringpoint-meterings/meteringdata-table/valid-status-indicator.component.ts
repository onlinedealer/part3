import { Component, Input, OnChanges, ChangeDetectionStrategy, SimpleChanges, Type } from "@angular/core";
import { StatusIndicator } from "../../../models/view-objects/summarytable-vo.model";
import { TranslationsService } from "../../../../app/services/translations-service";

const binaryZeroArray = "00000000".split("").map((binaryZero) => +binaryZero);

@Component({
    selector: "landisgyr-valid-status-indicator",
    templateUrl: "./valid-status-indicator.component.html",
    styleUrls: ["./valid-status-indicator.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ValidStatusIndicatorComponent implements OnChanges {
    @Input() meteringStatus!: number | undefined;
    @Input() meteringValidatedStatus!: number;
    @Input() meteringDeliveryStatus!: number | undefined;
    @Input() useSmallLayout!: boolean;
    @Input() noValidColumn!: boolean;
    showCheckIcon = false;
    defaultStatusArray: StatusIndicator[] = [
        {
            name: "T",
            status: "",
            statusName: $localize`:|@@statusIndicator.timeAdjusted:T: Time adjusted`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "E",
            status: "",
            statusName: $localize`:|@@statusIndicator.errorDuringMeasuring:E: Error during measuring`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "P",
            status: "",
            statusName: $localize`:|@@statusIndicator.powerFailure:P: Power failure`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "R",
            status: "",
            statusName: $localize`:|@@statusIndicator.illegalValueRequest:R: Illegal value request`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "X",
            status: "",
            statusName: $localize`:|@@statusIndicator.errorLoadingExternalDevice:X: Error while reading an external device`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "≈",
            status: "",
            statusName: $localize`:|@@statusIndicator.estimatedValue:≈: Estimated value`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "M",
            status: "",
            statusName: $localize`:|@@statusIndicator.manuallyModified:M: Manually modified`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "I",
            status: "",
            statusName: $localize`:|@@statusIndicator.calculatedIncompleteData:I: Calculated with incomplete data`,
            className: "status-box",
            showToolTip: false
        },
        {
            name: "",
            status: "",
            statusName: $localize`:|@@statusIndicator.presenceValidatedStatus:Presence of validated status`,
            className: "icon-container",
            showToolTip: false
        }
    ];

    statusArray: StatusIndicator[] = [...this.defaultStatusArray];

    constructor(private translations: TranslationsService) {}

    ngOnChanges(changes: SimpleChanges) {
        this.showCheckIcon = this.meteringValidatedStatus >= 0;
        this.meteringStatus = this.meteringStatus ? this.meteringStatus : undefined;
        if (changes.meteringValidatedStatus && changes.meteringValidatedStatus.currentValue) {
            this.meteringValidatedStatus = changes.meteringValidatedStatus.currentValue;
        }
        if (changes.meteringStatus || changes.meteringValidatedStatus) {
            this.statusArray = this.getStatusIndicatorStyle(this.meteringStatus, this.meteringValidatedStatus);
        }
    }

    getStatusIndicatorStyle(status: number | undefined, validatedStatus: number | undefined): StatusIndicator[] {
        const statusBinaryArray = this.binaryConversion(status);
        const validatedStatusBinaryArray = this.binaryConversion(validatedStatus);
        const statusArray = this.defaultStatusArray.map((statusItem) => {
            return {
                ...statusItem
            };
        });
        for (let i = 0; i < 8; i++) {
            if (statusBinaryArray[i] === 0 && validatedStatusBinaryArray[i] === 0) {
                continue;
            }
            if (statusBinaryArray[i] === 1 && validatedStatusBinaryArray[i] === 0) {
                statusArray[i].className = "status-box original-status";
                statusArray[i].status = $localize`:|@@validStatusIndicator.originalStatus:Original status`;
            } else if (statusBinaryArray[i] === 0 && validatedStatusBinaryArray[i] === 1) {
                statusArray[i].className = "status-box validated-status";
                statusArray[i].status = $localize`:|@@validStatusIndicator.validatedStatus:Validated status`;
            } else if (statusBinaryArray[i] === 1 && validatedStatusBinaryArray[i] === 1) {
                statusArray[i].className = "status-box original-validated-status";
                statusArray[i].status = $localize`:|@@validStatusIndicator.originalAndvalidatedStatus:Original & validated status`;
            }
        }
        return statusArray;
    }

    binaryConversion(decimalValue: number | undefined): number[] {
        if (decimalValue === undefined) {
            return binaryZeroArray;
        }

        const binaryArray = parseInt(decimalValue.toString(), 10).toString(2).split("");
        if (binaryArray.length < 8) {
            const loop = 8 - binaryArray.length;
            for (let i = 0; i < loop; i++) {
                binaryArray.unshift("0");
            }
        }
        return binaryArray.map((binary) => +binary);
    }

    trackByFn(index: number, item: StatusIndicator) {
        return index;
    }
}
