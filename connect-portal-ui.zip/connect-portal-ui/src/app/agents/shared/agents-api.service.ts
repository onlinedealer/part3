import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BaseAgentApiService } from '../../core/base-agent-api.service';
import { Agent } from './agent';

@Injectable({
  providedIn: 'root'
})
export class AgentsApiService extends BaseAgentApiService<Agent> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient, 'product/connect');
  }
}
