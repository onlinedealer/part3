import React from 'react'
import { shallow } from 'enzyme'
import DashboardTable, { DashboardTable as DashboardTableComponent } from '../DashboardTable'

describe('DashboardTable component', () => {
  let wrapper, wrapperBlock
  let grouperList = [{'group_id': 3, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534305000, 'department': {'department_id': 242, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962400000, 'status': 'InActive'},
    {'group_id': 5, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534306000, 'department': {'department_id': 244, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962800000, 'status': 'Active'}]
  let props = {
    classes: {},
    data: grouperList,
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }
  it('renders', () => {
    wrapper = shallow(
      <DashboardTable {...props} />)
    expect(wrapper).toHaveLength(1)
  })

  it('invoking handleRequestSort ', () => {
    wrapperBlock = shallow(
      <DashboardTableComponent {...props} />)
    wrapperBlock.instance().handleRequestSort('group_id')
    expect(wrapperBlock.instance().state.orderBy).toEqual('group_id')
    wrapperBlock.instance().handleRequestSort('group_id')
    expect(wrapperBlock.instance().state.order).toEqual('asc')
  })

  it('invoking handleChangeRowsPerPage ', () => {
    wrapperBlock = shallow(
      <DashboardTableComponent {...props} />)
    wrapperBlock.instance().handleChangeRowsPerPage({ target: { value: 5 } })
    expect(wrapperBlock.instance().state.rowsPerPage).toEqual(5)
  })
  it('invoking handleChangePage ', () => {
    wrapperBlock = shallow(
      <DashboardTableComponent {...props} />)
    wrapperBlock.instance().handleChangePage({}, 2)
    expect(wrapperBlock.instance().state.page).toEqual(2)
  })
})
