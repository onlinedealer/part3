﻿import { YesnoComponent } from './yesno.component';

describe('YesnoComponent', () => {
  let component: YesnoComponent;

  beforeEach(() => {
    component = new YesnoComponent({} as any);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
