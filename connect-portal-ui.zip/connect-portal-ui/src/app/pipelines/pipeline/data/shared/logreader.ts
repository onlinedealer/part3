export class LogReader {
  type?: string;
  dataConnectionId?: string;
  journalName?: string;
  logReaderId?: string;
  name?: string;
  parameters?: { key: string; value: string }[];
}
