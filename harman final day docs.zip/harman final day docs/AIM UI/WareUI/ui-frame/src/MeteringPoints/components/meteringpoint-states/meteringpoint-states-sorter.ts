import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber, isArray, isString } from "lodash";
import { MeteringPointState } from "../../models/meteringpointstates.model";

export class MeteringPointStatesSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: string }> = new BehaviorSubject({
        active: "",
        direction: ""
    });

    meteringPointStates: MeteringPointState[] = [];

    public setMeteringPointStates(meteringPointStates: MeteringPointState[]) {
        if (isArray(meteringPointStates)) {
            this.meteringPointStates = meteringPointStates;
        }
    }

    public getSortedMeteringPointStates(): Observable<MeteringPointState[]> {
        return this.sortingSubject
            .asObservable()
            .pipe(map(sortingValues => [...this.meteringPointStates].sort(this.sortedMeteringPointStateComparator)));
    }

    public onSortEvent(event: { active: string; direction: string }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    sortedMeteringPointStateComparator = (state1: MeteringPointState, state2: MeteringPointState): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "startTime":
                return this.sortByNumber(state1.startTime, state2.startTime, directionMultiplier);
            case "endtime":
                return this.sortByNumber(state1.endTime, state2.endTime, directionMultiplier);
            case "duration":
                return this.sortByNumber(state1.duration, state2.duration, directionMultiplier);
            case "numberOfComments":
                return this.sortByNumber(state1.comments.length, state2.comments.length, directionMultiplier);
            case "state":
                return this.sortByString(state1.typeName, state2.typeName, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByString(value1: string, value2: string, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }

        return directionMultiplier;
    }

    sortByNumber(value1: number | undefined, value2: number | undefined, directionMultiplier: number) {
        if (isNumber(value1) && isNumber(value2)) {
            return value1 > value2 ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNumber(value1) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && isNumber(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value1) || isNil(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value2) || isNil(value1)) {
            return -1 * directionMultiplier;
        }

        return 0;
    }
}
