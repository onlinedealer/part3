import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { ConnectionsStatesModel } from '../connections.state.model';
import { ConnectionOptionModel } from '../connection-option.model';
import { ConnectionModel } from '../connection.model';
import { ValidationMessageTypeModel } from '../../form-validation-message/validation-message-type.model';
import { ValidationMessage } from '../../form-validation-message/validation-message.model';
import { SharedConstants } from '../../shared.constant';
import { ConnectionService } from '../connection.service';

@Component({
  selector: 'discovery-connection-configure',
  templateUrl: './connection-configure.component.html',
  styleUrls: ['./connection-configure.component.css']
})
export class ConnectionConfigureComponent implements OnInit {
  /**
   *
   */
  @Output() showConnectionSidebarChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() refresh: EventEmitter<string> = new EventEmitter<string>();

  connectionConfigureType = SharedConstants.connectionConfigureType;

  /**
   * List of connection states
   */
  AppStateName: typeof ConnectionsStatesModel = ConnectionsStatesModel;

  /**
   * Connection details
   */
  connectionModel: ConnectionModel;

  /**
   * List of validation types
   */
  ValidationMessageType: typeof ValidationMessageTypeModel = ValidationMessageTypeModel;

  /**
   * list of failure messages
   */
  failureMessages: ValidationMessage[] = [];

  /**
   * list of failure message for connection load
   */
  loadFailureMessages: ValidationMessage[] = [];

  /**
   * list of success messages
   */
  successMessages: ValidationMessage[] = [];

  /**
   *
   */
  testInProgress: boolean;
  isAccountIncorrect: boolean;

  /**
   * flag for checking save in progress
   */
  saveInProgress: boolean;
  /**
   * flag for checking load in progress
   */
  isLoading = false;

  /**
   * flag for checking form is valid
   */

  get formValid(): boolean {
    return this._formValid;
  }

  set formValid(val: boolean) {
    this._formValid = val;
  }

  get viewType(): string {
    return this._viewType;
  }

  @Input()
  set viewType(val: string) {
    this._viewType = val;
    this.loadData();
  }

  get connectionId(): string {
    return this._connectionId;
  }

  @Input()
  set connectionId(val: string) {
    this._connectionId = val;
    this.loadData();
  }

  get showConnectionSidebar(): boolean {
    return this._showConnectionSidebar;
  }

  @Input()
  set showConnectionSidebar(val: boolean) {
    this._showConnectionSidebar = val;
    this.resetForm = !val;
    this.loadData();
  }

  get connectionType(): string {
    return this._connectionType;
  }

  @Input()
  set connectionType(val: string) {
    this._connectionType = val;
  }

  get invalidName(): boolean {
    return this._invalidName;
  }

  set invalidName(val: boolean) {
    this._invalidName = val;
  }

  get buttonClickType(): string {
    return this._buttonClickType;
  }

  set buttonClickType(val: string) {
    this._buttonClickType = val;
  }

  get resetForm(): boolean {
    return this._resetForm;
  }

  set resetForm(val: boolean) {
    this._resetForm = val;
  }

  private _formValid: boolean;

  /**
   * create, edit or copy mode
   */
  private _viewType: string;

  /**
   * connection ID for edit or copy mode
   */
  private _connectionId: string;

  /**
   * toggle for sidebar visibility
   */
  private _showConnectionSidebar: boolean;

  private _resetForm: boolean;

  /**
   * connection type string
   */

  private _connectionType: string;

  private _invalidName: boolean;

  private _buttonClickType: string;
  /**
   *
   * @param translocoService
   */
  constructor(private connectionService: ConnectionService, private translocoService: TranslocoService) {
    this.connectionModel = new ConnectionModel();
  }

  /**
   *
   */
  ngOnInit(): void {
    this.validateForm(false);
  }

  validateForm(val: boolean): void {
    this.formValid = val;
  }

  loadData() {
    this.clearMessages();
    if (
      this.viewType === SharedConstants.connectionConfigureModes.EDIT ||
      this.viewType === SharedConstants.connectionConfigureModes.COPY
    ) {
      this.loadConnectionById(this.connectionId);
    }
  }

  /**
   *
   */
  saveConnection(): void {
    this.failureMessages = [];
    this.saveInProgress = true;
    this.connectionService
      .saveConnection(this.connectionModel, this.viewType !== SharedConstants.connectionConfigureModes.EDIT)
      .subscribe(
        (response: any) => {
          this.saveInProgress = false;
          if (this.viewType === SharedConstants.connectionConfigureModes.ADD) {
            this.refresh.emit(response.id);
          } else {
            this.refresh.emit('');
          }
          this.cancelCreate();
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.saveInProgress = false;
          if (httpErrorResponse.status !== 403) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryShared.configureConnection.saveConnectionFailed', {
                  serverMessage:
                    httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                      ? httpErrorResponse.error.message
                      : ''
                })
              )
            ];
          }
        }
      );
  }

  /**
   *
   */
  testConnection(): void {
    this.failureMessages = [];
    this.successMessages = [];
    this.isLoading = true;
    this.testInProgress = true;
    this.connectionService.testConnectionByObject(this.connectionModel).subscribe(
      (response) => {
        this.isLoading = false;
        this.testInProgress = false;
        this.successMessages = [
          new ValidationMessage(this.translocoService.translate('discoveryShared.configureConnection.testSuccessful'))
        ];
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.isLoading = false;
        this.testInProgress = false;
        this.isAccountIncorrect = false;
        this.failureMessages = [
          new ValidationMessage(
            this.translocoService.translate('discoveryShared.configureConnection.testFailed', {
              serverMessage:
                httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                  ? httpErrorResponse.error.message
                  : ''
            })
          )
        ];
        if (httpErrorResponse.error.message === SharedConstants.connectionConfigureErrorMsg.ACCOUNT) {
          this.isAccountIncorrect = true;
          this.failureMessages.push(
            new ValidationMessage(this.translocoService.translate('discoveryShared.configureConnection.accountError'), {
              showDetailLink:
                'https://docs.snowflake.com/en/user-guide/admin-account-identifier.html#option-2-account-locator-in-a-region'
            })
          );
        }
      }
    );
  }

  /**
   *
   */
  cancelCreate(): void {
    this.validateForm(false);
    this.showConnectionSidebarChange.emit(false);
    this.showConnectionSidebar = false;
  }

  /**
   *
   * @param htmlButtonElement
   */
  submitConnection(htmlButtonElement: HTMLButtonElement) {
    this.buttonClickType = htmlButtonElement.id;
    if (htmlButtonElement.id === 'connection-save') {
      if (this.connectionModel.name && !this.invalidName) {
        this.saveConnection();
      }
    } else if (htmlButtonElement.id === 'connection-test') {
      if (!this.invalidName) {
        this.testConnection();
      }
    }
    return true;
  }

  /**
   *
   * @param connectionId
   */
  loadConnectionById(connectionId: string): void {
    if (connectionId) {
      this.isLoading = true;
      this.connectionService.getConnectionById(connectionId).subscribe({
        next: (connectionModel: ConnectionModel) => {
          this.connectionModel = connectionModel;
          this.isLoading = false;
          if (this.viewType === SharedConstants.connectionConfigureModes.COPY) {
            this.connectionModel.name = this.translocoService.translate('discoveryShared.configureConnection.copyOf', {
              connectionName: this.connectionModel.name
            });
          }
        },
        error: (httpErrorResponse: HttpErrorResponse) => {
          this.isLoading = false;
          if (httpErrorResponse.status === 404) {
            this.loadFailureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryShared.configureConnection.connectionNotFound')
              )
            ];
          } else {
            this.loadFailureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryShared.configureConnection.getConnectionFailed', {
                  serverMessage:
                    httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                      ? httpErrorResponse.error.message
                      : ''
                })
              )
            ];
          }
        }
      });
    }
  }

  /**
   *
   * @param key
   * @param value
   */

  setOption(data: { key: string; value: string }): void {
    if (this.connectionModel.options) {
      for (const option of this.connectionModel.options) {
        if (option.name === data.key) {
          option.value = data.value;
          return;
        }
      }
    }
    this.connectionModel.options.push(new ConnectionOptionModel(data.key, data.value));
  }

  checkConnectionName(val: boolean): void {
    this.invalidName = val;
  }

  closeValidationMessage(data) {
    if (data.message) {
      switch (data.type) {
        case ValidationMessageTypeModel.Error:
          let index = this.failureMessages.indexOf(data.message);
          if (index > -1) {
            this.failureMessages.splice(index, 1);
          } else {
            index = this.loadFailureMessages.indexOf(data.message);
            if (index > -1) {
              this.loadFailureMessages.splice(index, 1);
            }
          }
          this.isAccountIncorrect = false;
          break;
        case ValidationMessageTypeModel.Success:
          this.successMessages = [];
          break;
      }
    }
  }

  private clearMessages() {
    this.checkConnectionName(false);
    this.validateForm(false);
    this.failureMessages = [];
    this.successMessages = [];
    this.loadFailureMessages = [];
  }
}
