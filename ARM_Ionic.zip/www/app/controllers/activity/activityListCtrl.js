﻿(function () {
    'use strict';

    angular.module('arm').controller('activityListCtrl',
                    ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate', 'activityService', 'contactService', 'utility', 'GENERAL_CONFIG', 'MASTER_TABLE', '$filter','homeService','$rootScope', activityListCtrl]);

    function activityListCtrl($scope, $state, $ionicModal, $ionicSideMenuDelegate, activityService, contactService, utility, GENERAL_CONFIG, MASTER_TABLE, $filter,homeService,$rootScope) {
        $scope.objFilter = {
            pro: 3,
            search: '',
            selDate: '',
            selCalDate: ''
        };
        $scope.selectedFilter = {};
        //update the final value as per selected datetime control
        $scope.$watch(function (scope) { return scope.objFilter.selCalDate },
              function (newValue, oldValue) {
                  if (newValue == null || newValue == '') return;
                  loadDateFilter(newValue);
                  //$scope.objFilter.selDate = utility.getDateInDisplayFormat(newValue);
              }
             );

        function init() {
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("deviceready", onDeviceReady, false);
            }
            $scope.pro = 1;
            $scope.actModel = [];
            loadData();
            $scope.actSet = activityService.fieldSetting;
            var curDt = new Date();
            loadDateFilter(curDt);
            getCurrentLoc();
        }
        init();

        function getCurrentLoc() {
            var curAt = '';
            var options = {
                enableHighAccuracy: true,
                timeout: 5000,
                maximumAge: 0
            };
            navigator.geolocation.getCurrentPosition(function (position) {
                curAt = position.coords.latitude + ' ' + position.coords.longitude;
                $scope.currentLoc = curAt;
            }, function () { }, options);
        }

        function loadDateFilter(date) {
            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

            var day = date.getDate();
            var monthIndex = date.getMonth();
            var year = date.getFullYear();
            $scope.filterDate = day + ' ' + monthNames[monthIndex] + ', ' + year;
            //$scope.search = $scope.filterDate;
            var m = ('0' + (monthIndex + 1)).slice(-2);

            $scope.objFilter.selDate = year + '-' + m + '-' + day;

        }

        $scope.nextPreDate = function (type) {
            var dt = new Date($scope.filterDate);
            if (type == 'N') {
                dt.setDate(dt.getDate() + 1);
                loadDateFilter(dt);
            }
            else {
                dt.setDate(dt.getDate() - 1);
                loadDateFilter(dt);
            }
            //$scope.actList = angular.copy(filterDate());
        }

        function filterDate() {
            var dateFilterArr = [];
            var selDt = utility.getDateInServerFormat($scope.objFilter.selDate); //utility.parseDate(from);getDateStringMDYFormat
            var df = new Date(selDt);
            var result = [];
            for (var i = 0; i < retainArr.length; i++) {
                var actDate = utility.getDateInServerFormat(retainArr[i].ActivityDate);
                var tf = new Date(actDate);
                if (tf >= df) {
                    dateFilterArr.push(retainArr[i]);
                }
            }
            return dateFilterArr;
        }

        var retainArr = [];
        function loadData() {
            // Fetch the all DeviceObjIds for login user Id's
            $scope.allDeviceObjIdsByLoginUserID = [];
            contactService.sqlGetAllDeviceObjIds().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.allDeviceObjIdsByLoginUserID.push(result.rows.item(i));
                }
            });
            $scope.actList = [];
            $scope.overDueCount = 0;
            $scope.pro = 1;
            activityService.sqlActGetAll().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.actList.push(result.rows.item(i));
                    $scope.actList[i].Priority = utility.getColorCode(result.rows.item(i)['ActivityDate'], result.rows.item(i)['ActivityTime'], result.rows.item(i)['ActivityStageID']);
                    if ($scope.actList[i].Priority == 1) {
                        $scope.overDueCount++;
                    }
                    $scope.actList[i].Fields = [];
                    $scope.actList[i].Correspondences = [];
                    $scope.actList[i].ActivityAttendees = [];
                    $scope.actList[i].Notes = [];                    
                    loadFields($scope.actList[i]);
                    loadNote(result.rows.item(i)['DeviceObjID'], $scope.actList[i].Notes);
                }

                //console.log($scope.actList);
                retainArr = angular.copy($scope.actList);
                loadFilter();
                $scope.actionFilter();
            });
        }

        function loadNote(actId, objNote) {
            activityService.sqlGetNote(actId).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    objNote.Description = result.rows.item(i)['Description'];
                }
            });
        }

        $scope.getNameValue = function (item) {
            return utility.getNameByOrOwner(item);
        };

        $scope.doRefresh = function (type) {
            //console.log("Refresh for Pull...!!");
            //$scope.$broadcast('scroll.refreshComplete');
            var retType = '';
            var serType = '';
            if (type == 'Next') {
                retType = GENERAL_CONFIG.DataRetrivalType.Next;
                serType = GENERAL_CONFIG.WebServiceType.ActivityListNext;
            }
            else {
                retType = GENERAL_CONFIG.DataRetrivalType.Pevious;
                serType = GENERAL_CONFIG.WebServiceType.ActivityListPrev;
            }
            activityService.refreshData(retType, serType).then(function (result) {
                //syncServerRecords(result, $scope.actList);
                var obj = new Object();
                obj.OverDue = $scope.overDueCount;
                contactService.syncServerContactFromOtherModule(result.Contacts, $scope.allDeviceObjIdsByLoginUserID);
                $scope.allActdevicesByLoginUserID = [];
                activityService.syncServerRecords(result.Activities, $scope.actList, obj, $scope.allActdevicesByLoginUserID);
                retainArr = angular.copy($scope.actList);
                $scope.overDueCount = obj.OverDue;
                retainArr = angular.copy($scope.actList);
            });
            if (type == "Next") {
                $scope.$broadcast('scroll.refreshComplete');
            }
        };

        function syncServerRecords(sourceArry, desArry) {
            contactService.syncServerContactFromOtherModule(sourceArry.Contacts, $scope.allDeviceObjIdsByLoginUserID);
            angular.forEach(sourceArry.Activities, function (obj, key) {
                if (obj.DeviceObjID != null) {
                    var exitingLst = $filter('filter')(desArry, { DeviceObjID: obj.DeviceObjID });
                    if (exitingLst.length == 0) {
                        exitingLst = activityService.activityMod().uiObject;
                        utility.syncModelWithoutInnerCollection(obj, exitingLst);

                        loadChild(obj, exitingLst, 'A');
                        desArry.push(exitingLst);
                        activityService.sqlActAdd(exitingLst, exitingLst.ActivityAttendees, 'S').then(function (result) {

                        });
                    }
                    else {
                        checkOverDue(obj, exitingLst[0], 'U');
                        utility.syncModelWithoutInnerCollection(obj, exitingLst[0]);
                        loadChild(obj, exitingLst[0], 'U');
                        activityService.sqlActUpdate(exitingLst[0], exitingLst[0].ActivityAttendees, 'S').then(function (result) {
                        });
                    }
                }
            });
            retainArr = angular.copy($scope.actList);
            //$scope.$apply();

        }

        function checkOverDue(selLst, tarLst, action) {
            var updatePro = utility.getColorCode(selLst['ActivityDate'], selLst['ActivityTime'], selLst['ActivityStageID']);
            if (updatePro == 1 && action == 'A') {
                $scope.overDueCount++;
            }
            else {
                var existingP = utility.getColorCode(tarLst['ActivityDate'], tarLst['ActivityTime'], tarLst['ActivityStageID']);
                if (existingP == 1) {
                    if (updatePro > 1)
                        $scope.overDueCount--;
                }
                else {
                    if (updatePro == 1) {
                        $scope.overDueCount++;
                    }
                }
            }
        }

        function loadChild(selLst, tarLst, action) {
            if (tarLst.ContactTypeID == 1) {
                tarLst.ContactDisplayName = selLst.ContactName;
                //tarLst.ContactName = tarLst.contactName;
                if (typeof selLst.EmployerName == 'undefined' || selLst.EmployerName == null) {
                    tarLst.CompanyName = '';
                }
                else {
                    tarLst.Companyname = selLst.EmployerName;
                }
            }
            else {
                tarLst.CompanyName = selLst.ContactName;
                if (typeof selLst.RepresentativeName == 'undefined' || selLst.RepresentativeName == null)
                    tarLst.ContactDisplayName = '';
                else {
                    tarLst.ContactDisplayName = selLst.RepresentativeName;

                }
            }
            tarLst.Priority = utility.getColorCode(tarLst['ActivityDate'], tarLst['ActivityTime'], tarLst['ActivityStageID']);
            loadLocation(selLst.Correspondences, tarLst, action);
            loadFields(selLst, tarLst.Fields, action);
            loadAttendees(selLst, tarLst.ActivityAttendees, action);
            loadNotes(selLst, tarLst, action);
            //loadNote(selLst.DeviceObjID, tarLst.Notes);
        }

        function loadLocation(selLst, tarLst, action) {
            if (selLst.length == 0) { return };
            tarLst.Address = selLst[selLst.length - 1].Address;
            tarLst.Correspondences.Address = selLst[selLst.length - 1].Address;
            tarLst.Correspondences.ModuleID = GENERAL_CONFIG.MODULES.Activity;
            tarLst.Correspondences.GoogleLat = selLst[selLst.length - 1].GoogleLat;
            tarLst.Correspondences.GoogleLong = selLst[selLst.length - 1].GoogleLong;
        }

        function loadNotes(selLst, tarLst, action) {
            tarLst.Notes = [];
            if (selLst.Notes.length > 0) {
                tarLst.Notes.Description = selLst.Notes[selLst.Notes.length - 1].Description;
            }
            angular.forEach(selLst.Notes, function (obj, key) {
                var devId = obj.DeviceObjID == null ? utility.generateUUID() : obj.DeviceObjID;
                if (typeof obj.Description != 'undefined') {
                    tarLst.Notes.push({
                        ModuleID: GENERAL_CONFIG.MODULES.Activity,
                        EntityID: selLst.ActivityID,
                        Description: obj.Description,
                        DeviceObjID: devId,
                        NoteID: obj.NoteID,
                        CreatorID: obj.CreatorID,
                        CreatorName: obj.CreatorName,
                        CreatedOn: obj.CreatedOn,
                        ModifiedAt: obj.ModifiedAt,
                        ModifiedBy: obj.ModifiedBy,
                        ModifiedOn: obj.ModifiedOn,
                        CreatedAt: obj.CreatedAt
                    });
                }
            });
        }

        function loadAttendees(selLst, tarLst, action) {
            angular.forEach(selLst.ActivityAttendees, function (obj, key) {
                var devId = obj.DeviceObjID == null ? utility.generateUUID() : obj.DeviceObjID;
                tarLst.push(
                    {
                        EntityAttendeeID: obj.EntityAttendeeID,//obj.ActivityAttendeeID,//didn't get this value right now..hardcoded 0
                        AttendeeID: obj.AttendeeID,
                        UserName: obj.AttendeeName,
                        Type: obj.IsContact == true ? 'CP' : 'UP',
                        ParentDeviceObjType: selLst.DeviceObjID,
                        DeviceObjID: devId,
                        IsContact: obj.IsContact,
                        IsChecked: 1,
                        AttendeeDeviceObjID: obj.AttendeeDeviceObjID
                    });
            });
        }

        function loadFields(sourceArr, desArr, action) {
            var count = 1;
            angular.forEach(sourceArr.Fields, function (obj, key) {
                desArr.push({
                    EntityID: sourceArr.ActivityID,
                    ModuleID: GENERAL_CONFIG.MODULES.Activity,
                    ParentDeviceObjID: sourceArr.DeviceObjID,
                    FieldLabel: '',
                    FieldName: obj.FieldName,
                    FieldValue: obj.FieldValue,
                    FieldID: obj.FieldID,
                    IsConfidential: 0,
                    IsMandatory: 0,
                    IsVisible: 0
                });
                count++;
            });
        }

        function PushData(soureArr, ChildArr) {
            angular.forEach(soureArr, function (obj, key) {

            });
        }

        $scope.selActTypeIndx = -1;

        $scope.filterPro = function (tabchecked) {
            $scope.tabchecked = !$scope.tabchecked;

            if (!$scope.tabchecked) {
                $scope.actList = angular.copy(retainArr);
                var curDt = new Date();
                loadDateFilter(curDt);
                loadFilter();
                $scope.actionFilter();
            }
            else {
                $scope.objFilter.selDate = '';
                $scope.objFilter.search = '';
                $scope.selectedFilter = {};
                $scope.actList = utility.getObjData(retainArr, 'Priority', 1);
                
            }

        }


        $scope.fnclickToggle = function ($index, actStageId) {
            if (actStageId > 1) return;
            $scope.selActTypeIndx = $index;
        };

        $scope.fnswitchToggle = function ($index) {
            $scope.selActTypeIndx = -1;
        };

        $scope.openMenu = function () {
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.activitiesdetail = function (activitiesId) {
            $scope.selActTypeIndx = -1;
            activityService.setActivity(utility.getObjData($scope.actList, 'DeviceObjID', activitiesId))
            $state.go('tab.activityDetail', { activitiesId: activitiesId, screenType: 'List' });
        }

        //$scope.activitiesdetail = function (activitiesId) {
        //    $scope.selActTypeIndx = -1;
        //    activityService.setActivity(utility.getObjData($scope.actList, 'DeviceObjID', activitiesId))
        //    $state.go('tab.activityDetail', { activitiesId: activitiesId, screenType: 'List' });
        //}

        $scope.$on('eventName', function (event, args) {
            init();
        });
        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };

        $scope.openActivityType = function (type, activitiesID, stageId, ConDevId) {
            if (stageId > GENERAL_CONFIG.ActivityStage.Open) {
                return;
            }
            activityService.sqlGetCommnications(ConDevId).then(function (result) {
                var comArr = contactService.getAllComData(result);
                $scope.phone = comArr.mobilePhone;
                $scope.email = comArr.email;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                if (type == 1) {
                    $scope.callNumber(activitiesID, stageId);
                }
                else if (type == 3) {//sms
                    $scope.openSMS(activitiesID, stageId);
                }
                else if (type == 4) {//email
                    $scope.openEmail(activitiesID, stageId);
                }
            });

        }

        // Modal filter
        $scope.finalFilterData = [];
        $scope.FilterOptions = [];
        $scope.filterFlag = false;
        function loadFilter() {

            var retFilterData = utility.getMasterDataByKey(GENERAL_CONFIG.FilterKey.activityFilterData);
            if (typeof retFilterData == 'undefined' || retFilterData == '' || retFilterData == null) {
                $scope.filterFlag = false;
                $scope.FilterOptions = [
                         //{
                         //    Title: "Owner",
                         //    FilterData: [
                         //        { ID: 1, Text: "Owner by me", Checked: true },
                         //        { ID: 2, Text: "Owner by others", Checked: true }
                         //    ]
                         //},
                         {
                             Title: "Tier",
                             FilterData: [
                                 { ID: 1, Text: "Tier 1", Checked: true },
                                 { ID: 2, Text: "Tier 2", Checked: true },
                                 { ID: 3, Text: "Tier 3", Checked: true },
                                 { ID: 4, Text: "Tier 4", Checked: true }
                             ]
                         },
                         {
                             Title: "Status",
                             FilterData: [
                                 { ID: 1, Text: "Overdue", Checked: true },
                                 { ID: 2, Text: "Due", Checked: true },
                                 { ID: 3, Text: "Not Yet Due", Checked: true },
                                 { ID: 4, Text: "Done", Checked: true },
                                 { ID: 5, Text: "Cancel", Checked: true } 
                             ]
                         }                        
                ];
            }
            else {
                $scope.filterFlag = true;
                $scope.FilterOptions = retFilterData;
            }
        }

        $ionicModal.fromTemplateUrl('app/views/activity/activityFilter.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalactfilter = modal;
        });

        $scope.openFilter = function () {
            $scope.modalactfilter.show();
            loadFilter();

            //var retFilterData = utility.getMasterDataByKey('activityFilterData');
            //if (typeof retFilterData == 'undefined' || retFilterData == '') return;
            //$scope.filterOptions = retFilterData;
        };

        $scope.closeFilter = function () {
            $scope.modalactfilter.hide();
        };

        $scope.actionFilter = function () {
            $scope.finalFilterData = [];
            var filterList = [];
            var newList = [];
            var filterTierArr = [];
            var filterStageArr = [];
            var filterPriorityArr = [];
            var filterOwnerArr = [];
            angular.forEach($scope.FilterOptions, function (obj) {                
                angular.forEach(obj.FilterData, function (item) {
                    if (item.Checked) {                        
                        var objFilter = [];
                        if (obj.Title == 'Tier') {                           
                            filterTierArr.push(item.ID);
                        }
                        else if (obj.Title == 'Stages') {
                                                       
                        }
                        else if (obj.Title == 'Status') {
                            switch (item.ID) {
                                case 1:
                                    {
                                        filterPriorityArr.push(item.ID);    //overdue                                                                          
                                    }
                                    break;
                                case 2:
                                    {                                        
                                        filterPriorityArr.push(3); //due                                                                       
                                    }
                                    break;
                                case 3:
                                    {
                                        filterPriorityArr.push(2);//not yet due
                                    }
                                    break;
                                case 4:
                                    {
                                        filterPriorityArr.push(4);//done
                                    }
                                    break;
                                case 5:
                                    {
                                        filterPriorityArr.push(5);//cancel
                                    }
                                    break;
                                default:
                            }
                        }


                    }
                });             
                
            });
           
            var filterFinalData = {};
            if (filterTierArr.length > 0) {
                filterFinalData.ContactTierID = filterTierArr;
            }
            if (filterPriorityArr.length > 0) {
                filterFinalData.Priority = filterPriorityArr;
            }
            //if (filterStageArr.length > 0) {
            //    filterFinalData.ActivityStageID = filterStageArr;
            //}
            $scope.filterFlag = true;          
            $scope.selectedFilter = filterFinalData;
            utility.setMasterData(GENERAL_CONFIG.FilterKey.activityFilterData, $scope.FilterOptions);
            $scope.modalactfilter.hide();

        };

        $scope.selectedAll = true;
        $scope.checkAll = function () {
            $scope.selectedAll = !$scope.selectedAll;
            angular.forEach($scope.FilterOptions, function (obj) {
                angular.forEach(obj.FilterData, function (item) {
                    item.Checked = $scope.selectedAll;
                });
            });
        }
        //////////////////CALL/SMS/EMAIL//////////////////

        function onDeviceReady() {
            // Register the event listener
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("resume", onEndCallKeyDown, false);
            }
        }

        $scope.count = 0;
        $scope.devID = 0;
        $scope.startDt;
        function onEndCallKeyDown() {
            if ($scope.count >= 1) return;
            if ($scope.type != 'Call') return;
            $scope.count++;
            var endDt = new Date();
            checkTime($scope.startDt, endDt);
        }

        function checkTime(startDt, endDt) {
            var dif = endDt.getTime() - startDt.getTime();
            var difDt = dif / 1000;
            var finalDifDate = Math.abs(difDt);
            if (finalDifDate >= 15) {
                $scope.openHappend('D', $scope.devID, $scope.type);
            }
        }

        $scope.searchfooterfocus = function () {
            angular.element(document.querySelector('body')).addClass('footer-tab-hide');
        }
        $scope.searchfooterblurred = function () {
            angular.element(document.querySelector('body')).removeClass('footer-tab-hide');
        }

        $scope.openHappend = function (val, activitiesId, actType) {
            activityService.setActStatus('C');
            activityService.setActivity(utility.getObjData($scope.actList, 'DeviceObjID', activitiesId));
            $state.go('tab.activityHappen', { devObjId: activitiesId, actStatgeType: val, screenType: GENERAL_CONFIG.ScreenType.ActivtyList, actType: actType });
        };

        $scope.openSMS = function (activitiesID, stageId) {
            $scope.count = 0;
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }
            var message = '';//'hello text';
            //console.log("going to send " + message + " to " + number);

            //simple validation for now
            //if (number === '' || message === '') return;

            var msg = {
                phoneNumber: number,
                textMessage: message
            };
            //CONFIGURATION
            var options = {
                replaceLineBreaks: false, // true to replace \n by a new line, false by default
                android: {
                    intent: 'INTENT'  // send SMS with the native android SMS messaging
                    //intent: '' // send SMS without open any other app
                }
            };

            var success = function (res) {
                var s = res;
                $scope.type = 'SMS';
                $scope.openHappend('D', activitiesID, 'SMS');
                //if(s == 'ok')
                //alert('Message sent successfully');
            };

            var error = function (e) { console.log('Message Failed:' + e); };
            sms.send(number, message, options, success, error);
        }

        $scope.openEmail = function (activitiesID, stageId) {
            $scope.count = 0;
            $scope.type = 'EMAIL';
            cordova.plugins.email.open({
                to: $scope.email,
                cc: '',
                bcc: [''],
                subject: 'Greetings',
                body: 'test mail'
            });
            $scope.openHappend('D', activitiesID, 'Email');
        }

        $scope.callNumber = function (activitiesID, stageId) {
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }

            window.plugins.CallNumber.callNumber(function () {
                if (window.cordova && ionic.Platform.isAndroid()) {
                    $scope.startDt = new Date();
                    $scope.type = 'Call';
                    $scope.devID = activitiesID;
                    $scope.count = 0;
                }
                else {
                    $scope.openHappend('D', activitiesID, 'Call');
                }
            }, function () {
                console.log("eroor");
                //error logic goes here
            }, number)
        };
        /////////////////CALL/SMS/EMAIL////////END///////////////////////

        //############### LoggedInAs User  functionality START ##############
        $ionicModal.fromTemplateUrl('app/views/common/loggedInAsUserList.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function (modal) {
            $scope.modalLoginAsUsers = modal;
        });

        $scope.loggedInUsers = [];
        var loggedInUserInfo = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.selfLoggedInID = loggedInUserInfo.UserID;

        $scope.selectedUser = function (index, isSelfUser) {
            utility.selectedLogginAsUser(index, isSelfUser, $scope.modalLoginAsUsers, $scope.loggedInUsers).then(function (res) {
                init();
                if ($rootScope.isAccessingOtherUserProfile) {
                    homeService.syncServerRecords();
                }
            });
        }


        $scope.openLogInUserMenu = function () {
            $scope.loggedInUsers = [];
            utility.loadLoggodInAsUsers($scope.loggedInUsers);
            $scope.modalLoginAsUsers.show();

        };
        $scope.closeLogInMenu = function () {
            $scope.modalLoginAsUsers.hide();
            $scope.loggedInUsers = [];
        };
        //############### LoggedInAs User  functionality END ##############


    };

})();
