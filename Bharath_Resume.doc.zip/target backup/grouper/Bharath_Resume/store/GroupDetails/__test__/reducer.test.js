import reducer, { initialState } from '../reducer'
import { fromJS } from 'immutable'
import {
  GET_GROUP_DETAILS_SUCCESS,
  ADD_TCINS,
  ADD_TCINS_SUCCESS,
  REMOVE_TCINS,
  UPDATE_GROUP_NAME,
  UPDATE_GROUP_NAME_SUCCESS,
  REMOVE_TCINS_SUCCESS,
  CLEAR_GROUP_DETAILS_REQUEST_TYPE,
  SET_ADDITEM_ERROR_TCINS,
  UPDATE_ITEMS_ORDER,
  UPDATE_ITEMS_ORDER_ERROR,
  UPDATE_ITEMS_ORDER_SUCCESS,
} from '../actionType'

describe('GroupDetails reducer', () => {
  it('returns the initial state', () => {
    expect(
      reducer(undefined, {})
    ).toEqual(initialState)
  })

  it('should handle GET_GROUP_DETAILS_SUCCESS', () => {
    const groupDetails = {'group_id': 20, 'group_name': '3.5oz tray', 'group_type': 'variation', 'item_type': 'pet food', 'parent_tcin': 76729541, 'themes': [], 'items': [], 'group_type_id': 1, 'last_updated_dt': 1536649451000, 'department_id': 83, 'department_name': 'PET CARE', 'created_dt': 1536572806000}
    const initial = initialState.toJS()
    initial['requestType'] = 'GROUP_DETAILS'
    initial['groupDetails'] = groupDetails
    initial['addItemErrorTcins'] = []
    expect(reducer(fromJS(initialState), {
      type: GET_GROUP_DETAILS_SUCCESS,
      data: groupDetails,
    })).toEqual(fromJS(initial))
  })

  it('should handle ADD_TCINS', () => {
    const initial = initialState.toJS()
    initial['requestType'] = ''
    initial['addItemErrorTcins'] = []
    expect(reducer(fromJS(initialState), {
      type: ADD_TCINS,
    })).toEqual(fromJS(initial))
  })

  it('should handle ADD_TCINS_SUCCESS', () => {
    const initial = initialState.toJS()
    initial['requestType'] = 'ADDED_TCINS'
    initial['addItemErrorTcins'] = []
    expect(reducer(fromJS(initialState), {
      type: ADD_TCINS_SUCCESS,
    })).toEqual(fromJS(initial))
  })

  it('should handle REMOVE_TCINS', () => {
    const initial = initialState.toJS()
    initial['requestType'] = ''
    initial['addItemErrorTcins'] = []
    expect(reducer(fromJS(initialState), {
      type: REMOVE_TCINS,
    })).toEqual(fromJS(initial))
  })

  it('should handle REMOVE_TCINS_SUCCESS', () => {
    const initial = initialState.toJS()
    expect(reducer(fromJS(initialState), {
      type: REMOVE_TCINS_SUCCESS,
    })).toEqual(fromJS(initial))
  })

  it('should handle UPDATE_GROUP_NAME', () => {
    const initial = initialState.toJS()
    initial['requestType'] = ''
    initial['addItemErrorTcins'] = []
    expect(reducer(fromJS(initialState), {
      type: UPDATE_GROUP_NAME,
    })).toEqual(fromJS(initial))
  })

  it('should handle UPDATE_GROUP_NAME_SUCCESS', () => {
    const initial = initialState.toJS()
    initial['requestType'] = 'GROUP_NAME_UPDATED'
    initial['addItemErrorTcins'] = []
    expect(reducer(fromJS(initialState), {
      type: UPDATE_GROUP_NAME_SUCCESS,
    })).toEqual(fromJS(initial))
  })

  it('should handle UPDATE_ITEMS_ORDER', () => {
    const initial = initialState.toJS()
    initial['requestType'] = ''
    expect(reducer(fromJS(initialState), {
      type: UPDATE_ITEMS_ORDER,
    })).toEqual(fromJS(initial))
  })

  it('should handle UPDATE_ITEMS_ORDER_SUCCESS', () => {
    const initial = initialState.toJS()
    initial['requestType'] = 'ORDER_UPDATED'
    expect(reducer(fromJS(initialState), {
      type: UPDATE_ITEMS_ORDER_SUCCESS,
    })).toEqual(fromJS(initial))
  })

  it('should handle UPDATE_ITEMS_ORDER_ERROR', () => {
    const initial = initialState.toJS()
    initial['requestType'] = ''
    expect(reducer(fromJS(initialState), {
      type: UPDATE_ITEMS_ORDER_ERROR,
    })).toEqual(fromJS(initial))
  })

  it('should handle CLEAR_GROUP_DETAILS_REQUEST_TYPE', () => {
    const initial = initialState.toJS()
    initial['requestType'] = ''
    initial['addItemErrorTcins'] = []
    expect(reducer(fromJS(initialState), {
      type: CLEAR_GROUP_DETAILS_REQUEST_TYPE,
    })).toEqual(fromJS(initial))
  })

  it('should handle SET_ADDITEM_ERROR_TCINS', () => {
    const errorTcins = [1234, 5678]
    const initial = initialState.toJS()
    initial['addItemErrorTcins'] = errorTcins
    expect(reducer(fromJS(initialState), {
      type: SET_ADDITEM_ERROR_TCINS,
      errorTcins: errorTcins,
    })).toEqual(fromJS(initial))
  })
})
