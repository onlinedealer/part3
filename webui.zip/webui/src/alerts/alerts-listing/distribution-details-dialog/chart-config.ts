import { AlertMetricModel } from 'alerts/alert-metric.model';
import { AlertModel } from 'alerts/alert.model';
import { TrendsMetricModel } from 'alerts/alertcounts.model';
import { Helper, SharedConstants } from 'discovery-shared';
import { AlertConstants } from '../alert-constants';
import { showByPercentageCalculation } from '../alerts-chart-config';

export interface IChart {
  datasets: Array<any>;
  labels: Array<Date>;
}

const allowedMultiLineMetricType = [AlertConstants.METRIC_TYPE.CARDINALITY_DETAIL];
const allowedMetricTypes = [AlertConstants.METRIC_TYPE.MAXIMUM_VALUE, AlertConstants.METRIC_TYPE.MINIMUM_VALUE];
const CRITICAL = AlertConstants.CRITICAL;

export function yAxisLabelCb(
  label,
  metricType: string,
  dateOnYaxis: boolean,
  alert: AlertModel,
  isShowPercentage: boolean
) {
  // columnType is optional parameter which would usually be available in Data Drift rule config
  if (allowedMetricTypes.includes(metricType) && dateOnYaxis) {
    const formatDate = Helper.getConvertedDateOnToolTip(label);
    return formatDate.date + '/' + formatDate.shortMonth + '/' + formatDate.year;
  } else if (alert?.columnType === AlertConstants.COLUMN_TYPE.TIME) {
    return new Date(label * 1000).toISOString().slice(11, 19);
  } else if (metricType == AlertConstants.METRIC_TYPE.CARDINALITY_DETAIL && isShowPercentage) {
    return label <= 100 ? label + '%' : '';
  } else {
    return label;
  }
}

export function tooltipText(tooltipItems, metric: AlertMetricModel, alert: AlertModel, isShowPercentage: boolean) {
  const metricName = metric.metricName;
  if (
    allowedMetricTypes.includes(metric.metricType) &&
    (alert.columnType === AlertConstants.COLUMN_TYPE.DATE ||
      alert.columnType === AlertConstants.COLUMN_TYPE.DATETIME ||
      alert.columnType === AlertConstants.COLUMN_TYPE.TIMESTAMP)
  ) {
    const convertedDate = Helper.getConvertedDateOnToolTip(tooltipItems[0].parsed.y);
    switch (alert?.columnType) {
      case AlertConstants.COLUMN_TYPE.DATE:
        return `${metricName}: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}`;
      case AlertConstants.COLUMN_TYPE.DATETIME:
      case AlertConstants.COLUMN_TYPE.TIMESTAMP:
        return `${metricName}: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}, ${convertedDate.hour}:${convertedDate.min}:${convertedDate.sec}`;
    }
  } else if (alert?.columnType === AlertConstants.COLUMN_TYPE.TIME) {
    let value = parseInt(tooltipItems[0].formattedValue);
    let time = new Date(value * 1000).toISOString().slice(11, 19);
    return `${metricName}: ${time}`;
  } else if (allowedMultiLineMetricType.includes(metric.metricType)) {
    if (
      tooltipItems[0].dataset &&
      tooltipItems[0].dataset.label &&
      tooltipItems[0].dataset.label.length &&
      isShowPercentage
    ) {
      return `Value: ${tooltipItems[0].dataset.label}\n${metricName}: ${tooltipItems[0].formattedValue}%`;
    } else if (tooltipItems[0].dataset && tooltipItems[0].dataset.label && tooltipItems[0].dataset.label.length) {
      return `Value: ${tooltipItems[0].dataset.label}\n${metricName}: ${tooltipItems[0].formattedValue}`;
    } else {
      return `${metricName}: ${tooltipItems[0].formattedValue}`;
    }
  } else {
    return `${metricName}: ${tooltipItems[0].formattedValue}`;
  }
}

export function getChartConfig(
  xAxisLabel: string,
  yAxisLabel: string,
  metric: AlertMetricModel,
  alert: AlertModel,
  isShowPercentage: boolean
) {
  let dateOnYaxis: boolean = false;

  if (alert.columnType) {
    if (
      alert.columnType === AlertConstants.COLUMN_TYPE.DATE ||
      alert.columnType === AlertConstants.COLUMN_TYPE.DATETIME ||
      alert.columnType === AlertConstants.COLUMN_TYPE.TIMESTAMP
    ) {
      dateOnYaxis = true;
    } else {
      dateOnYaxis = false;
    }
  }
  return {
    plugins: {
      tooltip: {
        callbacks: {
          title: (tooltipItems) => tooltipText(tooltipItems, metric, alert, isShowPercentage),
          label: () => {
            return '';
          },
          footer: dateFormate
        }
      },
      legend: {
        display: true,
        position: 'right',
        align: 'start',
        // color: AlertConstants.MULTILINE_COLORS,
        labels: {
          boxWidth: 15,
          boxHeight: 15,
          filter: (item) => {
            if (item.text?.length > 0) {
              return true;
            }
          }
        },
        onClick: (_event: any) => {
          // hide line functionality disabled
        }
      }
    },
    scales: {
      x: {
        title: {
          display: true,
          align: 'end',
          text: xAxisLabel
        },
        ticks: {
          callback: function (val) {
            let formatDate = Helper.getConvertedDateOnToolTip(this.getLabelForValue(val));
            return formatDate.date + ' ' + formatDate.shortMonth + ' ' + formatDate.year;
          },
          source: 'auto',
          color: SharedConstants.CHARTFONTSCOLORS.TICKS,
          display: true,
          minRotation: 90
        },
        grid: {
          display: false,
          drawOnChartArea: false,
          drawTicks: false,
          color: SharedConstants.CHARTFONTSCOLORS.GRID
        }
      },
      y: {
        title: {
          display: true,
          align: 'end',
          text: yAxisLabel // metric // Distribution of value count
        },
        ticks: {
          color: SharedConstants.CHARTFONTSCOLORS.TICKS,
          display: true,
          // stepSize: 1,
          callback: (label) => yAxisLabelCb(label, metric.metricType, dateOnYaxis, alert, isShowPercentage)
        },
        grid: {
          drawTicks: false,
          color: '#f2f2f2'
        }
      }
    }
  };
}

export function dateFormate(tooltipItems) {
  const convertedDate = Helper.getConvertedDateOnToolTip(tooltipItems[0].label);
  return `Date: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}, ${convertedDate.hour}:${convertedDate.min}:${convertedDate.sec}`;
}

export function populateChartValues(values: any[], point: any, metricType: string) {
  // based on valuePoint and metric type push the chart value to values array
  // in case of cardinality detail value point will be type of map
  if (allowedMultiLineMetricType.includes(metricType) && point && point.size > 0) {
    let data = [];
    for (const [key, value] of point) {
      let checkAllNull = value.every((element) => element === null);
      if (!checkAllNull) {
        data.push({ label: key, value: value });
      }
    }
    values = data;
  } else {
    values.push(point);
  }

  return values;
}

export function getTrendsValue(
  element: TrendsMetricModel,
  metricType: string,
  alertColumnType: string,
  sampleKeyArray?: string[],
  finalValues?
) {
  if (
    allowedMetricTypes.includes(metricType) &&
    (alertColumnType === AlertConstants.COLUMN_TYPE.DATE ||
      alertColumnType === AlertConstants.COLUMN_TYPE.DATETIME ||
      alertColumnType === AlertConstants.COLUMN_TYPE.TIMESTAMP)
  ) {
    return new Date(element.value);
  } else if (alertColumnType === AlertConstants.COLUMN_TYPE.TIME) {
    let timeArray = element.value.toString().split(':');
    return +timeArray[0] * 60 * 60 + +timeArray[1] * 60 + +timeArray[2];
  } else if (allowedMultiLineMetricType.includes(metricType) && element.details && element.details.length > 0) {
    for (const item of element.details) {
      if (sampleKeyArray.includes(item.key)) {
        let index = sampleKeyArray.indexOf(item.key);
        finalValues.set(item.key, [...finalValues.get(item.key), item.value]);
        sampleKeyArray.splice(index, 1);
      }
    }
    sampleKeyArray.forEach((ele) => {
      finalValues.set(ele, [...finalValues.get(ele), null]);
    });
    return finalValues;
  } else {
    return element.value;
  }
}

export function setGraphData(
  metric: AlertMetricModel,
  criticality: string,
  labels: any,
  data: any,
  raiseOnDate: Date,
  percentageToggle: boolean,
  percentageData: any
) {
  let dataSets = [];
  let criticalColor =
    CRITICAL === criticality ? AlertConstants.HIGHLIGHT_COLOR.CRITICAL : AlertConstants.HIGHLIGHT_COLOR.WARNING;
  if (allowedMultiLineMetricType.includes(metric.metricType) && !percentageToggle) {
    dataSets = plotLargeCardinalityDetailChart(data, labels, raiseOnDate, criticalColor, false);
  } else if (allowedMultiLineMetricType.includes(metric.metricType) && percentageToggle) {
    let chartData = showByPercentageCalculation(percentageData, metric, percentageToggle);
    dataSets = plotLargeCardinalityDetailChart(
      chartData.values,
      chartData.lables,
      chartData.raisedOnDate,
      criticalColor,
      false
    );
  } else {
    dataSets = [
      {
        label: '',
        data: data,
        barThickness: 20,
        maxBarThickness: 20,
        borderColor: '#AC72F9',
        backgroundColor: '#AC72F9',
        segment: {
          borderColor: (ctx) => highlightLineSegment(ctx, labels, raiseOnDate, criticality)
        },
        pointStyle: (ctx) => highlightPointStyling(ctx, labels, raiseOnDate, 'rect', 'circle'),
        pointRadius: (ctx) => highlightPointStyling(ctx, labels, raiseOnDate, 6, 3),
        pointBackgroundColor: (ctx) => highlightPointStyling(ctx, labels, raiseOnDate, criticalColor, '#AC72F9'),
        pointBorderColor: (ctx) => highlightPointStyling(ctx, labels, raiseOnDate, criticalColor, '#AC72F9'),
        lineTension: 0
      }
    ];
  }

  return {
    labels: labels,
    datasets: dataSets
  };
}

/**
 * This function is to get an array of values for cardinality details chart
 * @param data
 * @param labels
 * @param raiseOnDate
 * @param criticalColor
 * @param isNew
 * @returns array of values for multiline chart when metric type is cardinality details
 */

export function plotLargeCardinalityDetailChart(data, labels, raiseOnDate, criticalColor, isNew) {
  let plotData = [];
  for (const point of data) {
    plotData.push({
      label: point?.label,
      data: point?.value,
      barThickness: 20,
      maxBarThickness: 20,
      borderColor: undefined,
      backgroundColor: undefined,
      segment: {
        borderColor: (ctx) => highlightLineSegment(ctx, labels, raiseOnDate, criticalColor, isNew)
      },
      pointStyle: (ctx) => highlightPointStyling(ctx, labels, raiseOnDate, 'rect', 'circle', isNew),
      pointRadius: (ctx) => highlightPointStyling(ctx, labels, raiseOnDate, 6, 3, isNew),
      pointBackgroundColor: (color) => {
        return (ctx) => {
          return highlightPointStyling(ctx, labels, raiseOnDate, criticalColor, color, isNew);
        };
      },
      pointBorderColor: (color) => {
        return (ctx) => {
          let highlightIndex = getHighlightedIndex(labels, raiseOnDate);
          if (!point?.isNew && (ctx.dataIndex === highlightIndex || ctx.dataIndex === highlightIndex - 1)) {
            return criticalColor;
          } else {
            return color;
          }
        };
      },
      spanGaps: true,
      lineTension: 0
    });
  }
  return plotData;
}

export function highlightLineSegment(ctx, xAxisLabel: Date[], raiseOnDate: Date, criticalColor, isNew?: boolean) {
  let highlightIndex = getHighlightedIndex(xAxisLabel, raiseOnDate);
  if ((ctx.p1DataIndex === highlightIndex || ctx.p0DataIndex === highlightIndex - 1) && !isNew) {
    return criticalColor;
  } else {
    return undefined;
  }
}

export function highlightPointStyling(
  ctx,
  xAxisLabel: Date[],
  raiseOnDate: Date,
  successValue,
  failureValue,
  isNew: boolean = false
) {
  let highlightIndex = getHighlightedIndex(xAxisLabel, raiseOnDate);
  if (!isNew && (ctx.dataIndex === highlightIndex || ctx.dataIndex === highlightIndex - 1)) {
    return successValue;
  } else {
    return failureValue;
  }
}

export function getHighlightedIndex(xAxisLabel: Date[], raiseOnDate: Date) {
  raiseOnDate.setSeconds(0, 0);
  return xAxisLabel.findIndex((item) => {
    let tempDate = new Date(item);
    tempDate.setSeconds(0, 0);
    if (tempDate.getTime() >= raiseOnDate.getTime()) {
      return item;
    }
  });
}

export function getFormattedDate(date: Date) {
  if (new Date(date).toLocaleString() === 'Invalid Date') {
    return 'Invalid Date';
  }

  return date.getFullYear() + '-' + ('0' + (date.getMonth() + 1)).slice(-2) + '-' + ('0' + date.getDate()).slice(-2);
}
