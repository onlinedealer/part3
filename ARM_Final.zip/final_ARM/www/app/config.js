(function () {
    /*
    $rootScope.token — > web service  token

    rootScope.isAccessingOtherUserProfile — > to implement stuff like allow only online mode --> set on Login = false and tap on switching the user = true again on signout from other user = false

    $rootScope.loggedInUserID —> to keep track of logged in user id. it is used to differentiate the data in sqlite table. set on login and on every switch user click and also on other user sign out action.

    $rootScope.loadNewMasterDataForLoggedInAsUser ---> if it sets to true in signin controller then app will load new master data for switched user else it will use the same logged in user master data.

    $rootScope.lastLoggedInUserState --> To track user switch to new user from which screen/state.--> Set this value on other user selection and use it on other user sign out.
    */
    'use strict';

    var config_module = angular.module('arm.config', []);

    var config_data = {
        'GENERAL_CONFIG': {
            'APP_NAME': 'Sales ARM',
            'APP_VERSION': '1.0.0',
            'DEFAULT_UUID': '',
            'Name': 'salesArm.db',
            'BUILD_ENVIRONMENT': 'SERVER',
            'ServerDateTimes': 'ServerDateTimes',
            'OldUser': 'OldUser',
            'AppFirstTimeLaunch': 'ApplicationFirstTimeLaunch',
            'MODULES': {
                "ALL": 1,
                "Product": 2,
                "Contact": 3,
                "Activity": 4,
                "Deal": 5,
                "User": 6,
                "Dashboard": 7
            },
            'MoreMenuOptions' :
            {
                "Dashboard": 0,
                "Products": 1,
                "Messages": 6,
                "DBRCalculator": 2,
                "SMEBankingCalculator": 3,
                "Logout": 5,
                "HelpMePlan": 11,
                "Note": 7,
                "AdvSearch": 8,
                "Notification": 9,
                "Settings": 10,
                "Sync": 4,
                "Help": 12,
                "ResetAllData": 13,
            },
            'ServerStatusCode':{
                "Success" : 2,
                "Failure" : 0,
                "Unauthorized" : 401
            },
            'ServerStatus':{
                "Success" : 'Success',
                "Failure" : 'Failure'
            },
            'ScreenType': {
                "ActivityDetail": 1,
                "ActivtyList": 2,
                "ContactList": 3,
                "ContactDetail": 4,
                "HomeContact": 5,
                "HomeActivity": 6,
                "ContactDetailActivity": 7
            },
            'WebServiceType': {
              "Login": 1,
              "Master": 2,
              "HomeList": 3,
              "ContactListNext": 4,
              "ContactListPrev": 5,
              "ActivityListNext": 6,
              "ActivityListPrev": 7,
              "DealListNext": 8,
              "DealListPrev": 9,
              "NoteListNext": 10,
              "NoteListPrev": 11,
              "ProductListNext": 12,
              "ProductListPrev": 13,
              "UserListNext": 14,
              "UserListPrev": 15
            },
            'DataRetrivalType':
            {
              "Chunk": 0,
              "All": 1,
              "Pevious": 1,
              "Next": 2
            },
            'AccessCategory': {
                "Owner": 1,
                "FullAccess": 2,
                "RestrictedAccess": 3,
                "NoAccess": 4
            },
            'UsersCategory': {
                "ActivityOwnershipUsers": 1,
                "ContactOwnershipUsers": 2,
                "ContactSharingUsers": 3,
                "DealOwnershipUsers": 4,
                "InternalMessagingUsers": 5,
                "LoggedInAsUsers": 6,
                "OtherAttendeeUsers": 7,
                "ParallelAccessUsers": 8
            },
            'ActivityStage': {
                "Open" : 1,
                "Done" : 2,
                "Cancel" : 3
            },
            'DealStageModel': {
                "Close" : 4,
                "Lost" : 5
            },
            'FilterKey': {
                "activityFilterData": 'actFilter',
                "dealFilterData": 'dealFilter'
            },
            'TableNames':
            [
              'Users',
              'Contacts',
              'Communications',
              'Correspondences',
              'UsersAccessMapping',
              'Activity',
              'Deals',
              'ProductFamily',
              'Products',
              'DealDocumentMapping',
              'Participients',
              'ContactRelationships',
              'Attachments',
              'Notes',
              'DynamicFields',
              'MsgConversations',
              'Messages'
            ],
            'Tables': [
              {
                  name: 'Users',
                  columns: [
                      { name: 'UserID', type: 'integer' },
                      { name: 'OrganisationID', type: 'integer' },
                      { name: 'UserName', type: 'text' },
                      { name: 'ManagerID', type: 'integer' },
                      { name: 'SalutationID', type: 'integer' },
                      { name: 'SalutationName', type: 'text' },
                      { name: 'FirstName', type: 'text' },
                      { name: 'LastName', type: 'text' },
                      { name: 'MiddleName', type: 'text' },
                      { name: 'FullName', type: 'text' },
                      { name: 'DOB', type: 'datetime' },
                      { name: 'DesignationID', type: 'integer' },
                      { name: 'UnitID', type: 'integer' },
                      { name: 'AllowedContactType', type: 'integer' },
                      { name: 'PreferredLanguageID', type: 'integer' },
                      { name: 'PasswordHash', type: 'text' },
                      { name: 'IsActive', type: 'text' },
                      { name: 'Islocked', type: 'text' },
                      { name: 'UserType', type: 'integer' },
                      { name: 'AccessCategoryID', type: 'integer' },
                      { name: 'LoggedInUserID', type: 'integer'}
                  ]
              },
              {
                  name: 'Contacts',
                  columns: [
                      { name: 'DeviceObjID', type: 'text' },
                      { name: 'ContactID', type: 'integer' },
                      { name: 'SyncStatus', type: 'integer' },
                      { name: 'ContactTypeID', type: 'integer' },
                      { name: 'ModuleID', type: 'integer' },
                      { name: 'OrganisationID', type: 'integer' },//userOrgid
                      { name: 'SalutationID', type: 'integer' },
                      { name: 'ContactSegmentID', type: 'integer' },
                      { name: 'ContactSegmentName', type: 'text' },
                      { name: 'ContactTierID', type: 'integer' },
                      { name: 'ContactTierName', type: 'text' },
                      { name: 'OwnerID', type: 'integer' },
                      { name: 'OwnerName', type: 'text' },
                      { name: 'FirstName', type: 'text' },
                      { name: 'MiddleName', type: 'text' },
                      { name: 'LastName', type: 'text' },
                      { name: 'CompanyName', type: 'text' },
                      { name: 'CustomerID', type: 'text' },
                      { name: 'BalanceA', type: 'text' },
                      { name: 'BalanceB', type: 'text' },
                      { name: 'ProfileImageID', type: 'integer' },
                      { name: 'JobTitle', type: 'text' },
                      { name: 'LastContactedDate', type: 'text' },
                      { name: 'NextContactedDate', type: 'text' },
                      { name: 'IsRepresentative', type: 'bit' },
                      { name: 'IsClient', type: 'bit' },
                      { name: 'CompanyWebsite', type: 'text' },
                      { name: 'IsConfidential', type: 'bit' },
                      { name: 'ServerDateTime', type: 'text' },
                      { name: 'IsDeleted', type: 'bit' },
                      { name: 'CreatorID', type: 'integer' }, //created usedId
                      { name: 'CreatedOn', type: 'datetime' },//current date
                      { name: 'CreatedAt', type: 'text' },//location
                      { name: 'ModifiedBy', type: 'integer' },
                      { name: 'ModifiedOn', type: 'text' },
                      { name: 'ModifiedAt', type: 'text' },
                      { name: 'CreatorName', type: 'text' },
                      { name: 'EmployerName', type: 'text' },
                      { name: 'EmployerID', type: 'integer' },
                      { name: 'EmployerDeviceObjID', type: 'text' },
                      { name: 'IsEmployer', type: 'bit' },
                      { name: 'LoggedInUserID', type: 'integer'}
                  ]
              },
              {
                  name: 'Communications',
                  columns: [
                      { name: 'DeviceObjID', type: 'text' },
                      { name: 'ParentDeviceObjID', type: 'text' },
                      { name: 'CommunicationID', type: 'integer' },
                      { name: 'ModuleID', type: 'integer' },
                      { name: 'EntityID', type: 'integer' },
                      { name: 'CommunicationTypeID', type: 'integer' },
                      { name: 'CommunicationCategoryID', type: 'integer' },
                      { name: 'CommunicationData', type: 'text' },
                      { name: 'IsDefault', type: 'bit' },
                      { name: 'CreatedOn', type: 'datetime' },
                      { name: 'CreatorID', type: 'integer' },
                      { name: 'CreatedAt', type: 'text' },
                      { name: 'IsMandatory', type: 'bit' },
                      { name: 'LoggedInUserID', type: 'integer'}
                  ]
              },
              {
                  name: 'Correspondences',
                  columns: [
                      { name: 'DeviceObjID', type: 'text' },
                      { name: 'ParentDeviceObjID', type: 'text' },
                      { name: 'CorresspondenceID', type: 'integer' },
                      { name: 'CorrespondenceTypeID', type: 'integer' },
                      { name: 'ModuleID', type: 'integer' },
                      { name: 'EntityID', type: 'integer' },
                      { name: 'IsDefault', type: 'bit' },
                      { name: 'IsMandatory', type: 'bit' },
                      { name: 'Address', type: 'text' },
                      { name: 'CityName', type: 'text' },
                      { name: 'CountryName', type: 'text' },
                      { name: 'StateName', type: 'text' },
                      { name: 'Zip', type: 'text' },
                      { name: 'GoogleLat', type: 'text' },
                      { name: 'GoogleLong', type: 'text' },
                      { name: 'CreatedOn', type: 'datetime' },
                      { name: 'CreatorID', type: 'integer' },
                      { name: 'CreatedAt', type: 'text' },
                      { name: 'LoggedInUserID', type: 'integer'}
                  ]
              },
              {
                name: 'UsersAccessMapping',
                    columns: [
                        { name: 'DeviceObjID', type: 'text' },
                        { name: 'ContactID', type: 'integer' },
                        { name: 'ParentDeviceObjID', type: 'text' },
                        { name: 'UserID', type: 'integer' },
                        { name: 'OrganisationID', type: 'integer' },
                        { name: 'UserName', type: 'text' },
                        { name: 'ManagerID', type: 'integer' },
                        { name: 'SalutationID', type: 'integer' },
                        { name: 'FirstName', type: 'text' },
                        { name: 'LastName', type: 'text' },
                        { name: 'MiddleName', type: 'text' },
                        { name: 'FullName', type: 'text' },
                        { name: 'DOB', type: 'datetime' },
                        { name: 'DesignationID', type: 'integer' },
                        { name: 'UnitID', type: 'integer' },
                        { name: 'AllowedContactTypes', type: 'text' },
                        { name: 'PerfferedLanguageID', type: 'integer' },
                        { name: 'PasswordHash', type: 'text' },
                        { name: 'IsActive', type: 'text' },
                        { name: 'Islocked', type: 'text' },
                        { name: 'ServerDateTime', type: 'text' },
                        { name: 'UserType', type: 'integer' },
                        { name: 'AccessCategoryID', type: 'integer' },
                        { name: 'LoggedInUserID', type: 'integer'}
                    ]
              },
                  {
                      name: 'Activity',
                      columns: [
                        { name: 'DeviceObjID', type: 'text' },
                        { name: 'ActivityID', type: 'integer' },
                        { name: 'ModuleID', type: 'integer' },
                        { name: 'ContactID', type: 'integer' },//act id
                        { name: 'ContactDeviceObjID', type: 'text' },
                        { name: 'ContactName', type: 'text' },//activity name
                        { name: 'ActivitySubject', type: 'text' },
                        { name: 'ActivityDate', type: 'text' },
                        { name: 'ActivityDateForSort', type: 'datetime' },
                        { name: 'ActivityTime', type: 'text' },
                        { name: 'ActivityDuration', type: 'text' },
                        { name: 'ActivityRemainderInterval', type: 'integer' },
                        { name: 'IsActivityEvent', type: 'bit' },
                        { name: 'OwnerID', type: 'integer' },
                        { name: 'OwnerName', type: 'text' },
                        { name: 'ContactSegmentID', type: 'integer' },
                        { name: 'ContactSegmentName', type: 'text' },
                        { name: 'ContactTierID', type: 'integer' },
                        { name: 'ContactTierName', type: 'text' },
                        { name: 'CompanyName', type: 'text' },//org name
                        { name: 'ActivityStageID', type: 'integer' },
                        { name: 'RepresentativeID', type: 'integer' },
                        { name: 'ActivityTypeID', type: 'integer' },
                        { name: 'ActivityType', type: 'text' },
                        { name: 'CreatorName', type: 'text' },
                        { name: 'LocLat', type: 'text' },
                        { name: 'LocLog', type: 'text' },
                        { name: 'Address', type: 'text' },
                        { name: 'Notes', type: 'text' },
                        { name: 'IsConfidential', type: 'bit' },
                        { name: 'IsDeleted', type: 'bit' },
                        { name: 'CreatorID', type: 'integer' }, //created usedId
                        { name: 'CreatedOn', type: 'text' },//current date
                        { name: 'CreatedAt', type: 'text' },//location
                        { name: 'ModifiedBy', type: 'integer' },
                        { name: 'ModifiedByName', type: 'text' },
                        { name: 'ModifiedOn', type: 'text' },
                        { name: 'ModifiedAt', type: 'text' },
                        { name: 'SyncStatus', type: 'integer' },
                        { name: 'ContactTypeID', type: 'integer' },
                        { name: 'ContactDisplayName', type: 'text' },
                        { name: 'RepresentativeDeviceObjID', type: 'text' },
                        { name: 'LoggedInUserID', type: 'integer' },
                        { name: 'EmployerID', type: 'integer' },
                        { name: 'EmployerName', type: 'text' },
                        { name: 'RepresentativeName', type: 'text' },
                      ]
                  },
              {
                  name: 'Deals',
                  columns: [
                       { name: 'DealID', type: 'integer' },
                       { name: 'DeviceObjID', type: 'text' },
                       { name: 'ContactID', type: 'integer' },
                       { name: 'ContactDeviceObjID', type: 'text' },
                       { name: 'ContactName', type: 'text' },
                       { name: 'ContactDisplayName', type: 'text' },
                       { name: 'CompanyName', type: 'text' },
                       { name: 'ProductFamilyID', type: 'integer' },
                       { name: 'ProductFamilyName', type: 'text' },
                       { name: 'ProductID', type: 'integer' },
                       { name: 'ProductName', type: 'text' },
                       { name: 'DealSubject', type: 'text' },
                       { name: 'ExpectedDealSize', type: 'float' },
                       { name: 'ExpectedDealSizeCurrencyID', type: 'integer' },
                       { name: 'ExpectedDealSizeCurrencyConvRate', type: 'float' },
                       { name: 'ExpectedDealSizeConverted', type: 'float' },
                       { name: 'ExpectedDealRevenue', type: 'float' },
                       { name: 'ExpectedDealRevenueCurrencyID', type: 'integer' },
                       { name: 'ExpectedDealRevenueCurrencyConvRate', type: 'float' },
                       { name: 'ExpectedDealRevenueConverted', type: 'float' },
                       { name: 'ActualDealSize', type: 'float' },
                       { name: 'ActualDealSizeCurrencyID', type: 'integer' },
                       { name: 'ActualDealSizeCurrencyConvRate', type: 'float' },
                       { name: 'ActualDealSizeConverted', type: 'float' },
                       { name: 'ActualDealRevenue', type: 'float' },
                       { name: 'ActualDealRevenueCurrencyID', type: 'integer' },
                       { name: 'ActualDealRevenueCurrencyConvRate', type: 'float' },
                       { name: 'ActualDealRevenueConverted', type: 'float' },
                       { name: 'ExpectedDealCloseDate', type: 'text' },
                       { name: 'RepresentativeID', type: 'integer' },
                       { name: 'OwnerID', type: 'integer' },
                       { name: 'CreatorID', type: 'integer' },
                       { name: 'OwnerName', type: 'text' },
                       { name: 'IsConfidential', type: 'boolean' },
                       { name: 'CreatedOn', type: 'text' },
                       { name: 'CreatedAt', type: 'text' },
                       { name: 'ModifiedBy', type: 'integer' },
                       { name: 'ModifiedOn', type: 'text' },
                       { name: 'ModifiedAt', type: 'text' },
                       { name: 'ModuleID', type: 'integer' },
                       { name: 'ActualDealCloseDate', type: 'text' },
                       { name: 'CampaignReference', type: 'text' },
                       { name: 'CampaignReferenceID', type: 'integer' },
                       { name: 'ContactOwnerID', type: 'integer' },
                       { name: 'ContactOwnerName', type: 'text' },
                       { name: 'ContactSegmentID', type: 'integer' },
                       { name: 'ContactSegmentName', type: 'text' },
                       { name: 'ContactTierID', type: 'integer' },
                       { name: 'ContactTierName', type: 'text' },
                       { name: 'ContactTypeID', type: 'integer' },
                       { name: 'CreatorName', type: 'text' },
                       { name: 'DealCompetitorID', type: 'integer' },
                       { name: 'DealSourceID', type: 'integer' },
                       { name: 'DealSourceName', type: 'text' },
                       { name: 'DealStageID', type: 'integer' },
                       { name: 'DealStageName', type: 'text' },
                       { name: 'DealStageModelID', type: 'integer' },
                       { name: 'EmployerID', type: 'integer' },
                       { name: 'EmployerName', type: 'text' },
                       { name: 'IsDeleteRequestRaised', type: 'boolean' },
                       { name: 'RepresentativeDeviceObjID', type: 'text' },
                       { name: 'RepresentativeName', type: 'text' },
                       { name: 'AddedFromSource', type: 'integer' },
                       { name: 'DealChecklistMappingStr', type: 'text' },
                       { name: 'LoggedInUserID', type: 'integer'}
                  ]
              },
              {
                   name: 'ProductFamily',
                   columns: [
                      { name: 'CreatedAt', type: 'text' }, //[selected part id]
                      { name: 'CreatedBy', type: 'text' }, //[selected part id]
                      { name: 'CreatedOn', type: 'text' }, //[selected part id]
                      { name: 'IsDefault', type: 'boolean' }, //[selected part id]
                      { name: 'IsDeleted', type: 'boolean' }, //[selected part id]
                      { name: 'ModifiedAt', type: 'text' }, //[selected part id]
                      { name: 'ModifiedBy', type: 'integer' }, //[selected part id]
                      { name: 'ModifiedOn', type: 'text' }, //[selected part id]
                      { name: 'Description', type: 'text' }, //[selected part id]
                      { name: 'ModuleID', type: 'integer' }, //[selected part id]
                      { name: 'Name', type: 'text' }, //[selected part id]
                      { name: 'Name_OL1', type: 'text' }, //[selected part id]
                      { name: 'Name_OL2', type: 'text' }, //[selected part id]
                      { name: 'OrganisationID', type: 'integer' }, //[selected part id]
                      { name: 'ProductFamilyID', type: 'integer' }, //[selected part id]
                      { name: 'UserID', type: 'integer' }, //[selected part id]
                      { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
               {
                   name: 'Products',
                   columns: [
                      { name: 'CreatedAt', type: 'text' }, //[selected part id]
                      { name: 'CreatedBy', type: 'text' }, //[selected part id]
                      { name: 'CreatedOn', type: 'text' }, //[selected part id]
                      { name: 'IsDefault', type: 'boolean' }, //[selected part id]
                      { name: 'IsDeleted', type: 'boolean' }, //[selected part id]
                      { name: 'ModifiedAt', type: 'text' }, //[selected part id]
                      { name: 'ModifiedBy', type: 'integer' }, //[selected part id]
                      { name: 'ModifiedOn', type: 'text' }, //[selected part id]
                      { name: 'Description', type: 'text' }, //[selected part id]
                      { name: 'IsActive', type: 'boolean' }, //[selected part id]
                      { name: 'Name', type: 'text' }, //[selected part id]
                      { name: 'Name_OL1', type: 'text' }, //[selected part id]
                      { name: 'Name_OL2', type: 'text' }, //[selected part id]
                      { name: 'OrganisationID', type: 'integer' }, //[selected part id]
                      { name: 'ProductFamilyID', type: 'integer' }, //[selected part id]
                      { name: 'ProductFamilyName', type: 'text' }, //[selected part id]
                      { name: 'ProductID', type: 'integer' },
                      { name: 'ProductOwnerEmail', type: 'text' }, //[selected part id]
                      { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
              {
                   name: 'DealDocumentMapping',
                   columns: [
                      { name: 'DealDocumentMappingID', type: 'integer' },
                      { name: 'DealID', type: 'integer' }, //[selected part id]
                      { name: 'DeviceObjID', type: 'text' }, //[selected part id]
                      { name: 'ParentDeviceObjID', type: 'text' }, //[selected part id]
                      { name: 'DocumentID', type: 'text' }, //[selected part id]
                      { name: 'DocumentName', type: 'text' }, //[selected part id]
                      { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
               {
                   name: 'Participients',
                   columns: [
                      { name: 'DeviceObjID', type: 'text' },
                      { name: 'AttendeeDeviceObjID', type: 'text' }, //[selected part id]
                      { name: 'AttendeeID', type: 'integer' }, //[selected part id]
                      { name: 'UserName', type: 'text' },//activity name [selected part name]
                      { name: 'ParentType', type: 'text' },//type for deal/activity[parent device type like A,D]
                      { name: 'ParentDeviceObjID', type: 'integer' },//Id for the deal/activity[parent device id]
                      { name: 'Type', type: 'integer' },//type for internal/external [UP,CP]
                      { name: 'AccessCategoryID', type: 'integer' },//for full/partital[R-restricted,F-full]
                      { name: 'EntityAttendeeID', type: 'integer' },
                      { name: 'IsChecked', type: 'boolean' },
                      { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
               {
                   name: 'ContactRelationships',
                   columns: [
                      { name: 'DeviceObjID', type: 'text' },
                      { name: 'ContactRelationshipMappingID', type: 'integer' },
                      { name: 'ContactID', type: 'integer' },
                      { name: 'ContactName', type: 'text' },
                      { name: 'ContactDeviceObjID', type: 'text' },
                      { name: 'ContactRelationshipTypeID', type: 'integer' },
                      { name: 'RelationshipWithContactID', type: 'integer' },
                      { name: 'RelationshipWithContactName', type: 'text' },
                      { name: 'RelationshipWithContactDeviceObjID', type: 'text' },
                      { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
               {
                   name: 'Attachments',
                   columns: [
                       { name: 'CreatedAt', type: 'text' }, //[selected part id]
                       { name: 'CreatedBy', type: 'text' }, //[selected part id]
                       { name: 'CreatedOn', type: 'text' }, //[selected part id]
                       { name: 'ModifiedAt', type: 'text' }, //[selected part id]
                       { name: 'ModifiedBy', type: 'integer' }, //[selected part id]
                       { name: 'ModifiedOn', type: 'text' }, //[selected part id]
                       { name: 'AttachmentCategoryID', type: 'integer' }, //[selected part id]
                       { name: 'AttachmentID', type: 'integer' }, //[selected part id]
                       { name: 'AttachmentSize', type: 'text' }, //[selected part id]
                       { name: 'Base64String', type: 'text' }, //[selected part id]
                       { name: 'DeviceObjID', type: 'text' },
                       { name: 'DocumentID', type: 'integer' },
                       { name: 'EntityID', type: 'integer' },
                       { name: 'Extension', type: 'text' },
                       { name: 'FileName', type: 'text' },
                       { name: 'FilePath', type: 'text' },
                       { name: 'MIMEContentType', type: 'text' },
                       { name: 'ModuleID', type: 'integer' },
                       { name: 'ParentDeviceObjID', type: 'text' },
                       { name: 'DocumentName', type: 'text' },
                       { name: 'SyncStatus', type: 'integer' },
                       { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
                {
                   name: 'Notes',
                   columns: [
                       { name: 'DeviceObjID', type: 'text' },
                       { name: 'EntityID', type: 'integer' },
                       { name: 'ModuleID', type: 'integer' },
                       { name: 'NoteID', type: 'integer' },
                       { name: 'ParentDeviceObjID', type: 'text' },
                       { name: 'Description', type: 'text' },
                       { name: 'ContactObjID', type: 'text' },
                       { name: 'CreatorID', type: 'integer' }, //created usedId
                       { name: 'CreatorName', type: 'text' }, //created usedId
                       { name: 'CreatedOn', type: 'text' },//current date
                       { name: 'CreatedAt', type: 'text' },//location
                       { name: 'RepresentativeID', type: 'integer' },
                       { name: 'RepresentativeObjID', type: 'text' },
                       { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
               {
                   name: 'DynamicFields',
                   columns: [
                   { name: 'EntityID', type: 'integer' },
                   { name: 'ModuleID', type: 'text' },
                   { name: 'ParentDeviceObjID', type: 'text' },
                   { name: 'LoggedInUserID', type: 'integer'},
                   { name: 'Field1', type: 'text' },
                   { name: 'Field2', type: 'text' },
                   { name: 'Field3', type: 'text' },
                   { name: 'Field4', type: 'text' },
                   { name: 'Field5', type: 'text' },
                   { name: 'Field6', type: 'text' },
                   { name: 'Field7', type: 'text' },
                   { name: 'Field8', type: 'text' },
                   { name: 'Field9', type: 'text' },
                   { name: 'Field10', type: 'text' },
                   { name: 'Field11', type: 'text' },
                   { name: 'Field12', type: 'text' },
                   { name: 'Field13', type: 'text' },
                   { name: 'Field14', type: 'text' },
                   { name: 'Field15', type: 'text' },
                   { name: 'Field16', type: 'text' },
                   { name: 'Field17', type: 'text' },
                   { name: 'Field18', type: 'text' },
                   { name: 'Field19', type: 'text' },
                   { name: 'Field20', type: 'text' },
                   { name: 'Field21', type: 'text' },
                   { name: 'Field22', type: 'text' },
                   { name: 'Field23', type: 'text' },
                   { name: 'Field24', type: 'text' },
                   { name: 'Field25', type: 'text' },
                   { name: 'Field26', type: 'text' },
                   { name: 'Field27', type: 'text' },
                   { name: 'Field28', type: 'text' },
                   { name: 'Field29', type: 'text' },
                   { name: 'Field30', type: 'text' },
                   { name: 'Field31', type: 'text' },
                   { name: 'Field32', type: 'text' },
                   { name: 'Field33', type: 'text' },
                   { name: 'Field34', type: 'text' },
                   { name: 'Field35', type: 'text' },
                   { name: 'Field36', type: 'text' },
                   { name: 'Field37', type: 'text' },
                   { name: 'Field38', type: 'text' },
                   { name: 'Field39', type: 'text' },
                   { name: 'Field40', type: 'text' },
                   ]

               },
               {
                   name: 'MsgConversations',
                   columns: [
                       { name: 'DeviceObjID', type: 'text' },
                       { name: 'Participant1ID', type: 'integer' },
                       { name: 'Participant2ID', type: 'integer' },
                       { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
               {
                   name: 'Messages',
                   columns: [  
                       { name: 'MsgIndex', type: 'INTEGER PRIMARY KEY   AUTOINCREMENT' },
                       { name: 'ConversationDeviceObjID', type: 'text' },
                       { name: 'DeviceObjID', type: 'text' },
                       { name: 'InternalMessageID', type: 'integer' },
                       { name: 'SendByID', type: 'integer' },
                       { name: 'SendByName', type: 'text' },
                       { name: 'SendToID', type: 'integer' },
                       { name: 'SendToName', type: 'text' },
                       { name: 'Description', type: 'text' },
                       { name: 'SystemDateTime', type: 'text' },
                       { name: 'LoggedInUserID', type: 'integer'}
                   ]
               },
               {
                   name: 'Alerts',
                   columns: [
                       { name: 'AlertID', type: 'integer' },
                       { name: 'AlertCategoryID', type: 'integer' },
                       { name: 'ModuleID', type: 'integer' },
                       { name: 'EntityID', type: 'integer' },
                       { name: 'Description', type: 'text' },
                       { name: 'UserID', type: 'integer' },
                       { name: 'AlertDate', type: 'text' },
                       { name: 'IsRead', type: 'boolean' },
                       { name: 'ReadDateTime', type: 'text' },
                       { name: 'IsDeleted', type: 'boolean' },
                       { name: 'CreatedBy', type: 'text' },
                       { name: 'CreatedOn', type: 'text' },
                       { name: 'ServerDateTime', type: 'text' },
                       { name: 'LoggedInUserID', type: 'integer'}
                   ]
               }
            ],
        },
        'MASTER_TABLE': {
            'AccCat': 'AccessCategory',
            'ActDur': 'ActivityDuration',
            'ActFldSet': 'ActivityFieldSetting',
            'ActStag': 'ActivityStage',
            'ActTime': 'ActivityTime',
            'ActType': 'ActivityType',
            'AtchCat': 'AttachmentCategory',
            'ChLstDoc': 'ChecklistDocument',
            'ChLstMat': 'ChecklistMatrix',
            'ComCat': 'CommunicationCategory',
            'ComTyp': 'CommunicationType',
            'ConFieldSet': 'ContactFieldSetting',
            'ConGrup': 'ContactGroup',
            'ConSeg': 'ContactSegment',
            'ConTier': 'Tier',
            'ConTyp': 'ContactType',
            'CorTyp': 'CorrespondenceType',
            'Curcy': 'Currency',
            'CusTyp': 'CustomerType',
            'DelSet': 'DealFieldSetting',
            'DelSuc': 'DealSource',
            'DelSubStg': 'DealSubStage',
            'FildCat': 'FieldCategory',
            'Lang': 'Language',
            'LobSet': 'LOBSetting',
            'Mod': 'Module',
            'OrgModPer': 'OrganisationModulePermission',
            'OrgSet': 'OrganisationSetting',
            'PrdSch': 'ProductScheme',
            'PrdTyp': 'ProductType',
            'RelTyp': 'RelationshipType',
            'RelInverseType': 'RelationshipTypeInverseMapping',
            'Sal': 'Salutation',
            'Tier': 'Tier',
            'UsrModAcsPer': 'UserModuleAccessPermission',
            'UsrSet': 'UserSetting',
            'LoggedInUserInfo': 'LoggedInUserInfo',
            'LoggedInAsUserInfo': 'LoggedInAsUserInfo',
            'UserGroup': 'UserGroup'
        },
        'PATH': {
            'CONTROLLER': 'app/controllers/',
            'VIEW': 'app/views/'
        },
        'ALERT_MESSAGE': {
            'ALERT_TITLE': 'Sales ARM',
            'EMAIL': 'Please Enter Valid Email',
            'PASSWORD' : 'Please Enter Valid Password',
            'FIRST_NAME': 'Please Enter First Name',
            'COMPANY_NAME' : 'Please Enter Company Name',
            'SELECT_COMPANY' : 'Please Select Contact or Company',
            'NETWORK' : 'Please check your device network',
            'CONTACT_NOT_SYNC' : 'Contact is not configure',
            'DECRYPTION_ERROR': 'Response decryption error',
            'NOTE_ADD': 'Notes Added Successfully',
            'GROUP' : 'Please Select Group'
        },
        'ENVIRONMENT': {
            "SSL": "https://services.sales-arm.com/", 
            "SERVER": "http://demo.services.sales-arm.com/",//"http://172.20.131.54/SalesARMDeviceService/" //"http://localhost:64932/"//"http://172.20.131.54/ARMLiveExternalServicesPortal/"
            "ENBD_SIT": "http://10.119.2.158/salesarm-service/",
            "Development": "http://172.20.131.54/SalesARMDeviceService/"
        },
        'DATABASENAME': 'salesArm.db',
        'SERVICE_TYPE': {
            "LOGIN": "DeviceUserService.svc/Authenticate",//{BaseAddress}/DeviceUserService.svc/Authenticate
            "CONTACT": "DeviceContactService.svc/AddModify",
            "MASTERDATA": "DeviceMasterDataService.svc/GetMasterData/",//DeviceMasterDataService.svc/GetMasterData/{UserId}/{ModuleId}/{FetchAllRecords}
            "ACTIVITYADD": "DeviceActivityService.svc/AddModify",//DeviceMasterDataService.svc/GetMasterData/{UserId}/{ModuleId}/{FetchAllRecords}
            "DEALADD": "DeviceDealService.svc/AddModify",//DeviceMasterDataService.svc/GetMasterData/{UserId}/{ModuleId}/{FetchAllRecords}
            "DEALDETAILSEMAIL": "DeviceDealService.svc/SendEmailForDealDetails",//DeviceMasterDataService.svc/GetMasterData/{UserId}/{ModuleId}/{FetchAllRecords}
            "DEALCLOSELOST": "DeviceDealService.svc/UpdateDealStage",//DeviceMasterDataService.svc/GetMasterData/{UserId}/{ModuleId}/{FetchAllRecords}
            "USERLIST": "DeviceUserService.svc/GetUsersForAccess/",
            "PRODUCTFAMILY": "DeviceProductService.svc/GetProductForListing",
            "GETATTACHMENT": "DeviceAttachmentService.svc/GetAttachmentByID",
            "DASHBOARDGRAPH": "DeviceDashboardService.svc/GetHomeDashboard",
            "CONTACTGRAPH": "DeviceDashboardService.svc/GetContactDashboard",
            "ACTIVITYLIST": "DeviceActivityService.svc/GetActivityForListing/",
            "DEALLIST": "DeviceDealService.svc/GetDealForListing/",
            "CONTACTLIST": "DeviceContactService.svc/GetContactForListing/",
            "CONTACTNOTE": "DeviceCommonService.svc/AddModifyNote",
            "ATTACHMENT": "DeviceAttachmentService.svc/AddModifyAttachment",
            "HOMELIST": "DeviceHomeService.svc/GetHomePageRecords/",//{BaseAddress}/DeviceHomeService.svc/GetHomePageRecords/{userID}/{languageID}

        }

    }

    angular.forEach(config_data, function (key, value) {
        config_module.constant(value, key);
    });

})();
