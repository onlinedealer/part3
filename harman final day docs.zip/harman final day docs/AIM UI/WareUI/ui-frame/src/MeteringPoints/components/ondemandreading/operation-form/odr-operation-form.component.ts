import {
    Component,
    Input,
    Output,
    EventEmitter,
    OnDestroy,
    OnInit,
    OnChanges,
    SimpleChanges,
    ChangeDetectionStrategy
} from "@angular/core";
import {
    OnDemandReadingService,
    OnDemandReading,
    OnDemandReadingRequestType,
    OnDemandReadingFeatureRequestData
} from "../../../models/ondemandreading.model";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { Metering } from "../../../models/metering.model";
import { Observable, Subscription } from "rxjs";
import { DateAdapter } from "@angular/material/core";
import { MatSnackBar } from "@angular/material/snack-bar";
import * as moment from "moment";
import { TranslationsService } from "../../../../app/services/translations-service";
import { FormGroup, FormBuilder, AbstractControl } from "@angular/forms";
import { map, withLatestFrom, debounceTime } from "rxjs/operators";
import { dayDiff } from "../../../../Shared/helpers/date.helper";
import { Store } from "@ngrx/store";
import { getFormControl, getFormControlValue } from "../../../../Shared/helpers/form.helpers";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { getProfileDataRecommendedReadDays } from "../../../store/selectors/profiledata.selectors";
import { DateFormatService } from "../../../../Shared/services/date-format.service";

enum ReadingButtonState {
    Hidden = 1,
    Visible = 2,
    Disabled = 3
}

@Component({
    selector: "landisgyr-ondemandreading-operation-form",
    templateUrl: "./odr-operation-form.component.html",
    styleUrls: ["./odr-operation-form.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OnDemandReadingOperationFormComponent implements OnInit, OnChanges, OnDestroy {
    @Input()
    onDemandReadingRequests!: any[];
    @Input()
    scheduledReadings!: any[];
    @Input()
    onDemandReadingServices!: OnDemandReadingService[];
    @Input()
    onDemandReadingServicesFetched = false;

    @Input()
    supportedOnDemandReadingServices!: OnDemandReadingService[];

    @Input()
    instanteneousReadingTypes!: string[];

    @Input()
    meteringPoint!: MeteringPoint;

    @Input()
    profileMeteringsThatCanBeRead!: Metering[];

    @Input()
    periodicMeteringsThatCanBeRead!: Metering[];

    @Output()
    submitted: EventEmitter<OnDemandReading> = new EventEmitter<OnDemandReading>();

    mainForm!: FormGroup;

    mainFormSelectedRadio$!: Observable<string>;

    readButtonState$!: Observable<ReadingButtonState>;

    showWarnMessage$!: Observable<boolean>;

    warnMessage = this.translationsService.getTranslation("Reading a long time range might take time.");

    profileReadEnabled = false;
    periodicReadEnabled = false;
    instanteneousReadEnabled = false;
    eventsReadEnabled = false;
    transformerRatioEnabled = true;

    scheduledTimeDisableSubscription: Subscription;
    constructor(
        private snackBar: MatSnackBar,
        public translationsService: TranslationsService,
        private fb: FormBuilder,
        private store: Store<MeteringPointsFeatureState>,
        private dateAdapter: DateAdapter<moment.Moment>,
        private dateFormatService: DateFormatService
    ) {
        this.mainForm = this.fb.group({
            radioSelection: "",
            profileGroup: this.fb.group(
                {
                    meterings: [""],
                    date: this.fb.control({
                        begin: this.dateAdapter.addCalendarDays(this.dateAdapter.today(), -2),
                        end: this.dateAdapter.today()
                    })
                },
                { validator: this.validateProfileForm }
            ),
            periodicGroup: this.fb.group({
                periodicRadioSelection: "current",
                scheduledTime: this.fb.control(this.dateAdapter.addCalendarDays(this.dateAdapter.today(), 1))
            }),
            instanteneousVal: this.fb.group({
                instanteous: [""]
            }),
            eventsVal: this.fb.group({
                events: [""]
            })
        });
        this.scheduledTimeDisableSubscription = this.mainForm.valueChanges
            .pipe(
                debounceTime(100),
                map((values) => {
                    return { ...this.mainForm.getRawValue(), ...values };
                })
            )
            .subscribe((values) => {
                const control = this.mainForm.controls.periodicGroup.get("scheduledTime");

                if (!control) {
                    return;
                }
                if (values.periodicGroup.periodicRadioSelection === "current") {
                    control.disable({ emitEvent: true });
                } else {
                    control.enable({ emitEvent: true });
                }
            });
    }

    validateProfileForm = (formGroup: FormGroup) => this.validateProfileFormValues(formGroup.value);

    getLabelForOdrType(requestType: OnDemandReadingRequestType) {
        if (!this.onDemandReadingServices || this.onDemandReadingServices.length === 0) {
            return "";
        }
        const serviceFound = this.onDemandReadingServices.find((service) => service.id === requestType);
        if (!serviceFound) {
            return "";
        }
        return serviceFound.name;
    }

    validateProfileFormValues(value: any) {
        if (value.to > new Date().valueOf()) {
            this.mainForm.patchValue({
                profileGroup: {
                    to: new Date().valueOf()
                }
            });
        }
        if (value.meterings && value.meterings.length === 0) {
            return { notValid: true };
        }
        return null;
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.onDemandReadingServices || changes.profileMeteringsThatCanBeRead) {
            this.instanteneousReadEnabled = this.isActiveReadState(
                this.supportedOnDemandReadingServices,
                OnDemandReadingRequestType.ReadInstantaneousValue
            );
            this.profileReadEnabled =
                this.isActiveReadState(this.supportedOnDemandReadingServices, OnDemandReadingRequestType.ReadProfileData) &&
                this.profileMeteringsThatCanBeRead.length > 0;
            this.periodicReadEnabled =
                this.isActiveReadState(this.supportedOnDemandReadingServices, OnDemandReadingRequestType.ReadPeriodicData) &&
                this.periodicMeteringsThatCanBeRead.length > 0;
            this.eventsReadEnabled = this.isActiveReadState(
                this.supportedOnDemandReadingServices,
                OnDemandReadingRequestType.ReadEventData
            );
            this.transformerRatioEnabled = this.isActiveReadState(
                this.supportedOnDemandReadingServices,
                OnDemandReadingRequestType.ReadTransformerRatio
            );
            this.setControlActiveState(this.mainForm, ["instanteneousVal"], this.instanteneousReadEnabled);
            this.setControlActiveState(this.mainForm, ["profileGroup"], this.profileReadEnabled);
            this.setControlActiveState(this.mainForm, ["periodicGroup"], this.periodicReadEnabled);
            this.setControlActiveState(this.mainForm, ["eventsVal"], this.eventsReadEnabled);
        }
    }

    ngOnDestroy() {
        this.scheduledTimeDisableSubscription.unsubscribe();
    }

    ngOnInit() {
        this.showWarnMessage$ = this.mainForm.valueChanges.pipe(
            withLatestFrom(this.store.select(getProfileDataRecommendedReadDays)),
            map(([values, recommendedDays]) => {
                if (!values.profileGroup || values.radioSelection !== OnDemandReadingRequestType.ReadProfileData) {
                    return false;
                }
                return dayDiff(values.profileGroup.from, values.profileGroup.to) > recommendedDays;
            })
        );
        this.mainFormSelectedRadio$ = this.mainForm.valueChanges.pipe(
            map((values) => {
                return values.radioSelection;
            })
        );
        this.readButtonState$ = this.mainForm.valueChanges.pipe(
            map((values) => {
                return { ...this.mainForm.getRawValue(), ...values };
            }),
            map((values) => {
                if (!this.onDemandReadingServicesFetched) {
                    return ReadingButtonState.Hidden;
                }
                if (!values.radioSelection) {
                    return ReadingButtonState.Disabled;
                }
                if (values.radioSelection === OnDemandReadingRequestType.ReadProfileData) {
                    return this.validateProfileFormValues(values.profileGroup) != null
                        ? ReadingButtonState.Disabled
                        : ReadingButtonState.Visible;
                } else if (values.radioSelection === OnDemandReadingRequestType.ReadPeriodicData) {
                    return ReadingButtonState.Visible;
                }
                return ReadingButtonState.Visible;
            })
        );
    }

    isActiveReadState(readingServices: OnDemandReadingService[], value: OnDemandReadingRequestType) {
        if (!readingServices) {
            return false;
        }
        const serviceFound = readingServices.map((service) => service.id).includes(value);
        return serviceFound;
    }

    setControlActiveState(formGroup: FormGroup, controlNames: string[], activeState: boolean): AbstractControl {
        const control = getFormControl(formGroup, controlNames);
        if (activeState) {
            control.enable();
        } else {
            control.disable();
        }
        return control;
    }

    onRead(mainFormValues: any) {
        switch (mainFormValues.radioSelection) {
            case OnDemandReadingRequestType.ReadProfileData:
                this.readProfileData();
                break;
            case OnDemandReadingRequestType.ReadInstantaneousValue:
                this.readInstantaneousValue();
                break;
            case OnDemandReadingRequestType.ReadPeriodicData:
                this.readPeriodicData();
                break;
            case OnDemandReadingRequestType.ReadEventData:
                this.readEventData();
                break;
            case OnDemandReadingRequestType.ReadTransformerRatio:
                this.readTransformerData();
                break;
            default:
                this.snackBar.open("This option is not yet supported.", "", {
                    duration: 800
                });
                break;
        }
        this.resetFormSelections();
    }

    readProfileData() {
        const dateRange = getFormControlValue(this.mainForm, ["profileGroup", "date"]);
        const startTime = this.dateAdapter.clone(dateRange.begin);
        const endTime = this.dateAdapter.clone(dateRange.end);
        const onDemandReadingRequest: OnDemandReading = {
            meteringPointId: this.meteringPoint.id,
            requestType: OnDemandReadingRequestType.ReadProfileData,
            startTime: this.dateFormatService.toStartOfDay(startTime.valueOf()),
            endTime: this.dateFormatService.toEndOfDay(endTime.valueOf()),
            meteringRequestData: []
        };
        const meteringsValue = getFormControlValue(this.mainForm, ["profileGroup", "meterings"]);
        if (meteringsValue) {
            meteringsValue.forEach((metering: Metering) => {
                if (onDemandReadingRequest.meteringRequestData) {
                    onDemandReadingRequest.meteringRequestData.unshift({
                        meteringId: metering.meteringId,
                        measuredAttribute: metering.measuredAttribute,
                        measuredUnit: metering.measuredUnit,
                        measurementType: metering.measurementType
                    });
                }
            });
        }
        this.submitted.next(onDemandReadingRequest);
    }

    readPeriodicData() {
        const scheduledTimeControl = this.mainForm.get(["periodicGroup", "scheduledTime"]);
        const periodicRadioSelectionControl = this.mainForm.get(["periodicGroup", "periodicRadioSelection"]);
        const onDemandReadingRequest = this.createOnDemandReading(OnDemandReadingRequestType.ReadPeriodicData);
        if (scheduledTimeControl && periodicRadioSelectionControl && periodicRadioSelectionControl.value === "scheduled") {
            onDemandReadingRequest.expectedReadingTime = this.dateAdapter
                .clone(scheduledTimeControl.value.begin.startOf("date"))
                .set({ hours: 1 })
                .valueOf();
        }
        this.submitted.next(onDemandReadingRequest);
    }

    readInstantaneousValue() {
        const onDemandReadingRequest: OnDemandReading = this.createOnDemandReading(OnDemandReadingRequestType.ReadInstantaneousValue, [
            ...this.instanteneousReadingTypes.map((readingType) => {
                return {
                    id: readingType
                };
            })
        ]);

        this.submitted.next(onDemandReadingRequest);
    }

    readEventData() {
        const onDemandReadingRequest: OnDemandReading = this.createOnDemandReading(OnDemandReadingRequestType.ReadEventData, [
            { id: "Events" }
        ]);
        this.submitted.next(onDemandReadingRequest);
    }

    readTransformerData() {
        const onDemandReadingRequest: OnDemandReading = this.createOnDemandReading(OnDemandReadingRequestType.ReadInstantaneousValue, [
            { id: "TransformerRatio" }
        ]);
        this.submitted.next(onDemandReadingRequest);
    }

    createOnDemandReading(type: OnDemandReadingRequestType, featureRequestData?: OnDemandReadingFeatureRequestData[]) {
        const now = this.dateAdapter.today();
        const onDemandReadingRequest: OnDemandReading = {
            meteringPointId: this.meteringPoint.id,
            requestType: type,
            // Use of time parameters depends on device type, in some cases they may be ignored
            startTime: this.dateAdapter.addCalendarDays(now, -1).valueOf(),
            endTime: this.dateAdapter.clone(now).valueOf(),
            featureRequestData: featureRequestData || []
        };
        return onDemandReadingRequest;
    }

    private resetFormSelections() {
        this.mainForm.reset({
            radioSelection: "",
            profileGroup: {
                meterings:
                    this.profileMeteringsThatCanBeRead && this.profileMeteringsThatCanBeRead.length > 0
                        ? [...this.profileMeteringsThatCanBeRead, 0]
                        : [],
                date: {
                    begin: this.dateAdapter.addCalendarDays(this.dateAdapter.today(), -2),
                    end: this.dateAdapter.today()
                }
            },
            periodicGroup: {
                periodicRadioSelection: "current",
                scheduledTime: this.dateAdapter.addCalendarDays(this.dateAdapter.today(), 1)
            },
            instanteneousVal: {
                instanteous: [""]
            },
            eventsVal: { events: [""] }
        });
    }
}
