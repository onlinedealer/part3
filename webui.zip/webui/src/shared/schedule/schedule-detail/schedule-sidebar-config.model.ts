export class ScheduleSidebarConfigModel {
  viewType: string;
  id: string;
  editEnabled: boolean;
  source: string;
  name?: string;
}
