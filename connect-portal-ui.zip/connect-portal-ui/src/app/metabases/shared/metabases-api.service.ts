import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { BaseConnectApiService } from '../../core/base-connect-api.service';
import { Metabase } from './metabase.model';

@Injectable({
  providedIn: 'root'
})
export class MetabasesApiService extends BaseConnectApiService<Metabase> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient);
  }

  getPhysicalSQLServerPaths(connectionId: number, data: { adminUserId: string; adminUserPassword: string }) {
    return this.httpClient.post(`${environment.connectApiBaseURL}/metadata/dataDirectory?connection_id=${connectionId}`, data);
  }

  deleteMetabase(
    dataConnectionId: string,
    credentials?: { userId: string; password: string; removeConfigOnly?: boolean }
  ): Observable<any> {
    let removeConfigOnlyStr = 'false';
    let options;
    if (credentials) {
      removeConfigOnlyStr = credentials.removeConfigOnly ? credentials.removeConfigOnly.toString() : 'false';
      options = {
        body: {
          adminUserId: credentials.userId,
          adminUserPassword: credentials.password
        }
      };
    }
    const apiEndpoint = `${this.serviceURL}/${dataConnectionId}?removeConfigOnly=${removeConfigOnlyStr}`;
    return this.httpClient.request('delete', apiEndpoint, options);
  }

  upgradeMetabase(dataConnectionId: string, data: { adminUserId: string; adminUserPassword: string }) {
    const apiEndpoint = `${this.serviceURL}/${dataConnectionId}/upgrade`;
    return this.httpClient.post(apiEndpoint, data);
  }

  getMetabaseVersionForUpgrade(dataConnectionId: string) {
    const apiEndpoint = `${this.serviceURL}/${dataConnectionId}/availableVersion`;
    return this.httpClient.get(apiEndpoint);
  }
}
