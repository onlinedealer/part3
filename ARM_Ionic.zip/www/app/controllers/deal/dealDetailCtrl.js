(function () {
    'use strict';

    angular.module('arm').controller('dealDetailCtrl',
                            ['$scope','$state','dealService','utility', 'MASTER_TABLE', '$filter', "$ionicModal",'GENERAL_CONFIG', '$cordovaDialogs', '$cordovaFile', '$timeout', dealDetailCtrl]);


    function dealDetailCtrl($scope, $state, dealService, utility, MASTER_TABLE, $filter, $ionicModal, GENERAL_CONFIG, $cordovaDialogs, $cordovaFile, $timeout) {
        ////console.log($state.params.itemClickedIndex);
        //$scope.dealDetails = angular.fromJson($state.params.dealModelToSend);

        // Deal Stage
        $scope.selDealStages = {
            activeDealStage: "",
            tempDealStage: "",
            previousDealStageID:"",
            previousDealStageName:""
        };

        var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.dealStages = utility.getMultLangMasData(MASTER_TABLE.DelSubStg);
        $scope.currencies = utility.getMultLangMasData(MASTER_TABLE.Curcy);
        $scope.user = {};

        $scope.dealDetails = dealService.getSelectedDeal();
        $scope.dealStageModelID = utility.dealStageModelIDCheck($scope.dealDetails.DealStageID);
        $scope.isEditButtonFlag = utility.allowEditing($scope.dealDetails);

        if($scope.dealDetails.DealAttendees.length == 0){
            dealService.sqlGetPanelData("Participients",$scope.dealDetails.DeviceObjID).then(function(result){
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.dealDetails.DealAttendees.push(result.rows.item(i));
                }

            },function(err){
                    alert(err);
            });
        }

        var shouldDisplayConfidentialFields = true;
            var fieldSet = utility.getMasterDataByKey(MASTER_TABLE.DelSet);
            fieldSet = $filter('filter')(fieldSet, {IsStaticField: false});
            if (!shouldDisplayConfidentialFields) { //Display Confidential fields if user== full access
                fieldSet = $filter('filter')(fieldSet, {IsConfidential: false});
            }
            fieldSet = $filter('filter')(fieldSet, {IsVisible: true});


        if($scope.dealDetails.Fields.length == 0){
            dealService.sqlGetPanelData("DynamicFields",$scope.dealDetails.DeviceObjID).then(function(result){

                for (var i = 0; i < fieldSet.length; i++) {
                    $scope.dealDetails.Fields.push({
                        FieldLabel: fieldSet[i].FieldLabel,
                        FieldName: fieldSet[i].FieldName,
                        FieldValue: result.rows.item(0)[fieldSet[i].FieldName],
                        FieldID: fieldSet[i].FieldID,
                        IsConfidential: fieldSet[i].IsConfidential,
                        IsMandatory: fieldSet[i].IsMandatory,
                        IsVisible: fieldSet[i].IsVisible,
                        ContactTypeID: fieldSet[i].ContactTypeID,
                        ContactFieldCategoryID: fieldSet[i].ContactFieldCategoryID
                    });
                }

            },function(err){
                    alert(err);
            });
        }


        if($scope.dealDetails.DealDocumentMapping.length == 0){
            dealService.sqlGetPanelData("DealDocumentMapping",$scope.dealDetails.DeviceObjID).then(function(result){
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.dealDetails.DealDocumentMapping.push(result.rows.item(i));
                }

            },function(err){
                    alert(err);
            });
        }

        if($scope.dealDetails.Notes.length == 0){
            dealService.sqlGetPanelData("Notes",$scope.dealDetails.DeviceObjID).then(function(result){
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.dealDetails.Notes.push(result.rows.item(i));
                    $scope.dealDetails.Notes[i].CreatedOnToDisplay = utility.getDateTimeInDisplayFormatForNotes($scope.dealDetails.Notes[i].CreatedOn);
                }

            },function(err){
                    alert(err);
            });
        }

        if($scope.dealDetails.Attachments.length == 0){
            dealService.sqlGetPanelData("Attachments",$scope.dealDetails.DeviceObjID).then(function(result){
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.dealDetails.Attachments.push(result.rows.item(i));
                }

            },function(err){
                    alert(err);
            });
        }

        $scope.AdditionalPanel = false; $scope.DealParticipantPanel = false;
        $scope.DealParticipantInternalPanel = false; $scope.DealChecklistPanel = false; $scope.AttachmentPanel = false;

        $scope.togglePanel = function(panelName) {
            if(panelName=="Additional"){
                $scope.AdditionalPanel = !$scope.AdditionalPanel;
            }
            else if(panelName=="DealParticipant"){
                $scope.DealParticipantPanel = !$scope.DealParticipantPanel;
            }
            else if(panelName=="DealParticipantInternal"){
                $scope.DealParticipantInternalPanel = !$scope.DealParticipantInternalPanel;
            }
            else if(panelName=="DealChecklist"){
                $scope.DealChecklistPanel = !$scope.DealChecklistPanel;
            }
            else if(panelName=="Attachment"){
                $scope.AttachmentPanel = !$scope.AttachmentPanel;
            }
        }

        $scope.backPage = function () {
            $state.go('tab.deal');
        }

        $scope.openEditMode = function () {
            $state.go('tab.dealAdd', { dealId:0, editModeFlag:1 });
        }

        // Show image in full width on popup over
        $scope.showImage = function (dealAttachment, attachmentIndex) {
          if(dealAttachment.FilePath = "" || dealAttachment.FilePath == null){

            dealService.getAttachments(dealAttachment.AttachmentID).then(function (productAttachmentsRes) {

                    // If your base64 string contains "data:image/png;base64,"" at the beginning, keep reading.
                    var myBase64 = productAttachmentsRes.Base64String;
                    // To define the type of the Blob
                    var contentType = productAttachmentsRes.MIMEContentType;
                    // if cordova.file is not available use instead :
                    // var folderpath = "file:///storage/emulated/0/";
                    var filename = productAttachmentsRes.FileName+productAttachmentsRes.Extension;
                    var folderpath = cordova.file.cacheDirectory + "dealImages";

                    var filePath = folderpath+"/"+filename;

                    $scope.dealDetails.Attachments[attachmentIndex].FilePath = filePath;

                    utility.savebase64AsImageFile(folderpath,filename,myBase64,contentType,"dealImages");

                    dealService.sqlUpdateAttachmentPath(filePath,productAttachmentsRes.AttachmentID).then(function(updateAttachmentSqlRes){
                        $ionicModal.fromTemplateUrl('app/views/common/image-popover.html', function ($ionicModal) {
                          $scope.imageModal = $ionicModal;
                          $timeout(function () {
                            $scope.imageSrc = cordova.file.cacheDirectory + "dealImages/"+dealAttachment.FileName+dealAttachment.Extension + '?' + new Date().getTime();
                            $scope.imageModal.show();
                          }, 2000);
                          }, {
                              // Use our scope for the scope of the modal to keep it simple
                              scope: $scope,
                              controller: 'contactController',
                              // The animation we want to use for the modal entrance
                              animation: 'slide-in-up'
                          });
                    },function (err) {
                        //console.log('product family error'+err);
                    });


                },function (err) {
                //console.log('product family error'+err);
                });


          }else{
             $scope.dealDetails.Attachments[attachmentIndex].FilePath = cordova.file.cacheDirectory + "dealImages/"+dealAttachment.FileName+dealAttachment.Extension;
             $ionicModal.fromTemplateUrl('app/views/common/image-popover.html', function ($ionicModal) {
              $scope.imageModal = $ionicModal;
              $scope.imageSrc = cordova.file.cacheDirectory + "dealImages/"+dealAttachment.FileName+dealAttachment.Extension + '?' + new Date().getTime();
              $scope.imageModal.show();
              }, {
                  // Use our scope for the scope of the modal to keep it simple
                  scope: $scope,
                  controller: 'contactController',
                  // The animation we want to use for the modal entrance
                  animation: 'slide-in-up'
              });
          }
        }
        $scope.closeImgModal = function() {
            $scope.imageModal.remove();
        };
        $scope.getImagePath = function(item) {
            var imgPath = cordova.file.cacheDirectory + "dealImages/"+ item.FileName + item.Extension;
            return imgPath;
        };


          /////////////////////////////////////////////////////////// Modal for Deal Stages /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStages.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStages = modal;
        });

        $scope.openDealStagesList = function (val) {
            $scope.modelSelected = val;
            var dealStageModelID = utility.dealStageModelIDCheck($scope.dealDetails.DealStageID);
            if(!(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close || dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost)){
                $scope.selDealStages.activeDealStage = $scope.dealDetails.DealStageID;
                $scope.selDealStages.previousDealStageID = $scope.dealDetails.DealStageID;
                $scope.selDealStages.previousDealStageName = $scope.dealDetails.DealStageName;
                $scope.modalDealStages.show();
            }
        };
        $scope.closeDealStagesList = function () {
            $scope.modalDealStages.hide();
        };

        $scope.actionDealStagesList = function () {
            var dealStageModelID = utility.dealStageModelIDCheck($scope.selDealStages.activeDealStage);
            if(!(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close || dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost)){
                $scope.selDealStages.tempDealStage = $scope.selDealStages.activeDealStage;
                for(var i=0;i<$scope.dealStages.length;i++){
                        if($scope.selDealStages.activeDealStage == $scope.dealStages[i].DealStageID){
                            $scope.dealDetails.DealStageID = $scope.dealStages[i].DealStageID;
                            $scope.dealDetails.DealStageName = $scope.dealStages[i].Name;
                            $scope.dealCloseModel = dealService.dealCloseLostMod().uiObject;
                            $scope.dealCloseModel.DeviceObjID = $scope.dealDetails.DeviceObjID;
                            $scope.dealCloseModel.DealID = $scope.dealDetails.DealID;
                            $scope.dealCloseModel.DealStageID = $scope.dealDetails.DealStageID;
                            $scope.dealCloseModel.DealStageName = $scope.dealDetails.DealStageName;
                            $scope.dealCloseModel.ModifiedBy = lgnUser.UserID;
                            var dateStringInUTC = utility.getDateStringInUTC(new Date());
                            $scope.dealCloseModel.ModifiedOn = dateStringInUTC;

                            dealService.sqlDealStageUpdate($scope.dealDetails).then(function(){

                                dealService.dealCloseLost($scope.dealCloseModel).then(function(res){
                                        //console.log("Deal Stage Update Result is"+JSON.stringify(res));
                                },function(err){
                                        alert(err);
                                });
                            },function(err){
                             alert(err);
                           });
                            //console.log('Deal Stage ID is'+$scope.dealDetails.DealStageID);
                            //console.log('Deal Stage Model ID is'+$scope.dealStages[i].DealStageModelID);
                        }
                }
                $scope.modalDealStages.hide();
            }else{
                for(var i=0;i<$scope.dealStages.length;i++){
                        if($scope.selDealStages.activeDealStage == $scope.dealStages[i].DealStageID){
                            $scope.dealDetails.DealStageID = $scope.dealStages[i].DealStageID;
                            $scope.dealDetails.DealStageName = $scope.dealStages[i].Name;
                            //console.log('Deal Stage ID is'+$scope.dealDetails.DealStageID);
                            //console.log('Deal Stage Model ID is'+$scope.dealStages[i].DealStageModelID);
                        }
                }
                if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close){
                    $scope.openDealStagesClose('DSC');
                    $scope.modalDealStages.hide();

                }else if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost){
                    $scope.openDealStagesLost('DSL');
                    $scope.modalDealStages.hide();
                }
            }
        };

                 /////////////////////////////////////////////////////////// Modal for Deal Stages Close /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStagesClose.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesClose = modal;
        });

        $scope.openDealStagesClose = function (val) {
            $scope.modelSelected = val;

            for(var i=0;i<$scope.currencies.length;i++){
                if($scope.currencies[i].CurrencyID == $scope.dealDetails.ExpectedDealSizeCurrencyID){
                    $scope.user.dealSizeCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.actualDealSize = $scope.dealDetails.ExpectedDealSize;
            $scope.user.actualDealSizeConverted = $scope.dealDetails.ExpectedDealSizeConverted;

            for(var i=0;i<$scope.currencies.length;i++){
                if($scope.currencies[i].CurrencyID == $scope.dealDetails.ExpectedDealRevenueCurrencyID){
                    $scope.user.dealRevenueCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.actualDealRevenue = $scope.dealDetails.ExpectedDealRevenue;
            $scope.user.actualDealRevenueConverted = $scope.dealDetails.ExpectedDealRevenueConverted;

            dealService.sqlGetContactCustomerID($scope.dealDetails.ContactDeviceObjID).then(function(result){
                for (var i = 0; i < result.rows.length; i++) {
                    if(result.rows.item(i).CustomerID == '0'){
                        $scope.user.actualDealCustomerID == '';
                    }else{
                        $scope.user.actualDealCustomerID = result.rows.item(i).CustomerID;
                    }
                }
            },function(err){
                alert(err);
            });

            $scope.modalDealStagesClose.show();
        };
        $scope.closeDealStagesClose = function () {
            $scope.dealDetails.DealStageID = $scope.selDealStages.previousDealStageID;
            $scope.dealDetails.DealStageName = $scope.selDealStages.previousDealStageName;
            $scope.modalDealStagesClose.hide();
        };

        $scope.actionDealStagesClose = function () {
            if(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == ''){
                $cordovaDialogs.confirm('Are you sure you do not want to enter client ID ?', 'SalesARM', ['Yes','No'])
                .then(function(buttonIndex) {
                    if(buttonIndex == 1){
                        $scope.closeDealStageConfirm();
                    }
                });
            }else{
                $scope.closeDealStageConfirm();
            }
        };

        $scope.closeDealStageConfirm = function(){
            $scope.isEditButtonFlag = false;
            $scope.dealCloseModel = dealService.dealCloseLostMod().uiObject;
            $scope.dealCloseModel.DeviceObjID = $scope.dealDetails.DeviceObjID;
            $scope.dealCloseModel.DealID = $scope.dealDetails.DealID;
            $scope.dealCloseModel.ActualDealCloseDate = utility.getDateInServerFormatFromToday(new Date()).toString();
            $scope.dealCloseModel.ActualDealRevenue = $scope.user.actualDealRevenue;
            $scope.dealCloseModel.ActualDealRevenueConverted = $scope.user.actualDealRevenueConverted;
            $scope.dealCloseModel.ActualDealRevenueCurrencyConvRate = $scope.user.dealRevenueCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealRevenueCurrencyID = $scope.user.dealRevenueCurrencyObject.CurrencyID;
            $scope.dealCloseModel.ActualDealSize = $scope.user.actualDealSize;
            $scope.dealCloseModel.ActualDealSizeConverted = $scope.user.actualDealSizeConverted;
            $scope.dealCloseModel.ActualDealSizeCurrencyConvRate = $scope.user.dealSizeCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealSizeCurrencyID = $scope.user.dealSizeCurrencyObject.CurrencyID;
            $scope.dealCloseModel.DealStageID = $scope.dealDetails.DealStageID;
            $scope.dealCloseModel.DealStageName = $scope.dealDetails.DealStageName;
            $scope.dealCloseModel.ModifiedBy = lgnUser.UserID;
            var dateStringInUTC = utility.getDateStringInUTC(new Date());
            $scope.dealCloseModel.ModifiedOn = dateStringInUTC;
            if(!(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == '')){
                $scope.dealCloseModel.CustomerID = $scope.user.actualDealCustomerID;
            }
            $scope.dealStageModelID = utility.dealStageModelIDCheck($scope.dealDetails.DealStageID);
            $scope.dealDetails.ActualDealSizeConverted = $scope.user.actualDealSizeConverted;
            $scope.dealDetails.ActualDealRevenueConverted = $scope.user.actualDealRevenueConverted;

            dealService.dealCloseToSql($scope.dealCloseModel).then(function(result){
                dealService.dealCloseLost($scope.dealCloseModel).then(function(res){
                    if(!(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == '')){
                        dealService.sqlUpdateContactCustomerID($scope.user.actualDealCustomerID, $scope.dealDetails.ContactDeviceObjID).then(function(customerRes){
                            //console.log("Deal Close Result is"+JSON.stringify(res));
                        },function(err){
                          alert(err);
                        });
                    }
                    //console.log("Deal Close Result is"+JSON.stringify(res));
                },function(err){
                    alert(err);
                });

            },function(err){
                alert(err);
            });


            $scope.modalDealStagesClose.hide();

        };

        /////////////////////////////////////////////////////////// Expected Deal Size Conversion ///////////////////////////////////////////////////////

        $scope.actualDealSizeConversion = function(){
            $scope.user.actualDealSizeConverted = ($scope.user.actualDealSize * $scope.user.dealSizeCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Expected Deal Revenue Conversion ///////////////////////////////////////////////////////

        $scope.actualDealRevenueConversion = function(){
            $scope.user.actualDealRevenueConverted = ($scope.user.actualDealRevenue * $scope.user.dealRevenueCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $scope.removeZero = function(){
            if($scope.user.actualDealSize == 0)
                $scope.user.actualDealSize = '';
            if($scope.user.actualDealRevenue == 0)
                $scope.user.actualDealRevenue = '';
        }

         /////////////////////////////////////////////////////////// Modal for Deal Stages Lost /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStagesLost.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesLost = modal;
        });

        $scope.openDealStagesLost = function (val) {
            $scope.modelSelected = val;
            $scope.modalDealStagesLost.show();
        };
        $scope.closeDealStagesLost = function () {
            $scope.dealDetails.DealStageID = $scope.selDealStages.previousDealStageID;
            $scope.dealDetails.DealStageName = $scope.selDealStages.previousDealStageName;
            $scope.modalDealStagesLost.hide();
        };

        $scope.actionDealStagesLost = function () {
            $scope.isEditButtonFlag = false;
            $scope.dealLostModel = dealService.dealCloseLostMod().uiObject;
            if ($scope.user.notes != '') {
                $scope.dealLostModel.DeviceObjID = $scope.dealDetails.DeviceObjID;
                $scope.dealLostModel.DealID = $scope.dealDetails.DealID;
                $scope.dealLostModel.DealStageID = $scope.dealDetails.DealStageID;
                $scope.dealLostModel.DealStageName = $scope.dealDetails.DealStageName;
                $scope.dealLostModel.ModifiedBy = lgnUser.UserID;
                var dateStringInUTC = utility.getDateStringInUTC(new Date());
                $scope.dealLostModel.ModifiedOn = dateStringInUTC;
                $scope.dealLostModel.Note = {
                    DeviceObjID: utility.generateUUID(),
                    EntityID: $scope.dealDetails.DealID,
                    ModuleID: GENERAL_CONFIG.MODULES.Deal,
                    NoteID: 0,
                    ParentDeviceObjID: $scope.dealDetails.DeviceObjID,
                    Description: $scope.user.notes,
                    CreatorID: lgnUser.UserID,
                    CreatorName: lgnUser.UserName,
                    CreatedOn: utility.getDateStringInUTC(new Date()),
                    CreatedAt: $scope.dealDetails.CreatedAt,
                    ModifiedBy: null,
                    ModifiedOn: utility.getDateStringInUTC(new Date()),
                    ModifiedAt: $scope.dealDetails.ModifiedAt
                };

            dealService.dealLostToSql($scope.dealLostModel).then(function(result){
                dealService.dealCloseLost($scope.dealLostModel).then(function(res){
                    //console.log("Deal Lost Result is"+JSON.stringify(res));
                    dealService.dealLostUpdateNotesToSql(res).then(function(result){

                       },function(err){
                            alert(err);
                       });
                },function(err){
                    alert(err);
                });
            },function(err){
                alert(err);
            });
            $scope.modalDealStagesLost.hide();
            }
        };

        ////////////////////////////////////////////////// More Menu Functionality /////////////////////////////////////////////////////////////

        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };

        /////////////////////////////////////////////////// Email Deal Details ////////////////////////////////////////////////////////////////

        $scope.emailDealDetails = function(){
            dealService.emailDealDetails($scope.dealDetails.DealID).then(function (dealEmailRes) {
                //console.log('Deal Details Email Response is'+JSON.stringify(dealEmailRes));
                 $cordovaDialogs.alert('Deal Details Emailed Successfully.', 'Sales ARM', 'OK')
                    .then(function() {
                    });
            },function (err) {
                //console.log('Email Deal Details');
            });
        };

    };

})();
