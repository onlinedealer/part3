import { Component, Input, Output, EventEmitter, OnInit, OnDestroy, ChangeDetectionStrategy } from "@angular/core";
import { OnDemandReadingService } from "../../../models/ondemandreading.model";
import { FormControl } from "@angular/forms";
import { Subscription } from "rxjs";

@Component({
    selector: "landisgyr-ondemandreading-services-selection",
    templateUrl: "./odr-services-selection.component.html",
    styleUrls: ["./odr-services-selection.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OnDemandReadingServicesSelectionComponent implements OnInit, OnDestroy {
    selected_services = new FormControl();
    changeSubscription: Subscription | undefined;

    @Input()
    onDemandReadingServices!: OnDemandReadingService[];

    @Output()
    selectedOnDemandReadingServices: EventEmitter<OnDemandReadingService[]> = new EventEmitter<OnDemandReadingService[]>();

    ngOnInit() {
        this.changeSubscription = this.selected_services.valueChanges.subscribe(value => {
            this.selectedOnDemandReadingServices.next(value);
        });
    }

    ngOnDestroy() {
        if (this.changeSubscription) {
            this.changeSubscription.unsubscribe();
        }
    }
}
