import { TranslationsService } from "../../../app/services/translations-service";
import { Type } from "@angular/core";
import { getInjector } from "../../../app/app-injector";

export function getMeteringpointsXSFSearchFields(): { key: string; value: string; type: string }[] {
    const translationsService = getInjector().get<TranslationsService>(TranslationsService as Type<TranslationsService>);
    return [
        {
            key: "meteringPointName",
            value: translationsService.getTranslation("Metering point"),
            type: "text"
        },
        {
            key: "gsrn",
            value: translationsService.getTranslation("GSRN"),
            type: "text"
        },
        {
            key: "deviceNumber",
            value: translationsService.getTranslation("Device number"),
            type: "number"
        },
        {
            key: "streetName",
            value: translationsService.getTranslation("Street name"),
            type: "text"
        },
        {
            key: "zipCode",
            value: translationsService.getTranslation("Postal code"),
            type: "text"
        },
        {
            key: "customerName",
            value: translationsService.getTranslation("Customer name"),
            type: "text"
        },
        {
            key: "customerNumber",
            value: translationsService.getTranslation("Customer number"),
            type: "text"
        },
        {
            key: "utilitySerialNumber",
            value: translationsService.getTranslation("Customer property number"),
            type: "text"
        }
    ];
}
