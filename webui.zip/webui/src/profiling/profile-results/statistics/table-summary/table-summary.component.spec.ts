import { Spies } from 'discovery-test';
import { TableSummaryComponent } from './table-summary.component';

describe('TableSummaryComponent', () => {
  let component: TableSummaryComponent;

  beforeEach(async () => {});

  beforeEach(() => {
    Spies.init();
    component = new TableSummaryComponent(Spies.ProfileResultsService, Spies.Router, Spies.ActivatedRoute);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call profileResultsService on ngOnInit', () => {
    Spies.ProfileResultsService.getTableSummary.and.returnValue({
      headers: [{ field: 'CC' }],
      data: [{ column: 'CC' }]
    });
    component.loadData();
    expect(component.cols[0].field).toBe('CC');
    expect(component.data[0].column).toBe('CC');
  });
});
