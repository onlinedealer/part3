(function() {
    'use strict';

    codeathonApp.controller("loginCtrl", ['$scope', '$ajaxFactory', 'uiRouters', '$location', 'Idle', loginCtrl]);

    function loginCtrl($scope, $ajaxFactory, uiRouters, $location, Idle) {
        Codeathon.utils.hideHeaderFooterMenu();
        $scope.isDisplay = false;
        $scope.errormsg = "";
        $scope.userName = "";
        $scope.userPass = "";


        function validationForm() {
            var validUser = false;

            if ($scope.loginForm.$invalid) {

                if ($scope.loginForm.email.$invalid) {
                    $scope.isNameEmpty = true;
                    validUser = true;
                }

                if ($scope.loginForm.password.$invalid) {
                    $scope.isPwdEmpty = true;
                    validUser = true;
                }

            }

            return validUser;
        };
        $scope.authenticateUser = function() {
            $scope.isDisplay = false;

            if (!validationForm()) {
                var obj = {}
                obj.login = $scope.userName;
                obj.password = $scope.userPass;

                var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/login/response.json', 'POST', obj);
               // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + '/login/', 'POST', obj);

                promise.then(function(d) {
                    if (d.code == "000") {
                        indicatorStart(uiRouters.dashboardmsg);
                        Idle.watch();                        
                        $location.url(uiRouters.dashboard);
                        Codeathon.utils.setSessionItem('userId', d.userId);
                        Codeathon.utils.setSessionItem('ravindra', "test");
                        
                    } else {
                        $scope.isDisplay = true;
                        $scope.errormsg = d.desc;
                    }
                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
                promise.finally(function(d) {
                    console.log('finally block executed', d);
                });
            }

        };

    }

})();
