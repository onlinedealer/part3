import { createMuiTheme } from '@material-ui/core/styles'

export const praxis = {
  light: '#f05545',
  main: '#1967d2',
  dark: '#1967d2',
  contrastText: '#fff',
}

const praxisTheme = createMuiTheme({
  palette: {
    primary: praxis,
    secondary: praxis,
  },
})

export default praxisTheme
