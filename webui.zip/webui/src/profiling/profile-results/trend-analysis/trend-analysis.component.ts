import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, Input } from '@angular/core';
import { EventBusService } from 'core/eventBusService';
import { SharedConstants } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { ProfileMetadataModel } from '../profile-metadata.model';
import { ProfileResultsService } from '../profile-results.service';
import { TreePath } from '../tree-path.model';

@Component({
  selector: 'discovery-trend-analysis',
  templateUrl: './trend-analysis.component.html',
  styleUrls: ['./trend-analysis.component.css']
})
export class TrendAnalysisComponent implements OnInit {
  graphTimeframe: string;
  fetchingTrends: boolean;

  @Input() statistic: string;
  @Input() profileMetadata: ProfileMetadataModel;
  @Input() treePath: TreePath;
  @Input() lastRun: Date;

  trendData: any = [];

  constructor(
    private eventBusService: EventBusService,
    private profileResultsService: ProfileResultsService,
    private toastrService: ToastrService
  ) {}

  ngOnInit(): void {
    this.loadData();
  }
  emptyTrends() {
    this.trendData = [];
    this.eventBusService.emit('TrendsSidebarToggle', { flag: false });
  }

  loadData() {
    this.fetchingTrends = true;
    let fromDate: Date = new Date(this.lastRun);

    if (this.graphTimeframe === 'all') {
      fromDate = null;
    } else {
      let numericalTimeFrame = 7;

      if (this.graphTimeframe === 'month') {
        numericalTimeFrame = 30;
      } else if (this.graphTimeframe === 'year') {
        numericalTimeFrame = 365;
      }
      fromDate.setDate(fromDate.getDate() - numericalTimeFrame);
    }

    let assetPath = `[${this.profileMetadata.host}].[${this.profileMetadata.db}].[${this.profileMetadata.schema}].[${this.treePath.tableName.name}]`;

    if (this.treePath.columnView) {
      assetPath = assetPath + '.[' + this.treePath.columnName.name + ']';
    }

    this.profileResultsService
      .getTrendsHistory(assetPath, SharedConstants.trendsKeys[this.statistic], fromDate)
      .subscribe(
        (trends) => {
          this.fetchingTrends = false;
          this.trendData = trends;
        },
        (error: HttpErrorResponse) => {
          this.fetchingTrends = false;
          this.toastrService.error(error?.message);
        }
      );
  }

  updateTrends(event) {
    this.graphTimeframe = (event.target as HTMLInputElement).value;
    this.loadData();
  }
}
