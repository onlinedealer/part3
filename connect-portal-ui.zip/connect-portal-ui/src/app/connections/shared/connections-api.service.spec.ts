import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Connection } from './connection';
import { ConnectionsApiService } from './connections-api.service';

describe('ConnectionsService', () => {
  let service: ConnectionsApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  const mockConnection: Connection = {
    id: '1',
    name: 'test'
  } as Connection;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(ConnectionsApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should verify a connection', () => {
    let actualResponse;
    service.verify(mockConnection).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/verify');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(mockConnection);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });
});
