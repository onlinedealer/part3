import { Component, Input, ViewChild, OnInit, Output, EventEmitter } from '@angular/core';
import { SidebarButton } from 'src/app/shared/components/sidebar/sidebar-button';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { ChangeColumnMappingDefaultsTabComponent } from './change-column-mapping-defaults-tab/change-column-mapping-defaults-tab.component';
import { Pipeline, TableMapping } from '../../../shared/pipeline';
import { ChangeColumnMappingChangesTabComponent } from './change-column-mapping-changes-tab/change-column-mapping-changes-tab.component';
import { cloneDeep } from 'lodash';
import { TranslocoService } from '@ngneat/transloco';
@Component({
  selector: 'p-connect-change-column-mapping-sidebar',
  templateUrl: './change-column-mapping-sidebar.component.html',
  styleUrls: ['./change-column-mapping-sidebar.component.scss']
})
export class ChangeColumnMappingSidebarComponent implements OnInit {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(ChangeColumnMappingDefaultsTabComponent) changeColumnMappingDefaultsTabComponent: ChangeColumnMappingDefaultsTabComponent;
  @ViewChild(ChangeColumnMappingChangesTabComponent) changesTab: ChangeColumnMappingChangesTabComponent;
  @Output() updatedTableMapping = new EventEmitter<any>();

  @Input() checkedItems: any;
  @Input() data: any;
  @Input() pipeline: Pipeline;
  updateDefaultsButton: boolean = false;
  selectedTopics;
  isTargetExists: boolean;
  defaultsData: any;
  columnMappingType;
  activeTabIndex: number;
  changesTabDisabled: boolean;
  storeDefaultsTabData;
  isUpdateDefaultClicked: boolean = false;
  tableMapping: TableMapping[];

  cancelButton: SidebarButton = {
    id: 'cancelButton',
    text: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.BUTTONS.CANCEL_BUTTON'
  };
  primaryButton: SidebarButton = {
    id: 'primaryButton',
    text: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.BUTTONS.PRIMARY_BUTTON',
    isDisabled: false
  };

  secondaryButton: SidebarButton = {};

  constructor(private readonly mappingService: PipelineMappingService, private readonly translocoService: TranslocoService) {}

  disableSaveButtonIfUncheckAll(index) {
    this.primaryButton.isDisabled = !index;
  }

  disableSaveBtn() {
    let excludeCoundt = 0;
    this.defaultsData?.forEach((element) => {
      if (element.cdcRowMetadataType === 'EXCLUDE') {
        excludeCoundt++;
      }
    });
    if (excludeCoundt === this.defaultsData.length) {
      this.disableSaveButtonIfUncheckAll(false);
    }
  }

  ngOnInit(): void {
    this.disableUpdateDefaultsButton(this.changesTab?.changesTabFormGroup?.value);
  }

  getSelectedTopicsCount() {
    let count = [];
    this.checkedItems?.forEach((element) => {
      if (element.topic.name !== '') {
        count.push(element);
      }
    });
    this.selectedTopics = count;
    if (this.selectedTopics.length === 0) {
      this.changesTabDisabled = true;
      this.handleOptionsForTab(1);
    } else {
      this.changesTabDisabled = false;
      this.handleOptionsForTab(0);
    }
  }

  open(target: boolean, defaultsData, columnMapping) {
    this.isTargetExists = target;
    this.defaultsData = cloneDeep(defaultsData);
    this.metadataAlphabeticalSort();
    this.changeColumnMappingDefaultsTabComponent.defaultsMetaData = this.defaultsData;
    this.columnMappingType = columnMapping;
    this.changesTab.loadChangesTab();
    this.sidebarComponent.open();
    if (this.checkedItems?.length > 0) {
      this.handleOptionsForTab(0);
      this.changesTabDisabled = false;
    } else {
      this.handleOptionsForTab(1);
      this.changesTabDisabled = true;
    }
    this.getSelectedTopicsCount();
  }
  close() {
    this.sidebarComponent.close();
  }
  metadataAlphabeticalSort() {
    this.defaultsData = this.defaultsData.map((object) => ({
      ...object,
      displayLabel: this.translocoService.translate(
        `pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ROW_METADATA_FIELDS.` + object.key
      )
    }));
    this.defaultsData.sort((a, b) => {
      return a.displayLabel.toLowerCase().localeCompare(b.displayLabel.toLowerCase());
    });
  }
  handleTabChange(event) {
    if (event.index == 0) {
      this.handleOptionsForTab(0);
    } else {
      this.handleOptionsForTab(1);
      this.sidebarComponent.message = null;
    }
  }
  handleOptionsForTab(index) {
    if (index == 0) {
      this.activeTabIndex = 0;
      this.secondaryButton = {
        isDisabled: true,
        id: 'secondaryButton',
        text: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.BUTTONS.SECONDARY_BUTTON'
      };
      this.defaultsData = this.storeDefaultsTabData?.length > 0 ? cloneDeep(this.storeDefaultsTabData) : this.defaultsData;
    } else {
      this.activeTabIndex = 1;
      this.secondaryButton = {};
      this.defaultsData = this.storeDefaultsTabData?.length > 0 ? cloneDeep(this.storeDefaultsTabData) : this.defaultsData;
    }
  }

  processPayloadForSavingChangesTab(formValues, checkedItems) {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: null,
      columnMappingType: null
    };

    checkedItems?.forEach((row) => {
      payload.tableMappingIdList.push(row?.id);
    });
    this.setMapColumnDropDownValues(formValues, payload);
    this.setRowMetaDataDropdownValues(formValues, payload);
    return payload;
  }

  returnColumnMappingType(type: string) {
    if (type === 'COLUMN_NAME') {
      return 'NAME';
    } else {
      return 'ORDINAL';
    }
  }

  enableUpdateDefaultsButton() {
    this.secondaryButton.isDisabled = false;
  }

  setMapColumnDropDownValues(formValues, payload) {
    if (this.isTargetExists) {
      if (formValues.mapColumnsByDropdown.value === 'DO_NOT_CHANGE') {
        payload.columnMappingType = null;
      } else if (formValues.mapColumnsByDropdown.value === 'COLUMN_NAME') {
        payload.columnMappingType = this.returnColumnMappingType(formValues.mapColumnsByDropdown.value);
      } else if (formValues.mapColumnsByDropdown.value === 'COLUMN_ORDER') {
        payload.columnMappingType = this.returnColumnMappingType(formValues.mapColumnsByDropdown.value);
      } else if (formValues.mapColumnsByDropdown.value === 'USE_DEFAULT') {
        payload.columnMappingType = this.returnColumnMappingType(this.columnMappingType);
      }
    } else {
      payload.columnMappingType = null;
    }
  }

  setRowMetaDataDropdownValues(formValues, payload) {
    const getUpdateDefaultsPayload = this.changesTab.getBulkChangePayload();
    if (formValues?.rowMetaDataDropdown.value === 'DO_NOT_CHANGE') {
      payload.cdcRowMetadata = null;
    } else if (formValues?.rowMetaDataDropdown.value === 'SELECT_ROW_METADATA') {
      payload.cdcRowMetadata = getUpdateDefaultsPayload?.payload;
    } else if (formValues?.rowMetaDataDropdown.value === 'NO_ROW_METADATA') {
      payload.cdcRowMetadata = getUpdateDefaultsPayload?.payload;
    } else if (formValues?.rowMetaDataDropdown.value === 'USE_DEFAULT') {
      payload.cdcRowMetadata = getUpdateDefaultsPayload?.payload;
    }
  }

  disableUpdateDefaultsButton(event) {
    if (this.isTargetExists) {
      if (event.rowMetaDataDropdown.value === 'DO_NOT_CHANGE' || event.mapColumnsByDropdown?.value === 'DO_NOT_CHANGE') {
        this.secondaryButton.isDisabled = true;
      } else {
        this.secondaryButton.isDisabled = false;
      }
    } else {
      if (event?.rowMetaDataDropdown?.value === 'DO_NOT_CHANGE' || event?.rowMetaDataDropdown?.value === 'USE_DEFAULT') {
        this.secondaryButton.isDisabled = true;
      } else {
        this.secondaryButton.isDisabled = false;
      }
    }
  }

  updataDefaultsButtonClicked() {
    let isIncludeExists;
    this.secondaryButton.isDisabled = true;
    this.sidebarComponent.isProcessingRequest = true;
    const getUpdateDefaultsPayload = this.changesTab.getChangesPayloadData();
    if (getUpdateDefaultsPayload != undefined) {
      isIncludeExists = Object.keys(getUpdateDefaultsPayload?.payload).some((key) => getUpdateDefaultsPayload?.payload[key] == 'INCLUDE');
    }
    let selectedDropdownValue = this.changesTab.changesTabFormGroup.value?.rowMetaDataDropdown.value;

    if (isIncludeExists) {
      this.saveChangeColumnMappingDefaultsOnUpdate(getUpdateDefaultsPayload);
    } else if (!isIncludeExists && selectedDropdownValue == 'NO_ROW_METADATA') {
      this.saveChangeColumnMappingDefaultsOnUpdate(getUpdateDefaultsPayload);
    } else {
      this.rowMetadataValidationFails();
    }
  }

  saveChangeColumnMappingDefaultsOnUpdate(getUpdateDefaultsPayload) {
    this.mappingService.saveChangeColumnMappingDefaults(this.pipeline?.id, getUpdateDefaultsPayload).subscribe({
      next: () => {
        this.storeDefaultsTabData = cloneDeep(this.defaultsData);
        this.changeColumnMappingDefaultsTabComponent.loadDefaultTab(true);
        const success = {
          message: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.DEFAULTS_UPDATED_SUCCESSFULLY'
        };
        if (this.sidebarComponent?.parseHttpClientResponseMessage) {
          this.sidebarComponent.parseHttpClientResponseMessage('success', success);
        }
        this.sidebarComponent.isProcessingRequest = false;
      },
      error: (errorResponse) => {
        this.sidebarComponent.isProcessingRequest = false;
        if (this.sidebarComponent?.parseHttpClientResponseMessage) {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      }
    });
  }

  saveButtonClicked() {
    this.sidebarComponent.isProcessingRequest = true;

    if (this.activeTabIndex === 0) {
      const payLoad = this.processPayloadForSavingChangesTab(this.changesTab.changesTabFormGroup.value, this.selectedTopics);
      let isIncludeExists = payLoad.cdcRowMetadata?.some((element) => element.value == 'INCLUDE');
      let selectedDropdownValue = this.changesTab.changesTabFormGroup.value?.rowMetaDataDropdown.value;

      if (isIncludeExists || selectedDropdownValue == 'DO_NOT_CHANGE') {
        this.bulkChangeColumnMapping(payLoad);
      } else if (!isIncludeExists && selectedDropdownValue == 'NO_ROW_METADATA') {
        this.bulkChangeColumnMapping(payLoad);
      } else {
        this.rowMetadataValidationFails();
      }
    } else {
      let isIncludeExists;
      const data = this.changeColumnMappingDefaultsTabComponent?.getDefaultsPayloadData();
      if (data != undefined) {
        isIncludeExists = Object.keys(data?.payload).some((key) => data?.payload[key] == 'INCLUDE');
      }
      if (isIncludeExists) {
        this.saveChangeColumnMappingDefaults(data);
      } else if (
        !isIncludeExists &&
        this.changeColumnMappingDefaultsTabComponent.defaultsTabFormGroup.value?.includeRowMetaDataDropdown.value == 'NO_ROW_METADATA'
      ) {
        this.saveChangeColumnMappingDefaults(data);
      } else {
        this.rowMetadataValidationFails();
      }
    }
  }

  bulkChangeColumnMapping(payLoad) {
    this.mappingService.bulkChangeColumnMapping(this.pipeline?.id, payLoad).subscribe({
      next: () => {
        this.close();
        this.mappingService.refreshTableMappingGrid?.next();
        this.sidebarComponent.isProcessingRequest = false;
      },
      error: (errorResponse) => {
        this.sidebarComponent.isProcessingRequest = false;
        this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
      }
    });
  }

  saveChangeColumnMappingDefaults(payLoad) {
    this.mappingService.saveChangeColumnMappingDefaults(this.pipeline?.id, payLoad).subscribe({
      next: () => {
        this.storeDefaultsTabData = cloneDeep(this.defaultsData);
        this.mappingService.refreshTableMappingGrid?.next();
        this.close();
        this.sidebarComponent.isProcessingRequest = false;
      },
      error: (errorResponse) => {
        this.sidebarComponent.isProcessingRequest = false;
        this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
      }
    });
  }

  rowMetadataValidationFails() {
    const error = {
      message: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ROW_METADATA_MUST_BE_SELECTED'
    };
    this.sidebarComponent.isProcessingRequest = false;
    this.sidebarComponent.parseHttpClientResponseMessage('user_generated_error', error);
  }
  updateHasCustomColMapping(selectedDdlValue, selectedTable) {
    this.tableMapping?.map((ele, index) => {
      if (ele.id == selectedTable[index].id) {
        ele.hasCustomColMappings = selectedDdlValue?.rowMetaDataDropdown?.value == 'DO_NOT_CHANGE' ? ele.hasCustomColMappings : true;
        this.updatedTableMapping.emit({ hasCustomColMappings: ele.hasCustomColMappings, rowId: ele.id });
      }
    });
  }
}
