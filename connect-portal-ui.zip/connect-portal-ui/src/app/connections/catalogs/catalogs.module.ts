import { CommonModule, DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SharedModule } from '../../shared/shared.module';
import { ManageCatalogSidebarComponent } from './manage-catalog-sidebar/manage-catalog-sidebar.component';
import { ManageCatalogComponent } from './manage-catalog-sidebar/manage-catalog/manage-catalog.component';
import { DeleteCatalogSidebarComponent } from './manage-catalog-sidebar/delete-catalog-sidebar/delete-catalog-sidebar.component';
import { DeleteCatalogFormComponent } from './manage-catalog-sidebar/delete-catalog-sidebar/delete-catalog-form/delete-catalog-form.component';
import { TooltipModule } from 'primeng/tooltip';
import { commonLoader, serversLoader, connectionsLoader, pngLoader } from '../../i18n-loaders';
import { CatalogingErrorSidebarComponent } from './cataloging-error-sidebar/cataloging-error-sidebar.component';
import { CatalogingErrorFormComponent } from './cataloging-error-sidebar/cataloging-error-form/cataloging-error-form.component';
import { RouterModule } from '@angular/router';
import { AccordionModule } from 'primeng/accordion';

@NgModule({
  declarations: [
    ManageCatalogSidebarComponent,
    ManageCatalogComponent,
    DeleteCatalogSidebarComponent,
    DeleteCatalogFormComponent,
    CatalogingErrorSidebarComponent,
    CatalogingErrorFormComponent
  ],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'servers', loader: serversLoader },
        { scope: 'connections', loader: connectionsLoader },
        { scope: 'png', loader: pngLoader }
      ]
    },
    DatePipe
  ],
  imports: [CommonModule, SharedModule, TranslocoModule, TooltipModule, RouterModule, AccordionModule],
  exports: [ManageCatalogSidebarComponent, ManageCatalogComponent, DeleteCatalogSidebarComponent]
})
export class CatalogsModule {}
