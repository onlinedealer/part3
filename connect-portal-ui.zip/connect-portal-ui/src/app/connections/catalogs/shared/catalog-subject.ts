export interface CatalogSubject {
  lastCompleted: string;
  status: string;
  schemasCompleted: number;
  schemasCount: number;
  subject: string;
}
