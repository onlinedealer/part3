import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AlertsSidebarComponent } from './alerts-sidebar.component';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SidebarModule } from 'primeng/sidebar';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { PipelinesMonitoringApiService } from '../shared/pipelines-monitoring-api.service';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';
import { of, throwError } from 'rxjs';
import { ServersApiService } from '../../servers/shared/servers-api.service';
import { Server } from '../../servers/shared/server';
import { DropdownModule } from 'primeng/dropdown';
import { ProjectsApiService } from '../pipeline/shared/projects-api.service';
import { Project } from '../pipeline/shared/project';
import { FeatureFlagService } from '@shared/services/feature-flag.service';

describe('AlertsSidebarComponent', () => {
  let component: AlertsSidebarComponent;
  let fixture: ComponentFixture<AlertsSidebarComponent>;
  let pipelinesMonitoringApiService: PipelinesMonitoringApiService;
  let serversApiService: ServersApiService;
  let projectsApiService: ProjectsApiService;

  const mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

  const mockData = [
    {
      host: 'server1',
      id: '61b34028433686526f2f758b',
      level: 'INFO',
      levelInt: 20000,
      localTime: 1639137320,
      message: 'Connection refused (Connection refused)',
      projectId: '61b338e7433686526f2f7589',
      remoteTime: '',
      tenantId: 'Precisely'
    }
  ];

  const mockRuntimeServers = [
    { id: '0', name: 'test1', serverType: 'REPLICATION' } as Server,
    { id: '1', name: 'test2', serverType: 'REPLICATION' } as Server
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DropdownModule, SidebarModule, getTranslocoModule(), HttpClientTestingModule, RouterTestingModule],
      declarations: [AlertsSidebarComponent, SidebarComponent],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'filters' } },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(AlertsSidebarComponent);
    component = fixture.componentInstance;
    serversApiService = TestBed.inject(ServersApiService);
    spyOn(serversApiService, 'getAll').and.returnValue(of(mockRuntimeServers));
    pipelinesMonitoringApiService = TestBed.inject(PipelinesMonitoringApiService);
    projectsApiService = TestBed.inject(ProjectsApiService);
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ name: 'new project' } as Project));
    spyOn(pipelinesMonitoringApiService, 'getAlerts').and.returnValue(of(mockData as any));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get alerts', () => {
    component.alertsTableConfiguration.createButtonClicked();
    expect(component.alertsList[0]).toEqual({
      host: 'server1',
      id: '61b34028433686526f2f758b',
      level: 'INFO',
      levelInt: 20000,
      localTime: 1639137320,
      message: 'Connection refused (Connection refused)',
      projectId: '61b338e7433686526f2f7589',
      remoteTime: new Date(mockData[0].localTime * 1000).toLocaleString(),
      tenantId: 'Precisely'
    });
  });

  it('should handle errors when returning alerts', () => {
    spyOn(pipelinesMonitoringApiService, 'getAlerts').and.returnValue(throwError({}));
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    component.alertsTableConfiguration.createButtonClicked();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should return the correct styles for each alert type', () => {
    expect(component.getAlertStatusIconClass('ERROR')).toEqual(['png-alert-actionrequired-solid', 'text-danger']);
    expect(component.getAlertStatusIconClass('WARN')).toEqual(['png-alert-attention-solid', 'text-warning']);
    expect(component.getAlertStatusIconClass('INFO')).toEqual(['png-alert-info-solid', 'text-info']);
    expect(component.getAlertStatusIconClass('SOMETHING_ELSE')).toEqual([]);
  });

  it('should close sidebar', () => {
    spyOn(component.sidebarComponent, 'close');
    component.onClose();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should open sidebar', () => {
    spyOn(component.sidebarComponent, 'open');
    component.open('test');
    expect(component.selectedRuntimeEngine).toEqual('test');
    expect(pipelinesMonitoringApiService.getAlerts).toHaveBeenCalled();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should expect selectedRuntimeEngine to default to All value, if alerts-sidebar opened via global toolbar', () => {
    component.open();
    expect(component.selectedRuntimeEngine).toEqual('All');
  });

  it('should navigate to the specified route onClose', () => {
    component.onCloseRoute = 'newRoute';
    spyOn(component, 'navigateTo');
    component.onClose();
    expect(component.navigateTo).toHaveBeenCalledWith('newRoute');
  });

  it('should update the last refreshed time on clicking refresh', () => {
    spyOn(Date.prototype, 'toLocaleString').and.returnValue('2020-04-15');
    component.alertsTableConfiguration.createButtonClicked();
    expect(component.lastRefreshedTime).toEqual('2020-04-15');
  });

  it('should get the servers list', () => {
    component.servers$.subscribe((servers) => {
      expect(servers).toEqual(['All', 'test1', 'test2']);
    });
  });

  it('should get the project name and description', () => {
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(
      of({ name: 'new project', description: 'my project description' } as Project)
    );
    component.open();
    expect(projectsApiService.getDefaultProject).toHaveBeenCalled();
    expect(component.project.name).toBe('new project');
    expect(component.project.description).toBe('my project description');
  });

  it('should handle errors when getting default project', () => {
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(throwError({}));
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage');
    component.open();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });
});
