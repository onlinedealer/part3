import { Component, ChangeDetectionStrategy, Input, OnInit } from "@angular/core";
import { MatRadioChange } from "@angular/material/radio";
import { MeteringDataUIActions, PrepaymentActions } from "../../../store/actions";
import { MeteringDataUISelectors, PrepaymentSelectors } from "../../../store/selectors";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { Store } from "@ngrx/store";

@Component({
    selector: "landisgyr-metering-data-times-selector",
    templateUrl: "./ss-metering-data-times-selector.component.html",
    styleUrls: ["./ss-metering-data-times-selector.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSMeteringDataTimesSelectorComponent implements OnInit {
    @Input()
    tab!: string;
    @Input() meteringType!: string;
    @Input() dateRangeId!: string;
    @Input() isProfileDataEdited!: boolean;
    meteringDataTimesSelection$!: any;
    prepaymentDataTimesSelection$!: any;
    prepaymentDataTokenLogTimesSelection$!: any;

    constructor(private store: Store<MeteringPointsFeatureState>) {}

    ngOnInit() {
        if (this.tab === "metering") {
            this.meteringDataTimesSelection$ = this.store.select(MeteringDataUISelectors.getMeteringDataTimesSelection);
        }
        if (this.tab === "prepayment") {
            this.prepaymentDataTimesSelection$ = this.store.select(PrepaymentSelectors.getPrepaymentDateRange);
        }
        if (this.tab === "tokenlog") {
            this.prepaymentDataTokenLogTimesSelection$ = this.store.select(PrepaymentSelectors.getPrepaymentTokenLogDateRange);
        }
    }

    onRadioChanged(event: MatRadioChange) {
        if (event.value) {
            if (this.tab === "metering") {
                this.store.dispatch(MeteringDataUIActions.SelectMeteringDataRadio({ value: event.value }));
            }
            if (this.tab === "prepayment") {
                this.store.dispatch(PrepaymentActions.SelectPrepaymentDataRadio({ value: event.value }));
            }
            if (this.tab === "tokenlog") {
                this.store.dispatch(PrepaymentActions.SelectPrepaymentTokenLogDataRadio({ value: event.value }));
            }
        }
    }

    onPeriodSelectionChanged(period: string) {
        if (this.tab === "metering") {
            this.store.dispatch(MeteringDataUIActions.SelectMeteringDataPeriod({ period }));
        }
        if (this.tab === "prepayment") {
            this.store.dispatch(PrepaymentActions.SelectPrepaymentDataPeriod({ period }));
        }
        if (this.tab === "tokenlog") {
            this.store.dispatch(PrepaymentActions.SelectPrepaymentTokenLogDataPeriod({ period }));
        }
    }

    onTimePeriodChanged(timePeriod: { from: number; until: number }) {
        if (timePeriod && timePeriod.from !== null && timePeriod.until !== null) {
            if (this.tab === "metering") {
                this.store.dispatch(
                    MeteringDataUIActions.SetMeteringDataTimes({
                        from: timePeriod.from,
                        until: timePeriod.until
                    })
                );
            }
            if (this.tab === "prepayment") {
                this.store.dispatch(
                    PrepaymentActions.SetPrepaymentDataTimes({
                        from: timePeriod.from,
                        until: timePeriod.until
                    })
                );
            }
            if (this.tab === "tokenlog") {
                this.store.dispatch(
                    PrepaymentActions.SetPrepaymentTokenLogsDataTimes({
                        from: timePeriod.from,
                        until: timePeriod.until
                    })
                );
            }
        }
    }
}
