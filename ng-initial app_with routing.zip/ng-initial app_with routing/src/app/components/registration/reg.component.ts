import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-reg',
  templateUrl: './reg.component.html',
  styleUrls: ['./reg.component.css']
})
export class RegComponent {
  model: any = {};
  _postsArray;
  signOut;
  constructor(private http: HttpClient){
  }

  ngOnInit(): void {
      this.http.get('https://reqres.in/api/users?page=2').subscribe(data => {
        this._postsArray = data.data;
      });
    }
  }

  signOut(){
    this.router.navigate(['/reg']);
  }
  // onSubmit() {
  //   if(this.model.firstName == 'login@gmail.com' && this.model.password == 'admin123'){
  //     alert(JSON.stringify(this.model));
  //   }
  // }
}