/* eslint-disable no-bitwise */
import { ConnectionOptionModel } from './connection-option.model';

export class ConnectionModel {
  id: string;
  name: string;
  readOnly: boolean;
  resourceConnectionType: string;
  options: ConnectionOptionModel[];
  progress: number;
  dataProfiles: number;
  tenantId: string;
  createdAt: Date;
  createdBy: string;

  constructor() {
    this.options = [];
    this.resourceConnectionType = '';
  }
}
