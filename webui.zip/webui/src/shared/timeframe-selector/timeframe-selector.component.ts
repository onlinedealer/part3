import { Component, EventEmitter, Input, Output } from '@angular/core';

export interface TimeFrameSelector {
  name: string;
  value: string;
}

const TIME_FRAMES: TimeFrameSelector[] = [
  {
    name: 'discoveryAlerts.infoPanel.stats.timeframes.week',
    value: 'week'
  },
  {
    name: 'discoveryAlerts.infoPanel.stats.timeframes.month',
    value: 'month'
  },
  {
    name: 'discoveryAlerts.infoPanel.stats.timeframes.year',
    value: 'year'
  },
  {
    name: 'discoveryAlerts.infoPanel.stats.timeframes.all',
    value: 'all'
  }
];

@Component({
  selector: 'discovery-timeframe-selector',
  templateUrl: './timeframe-selector.component.html'
})
export class TimeframeSelectorComponent {
  timeSelectionDropdown: TimeFrameSelector[];
  @Input() selectedTimeFrame: string;
  @Input() id: string = 'timeframe-selector';

  @Output() timeframeChange: EventEmitter<string> = new EventEmitter<string>();
  constructor() {
    this.timeSelectionDropdown = TIME_FRAMES;
  }

  // onUpdateTimeFrame
}
