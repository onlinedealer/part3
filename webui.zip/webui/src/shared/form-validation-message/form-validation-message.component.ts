import { Component, EventEmitter, Input, Output } from '@angular/core';
import { SafeHtmlPipe } from 'shared/safe-html.pipe';
import { ValidationMessageTypeModel } from './validation-message-type.model';
import { ValidationMessage } from './validation-message.model';

@Component({
  selector: 'discovery-form-validation-message',
  templateUrl: './form-validation-message.component.html',
  styleUrls: ['./form-validation-message.component.css'],
  providers: [SafeHtmlPipe]
})
export class FormValidationMessageComponent {
  /**
   *
   */
  @Input() validationMessages: ValidationMessage[] = [];
  @Input() isPersistant: boolean;
  /**
   *
   */
  @Input() validationMessageType: ValidationMessageTypeModel;

  @Output() action: EventEmitter<string> = new EventEmitter<string>();

  @Output() messageClose: EventEmitter<any> = new EventEmitter<any>();

  /**
   *
   */
  ValidationMessageTypeModel: typeof ValidationMessageTypeModel = ValidationMessageTypeModel;

  /**
   *
   */
  constructor() {
    this.validationMessageType = ValidationMessageTypeModel.Error;
  }

  /**
   *
   */
  hasMessages(): boolean {
    return this.validationMessages.length > 0;
  }

  /**
   *
   */
  closeMessage(): void {
    this.messageClose.emit({ type: this.validationMessageType, message: this.validationMessages[0] });
    this.validationMessages = [];
  }

  performAction(): void {
    this.action.emit('');
  }
}
