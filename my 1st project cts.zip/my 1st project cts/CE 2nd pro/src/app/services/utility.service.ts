import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {BehaviorSubject, Observable} from "rxjs";


import {environment} from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UtilityService {
  
  constructor(private router: Router, private http: HttpClient) { 
  }
  
  host = {
    url:'',
    type:''
  }
  isEnablePrint128C:boolean = false;
  serviceUrls$: BehaviorSubject<any> = new BehaviorSubject('');
  serviceUrlsObservable$ = this.serviceUrls$.asObservable();
  expandedSection = {
    type: '',
    index: ''
  }

/**
 * Returns host information
 */
  getHostInfo(){
    
    if(window.location.href.indexOf('localhost') > 0){
      this.host.url = window.location.protocol+"//"+window.location.host + '/webcontent/ng-extracare/extracare_leanNg6';
      this.host.type = 'staging';
    }else{
      /* For production */
      /*this.host.url = window.location.protocol+"//"+window.location.host;
      this.host.type = 'live';*/

      /* Temporary mocking data for lower environments */
      this.host.url = "https://www-it1.cvs.com/webcontent/ng-extracare/extracare_leanNg6";
      this.host.type = 'staging';
    }
    return this.host;
  }

/**
 * Get host name
 */
  getHostName() {
    let hostName = '';
    if (window.location.href.indexOf('localhost') > -1) {
        hostName = "https://www-qa2.cvs.com";
    } else {
        hostName = "https://" + window.location.host;
    }
    return hostName;
  }


/**
 * Function to send request to the server. If payload is passed then it will be treated as post request or else get request.
 */
   sendRequest(url,  payload = {}, headers={}, host='', queryParams = ''){

     if(this.host.url === ''){
        this.getHostInfo();
     }

     if(this.host.type =='staging'){
       payload = {};
       queryParams = '';
       host='';
     }
     
     const httpOptions = {
        headers: new HttpHeaders({...this._getDefaultHeaders(),...headers})
      };
      let response;
      if(!this.isEmpty(payload)){
        response =  this.http.post(((host ==='')? this.host.url: host) + url + ((queryParams != '')?queryParams:'') , payload, httpOptions);
      }else{
        response = this.http.get(((host ==='')? this.host.url: host) + url + ((queryParams != '')?queryParams:'') ,httpOptions);
      }
      return response;
   }

   /**
    * Get all apis
    * For mocking local json just remove the payload from the return.
    */
   fetchServiceUrls(isMultioffer = false){
     let payLoad,
         url;
     if(isMultioffer){
        payLoad = {"pageName":"drstcV2"};
        url = (this.isMobile())?environment.headerconfigurlMobileMultiOffer : environment.headerconfigurlDesktopMultiOffer;
     }else{
        payLoad = { "pageName": "extraCareV3", "getConfigInfo": "Y" };
        url = (this.isMobile())?environment.headerconfigurlMobile : environment.headerconfigurlDesktop;
     }
     
     this.serviceUrls$.next({});
     return this.sendRequest(url,payLoad).subscribe((resp)=>{
       if(resp['response'].hasOwnProperty('status') && resp['response']['status']['code'] =='0000' && resp['response'].hasOwnProperty('config') &&  resp['response']['config'].hasOwnProperty('serviceUrls')){
         this.serviceUrls$.next({...resp['response']});
       }else{
         this.serviceUrls$.next({'error':true});
       }
       
     });
   }

   /**
    * Return ServiceApi Object
    */
   getServiceUrl = () => this.serviceUrls$;


   /**
    * Get all parameters of an url
    */
   findAllQueryParameters(url) {
      let params = {};
      let query = url.search.substring(1);
      let vars = query.split('&');
      for (let i = 0; i < vars.length; i++) {
        let pair = vars[i].split('=');
        if(pair[0] != ''){
          params[pair[0]] = decodeURIComponent(pair[1]);
        }
      }
      return params;
    }

    /** 
     * Check to see if an object is empty or not
     */
    isEmpty(obj) {
      for(var key in obj) {
          if(obj.hasOwnProperty(key))
              return false;
      }
      return true;
  }

  /**
   * Create bcc html content
   */
  getBccContent(slotId){
    const url = environment.retailurl + slotId;
    const httpOptions = {
      headers: new HttpHeaders({'Content-Type': 'text/plain'})
    };
    return this.http.get(url,httpOptions);
  }

/**
 * Get current date
 */
  getCurrentDate() {
    let d = new Date(),
        month = '' + (d.getMonth() + 1),
        day = '' + d.getDate(),
        year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
  }

  /**
   * Return Default Headers
   */
  private _getDefaultHeaders(){
      return {
        'Content-Type': 'application/json',
        'Accept': 'application/json'
    };
  }

/**
 * Function to detect mobile or not
 */
  isMobile(){
    let isMob = false;
    //if(navigator.userAgent.toLowerCase().indexOf('mobile') > -1){
    if(window.screen.width < 767){
      isMob = true;
    }
    return isMob;
  }

/**
 * Remove leading zeros from a string
 */
  removeLeadingZeros = (str) => str.replace(/^0+/, '');

  showExpandedView(type,index){
    
    console.log(document.getElementById(type + '_clickable_' + index).getAttribute('aria-expanded'));
    /*if(this.expandedSection.type != '' && this.expandedSection.index != ''){
      if( this.expandedSection.type == type && this.expandedSection.index == index){
        this._collapse(type,index);
        this.expandedSection.type = '';
        this.expandedSection.index = '';
      }else{
        this._collapse(this.expandedSection.type,this.expandedSection.index);
        this._expand(type,index);
      }
    }else {
      this._expand(type,index);
    }*/
    if(document.getElementById(type + '_clickable_' + index).getAttribute('aria-expanded') == 'false'){
      this._expand(type,index);
    }else{
      this._collapse(type,index);
    }
  }

  private _expand(type,index){
    let clickable = document.getElementById(type + '_clickable_' + index),
        expandable =  document.getElementById(type + '_expand_' + index);
      document.getElementById(type + '_expand_' + index).style.display = "block";
      document.getElementById(type + '_full_content_' + index).style.display = "block";
      document.getElementById(type + '_less_content_' + index).style.display = "none";
      clickable.getElementsByClassName("more-details")[0]['style'].display = "none";
      clickable.setAttribute('aria-expanded', 'true');
      /*this.expandedSection.type = type;
      this.expandedSection.index = index;*/
  }

  private _collapse(type,index){
    let clickable = document.getElementById(type + '_clickable_' + index),
        expandable =  document.getElementById(type + '_expand_' + index);
      expandable.style.display = "none";
      document.getElementById(type + '_full_content_' + index).style.display = "none";
      document.getElementById(type + '_less_content_' + index).style.display = "block";
      clickable.setAttribute('aria-expanded', 'false');
      clickable.getElementsByClassName("more-details")[0]['style'].display = "inline";
  }
 
}
