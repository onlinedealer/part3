import layoutReducer, { initialState } from '../reducer'
import { fromJS } from 'immutable'
import {
  OPEN_SIDE_NAV,
  CLOSE_SIDE_NAV,
  SET_HEADER_TITLE,
  SHOW_AUTH_POPUP,
} from '../actionType'

describe('layoutReducer', () => {
  it('should return the initial state', () => {
    expect(layoutReducer(undefined, {})).toEqual(initialState)
  })

  it('should handle OPEN_SIDE_NAV', () => {
    const initial = initialState.toJS()
    initial['sideNavIsOpen'] = true
    expect(layoutReducer(fromJS(initialState), {
      type: OPEN_SIDE_NAV,
    })).toEqual(fromJS(initial))
  })

  it('should handle CLOSE_SIDE_NAV', () => {
    const initial = initialState.toJS()
    initial['sideNavIsOpen'] = false
    expect(layoutReducer(fromJS(initialState), {
      type: CLOSE_SIDE_NAV,
    })).toEqual(fromJS(initial))
  })

  it('should handle SET_HEADER_TITLE', () => {
    const data = {
      headerTitle: 'ohayo gozaimasu',
    }
    const action = {
      type: SET_HEADER_TITLE,
      payload: data,
    }

    expect(layoutReducer(initialState, action))
  })

  it('should handle SHOW_AUTH_POPUP', () => {
    const initial = initialState.toJS()
    initial['openPopup'] = 1
    initial['popupType'] = 'login'
    expect(layoutReducer(fromJS(initialState), {
      type: SHOW_AUTH_POPUP,
      payload: 'login',
    })).toEqual(fromJS(initial))
  })
})
