import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, ChangeDetectionStrategy, ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { ErrorMessagesService } from '@precisely/prism-ng/cloud';
import { first } from 'rxjs/operators';
import { Connection } from '../../../connections/shared/connection';
import { BaseComponent } from '../../../core/base.component';
import { MetabasesApiService } from '../../../metabases/shared/metabases-api.service';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { PIPELINE_ENTITY_TYPE } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { LogReaderConfigurationSidebarComponent } from './logreaders/logreader-configuration-sidebar/logreader-configuration-sidebar.component';
import { SavedSchema } from './schema-table-selector/saved-schema';
import { SchemaTableSelectorComponent } from './schema-table-selector/schema-table-selector.component';
import { LogReader } from './shared/logreader';
import { SourceGeneralComponent } from './source-general/source-general.component';

@Component({
  selector: 'p-connect-data',
  templateUrl: './pipeline-data.component.html'
})
export class PipelineDataComponent extends BaseComponent implements OnInit, AfterViewInit {
  @ViewChild(SchemaTableSelectorComponent) schemaTableSelectorComponent: SchemaTableSelectorComponent;
  @ViewChild(LogReaderConfigurationSidebarComponent) logReaderSidebar: LogReaderConfigurationSidebarComponent;
  @ViewChild(SourceGeneralComponent) sourceGeneralComponent: SourceGeneralComponent;

  excludeConnectionsInMetabaseCheck = ['DB2ZOS'];

  isMetabaseSidebarVisible = false;

  sourceDataConnection: Connection;

  projectId: string;

  savedSchemas: SavedSchema[];

  selectedLogReader: LogReader = null;

  pipelineType: string;

  selectedJournal = '';

  pipelineId: string;

  possibleKeys: { key: string; value?: string }[] = ['IBMI_LOG_READER_NAME', 'IBMI_JOURNAL_NAME', 'LUW_LOG_READER_NAME'].map((value) => {
    return { key: value };
  });

  hasMissingDatasetsOrSchemas = false;

  readonly PIPELINE_TYPE = PIPELINE_ENTITY_TYPE;

  get pipelineEntityType(): string {
    return this.pipelineEntityService.pipelineEntityType;
  }

  constructor(
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly metabasesApiService: MetabasesApiService,
    private readonly progressIndicatorStateService: ProgressIndicatorStateService,
    private readonly changeDetectorRef: ChangeDetectorRef,
    public router: Router,
    public readonly errorMessagesService: ErrorMessagesService
  ) {
    super();
  }

  ngAfterViewInit(): void {
    // temporary fix for ExpressionChangedAfterItHasBeenCheckedError error
    setTimeout(() => {
      if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
        this.schemaTableSelectorComponent.loadSchemaData();
      } else if (
        !this.excludeConnectionsInMetabaseCheck.find((connectionType) => connectionType === this.sourceDataConnection.connectionType)
      ) {
        this.checkForMetabase(this.projectId, this.sourceDataConnection.id);
      } else {
        this.schemaTableSelectorComponent.loadSchemaData();
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  ngOnInit(): void {
    const pipeline = this.pipelineEntityService.getPipeline();
    this.sourceDataConnection = pipeline.source?.dataConnection;
    this.pipelineId = pipeline.id;
    this.projectId = pipeline.projectId;
    this.pipelineType = pipeline.dataFlowType;
    if (pipeline.source?.selectedTables) {
      this.savedSchemas = pipeline.source.selectedTables.map((schema) => {
        return {
          name: schema.key,
          tables: schema.value.tableAndKeys.map((table) => table.tableName)
        };
      });
    } else {
      this.savedSchemas = [];
    }

    this.progressIndicatorStateService.setIsValid(2, this.savedSchemas.length > 0);
  }

  tableStatusChanged(newStatus: any): void {
    this.progressIndicatorStateService.setIsValid(2, newStatus.status);
    if (this.areLogReadersRequired()) {
      this.selectedJournal = newStatus.journal;
      // don't need to save the logreader parameters on load.
      // this was causing the logreader to always default to autogenerate
      if (!newStatus.isLoading) {
        this.saveLogReaderParameter();
      }
    }
  }

  metabaseSavedEvent(): void {
    this.schemaTableSelectorComponent.loadSchemaData();
    if (this.areLogReadersRequired()) {
      this.schemaTableSelectorComponent.getJournals();
    }
  }

  private areLogReadersRequired(): boolean {
    return this.sourceDataConnection.connectionType === 'DB2I' && this.pipelineType !== 'COPY';
  }

  selectedLogReaderChanged(selectedLogReader: LogReader): void {
    if (selectedLogReader && selectedLogReader.name !== 'Autogenerate') {
      this.selectedLogReader = selectedLogReader;
      this.selectedJournal = selectedLogReader.journalName;
    } else {
      this.selectedLogReader = null;
    }
    this.saveLogReaderParameter();
  }

  saveLogReaderParameter(): void {
    let logReaderParameters: { key: string; value: string }[] = [];

    if (this.sourceDataConnection.connectionType === 'DB2I') {
      if (this.selectedLogReader && this.selectedLogReader.name !== 'Autogenerate') {
        logReaderParameters = [
          {
            key: 'IBMI_LOG_READER_NAME',
            value: this.selectedLogReader.name
          },
          {
            key: 'IBMI_JOURNAL_NAME',
            value: this.selectedLogReader.journalName
          }
        ];
      } else {
        logReaderParameters = [
          {
            key: 'IBMI_JOURNAL_NAME',
            value: this.selectedJournal
          }
        ];
      }
    } else if (this.sourceDataConnection.connectionType === 'DB2') {
      logReaderParameters = [
        {
          key: 'LUW_LOG_READER_NAME',
          value: this.selectedLogReader.name
        }
      ];
    }
    this.pipelineEntityService.patchPipeline({ properties: [...logReaderParameters, ...this.possibleKeys] });
  }

  private checkForMetabase(projectId: string, dataConnectionId: string) {
    this.metabasesApiService.serviceURL = `projects/${projectId}/metabases`;

    this.metabasesApiService
      .get(dataConnectionId)
      .pipe(first())
      .subscribe({
        next: () => {
          this.schemaTableSelectorComponent.loadSchemaData();
        },
        error: (error: HttpErrorResponse) => {
          if (error.status === 404) {
            this.isMetabaseSidebarVisible = true;
          }
        }
      })
      .add(() => {
        this.changeDetectorRef.markForCheck();
      });
  }

  configurationButtonClicked(): void {
    this.logReaderSidebar.open(this.selectedLogReader);
  }

  updateLogReaders(): void {
    this.sourceGeneralComponent.getLogReaders();
  }

  metabaseCancelButtonClicked($event): void {
    this.isMetabaseSidebarVisible = !$event;
    if ($event === true) {
      this.navigateTo(`/pipelines/${this.pipelineId}/edit/connections`);
      this.progressIndicatorStateService.setActiveStepIndex(1);
    }
  }
}
