import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarepassErrorBannerComponent } from './carepass-error-banner.component';

describe('CarepassErrorBannerComponent', () => {
  let component: CarepassErrorBannerComponent;
  let fixture: ComponentFixture<CarepassErrorBannerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarepassErrorBannerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarepassErrorBannerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
