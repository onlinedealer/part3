import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import { CustomPropertyVO } from "../../models/view-objects/custom-property-vo.model";
import { TranslationsService } from "../../../app/services/translations-service";
import { SortOrder } from "../../../Shared/models/sort-order.model";
import { Store } from "@ngrx/store";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { CustomPropertySorter } from "./custom-property-sorter";
interface ColumnTitles {
    [key: string]: string;
}

@Component({
    selector: "landisgyr-meteringpoint-custom-property-table",
    templateUrl: "./custom-property-table.component.html",
    styleUrls: ["./custom-property-table.component.scss"]
})
export class CustomPropertiesTableComponent implements OnChanges {
    TABLE_COLUMN_TITLES_CUSTOMPROPERTY: ColumnTitles = {
        // Note! Header of first column is received as input parameter 'firstColumnHeader'
        value: this.translations.getTranslation("Value"),
        latestUpdate: $localize`:|Table column title for Latest Update@@customPropertyTable.latestUpdate:Latest update`,
        updatedBy: $localize`:|Table column title for Updated By@@customPropertyTable.updatedBy:Updated by`
    };

    @Input() CustomProperties!: CustomPropertyVO[];
    @Output() sortChangeEvent: EventEmitter<SortOrder> = new EventEmitter();
    @Input() sortColumnname!: string;
    @Input() sortedColumn!: { active: string; direction: string };
    @Input() infoMessage!: string;
    @Input() firstColumnHeader!: string;
    @Input() loading!: boolean;
    @Input() refreshDataLoading!: boolean;
    customPropertySorter = new CustomPropertySorter();
    sortedCustomProperties$ = this.customPropertySorter.getSortedCustomProperties();
    constructor(public translations: TranslationsService, private store: Store<MeteringPointsFeatureState>) {}
    ngOnChanges(changes: SimpleChanges) {
        this.customPropertySorter.setCustomProperties(this.CustomProperties);
    }
}
