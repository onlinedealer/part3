import React from 'react'
import { shallow } from 'enzyme'
import { Auth } from '../Auth'

describe('Auth component', () => {
  it('renders', () => {
    const wrapper = shallow(<Auth />)
    expect(wrapper).toHaveLength(1)
  })

  it('loads access_token from localStorage', () => {
    const signInSuccess = jest.fn()
    global.localStorage.setItem('access_token', 'asdf4567')
    shallow(<Auth signInSuccess={signInSuccess} />)
    expect(signInSuccess).toHaveBeenCalledWith({accessToken: 'asdf4567'})
  })
})
