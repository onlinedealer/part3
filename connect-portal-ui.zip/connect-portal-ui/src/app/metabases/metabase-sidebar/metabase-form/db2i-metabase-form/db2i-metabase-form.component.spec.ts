import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { AuthModule } from 'angular-auth-oidc-client';
import { Connection } from '../../../../connections/shared/connection';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { SharedModule } from '../../../../shared/shared.module';
import { DB2IMetabaseFormComponent } from './db2i-metabase-form.component';

describe('DB2IMetabaseFormComponent', () => {
  let component: DB2IMetabaseFormComponent;
  let fixture: ComponentFixture<DB2IMetabaseFormComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [DB2IMetabaseFormComponent],
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule, AuthModule.forRoot({}), RouterModule.forRoot([]), SharedModule],
      providers: [
        {
          provide: TRANSLOCO_SCOPE,
          useValue: { scope: 'metabases' }
        },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DB2IMetabaseFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the database server control value if a data connection is passed', () => {
    component.dataConnection = { database: 'test', parameters: [{ key: 'DB2_I_ENABLE_IASP', value: 'YES' }] } as Connection;
    component.ngOnInit();
    expect(component.db2iMetabaseForm.get('databaseServer').value).toBe('test');
  });

  it('should NOT set the database server control value if a data connection is NOT passed', () => {
    component.ngOnInit();
    expect(component.db2iMetabaseForm.get('databaseServer').value).toBe('');
  });

  it('should return a metabase object from the form', () => {
    component.ngOnInit();
    component.db2iMetabaseForm.patchValue({
      metabaseLibrary: 'sharemb',
      replicationUserID: 'sa',
      replicationPassword: '',
      journalLocation: ''
    });
    component.db2iMetabaseForm.addControl('dataConnection', new FormControl('1'));
    const metabase = component.metabase;
    expect(metabase.name).toBe('SHAREMB');
    expect(metabase.parameters.length).toBe(3);
    expect(metabase.parameters[1].value).toBe('sa');
  });

  it('should not clear validators if form does not exist', () => {
    component.db2iMetabaseForm = null;
    component.ngOnDestroy();
    expect(component.db2iMetabaseForm).toBeNull();
  });
});
