import request = require("request-promise");
import { Observable, from, of } from "rxjs";
import { catchError } from "rxjs/operators";
import {
  BACKEND_URL_SCHEME,
  BACKEND_HOST,
  BACKEND_ROOT,
  REQUEST_DEBUG,
} from "../constants";

request.defaults({ jar: true });
request.debug = REQUEST_DEBUG;

export class SecurityService {
  static getUserInfo(): Observable<any> {
    return from(
      request.get({
        url: `${BACKEND_URL_SCHEME}://${BACKEND_HOST}${BACKEND_ROOT}security/getUserInfo`,
        rejectUnauthorized: false,
        followAllRedirects: true,
        json: true,
        jar: true,
        headers: {
          Accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
          "content-type": "text/xml; charset=utf-8",
        },
      })
    ).pipe(
      catchError((err) => {
        console.log("getUserInfo statusCode: ", err.statusCode);
        throw err;
      })
    );
  }

  static updateSession(): Observable<any> {
    return from(
      request.post({
        url: `${BACKEND_URL_SCHEME}://${BACKEND_HOST}${BACKEND_ROOT}security/updateSession`,
        rejectUnauthorized: false,
        followAllRedirects: true,
        json: true,
        jar: true,
        headers: {
          Accept: "application/json",
        },
      })
    ).pipe(
      catchError((err) => {
        console.log("updateSession statusCode: ", err.statusCode);
        throw err;
      })
    );
  }

  static logout(): Observable<any> {
    return from(
      request.get({
        url: `${BACKEND_URL_SCHEME}://${BACKEND_HOST}${BACKEND_ROOT}security/logout`,
        rejectUnauthorized: false,
        followAllRedirects: false,
        json: false,
        jar: true,
        headers: {
          Accept:
            "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8",
          "content-type": "text/xml; charset=utf-8",
        },
      })
    ).pipe(
      catchError((err) => {
        console.log("logout statusCode: ", err.statusCode);
        throw err;
      })
    );
  }
}
