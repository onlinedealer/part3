import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ConnectionModel } from '../connection.model';
import { DataBrickConnectionOptionsModel } from './databricks-connection-options.model';
import { NgForm } from '@angular/forms';
import { TranslocoService } from '@ngneat/transloco';
import { NameValidatorService } from '../../name-validator.service';
import { SharedConstants } from '../../shared.constant';

@Component({
  selector: 'discovery-databrick-connection',
  templateUrl: './databrick-connection.component.html',
  styleUrls: ['./databrick-connection.component.css']
})
export class DatabrickConnectionConfigureComponent implements OnInit {
  /**
   * View child for Ngform and name field
   */
  @ViewChild('databricksForm') databricksForm: NgForm;
  @ViewChild('connectionNameRefData') connectionNameRefData: ElementRef;

  /**
   * Output for event emitters
   */

  @Output() setField: EventEmitter<{ key: string; value: string }> = new EventEmitter<{
    key: string;
    value: string;
  }>();
  @Output() setFormValidProp: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() nameInvalidError: EventEmitter<boolean> = new EventEmitter<boolean>();

  nameError: any = {
    invalidName: false
  };

  get formViewType(): string {
    return this._formViewType;
  }

  @Input()
  set formViewType(val: string) {
    this._formViewType = val;
  }

  get buttonTypeClicked(): string {
    return this._clickButtonType;
  }

  @Input()
  set buttonTypeClicked(val: string) {
    this._clickButtonType = val;
    if (val === 'connection-save') {
      this.connectionNameRefData.nativeElement.required = true;
    }
    if (val === 'connection-test' || val === null) {
      this.connectionNameRefData.nativeElement.required = false;
    }
  }

  get resetFormData(): boolean {
    return this._resetFormData;
  }

  @Input()
  set resetFormData(val: boolean) {
    this._resetFormData = val;
    if (this._resetFormData) {
      this.closeDataForm();
    }
  }

  get connectionModel(): ConnectionModel {
    return this._connectionModel;
  }

  @Input()
  set connectionModel(val: ConnectionModel) {
    this._connectionModel = val;
    if (this._connectionModel && this._connectionModel.name) {
      this.validateConnectionName();
    }
  }

  get url(): string {
    return this.getOption(DataBrickConnectionOptionsModel.url);
  }

  /**
   *
   * @param value
   */
  set url(value: string) {
    this.setOption(DataBrickConnectionOptionsModel.url, value);
  }

  /**
   *
   */
  get password(): string {
    return this.getOption(DataBrickConnectionOptionsModel.password);
  }

  /**
   *
   * @param value
   */
  set password(value: string) {
    this.setOption(DataBrickConnectionOptionsModel.password, value);
  }

  /**
   * create, edit or copy mode
   */
  private _formViewType: string;

  /**
   * connection ID for edit or copy mode
   */
  private _connectionModel: ConnectionModel;

  /**
   * connection button type clicked
   */
  private _clickButtonType: string;

  /**
   * sidebar toggle
   */
  private _resetFormData: boolean;

  /**
   *
   * @param translocoService
   */
  constructor(private translocoService: TranslocoService) {}

  /**
   *
   */
  ngOnInit(): void {
    if (this.connectionModel && this.connectionModel.resourceConnectionType === '') {
      this.connectionModel.resourceConnectionType = SharedConstants.connectionConfigureType.DATABRICKS;
    }
  }

  /**
   *
   */
  validateConnectionName() {
    this.connectionModel.name = this.connectionModel.name?.trim();
    this.nameError.invalidName = false;
    if (this.connectionModel.name) {
      const test = NameValidatorService.validateName(this.connectionModel.name);
      if (!test || this.connectionModel.name.length > SharedConstants.NAMEMAXLENGTH) {
        this.nameError.invalidName = true;
      }
    }
    this.nameInvalidError.emit(this.nameError.invalidName);
  }

  closeDataForm() {
    if (this.databricksForm) {
      this.databricksForm.resetForm();
      this.setFormValidProp.emit(false);
      this.nameError.invalidName = false;
      this.buttonTypeClicked = null;
    }
  }

  /**
   *
   * @param key
   */
  private getOption(key: string): string {
    if (this.connectionModel.options) {
      for (const option of this.connectionModel.options) {
        if (option.name === key) {
          return option.value;
        }
      }
    }
  }

  /**
   *
   * @param key
   * @param value
   */
  private setOption(key: string, value: string): void {
    this.setField.emit({ key: key, value: value });
    this.setFormValidProp.emit(this.databricksForm.valid);
  }
}
