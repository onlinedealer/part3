import { Component, OnInit, HostListener } from '@angular/core';

@Component({
  selector: 'app-back-to-top',
  template: `<div id="back-to-top" (click)="goToTop()" (scroll)="scroll(event)" [hidden]="backToTop">Top</div>`,
  styleUrls: ['./back-to-top.component.scss']
})

export class BackToTopComponent implements OnInit {

  backToTop: boolean = true
  
  @HostListener('window:scroll', ['event']) scroll(event) {
    setTimeout( () => {
      if (window.pageYOffset > 200) {
         this.backToTop = false
      } else {
        this.backToTop = true
      }
    }, 1000)
  }

  goToTop(){
    document.body.scrollTop = document.documentElement.scrollTop = 0;
  }

  constructor() { }

  ngOnInit() { }

}
