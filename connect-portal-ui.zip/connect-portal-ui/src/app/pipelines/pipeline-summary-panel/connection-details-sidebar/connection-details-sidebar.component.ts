import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { SidebarButton } from '../../../shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { PipelinesMonitoringApiService } from '../../shared/pipelines-monitoring-api.service';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';

@Component({
  selector: 'p-connect-connection-details-sidebar',
  templateUrl: './connection-details-sidebar.component.html'
})
export class ConnectionDetailsSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  @Output() refreshEvent = new EventEmitter();

  primaryButton: SidebarButton = {
    id: 'connectionDetailsRefresh',
    text: 'common.BUTTONS.REFRESH'
  };

  cancelButton: SidebarButton = {
    id: 'connectionDetailsClose',
    text: 'common.BUTTONS.CLOSE'
  };

  selectedPipeline: any = {};
  selectedConnection: any = {};
  skipHeader = new HttpHeaders().set(InterceptorSkipHeader, '');
  projectName = '';

  constructor(public readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService) {}

  open(selectedPipeline: any, selectedConnectionName: string, projectName: string) {
    this.selectedPipeline = selectedPipeline;
    this.selectedConnection = this.getSelectedConnection(selectedConnectionName);
    this.primaryButton.isDisabled = this.selectedConnection ? this.selectedConnection.target : false;
    this.projectName = projectName;
    this.sidebarComponent.open();
  }

  primaryButtonClicked(): void {
    this.refreshEvent.emit();
  }

  cancelButtonClicked(): void {
    this.sidebarComponent.close();
  }

  private getSelectedConnection(selectedConnectionName: string): any {
    let selectedConnection = null;
    for (let i = 0; i < this.selectedPipeline.runtimeServers.length && !selectedConnection; i++) {
      const runtimeServer = this.selectedPipeline.runtimeServers[i];
      selectedConnection = runtimeServer.dataConnections.find((dataConnection) => dataConnection.name === selectedConnectionName);
    }
    return selectedConnection;
  }
}
