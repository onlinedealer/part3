(function() {
    'use strict';

    fileuploader.controller("loginCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$location', '$route', loginCtrl]);

    function loginCtrl($scope, $ajaxFactory, $rootScope, uiRouters, $location, $route) {
        
        $scope.isDisplay = false;
        $scope.errormsg = "";
        $scope.userName = "";
        $scope.userPass = "";
        // login authentication Function
        $scope.authenticateUser = function() {
           
                $scope.isDisplay = false;
                var obj = {}
                obj.login = $scope.userName;
                obj.password = $scope.userPass;
                var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/login.json', 'POST', obj);
               // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + '/login/', 'POST', obj);
                promise.then(function(d) {
                    for(var i = 0; i<=d.length;i++){
                        var item = d[i];                       
                    if (item.username == $scope.userName && item.password == $scope.userPass) {         
                       $location.url(uiRouters.home);
                       $rootScope.globalUserName = $scope.userName;                        
                    } else {
                    $scope.isDisplay = true;
                        $scope.errormsg = "Please Enter Valid Credentials";
                    }
                }
                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
                promise.finally(function(d) {
                    console.log('finally block executed', d);
                });
        };
    }
})();