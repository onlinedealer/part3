export class ExportDialogModel {
  alertId: string;
  fromDate?: Date;
  toDate: Date;
}
