import { AcceptLanguageInterceptorService } from "./interceptor-services/accept-language-interceptor.service";
import { ApplicationDataProviderService } from "./services/application-data-provider.service";
import { ApplicationHeaderMenuProviderService } from "./services/application-header-menu-provider.service";
import { AppRoutingModule } from "./app-routing.module";
import { AuthorizationInterceptorService } from "./interceptor-services/authorization-interceptor.service";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { BrowserModule } from "@angular/platform-browser";
import { DOCUMENT } from "@angular/common";
import { effects } from "./store/effects";
import { EffectsModule } from "@ngrx/effects";
import { environment } from "../environments/environment";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HeaderDataProvider } from "./modules/header/common/header-data-provider";
import { HeaderHelpMenuProvider } from "./modules/header/common/header-help-menu-provider";
import { HeaderModule } from "./modules/header/header.module";
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { LandisGyrAimConfigurationModel, landisGyrAimConfigurationFactory } from "../Shared/models/date-configuration.model";
import { MAT_DATE_LOCALE } from "@angular/material/core";
import { MaterialModule } from "../material.module";
import { NetworksModule } from "../Networks/networks.module";
import { NgModule, TRANSLATIONS, LOCALE_ID, Injector } from "@angular/core";
import { reducers, CustomSerializer } from "./store/reducers";
import { SharedModule } from "../Shared/shared.module";
import { StoreDevtoolsModule } from "@ngrx/store-devtools";
import { StoreModule } from "@ngrx/store";
import { StoreRouterConnectingModule } from "@ngrx/router-store";
import { ToastModule } from "../Shared/modules/toast";
import { TRANSLATIONS_FORMAT } from "@angular/core";
import { XHeaderInterceptorService } from "./interceptor-services/xheader-interceptor.service";
import { XSFSearchOverlayModule } from "../Shared/modules/xsf-search-overlay";
import * as fromComponents from "./components";
import * as fromContainers from "./containers";
import * as moment from "moment";
import { setInjector } from "./app-injector";
import { DataTableService} from "../Shared/components/data-table/dataTableService";

declare const require: Function;

export function localeFactory(configuration: LandisGyrAimConfigurationModel, document: Document) {
    const documentProvidedLocale = document.documentElement.lang;
    if (configuration) {
        console.log("Setting moment locale: ", configuration.systemLocale || documentProvidedLocale || "en");
        moment.locale(configuration.systemLocale || documentProvidedLocale || "en");
        return configuration.systemLocale || documentProvidedLocale || "en";
    }
    return documentProvidedLocale || "en";
}

export function translationsFactory(locale: string, configuration: LandisGyrAimConfigurationModel) {
    locale = configuration ? configuration.systemLocale : locale || "en"; // default to english if no locale
    try {
        return require(`raw-loader!../i18n/messages.${locale}.xlf`).default;
    } catch (es) {
        console.error(configuration ? "Error loading messages.xlf using AIM Configuration model: " : "Error loading messages.xlf", es);
        return require(`raw-loader!../i18n/messages.en.xlf`).default;
    }
}

@NgModule({
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        FormsModule,
        HttpClientModule,
        ReactiveFormsModule,
        MaterialModule,
        NetworksModule,
        HeaderModule,
        StoreModule.forRoot(reducers, {
            runtimeChecks: {
                strictStateImmutability: true,
                strictActionImmutability: true,
                strictStateSerializability: true,
                strictActionSerializability: false
            }
        }),
        EffectsModule.forRoot(effects),
        environment.production ? [] : StoreDevtoolsModule.instrument({ maxAge: 50, logOnly: true }),
        AppRoutingModule,
        StoreRouterConnectingModule.forRoot({
            serializer: CustomSerializer
        }),
        ToastModule,
        XSFSearchOverlayModule,
        FlexLayoutModule,
        SharedModule
    ],
    providers: [
        {
            provide: TRANSLATIONS_FORMAT,
            useValue: "xlf"
        },
        { provide: LOCALE_ID, useFactory: localeFactory, deps: [LandisGyrAimConfigurationModel, DOCUMENT] },
        { provide: MAT_DATE_LOCALE, useFactory: localeFactory, deps: [LandisGyrAimConfigurationModel, DOCUMENT] },
        {
            provide: TRANSLATIONS,
            useFactory: translationsFactory,
            deps: [LOCALE_ID, LandisGyrAimConfigurationModel]
        },
        {
            provide: LandisGyrAimConfigurationModel,
            useFactory: landisGyrAimConfigurationFactory
        },
        {
            provide: HeaderHelpMenuProvider,
            useClass: ApplicationHeaderMenuProviderService
        },
        {
            provide: HeaderDataProvider,
            useClass: ApplicationDataProviderService
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AcceptLanguageInterceptorService,
            multi: true
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: AuthorizationInterceptorService,
            multi: true
        },
        {
            provide: HTTP_INTERCEPTORS,
            useClass: XHeaderInterceptorService,
            multi: true
        },
        DataTableService
    ],
    declarations: [...fromContainers.containers, ...fromComponents.components],
    bootstrap: [fromContainers.AppComponent]
})
export class AppModule {
    static injector: Injector;
    constructor(injector: Injector) {
        AppModule.injector = injector;
        setInjector(injector);
    }
}
