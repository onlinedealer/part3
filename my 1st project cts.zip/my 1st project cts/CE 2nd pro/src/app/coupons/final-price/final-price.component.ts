
import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';
import { CouponHelperService } from '../../services/coupon-helper.service';
 
@Component({
  selector: 'app-final-price',
  templateUrl: './final-price.component.html',
  styleUrls: ['./final-price.component.scss']
})
export class FinalPriceComponent implements OnInit {
  @Input() data: any

  imagesPaths: Object = ImagePaths;
  serviceUrls: Object;

  constructor(public utilityService: UtilityService, public couponHelperService: CouponHelperService) { }

  ngOnInit() {
  }

}

