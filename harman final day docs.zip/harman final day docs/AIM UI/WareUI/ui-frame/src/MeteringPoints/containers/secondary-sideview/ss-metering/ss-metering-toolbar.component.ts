import { Component, Input, ChangeDetectionStrategy } from "@angular/core";
import { Metering } from "../../../models/metering.model";

@Component({
    selector: "landisgyr-ss-metering-toolbar",
    templateUrl: "./ss-metering-toolbar.component.html",
    styleUrls: ["./ss-metering-toolbar.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSMeteringToolbarComponent {
    @Input()
    metering!: Metering | undefined;

    @Input()
    activeView!: string;

    isMeteringSelectedAndOnChartView() {
        return this.metering && this.activeView === "chart";
    }
}
