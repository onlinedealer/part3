import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../store/configureStore'
import CreateGroup, { CreateGroup as CreateGroupComponent } from '../CreateGroup'
import * as Constants from '../../common/Utils/Constants'

describe('CreateGroup component', () => {
  let store, wrapper, wrapperBlock
  store = configureStore
  let props = {
    classes: {},
    groupTypes: [{'id': 1, 'name': 'variation', 'status': true}, {'id': 2, 'name': 'collection', 'status': false}],
    itemTypes: [{'item_type_id': 380505, 'item_type_name': 'Neckties', 'item_type_short_name': 'Neckties', 'item_type_status_code': 'ACTV', 'merchandise_type_id': 118302, 'merchandise_type_name': 'Ties'}],
    itemThemes: [{'id': 93, 'attribute_type': 'mta', 'name': 'Product Length', 'path': 'dummy', 'is_active': true, 'mta_attribute_id': 102627}, {'id': 97, 'attribute_type': 'mta', 'name': 'Product Color', 'path': 'dummy', 'is_active': true, 'mta_attribute_id': 107707}],
    requestType: '',
    errorTcins: [],
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }
  it('renders without props', () => {
    const div = document.createElement('div')
    shallow(
      <Provider store={store}>
        <CreateGroup />
      </Provider>, div)
  })

  it('renders with props', () => {
    wrapper = mount(
      <Provider store={store}>
        <CreateGroup {...props} />
      </Provider>)
    wrapper.setState({formData: {themes: {theme1: 93}}})
    expect(wrapper).toHaveLength(1)
  })

  it('invoking handleSelectChange ', () => {
    props.groupTypes = []
    props.getGrouperTypes = jest.fn()
    props.getItemThemes = jest.fn()
    props.clearItemThemes = jest.fn()
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)

    wrapperBlock.instance().handleSelectChange()
    expect(wrapperBlock.instance().state.formData.group_type).toEqual('')

    wrapperBlock.instance().handleSelectChange('group_type', 1)
    expect(wrapperBlock.instance().state.formData.group_type).toEqual(1)

    wrapperBlock.instance().handleSelectChange('item_type', 380505)
    expect(wrapperBlock.instance().state.formData.item_type).toEqual(380505)
    wrapperBlock.instance().handleSelectChange('item_type', '')
    expect(wrapperBlock.instance().state.formData.item_type).toEqual('')

    wrapperBlock.instance().handleSelectChange('theme1', 93)
    expect(wrapperBlock.instance().state.formData.themes.theme1).toEqual(93)
    wrapperBlock.instance().handleSelectChange('theme2', 97)
    expect(wrapperBlock.instance().state.formData.themes.theme2).toEqual(97)
    wrapperBlock.instance().handleSelectChange('theme3', 99)
    expect(wrapperBlock.instance().state.formData.themes.theme3).toEqual(99)
    wrapperBlock.instance().handleSelectChange('theme3', 95)
    expect(wrapperBlock.instance().state.formData.themes.theme3).toEqual(95)
    wrapperBlock.instance().handleSelectChange('theme1', 97)
    expect(wrapperBlock.instance().state.formData.themes.theme1).toEqual(93)
    wrapperBlock.instance().handleSelectChange('theme2', 93)
    expect(wrapperBlock.instance().state.formData.themes.theme2).toEqual(97)
  })

  it('invoking handleChange ', () => {
    props.getItemThemes = jest.fn()
    props.clearItemThemes = jest.fn()
    props.groupTypes = [{'id': 1, 'name': 'variation', 'status': true}, {'id': 2, 'name': 'collection', 'status': false}]
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)

    wrapperBlock.instance().handleChange('group_type')({target: { value: 1 }})
    expect(wrapperBlock.instance().state.formData.group_name).toEqual('')

    wrapperBlock.instance().handleChange('group_name')({target: { value: 'Text' }})
    expect(wrapperBlock.instance().state.formData.group_name).toEqual('Text')

    wrapperBlock.instance().handleChange('group_name')({target: { value: 'CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component CreateGroup component' }})
    expect(wrapperBlock.instance().state.errors.group_name).toEqual(Constants.GROUP_NAME_EXCEED_TEXT)

    wrapperBlock.instance().handleChange('group_name')({target: { value: '' }})
    expect(wrapperBlock.instance().state.errors.group_name).toEqual(Constants.ERROR_GROUP_NAME_REQ)
  })

  it('invoking handlekeyDown ', () => {
    props.getItemTypes = jest.fn()
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)

    wrapperBlock.instance().handlekeyDown('item_type', 'n')
    wrapperBlock.instance().handlekeyDown('item_theme', 'n')
    wrapperBlock.instance().handlekeyDown('item_type', 'nece')
    expect(props.getItemTypes).toHaveBeenCalled()
  })

  it('invoking handleDeleteTcin ', () => {
    props.getItemTypes = jest.fn()
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)
    wrapperBlock.instance().handleAddTcin('1234')
    wrapperBlock.instance().handleDeleteTcin('1234')
    expect(wrapperBlock.instance().state.formData.tcins).toEqual([])
  })

  it('invoking handleAddTcin ', () => {
    props.getItemTypes = jest.fn()
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)
    wrapperBlock.instance().handleAddTcin()
    wrapperBlock.instance().handleAddTcin('1234,5678')
    expect(wrapperBlock.instance().state.formData.tcins.length).toEqual(2)
    wrapperBlock.instance().handleAddTcin('4321 ')
    expect(wrapperBlock.instance().state.formData.tcins.length).toEqual(3)
    wrapperBlock.instance().handleAddTcin(`1234 5678${String.fromCharCode(9)}4321`)
    expect(wrapperBlock.instance().state.formData.tcins.length).toEqual(3)
    wrapperBlock.instance().handleAddTcin(`5678${String.fromCharCode(9)}4321`)
    expect(wrapperBlock.instance().state.formData.tcins.length).toEqual(3)
    wrapperBlock.instance().handleAddTcin('3210,')
    expect(wrapperBlock.instance().state.formData.tcins.length).toEqual(4)
    wrapperBlock.instance().handleAddTcin('3210,Test')
    expect(wrapperBlock.instance().state.errors.tcins).toEqual(Constants.INVALID_TCIN_TEXT)
  })

  it('invoking isValidate ', () => {
    props.addGroup = jest.fn()
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)
    wrapperBlock.instance().validateSubmit()
    expect(wrapperBlock.instance().state.errors.group_type).toEqual(Constants.ERROR_GROUP_TYPE_REQ)
    wrapperBlock.instance().handleSelectChange('group_type', 1)
    wrapperBlock.instance().handleSelectChange('item_type', 380505)
    wrapperBlock.instance().handleChange('group_name')({target: { value: 'Text' }})
    wrapperBlock.instance().handleAddTcin('1234,5678')
    wrapperBlock.instance().handleSelectChange('theme2', 93)
    wrapperBlock.instance().validateSubmit()
    wrapperBlock.instance().handleSelectChange('theme1', 95)
    wrapperBlock.instance().validateSubmit()
    expect(props.addGroup.mock.calls.length).toEqual(1)
  })

  it('invoking addThemesField ', () => {
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)
    wrapperBlock.instance().addThemesField()
    expect(wrapperBlock.instance().state.formData.themes['theme2']).toEqual('')
    wrapperBlock.instance().handleSelectChange('theme2', 97)
    wrapperBlock.instance().addThemesField()
    expect(wrapperBlock.instance().state.formData.themes['theme2']).toEqual(97)
  })

  it('invoking removeThemesField ', () => {
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)
    wrapperBlock.instance().addThemesField()
    wrapperBlock.instance().removeThemesField('theme2')
    expect(wrapperBlock.instance().state.formData.themes['theme2']).toEqual(undefined)
  })

  it('invoking componentWillReceiveProps ', () => {
    props.closeDrawer = jest.fn()
    wrapperBlock = shallow(
      <CreateGroupComponent
        {...props}
      />)
    wrapperBlock.setProps({ errorTcins: [] })
    wrapperBlock.setProps({ requestType: 'REMOVE' })
    wrapperBlock.setProps({ requestType: 'ADD' })
    expect(props.closeDrawer.mock.calls.length).toEqual(1)
  })
})
