(function() {
    'use strict';
    codeathonApp.factory('dataShare', ['$rootScope', '$timeout', dataShare]);

    function dataShare($rootScope, $timeout) {
        var service = {};
        service.data = false;
        service.sendData = function(data) {
            this.data = data;
            $timeout(function() {
                $rootScope.$broadcast('shared_data');
            }, 100);
        };
        service.getData = function() {
            return this.data;
        };
        service.removeData = function() {
            this.data = false;
        };
        return service;
    }

})();
