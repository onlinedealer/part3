import { Component, Inject, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { AgentsApiService } from '../../agents/shared/agents-api.service';
import { ProgressIndicatorStateService } from '../../shared/components/progress-indicator/progress-indicator-state.service';
import { NGX_LOADING_BAR_IGNORED } from '@ngx-loading-bar/http-client';
import { HttpContext } from '@angular/common/http';
import { DOCUMENT } from '@angular/common';

@Component({
  selector: 'p-connect-agents-home',
  templateUrl: './agents-home.component.html',
  styleUrls: ['./agents-home.component.scss']
})
export class AgentsHomeComponent implements OnInit {
  isAgentRegistered: boolean;
  agentDownloadURL = environment.agentDownloadURL;

  constructor(
    private readonly agentsService: AgentsApiService,
    private readonly progressIndicatorStateService: ProgressIndicatorStateService,
    @Inject(DOCUMENT) private doc: Document
  ) {}

  ngOnInit(): void {
    this.checkForAgent();
  }

  private checkForAgent() {
    setTimeout(() => {
      // Don't poll if we're not in DI module.
      if (this.doc.location.href.includes('/data-integration/')) {
        this.agentsService
          .getAll(undefined, new HttpContext().set(NGX_LOADING_BAR_IGNORED, true)) // Don't show loading bar on polling requests.
          .pipe(first())
          .subscribe({
            next: (agents) => {
              if (agents.length === 0) {
                this.checkForAgent();
              } else {
                this.isAgentRegistered = true;
                this.progressIndicatorStateService.setIsValid(0, true);
              }
            },
            error: () => {
              this.checkForAgent();
            }
          });
      }
    }, 2000);
  }
}
