import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { TranslocoService } from '@ngneat/transloco';
import { PipelineEntityService } from '../../../../shared/pipeline-entity.service';
import { cloneDeep } from 'lodash';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
import { Pipeline } from 'src/app/pipelines/pipeline/shared/pipeline';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';

@Component({
  selector: 'p-connect-change-column-mapping-defaults-tab',
  templateUrl: './change-column-mapping-defaults-tab.component.html',
  styleUrls: ['./change-column-mapping-defaults-tab.component.scss']
})
export class ChangeColumnMappingDefaultsTabComponent implements OnInit {
  @Input() isTargetExists: boolean;
  @Input() columnMappingType;
  @Output() disableSaveButton = new EventEmitter<any>();
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  pipeline: Pipeline;
  dataConnectionType;
  mapColumnsByDropdownData = [
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.MAP_COLUMNS_BY_DROPDOWN_DATA.COLUMN_NAME',
      value: 'COLUMN_NAME'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.MAP_COLUMNS_BY_DROPDOWN_DATA.COLUMN_ORDER',
      value: 'COLUMN_ORDER'
    }
  ];
  includeRowMetaDataDropdownData = [
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.INCLUDE_ROW_METADATA_DROPDOWN_DATA.SELECT_ROW_METADATA',
      value: 'SELECT_ROW_METADATA'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.INCLUDE_ROW_METADATA_DROPDOWN_DATA.NO_ROW_METADATA',
      value: 'NO_ROW_METADATA'
    }
  ];
  defaultsTabFormGroup: FormGroup;
  metaDataforDB2IBMi;
  metaDataCheckboxField = true;
  payloadForDefaults = {};
  storeDefaultsData;
  rowMetadata;
  isUpdateDefaultClicked: boolean = false;

  @Input()
  set defaultsMetaData(data) {
    this.rowMetadata = data;
    if (!this.isUpdateDefaultClicked) {
      this.getDefaultData();
    }
  }

  constructor(
    public readonly translocoService: TranslocoService,
    private formBuilder: FormBuilder,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly mappingService: PipelineMappingService
  ) {}

  ngOnInit(): void {
    this.createForm();
    this.dataConnectionType = this.pipelineEntityService.getConnectionType();
  }

  loadDefaultTab(isUpdateDefaultClicked: boolean) {
    this.isUpdateDefaultClicked = isUpdateDefaultClicked;
    if (isUpdateDefaultClicked) {
      this.getUpdatedRowMetadata();
    }
  }

  // this gets called when no row is selected
  getDefaultData() {
    let isIncludeExist = this.rowMetadata?.some((element) => element.cdcRowMetadataType == 'INCLUDE');
    this.checkIsIncludeExist(isIncludeExist);
  }

  getUpdatedRowMetadata() {
    this.mappingService?.getChangeColumnMappingDefaults(this.pipelineEntityService.getPipeline().id)?.subscribe({
      next: (data) => {
        this.rowMetadata = data.cdcRowMetadatas;
        this.metadataAlphabeticalSort();
        let isIncludeExist = this.rowMetadata?.some((element) => element.cdcRowMetadataType == 'INCLUDE');
        this.checkIsIncludeExist(isIncludeExist);
      },
      error: (errorResponse) => {
        this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
      }
    });
  }

  checkIsIncludeExist(isIncludeExist: boolean) {
    if (isIncludeExist) {
      this.defaultsTabFormGroup.controls['includeRowMetaDataDropdown'].setValue(this.includeRowMetaDataDropdownData[0]);
      this.metaDataCheckboxField = true;
    } else {
      this.defaultsTabFormGroup.controls['includeRowMetaDataDropdown'].setValue(this.includeRowMetaDataDropdownData[1]);
      this.metaDataCheckboxField = false;
    }
    this.rowMetadata?.forEach((element) => {
      element.cdcRowMetadataType == 'INCLUDE' ? (element['isChecked'] = true) : (element['isChecked'] = false);
    });
    this.storeDefaultsData = this.rowMetadata;
  }

  createForm() {
    this.defaultsTabFormGroup = this.formBuilder.group({
      mapColumnsByDropdown: new FormControl({
        value: this.mapColumnsByDropdownData[0]?.value,
        name: this.mapColumnsByDropdownData[0]?.name
      }),
      includeRowMetaDataDropdown: new FormControl({
        value: this.includeRowMetaDataDropdownData[0]?.value,
        name: this.includeRowMetaDataDropdownData[0]?.name
      })
    });
  }

  mapColumnsByDropdownChange(event) {
    this.columnMappingType = event.value.value;
  }

  includeRowMetaDataDropdownChanged(event) {
    if (event.value.value === 'SELECT_ROW_METADATA') {
      this.metaDataCheckboxField = true;
      this.rowMetadata = cloneDeep(this.storeDefaultsData);
    } else if (event.value.value === 'NO_ROW_METADATA') {
      this.storeDefaultsData = cloneDeep(this.rowMetadata);
      this.metaDataCheckboxField = false;
      this.rowMetadata?.forEach((element) => {
        element['isChecked'] = false;
        element.cdcRowMetadataType = 'EXCLUDE';
      });
    }
    this.rowMetaDataCheckAll();
  }

  rowMetaDataCheckAll() {
    let excludeCoundt = 0;
    this.rowMetadata?.forEach((element) => {
      if (element.cdcRowMetadataType === 'EXCLUDE') {
        excludeCoundt++;
      }
    });
    if (excludeCoundt === this.rowMetadata?.length) {
      this.rowMetadata?.forEach((element) => {
        element['isChecked'] = true;
        element.cdcRowMetadataType = 'INCLUDE';
      });
    }
  }

  disableSaveButtonIfUnchecked() {
    const getDefaultsTabMetaData = this.getDefaultsPayloadData();
    const isDisableSaveBtn = Object.values(getDefaultsTabMetaData.payload).some((val) => val === 'INCLUDE');
    this.disableSaveButton.emit(isDisableSaveBtn);
  }

  getDefaultEmittedData(metaData) {
    this.rowMetadata = metaData;
  }

  getColumnMappingType(columnMappingType) {
    if (columnMappingType === 'COLUMN_ORDER') {
      return 'Column order';
    } else {
      return 'Column name';
    }
  }

  getDefaultsPayloadData() {
    this.rowMetadata.forEach((data) => {
      if (this.defaultsTabFormGroup.get('includeRowMetaDataDropdown').value.name === this.includeRowMetaDataDropdownData[0].name) {
        this.payloadForDefaults[data.key] = data.cdcRowMetadataType;
      } else {
        this.payloadForDefaults[data.key] = 'EXCLUDE';
      }
    });
    return {
      payload: this.payloadForDefaults,
      mapColumns: this.isTargetExists ? this.getColumnMappingType(this.columnMappingType) : undefined
    };
  }

  metadataAlphabeticalSort() {
    this.rowMetadata = this.rowMetadata.map((object) => ({
      ...object,
      displayLabel: this.translocoService.translate(
        `pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ROW_METADATA_FIELDS.` + object.key
      )
    }));
    this.rowMetadata.sort((a, b) => {
      return a.displayLabel.toLowerCase().localeCompare(b.displayLabel.toLowerCase());
    });
  }
}
