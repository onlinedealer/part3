import { Action, createReducer, on } from "@ngrx/store";
import { SecurityActions } from "../actions";

export interface ErrorState {
    errorCode?: number;
    errorText?: string;
    parameters?: string[];
}

export interface SecurityStateUser {
    userName: string;
    email: string;
    foreNames: string;
    fullName: string;
    languageCode: string;
    lastName: string;
    networkId: string;
    sessionTimeout: number;
    timeZone: string;
}
export interface SecurityState {
    authenticated: boolean;
    networks: string[];
    user?: SecurityStateUser;
    session: any;
    permissions: string[];
    roles: any[];
    loadingUserInfo: boolean;
    updatingSession: boolean;
    showingTimeoutDialog: boolean;
    securityResponseFailures: number;
    getUserFailed?: ErrorState;
    getSessionFailed?: ErrorState;
    securityFailed: boolean;
}

export const initialState: SecurityState = {
    authenticated: false,
    networks: [],
    user: undefined,
    session: undefined,
    permissions: [],
    roles: [],
    loadingUserInfo: false,
    updatingSession: false,
    showingTimeoutDialog: false,
    securityResponseFailures: 0,
    getUserFailed: {},
    getSessionFailed: {},
    securityFailed: false
};

const securityReducer = createReducer(
    initialState,

    on(SecurityActions.GetUserInfo, (state) => {
        return {
            ...state,
            loadingUserInfo: true
        };
    }),

    on(SecurityActions.GetUserInfoSuccess, (state, { response }: any) => {
        const permissions = response.permissions ? response.permissions : [];
        const networks = response.networks ? [...response.networks] : [];
        const roles = response.roles ? response.roles : [];
        const userName = response.user ? response.user.username : "";
        const userAttributes = response.userAttributes ? response.userAttributes : {};
        const sessionStorageUserName = sessionStorage.getItem("userName");
        if (sessionStorageUserName && sessionStorageUserName !== userName) {
            sessionStorage.clear();
        }
        sessionStorage.setItem("userName", userName);

        return {
            ...state,
            authenticated: response.authenticated,
            networks: networks.map((network: { name: string }) => network.name),
            permissions: permissions.filter((permission: string) => !permission.startsWith("IGM2") && !permission.startsWith("Dm")).sort(),
            roles: roles,
            loadingUserInfo: false,
            user: {
                userName: userName,
                ...userAttributes,
                username: undefined
            },
            getUserFailed: {},
            securityResponseFailures: 0,
            securityFailed: false
        };
    }),

    on(SecurityActions.GetUserInfoFail, (state, { error }) => {
        return {
            ...state,
            loadingUserInfo: true,
            getUserFailed: {
                ...state.getUserFailed,
                errorCode: error.errorCode ? error.errorCode : error.statusCode
            },
            securityResponseFailures: state.securityResponseFailures + 1,
            securityFailed: true
        };
    }),

    on(SecurityActions.UpdateSession, (state, error: any) => {
        return {
            ...state,
            updatingSession: true
        };
    }),

    on(SecurityActions.UpdateSessionSuccess, (state, response: any) => {
        return {
            ...state,
            updatingSession: false,
            session: response,
            securityResponseFailures: 0,
            securityFailed: false
        };
    }),

    on(SecurityActions.UpdateSessionFail, (state, error: any) => {
        return {
            ...state,
            updatingSession: false,
            getUserFailed: {
                ...state.getUserFailed,
                errorCode: error.error.errorCode ? error.error.errorCode : error.error.statusCode
            },
            securityResponseFailures: state.securityResponseFailures + 1,
            securityFailed: true
        };
    }),

    on(SecurityActions.ShowTimeoutDialog, (state) => ({
        ...state,
        showingTimeoutDialog: true
    })),

    on(SecurityActions.ClosedTimeoutDialog, (state) => ({
        ...state,
        showingTimeoutDialog: false
    }))
);

export function reducer(state: SecurityState | undefined, action: Action): SecurityState {
    return securityReducer(state, action);
}
