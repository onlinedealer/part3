import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import _ from 'lodash'
import LoadingHOC from '../common/HOC/LoadingHOC'
import PropTypes from 'prop-types'
import DashboardTable from './DashboardTable'
import DashboardToolbar from './DashboardToolbar'
import DashboardFooter from './DashboardFooter'
import GrouperDialog from '../common/GrouperDialog/GrouperDialog'
import { getFormatedDate } from '../common/Utils/CommonUtils'

const styles = theme => ({
  root: {
    padding: 0,
  },
})

export class Dashboard extends React.PureComponent {
  constructor (props) {
    super(props)

    this.state = {
      order: 'asc',
      orderBy: 'calories',
      selected: [],
      data: [],
      originalData: [],
      page: 0,
      rowsPerPage: 10,
      dialogOpenStatus: false,
      selectedGroup: '',
      selectedGroupType: '',
      totalListCount: 0,
    }
  }
  componentWillMount () {
    const newFilter = _.filter(this.props.grouperList.groups, function (obj) {
      return !obj.group_deleted
    })
    this.setState({ data: newFilter, originalData: newFilter, totalListCount: this.props.grouperList.count })
  }

  componentDidMount () {
    const newFilter = _.filter(this.props.grouperList.groups, function (obj) {
      return !obj.group_deleted
    })
    this.setState({ data: newFilter, originalData: newFilter, totalListCount: this.props.grouperList.count })
  }

  componentWillReceiveProps (nextProps) {
    const newFilter = _.filter(nextProps.grouperList.groups, function (obj) {
      return !obj.group_deleted
    })
    this.setState({ data: newFilter, originalData: newFilter, totalListCount: nextProps.grouperList.count })
  }

  getFilter = (selectRef) => {
    let tempData = this.state.originalData
    for (let key of Object.keys(selectRef)) {
      tempData = tempData.filter((o) => {
        const checkArr = key.split(',')
        let objVal = ''
        checkArr.map((obj, index) => {
          objVal = (objVal === '') ? o[obj] : objVal[obj]
        })
        const checkVal = (key === 'launch_date') ? getFormatedDate(objVal) : objVal
        return (checkVal && (checkVal.toLowerCase().indexOf(typeof selectRef[key] === 'string' ? selectRef[key].toLowerCase() : selectRef[key]) !== -1))
      })
    }
    this.setState({ data: tempData })
  }

  resetFilter = () => {
    this.setState({ data: this.state.originalData })
  }

  handleClick = (event, id, type) => {
    this.setState({dialogOpenStatus: true, selectedGroup: id, selectedGroupType: type})
  };

  deleteConfirm = (status) => {
    if (status) {
      const sendData = {
        group_id: this.state.selectedGroup,
        group_type: this.state.selectedGroupType,
      }
      this.props.deleteGroup(sendData, this.props.auth.memberOf, this.props.auth.lanId)
      this.setState({dialogOpenStatus: false, selectedGroup: '', selectedGroupType: ''})
    }
    if (!status) {
      this.setState({ dialogOpenStatus: false })
    } else {
      setTimeout(() => {
        this.props.closeSnackBar()
        this.setState({ dialogOpenStatus: false })
      }, 3000)
    }
  }

  deleteSelected = (listGroups) => {
    this.setState({ selected: listGroups })
  }

  deleteMultipleConfirmCheck = () => {
    this.setState({dialogOpenStatus: true, selectedGroup: this.state.selected, selectedGroupType: ''})
  }

  deleteMultipleConfirm = (status) => {
    if (status) {
      const sendArray = []
      for (let i = 0; i < this.state.selected.length; i++) {
        const sendData = {
          group_id: this.state.selected[i],
          group_type: _.find(this.state.data, (n) => { return n.group_id === this.state.selected[i] }).group_type,
        }
        sendArray.push(sendData)
        // this.props.deleteGroup(sendData, this.props.auth.memberOf, this.props.auth.lanId)
      }
      const sendDataArray = { group_ids: sendArray }
      this.props.deleteGroupMultiple(sendDataArray, this.props.auth.memberOf, this.props.auth.lanId)
      /* for (let i = 0; i < this.state.selected.length; i++) {
        const sendData = {
          group_id: this.state.selected[i],
          group_type: _.find(this.state.data, (n) => { return n.group_id === this.state.selected[i] }).group_type,
        }
        this.props.deleteGroup(sendData, this.props.auth.memberOf, this.props.auth.lanId)
      } */
    }
    this.setState({dialogOpenStatus: false, selectedGroup: '', selectedGroupType: ''})
  }

  render () {
    const { classes } = this.props
    const { data, order, orderBy, rowsPerPage, page, dialogOpenStatus, originalData, totalListCount } = this.state
    const isDeleteDisabled = (this.state.selected.length === 0)
    return (
      <div className={classes.wrapper}>
        <DashboardToolbar
          onFilterRequest={this.getFilter}
          onFilterReset={this.resetFilter}
          listItems={originalData}
          loadingBtnStatus={this.props.loadingBtnStatus}
          groupTypes={this.props.groupTypes}
          groupListRequestParams={this.props.groupListRequestParams}
          getGrouperList={this.props.getGrouperList}
          updateGroupListRequestParams={this.props.updateGroupListRequestParams}
          statusList={this.props.statusList}
        />
        <DashboardTable
          items={data}
          page={page}
          order={order}
          orderBy={orderBy}
          rowsPerPage={rowsPerPage}
          validateDelete={this.handleClick}
          handleChangePage={this.handleChangePage}
          handleChangeRowsPerPage={this.handleChangeRowsPerPage}
          deleteSelectedCB={this.deleteSelected}
          history={this.props.history}
          groupListRequestParams={this.props.groupListRequestParams}
          getGrouperList={this.props.getGrouperList}
          updateGroupListRequestParams={this.props.updateGroupListRequestParams}
          totalListCount={totalListCount}
        />
        {data.length > 0 &&
          <DashboardFooter
            isDeleteDisabled={isDeleteDisabled}
            deleteMultipleConfirmCB={this.deleteMultipleConfirmCheck}
            loadingBtnStatus={this.props.loadingBtnStatus}
          />
        }
        <GrouperDialog
          openStatus={dialogOpenStatus}
          deleteConfirmCallback={this.deleteMultipleConfirm}
          title="Delete Group(s)"
          message={`Are you sure to delete ${this.state.selectedGroup.length} group(s)? : ${this.state.selectedGroup}`}
          disAgreeText="Cancel"
          agreeText="Delete"
        />
      </div>
    )
  }
}

Dashboard.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default LoadingHOC(['grouperList'])((withStyles(styles)(Dashboard)))
