import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoService } from '@ngneat/transloco';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { SecondaryNavItemsService, SharedConstants } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { ObserverService } from 'observer/observer.service';
import { ConfirmationService, MenuItem } from 'primeng/api';
import { Table } from 'primeng/table';
import { ScheduleSidebarConfigModel } from 'shared/schedule/schedule-detail/schedule-sidebar-config.model';
import { ObserverListModel } from './observer-list.model';

@Component({
  selector: 'discovery-observer-listing',
  templateUrl: './observer-listing.component.html',
  styleUrls: ['./observer-listing.component.css'],
  providers: [ConfirmationService]
})
export class ObserverListingComponent implements OnInit {
  isLoading = true;
  /**
   *
   */
  @ViewChild('observerTable') observerTable: Table;

  /**
   *
   */
  items: MenuItem[];
  observerList: any;
  fetchObserverInProgress = false;

  /**
   *
   */
  baseUrl: string;

  /**
   * menu items for secondary navigation left sliding menu
   */
  navItems: MenuItem[];

  scheduleType: ScheduleSidebarConfigModel;

  scheduleSidebarToggle: boolean;

  get emailNotificationFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.EMAIL_NOTIFICATION);
  }

  constructor(
    private navItemsService: SecondaryNavItemsService,
    private translocoService: TranslocoService,
    private confirmationService: ConfirmationService,
    private observerService: ObserverService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private toastrService: ToastrService,
    private launchDarklyService: LaunchDarklyService,
    httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('dataobservabilityconfig', 'profiling', 'api/v1/');
    this.observerList = [];
  }
  ngOnInit(): void {
    this.loadObserverList();
    this.navItems = this.navItemsService.getNavItems();
  }

  filterGlobal($event: Event, contains: string) {
    this.observerTable.filterGlobal(($event?.target as HTMLInputElement)?.value, contains);
  }

  loadObserverList() {
    this.isLoading = true;
    this.observerService.getObserverList().subscribe(
      (observers: ObserverListModel[]) => {
        this.isLoading = false;
        this.observerList = observers;
      },
      (error) => {
        this.isLoading = false;
      }
    );
  }

  deleteObserver(observer: ObserverListModel) {
    this.confirmationService.confirm({
      message: this.translocoService.translate('discoveryObserver.listing.deleteMessage', {
        observerName: observer.name
      }),
      header: this.translocoService.translate('discoveryObserver.listing.deleteTitle'),
      icon: 'pi pi-info-circle',
      accept: () => {
        this.observerService.deleteObserver(observer.observableId).subscribe(
          (response) => {
            this.loadObserverList();
          },
          (httpErrorResponse: HttpErrorResponse) => {
            let errorMsg = httpErrorResponse?.message;
            if (httpErrorResponse.status === 404) {
              errorMsg = this.translocoService.translate('discoveryObserver.listing.profileNotFound');
            } else if (httpErrorResponse.status === 400) {
              errorMsg = httpErrorResponse.error.message;
            } else if (httpErrorResponse.status === 423) {
              errorMsg = this.translocoService.translate('discoveryObserver.listing.observerDeleteRunningError');
            } else if (httpErrorResponse.status === 403) {
              errorMsg = this.translocoService.translate('discoveryObserver.listing.unauthorized');
              this.toastrService.error(errorMsg);
            }
            if (httpErrorResponse.status !== 403) {
              this.toastrService.error(errorMsg);
            }
          }
        );
      },
      reject: () => {
        console.log('Delete Cancel');
      }
    });
  }

  editObserver(observerId: string) {
    this.router.navigateByUrl('/data-observability/observers/edit/' + observerId);
  }
  onContextMenu(rowData: ObserverListModel) {
    this.items = [
      {
        label: this.translocoService.translate('discoveryObserver.listing.editMenu'),
        command: () => this.editObserver(rowData.observableId)
      },
      {
        label: this.translocoService.translate('discoveryObserver.listing.deleteMenu'),
        command: () => this.deleteObserver(rowData)
      }
    ];
  }

  getObserverDetailView(rowData: ObserverListModel) {
    if (rowData) {
      this.observerService.getObserver(rowData.observableId).subscribe({
        next: (response: ObserverListModel) => {
          if (response) {
            this.router.navigate(['observer-detail', rowData.name, rowData.observableId, 'alerts'], {
              queryParams: {
                profileId: rowData.profileId,
                runId: response?.lastProfileRunDetails?.runId
              },
              relativeTo: this.activatedRoute
            });
          }
        },
        error: (httpErrorResponse: HttpErrorResponse) => {
          if (httpErrorResponse.status === 404) {
            this.toastrService.error(
              this.translocoService.translate('discoveryObserver.observerConfigure.observerNotFound')
            );
            this.loadObserverList();
          }
        }
      });
    }
  }

  showScheduleSidebar(rowData) {
    this.scheduleSidebarToggle = true;
    this.scheduleType = {
      viewType: rowData.scheduleConfig.enabled
        ? SharedConstants.SCHEDULE_STATUS.ENABLED
        : rowData.scheduleConfig['status'],
      id: rowData.profileId,
      editEnabled: false,
      source: SharedConstants.SCHEDULER_SOURCE.OBSERVER,
      name: rowData.name
    };
  }

  onToggleEmailNotification(observableId: string) {
    this.observerList = this.observerList.map((observer) => {
      if (observer.observableId === observableId) {
        observer['notificationConfig'] = !observer['notificationConfig'];
      }
      return observer;
    });
  }
}
