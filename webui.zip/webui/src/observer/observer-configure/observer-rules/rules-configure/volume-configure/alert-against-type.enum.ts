export enum AlertAgainstTypeEnum {
  MOVING_AVERAGE = 'MOVING_AVERAGE',
  LAST_PROFILE_RUN = 'LAST_PROFILE_RUN'
}
