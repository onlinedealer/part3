import { Component, Input, AfterViewInit, OnInit } from "@angular/core";
import { MeterConnection } from "../../models/meterconnection.model";
import { MeterConnectionActions, SecondarySideviewActions } from "../../store/actions";
import {
    MeterConnectionSelectors,
    MeterConnectionsWithConfigurationsSelectors,
    RegistersSelectors,
    MeteringsSelectors,
    MeteringPointsUISelectors
} from "../../store/selectors";
import { MeterConnectionVO } from "../../models/view-objects/meterconnection-vo.model";
import { MeteringPoint } from "../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { Observable } from "rxjs";
import { RegisterVO } from "../../models/view-objects/register-vo.model";
import { RouterSelectors } from "../../../app/store/selectors";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../app/services/translations-service";
import { LocalStorageService, LocalStorageKeys } from "../../../app/services/local-storage.service";

@Component({
    selector: "landisgyr-meteringpoint-devices",
    templateUrl: "./meteringpoint-devices.component.html",
    styleUrls: ["./meteringpoint-devices.component.scss"]
})
export class MeteringPointDevicesComponent implements OnInit, AfterViewInit {
    protected urlSubPath = "devices";
    changed = false;
    mpDevicesColConfig: any;

    @Input()
    meteringPoint!: MeteringPoint;
    loading$: Observable<boolean> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);

    refreshDataLoading$: Observable<boolean> = this.store.select(MeterConnectionSelectors.getLoadingData);

    selectedMeterConnection$: Observable<MeterConnection | undefined> = this.store.select(
        MeterConnectionSelectors.getSelectedMeterConnection
    );

    meterConnections$: Observable<MeterConnectionVO[]> = this.store.select(
        MeterConnectionsWithConfigurationsSelectors.getSelectedMeteringPointMeterConnectionsEntitiesForTable
    );

    registers$: Observable<RegisterVO[]> = this.store.select(RegistersSelectors.getSelectedMeterConnectionRegistersEntitiesForTable);

    infoMessage: string = $localize`:|@@devices.noDevicesMessage:No devices`;

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        public translations: TranslationsService,
        private localStorage: LocalStorageService
    ) {}

    ngOnInit() {
        this.store.select(MeterConnectionSelectors.getSelectedDeviceMeterId).subscribe((data) => {
            if (data) {
                const deviceId = data;
                this.store.dispatch(MeterConnectionActions.LoadDevicesCustomProperty({ deviceMeterId: deviceId }));
            }
        });

        this.localStorage.changedColumnInfo.subscribe((data) => {
            if (data.key === LocalStorageKeys.mpDevicesTable) {
                this.changed = true;
                this.mpDevicesColConfig = data.value;
            }
        });
        if (!this.changed) {
            if (this.localStorage.getColumnConfiguration(LocalStorageKeys.mpDevicesTable)) {
                this.mpDevicesColConfig = this.localStorage.getColumnConfiguration(LocalStorageKeys.mpDevicesTable);
            } else {
                this.store.select(MeteringPointsUISelectors.getMPDevicesColumnConfigInitial).subscribe((data) => {
                    this.mpDevicesColConfig = data;
                });
            }
        }
    }

    onSelectMeterConnection(meterConnection: MeterConnectionVO) {
        const meterConnectionId = meterConnection.meterConnectionId;
        this.store.dispatch(
            MeterConnectionActions.SelectMeteringPointMeterConnection({ meteringPointId: this.meteringPoint.id, meterConnectionId })
        );
        const deviceId = meterConnection.deviceMeterId;
        this.store.dispatch(MeterConnectionActions.LoadDevicesCustomProperty({ deviceMeterId: deviceId }));
    }

    openDevicesRelaysSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.openDevicesRelaysSecondarySideview());
    }

    openDevicesConfigurationsAndRegistersSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.openDevicesConfigurationsAndRegistersSecondarySideview());
    }

    openDevicesTransformerSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.openDevicesTransformerSecondarySideview());
    }

    openDevicesCustomPropertiesSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.openDevicesCustomPropertiesSecondarySideview());
    }

    ngAfterViewInit() {
        setTimeout(() => this.checkURLForSecondarySideview());
    }

    checkURLForSecondarySideview() {
        this.store
            .select(RouterSelectors.getLastSegment)
            .subscribe((lastSegment) => {
                if (lastSegment === "relays") {
                    this.openDevicesRelaysSecondarySideview();
                } else if (lastSegment === "configurationsRegisters") {
                    this.openDevicesConfigurationsAndRegistersSecondarySideview();
                } else if (lastSegment === "transformer") {
                    this.openDevicesTransformerSecondarySideview();
                } else if (lastSegment === "parametersAndStatuses") {
                    this.openDevicesCustomPropertiesSecondarySideview();
                }
            })
            .unsubscribe();
    }
}
