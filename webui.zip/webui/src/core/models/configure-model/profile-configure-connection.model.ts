export class ProfileConfigureConnectionModel {
  id: string;
}
