import { Router, Request, Response } from "express";
import { SecurityService } from "../services/security.service";

export const securityRouter = Router();

securityRouter.get("/getUserInfo", (req: Request, res: Response) => {
  SecurityService.getUserInfo().subscribe(
    (response: string) => res.send(response),
    (error: any) => {
      res.status(543).json(error);
    }
  );
});

securityRouter.post("/updateSession", (req: Request, res: Response) => {
  SecurityService.updateSession().subscribe(
    (response: string) => res.send(response),
    (error: any) => {
      res.status(543).json(error);
    }
  );
});

securityRouter.get("/logout", (req: Request, res: Response) => {
  SecurityService.logout().subscribe(
    (response: string) => res.send(response),
    (error: any) => {
      res.status(543).json(error);
    }
  );
});
