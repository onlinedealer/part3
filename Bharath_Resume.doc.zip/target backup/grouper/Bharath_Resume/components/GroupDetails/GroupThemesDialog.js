import React from 'react'
import _ from 'lodash'
import { withStyles } from '@material-ui/core/styles'
import Button from '@material-ui/core/Button'
import Grid from '@material-ui/core/Grid'
import FormHelperText from '@material-ui/core/FormHelperText'
import * as Constants from '../common/Utils/Constants'
import { compareThemes } from '../common/Utils/CommonUtils'
import CircularProgress from '@material-ui/core/CircularProgress'
import VariationThemes from '../common/ThemeField/VariationThemes'

const styles = theme => ({
  heading: {
    fontSize: 18,
    fontWeight: 500,
    paddingBottom: '16px',
  },
  helperText: {
    marginTop: 8,
  },
  formControl: {
    marginTop: 24,
    width: '100%',
  },
  field: {
    marginTop: 24,
    width: '100%',
  },
  textHead1: {
    fontSize: 13,
    fontWeight: 500,
  },
  textSmall: {
    fontSize: 11,
    fontStyle: 'italic',
    color: '#999',
  },
  actionContainer: {
    padding: '24px 16px',
  },
  updateButtonStyle: {
    color: '#fff',
    float: 'right',
    background: '#1976d2',
    fontWeight: 300,
    marginLeft: 10,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  content: {
    /* minHeight: '490px', */
    overflowY: 'visible',
  },
  dialog: {
    width: '328px',
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  themeRow: {
    width: '100%',
  },
})
class GroupThemesDialog extends React.Component {
  constructor (props) {
    super(props)

    this.state = {

      errorText: '',
      formData: {
        themes: {},
      },
      errors: {

      },
    }
  }

  validateSubmit = () => {
    const formData = { ...this.state.formData }
    const errors = { ...this.state.errors }
    const { groupDetails } = this.props
    let payload = {}
    let themesData = []
    payload.group_name_updated = false
    payload.theme_updated = false
    let isValid = true
    if (!formData.themes['theme1']) {
      errors.theme1 = Constants.ERROR_THEME1_REQ
      isValid = false
    } else {
      let count = 1
      Object.keys(formData.themes).map((key) => {
        const curObj = _.find(this.props.itemThemes, (n) => { return formData.themes[key].id === n.id })
        const fixedThemeObj = _.find(this.props.fixedThemes, (e) => { return e.fixed_theme_id === formData.themes[key].fixed_theme_id })
        const sendObj = { id: curObj.id, fixed_theme_id: fixedThemeObj.fixed_theme_id, fixed_theme_name: fixedThemeObj.fixed_theme_name, attribute: curObj.name, attribute_type: curObj.attribute_type, theme_sort_order: count }
        themesData.push(sendObj)
        count++
      })
      groupDetails.items.map((itemObj) => {
        themesData.map((themesObj) => {
          if (!itemObj.variation_theme_values[themesObj.attribute]) {
            itemObj.variation_theme_values[themesObj.attribute] = ''
          }
        })
      })

      if (compareThemes(groupDetails.themes, themesData)) {
        payload.theme_updated = true
      }
      payload.themes = themesData
      errors.themes = ''
    }

    if (isValid && groupDetails && groupDetails.group_id) {
      let updatedGroupDetails = {...groupDetails}
      let themeUpdatedFlag = false
      updatedGroupDetails.themes.map((themeObj) => {
        const curObj = _.find(themesData, (e) => { return (e.id === themeObj.id && e.fixed_theme_id === themeObj.fixed_theme_id && e.theme_sort_order === themeObj.theme_sort_order) })
        if (!curObj) {
          themeUpdatedFlag = true
        }
      })
      updatedGroupDetails.themes = themesData
      this.props.setGroupDetails(updatedGroupDetails)
      this.props.themeUpdatedFlagCB(themeUpdatedFlag)
    } else {
      this.setState({ errors })
    }
    /* if (isValid && groupDetails && groupDetails.group_id) {
      payload.description = groupDetails.description
      payload.group_type = groupDetails.group_type
      payload.group_name = groupDetails.group_name
      payload.group_id = groupDetails.group_id
      payload.group_type_id = groupDetails.group_type_id
      payload.status = groupDetails.status
      payload.item_type_id = groupDetails.item_type_id
      payload.item_type = groupDetails.item_type
      payload.tcin_data = []
      if (groupDetails.group_type === 'collection') {
        console.log('payload')
        console.log(payload)
        // this.props.updateGroupName(payload, auth.memberOf, auth.lanId)
      } else if (groupDetails.group_type === 'variation') {
        let updatedGroupDetails = {...groupDetails}
        updatedGroupDetails.themes = themesData
        this.props.setGroupDetails(updatedGroupDetails)
      }
    } else {
      this.setState({ errors })
    } */
  }

  handleChange = (name, value) => {
    const formData = { ...this.state.formData }
    formData[name] = value
    this.setState({ formData })
  }

  changeThemeVariation = () => {
    const formData = { ...this.state.formData }
    const { variationPage1Data } = this.props
    let themesData = []
    let count = 1
    Object.keys(formData.themes).map((key) => {
      const curObj = _.find(this.props.itemThemes, (n) => { return formData.themes[key].id === n.id })
      const fixedThemeObj = _.find(this.props.fixedThemes, (e) => { return e.fixed_theme_id === formData.themes[key].fixed_theme_id })
      const sendObj = { id: curObj.id, fixed_theme_id: fixedThemeObj.fixed_theme_id, fixed_theme_name: fixedThemeObj.fixed_theme_name, attribute: curObj.name, attribute_type: curObj.attribute_type, theme_sort_order: count }
      themesData.push(sendObj)
      count++
    })
    variationPage1Data.themes = themesData
    this.props.updateVariationDetails(variationPage1Data, 'Save')
  }

  render () {
    const { classes, closeDrawer, itemThemes, groupDetails, loadingBtnStatus, fixedThemes } = this.props
    const { formData, errors } = this.state

    let saveDisableState = true
    /* groupDetails.themes.map((obj, index) => {
      if (formData.themes[`theme${index + 1}`] !== obj.id) {
        saveDisableState = false
      }
    }) */

    if (Object.keys(formData.themes).length > 0) {
      saveDisableState = false
    }

    let btnText = groupDetails.group_id ? 'Save' : 'Change'
    let btnClickEvent = groupDetails.group_id ? this.validateSubmit : this.changeThemeVariation
    return (
      <div>
        <Grid container>
          <Grid item xs={12}>
            <h4>Edit Themes</h4>
          </Grid>
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={12}>
                <div className={classes.textSmall}>Minimum of 1 theme must be entered.</div>
                <div className={classes.textSmall}>Changing the order will display to the guest</div>
              </Grid>
              <VariationThemes
                itemThemes={itemThemes}
                fixedThemes={fixedThemes}
                onHandleChange={this.handleChange}
                groupDetails={groupDetails}
                classes={classes}
              />
            </Grid>
            {(errors.themes) && <FormHelperText error className={classes.helperText}>{errors.themes}</FormHelperText>}
          </Grid>
          <Grid item xs={12} className={classes.actionContainer}>
            <Button onClick={btnClickEvent} color="primary" className={classes.updateButtonStyle} disabled={saveDisableState}>
              {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Save') &&
                <CircularProgress
                  className={classes.progress}
                  size={25}
                />
              }
              {btnText}
            </Button>
            <Button onClick={closeDrawer} color="primary" className={classes.cancelButtonStyle} >
                Cancel
            </Button>
          </Grid>
        </Grid>
      </div>
    )
  }
}

export default withStyles(styles)(GroupThemesDialog)
