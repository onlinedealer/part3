import _ from 'lodash'

export function getGroupTypesOptions (arr) {
  return arr.map(function (obj) {
    var rObj = {}
    rObj.label = obj.name
    rObj.value = obj.id
    return rObj
  })
}

export function getItemTypesOptions (arr) {
  return arr.map(function (obj) {
    var rObj = {}
    rObj.label = obj.item_type_name
    rObj.value = obj.item_type_id
    return rObj
  })
}

export function getThemesOptions (arr) {
  return arr.map(function (obj) {
    var rObj = {}
    rObj.label = obj.name
    rObj.value = obj.id
    return rObj
  })
}

export function getFixedThemesOptions (arr) {
  return arr.map(function (obj) {
    var rObj = {}
    rObj.label = obj.fixed_theme_name
    rObj.value = obj.fixed_theme_id
    return rObj
  })
}

export function getCollectionMTAOptions (arr) {
  return arr.map(function (obj) {
    var rObj = {}
    rObj.label = obj.uda_lov_value_name
    rObj.value = obj.uda_lov_value_name
    return rObj
  })
}

export function getCollectionMTAUOMOptions (arr) {
  return arr.map(function (obj) {
    var rObj = {}
    rObj.label = obj.uom_name
    rObj.value = obj.uom_name
    return rObj
  })
}

export function getFormatedDate (dt) {
  const month = [ 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec' ]
  if (dt) {
    let fdate = new Date(dt)
    var mm = fdate.getMonth()
    var dd = fdate.getDate()

    return [
      month[mm], ' ',
      (dd > 9 ? '' : '0') + dd, ', ',
      fdate.getFullYear(),

    ].join('')
  } else {
    return ''
  }
}

export function changeLaunchDateEditFormat (dt) {
  if (dt) {
    let fdate = new Date(dt)
    var mm = fdate.getMonth() + 1
    var dd = fdate.getDate()
    var yyyy = fdate.getFullYear()
    mm = mm < 10 ? '0' + mm : mm
    dd = dd < 10 ? '0' + dd : dd
    return yyyy + '-' + mm + '-' + dd
  } else {
    return ''
  }
}

export function changeDateToTimestamp (dt) {
  var date = new Date(dt)
  var milliseconds = date.getTime()
  return milliseconds
}

export function sortData (order, orderBy) {
  return order === 'desc' ? (a, b) => b[orderBy] - a[orderBy] : (a, b) => a[orderBy] - b[orderBy]
}

export function isEmpty (data) {
  return (data === null ||
  data === undefined ||
  (data.hasOwnProperty('length') && data.length === 0) ||
  (data.constructor === Object && Object.keys(data).length === 0))
}

export function getStatusFormat (data) {
  if (data !== undefined && data !== null) {
    return data.replace(/_/gi, ' ').toLowerCase()
  }
  return ' '
}

export function convertStatusFormat (data) {
  if (data !== undefined && data !== null) {
    return data.replace(/ /gi, '_').toUpperCase()
  }
  return ' '
}

export function getStatusStyle (data) {
  if (data === 'READY_FOR_LAUNCH') {
    return 'groupStateRFL'
  } else if (data === 'READY_FOR_ORDER') {
    return 'groupStateRFO'
  } else if (data === 'INITIATED') {
    return 'groupStateIn'
  } else if (data === 'HISTORICAL') {
    return 'groupStateHis'
  }
  return ' '
}

export function compareThemes (master, updated) {
  if (master.length !== updated.length) {
    return true
  }
  for (var i = 0, len = updated.length; i < len; i++) {
    const curObj = _.find(master, (n) => { return n.id === updated[i].id })
    if (!curObj) {
      return true
    }
    if (master[i].id !== updated[i].id) {
      return true
    }
  }
  return false
}

export function compareCollectionThemes (master, updated) {
  if (master.length !== updated.length) {
    return true
  }
  for (var i = 0, len = updated.length; i < len; i++) {
    const curObj = _.find(master, (n) => { return n.id === updated[i].id })
    if (!curObj) {
      return true
    } else {
      if ((curObj.attribute_value.length !== updated[i].attribute_value.length) || (curObj.attribute_uom_value !== updated[i].attribute_uom_value)) {
        return true
      }
    }
  }
  return false
}

export function convertDateTimeToMilli (dt, tm) {
  tm = tm + ':00' //  adding seconds to '00'
  var date = new Date(dt + 'T' + tm)
  var milliseconds = date.getTime()
  return milliseconds
}

export function convertMilliToHoursMin (dt) {
  if (dt) {
    let fdate = new Date(dt)
    var hh = fdate.getHours()
    var mm = fdate.getMinutes()
    hh = hh < 10 ? '0' + hh : hh
    mm = mm < 10 ? '0' + mm : mm
    return hh + ':' + mm
  } else {
    return ''
  }
}
