import { Component, Input, OnInit, Output, EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { TranslationsService } from "../../../../app/services/translations-service";
import { FormGroup, FormControl } from "@angular/forms";
import { properties } from "../../../models/constants/properties";
import { ControlRelayTranslations } from "../../../RelayControl/translations/control-relay.translations";

@Component({
    selector: "landisgyr-set-relay-usage-dialogs",
    templateUrl: "./set-relay-usage-dialogs.component.html",
    styleUrls: ["./set-relay-usage-dialogs.component.scss"]
})
export class SetRelayUsageDialogsComponent implements OnInit, OnChanges {
    constructor(public dialog: MatDialog, public translationsService: ControlRelayTranslations, public translations: TranslationsService) {}
    @Input()
    header!: string;

    @Input()
    operation!: string;

    @Input()
    relay!: any;

    @Input()
    allRelayTypes!: any;

    @Input()
    allUsages!: string[];

    @Input()
    existingRelayTypes!: string[];

    @Input()
    loading!: boolean;

    @Input()
    existingUsages!: string[];

    @Input()
    errorMessage!: number;
    usageDropDownText = false;
    relayDropDownText = false;

    @Output() relayAddFormGroup: EventEmitter<any> = new EventEmitter();

    @Output() relayEditFormGroup: EventEmitter<any> = new EventEmitter();

    @Output() setRelayUsageDeleteClick: EventEmitter<null> = new EventEmitter();

    setRelayUsageForm = new FormGroup({
        relayTypes: new FormControl(),
        relayUages: new FormControl(),
        controlLogicType: new FormControl()
    });

    infoMessage!: string;
    errorTextMessge!: string;
    addErrorText = $localize`:|@@setRelayUsageDialog.errorForAdd:Failed to add a new relay:`;
    editErrorText = $localize`:|@@setRelayUsageDialog.errorForEdit:Failed to edit an existing relay:`;
    deleteErrorText = $localize`:|@@setRelayUsageDialog.errorForDelete:Failed to delete an existing relay:`;

    isDisable(relayTypesOrUsages: any, dropDownType: string) {
        let index;
        if (dropDownType === "relays") {
            index = this.existingRelayTypes.indexOf(relayTypesOrUsages);
        } else if (dropDownType === "usages") {
            index = this.existingUsages.indexOf(relayTypesOrUsages);
        }
        if (index === -1) {
            return false;
        } else {
            return true;
        }
    }

    public reversedToText(reversed: boolean): string {
        return reversed ? "true" : "false";
    }

    ngOnInit() {
        this.errorTextMessge =
            this.operation === "add" ? this.addErrorText : this.operation === "edit" ? this.editErrorText : this.deleteErrorText;
        this.setErrorMesage(this.errorMessage);
        if (this.operation === "edit") {
            this.setRelayUsageForm.controls.relayTypes.setValue(this.relay.relayId);
            this.setRelayUsageForm.controls.relayUages.setValue(this.relay.usage);
            this.setRelayUsageForm.controls.controlLogicType.setValue(this.reversedToText(this.relay.reversed));
            this.usageDropDownText = true;
        } else {
            this.setRelayUsageForm.controls.relayTypes.setValue("relayPlaceholder");
            this.setRelayUsageForm.controls.relayUages.setValue("usagePlaceholder");
            this.setRelayUsageForm.controls.controlLogicType.setValue(properties.controlLogic);
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.errorMessage && changes.errorMessage.currentValue) {
            if (changes.operation && changes.operation.currentValue) {
                const operationName = changes.operation.currentValue;
                this.errorTextMessge =
                    operationName === "add" ? this.addErrorText : operationName === "edit" ? this.editErrorText : this.deleteErrorText;
            }
            this.setErrorMesage(changes.errorMessage.currentValue);
        }
    }

    setErrorMesage(errorCode: number) {
        if (errorCode) {
            this.infoMessage = this.errorTextMessge + this.translationsService.getControlRelayErrorMsgTranslation(errorCode);
        }
    }

    onClickCancel() {
        this.dialog.closeAll();
    }

    onClickAdd() {
        this.relayAddFormGroup.emit(this.setRelayUsageForm);
    }

    onClickDelete() {
        this.setRelayUsageDeleteClick.emit();
    }

    onClickSave() {
        this.relayEditFormGroup.emit(this.setRelayUsageForm);
    }

    selectedUsageDropDownValue(event: any) {
        this.usageDropDownText = true;
    }

    selectedRelayDropDownValue(event: any) {
        this.relayDropDownText = true;
    }
}
