import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import FormHelperText from '@material-ui/core/FormHelperText'
import Tooltip from '@material-ui/core/Tooltip'
import RemoveIcon from '@material-ui/icons/RemoveCircle'
import IconButton from '@material-ui/core/IconButton'
import AddCircle from '@material-ui/icons/AddCircle'
import { getThemesOptions } from '../Utils/CommonUtils'
import Button from '@material-ui/core/Button'
import IntegrationReactSelect from '../GrouperAutoComplete/IntegrationReactSelect'

const styles = theme => ({
  helperText: {
    marginTop: 8,
  },
  IconButton: {
    width: '100%',
    height: '100%',
    '&:hover': {
      background: 'transparent',
    },
  },
  iconColor: {
    color: '#1976d2',
  },
  addThemeIcon: {
    color: '#1976d2',
    width: 15,
    paddingRight: 5,
  },
  addThemeButtonStyle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#1976d2',
    padding: 0,
    '&:hover': {
      background: 'none',
    },
  },
})

function ThemeField (props) {
  const isMultiple = false
  return (
    <div>
      <Grid item xs={12} className={props.classes.field}>
        <Grid container>
          <Grid item xs={11}>
            {/* <GrouperAutoComplete
              placeholderMsg={props.placeholder}
              isMultiOption="false"
              currentValue={props.value}
              column_id={props.id}
              options={getThemesOptions(props.themes)}
              inputType={props.inputType}
              handleSelectChange={props.handleSelectChange}
            /> */}
            <IntegrationReactSelect
              currentValue={props.value}
              column_id={props.id}
              options={getThemesOptions(props.themes)}
              isMultiOption={isMultiple}
              handleSelectChange={props.handleSelectChange}
              labeledMsg={props.placeholder}
            />
          </Grid>
          { props.isRemoveRequired && <Grid item xs={1} >
            <Tooltip id="tooltip-icon" title="Remove Theme">
              <IconButton color="primary" aria-label="remove" className={props.classes.IconButton} onClick={(e) => props.removeThemesField(props.id)} >
                <RemoveIcon className={props.classes.iconColor} />
              </IconButton>
            </Tooltip>
          </Grid>}
        </Grid>
        {(props.id === 'theme1' && props.errors.theme1) && <FormHelperText error className={props.classes.helperText}>{props.errors.theme1}</FormHelperText>}
      </Grid>
      { props.isAddRequired &&
        <Grid item xs={12}>
          <Button className={props.classes.addThemeButtonStyle} onClick={props.addThemesField}>
            <AddCircle className={props.classes.addThemeIcon} /> ADD THEME
          </Button>
        </Grid>
      }
    </div>
  )
}

export default withStyles(styles)(ThemeField)
