import React, { Component } from 'react'
import './LoadingHOC.css'
import { isEmpty } from '../Utils/CommonUtils'
import Loader from './Loader'

const LoadingHOC = (loadingProp) => (WrappedComponent) => {
  return class LoadingHOC extends Component {
    componentDidMount () {
      this.startTimer = Date.now()
    }

    componentWillUpdate (nextProps) {
      if (!isEmpty(nextProps[loadingProp])) {
        this.endTimer = Date.now()
      }
    }

    render () {
      const myProps = {
        loadingTime: ((this.endTimer - this.startTimer) / 1000).toFixed(2),
      }
      let loadStatus = false
      loadingProp.map((opt) => {
        if (isEmpty(this.props[opt])) {
          loadStatus = true
        }
      })
      return loadStatus ? <Loader /> : <WrappedComponent {...this.props} {...myProps} />
    }
  }
}

export default LoadingHOC
