export class HistoryDataModel {
  run: number;
  duration: string;
  status: string;
  id?: string;
  rowsProcessed?: number;
  user?: string;
  constructor(data?) {
    if (data) {
      this.run = data.run;
      this.duration = data.duration;
      this.status = data.status;
      this.id = data.id;
      this.user = data.user;
      this.rowsProcessed = data.rowsProcessed;
    }
  }
}
