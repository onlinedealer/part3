import { Component, Input, EventEmitter, Output } from "@angular/core";
import { Metering } from "../../models/metering.model";
import { slideCloseOpenAnimation } from "../../../Shared/Animations/slide-close-open.animation";

@Component({
    selector: "landisgyr-product-component-container",
    templateUrl: "./product-component-container.component.html",
    styleUrls: ["./product-component-container.component.scss"],
    animations: slideCloseOpenAnimation()
})
export class ProductComponentContainerComponent {
    @Input() title!: string;
    @Input() productComponentMeterings!: Metering[];
    @Output() productComponentClicked: EventEmitter<Metering[]> = new EventEmitter();

    contentOpen = "open";

    onProductComponentClicked(productComponentMeterings: Metering[]) {
        this.productComponentClicked.emit(productComponentMeterings);
    }

    toggleContent() {
        this.contentOpen = this.contentOpen === "open" ? "closed" : "open";
    }

    isCollapsed() {
        return this.contentOpen === "closed";
    }
}
