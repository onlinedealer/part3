import { Mocks, Spies } from 'discovery-test';
import { of, throwError } from 'rxjs';
import { ObserverRulesComponent } from './observer-rules.component';

describe('ObserverRulesComponent', () => {
  let component: ObserverRulesComponent;

  beforeEach(() => {
    Spies.init();
    component = new ObserverRulesComponent(
      Spies.ObserverService,
      Spies.ToastrService,
      Spies.TranslateService,
      Spies.eventBusService
    );
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should run ngOnInit', () => {
    Spies.ObserverService.getObservationRulesList.and.returnValue(of(Mocks.MockObserverRuleModels));
    spyOn(component.observationRuleListChange, 'emit');
    component.ngOnInit();
    expect(component.loadInProgress).toBe(true);
    expect(component.observationRuleListChange.emit).toHaveBeenCalled();
  });

  it('test loadRuleListData rule loading failed', () => {
    Spies.ObserverService.getObservationRulesList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.getObserverRuleService();
    expect(component.loadInProgress).toBe(false);
    expect(Spies.ToastrService.error).toHaveBeenCalled();
  });

  it('should validate observer rule config', () => {
    Spies.ObserverService.getObservationRulesList.and.returnValue(of(Mocks.MockObserverRuleModels));
    component.getObserverRuleService();
    component.validate();
    expect(component.selectedObservationRuleList.length).toBeGreaterThan(0);
  });

  it('should toggle checkbox of observer rule list', () => {
    spyOn(component, 'observationRulesList');
    component.observationRules = [
      { selected: true, metricName: 'Volume', metricDescription: 'Sample for volume' },
      { selected: true, metricName: 'Data drift', metricDescription: 'Sample for data drift' }
    ];
    component.tableHeaderSelectionChanged();
    expect(component.observationRulesList).toHaveBeenCalled();
  });
});
