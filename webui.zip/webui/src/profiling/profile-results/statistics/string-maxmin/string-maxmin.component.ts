import { Component, Input, OnInit } from '@angular/core';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { StatisticalAnalysisModel } from '../numerical-analysis/statistical-analysis-model';
import { TranslocoService } from '@ngneat/transloco';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { EventBusService } from 'core/eventBusService';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
@Component({
  selector: 'discovery-string-maxmin',
  templateUrl: './string-maxmin.component.html',
  styleUrls: ['./string-maxmin.component.css']
})
export class StringMaxminComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, string>[];
  dataset: StatisticalAnalysisModel[];
  type: string;

  constructor(
    private translocoService: TranslocoService,
    private eventBusService: EventBusService,
    public httpUtil: HttpUtilService
  ) {}

  ngOnInit(): void {
    this.loadData();
  }

  launchTrendsSidebar(stat: string) {
    this.eventBusService.emit('TrendsSidebarToggle', { flag: true, stat: stat });
  }

  private loadData(): void {
    if (this.treePath.columnView) {
      this.type = this.statistics.filter((stat) => stat['type'] !== ProfilingConstants.STATS.SEMANTIC)[0]['type'];
      const combinedStats = this.statistics.reduce((result, current) => Object.assign(result, current), {});
      this.dataset = [
        {
          fieldName: 'semanticType',
          label: this.translocoService.translate('discoveryProfiling.results.detectedType'),
          imageUrl: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/detected.svg'),
          data: combinedStats['semanticType']
        },
        {
          fieldName: 'minLength',
          label: this.translocoService.translate('discoveryProfiling.results.minLength'),
          imageUrl: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/minimum.svg'),
          data: combinedStats['minLength']
        },
        {
          fieldName: 'maxLength',
          label: this.translocoService.translate('discoveryProfiling.results.maxLength'),
          imageUrl: this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/maximum.svg'),
          data: combinedStats['maxLength']
        }
      ];
    }
  }
}
