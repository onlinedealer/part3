import React from 'react'
import { object } from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { withStyles } from '@material-ui/core/styles'
import Paper from '@material-ui/core/Paper'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import TextField from '@material-ui/core/TextField'
import GridDisplay from './GridDisplay'
import Select from '@material-ui/core/Select'
import MenuItem from '@material-ui/core/MenuItem'
import InputLabel from '@material-ui/core/InputLabel'
import FormControl from '@material-ui/core/FormControl'
import CircularProgress from '@material-ui/core/CircularProgress'
import Snackbar from '@material-ui/core/Snackbar'
import FileSaver from 'file-saver'
import VerticalAlignBottom from '@material-ui/icons/VerticalAlignBottom'
import VerticalAlignTop from '@material-ui/icons/VerticalAlignTop'
import MitSnackbarContent from './MitSnackbarContent'
import XLSX from 'xlsx'
import { getMaintenanceDetails,
  getItems,
  excelUpload,
  changeUpdateMode,
  getItemsFromTcins,
  toggleLoading,
} from '../../store/massItemMaintain/actionCreator'

const styles = theme => ({
  root: {
    flexGrow: 1,
  },
  paper: {
    padding: theme.spacing.unit * 2,
    textAlign: 'center',
    color: theme.palette.text.secondary,
  },
  boxMargin: {
    margin: 20,
  },
  button: {
    margin: theme.spacing.unit,
  },
  downloadUploadBtn: {
    margin: theme.spacing.unit,
    color: '#000',
    backgroundColor: '#ffe08a',
    fontSize: 13,
    '&:hover': {
      backgroundColor: '#ffe08a',
    },
  },
  uploadBtn: {
    marginBottom: 20,
    marginLeft: 10,
  },
  input: {
    display: 'none',
  },
  textField: {
    marginLeft: theme.spacing.unit,
    marginRight: theme.spacing.unit,
    width: 200,
  },
  confirmMsg: {
    color: 'green',
    fontSize: 18,
  },
  errorMsg: {
    color: 'red',
    fontSize: 12,
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 220,
    border: '1px solid #666',
    padding: '0px 2px',
    borderRadius: 5,
  },
  formControlLabel: {
    marginTop: 4,
    marginLeft: 12,
  },
  textArea: {
    border: '1px solid #ccc',
    width: 300,
  },
  optionText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'left',
  },
  alignLeft: {
    textAlign: 'left',
    paddingLeft: 10,
  },
  descBox: {
    minHeight: 237,
    fontSize: 13,
  },
  gridHeadText: {
    fontSize: 22,
    marginBottom: 0,
    fontWeight: 400,
    marginTop: 0,
  },
  gridDesc: {
    margin: 10,
  },
  textIndent: {
    paddingLeft: 10,
  },
  iconFont: {
    fontSize: 18,
  },
})

const initialState = {
  jiraId: '',
  errorStatus: false,
  fieldError: '',
  tcinStatus: false,
  tcinError: '',
  excelStatus: false,
  excelError: '',
  maintenance_type: ' ',
  tcins: '',
  excelData: '',
  uplaodedFile: '',
  loading: false,
  loadingData: false,
  action: '',
  snackBarOpen: false,
  tcinDpciInfo: {},
  excelInfo: {},
  actions: [],
  selected_action: ' ',
}

export class GridEntry extends React.Component {
  static propTypes = {
    classes: object,
  }

  constructor (props) {
    super(props)
    this.state = initialState
  }

  componentWillMount () {
    this.props.getMaintenanceDetails(this.props.auth.memberOf, this.props.auth.lanId)
  }

  componentWillReceiveProps (nextProps) {
    const snackBarOpen = !!nextProps.submitStatus
    this.setState({ snackBarOpen })
    this.setState({ jiraId: '' })
  }

  handleSnackbarClose = event => {
    this.setState({ snackBarOpen: false })
  }

  validateJiraId () {
    if (this.state.jiraId === '') {
      this.setState({ 'errorStatus': true, 'fieldError': 'please enter Jira Id' })
      return false
    } else {
      const _count = (this.state.jiraId.match(/-/g) || []).length
      if (_count === 1) {
        const _split = this.state.jiraId.split('-')
        if (isNaN(_split[0]) && !isNaN(_split[1])) { return true }
      }
      this.setState({ 'errorStatus': true, 'fieldError': 'Invalid Jira Id' })
      return false
    }
  }

  validateExcel () {
    const excelInfoCheck = this.state.excelInfo
    let retVal = true
    this.state.excelData[0].map(function (obj, key) {
      if (obj !== excelInfoCheck.template[key]) {
        retVal = false
      }
    })
    return retVal
  }

  submitJiraId = event => {
    if (this.validateJiraId()) {
      this.setState({ 'loadingData': true })
      this.props.changeUpdateMode('jira')
      this.props.toggleLoading(true, 'Loading')
      this.props.getItems(this.state.jiraId, this.props.auth.memberOf, this.props.auth.lanId)
      this.setState(initialState)
    }
  }

  submitTcins = (serviceName, gridRequired) => event => {
    if (this.validateJiraId()) {
      if (this.state.tcins.trim() !== '') {
        this.setState({ 'loadingData': true })
        this.props.changeUpdateMode('tcins')
        this.props.toggleLoading(true, 'Loading')
        let listTcins = this.state.tcins.trim().split('\n')
        listTcins = listTcins.map(function (el) {
          return el.trim()
        })
        const sendData = {
          'tcin_dpci': listTcins,
          'attribute': this.state.maintenance_type,
          'jira_id': this.state.jiraId,
          'maintenance_type': this.state.maintenance_type,
          'user_id': this.props.auth.lanId,
          'is_vop_level_attribute': this.state.tcinVopLevelAttr,
        }
        this.props.getItemsFromTcins(sendData, serviceName, gridRequired, this.props.auth.memberOf, this.props.auth.lanId)
        this.setState(initialState)
      } else {
        this.setState({ 'tcinStatus': true, 'tcinError': 'please enter TCINS' })
      }
    }
  }

  submitExcel = event => {
    if (this.validateJiraId()) {
      if (this.state.excelData.length > 0) {
        if (this.validateExcel()) {
          this.props.changeUpdateMode('excel')
          this.props.toggleLoading(true, 'Loading')
          this.setState({ 'loadingData': true })
          const sendData = {
            'jira_id': this.state.jiraId,
            'maintenance_type': this.state.maintenance_type,
            'action': this.state.selected_action,
            'is_vop_level_attribute': this.state.excelVopLevelAttr,
          }
          this.props.excelUpload(this.state.excelData, sendData, this.state.excelInfo, this.props.auth.memberOf, this.props.auth.lanId)
          this.setState(initialState)
        } else {
          this.setState({ 'excelStatus': true, 'excelError': 'please upload valid excel file' })
        }
      } else {
        this.setState({ 'excelStatus': true, 'excelError': 'please upload excel file' })
      }
    }
  }

  handleChange = (field) => event => {
    if (event.target.value !== '') {
      this.setState({ 'errorStatus': false, 'fieldError': '', 'option2errorStatus': false, 'option2fieldError': '', 'option2selectionStatus': false, 'option2selectionError': '' })
    }
    this.setState({ [field]: event.target.value })
  }

  changeMaintenanceType = event => {
    this.setState({ maintenance_type: event.target.value, tcinDpciInfo: {}, tcinVopLevelAttr: '', excelInfo: {}, excelVopLevelAttr: '', actions: [], selected_action: ' ' })
    const currentMaintenanceType = this.props.maintenanceDetails.find((obj) => { return obj.maintenance_type === event.target.value })
    currentMaintenanceType.maintenance_options.map((optionObj, keyOption) => {
      if (optionObj.option_name === 'Process Tcin Dpci List') {
        this.setState({ tcinDpciInfo: optionObj, tcinVopLevelAttr: currentMaintenanceType.is_vop_level_attribute })
      } else {
        if (optionObj.option_name === 'Excel Upload' && optionObj.actions === undefined) {
          this.setState({ excelInfo: optionObj, excelVopLevelAttr: currentMaintenanceType.is_vop_level_attribute })
        } else if (optionObj.actions !== undefined) {
          this.setState({ actions: optionObj.actions, excelVopLevelAttr: currentMaintenanceType.is_vop_level_attribute })
        }
      }
    })
  }

  changeAction = event => {
    this.setState({ selected_action: event.target.value, excelInfo: {} })
    if (event.target.value !== ' ') {
      const currentAction = this.state.actions.find((obj) => { return obj.action_name === event.target.value })
      currentAction.option_name = 'Excel Upload'
      this.setState({ excelInfo: currentAction })
    }
  }

  handleFileUpload = event => {
    if (event.target.files.length > 0) {
      this.setState({ 'loading': true })
      var files = event.target.files
      var rABS = true
      var excelData = {}
      var f = files[0]
      var reader = new window.FileReader()
      reader.onload = function (event) {
        var data = event.target.result
        if (!rABS) data = new Uint8Array(data)
        var workbook = XLSX.read(data, {type: rABS ? 'binary' : 'array'})
        var firstWorksheet = workbook.Sheets[workbook.SheetNames[0]]
        excelData = XLSX.utils.sheet_to_json(firstWorksheet, {header: 1})
      }
      if (rABS) reader.readAsBinaryString(f); else reader.readAsArrayBuffer(f)

      setTimeout(function () {
        this.setState({ excelData, 'uplaodedFile': files[0].name, 'option2selectionStatus': false, 'option2selectionError': '' })
        this.setState({ 'loading': false })
      }.bind(this), 1000)
    }
  }

  s2ab (s) {
    var buf = new ArrayBuffer(s.length)
    var view = new Uint8Array(buf)
    for (var i = 0; i !== s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF
    return buf
  }

  downloadExcel = (receiveData) => event => {
    const ws1 = XLSX.utils.aoa_to_sheet([receiveData])
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws1, 'Template')
    if (this.state.excelInfo.country_name_list !== undefined && this.state.excelInfo.country_name_list.length > 0) {
      let countryListArr = []
      this.state.excelInfo.country_name_list.map((option) => {
        const tempArr = [option]
        countryListArr.push(tempArr)
      })
      const ws2 = XLSX.utils.aoa_to_sheet(countryListArr)
      XLSX.utils.book_append_sheet(wb, ws2, 'Country List')
    }
    const wbout = XLSX.write(wb, {bookType: 'xlsx', type: 'binary'}) // generate a nodejs buffer
    const fileName = this.state.selected_action !== ' ' ? this.state.maintenance_type + '-' + this.state.selected_action : this.state.maintenance_type
    FileSaver.saveAs(new window.Blob([this.s2ab(wbout)], {type: 'application/octet-stream'}), fileName + '.xlsx')
  }

  render () {
    const { classes } = this.props
    const InputLabelProps = {
      className: classes.textIndent,
    }
    const dispExcelInfo = this.state.excelInfo.display_text2 ? this.state.excelInfo.display_text2 : ''
    const dispExcelButtonText = this.state.excelInfo.grid_required ? 'LOAD DATA' : 'SUBMIT CHANGES'
    // const dispExcelInfo = "When completing the template, to apply a new rule to ALL Vendors \n and/or ALL VOS, leave the Vendor and/or VOS columns blank."
    return (
      <div className={classes.root}>
        <Snackbar
          anchorOrigin={{
            vertical: 'top',
            horizontal: 'right',
          }}
          variant="error"
          open={this.state.snackBarOpen}
          autoHideDuration={6000}
          onClose={this.handleSnackbarClose}
        >
          <MitSnackbarContent
            variant={this.props.submitMessage.variant}
            className={classes.margin}
            message={this.props.submitMessage.message}
            onClose={this.handleSnackbarClose}
          />
        </Snackbar>

        <Grid container>
          { (this.props.listStatus === false) &&
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={12}>
                <FormControl className={classes.formControl}>
                  <InputLabel htmlFor="age-simple" className={classes.formControlLabel}>Maintenance Type</InputLabel>
                  <Select
                    value={this.state.maintenance_type}
                    onChange={this.changeMaintenanceType}
                    className={classes.alignLeft}
                  >
                    <MenuItem value=" ">Select Maintenance Type</MenuItem>
                    {this.props.maintenanceDetails.map((option, keyOption) => {
                      return (
                        <MenuItem value={option.maintenance_type} key={keyOption}>
                          {option.maintenance_name}
                        </MenuItem>
                      )
                    })}
                  </Select>
                </FormControl>
                <TextField
                  required
                  id="jira-id"
                  label="Enter Jira ID"
                  value={this.state.jiraId}
                  className={classes.formControl}
                  onChange={this.handleChange('jiraId')}
                  margin="normal"
                  helperText={this.state.fieldError}
                  error={this.state.errorStatus}
                  InputLabelProps={InputLabelProps}
                  InputProps={InputLabelProps}
                />
                {this.state.actions.length >= 1 &&
                  <FormControl className={classes.formControl}>
                    <InputLabel htmlFor="age-simple" className={classes.formControlLabel}>Select Action</InputLabel>
                    <Select
                      value={this.state.selected_action}
                      onChange={this.changeAction}
                      className={classes.alignLeft}
                    >
                      <MenuItem value=" ">Select Action</MenuItem>
                      {this.state.actions.map((actionObj, keyOption) => {
                        return (
                          <MenuItem value={actionObj.action_name} key={keyOption}>
                            {actionObj.action_name}
                          </MenuItem>
                        )
                      })}
                    </Select>
                  </FormControl>
                }
              </Grid>
            </Grid>

            <Grid container>
              { (this.props.loadingInfo.status) &&
                <Grid item xs={12}>
                  <CircularProgress />
                  <p>{this.props.loadingInfo.message} Data please wait.....</p>
                </Grid>
              }
              <Grid item xs={12}>
                <Grid container>
                  { (this.state.tcinDpciInfo.option_name === 'Process Tcin Dpci List') &&
                    <Grid item xs className={classes.boxMargin}>
                      <Paper className={classes.paper}>
                        <Grid container>
                          <Grid item xs={12} className={classes.descBox}>
                            <Grid container>
                              <Grid item xs={12}>
                                <h3 className={classes.gridHeadText}>Enter TCINs / DPCIs</h3>
                              </Grid>
                              <Grid item xs={12} className={classes.gridDesc}>
                                {this.state.tcinDpciInfo.display_text}
                              </Grid>
                              <Grid item xs={12}>
                                <TextField
                                  id="multiline-flexiable"
                                  label="Enter TCINs / DPCIs"
                                  multiline
                                  rowsMax="5"
                                  value={this.state.tcins}
                                  onChange={this.handleChange('tcins')}
                                  className={classes.formControl}
                                  margin="normal"
                                  InputLabelProps={InputLabelProps}
                                  InputProps={InputLabelProps}
                                />
                                {this.state.tcinStatus &&
                                <div className={classes.errorMsg}>{this.state.tcinError}</div>
                                }
                              </Grid>
                            </Grid>
                          </Grid>
                          <Grid item xs={12}>
                            <Button variant="raised" color="primary" className={classes.button} onClick={this.submitTcins(this.state.tcinDpciInfo.service_name, this.state.tcinDpciInfo.grid_required)}>
                                LOAD DATA
                            </Button>
                          </Grid>
                        </Grid>
                      </Paper>
                    </Grid>
                  }

                  { (this.state.excelInfo.option_name === 'Excel Upload') &&
                    <Grid item xs className={classes.boxMargin}>
                      <Paper className={classes.paper}>
                        <Grid container>
                          <Grid item xs={12} className={classes.descBox}>
                            <Grid container>
                              <Grid item xs={12}>
                                <h3 className={classes.gridHeadText}>Excel Template Upload</h3>
                              </Grid>
                              <Grid item xs={12} className={classes.gridDesc}>
                                {this.state.excelInfo.display_text}
                              </Grid>
                              <Grid item xs={12}>
                                <Button className={classes.downloadUploadBtn} onClick={this.downloadExcel(this.state.excelInfo.template)}>
                                  <VerticalAlignBottom className={classes.iconFont} />DOWNLOAD TEMPLATE
                                </Button>
                              </Grid>
                              <Grid item xs={12}>
                                {dispExcelInfo.split('\n').map((item, key) => {
                                  return <div key={key}><span dangerouslySetInnerHTML={{__html: item}} /><br /></div>
                                })}
                              </Grid>
                              <Grid item xs={12}>
                                <input
                                  accept="xlxs/*"
                                  className={classes.input}
                                  id="raised-button-file"
                                  type="file"
                                  onChange={this.handleFileUpload}
                                />
                                <label htmlFor="raised-button-file">
                                  <Button variant="raised" component="span" className={classes.downloadUploadBtn}>
                                    <VerticalAlignTop className={classes.iconFont} />UPLOAD EXCEL FILE
                                  </Button>
                                </label>
                                {this.state.loading && <CircularProgress size={24} className={classes.buttonProgress} />}
                                { this.state.uplaodedFile !== '' &&
                                <div>( {this.state.uplaodedFile} )</div>
                                }
                                {this.state.excelStatus &&
                                <div className={classes.errorMsg}>{this.state.excelError}</div>
                                }
                              </Grid>
                            </Grid>
                          </Grid>
                          <Grid item xs={12}>
                            <Button variant="raised" color="primary" className={classes.button} onClick={this.submitExcel}>
                              {dispExcelButtonText}
                            </Button>
                          </Grid>
                        </Grid>
                      </Paper>
                    </Grid>
                  }
                </Grid>
              </Grid>
            </Grid>
          </Grid>
          }
          <Grid item xs={12} className={classes.boxMaring}>
            <GridDisplay
              auth={this.props.auth}
              listStatus={this.props.listStatus}
              loadingInfo={this.props.loadingInfo}
              updateMode={this.props.updateMode}
              listItems={this.props.listItems}
              columnInfo={this.props.columnInfo}
              commonFields={this.props.commonFields}
              gridText={this.props.gridText}
              sendToResponse={this.props.sendToResponse}
              errorItems={this.props.errorItems}
            />

          </Grid>
        </Grid>
      </div>
    )
  }
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getMaintenanceDetails,
    getItems,
    excelUpload,
    changeUpdateMode,
    getItemsFromTcins,
    toggleLoading,
  }, dispatch)

const mapStateToProps = state => ({
  maintenanceDetails: state.getIn(['items', 'maintenanceDetails']).toJS(),
  listItems: state.getIn(['items', 'listItems']).toJS(),
  columnInfo: state.getIn(['items', 'columnInfo']).toJS(),
  commonFields: state.getIn(['items', 'commonFields']).toJS(),
  gridText: state.getIn(['items', 'gridText']).toJS(),
  sendToResponse: state.getIn(['items', 'sendToResponse']).toJS(),
  errorItems: state.getIn(['items', 'errorItems']).toJS(),
  updateMode: state.getIn(['items', 'updateMode']),
  listStatus: state.getIn(['items', 'listStatus']),
  submitStatus: state.getIn(['items', 'submitStatus']),
  submitMessage: state.getIn(['items', 'submitMessage']).toJS(),
  loadingInfo: state.getIn(['items', 'loadingInfo']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(GridEntry))
