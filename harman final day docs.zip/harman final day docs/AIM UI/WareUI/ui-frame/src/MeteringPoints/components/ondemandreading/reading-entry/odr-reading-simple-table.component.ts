import { cloneDeep } from "lodash";
import { Component, Input, ChangeDetectionStrategy, OnInit, SimpleChanges, OnChanges } from "@angular/core";
import { DateFormatService, DateFormats } from "../../../../Shared/services/date-format.service";
import { ExportDialogComponent } from "../../export-dialog/export-dialog.component";
import { MatDialog } from "@angular/material/dialog";
import { MeteringPointsSelectors, OnDemandReadingsSelectors, MeterConnectionSelectors } from "../../../store/selectors";
import { OnDemandReadingRequest } from "../../../models/ondemandreading.model";
import { State } from "../../../../app/store/reducers";
import { Store } from "@ngrx/store";
import { ExportDataColHeaderService } from "../../../../MeteringPoints/services/export-data-col-header.service";
import { ODRReadingSimpleSorter } from "./odr-reading-simple-table.sorter";

@Component({
    selector: "landisgyr-odr-reading-simple-table",
    templateUrl: "./odr-reading-simple-table.component.html",
    styleUrls: ["./odr-reading-simple-table.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OdrReadingSimpleTableComponent implements OnInit, OnChanges {
    @Input() columns: { key: string; header: string; useStatus?: boolean; forceSize?: string }[] = [];
    @Input() dates: string[] = [];
    @Input() meterings!: any[];
    @Input() valueStart!: number;
    @Input() valueEnd!: number;
    @Input()
    useSmallLayout = false;

    @Input() userDefinedStartTime!: number;
    @Input() userDefinedEndTime!: number;

    meteringPointName!: string;
    meteringPointId!: number;
    odrRequestOfSelectedMeteringPoint!: OnDemandReadingRequest[];
    selectedOnDemandRequestType!: string;
    selectedOnDemandRequestId!: number;
    readingTime!: string | undefined;
    meterSerialNumber!: string;
    binaryZeroArray = "00000000".split("");
    displayExportButton = true;
    odrReadingSimpleSorter = new ODRReadingSimpleSorter();
    sortedODRReadingData$ = this.odrReadingSimpleSorter.getSortedODRReadingTable();

    constructor(
        private dialog: MatDialog,
        private store: Store<State>,
        private formatService: DateFormatService,
        private exportDataColHeaderService: ExportDataColHeaderService
    ) {}

    ngOnChanges(changes: SimpleChanges) {
        this.odrReadingSimpleSorter.setODRReadingTable(this.meterings);
    }

    ngOnInit() {
        this.store.select(MeteringPointsSelectors.getSelectedMeteringPointDetails).subscribe((data) => {
            this.meteringPointName = data ? data.name : "";
            this.meteringPointId = data ? data.id : NaN;
        });
        this.store.select(OnDemandReadingsSelectors.getSelectedOnDemandRequest).subscribe((result) => {
            if (result) {
                this.selectedOnDemandRequestType = result.requestType;
                this.selectedOnDemandRequestId = result.requestId ? result.requestId : NaN;
                if (result.requestType === "ReadTransformerRatio") {
                    this.displayExportButton = false;
                }
            }
            this.store.select(OnDemandReadingsSelectors.getSelectedMeteringPointOnDemandReadingsEntities).subscribe((data) => {
                this.odrRequestOfSelectedMeteringPoint = data.filter((ele) => ele.requestType === this.selectedOnDemandRequestType);
            });
        });
    }

    trackColumnFn(index: number, column: { key: string; header: string }) {
        return index;
    }

    trackRowFn(index: number, item: any) {
        return index;
    }

    getReadingTime(requestId: number) {
        const timeRange: { startTime: number; endTime: number } = {
            startTime: 0,
            endTime: 0
        };
        if (requestId) {
            this.odrRequestOfSelectedMeteringPoint = this.odrRequestOfSelectedMeteringPoint.filter((ele) => ele.requestId === requestId);
            if (
                this.odrRequestOfSelectedMeteringPoint.length > 0 &&
                this.odrRequestOfSelectedMeteringPoint[0].requests &&
                this.odrRequestOfSelectedMeteringPoint[0].requests.length > 0
            ) {
                timeRange.startTime = this.odrRequestOfSelectedMeteringPoint[0].requests[0].startTime;
                timeRange.endTime = this.odrRequestOfSelectedMeteringPoint[0].requests[0].endTime;
                return timeRange;
            } else {
                return timeRange;
            }
        } else {
            return timeRange;
        }
    }

    getMeterSerialNumber(readingTime: { startTime: number; endTime: number }) {
        if (readingTime.startTime > 0) {
            this.store.select(MeterConnectionSelectors.getSelectedMeteringPointMeterConnectionsEntities).subscribe((data) => {
                const meterConnection = data[0];
                if (readingTime.startTime > meterConnection.validFrom && meterConnection.validUntil === undefined) {
                    this.meterSerialNumber = meterConnection.deviceMeter ? meterConnection.deviceMeter.meterSerialNumber : "";
                } else if (
                    readingTime.startTime > meterConnection.validFrom &&
                    meterConnection.validUntil &&
                    readingTime.startTime < meterConnection.validUntil
                ) {
                    this.meterSerialNumber = meterConnection.deviceMeter ? meterConnection.deviceMeter.meterSerialNumber : "";
                } else {
                    this.meterSerialNumber = "";
                }
            });
        }
    }

    binaryConversion(decimalValue: number | undefined | null): string | null {
        if (decimalValue === undefined || decimalValue === null) {
            return null;
        } else if (decimalValue >= 0) {
            const binaryArray = parseInt(decimalValue.toString(), 10).toString(2).split("");
            if (binaryArray.length < 8) {
                const loop = 8 - binaryArray.length;
                for (let i = 0; i < loop; i++) {
                    binaryArray.unshift("0");
                }
            }
            return binaryArray.join("");
        } else {
            return null;
        }
    }

    openExportDialog() {
        let headerObj = {};
        let fileName = "";
        const exportData: any[] = cloneDeep(this.meterings);
        const readingTime = this.getReadingTime(this.selectedOnDemandRequestId);
        let havingBinaryConvertedData = false;
        this.getMeterSerialNumber(readingTime);
        if (this.selectedOnDemandRequestType) {
            if (this.selectedOnDemandRequestType === "ReadInstantaneousValue") {
                headerObj = this.exportDataColHeaderService.readInstantaneousDataHeader;
                exportData.forEach((ele) => {
                    ele["meteringPointName"] = this.meteringPointName;
                    ele["meterSerialNumber"] = this.meterSerialNumber;
                });
                fileName = "adhoc_instantaneous_values";
            } else if (this.selectedOnDemandRequestType === "ReadProfileData") {
                headerObj = this.exportDataColHeaderService.readProfileDataHeader;
                exportData.forEach((ele) => {
                    ele["meteringPointName"] = this.meteringPointName;
                    ele["value"] = ele.value.split(" ")[0];
                    ele["meterSerialNumber"] = this.meterSerialNumber;
                    ele["valueEndTime"] = this.formatService.toLocaleString(ele["valueEndTime"], DateFormats.DATETIME);
                    ele["status"] = this.binaryConversion(ele.status);
                    ele["validatedStatus"] = this.binaryConversion(ele.validatedStatus);
                    ele["unit"] = ele.measuredUnit.name;
                });
                havingBinaryConvertedData = true;
                fileName = "adhoc_profile_values";
            } else if (this.selectedOnDemandRequestType === "ReadPeriodicData") {
                headerObj = this.exportDataColHeaderService.readPeriodicDataHeader;
                exportData.forEach((ele) => {
                    ele["meteringPointName"] = this.meteringPointName;
                    ele["meterSerialNumber"] = this.meterSerialNumber;
                    ele["readingTime"] = readingTime ? this.formatService.toLocaleString(readingTime.endTime, DateFormats.DATETIME) : null;
                });
                fileName = "adhoc_periodic_values";
            }
        }

        const timeRange = {
            from: this.formatService.toStartOfDay(this.userDefinedStartTime),
            until: this.formatService.toEndOfDay(this.userDefinedEndTime)
        };

        this.dialog.open(ExportDialogComponent, {
            width: "850px",
            maxWidth: "850px",
            height: "600px",
            maxHeight: "600px",
            disableClose: true,
            data: {
                fileName: this.meteringPointName + "_" + fileName,
                results: exportData,
                header: headerObj,
                includePageRange: false,
                includeTimeRange: fileName.includes("adhoc_profile_values"),
                timeRangeInput: timeRange,
                havingBinaryConvertedData: havingBinaryConvertedData
            }
        });
    }
}
