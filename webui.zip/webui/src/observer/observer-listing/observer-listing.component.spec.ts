import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslocoModule, TranslocoService } from '@ngneat/transloco';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { SecondaryNavModule } from '@precisely/prism-ng/secondary-nav';
import { AuthenticationService, ConnectionService, SecondaryNavItemsService, SharedModule } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { ObserverService } from 'observer/observer.service';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialog, ConfirmDialogModule } from 'primeng/confirmdialog';
import { ContextMenuModule } from 'primeng/contextmenu';
import { TableModule } from 'primeng/table';
import { of, throwError } from 'rxjs';
import { ObserverListModel } from './observer-list.model';
import { ObserverListingComponent } from './observer-listing.component';

describe('ObserverListingComponent', () => {
  let component: ObserverListingComponent;
  let fixture: ComponentFixture<ObserverListingComponent>;
  let toasterService;
  let translocoService;
  let router;
  let elementSelector: any;
  beforeEach(() => {
    Spies.init();
    const mockSecNav = jasmine.createSpyObj('SecondaryNavItemsService', ['getNavItems']);
    TestBed.configureTestingModule({
      declarations: [ObserverListingComponent],
      imports: [
        CommonModule,
        HttpClientTestingModule,
        ConfirmDialogModule,
        FormsModule,
        RouterTestingModule.withRoutes([]),
        BrowserAnimationsModule,
        ToastrModule.forRoot(),
        TranslocoModule,
        TableModule,
        ContextMenuModule,
        SecondaryNavModule,
        SharedModule
      ],
      providers: [
        { provide: ObserverService, useValue: Spies.ObserverService },
        ConfirmationService,
        { provide: ConnectionService, useValue: Spies.ConnectionService },
        { provide: ToastrService },
        { provide: TranslocoService },
        { provide: LaunchDarklyService, useValue: Spies.launchDarklyService },
        { SecondaryNavItemsService, useValue: mockSecNav },
        { provide: AuthenticationService, useValue: Spies.AuthenticationService },
        { provide: HttpUtilService, useValue: Spies.HttpUtilService }
      ]
    });

    fixture = TestBed.createComponent(ObserverListingComponent);
    component = fixture.componentInstance;
    toasterService = TestBed.get(ToastrService);
    spyOn(toasterService, 'success');
    spyOn(toasterService, 'error');
    translocoService = TestBed.get(TranslocoService);
    spyOn(translocoService, 'translate');
    router = TestBed.get(Router);
    spyOn(router, 'navigate').and.callFake(() => {});
    spyOn(router, 'navigateByUrl').and.callFake(() => {});
    spyOn(router, 'url').and.callFake(() => {});
    mockSecNav.getNavItems.and.returnValue(of([]));
    elementSelector = fixture.debugElement.nativeElement;
    fixture.autoDetectChanges(true);
  });
  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should load observers on ngOnInit function', () => {
    component.ngOnInit();
    expect(component.observerList.length).toBeDefined();
  });

  it('should stop loader in observer list failed', () => {
    Spies.ObserverService.getObserverList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.ngOnInit();
    expect(component.isLoading).toBe(false);
  });

  it('should load menuitems on OnContextMenu', () => {
    const rowData = Mocks.MockObserverListModels[0];
    component.onContextMenu(rowData);
    expect(component.items.length).toBe(2);
  });

  it('should check delete observer', () => {
    component.observerList = Mocks.MockObserverListModels;
    Spies.ObserverService.deleteObserver.and.returnValue(of('dummy'));
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const accept = spyOn(confirmdialog, 'accept').and.callThrough();
    Spies.ConnectionService.deleteConnection.and.returnValue(of('success'));
    const observer = Mocks.MockObserverListModels[0];
    component.deleteObserver(observer);
    fixture.detectChanges();
    const acceptBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-accept');
    acceptBtn.click();
    expect(accept).toHaveBeenCalled();
    expect(Spies.ObserverService.getObserverList).toHaveBeenCalled();
  });

  it('should call onDelete with error response 404', () => {
    component.observerList = Mocks.MockObserverListModels;
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const accept = spyOn(confirmdialog, 'accept').and.callThrough();
    Spies.ObserverService.deleteObserver.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    const observer = Mocks.MockObserverListModels[0];
    component.deleteObserver(observer);
    fixture.detectChanges();
    const acceptBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-accept');
    acceptBtn.click();
    expect(accept).toHaveBeenCalled();
  });

  it('should call onDelete with No button click', () => {
    const observer = Mocks.MockObserverListModels[0];
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const reject = spyOn(confirmdialog, 'reject').and.callThrough();
    component.deleteObserver(observer);
    fixture.detectChanges();
    const noBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-reject');
    noBtn.click();
    expect(reject).toHaveBeenCalled();
  });

  it('should check edit observer allowed', () => {
    const observer = Mocks.MockObserverListModels[0];
    component.editObserver(observer.observableId);
  });

  it('should run filterGlobal fn for filter', () => {
    component.filterGlobal(event as Event, 'contains');
    expect(component.observerList.length).toBeGreaterThanOrEqual(1);
  });

  it('should check observer scheduler sidebar open', () => {
    const rowData = {
      profileId: '1',
      name: 'name',
      scheduleConfig: {
        enabled: true
      }
    };
    component.showScheduleSidebar(rowData);
    expect(component.scheduleType.id).toBe(rowData.profileId);
  });

  it('should display email Notif column if flag is turned ON', () => {
    Spies.launchDarklyService.variation.and.returnValue(true);
    fixture.detectChanges();
    const emailNotifColumn = elementSelector.querySelector('#emailNotifColumn');
    expect(emailNotifColumn).not.toBeNull();
  });

  it('should not display email Notification column if flag is turned OFF', () => {
    Spies.launchDarklyService.variation.and.returnValue(false);
    fixture.detectChanges();
    const emailNotifColumn = elementSelector.querySelector('#emailNotifColumn');
    expect(emailNotifColumn).toBeNull();
  });

  it('should toggle email notification icon', () => {
    const selectedObserver = Mocks.MockObserverListModels[0];
    component.onToggleEmailNotification(selectedObserver.observableId);
    expect(component.observerList[0]['notificationConfig']).toBeTrue();
    component.onToggleEmailNotification(selectedObserver.observableId);
    expect(component.observerList[0]['notificationConfig']).toBeFalse();
  });

  it('should navigate to observer detail view', () => {
    let rowData: ObserverListModel = Mocks.MockObserverListModels[0];
    component.getObserverDetailView(rowData);
    expect(component).toBeTruthy();
  });
});
