import { Component, OnChanges, SimpleChanges, OnInit } from "@angular/core";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { DeviceTransformerFactor } from "../../../models/meterconnection.model";
import { TranslationsService } from "../../../../app/services/translations-service";
import { map } from "rxjs/operators";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import * as MeterConnectionSelectors from "../../../store/selectors/meterconnections.selectors";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { SSTransformerSorter } from "./ss-transformer-factors-sorter";

@Component({
    selector: "landisgyr-ss-transformer-factors",
    templateUrl: "./ss-transformer-factors.component.html",
    styleUrls: ["./ss-transformer-factors.component.scss"]
})
export class SSTransformerFactorsComponent implements OnChanges, OnInit {
    urlSegment = "/transformer";

    refreshDataLoading$: Observable<boolean> = this.store.select(MeterConnectionSelectors.getLoadingData);

    selectedMeterSerialNumber$ = this.store
        .select(MeterConnectionSelectors.getSelectedMeterConnection)
        .pipe(
            map((meterConnection) =>
                meterConnection && meterConnection.deviceMeter ? meterConnection.deviceMeter.meterSerialNumber + "" : ""
            )
        );

    factors$: any = this.store
        .select(MeterConnectionSelectors.getSelectedMeterConnection)
        .pipe(map((meterConnection) => (meterConnection && meterConnection.deviceMeter ? meterConnection.deviceMeter.transformers : [])));

    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    sstransformerSorter = new SSTransformerSorter();
    sortedTransformerData$ = this.sstransformerSorter.getSortedTransformerFactorsData(this.factors$);

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {}

    ngOnChanges(changes: SimpleChanges) {
        this.sstransformerSorter.setTransformerFactors(this.factors$);
    }

    ngOnInit() {
        this.sstransformerSorter.setTransformerFactors(this.factors$);
    }
}
