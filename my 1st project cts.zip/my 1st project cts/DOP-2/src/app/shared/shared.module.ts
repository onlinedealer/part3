import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BccComponent } from './bcc/bcc.component';
import { FormValidationComponent } from './components/form-validation/form-validation.component';
import { ClubGenericErrorComponent } from './components/club-generic-error/club-generic-error.component';
import { CarepassErrorBannerComponent } from './components/carepass-error-banner/carepass-error-banner.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [BccComponent, FormValidationComponent, ClubGenericErrorComponent, CarepassErrorBannerComponent],
  exports: [BccComponent, FormValidationComponent, ClubGenericErrorComponent, CarepassErrorBannerComponent]
})
export class SharedModule { }
