import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { BundlesApiService } from '../shared/bundles-api.service';
import { of } from 'rxjs';
import { StopBundleDialogComponent } from './stop-bundle-dialog.component';

describe('StopBundleDialogComponent', () => {
  let component: StopBundleDialogComponent;
  let fixture: ComponentFixture<StopBundleDialogComponent>;
  let bundlesApiService: BundlesApiService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'bundles' } }],
      declarations: [StopBundleDialogComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(StopBundleDialogComponent);
    bundlesApiService = TestBed.inject(BundlesApiService);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the dialog', () => {
    const bundles = [
      {
        id: '01',
        status: 'in-progress'
      },
      {
        id: '02',
        status: 'in-progress'
      }
    ];
    component.open(bundles, 5);
    expect(component.stoppableBundles.length).toBe(2);
    expect(component.bundlesCount).toBe(5);
  });

  it('should close the dialog when cancel button is clicked', () => {
    spyOn(component.isVisibleChanged, 'emit');
    component.cancelButtonClicked();
    expect(component.isVisible).toBe(false);
    expect(component.isVisibleChanged.emit).toHaveBeenCalled();
  });

  it('should stop bundling when the stop button is clicked', () => {
    spyOn(component.bundleStoppedEvent, 'emit');
    spyOn(component.isVisibleChanged, 'emit');
    spyOn(bundlesApiService, 'stopBundle').and.returnValue(of({}));
    component.stoppableBundles = [
      {
        id: '01',
        status: 'in-progress'
      },
      {
        id: '02',
        status: 'in-progress'
      }
    ];
    component.stopButtonClicked();
    expect(component.isVisible).toBe(false);
    expect(component.bundleStoppedEvent.emit).toHaveBeenCalled();
    expect(component.isVisibleChanged.emit).toHaveBeenCalled();
  });
});
