import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-on-card',
  templateUrl: './on-card.component.html',
  styleUrls: ['./on-card.component.scss']
})
export class OnCardComponent implements OnInit {

  @Input() couponList: any ;

  constructor() { }

  ngOnInit() {
  }

}
