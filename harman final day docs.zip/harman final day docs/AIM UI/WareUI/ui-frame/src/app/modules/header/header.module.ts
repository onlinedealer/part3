import { NgModule } from "@angular/core";
import { CommonModule } from "@angular/common";
import { AboutApplicationComponent } from "./dialog-components/about-application/about-application.component";
import { HeaderComponent } from "./containers/header.component";
import { MatButtonModule } from "@angular/material/button";
import { MatDialogModule } from "@angular/material/dialog";
import { MatIconModule } from "@angular/material/icon";
import { MatMenuModule } from "@angular/material/menu";
import { MatRadioModule } from "@angular/material/radio";
import { MatSelectModule } from "@angular/material/select";
import { UserMenuComponent } from "./components/user-menu/user-menu.component";
import { ReactiveFormsModule, FormsModule } from "@angular/forms";
import { HeaderTextAreaComponent } from "./components/header-text-area/header-text-area.component";
import { HeaderNetworkAreaComponent } from "./components/header-network-area/header-network-area.component";
import { HeaderHelpAreaComponent } from "./components/application-help-area/header-help-area.component";
import { EnvironmentIndicatorComponent } from "./components/environment-indicator/environment-indicator.component";
import { SharedModule } from "../../../Shared/shared.module";

@NgModule({
    declarations: [
        AboutApplicationComponent,
        HeaderComponent,
        UserMenuComponent,
        HeaderHelpAreaComponent,
        HeaderTextAreaComponent,
        HeaderNetworkAreaComponent,
        EnvironmentIndicatorComponent
    ],
    imports: [
        CommonModule,
        MatIconModule,
        MatMenuModule,
        MatButtonModule,
        MatSelectModule,
        MatDialogModule,
        MatRadioModule,
        ReactiveFormsModule,
        FormsModule,
        SharedModule
    ],
    exports: [HeaderComponent, UserMenuComponent, EnvironmentIndicatorComponent]
})
export class HeaderModule {}
