import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber, isString } from "lodash";
import { CustomPropertyVO } from "../../models/view-objects/custom-property-vo.model";

export class CustomPropertySorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" }> = new BehaviorSubject({
        active: "customProperty",
        direction: "asc"
    } as any);

    customPropertyObj: CustomPropertyVO[] = [];

    public setCustomProperties(customPropertyObj: CustomPropertyVO[]) {
        this.customPropertyObj = customPropertyObj;
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedCustomProperties(): Observable<CustomPropertyVO[]> {
        return this.sortingSubject.asObservable().pipe(map(() => [...this.customPropertyObj].sort(this.customPropertyComparator)));
    }

    public onSortChange(event: { active: string; direction: "asc" | "desc" }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    customPropertyComparator = (r1: CustomPropertyVO, r2: CustomPropertyVO): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "customProperty":
                return this.sortByNumberOverString(r1.customProperty, r2.customProperty, directionMultiplier);
            case "customPropertyValue":
                return this.sortByNumberOverString(r1.customPropertyValue, r2.customPropertyValue, directionMultiplier);
            case "lastUpdatedTimestamp":
                return this.sortByDate(r1, r2, directionMultiplier);
            case "lastUpdatedBy":
                return this.sortByNumberOverString(r1.lastUpdatedBy, r2.lastUpdatedBy, directionMultiplier);

            default:
                return 0;
        }
    };
    sortByDate(r1: CustomPropertyVO, r2: CustomPropertyVO, directionMultiplier: number) {
        if (isNumber(r1.lastUpdatedTimestamp) && isNumber(r2.lastUpdatedTimestamp)) {
            return r1.lastUpdatedTimestamp > r2.lastUpdatedTimestamp ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(r1.lastUpdatedTimestamp) && isNil(r2.lastUpdatedTimestamp)) {
            return this.sortByString(r1.customProperty, r2.customProperty, 1);
        }

        if (isNil(r1.lastUpdatedTimestamp)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.lastUpdatedTimestamp)) {
            return directionMultiplier;
        }

        return 0;
    }

    sortByNumberOverString(value1: string | undefined, value2: string | undefined, directionMultiplier: number) {
        if (!isNaN(Number(value1)) && !isNaN(Number(value2))) {
            return Number(value1) > Number(value2) ? directionMultiplier : -1 * directionMultiplier;
        }
        if (!isNaN(Number(value1)) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && !isNaN(Number(value2))) {
            return directionMultiplier;
        }

        if (!isNaN(Number(value2)) || isNil(value2)) {
            return directionMultiplier;
        }

        if (!isNaN(Number(value1)) || isNil(value1)) {
            return -1 * directionMultiplier;
        }
        if (isString(value1) && isString(value2)) {
            return this.sortByString(value1, value2, directionMultiplier);
        }
        return value1.toUpperCase() < value2.toUpperCase() ? directionMultiplier : -1 * directionMultiplier;
    }

    sortByString(value1: string | undefined, value2: string | undefined, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }
        return directionMultiplier;
    }
}
