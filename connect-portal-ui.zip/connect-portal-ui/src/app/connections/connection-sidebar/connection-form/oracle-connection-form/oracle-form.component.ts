import { AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../shared/connection';
import { ConnectionFormValidators } from '../shared/connection-form-validators';
import { BaseConnectionForm } from '../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../base-connection-form/base-connection-form.component';
import { Server } from '../../../../servers/shared/server';
import { ConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component';

/**
 * Connection parmaeters for the oracle connection
 */
export enum ORACLE_CONNECTION_PARAMETERS {
  ORACLE_JDBC_SUPPORT_PLUGGABLE = 'ORACLE_JDBC_SUPPORT_PLUGGABLE',
  ORACLE_JDBC_ROOT_CONTAINER_USER_ID = 'ORACLE_JDBC_ROOT_CONTAINER_USER_ID',
  ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD = 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD',
  JDBC_ENCRYPTION = 'JDBC_ENCRYPTION',
  ORACLE_JDBC_INSTANCE_NAME = 'ORACLE_JDBC_INSTANCE_NAME',
  ORACLE_JDBC_DRIVER_VERSION = 'ORACLE_JDBC_DRIVER_VERSION'
}

/**
 * The Oracle connection child form
 */
@Component({
  selector: 'p-connect-oracle-form',
  templateUrl: './oracle-form.component.html'
})
export class OracleFormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy, AfterViewInit, BaseConnectionForm {
  /**
   * Selected Runtime Server
   */
  @Input() selectedRuntimeServer: Server;

  /**
   * Reference to the credentials child component
   */
  @ViewChild(ConnectionCredentialsFormComponent) credentialsComponent: ConnectionCredentialsFormComponent;

  /**
   * form group
   */
  oracleFormGroup: FormGroup;

  /**
   * List of options for the JDBC driver version
   */
  jdbcDriverVersionItems = [
    { label: '11g', value: 'ORACLE11' },
    { label: '12c', value: 'ORACLE12' }
  ];

  /**
   * Controls whether the container user/password section should be displayed
   */
  isContainerSectionVisible = false;

  /**
   * Flags whether the container's password changed
   */
  hasContainerPasswordChanged = false;

  constructor(private readonly controlContainer: ControlContainer, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }

  ngOnDestroy(): void {
    this.removeChildFormControls(this.oracleFormGroup);
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.createForm();
  }

  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): Connection {
    const connection = this.credentialsComponent.getConnection(isTesting); // only populates the user & password properties; dummy change
    connection.database = this.oracleFormGroup.get('database').value;
    connection.port = this.oracleFormGroup.get('databasePort').value;

    connection.parameters = [
      {
        key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_INSTANCE_NAME,
        value: this.oracleFormGroup.get('instanceName').value
      },
      {
        key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_DRIVER_VERSION,
        value: this.oracleFormGroup.get('jdbcDriverVersion').value
      },
      {
        key: ORACLE_CONNECTION_PARAMETERS.JDBC_ENCRYPTION,
        value: this.oracleFormGroup.get('jdbcEncryption').value
      }
    ];

    if (this.oracleFormGroup.get('jdbcDriverVersion').value === 'ORACLE12') {
      const isPluggable = this.oracleFormGroup.get('pluggableDatabase').value;

      connection.parameters.push({
        key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_SUPPORT_PLUGGABLE,
        value: isPluggable
      });

      if (isPluggable) {
        connection.parameters.push(
          {
            key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_ROOT_CONTAINER_USER_ID,
            value: this.oracleFormGroup.get('containerUser').value
          },
          {
            key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD,
            value: this.hasContainerPasswordChanged ? this.oracleFormGroup.get('containerPassword').value : ''
          }
        );
      }
    }

    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   */
  set connection(connection: Connection) {
    this.oracleFormGroup.patchValue({
      database: connection.database,
      databasePort: connection.port,
      instanceName: this.getParameterValue(connection.parameters, ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_INSTANCE_NAME),
      jdbcDriverVersion: this.getParameterValue(connection.parameters, ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_DRIVER_VERSION)
    });

    this.credentialsComponent.connection = connection;

    if (this.getParameterValue(connection.parameters, ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_DRIVER_VERSION) === 'ORACLE12') {
      const isPluggable: boolean = JSON.parse(
        this.getParameterValue(connection.parameters, ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_SUPPORT_PLUGGABLE)
      );
      this.oracleFormGroup.patchValue({
        pluggableDatabase: isPluggable,
        jdbcEncryption: JSON.parse(this.getParameterValue(connection.parameters, ORACLE_CONNECTION_PARAMETERS.JDBC_ENCRYPTION))
      });

      if (isPluggable) {
        this.oracleFormGroup.patchValue({
          containerUser: this.getParameterValue(connection.parameters, ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_ROOT_CONTAINER_USER_ID),
          containerPassword: this.credentialsComponent.passwordMask
        });
      }

      this.pluggableDatabaseChanged(isPluggable);
    }
  }

  /**
   * Creates form controls for connection type
   */
  createForm(): void {
    this.oracleFormGroup = this.controlContainer.control as FormGroup;
    this.oracleFormGroup.addControl('database', new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator]));
    this.oracleFormGroup.addControl(
      'databasePort',
      new FormControl('1521', [Validators.required, Validators.min(1024), Validators.max(65535), Validators.pattern('^[0-9]*$')])
    );
    this.oracleFormGroup.addControl(
      'instanceName',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.oracleFormGroup.addControl('jdbcDriverVersion', new FormControl('ORACLE11', Validators.required));
    this.oracleFormGroup.addControl('pluggableDatabase', new FormControl(false));
    this.oracleFormGroup.addControl('jdbcEncryption', new FormControl(false));
    this.oracleFormGroup.addControl('containerUser', new FormControl(''));
    this.oracleFormGroup.addControl('containerPassword', new FormControl(''));
    this.pluggableDatabaseChanged(false);
  }

  /**
   * Controls whether to display the pluggable form elements
   * @returns true if drivcer version is equal to ORACLE12
   */
  isPluggableDatabaseSupported(): boolean {
    return this.oracleFormGroup.get('jdbcDriverVersion').value === 'ORACLE12';
  }

  /**
   * Event handler for when the pluggable database checkbox value changes
   * @param isChecked checked object from p-checkbox
   */
  pluggableDatabaseChanged(isChecked): void {
    const userControl = this.oracleFormGroup.get('containerUser');
    const passwordControl = this.oracleFormGroup.get('containerPassword');
    this.isContainerSectionVisible = isChecked;

    if (isChecked) {
      userControl.setValidators([Validators.required, ConnectionFormValidators.noWhiteSpaceValidator]);
      passwordControl.setValidators([Validators.required, ConnectionFormValidators.noWhiteSpaceValidator]);
    } else {
      userControl.clearValidators();
      passwordControl.clearValidators();
    }
    userControl.updateValueAndValidity();
    passwordControl.updateValueAndValidity();
  }

  /**
   * Event handler for the container password
   */
  containerPasswordChanged(): void {
    if (!this.hasContainerPasswordChanged) {
      this.hasContainerPasswordChanged = true;
      this.oracleFormGroup.get('containerPassword').setValue('');
    }
  }

  /**
   * Event handler for the JDBC driver version
   */
  jdbcDriverVersionChanged(jdbcVersion) {
    this.pluggableDatabaseChanged(jdbcVersion === 'ORACLE12' && this.oracleFormGroup.get('pluggableDatabase').value);
  }

  /**
   * Event handler for when the database or port changes
   */
  requireCredentials(): void {
    this.credentialsComponent.requireCredentials();
    // if pluggabe database is set then the container credentials are required again
    if (this.oracleFormGroup.get('pluggableDatabase').value) {
      // clear the container values
      this.oracleFormGroup.get('containerUser').setValue('');
      this.oracleFormGroup.get('containerPassword').setValue('');
      // require the container credentials to be entered again
      this.pluggableDatabaseChanged(true);
    }
  }
}
