(function () {
    'use strict';

    angular.module('arm').controller('conversationDetailCtrl',
                ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate', conversationDetailCtrl]);

    function conversationDetailCtrl($scope, $state, $ionicModal, $ionicSideMenuDelegate) {

		$scope.cancel = function()
		{
			$state.go('tab.conversationList', {
               //
            });
		}
		//		   
	};
})();



