import { Component, ChangeDetectionStrategy, Input, OnChanges, SimpleChanges } from "@angular/core";
import { MeteringPointState } from "../../models/meteringpointstates.model";
import { MeteringPointStatesSorter } from "./meteringpoint-states-sorter";

@Component({
    selector: "landisgyr-meteringpoint-states-list",
    templateUrl: "./meteringpoint-states-list.component.html",
    styleUrls: ["./meteringpoint-states-list.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringPointStatesListComponent implements OnChanges {
    @Input()
    meteringPointStates!: MeteringPointState[];

    meteringPointStatesSorter = new MeteringPointStatesSorter();
    sortedMeteringPointStates$ = this.meteringPointStatesSorter.getSortedMeteringPointStates();

    constructor() {}

    ngOnChanges(changes: SimpleChanges) {
        this.meteringPointStatesSorter.setMeteringPointStates(this.meteringPointStates);
        this.meteringPointStatesSorter.onSortEvent({
            active: "startTime",
            direction: "desc"
        });
    }
}
