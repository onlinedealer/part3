import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DatePipe } from '@angular/common';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { of } from 'rxjs';
import { Pipeline } from '../pipelines/pipeline/shared/pipeline';
import { PipelinesApiService } from '../pipelines/pipeline/shared/pipelines-api.service';
import { Project } from '../pipelines/pipeline/shared/project';
import { ProjectsApiService } from '../pipelines/pipeline/shared/projects-api.service';
import { BundlesComponent } from './bundles.component';
import { CreateBundleSidebarComponent } from './create-bundle-sidebar/create-bundle-sidebar.component';
import { Bundle } from './shared/bundles';
import { BundlesApiService } from './shared/bundles-api.service';
import { StopBundleDialogComponent } from './stop-bundle-dialog/stop-bundle-dialog.component';
import { DeleteBundleDialogComponent } from './delete-bundle-dialog/delete-bundle-dialog.component';
import { BundleDetailsSidebarComponent } from './bundle-details-sidebar/bundle-details-sidebar.component';

describe('BundlesComponent', () => {
  let component: BundlesComponent;
  let fixture: ComponentFixture<BundlesComponent>;
  let projectsApiService: ProjectsApiService;
  let pipelinesApiService: PipelinesApiService;
  let bundlesApiService: BundlesApiService;

  const mockLaunchDarklyService = jasmine.createSpyObj({
    dispose: () => of(),
    identify: () => of(),
    variation: () => {}
  });

  @Component({
    selector: 'p-connect-create-bundle-sidebar',
    template: '',
    providers: [
      {
        provide: CreateBundleSidebarComponent,
        useClass: MockCreateBundleSidebarComponent
      }
    ]
  })
  class MockCreateBundleSidebarComponent {
    open() {}
  }

  @Component({
    selector: 'p-connect-stop-bundle-dialog',
    template: '',
    providers: [
      {
        provide: StopBundleDialogComponent,
        useClass: MockStopBundleDialogComponent
      }
    ]
  })
  class MockStopBundleDialogComponent {
    isVisible: boolean;
    open() {}
  }

  @Component({
    selector: 'p-connect-delete-bundle-dialog',
    template: '',
    providers: [
      {
        provide: DeleteBundleDialogComponent,
        useClass: MockDeleteBundleDialogComponent
      }
    ]
  })
  class MockDeleteBundleDialogComponent {
    isVisible: boolean;
    open() {}
  }

  @Component({
    selector: 'p-connect-bundle-details-sidebar',
    template: '',
    providers: [
      {
        provide: BundleDetailsSidebarComponent,
        useClass: MockBundleDetailsSidebarComponent
      }
    ]
  })
  class MockBundleDetailsSidebarComponent {
    open() {}
  }

  const mockPipelines: Pipeline[] = [
    {
      id: '1',
      name: 'test',
      description: '',
      dataFlowType: 'SYNCHRONIZE',
      properties: [],
      filters: [],
      projectId: 'abcd',
      source: { dataConnection: {} }
    },
    {
      id: '2',
      name: 'test2',
      description: '',
      dataFlowType: 'SYNCHRONIZE',
      properties: [],
      projectId: 'abcd',
      filters: []
    }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [
        BundlesComponent,
        MockCreateBundleSidebarComponent,
        MockStopBundleDialogComponent,
        MockDeleteBundleDialogComponent,
        MockBundleDetailsSidebarComponent
      ],
      providers: [{ provide: LaunchDarklyService, useValue: mockLaunchDarklyService }, DatePipe]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BundlesComponent);
    bundlesApiService = TestBed.inject(BundlesApiService);
    component = fixture.componentInstance;
    projectsApiService = TestBed.inject(ProjectsApiService);
    pipelinesApiService = TestBed.inject(PipelinesApiService);
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of(mockPipelines));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should allow bundle name field to be clickable', () => {
    expect(component.fields[1].isClickable({})).toBe(true);
  });

  it('should open bundle details sidebar when clicking on bundle name field', () => {
    spyOn(component.bundleDetailsSidebarComponent, 'open').and.returnValue();
    component.fields[1].clickEvent({ bundleName: 'abcd' } as Bundle);
    expect(component.bundleDetailsSidebarComponent.open).toHaveBeenCalled();
  });

  it('should open create bundle sidebar', () => {
    spyOn(component.createBundleSidebarComponent, 'open').and.returnValue();
    component.tableConfiguration.createButtonClicked();
    expect(component.createBundleSidebarComponent.open).toHaveBeenCalled();
  });

  describe('on init', () => {
    it('should get list of bundles', () => {
      spyOn(bundlesApiService, 'getBundles').and.returnValue(
        of([{ bundleName: 'test', createdDate: '12 Oct 2022 10:30:36 pm' }] as Bundle[])
      );
      component.ngOnInit();
      expect(component.bundles.length).toEqual(1);
      expect(component.bundles[0].bundleName).toEqual('test');
    });
    it('should get list of source data connections in a project', () => {
      component.ngOnInit();
      expect(component.listOfSourceConnectionsInProject.length).toEqual(1);
    });
    it('should display 1st page level message which describes diagnostic bundles to the user', () => {
      component.ngOnInit();
      expect(component.pageLevelMessage).toEqual(1);
    });
  });

  it('should display 2nd page level message when bundle is created and create operation is underway', () => {
    spyOn(bundlesApiService, 'getBundles').and.returnValue(
      of([{ bundleName: 'test-bundle', status: 'COMPLETE', createdDate: '13 Oct 2022 06:20:40 pm' }] as Bundle[])
    );
    component.getListOfBundles('test-bundle');
    expect(component.pageLevelMessage).toEqual(2);
  });

  it('should display 3rd page level message when bundle is created but a bundle has a status of queued', () => {
    spyOn(bundlesApiService, 'getBundles').and.returnValue(
      of([
        { bundleName: 'test', status: 'QUEUED', createdDate: '13 Oct 2022 06:20:40 pm' },
        { bundleName: 'test-bundle', status: 'QUEUED', createdDate: '13 Oct 2022 06:20:45 pm' }
      ] as Bundle[])
    );
    component.getListOfBundles('test-bundle');
    expect(component.pageLevelMessage).toEqual(3);
  });

  it('should get bundle name when a bundle is created', () => {
    spyOn(bundlesApiService, 'getBundles').and.returnValue(
      of([{ bundleName: 'test', status: 'COMPLETE', createdDate: '13 Oct 2022 06:20:40 pm' }] as Bundle[])
    );
    component.getListOfBundles('test-bundle');
    expect(component.createdBundleName).toEqual('test-bundle');
  });

  it('should set the selected bundles', () => {
    component.tableConfiguration.rowSelectionChangedEvent([{ id: 1 }, { id: 2 }]);
    expect(component.selectedBundles.length).toBe(2);
  });

  it('should set data-cy of global checkbox in bundles table', () => {
    expect(component.tableConfiguration.getCheckboxTestIds(null)).toEqual('bundles-globalcheckbox');
  });

  it('should set data-cy of row checkbox in bundles table', () => {
    expect(component.tableConfiguration.getCheckboxTestIds({ bundleName: 'bundle1' } as Bundle)).toEqual('bundle-checkbox-bundle1');
  });

  it('should set if stop bundle button is disabled or not', () => {
    component.selectedBundles = [{ status: 'IN_PROGRESS' }];
    expect(component.isStopBundleDisabled()).toBeFalse();
    component.selectedBundles = [{ status: 'COMPLETED' }];
    expect(component.isStopBundleDisabled()).toBeTrue();
  });

  it('should set if delete bundle button is disabled or not', () => {
    component.selectedBundles = [{ status: 'IN_PROGRESS' }];
    expect(component.isDeleteBundleDisabled()).toBeTrue();
    component.selectedBundles = [{ status: 'COMPLETED' }];
    expect(component.isDeleteBundleDisabled()).toBeFalse();
  });

  it('should open stop bundle dialog', () => {
    spyOn(component.stopBundleDialogComponent, 'open').and.returnValue();
    component.selectedBundles = [{ status: 'IN_PROGRESS' }];
    component.openStopBundleDialog();
    expect(component.stopBundleDialogComponent.open).toHaveBeenCalled();
    expect(component.showStopBundleDialog).toBeTrue();
  });

  it('should open delete bundle dialog', () => {
    spyOn(component.deleteBundleDialogComponent, 'open').and.returnValue();
    component.selectedBundles = [{ status: 'COMPLETED' }];
    component.openDeleteBundleDialog();
    expect(component.deleteBundleDialogComponent.open).toHaveBeenCalled();
    expect(component.showDeleteBundleDialog).toBeTrue();
  });

  it('should clear the selected bundles and get the new list of bundles on delete event', () => {
    spyOn(bundlesApiService, 'getBundles').and.returnValue(
      of([{ bundleName: 'test', createdDate: '12 Oct 2022 10:30:36 pm' }] as Bundle[])
    );
    component.selectedBundles = [{ status: 'COMPLETED' }];
    component.refreshData();
    expect(component.selectedBundles.length).toBe(0);
    expect(component.bundles.length).toEqual(1);
    expect(component.bundles[0].bundleName).toEqual('test');
  });

  it('should format the size to MB', () => {
    expect(component.formatBytes(1024 * 512)).toBe('0.50 MB');
    expect(component.formatBytes(1024 * 1024)).toBe('1.00 MB');
  });

  it('should format the size to MB', () => {
    const expectedResult: Bundle[] = [{ createdDate: '13 Oct 2022 06:20:40 pm' }, { createdDate: '12 Oct 2022 10:30:36 pm' }];
    const bundles: Bundle[] = [{ createdDate: '12 Oct 2022 10:30:36 pm' }, { createdDate: '13 Oct 2022 06:20:40 pm' }];
    component.defaultSort(bundles);
    expect(bundles).toEqual(expectedResult);
  });

  it('should show and hide data-cy of bundle name', () => {
    expect(component.getBundleNameTestId({ field: { name: 'bundleName' }, defaultValue: 'bundle1' })).toEqual('bundle-bundle1');
    expect(component.getBundleNameTestId({ field: { name: 'createdDate' }, defaultValue: 'bundle1' })).toEqual(null);
  });
});
