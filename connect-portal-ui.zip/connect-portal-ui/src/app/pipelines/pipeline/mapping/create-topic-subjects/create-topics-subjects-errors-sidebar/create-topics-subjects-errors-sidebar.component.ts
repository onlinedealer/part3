import { Component, Input, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Pipeline } from '../../../shared/pipeline';

@Component({
  selector: 'p-connect-create-topics-subjects-errors-sidebar',
  templateUrl: './create-topics-subjects-errors-sidebar.component.html',
  styleUrls: ['./create-topics-subjects-errors-sidebar.component.scss']
})
export class CreateTopicsSubjectsErrorsSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @Input() errors = [];
  @Input() pipeline: Pipeline;

  secondaryButton: SidebarButton = {
    isDisabled: false,
    id: 'secondaryButton',
    text: 'pipelines.STAGES.MAPPING.CREATE_TOPIC_SUBJECTS_SIDEBAR.ERROR_SIDEBAR.COLLAPSE'
  };

  secondaryButtonClicked() {
    this.sidebarComponent.close();
  }

  open() {
    this.sidebarComponent.open();
  }
}
