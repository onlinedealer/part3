import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';

import { DiscardColumnMappingSidebarComponent } from './discard-column-mapping-sidebar.component';

describe('DiscardColumnMappingSidebarComponent', () => {
  let component: DiscardColumnMappingSidebarComponent;
  let fixture: ComponentFixture<DiscardColumnMappingSidebarComponent>;
  @Component({
    selector: 'p-connect-sidebar',
    template: '',
    providers: [
      {
        provide: SidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    open() {}
    close() {}
    parseHttpClientResponseMessage() {}
  }
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: '' } }],
      declarations: [DiscardColumnMappingSidebarComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DiscardColumnMappingSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should open dialog', () => {
    const openSidebar = spyOn(component.sidebarComponent, 'open');
    const row = { id: 'mapping_abc1', hasCustomColMappings: true, subject: { name: 'def', mappingIcon: 'ATTENTION' } };
    component.open(row);
    expect(openSidebar).toHaveBeenCalled();
  });
  it('should close the dialog', () => {
    const closeSidebar = spyOn(component.sidebarComponent, 'close');
    component.close();
    expect(closeSidebar).toHaveBeenCalled();
  });
  it('should emit discard clicked event and close the sidebar on primary button click', () => {
    const emitDiscardClicked = spyOn(component.discardClicked, 'emit');
    const closeSidebar = spyOn(component.sidebarComponent, 'close');
    component.rowData = { id: 'mapping_abc1', hasCustomColMappings: true, subject: { name: 'def', mappingIcon: 'ATTENTION' } };
    component.primaryButtonClicked();
    expect(emitDiscardClicked).toHaveBeenCalled();
    expect(closeSidebar).toHaveBeenCalled();
  });
  it('should close the sidebar upon clicking on cancel button', () => {
    const closeSidebar = spyOn(component.sidebarComponent, 'close');
    component.cancelButtonClicked();
    expect(closeSidebar).toHaveBeenCalled();
  });
});
