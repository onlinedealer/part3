export class CardListItemModel {

    public lastName: string;
    public carePassEnrolled: boolean;
    public state: string;
    public address1: string;
    public address2?: string;
    public city: string;
    public emailId?: string;
    public postalCode: string;
    public phoneNumber: string;
    public token: string;
    public expirationMonth: string;
    public expirationYear: string;
    public fSACard: boolean;
    public firstName: string;
    public creditCardType: string;
    public cardId: string;
    public expirationDateIndicator: string;
    public defaultCard: boolean;

    constructor(cardListItem: any) {
        this.lastName = cardListItem.lastName;
        this.carePassEnrolled = cardListItem.carePassEnrolled;
        this.state = cardListItem.state;
        this.address1 = cardListItem.address1;
        this.address2 = cardListItem.address2;
        this.city = cardListItem.city;
        this.emailId = cardListItem.emailId;
        this.postalCode = cardListItem.postalCode;
        this.phoneNumber = cardListItem.phoneNumber;
        this.token = cardListItem.token;
        this.expirationMonth = cardListItem.expirationMonth;
        this.expirationYear = cardListItem.expirationYear;
        this.fSACard = cardListItem.fSACard;
        this.firstName = cardListItem.firstName;
        this.creditCardType = cardListItem.creditCardType;
        this.cardId = cardListItem.cardId;
        this.expirationDateIndicator = cardListItem.expirationDateIndicator;
        this.defaultCard = cardListItem.defaultCard;
    }
}
