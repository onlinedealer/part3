import { TranslocoModule } from '@ngneat/transloco';
import { TestBed } from '@angular/core/testing';
import { MenuItem } from 'primeng/api';
import { SecondaryNavItemsService } from './secondary-nav-items.service';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { Spies } from 'discovery-test';

describe('SecondaryNavItemsService', () => {
  let service: SecondaryNavItemsService;

  beforeEach(() => {
    Spies.init();
    TestBed.configureTestingModule({
      imports: [TranslocoModule],
      providers: [{ provide: LaunchDarklyService, useValue: Spies.launchDarklyService }]
    });
    service = TestBed.inject(SecondaryNavItemsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call getNavItems', () => {
    const items: MenuItem[] = service.getNavItems();
    expect(items.length).toBeGreaterThan(1);
  });

  it('should call getActiveNav', () => {
    const item: MenuItem = service.getActiveNav('data-profile');
    expect(item.id).toBe('data-profile');
  });
});
