﻿(function () {
    'use strict';

    angular.module('arm')

    //    .directive("myDirective", function () {
    //    return {
    //        scope: {
    //            property: "="
    //        },
    //        link: function (scope, el) {

    //            //scope.someParentObject.foo = "See I can still change things because of inheritance";

    //            //scope.someLocalObject = {
    //            //    foo: "Yay, I'm local only to this direcive!"
    //            //}
    //        }
    //    }
    //})
    .filter("datefilter", function (utility) {
        return function (items, from) {
            if (typeof from == 'undefined' || from == '') {
                return items;
            }
            //var selDt = utility.getDateStringMDYFormat(from); //utility.parseDate(from);
            //var selDt = utility.getDateStringMDYFormat(from); //utility.parseDate(from);
            var firstValue = from.toString().split("-");
            var firstDate = new Date();
            firstDate.setFullYear(firstValue[0], (firstValue[1] - 1), firstValue[2]);

            var result = [];
            for (var i = 0; i < items.length; i++) {
                //var actDate = utility.getDateStringMDYFormat(items[i].ActivityDate);
                var secondValue = items[i].ActivityDate.toString().split("-"); //utility.getDateInServerFormat(items[i].ActivityDate)
                var secondDate = new Date();
                secondDate.setFullYear(secondValue[0], (secondValue[1] - 1), secondValue[2]);
                if (secondDate >= firstDate) {
                    result.push(items[i]);
                }
            }

            return result;
        };
    })
.filter('filterMultiple', ['$filter', 'utility', function ($filter, utility) {
    return function (items, keyObj) {
        if (typeof keyObj == 'undefined' || keyObj == '') {
            return items;
        }

        if (utility.isEmpty(keyObj)) {
            return items;
        }
        var flagEmptyData = true;
        var filterObj = {
            data: items,
            filteredData: [],
            applyFilter: function (obj, key) {               
                var fData = [];
                if (this.filteredData.length == 0)
                    this.filteredData = this.data;
                if (obj) {
                    var fObj = {};
                    if (!angular.isArray(obj)) {
                        fObj[key] = obj;
                        fData = fData.concat($filter('filter')(this.filteredData, fObj));
                    } else if (angular.isArray(obj)) {
                        if (obj.length > 0) {
                            for (var i = 0; i < obj.length; i++) {
                                if (angular.isDefined(obj[i])) {
                                    fObj[key] = obj[i];
                                    fData = fData.concat($filter('filter')(this.filteredData, fObj));                                    
                                }
                            }

                        }
                    }

                    if (fData.length > 0) {
                        this.filteredData = fData;
                    }
                    else {
                        this.filteredData = [];
                        flagEmptyData = false;
                    }
                    if (!flagEmptyData) {
                        this.filteredData = [];
                    }

                }
            }
        };

        if (keyObj) {
            angular.forEach(keyObj, function (obj, key) {                
                filterObj.applyFilter(obj, key);
            });
        }

        return filterObj.filteredData;
    }
}])

.filter('unique', function () {
    return function (input, key) {
        var unique = {};
        var uniqueList = [];
        for (var i = 0; i < input.length; i++) {
            if (typeof unique[input[i][key]] == "undefined") {
                unique[input[i][key]] = "";
                uniqueList.push(input[i]);
            }
        }
        return uniqueList;
    };
})

.filter("listingFilter", function (utility) {
    return function (items, from) {
        if (typeof from == 'undefined' || from == '') {
            return items;
        }
        //var selDt = utility.getDateStringMDYFormat(from); //utility.parseDate(from);
        //var selDt = utility.getDateStringMDYFormat(from); //utility.parseDate(from);
        var firstValue = from.toString().split("-");
        var firstDate = new Date();
        firstDate.setFullYear(firstValue[0], (firstValue[1] - 1), firstValue[2]);

        var result = [];
        for (var i = 0; i < items.length; i++) {
            //var actDate = utility.getDateStringMDYFormat(items[i].ActivityDate);
            var secondValue = items[i].ActivityDate.toString().split("-"); //utility.getDateInServerFormat(items[i].ActivityDate)
            var secondDate = new Date();
            secondDate.setFullYear(secondValue[0], (secondValue[1] - 1), secondValue[2]);
            if (secondDate >= firstDate) {
                result.push(items[i]);
            }
        }

        return result;
    };
})
    .filter("dealdatefilter", function (utility) {
        return function (items, from) {
            if (typeof from == 'undefined' || from == '') {
                return items;
            }

            //var selDt = utility.getDateStringMDYFormat(from); //utility.parseDate(from);
            var firstValue = from.toString().split("-");
            var firstDate = new Date();
            firstDate.setFullYear(firstValue[0], (firstValue[1] - 1), firstValue[2]);

            var result = [];
            for (var i = 0; i < items.length; i++) {
                //var actDate = utility.getDateStringMDYFormat(items[i].ActivityDate);
                var secondValue = items[i].ExpectedDealCloseDate.toString().split("-"); //utility.getDateInServerFormat(items[i].ActivityDate)
                var secondDate = new Date();
                secondDate.setFullYear(secondValue[0], (secondValue[1] - 1), secondValue[2]);
                if (secondDate >= firstDate) {
                    result.push(items[i]);
                }
            }
            return result;
        };
    })
    .directive('autoComplete', function ($timeout) {
        return function (scope, iElement, iAttrs) {
            iElement.autocomplete({
                source: scope[iAttrs.uiItems],
                select: function () {
                    $timeout(function () {
                        iElement.trigger('input');
                    }, 0);
                }
            });
        }
    });
    //.directive("myAddThings", function () {
    //    return {
    //        restrict: "E",
    //        template:
    //          "<input ng-model='vals.x' /><input ng-model='vals.y' />" +
    //          "<button ng-click='sum = localFn({ x: vals.x, y: vals.y })'>Add</button>" +
    //          "<div>{{sum}}</div>",
    //        scope: {
    //            localFn: "&fn"
    //        }
    //    };
    //})
    //.directive("myAddThings", function () {
    //    return {
    //        restrict: "E",
    //        template: "{{result}}",
    //        scope: {
    //            localFn: "&fn"
    //        },
    //        link: function (scope) {
    //            scope.result = scope.localFn({
    //                x: 1,
    //                y: 2
    //            });
    //        }
    //    };
    //});
})();