import { BehaviorSubject, Observable, combineLatest } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber, isString } from "lodash";
import { EventVO } from "../../../models/view-objects/event-vo.model";

export class SSPrepaymentTokenLogSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: string }> = new BehaviorSubject({
        active: "eventTime",
        direction: "desc"
    } as any);

    tokenLogObj: EventVO[] = [];

    public setTokenLogProperties(tokenLogObj: EventVO[]) {
        this.tokenLogObj = tokenLogObj;
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedTokenLogProperties(tokenLogData$: Observable<EventVO[]>): Observable<EventVO[]> {
        return combineLatest([this.sortingSubject.asObservable(), tokenLogData$]).pipe(
            map(([sortingValues, tokenLogValues]) =>
                sortingValues.direction === "" ? tokenLogValues : [...tokenLogValues].sort(this.tokenLogComparator)
            )
        );
    }

    public onSortChange(event: { active: string; direction: string }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    tokenLogComparator = (r1: any, r2: any): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "eventTime":
                return this.sortByDate(r1, r2, directionMultiplier);
            case "stsTokenId":
                return this.sortByNumber(
                    parseInt(r1.definitionParameters[0].stsTokenId.replace(/\s/g, ""), 10),
                    parseInt(r2.definitionParameters[0].stsTokenId.replace(/\s/g, ""), 10),
                    directionMultiplier
                );
            case "amount":
                return this.sortByNumber(
                    parseInt(r1.definitionParameters[3].value, 10),
                    parseInt(r2.definitionParameters[3].value, 10),
                    directionMultiplier
                );
            case "deliveryMethod":
                return this.sortByString(
                    r1.definitionParameters[2].deliveryStatus,
                    r2.definitionParameters[2].deliveryStatus,
                    directionMultiplier
                );
            case "tokenId":
                return this.sortByNumberOverString(r1.definitionParameters[1].value, r2.definitionParameters[1].value, directionMultiplier);
            case "description":
                return this.sortByString(r1.definitionParameters[4].value, r2.definitionParameters[4].value, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByDate(r1: EventVO, r2: EventVO, directionMultiplier: number) {
        if (isNumber(r1.eventTime) && isNumber(r2.eventTime)) {
            return r1.eventTime > r2.eventTime ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(r1.eventTime) && isNil(r2.eventTime)) {
            return this.sortByString(r1.eventTime, r2.eventTime, 1);
        }

        if (isNil(r1.eventTime)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.eventTime)) {
            return directionMultiplier;
        }

        return 0;
    }

    sortByNumberOverString(value1: string | undefined, value2: string | undefined, directionMultiplier: number) {
        if (!isNaN(Number(value1)) && !isNaN(Number(value2))) {
            return Number(value1) > Number(value2) ? directionMultiplier : -1 * directionMultiplier;
        }
        if (!isNaN(Number(value1)) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && !isNaN(Number(value2))) {
            return directionMultiplier;
        }

        if (!isNaN(Number(value2)) || isNil(value2)) {
            return directionMultiplier;
        }

        if (!isNaN(Number(value1)) || isNil(value1)) {
            return -1 * directionMultiplier;
        }
        if (isString(value1) && isString(value2)) {
            return this.sortByString(value1, value2, directionMultiplier);
        }
        return value1.toUpperCase() < value2.toUpperCase() ? directionMultiplier : -1 * directionMultiplier;
    }

    sortByString(value1: string | undefined, value2: string | undefined, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }
        return directionMultiplier;
    }

    sortByNumber(value1: number | undefined, value2: number | undefined, directionMultiplier: number) {
        if (isNumber(value1) && isNumber(value2)) {
            return value1 > value2 ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNumber(value1) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && isNumber(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value1) || isNil(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value2) || isNil(value1)) {
            return -1 * directionMultiplier;
        }

        return 0;
    }
}
