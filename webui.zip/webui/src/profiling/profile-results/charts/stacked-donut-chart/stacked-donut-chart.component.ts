import { Component, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-stacked-donut-chart',
  templateUrl: './stacked-donut-chart.component.html',
  styleUrls: ['./stacked-donut-chart.component.css']
})
export class StackedDonutChartComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, any>;
  @Input()
  showTrendsIndicator: boolean;
  data: any;
  basicOptions: any;
  totalRows: number;
  chartWidth: string = '20vw';

  constructor(private translocoService: TranslocoService) {}

  ngOnInit() {
    this.loadData();
  }

  selectData(event: any): void {}

  private loadData(): void {
    this.data = {
      labels: [],
      datasets: [
        {
          data: [],
          backgroundColor: [
            ProfilingConstants.FREQUENCYCHARTCOLORS[0],
            ProfilingConstants.FREQUENCYCHARTCOLORS[1],
            ProfilingConstants.FREQUENCYCHARTCOLORS[2],
            '#fff'
          ],
          hoverBackgroundColor: [
            ProfilingConstants.FREQUENCYCHARTCOLORS[0],
            ProfilingConstants.FREQUENCYCHARTCOLORS[1],
            ProfilingConstants.FREQUENCYCHARTCOLORS[2],
            '#fff'
          ],
          borderColor: 'white'
        },
        {
          data: [],
          backgroundColor: [
            ProfilingConstants.FREQUENCYCHARTCOLORS[0],
            ProfilingConstants.FREQUENCYCHARTCOLORS[1],
            ProfilingConstants.FREQUENCYCHARTCOLORS[2],
            '#fff'
          ],
          hoverBackgroundColor: [
            ProfilingConstants.FREQUENCYCHARTCOLORS[0],
            ProfilingConstants.FREQUENCYCHARTCOLORS[1],
            ProfilingConstants.FREQUENCYCHARTCOLORS[2],
            '#fff'
          ],
          borderWidth: 0
        }
      ]
    };

    if (this.treePath && this.treePath.columnView) {
      if (this.treePath && this.treePath.treeData && this.treePath.treeData.parent) {
        this.chartWidth = this.showTrendsIndicator ? '10vw' : '20vw';
        this.totalRows = this.treePath.treeData.parent.data.totalRows;
        const nonUniqueCount = this.totalRows - this.statistics['uniqueCount'];
        const unique = (
          (this.statistics['uniqueCount'] / (this.statistics['uniqueCount'] + nonUniqueCount)) *
          100
        ).toFixed(2);
        const distinct = (
          (this.statistics['distinctCount'] / (this.statistics['uniqueCount'] + nonUniqueCount)) *
          100
        ).toFixed(2);
        const nonUnique = ((nonUniqueCount / (this.statistics['uniqueCount'] + nonUniqueCount)) * 100).toFixed(2);

        // eslint-disable-next-line radix
        this.getDataUniqueness(parseFloat(unique), parseFloat(nonUnique), parseFloat(distinct));
      }
    }

    this.basicOptions = {
      plugins: {
        legend: {
          display: this.showTrendsIndicator ? false : true,
          align: 'start',
          position: 'right',
          onClick: (event: any, legendItem: any) => {},
          onHover: (e: any) => {
            e.native.target.style.cursor = 'pointer';
          },
          labels: {
            boxWidth: 10
          }
        },
        tooltip: { enabled: false }
      },
      cutout: '65%'
    };
  }

  private getDataUniqueness(unique: number, nonUnique: number, distinct: number): void {
    let falseData: number = 100;
    if (!isNaN(distinct)) {
      falseData = parseFloat((100 - distinct).toFixed(1));
    } else {
      distinct = 0;
    }
    this.data.datasets[0].data = [unique, nonUnique, 0, 0];
    this.data.datasets[1].data = [0, 0, distinct, falseData];

    this.data.labels[0] =
      this.translocoService.translate('discoveryProfiling.results.unique') + ' ' + '(' + unique + '%)';
    this.data.labels[1] =
      this.translocoService.translate('discoveryProfiling.results.nonUnique') + ' ' + '(' + nonUnique + '%)';
    this.data.labels[2] =
      this.translocoService.translate('discoveryProfiling.results.distinct') + ' ' + '(' + distinct + '%)';
  }
}
