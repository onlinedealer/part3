import { Component } from "@angular/core";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { map } from "rxjs/operators";

import { MeteringPointsFeatureState } from "../../../store/reducers";
import { MultiplyMeteringValuesVO, convertValuesForTableEpochsToDisplay } from "../../../models/view-objects/meteringdata-vo.model";
import { ProfileDataSelectors } from "../../../store/selectors";
import { DateFormatService } from "../../../../Shared/services/date-format.service";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { ProfileDataActions } from "../../../store/actions";
@Component({
    selector: "landisgyr-multiply-metering-values",
    templateUrl: "./multiply-metering-values.component.html",
    styleUrls: ["./multiply-metering-values.component.scss"]
})
export class MultiplyMeteringValuesComponent {
    dialogTitle: string;

    daialogTableData$: Observable<MultiplyMeteringValuesVO[]> = this.store
        .select(ProfileDataSelectors.getMultiplyMeteringValuesProfileDataWithOnlyRelevantReadings)
        .pipe(map((values) => this.convertValueTimestampsForDisplay(values)));

    dataEdited$: Observable<boolean> = this.store.select(ProfileDataSelectors.getIsProfileDataEditedInMultiplyDialog);

    dialogValueDigitLength$: Observable<any> = this.store.select(
        ProfileDataSelectors.getMultiplyMeteringValuesProfileDataValueDigitNumbers
    );

    constructor(private store: Store<MeteringPointsFeatureState>, private dateFormatService: DateFormatService) {
        // tslint:disable-next-line: max-line-length
        this.dialogTitle = $localize`:|Edit values with basic operations@@MultiplyMeteringValuesDialog.header:Edit values with basic operations`;
    }

    private convertValueTimestampsForDisplay = (values: MultiplyMeteringValuesVO[]) => {
        return values.map((value) => convertValuesForTableEpochsToDisplay(value, this.dateFormatService));
    };

    onSortChange(sortChange: SortOrder) {
        this.store.dispatch(ProfileDataActions.SetMultiplyMeteringValuesTableSorting({ sortChange: sortChange }));
    }
}
