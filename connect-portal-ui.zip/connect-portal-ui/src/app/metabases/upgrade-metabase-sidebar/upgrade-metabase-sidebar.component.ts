import { Clipboard } from '@angular/cdk/clipboard';
import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Metabase } from '../shared/metabase.model';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { UpgradeMetabaseFormComponent } from './upgrade-metabase-form/upgrade-metabase-form.component';
import { EncryptionService } from '@shared/services/encryption.service';

@Component({
  selector: 'p-connect-upgrade-metabase-sidebar',
  templateUrl: './upgrade-metabase-sidebar.component.html',
  styleUrls: ['./upgrade-metabase-sidebar.component.scss']
})
export class UpgradeMetabaseSidebarComponent {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * Reference to the UpgradeMetabaseFormComponent child component
   */
  @ViewChild(UpgradeMetabaseFormComponent) upgradeMetabaseFormComponent: UpgradeMetabaseFormComponent;

  @Output() metabaseUpgradeEvent = new EventEmitter<boolean>();

  primaryButton: SidebarButton = {
    id: 'metabaseUpgradeButton',
    text: 'metabases.METABASE_UPGRADE.BUTTONS.UPGRADE',
    isDisabled: true
  };
  cancelButton: SidebarButton = {
    id: 'metabaseCancelButton',
    text: 'common.BUTTONS.CANCEL'
  };

  errorMessage: string = '';

  constructor(
    private readonly metabasesApiService: MetabasesApiService,
    private clipboard: Clipboard,
    private readonly encryptionService: EncryptionService
  ) {}

  open(selectedMetabase: Metabase): void {
    this.upgradeMetabaseFormComponent.open(selectedMetabase);
    this.sidebarComponent.open();
  }

  async upgradeMetabaseButtonClicked() {
    this.sidebarComponent.isProcessingRequest = true;
    const connection = this.upgradeMetabaseFormComponent.selectedMetabase?.dataConnection;
    const { adminUserId, adminUserPassword } = this.upgradeMetabaseFormComponent.upgradeMetabaseForm.controls;
    let encryptedPassword = adminUserPassword.value;

    if (connection.connectionType !== 'DB2I') {
      encryptedPassword = await this.encryptionService
        .encrypt(connection.accessFromServer.name, adminUserPassword.value)
        .catch((errorResponse) => {
          this.upgradeMetabaseFormComponent.displayErrorMessage = true;
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
          this.toggleButtonVisibilityAndText(true, 'common.BUTTONS.CLOSE');
          this.errorMessage = this.sidebarComponent.message;
        });
    }

    this.metabasesApiService
      .upgradeMetabase(connection.id, { adminUserId: adminUserId.value, adminUserPassword: encryptedPassword })
      .subscribe({
        next: () => this.metabaseUpgradeEvent.emit(),
        error: (errorResponse: HttpErrorResponse) => {
          this.upgradeMetabaseFormComponent.displayErrorMessage = true;
          this.toggleButtonVisibilityAndText(true, 'common.BUTTONS.CLOSE');
          this.errorMessage = errorResponse.error.detailedMessage;
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  toggleButtonVisibilityAndText(isHidden: boolean, text: string): void {
    this.primaryButton.isHidden = isHidden;
    this.cancelButton.text = text;
  }

  cancelMetabaseButtonClicked(): void {
    this.upgradeMetabaseFormComponent.displayErrorMessage = false;
    this.toggleButtonVisibilityAndText(false, 'common.BUTTONS.CANCEL');
    this.upgradeMetabaseFormComponent.upgradeMetabaseForm.reset();
    this.errorMessage = '';
    this.sidebarComponent.close();
  }

  copyClipboard(): void {
    this.errorMessage ? this.clipboard.copy(this.errorMessage) : this.clipboard.copy('');
  }
}
