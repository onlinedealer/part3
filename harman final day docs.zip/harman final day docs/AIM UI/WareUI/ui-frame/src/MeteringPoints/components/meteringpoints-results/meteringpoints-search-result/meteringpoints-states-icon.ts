import { Component, ChangeDetectionStrategy, Input } from "@angular/core";

@Component({
    selector: "landisgyr-meteringpoint-state-icon",
    templateUrl: "./meteringpoints-states-icon.html",
    styleUrls: ["./meteringpoints-states-icon.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringPointStatesIconComponent {
    @Input() icons!: { icon: string; name: string; identifier: string }[];

    trackByFn(index: number, icon: any) {
        return index;
    }
}
