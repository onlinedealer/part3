(function() {
    'use strict';

    fileuploader.controller("homeCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$location', homeCtrl]);

    function homeCtrl($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $location) {
        $scope.viewbtn = true;
        $scope.DataSource = [];
        $rootScope.dropdownselect1 = "";
        $scope.checkboxall = "";

        $scope.fetchdropdown = "";

        $scope.uploadFile = function() {


            /*var filepath = $('#fileUploadId').val();
            // var isValidFileFormate = new RegExp("^(?:[\w]\:|\\)(\\[a-z_\-\s0-9\.]+)+\.(txt|gif|pdf|doc|docx|xls|xlsx)$").test(filepath);

            // if (!isValidFileFormate) {
            //     alert("Please Enter Valid Format");
            //     return;
            // }
            var file = $scope.myFile;
            var fd = new FormData();
            fd.append('file', file);
            var uploadUrl = "http://10.3.48.137:8080/ocr/rest/v0/service/upload/pdf/file/"; //fileUpload?path:'C/bharath/xyz.txt'  

            // parent :: key  : filePath   value = u shoiuld set
            var multiplefile = [];

            var obj = {};
            obj.filePath = $('#fileUploadId').val();
            obj.fileType = fd;

            multiplefile.push(obj);

            var promise = fileUpload.uploadFileToUrl(uploadUrl, fd, multiplefile)
            promise.then(function(data) {
                console.log(data);
            });
            promise.catch(function(d) {
                console.log(d);
                return d;
            });
*/

        /*var file = $scope.myFile;
        console.log('file is ' );
        console.dir(file);
        var uploadUrl = "http://10.3.48.137:8080/ocr/rest/v0/service/upload/pdf/file/";
        fileUpload.uploadFileToUrl(file, uploadUrl);*/

        /*var file = $scope.myFile;
var uploadUrl = 'http://10.3.48.137:8080/ocr/rest/v0/service/get/all/template';
fileUpload.uploadFileToUrl(file, uploadUrl);

        };*/
        var file = $scope.myFile;
        console.log('file is ' );
        console.dir(file);
        var uploadUrl = "http://10.3.48.137:8080/ocr/rest/v0/service/upload/pdf/file/";
        var promise = fileUpload.uploadFileToUrl(file, uploadUrl);
        //var promise = fileUpload.uploadFileToUrl(uploadUrl, fd, multiplefile)
            promise.then(function(data) {
                $scope.DataSource = data;
                console.log(DataSource)
                console.log($scope.DataSource)
            });
            promise.catch(function(data) {
                console.log(data);
                return data;
            });
        };


        $scope.open = function(checkeditem) {
            // $rootScope.pagedisplay = checkeditem;
            $location.url(uiRouters.dashboard);
            console.log(checkeditem)
             /*url = "/view/dashboard/" + checkeditem +  "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'POST', {});

            
            promise.then(function(d) {
                $rootScope.dashboardData = d;
                
                $scope.fetchDataSource();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                
            });*/
        };

        $scope.process = function(DataSource){
            var item = [];
            angular.forEach(DataSource, function (value, key) {
                if (DataSource[key].selected == DataSource[key].id) {
                    item.push(DataSource[key].selected);
                }
            });
            console.log(item)
            
        }

        /*$scope.fetchDataSource = function() {

            //var url = "/get/list/of/data/for/" + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/data.json', 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.DataSource = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });
        }
        $scope.fetchDataSource();*/

        $scope.fetchDataSource = function() {

            var url = "http://10.3.48.137:8080/ocr/rest/v0/service/get/all/template" + "/";
            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.testdropdown = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });
        }
        $scope.fetchDataSource();

        

    }
})();