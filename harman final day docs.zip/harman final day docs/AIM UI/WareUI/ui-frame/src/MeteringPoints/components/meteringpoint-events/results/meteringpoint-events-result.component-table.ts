import {
    Component,
    Input,
    EventEmitter,
    Output,
    ElementRef,
    OnInit,
    ViewChild,
    OnChanges,
    SimpleChanges,
    AfterViewInit,
    ChangeDetectorRef
} from "@angular/core";
import { Store } from "@ngrx/store";
import { MatDialog } from "@angular/material/dialog";
import { Subscription } from "rxjs";
import { CdkVirtualScrollViewport } from "@angular/cdk/scrolling";
import { EventVO } from "../../../models/view-objects/event-vo.model";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { getWindowHeight } from "../../../../app/store/selectors/ui.selectors";
import { TranslationsService } from "../../../../app/services/translations-service";
import { EditColumnDialogComponent } from "../../edit-column-dialog/edit-column-dialog.component";
import { State } from "../../../../app/store/reducers";

@Component({
    selector: "landisgyr-meteringpoint-events-result-table",
    templateUrl: "./meteringpoint-events-result.component-table.html",
    styleUrls: ["./meteringpoint-events-result.component-table.scss"]
})
export class MeteringPointEventsResultTableComponent implements OnInit, OnChanges, AfterViewInit {
    @ViewChild(CdkVirtualScrollViewport) virtualScrollViewport!: CdkVirtualScrollViewport;
    @Input() columns: { columnId: string; columnName: string; }[] = [];
    @Input() eventsColumnConfigurations: {
        columnId: string;
        columnName: string;
        showColumn: boolean;
        draggedColumn?: boolean;
        columnWidth: number;
    }[] = [];
    @Input() events!: EventVO[];
    @Input() eventsCount!: number;
    @Input() eventsLoading!: boolean;
    @Input() pageCount!: number;
    @Input() pageIndex!: number;
    @Input() dates!: string[];
    @Input() sideViewOpen!: boolean;
    @Input() selected!: number;
    @Input() scrollState!: boolean;
    @Input() sortColumnname!: string;
    @Input() eventsForExport!: EventVO[];
    @Input() viewName!: string;
    @Output() selectedEvent: EventEmitter<EventVO> = new EventEmitter();
    @Output() showSelectedEvent: EventEmitter<EventVO> = new EventEmitter();
    @Output() showSelectedEventCategory: EventEmitter<EventVO> = new EventEmitter();
    @Output() hideSelectedEventCategory: EventEmitter<EventVO> = new EventEmitter();
    @Output() hideSelectedEvent: EventEmitter<EventVO> = new EventEmitter();
    @Output() pageChangeEvent: EventEmitter<number> = new EventEmitter();
    @Output() sortChangeEvent: EventEmitter<SortOrder> = new EventEmitter();
    @Output() eventsExportDataClick: EventEmitter<{ data: EventVO[]; viewName: string }> = new EventEmitter();

    @ViewChild("table") table!: ElementRef<HTMLElement>;
    scrollVisible!: boolean;
    windowHeightSub!: Subscription;
    eventsSub!: Subscription;
    infoMessage = this.translations.getTranslation("No data available for the selected time period");
    sideViewExpanded!: boolean;
    eventIDWithOpenedMenu = -1;
    eventIDWithOpenedMenuForEvent = -1;
    displayColumnCount: any;
    constructor(
        private store: Store<State>,
        private dialog: MatDialog,
        public translations: TranslationsService,
        private ref: ChangeDetectorRef
    ) {}

    ngOnChanges(changes: SimpleChanges) {
        if ((changes.columns || changes.events) && this.virtualScrollViewport) {
            this.virtualScrollViewport.checkViewportSize();
        }
        this.displayColumnCount = this.columnsDisplayCount();
        this.checkTableScrollWithDelay();
    }
    columnsDisplayCount() {
        let columnCount = 0;
        this.eventsColumnConfigurations.forEach((ele) => {
            if (ele.showColumn === true) {
                columnCount++;
            }
        });
        return columnCount;
    }

    ngOnInit() {
        this.columnsDisplayCount();
    }
    ngAfterViewInit(): void {
        this.windowHeightSub = this.store.select(getWindowHeight).subscribe((data) => {
            this.checkTableScroll();
        });
    }
    checkTableScrollWithDelay() {
        setTimeout(() => this.checkTableScroll(), 100);
    }
    checkTableScroll() {
        const tableContentHeight = this.events.length * 39;
        if (this.table && tableContentHeight / this.table.nativeElement.clientHeight >= 1) {
            this.scrollVisible = true;
        } else {
            this.scrollVisible = false;
        }
        this.ref.detectChanges();
    }
    OnSelect(event: EventVO) {
        this.selectedEvent.emit(event);
    }
    onSortChange(event: SortOrder) {
        this.sortChangeEvent.next(event);
    }
    onPageChange(page: number) {
        this.pageChangeEvent.next(page);
        if (this.virtualScrollViewport) {
            this.virtualScrollViewport.scrollToIndex(0, "smooth");
        }
    }
    openExportDialog() {
        this.eventsExportDataClick.emit({ data: this.eventsForExport, viewName: this.sortColumnname });
    }
    openEditColumnDialog() {
        this.dialog.open(EditColumnDialogComponent, {
            width: "550px",
            maxWidth: "550px",
            height: "620px",
            maxHeight: "620px",
            data: {
                results: [],
                header: this.eventsColumnConfigurations,
                tabSelectionFlag: this.viewName
            }
        });
    }

    showOnlyThisType(event: EventVO) {
        this.eventIDWithOpenedMenu = -1;
        this.showSelectedEvent.emit(event);
    }
    hideThisType(event: EventVO) {
        this.eventIDWithOpenedMenuForEvent = -1;
        this.hideSelectedEvent.emit(event);
    }

    showOnlyThisTypeForEvents(event: EventVO) {
        this.eventIDWithOpenedMenuForEvent = -1;
        this.showSelectedEventCategory.emit(event);
    }
    hideThisTypeForEvents(event: EventVO) {
        this.eventIDWithOpenedMenuForEvent = -1;
        this.hideSelectedEventCategory.emit(event);
    }

    HideExpandViewForEvents() {
        this.eventIDWithOpenedMenuForEvent = -1;
    }
    showExpandViewForEvents(event: EventVO) {
        this.eventIDWithOpenedMenuForEvent = event.id;
    }
    showExpandViewForTypes(event: EventVO) {
        this.eventIDWithOpenedMenu = event.id;
    }
    hideExpandViewForTypes() {
        this.eventIDWithOpenedMenu = -1;
    }
}
