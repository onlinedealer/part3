export class OIDC {
  static CLIENT_ID = 'OIDC-DIS-SHELL';
  static APP_CLIENT_ID = 'OIDC-Discovery';
}
