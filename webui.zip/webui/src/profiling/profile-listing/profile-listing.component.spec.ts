import { CommonModule } from '@angular/common';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslocoModule, TranslocoService } from '@ngneat/transloco';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { SecondaryNavModule } from '@precisely/prism-ng/secondary-nav';
import { ConnectionService, SecondaryNavItemsService, ServerSentEventsService } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { MockComponents } from 'ng-mocks';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { ConfirmationService } from 'primeng/api';
import { ConfirmDialog, ConfirmDialogModule } from 'primeng/confirmdialog';
import { ContextMenuModule } from 'primeng/contextmenu';
import { Sidebar } from 'primeng/sidebar';
import { TableModule } from 'primeng/table';
import { ProfileService } from 'profiling/profile.service';
import { of, throwError } from 'rxjs';
import { ProfileListingComponent } from './profile-listing.component';

describe('ProfileListingComponent', () => {
  let component: ProfileListingComponent;
  let fixture: ComponentFixture<ProfileListingComponent>;
  let toasterService;
  let translocoService;
  let router;
  beforeEach(() => {
    Spies.init();
    const mockSecNav = jasmine.createSpyObj('SecondaryNavItemsService', ['getNavItems']);
    TestBed.configureTestingModule({
      declarations: [ProfileListingComponent, ...MockComponents(Sidebar)],
      imports: [
        CommonModule,
        HttpClientTestingModule,
        ConfirmDialogModule,
        FormsModule,
        RouterTestingModule.withRoutes([]),
        BrowserAnimationsModule,
        ToastrModule.forRoot(),
        TranslocoModule,
        TableModule,
        ContextMenuModule,
        SecondaryNavModule,
        TranslocoLocaleModule.forRoot()
      ],
      providers: [
        ConfirmationService,
        { provide: ProfileService, useValue: Spies.ProfileService },
        { provide: ConnectionService, useValue: Spies.ConnectionService },
        { provide: HttpUtilService, useValue: Spies.HttpUtilService },
        { provide: ToastrService },
        { provide: TranslocoService },
        { provide: ServerSentEventsService, useValue: Spies.ServerSentEventsService },
        { provide: LaunchDarklyService, useValue: Spies.launchDarklyService },
        { SecondaryNavItemsService, useValue: mockSecNav }
      ]
    });

    fixture = TestBed.createComponent(ProfileListingComponent);
    component = fixture.componentInstance;
    toasterService = TestBed.get(ToastrService);
    spyOn(toasterService, 'success');
    spyOn(toasterService, 'error');
    translocoService = TestBed.get(TranslocoService);
    spyOn(translocoService, 'translate');
    router = TestBed.get(Router);
    spyOn(router, 'navigate').and.callFake(() => {});
    spyOn(router, 'navigateByUrl').and.callFake(() => {});
    spyOn(router, 'url').and.callFake(() => {});
    mockSecNav.getNavItems.and.returnValue(of([]));
    fixture.autoDetectChanges(true);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should load profiles and connections on ngOnInit', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[0]));
    component.ngOnInit();
    expect(component.profileList.length).toBeDefined();
    expect(component.connectionList.length).toBeDefined();
  });

  it('run profile should return inprogress', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[1]));
    Spies.ProfileService.runProfile.and.returnValue(of('dummy'));
    component.runProfile('profileId-1', 'profileName');
    expect(Spies.ProfileService.runProfile.calls.count()).toBe(1);
    expect(component.profileList[0].status).toBe('INPROGRESS');
    expect(component.profileList[0].message).toBe('table1: INPROGRESS\n');
  });

  xit('run profile should return success', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[0]));
    Spies.ProfileService.runProfile.and.returnValue(of({ runId: 'runId' }));
    component.runProfile('profileId-1', 'profileName');
    expect(Spies.ProfileService.runProfile.calls.count()).toBe(1);
    expect(Spies.ServerSentEventsService.getServerSentEvent.calls.count()).toBe(1);
    expect(Spies.ServerSentEventsService.getServerSentEvent.calls.first().args[0]).toBe(
      'some-url/profile/runStatus?runId=runId'
    );
    // expect(component.profileList[0].status).toBe('SUCCESS');
  });

  it('run profile should return error', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    Spies.ProfileService.runProfile.and.returnValue(of('dummy'));
    component.runProfile('profileId-1', 'profileName');
    expect(Spies.ProfileService.runProfile.calls.count()).toBe(1);
    // expect(Spies.ServerSentEventsService.getServerSentEvent.calls.count()).toBe(1);
    // expect(component.profileList[0].status).toBe('ERROR');
  });

  it('run profile should return error response 404', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    Spies.ProfileService.runProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.runProfile('profileId-1', 'profileName');
    expect(toasterService.error).toHaveBeenCalled();
  });

  it('run profile should return error response 423', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    Spies.ProfileService.runProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[3]));
    component.runProfile('profileId-1', 'profileName');
    expect(toasterService.error).toHaveBeenCalled();
  });

  it('run profile should return error response 403', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    Spies.ProfileService.runProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[5]));
    component.runProfile('profileId-1', 'profileName');
    expect(Mocks.MockHTTPErrorResponse[5].error.message).toBe('Unauthorized');
  });
  it('run profile should return error response other than 403', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    Spies.ProfileService.runProfile.and.returnValue(
      throwError({
        status: 401,
        error: {
          message: 'Unauthorized'
        }
      })
    );
    component.runProfile('profileId-1', 'profileName');
    expect(toasterService.error).toHaveBeenCalled();
  });
  it('should check handle change on event', () => {
    const event = {
      values: 'dummy'
    };
    component.handleChange(event);
    expect(component.completenessFilterValue).toBe('dummy');
  });

  it('should load menuitems on OnContextMenu', () => {
    const rowData = Mocks.MockProfileListModels[0];
    component.onContextMenu(rowData);
    expect(component.items.length).toBe(5);
  });

  it('should check delete profile', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[0]));
    Spies.ProfileService.deleteProfile.and.returnValue(of('dummy'));
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const accept = spyOn(confirmdialog, 'accept').and.callThrough();
    Spies.ConnectionService.deleteConnection.and.returnValue(of('success'));
    const profile = Mocks.MockProfileListModels[0];
    component.deleteProfile(profile);
    fixture.detectChanges();
    const acceptBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-accept');
    acceptBtn.click();
    expect(accept).toHaveBeenCalled();
    expect(Spies.ProfileService.getProfileList).toHaveBeenCalled();
  });

  it('should call onDelete with error response 404', () => {
    component.profileList = Mocks.MockProfileListModels;
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[0]));
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const accept = spyOn(confirmdialog, 'accept').and.callThrough();
    Spies.ProfileService.deleteProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    const profile = Mocks.MockProfileListModels[0];
    component.deleteProfile(profile);
    fixture.detectChanges();
    const acceptBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-accept');
    acceptBtn.click();
    expect(accept).toHaveBeenCalled();
  });

  it('should check delete profile error response 423', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[0]));
    component.profileList = Mocks.MockProfileListModels;
    Spies.ProfileService.deleteProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[3]));
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const accept = spyOn(confirmdialog, 'accept').and.callThrough();
    const profile = Mocks.MockProfileListModels[0];
    component.deleteProfile(profile);
    fixture.detectChanges();
    const acceptBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-accept');
    acceptBtn.click();
    expect(accept).toHaveBeenCalled();
  });

  it('should call onDelete with No button click', () => {
    const profile = Mocks.MockProfileListModels[0];
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const reject = spyOn(confirmdialog, 'reject').and.callThrough();
    component.deleteProfile(profile);
    fixture.detectChanges();
    const noBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-reject');
    noBtn.click();
    expect(reject).toHaveBeenCalled();
  });

  it('should check edit profile allowed', () => {
    const profile = Mocks.MockProfileListModels[0];
    component.editProfile(profile.id, true);
    // expect(Spies.Router.navigateByUrl.calls.first().args[0]).toBe('/data-profiling/edit/' + profile.id);
  });

  it('should check edit profile not allowed', () => {
    const profile = Mocks.MockProfileListModels[0];
    component.editProfile(profile.id, false);
    expect(toasterService.error).toHaveBeenCalled();
  });

  it('should check sidebar open for snowflake', () => {
    component.createConnection('snowflake');
    expect(component.sidebarVisible).toBe(true);
    expect(component.configureViewType).toBe('Add');
  });

  it('should check loadConnectionlist success', () => {
    Spies.ConnectionService.getConnectionList.and.returnValue(of(Mocks.MockConnections));
    component.loadConnectionList();
    expect(component.fetchConnectionsInProgress).toBe(false);
    // expect(component.connectionList[0].id).toBe('b26627bf-2535-4835-b8b0-0ba9d58358aa');
  });

  it('should check loadConnectionlist failure', () => {
    Spies.ConnectionService.getConnectionList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.loadConnectionList();
    expect(component.fetchConnectionsInProgress).toBe(false);
  });

  it('should check loadProfilelist success', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[0]));
    Spies.ProfileService.getProfileList.and.returnValue(of(Mocks.MockProfiles));
    component.loadProfileList();
    expect(component.fetchProfilesInProgress).toBe(false);
    expect(component.profileList[0].id).toBe('2c9c80877cb6daee017cb71851a00001');
    expect(component.profileList[0].lastRunId).toBe('runId1');
  });

  it('should check loadProfilelist failure', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    Spies.ProfileService.getProfileList.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.loadProfileList();
    expect(component.fetchProfilesInProgress).toBe(false);
    expect(component.profileList.length).toBe(0);
  });
  it('should check scheduler sidebar open', () => {
    const data = { viewType: 'Enabled', id: 'asdf556e', status: 'SUCCESS' };
    component.showScheduleSidebarEvent(data);
    expect(component.isScheduleSidebarVisible).toBe(true);
    expect(component.scheduleType.id).toEqual(data.id);
  });
  it('should check stopRun profile', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[0]));
    component.profileList = Mocks.MockProfileListModels;
    Spies.ProfileService.stopRunProfile.and.returnValue(of('dummy'));
    const profile = Mocks.MockProfileListModels[0];
    component.stopRunningProfile(profile.lastRunId);
    //expect(Spies.ToastrService['error']).toHaveBeenCalled();
  });

  it('should check stopRun profile error response 404', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    component.profileList = Mocks.MockProfileListModels;
    Spies.ProfileService.stopRunProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    const profile = Mocks.MockProfileListModels[0];
    component.stopRunningProfile(profile.lastRunId);
    expect(toasterService.error).toHaveBeenCalled();
  });

  it('should check stopRun profile error response 423', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    component.profileList = Mocks.MockProfileListModels;
    Spies.ProfileService.stopRunProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[3]));
    const profile = Mocks.MockProfileListModels[0];
    component.stopRunningProfile(profile.lastRunId);
    expect(toasterService.error).toHaveBeenCalled();
  });
  it('run profile should return error response other than 403', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockProfileRunResponse[2]));
    component.profileList = Mocks.MockProfileListModels;
    Spies.ProfileService.stopRunProfile.and.returnValue(
      throwError({
        status: 401,
        error: {
          message: 'Unauthorized'
        }
      })
    );
    const profile = Mocks.MockProfileListModels[0];
    component.stopRunningProfile(profile.lastRunId);
    expect(toasterService.error).toHaveBeenCalled();
  });
});
