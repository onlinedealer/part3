export interface ExportDataOptions {
    columns: Column[];
    selectedFileType: string;
    selectedDelimiter: string;
    selectedRange: string;
    fileName: string;
    havingBinaryConvertedData: boolean;
}

export interface Column {
    fieldName: string;
    displayName: string;
    exportColumn: boolean;
    showColumn?: boolean;
}
