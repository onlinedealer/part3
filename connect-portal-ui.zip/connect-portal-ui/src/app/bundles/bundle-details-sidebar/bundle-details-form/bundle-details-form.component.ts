import { Component, Input } from '@angular/core';
import { ErrorMessage } from '@precisely/prism-ng/cloud';
import { SidebarContext, SidebarManagerService } from '@precisely/prism-ng/sidebar-manager';
import { Observable, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Connection, CONNECTION_TYPE } from 'src/app/connections/shared/connection';
import { LogReader } from 'src/app/pipelines/pipeline/data/shared/logreader';
import { LogReadersApiService } from 'src/app/pipelines/pipeline/data/shared/logreaders-api.service';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { Bundle, LogMetadataList, MetadataDetails, BUNDLE_STATUS, MetadataDetailsList } from '../../shared/bundles';

@Component({
  selector: 'p-connect-bundle-details-form',
  templateUrl: './bundle-details-form.component.html',
  styleUrls: ['./bundle-details-form.component.scss']
})
export class BundleDetailsFormComponent {
  @Input() bundleDetails: Bundle;

  bundleTableContent: any = {
    agentLogs: [
      { header: 'bundles.BUNDLE_DETAILS_SIDEBAR.BUNDLE_TABLE.AGENT_LOGS.GATEWAY_LOGS', fileType: 'AGENT' },
      { header: 'bundles.BUNDLE_DETAILS_SIDEBAR.BUNDLE_TABLE.AGENT_LOGS.JOB_CONTROLLER_LOGS', fileType: 'JOB_CONTROLLER' }
    ],
    runtimeEngineLogs: [
      { header: 'bundles.BUNDLE_DETAILS_SIDEBAR.BUNDLE_TABLE.RUNTIME_ENGINE_LOGS.KERNEL_LOGS', fileType: 'KERNEL' },
      { header: 'bundles.BUNDLE_DETAILS_SIDEBAR.BUNDLE_TABLE.RUNTIME_ENGINE_LOGS.LISTENER_LOGS', fileType: 'LISTENER' },
      { header: 'bundles.BUNDLE_DETAILS_SIDEBAR.BUNDLE_TABLE.RUNTIME_ENGINE_LOGS.PROJECT_CONFIG_FILES', fileType: 'XML' }
    ]
  };

  /**
   * Name for one instance of each DB2I connection used by this project.
   */
  db2iConnectionName = '';

  /**
   * Name of logreader instance for the associated DB2I connection used by this project.
   */
  logreaderName: Observable<string> = of('');
  /**
   * Name for one instance of each runtime engine used by this project.
   */
  runtimeEngineName = '';

  projectName = '';

  filesInTheBundle: MetadataDetails[] = [];

  constructor(private readonly logReadersApiService: LogReadersApiService, private readonly sidebarManagerService: SidebarManagerService) {}

  get locationOfBundle(): string {
    const containerName = 'connect-agent-jobcontroller:';
    return this.bundleDetails && this.bundleDetails.location ? containerName + this.bundleDetails.location : '';
  }

  getBundleStatusIcon(status: string, increaseIconSize = ''): string {
    if (status) {
      const commonStyles = `align-bottom png-icon-sm ${increaseIconSize}`;

      switch (status) {
        case 'ACTION_REQUIRED':
        case 'ERROR':
          return commonStyles + ' png-alert-actionrequired-solid text-danger';
        case 'STOPPED':
          return commonStyles + ' png-alert-stopped-solid text-danger';
        case 'IN_PROGRESS':
          return commonStyles + ' png-alert-inprogress text-success';
        case 'COMPLETED':
          return commonStyles + ' png-alert-ok-solid text-success';
        case 'QUEUED':
          return commonStyles + ' png-signin text-success';
      }
    }
  }

  /**
   * Hides/show individual file status icons in the table.
   */
  showBundleFileStatusIcon(fileType: string): boolean {
    const status = this.getSpecifiedFileInformation(fileType).status;
    return status !== '' && status !== 'QUEUED';
  }

  /**
   * When a project is not deployed, bundle details response will show kernel log to have a total size of '-1'.
   * For this scenario, this function will hide the the kernel log's total size in the bundle content table.
   * - OR -
   * For the scenario where a log's information (e.g. 'Listener log') is expected to be shown in the bundle content table, but the log's data is not within the bundle details response,
   * this function will hide the log's total size in the bundle content table.
   */
  hideBundleFileEstimatedSize(fileType: string): boolean {
    const totalSize = this.getSpecifiedFileInformation(fileType).totalSize;
    return (fileType === 'KERNEL' && totalSize === '') || !this.filesInTheBundle.some((file) => file.fileType === fileType);
  }

  /**
   * Gets an instance of DB2I connection and log reader used by the project and extract the user-given name.
   */
  getConnectionAndLogReaderName(sourceConnectionsInProject: Connection[], project: Project): void {
    const db2iConnections = sourceConnectionsInProject.filter((c) => c.connectionType === CONNECTION_TYPE.DB2I);

    if (db2iConnections.length) {
      this.db2iConnectionName = db2iConnections[0].name;
      this.logreaderName = this.getLogReaders(db2iConnections[0].id, project).pipe(map((logreader) => logreader[0].name));
    }
  }

  getFilesInTheBundle(logsInformation: LogMetadataList): void {
    this.filesInTheBundle = [
      ...this.getLogsOrFilesData<MetadataDetails>(logsInformation.hubMetadataList, 'metadataList'),
      ...this.getLogsOrFilesData<MetadataDetails>(logsInformation.serverMetadataList, 'metadataList')
    ];
  }

  checkIfIBMIConnectionUsedInProject(sourceConnectionsInProject: Connection[], project: Project): void {
    // 'IBMI' filetype is present only when there is an IBM i connection in the project
    const isDB2IConnectionUsedInProject = this.filesInTheBundle.some((file) => file.fileType === 'IBMI');

    if (isDB2IConnectionUsedInProject) {
      this.getConnectionAndLogReaderName(sourceConnectionsInProject, project);
    }
  }

  /**
   * @param fileType Specified file type
   * Function returns total size and worst overall status of specified file in the bundle
   */
  getSpecifiedFileInformation(fileType: string): { status: string; totalSize: string } {
    const specifiedFile = this.filesInTheBundle.filter((file) => file.fileType === fileType);
    const totalSize = specifiedFile.reduce((totalSize, file) => totalSize + file.totalSize, 0);

    const statusOfIndividualFiles = this.getLogsOrFilesData<MetadataDetailsList>(specifiedFile, 'metadataDetailsList').map(
      (data) => data.status
    );

    return { totalSize: this.formatBytes(totalSize), status: this.getOverallStatusOfIndividualFiles(statusOfIndividualFiles) };
  }

  openErrorMessageSidebar() {
    const error: ErrorMessage = {
      message: this.bundleDetails.details
    };
    this.sidebarManagerService.setActiveSidebar({ id: 'error-sidebar', data: [error] } as SidebarContext);
  }

  private getOverallStatusOfIndividualFiles(statusOfIndividualFiles: string[]): string {
    let overallStatus = '';

    if (statusOfIndividualFiles.includes(BUNDLE_STATUS.ERROR)) {
      overallStatus = BUNDLE_STATUS.ERROR;
    } else if (statusOfIndividualFiles.includes(BUNDLE_STATUS.STOPPED)) {
      overallStatus = BUNDLE_STATUS.STOPPED;
    } else if (statusOfIndividualFiles.includes(BUNDLE_STATUS.QUEUED)) {
      overallStatus = BUNDLE_STATUS.QUEUED;
    } else if (statusOfIndividualFiles.includes(BUNDLE_STATUS.IN_PROGRESS)) {
      overallStatus = BUNDLE_STATUS.IN_PROGRESS;
    } else if (statusOfIndividualFiles.includes(BUNDLE_STATUS.COMPLETED)) {
      overallStatus = BUNDLE_STATUS.COMPLETED;
    }
    return overallStatus;
  }

  private formatBytes(bytes: number, decimals = 2): string {
    const sizeInMB = (bytes / (1024 * 1024)).toFixed(decimals);
    return bytes < 0 ? '' : bytes === 0 ? '0.00 MB' : sizeInMB + ' MB';
  }

  private getLogReaders(db2iConnectionId: string, project: Project): Observable<LogReader[]> {
    return this.logReadersApiService.getLogReaders(db2iConnectionId, project.id);
  }

  /**
   * Reusable function to extract data from response of bundle details API
   */
  private getLogsOrFilesData<T>(metadataList: any[], metadataDetailsKey: string): T[] {
    return metadataList.map((data) => data[metadataDetailsKey]).reduce((arr, data) => arr.concat(data), []);
  }
}
