(function() {
	'use strict';

	angular.module('arm').factory('tabService', ['serviceApi', '$filter', 'SERVICE_TYPE', 'localStorageService', 'sqliteService', 'utility','GENERAL_CONFIG','$rootScope', tabService]);

	function tabService(serviceApi, $filter, SERVICE_TYPE, localStorageService, sqliteService, utility, GENERAL_CONFIG,$rootScope) {
		var serArr = {};

    function CheckNull(val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return "NULL";
            }
            return val;
    }

    function CheckBitVal(val) {
            if (val == true) {
                return 1;
            }
            return 0;
    }

    serArr.sqlSelectContacts = function(){
        return sqliteService.query("SELECT * FROM Contacts WHERE LoggedInUserID="+ $rootScope.loggedInUserID  +" ").then(function(result){
            return result;
        });
    }

    serArr.sqlSelectCommunications = function(contactObj){
        var returnArr = [contactObj];
        return sqliteService.query("SELECT * FROM Communications WHERE ParentDeviceObjID='" +contactObj.DeviceObjID+ "' AND LoggedInUserID="+ $rootScope.loggedInUserID  +" ").then(function(result){
            returnArr.push(result);
            return returnArr;
        });
    }

		return serArr;
	}

})();
