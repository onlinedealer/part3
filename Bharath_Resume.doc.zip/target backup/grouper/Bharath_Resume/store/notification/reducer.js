import { fromJS } from 'immutable'

import { SHOW_NOTIFICATION } from './actionType'

export const initialState = fromJS({
  isShown: false,
  message: '',
})

export default function notificationReducer (state = initialState, action = {}) {
  switch (action.type) {
    case SHOW_NOTIFICATION: {
      return state
        .set('isShown', action.payload.isShown)
        .set('message', action.payload.message)
    }
    default:
      return state
  }
}
