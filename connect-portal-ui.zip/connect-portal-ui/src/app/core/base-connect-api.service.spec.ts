import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { BaseConnectApiService } from './base-connect-api.service';

describe('BaseConnectService', () => {
  let service: MockService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      providers: [MockService]
    });
    service = TestBed.inject(MockService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return url', () => {
    service.serviceURL = 'test';
    expect(service.serviceURL).toBe('/api/v1/test');
  });

  it('should create a new resource', () => {
    let actualResponse;
    service = new MockService(httpClient, 'mock');
    const mockObject: MockModel = { name: 'C' };
    service.create(mockObject).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/create');
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual(mockObject);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should update a resource', () => {
    service = new MockService(httpClient, 'mock');
    const item = {
      target: { parameters: [{ name: 'xyz', key: 'PARTITION_MESSAGES_BY' }, { name: 'xyz', key: 'USE_EXISTING_TOPIC' }, { name: 'abc' }] }
    };
    let actualResponse;
    const mockObject = {
      id: '1',
      name: 'C',
      target: { parameters: [{ name: 'xyz', key: 'PARTITION_MESSAGES_BY' }, { name: 'xyz', key: 'USE_EXISTING_TOPIC' }, { name: 'abc' }] }
    };
    service.update(mockObject, false, false).subscribe((response) => {
      actualResponse = response;
      service.settingDefaultTableMappingParams(item);
    });
    service.settingDefaultTableMappingParams(item);
    const req = httpMock.expectOne(service.serviceURL + '/1');
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual(mockObject);
    req.flush(null);

    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should update a resource and add update to endpoint', () => {
    service = new MockService(httpClient, 'mock');
    const item = {
      target: { parameters: [{ name: 'xyz', key: 'PARTITION_MESSAGES_BY' }, { name: 'xyz', key: 'USE_EXISTING_TOPIC' }, { name: 'abc' }] }
    };
    let actualResponse;
    const mockObject = {
      id: '1',
      name: 'C',
      target: { parameters: [{ name: 'xyz', key: 'PARTITION_MESSAGES_BY' }, { name: 'xyz', key: 'USE_EXISTING_TOPIC' }, { name: 'abc' }] }
    };
    service.update(mockObject, true, false).subscribe((response) => {
      actualResponse = response;
      service.settingDefaultTableMappingParams(item);
    });
    service.settingDefaultTableMappingParams(item);
    const req = httpMock.expectOne(service.serviceURL + '/1/update');
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual(mockObject);
    req.flush(null);

    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should update a resource and add update to endpoint and when Feature flag enables', () => {
    service = new MockService(httpClient, 'mock');
    const item = {
      target: {
        parameters: [
          { key: 'MAP_TABLES', value: '' },
          { key: 'PARTITION_MESSAGES_BY' },
          { key: 'USE_EXISTING_TOPIC' },
          { key: 'PREFIX_MESSAGES_WITH_TABLENAME', value: '' }
        ]
      }
    };
    let actualResponse;
    const mockObject = { id: '1', name: 'C', target: { parameters: [{ name: 'xyz' }, { name: 'abc' }] } };
    service.update(mockObject, true, true).subscribe((response) => {
      actualResponse = response;
      service.settingDefaultTableMappingParams(item);
    });
    service.settingDefaultTableMappingParams(item);
    const req = httpMock.expectOne(service.serviceURL + '/1/update');
    expect(req.request.method).toBe('PUT');
    expect(req.request.body).toEqual(mockObject);
    req.flush(null);

    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should return the first item for a given resource', () => {
    service = new MockService(httpClient, 'mock');
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = service.serviceURL;
    let returnedData: MockModel;
    const mockApiResponse = [{ name: 'A' }];
    service.getFirst().subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.name).toEqual('A');
  });

  it('should return response for a given resource', () => {
    service = new MockService(httpClient, 'mock');
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = service.serviceURL;
    let returnedData: MockModel[];
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getAll().subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return content response containing elements for a given resouce', () => {
    service = new MockService(httpClient, 'mock');
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = service.serviceURL;
    let returnedData: MockModel[];
    const mockApiResponse = {
      content: [{ name: 'A' }, { name: 'B' }]
    };
    service.getAll().subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return response for a given resource with params', () => {
    service = new MockService(httpClient, 'mock');
    const expectedRequestMethod = 'GET';
    let returnedData: MockModel[];
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    const params = {
      projectId: '1',
      dataConnectionId: '1'
    };
    service.getAll(params).subscribe((response) => {
      returnedData = response;
    });
    const expectedEndpointUrl = service.serviceURL + '?projectId=1&dataConnectionId=1';
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return a resource by id', () => {
    service = new MockService(httpClient, 'mock');
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = `${service.serviceURL}/1`;
    let actualResponse;
    const mockApiResponse = { id: '1', name: 'test' };
    service.get('1').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(actualResponse.name).toEqual('test');
  });

  it('should return a resource by its name', () => {
    service = new MockService(httpClient, 'mock');
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = `${service.serviceURL}/by-name/test`;
    let actualResponse;
    const mockApiResponse = { id: '1', name: 'test' };
    service.getByName('test').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(actualResponse.name).toEqual('test');
  });

  it('should remove elements from the UI', () => {
    service = new MockService(httpClient, 'mock');
    const expectedRequestMethod = 'DELETE';
    const expectedEndpointUrl = service.serviceURL + '/delete';
    const ids = ['1', '2', '3'];
    let actualResponse = '';

    service.delete(ids).subscribe((response) => {
      actualResponse = response;
    });

    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });
});

class MockModel {
  id?: string;
  name?: string;
}

class MockService extends BaseConnectApiService<MockModel> {}
