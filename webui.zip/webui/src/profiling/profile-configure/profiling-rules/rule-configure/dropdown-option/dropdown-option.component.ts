import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ProfileRuleOptionModel } from 'profiling/profile-rule-option.model';

@Component({
  selector: 'discovery-rule-configure-option-type-dropdown',
  templateUrl: './dropdown-option.component.html',
  styleUrls: ['./dropdown-option.component.css']
})
export class DropdownOptionComponent {
  @Input() ruleConfigOption: ProfileRuleOptionModel;

  @Input()
  set showRuleSettingsSideBar(sideBarVisible: boolean) {
    if (sideBarVisible) {
      if (!this.ruleConfigOption.configuredOptionValue) {
        this.selectedOption = this.ruleConfigOption.defaultOptionValue;
      } else {
        this.selectedOption = this.ruleConfigOption.configuredOptionValue;
      }
    }
  }

  @Input() configuredOptionValues: Map<string, any> = new Map<string, any>();
  @Output() configuredOptionValuesChange: EventEmitter<Map<string, any>> = new EventEmitter<Map<string, any>>();
  selectedOption: any;

  onDropDownSelectionChanged(event) {
    this.configuredOptionValues.set(this.ruleConfigOption.id, event.value);
    this.configuredOptionValuesChange.emit(this.configuredOptionValues);
  }
}
