import { takeLatest, put, call } from 'redux-saga/effects'
import { getItemThemesAPI } from './actionCreator'
import * as types from './actionType'
import { TOGGLE_SNACKBAR } from '../Snackbar/actionType'

export function * getItemThemesSaga (action) {
  try {
    const payload = yield call(getItemThemesAPI, action.payload)

    yield put({
      type: types.GET_ITEM_THEMES_SUCCESS,
      payload,
    })
  } catch (error) {
    if (error && error.response && error.response.data) {
      const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: true }
      yield put({
        type: TOGGLE_SNACKBAR,
        snackMessage: errorData,
      })
    }
  }
}

export default function * watchDashboardSaga () {
  yield takeLatest(types.GET_ITEM_THEMES, getItemThemesSaga)
}
