import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PipelineFinalizeSummaryComponent } from './pipeline-finalize-summary.component';

describe('SummaryComponent', () => {
  let component: PipelineFinalizeSummaryComponent;
  let fixture: ComponentFixture<PipelineFinalizeSummaryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule],
      declarations: [PipelineFinalizeSummaryComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipelineFinalizeSummaryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
