import { Component, Input, Output } from '@angular/core';
import { EventEmitter } from '@angular/core';
@Component({
  selector: 'p-connect-excludeusers-form',
  templateUrl: './excludeusers-form.component.html'
})
export class ExcludeusersFormComponent {
  @Input() usersExcludedFromCapture: string[];
  @Output() usersExcludedFromCaptureChange = new EventEmitter();

  users = '';
  selectedUsers: string[] = [];

  addButtonClicked(): void {
    this.usersExcludedFromCapture = [...this.usersExcludedFromCapture, this.users];
    this.users = '';
    this.usersExcludedFromCaptureChange.emit(this.usersExcludedFromCapture);
    this.usersExcludedFromCapture.sort();
  }

  checkFirstCharacter(): boolean {
    if (this.users.match(/^\d+/)) {
      return true;
    } else {
      return false;
    }
  }

  removeItems(original: string[], removed: string[]): string[] {
    return original.filter((value) => !removed.includes(value));
  }

  removeButtonClicked(): void {
    this.usersExcludedFromCapture = this.removeItems(this.usersExcludedFromCapture, this.selectedUsers);
    this.selectedUsers = [];
    this.usersExcludedFromCaptureChange.emit(this.usersExcludedFromCapture);
  }

  checkRepeatedUsers(): boolean {
    return this.usersExcludedFromCapture?.includes(this.users);
  }
}
