import { Component, OnInit, Inject } from "@angular/core";
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { MatRadioChange } from "@angular/material/radio";
import { Store } from "@ngrx/store";
import * as exportDataAction from "../../../MeteringPoints/store/actions/export-data.action";
import * as exportTasksLogAction from "../../../Tasks/store/actions/task-xsf-search.action";
import { Column, ExportDataOptions } from "../../models/export.model";
import { NetworkSpecificConfigurationState } from "../../../app/store/reducers/network-specific-config.reducer";
import { Subscription } from "rxjs";
import { TranslationsService } from "../../../app/services/translations-service";
import { NetworkSpecificConfigSelectors } from "../../../app/store/selectors";
import { DateFormatService } from "../../../Shared/services/date-format.service";
import { ValuesForTable, convertValuesForTableEpochsToDisplay } from "../../models/view-objects/summarytable-vo.model";
import * as moment from "moment";
import { ExportDataService } from "../../../Shared/services/export.service";
import * as MeteringPointsSelectors from "../../../MeteringPoints/store/selectors/meteringpoints.selectors";
import { XSFSearchSelectors } from "../../../MeteringPoints/store/selectors";
import { getResultElementsCount, getTasksLogResultExportData } from "../../../Tasks/store/selectors/task-xsf-search.selectors";
import { ExportTableDataService } from "../../../MeteringPoints/services/export-data.service";
import { cloneDeep, map } from "lodash";

@Component({
    selector: "landisgyr-export-dialog",
    templateUrl: "./export-dialog.component.html",
    styleUrls: ["./export-dialog.component.scss"]
})
export class ExportDialogComponent implements OnInit {
    public headerItems: Column[] = [];
    public data: any = null;
    public fileName = "metering_points";
    public includeHeadings = true;
    public fileType = "csv";
    public delimiter = ",";
    public pageOption = "all";
    public rangeValue = "";
    public disableExport = false;
    public disableExportOnUnselectAll = false;

    totalPages = 0;
    totalSelectedPages = 0;
    maxRowLimit = 0;
    maxRowInPage = 100;
    selectedPageNo: any[] = [];
    infoMessageForAllData!: string;
    infoMessageForCustomData!: string;
    warningMsg!: string;
    radioButtonType = true;
    invalidRange = false;
    invRangeError!: string;
    selectedDataBetweenTimeRange: any[] = [];
    includePageRange!: boolean;
    includeTimeRange!: boolean;
    timeRangeInput!: { from: number; until: number };
    minDate!: Date;
    maxDate!: Date;
    viewName!: string;
    outOfRangeError!: boolean;
    havingBinaryConvertedData!: boolean;
    rangeDisable!: boolean;
    networkSpecificData!: Subscription;
    exportedData: any;
    totalExportRow: any;
    meteringPointsResultsCount!: number;
    tasksLogViewResultsCount!: number;
    showLoadingNotification = false;
    message = $localize`:|@@exportDialog.exportingData:Exporting data...`;

    constructor(
        public dialog: MatDialog,
        public dialogRef: MatDialogRef<ExportDialogComponent>,
        private store: Store<NetworkSpecificConfigurationState>,
        public translations: TranslationsService,
        public dateFormatService: DateFormatService,
        public exportService: ExportDataService,
        public exportTableDataService: ExportTableDataService,

        @Inject(MAT_DIALOG_DATA) data: any
    ) {
        this.data = data;
        this.exportedData = data;
    }

    ngOnInit() {
        this.headerItems = this.convertForCheckbox(this.data.header);
        this.includePageRange = this.data.includePageRange;
        this.includeTimeRange = this.data.includeTimeRange;
        this.timeRangeInput = this.data.timeRangeInput;
        this.meteringPointsResultsCount = this.data.meteringPointsResultsCount;

        // to set the date range in export dialog
        if (this.timeRangeInput && this.timeRangeInput.from && this.timeRangeInput.until) {
            this.minDate = moment(this.timeRangeInput.from).toDate();
            this.maxDate = moment(this.timeRangeInput.until).toDate();
        }

        this.viewName = this.data.fileName;

        this.havingBinaryConvertedData = this.data.havingBinaryConvertedData ? this.data.havingBinaryConvertedData : false;

        // To get the total count of records for MP search result
        this.store
            .select(XSFSearchSelectors.getResultElementsCount)
            .subscribe((data) => {
                this.meteringPointsResultsCount = data;
            })
            .unsubscribe();
        // To get the total count of records for tasklog view result
        this.store
            .select(getResultElementsCount)
            .subscribe((data) => {
                this.tasksLogViewResultsCount = data;
            })
            .unsubscribe();

        // setting totalpage count other than mp & takslog
        if (this.data.results.length > 0 && (this.data.fileName.match("TaskLog") === null)
            && (this.data.fileName.match("metering_points") === null)) {
            for (let i = 0; i < this.data.results.length; i = i + this.maxRowInPage) {
                this.totalPages++;
            }
        } else if ((this.data.fileName.match("TaskLog") !== null)) { // setting totalpage count for task log view
            this.totalPages = Math.ceil(this.tasksLogViewResultsCount / this.maxRowInPage);
        } else { // setting totalpage count for MP search results
            this.totalPages = Math.ceil(this.meteringPointsResultsCount / this.maxRowInPage);
        }

        this.networkSpecificData = this.store.select(NetworkSpecificConfigSelectors.getNetworkSpecificConfigurations).subscribe((data) => {
            for (const networkData of Object.values(data)) {
                if (networkData.identifier === "AIMUIExportTableLimit" && networkData.value) {
                    this.maxRowLimit = Number(networkData.value);
                }
            }
        });
        this.infoMessageForAllData = this.showCustomInfoMessage(this.data.results.length);
        this.infoMessageForCustomData = this.showCustomInfoMessage(0);
        // tslint:disable-next-line: max-line-length
        this.warningMsg = $localize`:|@@exportDialog.graphs.maximumExceeded:Maximum number of rows exceeded, the export will have only # rows`;
        this.warningMsg = this.warningMsg.replace("#", this.maxRowLimit.toString());

        if (this.includeTimeRange) {
            this.onTimePeriodChanged(this.timeRangeInput);
        }
        if (this.meteringPointsResultsCount && this.data.results.length === 0) {
            this.infoMessageForAllData = this.showCustomInfoMessage(this.meteringPointsResultsCount);
            this.infoMessageForCustomData = this.showCustomInfoMessage(0);
        }
        if (this.tasksLogViewResultsCount && this.data.results.length === 0) {
            this.infoMessageForAllData = this.showCustomInfoMessage(this.tasksLogViewResultsCount);
            this.infoMessageForCustomData = this.showCustomInfoMessage(0);
        }
        this.rangeDisable = true;
    }

    // convertForCheckbox() helps to convert array of object to accessable checkbox
    convertForCheckbox(actualHeader: any) {
        const keys = Object.keys(actualHeader);
        const values = Object.values(actualHeader);
        const checkBoxArray: any[] = [];
        for (let i = 0; i < keys.length; i++) {
            const obj = {
                fieldName: keys[i],
                displayName: values[i],
                exportColumn: true
            };
            checkBoxArray.push(obj);
        }
        return checkBoxArray;
    }

    exportData() {
        if (this.viewName === "metering_points") {
            this.exportDataForMeteringPoint();
        } else {
            this.exportDataForOthers();
        }

        // currently export data for tasks log disabled
        // else if ((this.data.fileName.match("TaskLog") !== null)) {
        //     this.exportDataForTasksLog();
        // }
    }

    /* Export data method to export MP search result*/
    exportDataForMeteringPoint() {
        this.showLoadingNotification = true;
        this.disableExport = true;
        const customdata: any[] = [];

        let exportOption: ExportDataOptions;
        exportOption = {
            columns: this.headerItems,
            selectedFileType: this.fileType,
            selectedDelimiter: this.delimiter,
            selectedRange: this.rangeValue,
            fileName: this.data.fileName,
            havingBinaryConvertedData: this.havingBinaryConvertedData
        };

        const rangeValues: any = this.exportService.convertPagesToRecords(this.rangeValue);

        this.store.dispatch(exportDataAction.ExportMeteringPointSearchResult({ range: this.pageOption === "range" ? rangeValues : "" }));

        this.store.select(MeteringPointsSelectors.getMeteringPointExportData).subscribe((dataLists) => {
            if (this.showLoadingNotification) {
                const exportData: any[] = cloneDeep(dataLists);
                exportData.forEach((item) => {
                    item.meteringPointStates = map(item.meteringPointStates, "identifier").join(", ");
                });
                const exportDataResults = this.exportTableDataService.getMeteringPointResults(exportData);
                if (exportDataResults && exportDataResults.length > 0) {
                    this.showLoadingNotification = false;
                    for (let j = 0; j < exportDataResults.length; j++) {
                        if (j < this.maxRowLimit) {
                            customdata[j] = exportDataResults[j];
                        }
                    }
                    this.store.dispatch(exportDataAction.ExportData({ columnOptions: exportOption, data: customdata }));
                    this.onClickCancel();
                }
            }
        });
    }

    /* Export data method to export tasks log result*/
    exportDataForTasksLog() {
        this.showLoadingNotification = true;
        this.disableExport = true;
        const customdata: any[] = [];

        let exportOption: ExportDataOptions;
        exportOption = {
            columns: this.headerItems,
            selectedFileType: this.fileType,
            selectedDelimiter: this.delimiter,
            selectedRange: this.rangeValue,
            fileName: this.data.fileName,
            havingBinaryConvertedData: this.havingBinaryConvertedData
        };

        const rangeValues: any = this.exportService.convertPagesToRecords(this.rangeValue);
        this.store.dispatch(exportTasksLogAction.ExportTasksLogView({
            range: this.pageOption === "range" ?
                rangeValues : "", rangeSize: this.totalExportRow
        }));

        this.store.select(getTasksLogResultExportData).subscribe((dataLists) => {
            if (this.showLoadingNotification) {
                const exportData: any[] = cloneDeep(dataLists);
                const exportDataResults = this.exportTableDataService.getTasksResults(exportData);
                if (exportDataResults && exportDataResults.length > 0) {
                    this.showLoadingNotification = false;
                    for (let j = 0; j < exportDataResults.length; j++) {
                        if (j < this.maxRowLimit) {
                            customdata[j] = exportDataResults[j];
                        }
                    }
                    this.store.dispatch(exportDataAction.ExportData({ columnOptions: exportOption, data: customdata }));
                    this.onClickCancel();
                }
            }
        });
    }

    /* Export data method to export the other table results*/
    exportDataForOthers() {
        const data = this.data.results;
        let customdata = [];
        let count = 0;
        const datalength = this.data.results.length;
        if (this.pageOption !== "all" && this.rangeValue !== "") {
            const pageRange = this.rangeValue.split(",");
            pageRange.forEach((range) => {
                const pages = range.split("-");
                const start = (Number(pages[0]) - 1) * this.maxRowInPage;
                let end;

                if (pages[1] === undefined) {
                    end = start + this.maxRowInPage;
                } else {
                    end = Number(pages[1]) * this.maxRowInPage;
                }
                if (end > datalength) {
                    end = datalength;
                }
                for (let j = start; j < end; j++) {
                    if (count !== this.maxRowLimit) {
                        customdata[count] = data[j];
                        count++;
                    }
                }
            });
            count = 0;
        } else if (this.pageOption === "all" && !this.includeTimeRange) {
            const dataRecords = this.data.results;

            for (let j = 0; j < this.data.results.length; j++) {
                if (j < this.maxRowLimit) {
                    customdata[j] = dataRecords[j];
                }
            }
        } else if (this.includeTimeRange) {
            const dataRecords = this.selectedDataBetweenTimeRange;

            for (let j = 0; j < this.data.results.length; j++) {
                if (j < this.maxRowLimit) {
                    if (dataRecords[j]) {
                        customdata[j] = dataRecords[j];
                    }
                }
            }
        } else {
            customdata = this.data.results;
        }
        let exportOption: ExportDataOptions;
        exportOption = {
            columns: this.headerItems,
            selectedFileType: this.fileType,
            selectedDelimiter: this.delimiter,
            selectedRange: this.rangeValue,
            fileName: this.data.fileName,
            havingBinaryConvertedData: this.havingBinaryConvertedData
        };
        this.store.dispatch(exportDataAction.ExportData({ columnOptions: exportOption, data: customdata }));

        this.onClickCancel();
    }

    onClickCancel() {
        if (this.viewName === "metering_points") {
            this.dialog.closeAll();
        } else {
            this.dialogRef.close();
        }
    }

    validationCheck() {
        this.disableExportOnUnselectAll = this.headerItems.every((item) => item.exportColumn === false);
    }

    radioButtonChange(event: MatRadioChange) {
        if (event.value === "range" && this.rangeValue === "") {
            this.disableExport = true;
            this.radioButtonType = false;
        } else {
            this.rangeValue = "";
            this.disableExport = false;
            this.invalidRange = false;
            this.radioButtonType = true;
            this.infoMessageForCustomData = this.showCustomInfoMessage(0);
        }
    }

    /** Custom page range validation and info/error messages */
    customPageRangeValidation() {
        this.invalidRange = false;
        this.invRangeError = "";

        const isRangeValid = this.exportService.customRangeValidator(this.rangeValue);
        const endPageNumberPattern = new RegExp("\\d+(?=\\D*$)");
        this.disableExport = !isRangeValid;
        /* Custom range input validation START */
        if (!isRangeValid && this.rangeValue) {
            this.invalidRange = true;
            this.invRangeError = $localize`:|@@exportDialog.exportRangeInvalidCharacter:Invalid characters, use e.g. 1-3, 5, 7-10`;
        }

        if (endPageNumberPattern.exec(this.rangeValue) && Number(endPageNumberPattern.exec(this.rangeValue)) > this.totalPages) {
            this.invalidRange = true;
            this.disableExport = true;
            this.invRangeError = $localize`:|@@exportDialog.exportRangeInvalidSelection:Invalid selection, only # pages exist`;
            this.invRangeError = this.invRangeError.replace("#", this.totalPages.toString());
        }
        if (this.rangeValue === "") {
            this.disableExport = true;
        }
        /* Custom range input validation END */

        /* Total no of page selected START */
        this.totalSelectedPages = 0;
        let totalNumberoFPages = 0;
        this.selectedPageNo = [];
        const recordsLength = this.totalPages * this.maxRowLimit;
        if (!this.disableExport) {
            const pageRange = this.rangeValue.split(",").map((pagesNum) => pagesNum.trim());
            pageRange.forEach((range) => {
                const pages = range.split("-");
                if (pages[1] === undefined) {
                    this.totalSelectedPages = totalNumberoFPages + 1;
                } else {
                    this.totalSelectedPages = totalNumberoFPages + (Number(pages[1]) - Number(pages[0]));
                    this.totalSelectedPages = this.totalSelectedPages + 1;
                }
                if (Number(pages[0]) === 0) {
                    this.totalSelectedPages = 0;
                }
                totalNumberoFPages = this.totalSelectedPages;
                let i = 0;
                pages.forEach((pageNo) => {
                    this.selectedPageNo.push(Number(pageNo));
                    i++;
                });

                if (i % 2 !== 0) {
                    this.selectedPageNo.push(",");
                }
            });

            for (let i = 0; i < this.selectedPageNo.length; i = i + 2) {
                let startPage = this.selectedPageNo[i] * this.maxRowLimit;

                const endPage = this.selectedPageNo[i + 1] * this.maxRowLimit;
                if (startPage === this.maxRowLimit) {
                    startPage = 1;
                }
                if (startPage < recordsLength || endPage < recordsLength) {
                    this.invalidRange = false;
                    this.invRangeError = "";
                    this.disableExport = false;
                }
            }
            if (this.totalSelectedPages < 0) {
                this.totalSelectedPages = 0;
            }
            if (this.invalidRange) {
                this.totalSelectedPages = 0;
            }

            if (this.selectedPageNo.includes(this.totalPages)) {
                if ((this.meteringPointsResultsCount > 0 && this.data.results.length === 0) || undefined) {
                    this.infoMessageForCustomData = this.showCustomInfoMessage(
                        this.totalSelectedPages * this.maxRowInPage -
                        (this.maxRowInPage - (this.meteringPointsResultsCount % this.maxRowInPage))
                    );
                } else if ((this.tasksLogViewResultsCount > 0 && this.data.results.length === 0) || undefined) {
                    this.infoMessageForCustomData = this.showCustomInfoMessage(
                        this.totalSelectedPages * this.maxRowInPage -
                        (this.maxRowInPage - (this.tasksLogViewResultsCount % this.maxRowInPage))
                    );
                } else if (this.data.results.length > 0) {
                    this.infoMessageForCustomData = this.showCustomInfoMessage(
                        this.totalSelectedPages * this.maxRowInPage - (this.maxRowInPage - (this.data.results.length % this.maxRowInPage))
                    );
                }
            } else {
                this.infoMessageForCustomData = this.showCustomInfoMessage(this.totalSelectedPages * this.maxRowInPage);
            }
        }
        if (this.rangeValue === "") {
            this.infoMessageForCustomData = this.showCustomInfoMessage(this.totalSelectedPages * this.maxRowInPage);
        }
    }

    /** To display custom info messages by passing the number of records */
    showCustomInfoMessage(value: number) {
        this.totalExportRow = value;
        return $localize`:|@@exportDialog.exportWillHave:The export will have # rows`.replace("#", value.toString());
    }

    /** Data to be exported when date range changes */
    onTimePeriodChanged(timePeriod: { from: number; until: number }) {
        if (timePeriod.from && timePeriod.until) {
            if (this.viewName.includes("adhoc_profile_values")) {
                const startDate = this.dateFormatService.toStartOfDay(timePeriod.from);
                const endDate = this.dateFormatService.toEndOfDay(timePeriod.until);

                this.selectedDataBetweenTimeRange = this.data.results.filter((ele: any) => {
                    return startDate <= ele.valueStartTime && ele.valueStartTime <= endDate;
                });
            } else {
                const startDate = this.dateFormatService.toStartOfDay(timePeriod.from);
                const endDate = this.dateFormatService.toEndOfDay(moment(timePeriod.until).add(1, "seconds").valueOf());

                this.selectedDataBetweenTimeRange = this.data.results.filter((ele: any) => {
                    return startDate <= ele.valueStartFullDate && endDate >= ele.valueStartFullDate;
                });
            }

            this.selectedDataBetweenTimeRange = this.convertValueTimestampsForDisplay(this.selectedDataBetweenTimeRange);
            this.infoMessageForCustomData = this.showCustomInfoMessage(this.selectedDataBetweenTimeRange.length);
            if (this.selectedDataBetweenTimeRange.length === 0) {
                this.disableExport = true;
            } else {
                this.disableExport = false;
            }

            this.outOfRangeError = false;
        }
    }

    convertValueTimestampsForDisplay = (values: ValuesForTable[]) => {
        return values.map((value) => convertValuesForTableEpochsToDisplay(value, this.dateFormatService));
    };
}
