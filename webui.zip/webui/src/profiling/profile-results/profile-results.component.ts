import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';
import { TranslocoService } from '@ngneat/transloco';
import { EventBusService } from 'core/eventBusService';
import { SharedConstants as ProfilingConstants, SharedConstants } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { TreeNode } from 'primeng/api';
import { Subscription } from 'rxjs';
import { ResultHeaderModel } from './header.model';
import { ProfileMetadataModel } from './profile-metadata.model';
import { ProfileResultsTableModel } from './profile-results-table.model';
import { ProfileResultsModel } from './profile-results.model';
import { ProfileResultsService } from './profile-results.service';
import { TreePath, Types } from './tree-path.model';
import { TreeTableModel } from './tree-table.model';

@Component({
  selector: 'discovery-profile-results',
  templateUrl: './profile-results.component.html',
  styleUrls: ['./profile-results.component.css']
})
export class ProfileResultsComponent implements OnInit {
  resultHeaderModel: ResultHeaderModel;
  treeData: TreeTableModel[] = [];
  schemaTree = [];
  selectedNode: TreeNode;
  node: TreeNode;
  treePath: TreePath;
  types: Types = new Types('', '', '');
  treeConfig: any;
  status: string;
  serviceSuccess: boolean;
  noRunIdAvailable: boolean = false;
  profileName: string;
  loading: boolean;
  profileMetadata: ProfileMetadataModel;
  historyResultSubscription: Subscription = {} as any;
  trendsSidebarSubscription: Subscription = {} as any;
  trendsSidebarVisible: boolean;
  trendsStat: string;
  routerUrl: string;
  isObserverDetailView: boolean = false;

  constructor(
    private profileResultsService: ProfileResultsService,
    public activatedRoute: ActivatedRoute,
    private toastrService: ToastrService,
    private translocoService: TranslocoService,
    public router: Router,
    private eventBusService: EventBusService
  ) {}

  ngOnInit(): void {
    if (this.router.url.includes('observer-detail')) {
      this.isObserverDetailView = true;
    }
    this.profileResultsService.profileId = this.activatedRoute.snapshot.paramMap.get('profileId');
    this.profileName = this.activatedRoute.snapshot.paramMap.get('profileName');
    this.queryParamChangeSubscription();
    this.historyResultSubscription = this.eventBusService?.on<any>('HistoryResultsNavigation')?.subscribe((data) => {
      const params = {
        runId: data.runId,
        tableName: this.treePath?.tableName.name
      };
      if (this.treePath?.columnView) {
        params['columnName'] = this.treePath.columnName.name;
      }
      this.treePath = null;
      this.router.navigate([], {
        relativeTo: this.activatedRoute,
        queryParams: params
      });
    });

    this.trendsSidebarSubscription = this.eventBusService?.on<any>('TrendsSidebarToggle')?.subscribe((data) => {
      this.trendsSidebarVisible = data.flag;
      if (data.stat) {
        this.trendsStat = data.stat;
      }
    });
  }
  /**
   * this function is used to watch query params in route
   * fetching runId and if profile result is showing from observer detail view flow and runId is not available
   * we need to show default screen as waiting for profile to run
   */

  queryParamChangeSubscription() {
    this.activatedRoute.queryParamMap.subscribe((query: ParamMap) => {
      this.profileResultsService.runId = query.get('runId');
      if (this.isObserverDetailView && !this.profileResultsService.runId) {
        this.serviceSuccess = true;
        this.noRunIdAvailable = true;
      } else {
        this.serviceSuccess = false;
        this.noRunIdAvailable = false;
        if (!this.treePath) {
          this.getProfileInfo();
        } else {
          this.fetchUrlQueryString();
        }
      }
    });
  }

  nodeSelect(event) {
    this.treePath = null;
    this.types = null;
    this.selectedNode = event.node;
    this.treePath = new TreePath();
    this.treePath.treeData = this.selectedNode as TreeTableModel;
    this.treePath.modelView = false;
    this.treePath.tableView = false;
    this.treePath.columnView = false;
    this.treePath.profileID = this.profileResultsService.profileId;
    this.treePath.runId = this.profileResultsService.runId;
    this.treePath.profileName = this.profileName;
    this.treePath.tableView = this.selectedNode.parent === undefined;
    this.treePath.columnView =
      this.selectedNode.type && this.selectedNode.type !== 'Physical' && this.selectedNode.type !== 'Logical';

    if (this.treePath.columnView) {
      this.types = new Types(this.selectedNode.label, this.selectedNode.type, '');
      this.treePath.columnName = this.types;
      this.treePath.tableName = new Types(this.selectedNode.parent.label, '', '');
    } else {
      this.types = new Types(this.selectedNode.label, undefined, this.selectedNode.label);
      this.treePath.tableName = this.types;
      this.treePath.columnName = undefined;
    }
    this.createURLforTree();
  }

  private getProfileInfo(): void {
    this.loading = true;
    this.profileResultsService
      .getProfileStatsById(this.profileResultsService.profileId, this.profileResultsService.runId)
      .subscribe(
        (profileResultsModels: ProfileResultsModel) => {
          this.loading = false;
          this.serviceSuccess = true;
          this.status = profileResultsModels.status;
          this.profileName = profileResultsModels.name;
          this.renderResultsHeader(profileResultsModels);
          if (
            this.status === ProfilingConstants.SERVICE_RESPONSE.SUCCESS ||
            this.status === ProfilingConstants.STATUS.ERROR ||
            this.status === ProfilingConstants.STATUS.CANCELLED
          ) {
            this.treeData = this.formatResultsTreeData(profileResultsModels.tables);
            this.node = this.treeData[0];
            this.treePath = new TreePath();
            this.profileMetadata = new ProfileMetadataModel();
            const connectionType = profileResultsModels.dataConnectionType?.toLowerCase() || '';
            this.profileMetadata.source = connectionType;
            if (
              connectionType === SharedConstants.connectionConfigureType.SNOWFLAKE ||
              connectionType === SharedConstants.connectionConfigureType.DATABRICKS
            ) {
              this.profileMetadata.sourceType = 'DBMS';
            } else {
              this.profileMetadata.sourceType = '';
            }
            this.profileMetadata.host = profileResultsModels.host;
            this.profileMetadata.db = profileResultsModels.databaseName;
            this.profileMetadata.schema = profileResultsModels.schema;
            this.treePath.profileID = this.profileResultsService.profileId;
            this.treePath.runId = this.profileResultsService.runId;
            this.treePath.profileName = profileResultsModels.name;
            this.types = new Types(this.node.label, '', '');
            this.treePath.modelName = this.node.label;
            this.treeConfig = this.treeData[0];
            this.treePath.treeData = this.treeData[0];
            this.treePath.columnView = false;
            this.treePath.tableView = true;
            this.treePath.profileName = profileResultsModels.name;
            this.treePath.tableName = this.types;
            this.treePath.columnName = null;
            this.fetchUrlQueryString();
          }
        },
        (httpErrorResponse: HttpErrorResponse) => {
          if (httpErrorResponse.status === 404 || httpErrorResponse.status === 400) {
            this.toastrService.error(this.translocoService.translate('discoveryProfiling.listing.profileNotFound'));
          } else {
            if (httpErrorResponse?.error?.message) {
              this.toastrService.error(httpErrorResponse.error.message);
            }
          }
        }
      );
  }

  private formatResultsTreeData(tables: ProfileResultsTableModel[]): TreeTableModel[] {
    this.schemaTree = [];
    tables = tables.sort((a, b) => (a.name > b.name ? 1 : -1));
    if (tables) {
      for (const table of tables) {
        const tableNode: TreeNode = new TreeTableModel();
        tableNode.label = table.name;
        tableNode.data = table;
        tableNode.expanded = true;
        tableNode.key = table.name + Math.random();
        tableNode.icon = 'png-icon-sm png-table';
        if (table.status === ProfilingConstants.STATUS.ERROR) {
          tableNode.styleClass = 'err-icon';
        }
        tableNode.leaf = false;
        tableNode.children = [];
        if (table.columns) {
          table.columns = table.columns.sort((a, b) => (a.name > b.name ? 1 : -1));
          for (const column of table.columns) {
            const columnNode: TreeNode = new TreeTableModel();
            columnNode.label = column.name;
            columnNode.data = column;
            columnNode.type = column.type;
            columnNode.key = column.name + Math.random();
            columnNode.icon = 'png-icon-sm png-tablecols';
            columnNode.styleClass = 'custom-column-class';
            if (column.status === ProfilingConstants.STATUS.ERROR) {
              columnNode.styleClass = `${columnNode.styleClass} err-icon`;
            }
            columnNode.leaf = true;
            columnNode.children = [];
            tableNode.children.push(columnNode);
          }
        }
        if (tableNode.children.length > 0) {
          this.schemaTree.push(tableNode);
        }
      }
    }
    return this.schemaTree;
  }

  private renderResultsHeader(profileResultsModels: ProfileResultsModel): void {
    this.resultHeaderModel = new ResultHeaderModel();
    this.resultHeaderModel.name = profileResultsModels.name;
    this.resultHeaderModel.description = profileResultsModels.description;
    this.resultHeaderModel.dataConnectionName = profileResultsModels.dataConnectionName;
    this.resultHeaderModel.dataConnectionType = profileResultsModels.dataConnectionType;
    this.resultHeaderModel.runByUser = profileResultsModels.runByUser;
    this.resultHeaderModel.duration = profileResultsModels.duration;
    this.resultHeaderModel.rowsProcessed = profileResultsModels.rowsProcessed;
    this.resultHeaderModel.lastRun = profileResultsModels.lastRun;
    this.resultHeaderModel.account = profileResultsModels.account;
    this.resultHeaderModel.databaseName = profileResultsModels.databaseName;
    this.resultHeaderModel.schema = profileResultsModels.schema;
    this.resultHeaderModel.warehouse = profileResultsModels.warehouse;
  }

  private fetchUrlQueryString(): void {
    const paramTableName = this.activatedRoute.snapshot.queryParamMap.get('tableName');
    const paramColumnName = this.activatedRoute.snapshot.queryParamMap.get('columnName');
    if (paramTableName && paramColumnName && this.getSelectedColumnNode(paramTableName, paramColumnName)) {
      this.node = this.getSelectedColumnNode(paramTableName, paramColumnName);
      this.updateTreePath(this.node, true, paramTableName, paramColumnName);
    } else if (paramTableName && this.getTableNode(paramTableName)) {
      this.node = this.getTableNode(paramTableName);
      this.updateTreePath(this.node, false, paramTableName, '');
    } else {
      // default view is table view
      this.node = this.treeData[0];
      this.updateTreePath(this.node, false, paramTableName, '');
    }
  }

  private updateTreePath(node: TreeNode, columnView: boolean, tableName: string, columnName: string): void {
    this.treePath = new TreePath();
    this.treePath.tableView = !columnView;
    this.treePath.columnView = columnView;
    this.treePath.treeData = node as TreeTableModel;
    if (columnView) {
      this.types = new Types(node.label, this.node.type, '');
      this.treePath.columnName = this.types;
      this.treePath.tableName = new Types(tableName, '', '');
    } else {
      this.types = new Types(node.label, undefined, node.label);
      this.treePath.tableName = this.types;
      this.treePath.columnName = undefined;
    }
    this.treePath.profileID = this.profileResultsService.profileId;
    this.treePath.runId = this.profileResultsService.runId;
    this.treePath.profileName = this.profileName;
  }

  private getSelectedColumnNode(tableName: string, columnName: string): TreeNode {
    let selection: TreeNode;
    for (const table of this.treeData) {
      if (!table.parent) {
        if (table.data.name === tableName) {
          for (const column of table.children) {
            if (column.label === columnName) {
              selection = column;
              break;
            }
          }
        }
      }
    }
    return selection;
  }

  private getTableNode(tableName: string): TreeNode {
    let selection: TreeNode;
    for (const table of this.treeData) {
      if (table.data.name === tableName) {
        selection = table;
        break;
      }
    }
    return selection;
  }

  private createURLforTree(): void {
    if (this.treePath.columnView) {
      this.router.navigate([], {
        relativeTo: this.activatedRoute,
        queryParams: {
          runId: this.treePath.runId,
          tableName: this.treePath.tableName.name,
          columnName: this.treePath.columnName.name
        }
      });
    } else if (this.treePath.tableView) {
      this.router.navigate([], {
        relativeTo: this.activatedRoute,
        queryParams: { runId: this.treePath.runId, tableName: this.treePath.tableName.name }
      });
    }
  }
}
