(function() {
    'use strict';
    widget.factory('ajaxFactory', ['$http', '$q', ajaxFactory]);

    function ajaxFactory($http, $q) {
        var data = [];
        var editData;
        var obj = {};
        var methods = {
            getData: getData,
            setData: setData,
            deleteData: deleteData,
            setEditDataToSave: setEditDataToSave,
            getEditDataToSave: getEditDataToSave,
            deleteEditDataToSave: deleteEditDataToSave,
            setting: setting,
            getting: getting
        }
        return methods;
        /* Implimentations*/
        function getData() {
            return data;
            console.log(data);
            alert("ddddddddd");
        }

        function setting(da) {
            obj = da;
            console.log(obj);
        }

        function getting() {
            return obj;
            console.log(obj);
        }



        function setData(item) {
            data.push(item);
            console.log(item)
        }

        function deleteData(index) {
            data.splice(index, 1);
            return data;
        }

        function setEditDataToSave(item) {
            editData = item;
        }
        function getEditDataToSave() {
            return editData;
        }
        function deleteEditDataToSave() {
            editData =  undefined;
            return editData;
        }
    }
})();