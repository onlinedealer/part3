import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { MetadataApiService } from './metadata-api.service';

describe('MetadataApiService', () => {
  let service: MetadataApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(MetadataApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create a kafka topic', () => {
    const expectedRequestMethod = 'POST';
    const expectedEndpointUrl = '/api/v1/metadata/1/createtopic';
    let returnedData;
    service.createTopic('1', 'test').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe('POST');
    expect(req.request.body).toEqual({ name: 'test' });
    req.flush(null);
    httpMock.verify();
    expect(returnedData).toBeNull();
  });

  it('should return schema information', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/api/v1/metadata/schemas?connection_id=aaa&project_id=bbb';
    let returnedData;
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getSchemas('aaa', 'bbb').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return subject information', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/api/v1/metadata/subjects?connection_id=aaa&project_id=bbb';
    let returnedData;
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getSubjects('aaa', 'bbb').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return table information', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/api/v1/metadata/tables?connection_id=aaa&project_id=bbb&schema_name=test';
    let returnedData;
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getTables('aaa', 'bbb', 'test').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return column information', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/api/v1/metadata/columns?connection_id=aaa&project_id=bbb&schema_name=test&table_name=table1';
    let returnedData;
    const mockApiResponse = [{ name: 'A' }, { name: 'B' }];
    service.getColumns('aaa', 'bbb', 'test', 'table1').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return the public key', () => {
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/api/v1/metadata/publickey?server_name=myServer';
    let returnedData;
    const mockApiResponse = 'myPublicKey';
    service.getPublicKey('myServer').subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData).toBe('myPublicKey');
  });
});
