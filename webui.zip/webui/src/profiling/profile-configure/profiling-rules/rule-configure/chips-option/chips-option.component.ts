import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ProfileRuleOptionModel } from 'profiling/profile-rule-option.model';
import { TranslocoService } from '@ngneat/transloco';

@Component({
  selector: 'discovery-rule-configure-option-type-chips',
  templateUrl: './chips-option.component.html',
  styleUrls: ['./chips-option.component.css']
})
export class ChipsOptionComponent {
  @Input() ruleConfigOption: ProfileRuleOptionModel;

  @Input()
  set showRuleSettingsSideBar(sideBarVisible: boolean) {
    this.errorMsg = '';
    if (sideBarVisible) {
      let editableListStr: string;
      if (this.ruleConfigOption.configuredOptionValue === undefined) {
        editableListStr = this.ruleConfigOption.defaultOptionValue;
      } else {
        editableListStr = this.ruleConfigOption.configuredOptionValue;
      }
      this.editableList = editableListStr.split('');
    }
  }

  @Input() configuredOptionValues: Map<string, any> = new Map<string, any>();
  @Output() configuredOptionValuesChange: EventEmitter<Map<string, any>> = new EventEmitter<Map<string, any>>();
  editableList: string[];
  errorMsg: string = '';

  constructor(private translocoService: TranslocoService) {}

  onAdd(event) {
    this.errorMsg = '';
    this.editableList.pop();

    if (event.value.trim().length > 1) {
      this.errorMsg = this.translocoService.translate(
        'discoveryProfiling.profilingRules.configuration.singleCharAllowedValidationMsg'
      );
    } else if (this.editableList.includes(event.value.trim())) {
      this.errorMsg = this.translocoService.translate(
        'discoveryProfiling.profilingRules.configuration.duplicateCharValidationMsg'
      );
    } else {
      this.editableList.push(event.value.trim());
      this.emitConfiguredValues();
    }
  }

  emitConfiguredValues() {
    this.configuredOptionValues.set(this.ruleConfigOption.id, this.editableList.join(''));
    this.configuredOptionValuesChange.emit(this.configuredOptionValues);
  }

  reset() {
    this.errorMsg = '';
    this.editableList = this.ruleConfigOption.defaultOptionValue.split('');
    this.emitConfiguredValues();
  }
}
