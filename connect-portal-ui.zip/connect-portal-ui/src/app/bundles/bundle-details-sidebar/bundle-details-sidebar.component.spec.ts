import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';
import { Connection } from 'src/app/connections/shared/connection';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { Bundle, LogMetadataList } from '../shared/bundles';
import { BundleDetailsFormComponent } from './bundle-details-form/bundle-details-form.component';

import { BundleDetailsSidebarComponent } from './bundle-details-sidebar.component';

describe('BundleDetailsSidebarComponent', () => {
  let component: BundleDetailsSidebarComponent;
  let fixture: ComponentFixture<BundleDetailsSidebarComponent>;

  @Component({
    selector: 'p-connect-bundle-details-form',
    template: '',
    providers: [
      {
        provide: BundleDetailsFormComponent,
        useClass: MockBundleDetailsFormComponent
      }
    ]
  })
  class MockBundleDetailsFormComponent {
    getConnectionAndLogReaderName(sourceConnectionsInProject: Connection[], project: Project) {}
    getFilesInTheBundle(logsInformation: LogMetadataList) {}
    checkIfIBMIConnectionUsedInProject(sourceConnectionsInProject: Connection[], project: Project) {}
    projectName = '';
    runtimeEngineName = '';
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [BundleDetailsSidebarComponent, MockSidebarComponent, MockBundleDetailsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(BundleDetailsSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the sidebar', () => {
    spyOn(component.sidebarComponent, 'open');
    component.open(
      { bundleName: 'test', logMetadataList: { serverMetadataList: [{ server: { name: 'test' } }] } } as Bundle,
      [{} as Connection],
      {} as Project
    );
    expect(component.bundleDetails.bundleName).toEqual('test');
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should get name for the instances of log reader, runtime engine and data connection used in project', () => {
    spyOn(component.bundleDetailsFormComponent, 'checkIfIBMIConnectionUsedInProject');
    spyOn(component.bundleDetailsFormComponent, 'getFilesInTheBundle');
    component.open(
      { bundleName: 'test', logMetadataList: { serverMetadataList: [{ server: { name: 'test' } }] } } as Bundle,
      [{} as Connection],
      { name: 'Default_Project' } as Project
    );
    expect(component.bundleDetailsFormComponent.getFilesInTheBundle).toHaveBeenCalled();
    expect(component.bundleDetailsFormComponent.projectName).toEqual('Default_Project');
    expect(component.bundleDetailsFormComponent.runtimeEngineName).toEqual('test');
    expect(component.bundleDetailsFormComponent.checkIfIBMIConnectionUsedInProject).toHaveBeenCalled();
  });

  it('should close sidebar', () => {
    spyOn(component.sidebarComponent, 'close');
    component.closeButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });
});
