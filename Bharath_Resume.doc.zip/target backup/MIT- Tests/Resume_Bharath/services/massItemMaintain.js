import axios from 'axios'
import config from '../config/apiConfig'
import { getKey } from 'react-oauth-openid'

export function getService (path, memberOf, userId) {
  const token = getKey('id_token')
  return axios.get(path, {
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': memberOf,
      'X-TGT-LANID': userId,
    },
  })
    .then(resp => {
      return resp.data
    })
}

export function postService (input, serviceName, memberOf, userId) {
  const token = getKey('id_token')
  const postUrl = config.massItemMaintain.commonPath + serviceName
  return axios.post(postUrl, input, {
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': memberOf,
      'X-TGT-LANID': userId,
    },
  })
    .then(resp => {
      return resp.data
    })
}

export function getItemsService (input, memberOf, userId) {
  const token = getKey('id_token')
  return axios.get(config.massItemMaintain.getItems + input, {
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': memberOf,
      'X-TGT-LANID': userId,
    },
  })
    .then(resp => {
      return resp.data
    })
}

export function saveItemsService (input, memberOf, userId) {
  const token = getKey('id_token')
  return axios.post(config.massItemMaintain.saveItems, input, {
    headers: {
      'Authorization': 'Bearer ' + token,
      'X-TGT-MEMBEROF': memberOf,
      'X-TGT-LANID': userId,
    },
  })
    .then(resp => {
      return resp.data
    })
}
