import { browser, by, element } from 'protractor';

export class CVSClubPage {
  navigateToRegistration() {
    return browser.driver.get('http://localhost:4200/carepass/go');
  }

  getParagraphTextById(id) {
    return element(by.id(id)).getText();
  }
   getParagraphTextByClass(className) {
    return element(by.className(className)).getText();
  }

  getElementByClass(className){
    return element(by.className(className));
  }
  getElementById(id){
    return element(by.className(id));
  }
}