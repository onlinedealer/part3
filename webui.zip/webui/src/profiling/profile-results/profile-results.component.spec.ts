import { convertToParamMap } from '@angular/router';
import { Mocks, Spies } from 'discovery-test';
import { of } from 'rxjs';
import { ProfileResultsComponent } from './profile-results.component';
import { TreeTableModel } from './tree-table.model';

describe('ProfileResultsComponent', () => {
  let component: ProfileResultsComponent;

  beforeEach(async () => {
    Spies.init();
    component = new ProfileResultsComponent(
      Spies.ProfileResultsService,
      Spies.ActivatedRoute,
      Spies.ToastrService,
      Spies.TranslateService,
      Spies.Router,
      Spies.eventBusService
    );

    Spies.ActivatedRoute.queryParamMap = of(convertToParamMap({ runId: '86587c8768c68' }));
    Spies.ActivatedRoute.snapshot.queryParamMap = new Map<string, string>();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with getProfileStatsById api call', () => {
    Spies.Router.url = 'http://localhost:4200/data-profiling/edit/2c9c80877cb6daee017cb71851a00001';
    component.ngOnInit();
    Spies.ProfileResultsService.getProfileStatsById.and.returnValue(of(Mocks.MockProfileResults[1]));
    expect(component.status).toBeTruthy(true);
    expect(component.profileName).toBe('Test Profile');
  });

  it('should call nodeSelect on click event', () => {
    const event = {};
    event['node'] = new TreeTableModel();
    component.profileName = 'Dummy';
    component.nodeSelect(event);
    expect(component.treePath.profileName).toBe(component.profileName);
  });
});
