import { Router, Request, Response } from 'express'
import { CompaniesService } from '../services/companies.service'

export const companiesRouter = Router();
const companiesService = new CompaniesService();

companiesRouter.get('/', (req: Request, res: Response) => {
  companiesService.getCompanies().subscribe( (response: any[]) => res.json(response));
})
