export interface CustomProperty {
    valueId: number;
    propertyId: number;
    value: string;
    entityId: number;
    entryTime: number;
    userName: string;
    entityType: string;
    identifier: string;
    dataType: string;
    name?: string;
}

export interface CustomPropertyRequest {
    meteringPointId: number;
}

export interface CustomPropertyResponse {
    parameters: any;
    data: CustomProperty[];
}
