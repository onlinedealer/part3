import { Injectable, Injector } from "@angular/core";
import { Overlay, PositionStrategy } from "@angular/cdk/overlay";
import { ComponentPortal, PortalInjector } from "@angular/cdk/portal";
import { MeteringpointsSearchfieldMenuRef } from "./menu.ref";
import { MeteringpointsSearchfieldMenuComponent, MeteringpointsSearchfieldMenuData } from "./menu.component";

@Injectable({
    providedIn: "root"
})
export class MeteringpointsSearchfieldMenuService {
    constructor(private overlay: Overlay, private parentInjector: Injector) {}

    show(data: MeteringpointsSearchfieldMenuData, origin: HTMLElement): MeteringpointsSearchfieldMenuRef {
        const positionStrategy = this.getPositionStrategy(origin);
        const overlayRef = this.getOverlayRef(positionStrategy);
        const meteringpointsSearchfieldMenuRef = new MeteringpointsSearchfieldMenuRef(overlayRef);

        const injector = this.getInjector(data, meteringpointsSearchfieldMenuRef, this.parentInjector);
        overlayRef.attach(new ComponentPortal(MeteringpointsSearchfieldMenuComponent, null, injector));

        return meteringpointsSearchfieldMenuRef;
    }

    getPositionStrategy(originOfOverlay: HTMLElement) {
        return this.overlay
            .position()
            .flexibleConnectedTo(originOfOverlay)
            .withPositions([
                {
                    originX: "start",
                    originY: "bottom",
                    overlayX: "start",
                    overlayY: "top"
                }
            ])
            .withLockedPosition(false)
            .withPush(false);
    }

    getOverlayRef(positionStrategy: PositionStrategy) {
        return this.overlay.create({
            hasBackdrop: true,
            backdropClass: "no-visible-background",
            positionStrategy: positionStrategy
        });
    }

    getInjector(
        data: MeteringpointsSearchfieldMenuData,
        meteringpointsSearchfieldMenuRef: MeteringpointsSearchfieldMenuRef,
        parentInjector: Injector
    ) {
        const tokens = new WeakMap();

        tokens.set(MeteringpointsSearchfieldMenuData, data);
        tokens.set(MeteringpointsSearchfieldMenuRef, meteringpointsSearchfieldMenuRef);

        return new PortalInjector(parentInjector, tokens);
    }
}
