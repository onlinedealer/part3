import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { LogReader } from './logreader';
import { environment } from '../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class LogReadersApiService {
  private readonly baseUrl: any;

  constructor(private readonly httpClient: HttpClient) {
    this.baseUrl = `${environment.connectApiBaseURL}/logreaders`;
  }

  createLogReader(connectionId: string, projectId: string, logReader: LogReader, headers?: HttpHeaders): Observable<LogReader> {
    const params = {
      projectId,
      dataConnectionId: connectionId
    };

    return this.httpClient.post(`${this.baseUrl}/create`, logReader, { params, headers });
  }

  getLogReader(connectionId: string, projectId: string, logReaderName: string, headers?: HttpHeaders): Observable<LogReader> {
    const params = {
      logReaderName
    };

    return this.httpClient.get(`${this.baseUrl}/${projectId}/${connectionId}`, { params, headers });
  }

  updateLogReader(connectionId: string, projectId: string, logReader: LogReader, headers?: HttpHeaders): Observable<LogReader> {
    const params = {
      logReaderName: logReader.name
    };

    return this.httpClient.put(`${this.baseUrl}/${projectId}/${connectionId}/update`, logReader, { params, headers });
  }

  renameLogReader(
    connectionId: string,
    projectId: string,
    logReaderName: string,
    newLogReaderName: string,
    headers?: HttpHeaders
  ): Observable<LogReader> {
    const params = {
      logReaderName
    };

    return this.httpClient.put(`${this.baseUrl}/${projectId}/${connectionId}/rename`, newLogReaderName, { params, headers });
  }

  deleteLogReader(connectionId: string, projectId: string, logReaderName: string, headers?: HttpHeaders): Observable<any> {
    const params = {
      logReaderName
    };

    return this.httpClient.delete(`${this.baseUrl}/${projectId}/${connectionId}/delete`, { params, headers });
  }

  getLogReaders(connectionId: string, projectId: string, headers?: HttpHeaders): Observable<LogReader[]> {
    const params = {
      projectId,
      dataConnectionId: connectionId
    };

    return this.httpClient.get(`${this.baseUrl}`, { params, headers }).pipe(
      map((response: any) => {
        const content = response.content || response;
        return content.map((logReader: LogReader) => {
          return logReader;
        });
      })
    );
  }

  getDataFlows(connectionId: string, projectId: string, logReaderName: string, headers?: HttpHeaders): Observable<any> {
    const params = {
      logReaderName
    };

    return this.httpClient.get(`${this.baseUrl}/${projectId}/${connectionId}/usage`, { params, headers });
  }
}
