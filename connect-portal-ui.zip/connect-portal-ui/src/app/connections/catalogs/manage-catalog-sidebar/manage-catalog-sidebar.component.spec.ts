import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MockSidebarComponent } from '../../../shared/components/sidebar/mock-sidebar.component.spec';
import { ManageCatalogSidebarComponent } from './manage-catalog-sidebar.component';

describe('ManageCatalogSidebarComponent', () => {
  let component: ManageCatalogSidebarComponent;
  let fixture: ComponentFixture<ManageCatalogSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ManageCatalogSidebarComponent, MockSidebarComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageCatalogSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should close the sidebar when clicking on dissmiss', () => {
    component.toggleSidebarVisibility(false);
    expect(component.isVisible).toBe(false);
  });

  it('should handle service error from the manage catalog component', () => {
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage');
    component.onServiceError('error');
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should update the progress indicator for the sidebar', () => {
    component.onProcessingRequest(true);
    expect(component.sidebarComponent.isProcessingRequest).toBe(true);
  });

  it('should close sidebar if the connection type is KAFKA', () => {
    component.connection = { connectionType: 'KAFKA' };
    component.onActionCompleted();
    expect(component.isVisible).toBe(false);
  });
});
