import { DatePipe } from '@angular/common';
import { NgModule } from '@angular/core';
import { Router, UrlTree } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SharedModule } from 'discovery-shared';
import { DialogService } from 'primeng/dynamicdialog';
import { alertsLoader, observerLoader, profilngLoader, sharedLoader } from '../core/i18n-loaders';
import { ObserveFeatureFlagGuard } from '../shared/observer-feature-flag-guard';
import { ObserverConfigureComponent } from './observer-configure/observer-configure.component';
import { ObserverDetailsComponent } from './observer-configure/observer-details/observer-details.component';
import { ObserverRulesComponent } from './observer-configure/observer-rules/observer-rules.component';
import { DataDriftConfigureComponent } from './observer-configure/observer-rules/rules-configure/data-drift-configure/data-drift-configure.component';
import { RulesConfigureComponent } from './observer-configure/observer-rules/rules-configure/rules-configure.component';
import { SliderComponent } from './observer-configure/observer-rules/rules-configure/slider/slider.component';
import { VolumeConfigureComponent } from './observer-configure/observer-rules/rules-configure/volume-configure/volume-configure.component';
import { ObserverDetailViewComponent } from './observer-detail-view/observer-detail-view.component';
import { ObserverListingComponent } from './observer-listing/observer-listing.component';
import { ObserverRoutingModule } from './observer-routing.module';

@NgModule({
  declarations: [
    ObserverListingComponent,
    ObserverConfigureComponent,
    ObserverDetailsComponent,
    ObserverRulesComponent,
    SliderComponent,
    VolumeConfigureComponent,
    RulesConfigureComponent,
    DataDriftConfigureComponent,
    ObserverDetailViewComponent
  ],
  imports: [SharedModule, ObserverRoutingModule],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'discoveryObserver', loader: observerLoader },
        { scope: 'discoveryAlerts', loader: alertsLoader },
        { scope: 'discoveryProfiling', loader: profilngLoader },
        { scope: 'discoveryShared', loader: sharedLoader }
      ]
    },
    DatePipe,
    DialogService
  ]
})
export class ObserverModule {
  constructor(router: Router, guard: ObserveFeatureFlagGuard) {
    const result: boolean | UrlTree = guard.canActivate(undefined, undefined);
    if (result instanceof UrlTree) {
      router.navigateByUrl(result);
    }
  }
}
