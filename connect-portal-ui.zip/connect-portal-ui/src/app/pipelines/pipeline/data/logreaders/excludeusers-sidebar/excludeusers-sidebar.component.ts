import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { BaseComponent } from 'src/app/core/base.component';
import { SidebarButton } from 'src/app/shared/components/sidebar/sidebar-button';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { ExcludeusersFormComponent } from '../excludeusers-form/excludeusers-form.component';

@Component({
  selector: 'p-connect-excludeusers-sidebar',
  templateUrl: './excludeusers-sidebar.component.html'
})
export class ExcludeusersSidebarComponent extends BaseComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(ExcludeusersFormComponent) excludeUsersForm: ExcludeusersFormComponent;
  @Input() usersExcludedFromCapture: string[];
  @Output() usersExcludedFromCaptureChange = new EventEmitter();
  primaryButton: SidebarButton = {
    id: 'save',
    text: 'logreaders.EXCLUDE_USERS.BUTTONS.SAVE'
  };
  cancelButton: SidebarButton = {
    id: 'cancel',
    text: 'logreaders.EXCLUDE_USERS.BUTTONS.CANCEL'
  };
  secondaryButton: SidebarButton = {
    isHidden: true
  };
  currentUsersExcludedFromCapture: string[] = [];

  open(): void {
    this.currentUsersExcludedFromCapture = this.usersExcludedFromCapture;
    this.sidebarComponent.open();
  }

  cancelSidebarButtonClicked(): void {
    this.sidebarComponent.close();
  }

  primaryButtonClicked() {
    this.usersExcludedFromCaptureChange.emit(this.currentUsersExcludedFromCapture);
    this.sidebarComponent.close();
  }
}
