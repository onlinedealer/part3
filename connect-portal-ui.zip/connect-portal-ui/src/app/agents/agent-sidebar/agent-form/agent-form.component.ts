import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BaseComponent } from '../../../core/base.component';

@Component({
  selector: 'p-connect-agent-form',
  templateUrl: './agent-form.component.html'
})
export class AgentFormComponent extends BaseComponent implements OnInit {
  agentFormGroup: FormGroup;
  initialFormGroupValue: { agentId: string; agentName: string; agentDescription: string };

  constructor(private readonly formBuilder: FormBuilder) {
    super();
  }

  ngOnInit(): void {
    this.createForm();
  }

  private createForm(): void {
    this.agentFormGroup = this.formBuilder.group({
      agentId: null,
      agentName: new FormControl('', [Validators.required]),
      agentDescription: new FormControl('')
    });

    this.initialFormGroupValue = this.agentFormGroup.value;
  }
}
