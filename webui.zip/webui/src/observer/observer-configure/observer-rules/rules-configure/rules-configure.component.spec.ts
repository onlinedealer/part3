import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RulesConfigureComponent } from './rules-configure.component';

describe('RulesConfigureComponent', () => {
  let component: RulesConfigureComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [RulesConfigureComponent]
    }).compileComponents();
    component = new RulesConfigureComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run showRulesSidebar fn with emiter', () => {
    const event = false;
    spyOn(component.ruleSidebarVisibleChange, 'emit');
    component.showRulesSidebar(event);
    expect(component.ruleSidebarVisible).toBe(false);
    expect(component.ruleSidebarVisibleChange.emit).toHaveBeenCalled();
  });

  it('should run onHide fn with emiter', () => {
    spyOn(component.ruleSidebarVisibleChange, 'emit');
    component.onHide();
    expect(component.ruleSidebarVisible).toBe(false);
    expect(component.ruleSidebarVisibleChange.emit).toHaveBeenCalled();
  });
});
