import { createAction, props } from "@ngrx/store";
import { NetworkControlParam } from "../../models/network-specific-config.model";

export const LoadNetworkSpecificConfiguration = createAction("[Network Specific Configuration] Load Network Specific Configuration");
export const LoadNetworkSpecificConfigurationSuccess = createAction(
    "[Network Specific Configuration] Load Network Specific Configuration Success",
    props<NetworkControlParam>()
);
export const LoadNetworkSpecificConfigurationFailure = createAction(
    "[Network Specific Configuration] Load Network Specific Configuration Failure",
    props<{ error: any }>()
);
