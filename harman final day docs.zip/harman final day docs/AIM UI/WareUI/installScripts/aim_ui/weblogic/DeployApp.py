"""
Deploy aim_ui application.
"""

import gs
import gsapp
from gs import args
import os.path

args.required("workspaceDir")
args.optional("wlServerName")

APP_DIR = os.path.join(args.workspaceDir, "Ware/Services/lib/")
PLAN_DIR = os.path.join(args.workspaceDir, "Ware/Services/lib/weblogic/plan")

gsapp.deployApplication(
	name="aim_ui",
	path=os.path.join(APP_DIR, "ui-frame.war"),
	planPath=os.path.join(PLAN_DIR, "aim_ui.xml"),
	targets=args.wlServerName)

gs.exit()