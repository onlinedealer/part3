import { DatadriftConfigureModel } from './data-drift-configure/data-drift-configure.model';
import { VolumeConfigureModel } from './volume-configure/volume-configure.model';

export class MetricRuleModel {
  volumeConfig: VolumeConfigureModel;
  dataDriftConfig: DatadriftConfigureModel;

  constructor() {
    this.volumeConfig = new VolumeConfigureModel();
    this.dataDriftConfig = new DatadriftConfigureModel();
  }
}
