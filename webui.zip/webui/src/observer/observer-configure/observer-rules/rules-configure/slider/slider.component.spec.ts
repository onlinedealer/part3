import { Spies } from 'discovery-test';
import { SliderComponent } from './slider.component';

describe('SliderComponent', () => {
  let component: SliderComponent;
  let element: any;

  beforeEach(() => {
    Spies.init();

    element = jasmine.createSpyObj('Element', ['getElementsByClassName']);
    element.style = {};
    element.getElementsByClassName.and.returnValue([element, element]);

    component = new SliderComponent();
    component.slider = {
      el: {
        nativeElement: element
      }
    } as any;
    component.sliderSettings = { sliderVisible: true, rangeValues: [60, 80] };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run ngOnInit', () => {
    component.ngOnInit();
    expect(component.selection.lowerThreshold).toBe(component.sliderSettings.rangeValues[0]);
    expect(component.selection.upperThreshold).toBe(component.sliderSettings.rangeValues[1]);
  });

  it('should run ngAfterViewChecked', () => {
    component.ngAfterViewChecked();
    expect(element.getElementsByClassName).toHaveBeenCalled();
  });

  it('should run slider handle change event with lower threshold more than 20', () => {
    const event = { values: [21, 80] };
    spyOn(component.threshold, 'emit');
    component.handleChange(event);
    expect(component.selection.lowerThreshold).toBe(21);
    expect(component.selection.upperThreshold).toBe(80);
    expect(component.threshold.emit).toHaveBeenCalled();
  });

  it('should run slider handle change event with lower threshold less than 20', () => {
    const event = { values: [19, 80] };
    component.handleChange(event);
    expect(component.selection.lowerThreshold).toBe(20);
  });

  it('should call onLowerThresholdChange event with lower threshold more than 20 when slider is visible', () => {
    component.selection.upperThreshold = 59;
    const event = { value: '60%' };
    component.onLowerThresholdChange(event);
    expect(component.selection.lowerThreshold).toBe(59);
  });

  it('should call onLowerThresholdChange event with lower threshold equal to 0 when slider is visible', () => {
    const event = { value: '0%' };
    component.onLowerThresholdChange(event);
    expect(component.selection.lowerThreshold).toBe(20);
  });

  it('should call onLowerThresholdChange event with lower threshold more than 100 when slider is visible', () => {
    component.selection.upperThreshold = 59;
    const event = { value: '102%' };
    component.onLowerThresholdChange(event);
    expect(component.selection.lowerThreshold).toBe(59);
  });

  it('should call onLowerThresholdChange event with lower threshold more than 20 when slider is not visible', () => {
    component.sliderSettings = { sliderVisible: false, rangeValues: [60, 80] };
    const event = { value: '60%' };
    component.onLowerThresholdChange(event);
    expect(component.selection.lowerThreshold).toBe(60);
  });

  it('should call onUpperThresholdChange event with lower threshold more than 20 when slider is visible', () => {
    const event = { value: '60%' };
    component.onUpperThresholdChange(event);
    expect(component.selection.upperThreshold).toBe(60);
  });

  it('should call onUpperThresholdChange event with lower threshold equal to 0 when slider is visible', () => {
    component.selection.lowerThreshold = 25;
    const event = { value: '0%' };
    component.onUpperThresholdChange(event);
    expect(component.selection.upperThreshold).toBe(25);
  });

  it('should call onUpperThresholdChange event with lower threshold more than 100 when slider is visible', () => {
    component.selection.lowerThreshold = 59;
    const event = { value: '102%' };
    component.onUpperThresholdChange(event);
    expect(component.selection.upperThreshold).toBe(59);
  });

  it('should run slider handle change event with thresholdNoAlertString is Yellow', () => {
    component.sliderSettings = { sliderVisible: false, rangeValues: [3, 8] };
    const event = { values: [21, 80] };
    component.handleChange(event);
    expect(component.thresholdNoAlertString.yellowAlert).toBe('Yellow');
    expect(component.thresholdNoAlertString.redAlert).toBe('Red');
  });

  it('should run slider handle change event with thresholdNoAlertString is No Yellow', () => {
    component.sliderSettings = { sliderVisible: false, rangeValues: [3, 8] };
    const event = { values: [25, 25] };
    component.handleChange(event);
    expect(component.thresholdNoAlertString.yellowAlert).toBe('No yellow');
    expect(component.thresholdNoAlertString.redAlert).toBe('Red');
  });
});
