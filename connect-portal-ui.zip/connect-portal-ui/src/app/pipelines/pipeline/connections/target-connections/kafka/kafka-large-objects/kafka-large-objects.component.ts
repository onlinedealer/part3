import { Component, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, ValidationErrors, ValidatorFn } from '@angular/forms';

@Component({
  selector: 'p-connect-kafka-large-objects',
  templateUrl: './kafka-large-objects.component.html'
})
export class KafkaLargeObjectsComponent implements OnInit, OnDestroy {
  largeObjectsForm: FormGroup;
  sizeOptions = ['bytes', 'KB', 'MB', 'GB'];

  constructor(private readonly controlContainer: ControlContainer) {}

  ngOnInit(): void {
    this.configureForm();
  }

  ngOnDestroy() {
    this.largeObjectsForm.clearValidators();
    this.largeObjectsForm.updateValueAndValidity();
  }

  private configureForm(): void {
    this.largeObjectsForm = this.controlContainer.control as FormGroup;
    this.largeObjectsForm.addControl('alwaysSend', new FormControl(false));
    this.largeObjectsForm.addControl('beforeImageValue', new FormControl(1000));
    this.largeObjectsForm.addControl('maxLOB', new FormControl(50000));
    this.largeObjectsForm.addControl('sizeFormat', new FormControl('bytes'));

    this.largeObjectsForm.setValidators(this.checkMinAndMaxValueForLOB());
  }

  private checkMinAndMaxValueForLOB(): ValidatorFn {
    return (group: FormGroup): ValidationErrors => {
      const sizeFormat = group.get('sizeFormat');
      const maxLOB = group.get('maxLOB');
      let isValid = false;

      switch (sizeFormat.value) {
        case 'bytes':
          isValid = maxLOB.value >= 100 && maxLOB.value <= 2000000000;
          break;
        case 'KB':
          isValid = maxLOB.value >= 0.1 && maxLOB.value <= 2000000;
          break;
        case 'MB':
          isValid = maxLOB.value >= 0.0001 && maxLOB.value <= 2000;
          break;
        case 'GB':
          isValid = maxLOB.value >= 0.0000001 && maxLOB.value <= 2;
          break;
      }

      if (!isValid) {
        group.get('maxLOB').setErrors({ invalidSizeFormat: true });
      } else {
        group.get('maxLOB').setErrors(null);
        return;
      }
    };
  }
}
