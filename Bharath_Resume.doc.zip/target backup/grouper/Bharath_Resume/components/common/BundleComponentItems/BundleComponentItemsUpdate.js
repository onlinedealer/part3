import React, { Component } from 'react'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import AddCircle from '@material-ui/icons/AddCircle'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormControl from '@material-ui/core/FormControl'
import Tooltip from '@material-ui/core/Tooltip'
import RemoveIcon from '@material-ui/icons/RemoveCircle'

export default class BundleComponentItemsUpdate extends Component {
  constructor (props) {
    super(props)
    this.state = {
      tcins: [],
      formData: {
        group_type: 'bundle',
        group_name: '',
        item_type: '',
        tcins: [],
      },
      errors: {
        group_type: '',
        item_type: '',
        group_name: '',
        tcins: '',
      },
      componentItemObj: {
        id: 0,
        tcinNum: '',
        quantity: '',
      },
      componentItemArray: [{
        id: 1,
        tcinNum: '',
        quantity: '',
      }, {
        id: 2,
        tcinNum: '',
        quantity: '',
      },

      ],
    }
    this.delComponentItem = this.delComponentItem.bind(this)
  }

  handleDeleteTcin = (tcin) => {
    const formData = { ...this.state.formData }
    formData.tcins = formData.tcins.filter((c) => c !== tcin)
    if (formData.tcins.length <= 0) {
      this.props.clearErrorTcins()
      this.props.toggleSnackBar({})
    }
    this.setState({ formData })
    this.props.onHandleChange('tcins', formData.tcins)
  }

  addComponentItem = () => {
    let componentItemArray = [ ...this.state.componentItemArray ]
    let compItemObj = {}
    compItemObj.id = componentItemArray.length + 1
    compItemObj.tcinNum = ''
    compItemObj.quantity = ''
    componentItemArray.push(compItemObj)
    this.setState({ componentItemArray })
  }

  delComponentItem () {
  }

  render () {
    const { classes } = this.props
    return (
      <div className={classes.themeRoot}>
        <Grid item xs={12} className={classes.field}>
          <Grid container style={{flexDirection: 'row'}}>
            {this.state.componentItemArray.map(function (object, i) {
              return <div key={i}>
                <span item xs={1} className={classes.indexNumberTop}>
                  {object.id}
                </span>
                <span item xs={5} className={classes.tcinMarginRight}>
                  <FormControl aria-describedby="name-helper-text">
                    <InputLabel htmlFor="name-helper" required>TCIN</InputLabel>
                    <Input id="name-helper" required />
                  </FormControl>
                </span>
                <span item xs={4} className={classes.quantityMarginRight}>
                  <FormControl aria-describedby="name-helper-text">
                    <InputLabel htmlFor="name-helper" required>Quantity</InputLabel>
                    <Input id="name-helper" required />
                  </FormControl>
                </span>
                <span item xs={1} >
                  <Tooltip id="tooltip-icon" title="Remove Component Item">
                    <Button color="primary" aria-label="remove"
                      className={classes.IconButton} >
                      <RemoveIcon className={classes.iconColor} />
                    </Button>
                  </Tooltip>
                </span>

              </div>
            })}
          </Grid>
        </Grid>
        <Grid item xs={12} style={{flexBasis: '2%'}}>
          <Button className={classes.addThemeButtonStyle} onClick={this.addComponentItem}>
            <AddCircle className={classes.addThemeIcon} /> ADD COMPONENT
          </Button>
        </Grid>
      </div>
    )
  }
}
