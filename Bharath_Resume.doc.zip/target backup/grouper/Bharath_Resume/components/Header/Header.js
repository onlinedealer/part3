import React from 'react'
import {object, string, func} from 'prop-types'
import AppBar from '@material-ui/core/AppBar'
import IconButton from '@material-ui/core/IconButton'
import MenuIcon from '@material-ui/icons/Menu'
import Toolbar from '@material-ui/core/Toolbar'
import { withStyles } from '@material-ui/core/styles'

import { appBarStyles } from 'react-praxis-components/SecondaryNav'
import { ReactComponent as Logo } from '../../images/logo.svg'

export function Header ({ classes, title, menuAction }) {
  return (
    <div className={classes.header}>
      <AppBar className={classes.appBar}>
        <Toolbar>
          { menuAction && (
            <IconButton onClick={menuAction} aria-label="Menu">
              <MenuIcon className={classes.menuIconMargin} />
            </IconButton>
          ) }
          <Logo className={classes.logo} />
        </Toolbar>
      </AppBar>
    </div>
  )
}

Header.displayName = 'Header'

Header.propTypes = {
  classes: object,
  title: string.isRequired,
  menuAction: func,
}

Header.defaultProps = {
  classes: {},
}

const styles = theme => ({
  header: {
    height: 56,
    [`${theme.breakpoints.up('xs')} and (orientation: landscape)`]: {
      height: 48,
    },
    [theme.breakpoints.up('sm')]: {
      height: 64,
    },
  },
  appBar: {
    backgroundColor: '#f5f5f5',
    ...appBarStyles,
  },
  logo: {
    height: 26,
    margin: '0 18px 0 10px',
  },
  menuIconMargin: {
    marginLeft: '-25px',
  },
})

export default withStyles(styles)(Header)
