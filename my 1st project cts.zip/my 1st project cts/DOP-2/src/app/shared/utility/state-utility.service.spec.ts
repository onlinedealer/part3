import { TestBed, inject } from '@angular/core/testing';

import { StateUtilityService } from './state-utility.service';

describe('StateUtilityService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [StateUtilityService]
    });
  });

  it('should be created', inject([StateUtilityService], (service: StateUtilityService) => {
    expect(service).toBeTruthy();
  }));
});
