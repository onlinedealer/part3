import { Action, createReducer, on } from "@ngrx/store";
import { UserSettingsActions } from "../actions";

export interface ErrorState {
    errorCode?: number;
    errorText?: string;
    parameters?: string[];
}

export interface MeteringPointsSearchSettings {
    defaultSearchField: string;
}

export interface SearchSettings {
    meteringPoints?: MeteringPointsSearchSettings;
}

export interface UserSettingsState {
    searchSettings?: SearchSettings;
    userProfileSetting: any;
    loaded: boolean;
    userSettingFailed: boolean;
    getUserSettingErrorState?: ErrorState;
    updateUserSettingErrorState?: ErrorState;
}

export const initialState: UserSettingsState = {
    loaded: false,
    userSettingFailed: false,
    userProfileSetting: {}
};

const userSettingsReducer = createReducer(
    initialState,

    on(UserSettingsActions.GetUserSettingsSuccess, (state, payload) => {
        const userSettings =
            payload.userSettings && payload.userSettings[0] && payload.userSettings[0].setting
                ? JSON.parse(payload.userSettings[0].setting)
                : {};

        return {
            ...state,
            loaded: true,
            getUserSettingErrorState: {},
            userSettingFailed: false,
            userProfileSetting: userSettings
        };
    }),
    on(UserSettingsActions.GetUserSettingsFail, (state, error) => {
        const isEmpty = isUserSettingsDataEmpty(error);

        return {
            ...state,
            userSettingFailed: !isEmpty,
            getUserSettingErrorState: {
                ...state.getUserSettingErrorState,
                errorCode: isEmpty ? "" : error.error.errorCode || error.error.statusCode
            }
        };
    }),
    on(UserSettingsActions.UpdateUserSettingsSuccess, (state, userSetting) => {
        return {
            ...state,
            userSettingFailed: false,
            updateUserSettingErrorState: {},
            userProfileSetting: userSetting.userSettings
        };
    }),
    on(UserSettingsActions.UpdateUserSettingsFail, (state, error) => {
        return {
            ...state,
            userSettingFailed: true,
            updateUserSettingErrorState: {
                ...state.updateUserSettingErrorState,
                errorCode: error.error.errorCode ? error.error.errorCode : error.error.statusCode
            }
        };
    }),
    on(UserSettingsActions.GetMeteringPointsSearchSettingsSuccess, (state, payload) => {
        const settings = payload.mpSearchSettings && payload.mpSearchSettings[0] ? JSON.parse(payload.mpSearchSettings[0].setting) : {};

        const searchSettings = state.searchSettings ? { ...state.searchSettings } : {};
        searchSettings.meteringPoints = settings.meteringPoints;

        return {
            ...state,
            searchSettings
        };
    }),
    on(UserSettingsActions.SetMeteringPointsSearchSettings, (state, payload) => {
        const searchSettings = state.searchSettings ? { ...state.searchSettings } : {};
        searchSettings.meteringPoints = payload.meteringPointsSearchSettings;

        return {
            ...state,
            searchSettings
        };
    })
);

export function reducer(state: UserSettingsState | undefined, action: Action): UserSettingsState {
    return userSettingsReducer(state, action);
}

const isUserSettingsDataEmpty = (error: any): boolean => {
    if (error.error && error.error.errorCode === 23 && error.error.parameters.length === 0) {
        return true;
    } else {
        return false;
    }
};
