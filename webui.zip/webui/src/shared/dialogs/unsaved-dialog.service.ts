import { Injectable } from '@angular/core';
import { LogManagerService } from '../log/log-manager.service';
import { Logger } from '../log/logger.model';
import { noop } from '../noop.model';
import { DialogService } from './dialog.service';

/**
 *This service Provides support for showing "unsaved changes" dialogs from external app like metadata etc..
 */

@Injectable({
  providedIn: 'root'
})
export class UnsavedDialogService {
  private $state: any; // StateService;
  private log: Logger;

  /**
   * @internal
   */
  constructor(private dialogService: DialogService, logManager: LogManagerService) {
    this.log = logManager.getLogger('UnsavedDialogService');
  }

  /**
   *Below method Listens for ui router state change start events.  When fired, calls isDirtyCallback to
   * determine if the current form is dirty.  If so, displays an appropriate dialog to the user alerting
   * them to the unsaved changes.  If the user cancels the navigation, $transition will be aborted
   * @example
   * <pre>
   UnsavedDialogService.registerUnsavedDialog(function () {
        return profileForm.dirty;
      });
   * </pre>
   */
  registerUnsavedDialog(router: any, isDirtyCallback: any): void {
    const $transition: any = router.transitionService;
    this.$state = router.stateService;

    if (isDirtyCallback.onRouteChangeOff !== undefined) {
      this.unregister(isDirtyCallback);
    }
    isDirtyCallback.onRouteChangeOff = $transition.onStart({}, (trans: any) =>
      this.routeChange(trans, isDirtyCallback)
    );
  }

  /**
   * callback called before the state transition happens
   * open the unsaved dialog and ask for response.
   */
  private routeChange(transition: any, isDirtyCallback: any): void | any {
    // Ignore events where to and from routes are the same.
    if (transition.to().name === transition.from().name) {
      transition.abort();
      return;
    }

    // If not dirty, unregister our callback and continue w/state transition.
    if (!isDirtyCallback()) {
      this.unregister(isDirtyCallback);
      return;
    }

    this.dialogService.unsavedChanges().then((success: boolean) => {
      if (success) {
        this.unregister(isDirtyCallback);
        // find new route from url
        this.log.debug('Changing state to: ' + transition.to().name + ' -> ');
        return this.$state.go(transition.to().name);
      }
    }, noop);

    // Prevent navigation since we will handle it once user selects from dialog and fire
    transition.abort();
  }

  /**
   * Unregister the listener and cleanup.
   */
  private unregister(isDirtyCallback: any): void {
    isDirtyCallback.onRouteChangeOff();
    delete isDirtyCallback.onRouteChangeOff;
  }
}
