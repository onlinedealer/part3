import { Injectable, LOCALE_ID, Inject, Optional } from "@angular/core";
import { HeaderDataProvider, HeaderData } from "../modules/header/common/header-data-provider";
import { Observable, combineLatest } from "rxjs";
import { UiConfiguration, configurationAvailableDateFormats } from "../store/reducers/configurations.reducer";
import { Store } from "@ngrx/store";
import { map } from "rxjs/operators";
import { VersionNumberService } from "../../Shared/services/version-number.service";
import { LocaleService } from "../../Shared/services/locale.service";
import { NetworkConfigurationService } from "../../Shared/services/network-configuration.service";
import { SorterService } from "../../Shared/services/sorter.service";
import { UserMenuTimeZoneInformation } from "../modules/header/components/user-menu/user-menu.component";
import {
    getUAMDefinedTimeZone,
    getTimeZoneInUse,
    getUserSettingsUrl,
    getUiLocale
} from "../store/selectors/configurations.selectors";
import { TimeZoneService } from "../../Shared/services/time-zone.service";
import { UISelectors, SecuritySelectors, ConfigurationsSelectors } from "../store/selectors";
import { State } from "../store/reducers";

@Injectable({
    providedIn: "root"
})
export class ApplicationDataProviderService extends HeaderDataProvider {
    headerTitle$: Observable<string> = this.store.select(UISelectors.getHeaderTitle);
    userInformation$: Observable<any> = this.store.select(SecuritySelectors.getUserInformation);
    uiConfigurations$: Observable<UiConfiguration> = this.store.select(ConfigurationsSelectors.getUiConfigurations);
    _versionNumber$: Observable<string>;
    timeZoneInUse$ = this.store.select(getTimeZoneInUse);
    uamTimeZone$ = this.store.select(getUAMDefinedTimeZone);
    userSettingsUrl$ = this.store.select(getUserSettingsUrl);
    getUILocale$ = this.store.select(getUiLocale);
    constructor(
        private store: Store<State>,
        private versionNumberService: VersionNumberService,
        private localeService: LocaleService,
        private networkConfigurationService: NetworkConfigurationService,
        private sorterService: SorterService,
        private timeZoneService: TimeZoneService,
        @Optional() @Inject(LOCALE_ID) private localeId: string
    ) {
        super();
        this._versionNumber$ = this.versionNumberService.getVersionNumber();
    }

    getAvailableUILanguages(): Observable<{ code: string; name: string }[]> {
        return this.localeService.getAvailableLanguges().pipe(map((languages) => this.sorterService.sortByName(languages)));
    }

    getHeaderData(): Observable<HeaderData> {
        return combineLatest([
            this.headerTitle$,
            this.userInformation$,
            this.uiConfigurations$,
            this._versionNumber$,
            this.networkConfigurationService.getNetworkData(),
            this.userSettingsUrl$,
            this.getUILocale$
        ]).pipe(
            map(([headerTitle, userInformation, uiConfiguration, versionNumber, networkData, userSettingsUrl, uiLocale]) => {
                const headerData: HeaderData = {
                    applicationTitle: "AIM",
                    userInformation: userInformation,
                    currentLocale: this.localeId || uiLocale || "en",
                    headerTitle: headerTitle,
                    versionNumber: versionNumber,
                    manualAddress: `manual/${this.localeId}/index.html`,
                    networkTimeZoneName: networkData.timeZone,
                    network: networkData.networkName,
                    uiConfiguration: uiConfiguration,
                    uiDateConfigurationsAvailable: configurationAvailableDateFormats,
                    userSettingsUrl: userSettingsUrl,
                    localTimeZoneQuessedName: this.timeZoneService.getLocalTimeZoneName()
                };
                return headerData;
            })
        );
    }

    getUITimeZoneInformation(): Observable<UserMenuTimeZoneInformation> {
        return combineLatest([
            this.timeZoneInUse$,
            this.uamTimeZone$,
            this.timeZoneService.getAllTimezones(),
            this.networkConfigurationService.getNetworkData()
        ]).pipe(
            map(([timeZoneInUse, uamTimeZone, allTimeZonesReported, networkData]) => {
                const allTimeZones = this.sorterService.sort(
                    [...allTimeZonesReported, uamTimeZone, networkData.timeZone],
                    true
                );
                const data: UserMenuTimeZoneInformation = {
                    timeZoneInUse: timeZoneInUse,
                    uamTimeZone: uamTimeZone,
                    networkTimeZone: networkData.timeZone,
                    availableTimeZones: allTimeZones.filter(
                        (timeZone) =>
                            timeZone !== uamTimeZone &&
                            timeZone !== networkData.timeZone
                    )
                };
                return data;
            })
        );
    }
}
