import { MeteringPointGroup } from "../meteringpoint-group.model";

export const meteringpointGroup: MeteringPointGroup = {
    id: 1,
    name: "string",
    meteringPointIds: [1, 2, 3]
};

export const meteringpointGroups: MeteringPointGroup[] = [meteringpointGroup];
