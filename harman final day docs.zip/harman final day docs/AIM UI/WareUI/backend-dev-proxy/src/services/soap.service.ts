import { Observable, from } from 'rxjs';
import * as soapAPI from '../soap-api/index';

export class SOAPService {

    public soapRequest(url: string, headers: any, xml: string): Observable<any>{

        return from(soapAPI.getMeteringPoints());

    }


}
