import { Component, OnInit, Input } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-semantic-donut-chart',
  templateUrl: './semantic-donut-chart.component.html',
  styleUrls: ['./semantic-donut-chart.component.css']
})
export class SemanticDonutChartComponent implements OnInit {
  @Input() statistic: any;
  @Input() name: string;
  @Input() semanticType: string;
  @Input() totalRows: number;
  @Input() id: number;
  @Input() displayName: string;
  @Input() showTrendsIndicator: boolean;

  data: any;
  basicOptions: any;
  keys: any[];
  values: any[];
  chartWidth: string = '20vw';

  constructor(private translocoService: TranslocoService) {}

  ngOnInit() {
    this.data = {
      labels: [],
      datasets: [
        {
          data: [],
          backgroundColor: [
            ProfilingConstants.FREQUENCYCHARTCOLORS[0],
            ProfilingConstants.FREQUENCYCHARTCOLORS[1],
            ProfilingConstants.FREQUENCYCHARTCOLORS[2],
            ProfilingConstants.FREQUENCYCHARTCOLORS[3]
          ],
          hoverBackgroundColor: [
            ProfilingConstants.FREQUENCYCHARTCOLORS[0],
            ProfilingConstants.FREQUENCYCHARTCOLORS[1],
            ProfilingConstants.FREQUENCYCHARTCOLORS[2],
            ProfilingConstants.FREQUENCYCHARTCOLORS[3]
          ]
        }
      ]
    };

    this.basicOptions = {
      plugins: {
        legend: {
          display: this.showTrendsIndicator ? false : true,
          align: 'start',
          position: 'right',
          onClick: (event: any, legendItem: any) => {
            // alert(legendItem.text);
          },
          onHover: (e: any) => {
            e.native.target.style.cursor = 'pointer';
          },
          labels: {
            boxWidth: 10
          }
        },
        tooltip: { enabled: false }
      },
      cutout: '80%'
    };
    if (this.statistic) {
      this.generateDataLabel();
    }
  }

  selectData(event: any): void {}

  private generateDataLabel() {
    this.chartWidth = this.showTrendsIndicator ? '10vw' : '20vw';
    this.data.datasets[0].data = [this.statistic['validCount'], this.statistic['invalidCount']];
    switch (this.name) {
      case ProfilingConstants.SEMANTICSTATSFREQUENCY.VALIDITY:
        this.generateValidityDataLabel();
        break;
      case ProfilingConstants.SEMANTICSTATSFREQUENCY.CONFIDENCE:
        this.generateConfidenceDataLabel();
        break;
    }
  }

  private generateValidityDataLabel() {
    this.data.labels[0] =
      this.translocoService.translate('discoveryProfiling.results.validCount') +
      ' ' +
      '(' +
      ((this.statistic['validCount'] / (this.statistic['validCount'] + this.statistic['invalidCount'])) * 100).toFixed(
        2
      ) +
      '%)';
    this.data.labels[1] =
      this.translocoService.translate('discoveryProfiling.results.invalidCount') +
      ' ' +
      '(' +
      (
        (this.statistic['invalidCount'] / (this.statistic['validCount'] + this.statistic['invalidCount'])) *
        100
      ).toFixed(2) +
      '%)';
  }
  private generateConfidenceDataLabel() {
    this.data.labels[0] =
      this.translocoService.translate('discoveryProfiling.results.confidence') +
      ' ' +
      '(' +
      ((this.statistic['validCount'] / (this.statistic['validCount'] + this.statistic['invalidCount'])) * 100).toFixed(
        2
      ) +
      '%)';
    this.data.datasets[0].backgroundColor[1] = ProfilingConstants.FREQUENCYCHARTCOLORS[8];
    this.data.datasets[0].hoverBackgroundColor[1] = ProfilingConstants.FREQUENCYCHARTCOLORS[8];
  }
}
