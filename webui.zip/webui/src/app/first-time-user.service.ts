import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class FirstTimeUserService {
  showHeader: boolean = true;

  showHeaderMenu(show: boolean) {
    if (this.firstTimeUser()) {
      this.showHeader = show;
    }
  }
  firstTimeUser(): boolean {
    return true;
  }
}
