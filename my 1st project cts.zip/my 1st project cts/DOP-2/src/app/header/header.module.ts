import { NgModule } from '@angular/core';
import {CommonModule} from "@angular/common";
import {HeaderComponent} from './header.component';
import {SearchComponent} from './search/search.component';



@NgModule({
  declarations: [
      HeaderComponent,
      SearchComponent
  ],
  exports:[
      HeaderComponent
  ],
  imports:[
      CommonModule
  ]
})
export class HeaderModule { }