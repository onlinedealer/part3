export enum AGENT_STATUS {
  UP = 'up',
  DOWN = 'down'
}

export class Agent {
  agentDescription?: string;
  agentId?: string;
  agentName?: string;
  agentUpOrDownStatus?: string;
  hostName?: string;
  lastHeartBeatAsLongInMilliSeconds?: number;
  lastHeartBeatTime?: string;
  osType?: string;
  osVersion?: string;
  productName?: string;
  tenantId?: string;
  timeOutDuration?: string;
  totalCPUCount?: number;
  totalDiskSpace?: number;
  totalMemory?: number;
  uuid?: string;
  versionInfo?: string;
}
