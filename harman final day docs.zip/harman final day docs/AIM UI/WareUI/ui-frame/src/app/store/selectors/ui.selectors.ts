import { createSelector } from "@ngrx/store";

import * as fromRoot from "../reducers";
import * as fromUI from "../reducers/ui.reducer";

export const getWindowWidth = createSelector(fromRoot.getUIState, (uiState: fromUI.UiState) => uiState.windowWidth);

export const getWindowHeight = createSelector(fromRoot.getUIState, (uiState: fromUI.UiState) => uiState.windowHeight);

export const getWindowDimensions = createSelector(getWindowWidth, getWindowHeight, (windowWidth, windowHeight) => {
    return {
        width: windowWidth,
        height: windowHeight
    };
});

export const getHeaderTitle = createSelector(fromRoot.getUIState, (uiState: fromUI.UiState) => uiState.headerTitle);
