import { Spies } from 'discovery-test';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { StringMaxminComponent } from './string-maxmin.component';

describe('StringMaxminComponent', () => {
  let component: StringMaxminComponent;

  beforeEach(() => {
    Spies.init();
    component = new StringMaxminComponent(Spies.TranslateService, Spies.eventBusService, Spies.HttpUtilService);
    component.treePath = new TreePath();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
  it('Initialize ngOnInit with StringLengthStatistics', () => {
    component.statistics = [
      {
        type: 'StringLengthStatistics',
        maxLength: 200,
        minLength: 0
      },
      {
        type: 'DetectedSemanticTypeStatistics',
        group: 'STRING_ANALYSIS',
        semanticType: 'First Name'
      }
    ] as any;
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.dataset[0].data).toBe(component.statistics[1]['semanticType']);
    expect(component.dataset[1].data).toEqual(0);
    expect(component.dataset[2].data).toEqual(200);
  });

  it('should emit event on launchTrendsSidebar', () => {
    component.launchTrendsSidebar('Min Length');
    expect(Spies.eventBusService['emit']).toHaveBeenCalled();
  });
});
