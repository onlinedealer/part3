(function () {
    'use strict';

    angular.module('arm').controller('conversationListCtrl',
                ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate', conversationListCtrl]);

    function conversationListCtrl($scope, $state, $ionicModal, $ionicSideMenuDelegate) {
		
		$scope.openMenu = function () {
			$ionicSideMenuDelegate.toggleLeft();
		}
		$scope.messageDetail = function(messageId) {
			//console.log(messageId)
            $state.go('tab.conversationDetail', {
               //
            });
        }
		$scope.fnAddContact = function() {
			$scope.modal.show();
		};		
		  
		//
		$scope.groups = [
			{ title: 'Beverage Distribution LLC', id: 1 }
	    ];
			  
		$scope.toggleGroup = function(group) {
			group.show = !group.show;
		};
		$scope.isGroupShown = function(group) {
			return group.show;
		};	  
		
		$ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
			scope: $scope,
			animation: 'slide-in-left',
			focusFirstInput: true
		}).then(function(modal) {
			$scope.modal = modal
		})

		$scope.fnaddBtn = function() {
			$scope.modal.show();
		}

		$scope.closeModal = function() {
			$scope.modal.hide();
		};

		$scope.$on('$destroy', function() {
			$scope.modal.remove();
		});		
		//		   
	};
})();



