export class SchemaModel {
  name: string;
  id: string;
  tableCount: number;
  selected: boolean;
  lastCataloged?: string;
  children: TableModel[];
  hasBeenCached = false;

  appendIcon: { iconClassList: string[]; iconTooltip: string };

  get tableSelectionCount(): string {
    let count = 0;
    for (const table of this.children) {
      if (table.selected) {
        count++;
      }
    }
    return `${count}`;
  }

  constructor(schema?: SchemaModel, catalogDateTime?: string, appendIcon?: { iconClassList: string[]; iconTooltip: string }) {
    this.selected = schema && schema.selected;
    this.children = [];
    if (schema) {
      this.name = schema.name;
      this.id = schema.id;

      if (appendIcon) {
        this.appendIcon = appendIcon;
      }

      this.tableCount = schema.tableCount;
      if (catalogDateTime) {
        this.lastCataloged = catalogDateTime;
      }
      if (schema.children) {
        for (const table of schema.children) {
          this.children.push(new TableModel(table));
        }
      }
    }
  }
}

export class TableModel {
  name: string;
  id: string;
  journal: string;
  selected: boolean;
  children: ColumnModel[];
  appendIcon: { iconClassList: string[]; iconTooltip: string };

  constructor(table?: TableModel, appendIcon?: { iconClassList: string[]; iconTooltip: string }) {
    this.selected = table && table.selected;
    this.children = [];

    if (appendIcon) {
      this.appendIcon = appendIcon;
    }

    if (table) {
      this.name = table.name;
      this.journal = table.journal;
      this.children = table.children ? table.children : [];
    }
  }
}

export class ColumnModel {
  dataType: string;
  isPrimaryKey: boolean;
  name: string;
}
