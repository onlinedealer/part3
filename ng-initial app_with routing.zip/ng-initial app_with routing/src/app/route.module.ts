import { NgModule } from '@angular/core';
 import { Routes, RouterModule } from '@angular/router';
 import { UserComponent } from './components/user/user.component';
 import { RegComponent } from './components/registration/reg.component';
 
 const routes: Routes = [
   { path: 'login', component: UserComponent },
   { path: 'reg', component: RegComponent },
   { path: '**', component: UserComponent }
 ]; 
 
 @NgModule({
   imports: [RouterModule.forRoot(routes)],
   exports: [RouterModule],
 })
 export class AppRoutingModule {}
  