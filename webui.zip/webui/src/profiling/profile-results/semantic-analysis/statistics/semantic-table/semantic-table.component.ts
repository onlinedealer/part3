import { Component, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-semantic-table',
  templateUrl: './semantic-table.component.html',
  styleUrls: ['./semantic-table.component.css']
})
export class SemanticTableComponent implements OnInit {
  @Input() statistic: any;
  @Input() name: string;
  @Input() semanticType: string;
  @Input() totalRows: number;
  @Input() parentCols?: Array<Record<string, unknown>>;
  @Input() defaultSorting?: string;

  cols = [];
  data = [];
  defaultSort = '';
  constructor(private translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.data = [];
    if (this.semanticType === ProfilingConstants.SEMANTICSTATSFREQUENCY.MULTIPLE_SEMANTIC_TYPE_INFO) {
      this.cols = this.parentCols;
      this.data = this.statistic;
      this.defaultSort = this.defaultSorting;
    } else {
      switch (this.name) {
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.DATEFORMAT:
          this.loadDateTable();
          break;
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.PHONECOUNTRY:
          this.loadPhoneCountryTable();
          break;
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.PHONETYPE:
          this.loadPhoneTypeTable();
          break;
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.PHONEREGION:
          this.loadPhoneRegionTable();
          break;
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.CREDITCARD:
          this.loadCreditCardTable();
          break;
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.EMAILDOMAIN:
          this.loadEmailTable();
          break;
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.VINCOUNTRY:
          this.loadVinTable();
          break;
        case ProfilingConstants.SEMANTICSTATSFREQUENCY.IBANCOUNTRY:
          this.loadIbanTable();
          break;
      }
    }
  }

  getSemanticTypeString(key) {
    if (ProfilingConstants.MULTISEMANTICINFOTABLE[key]) {
      return this.translocoService.translate(
        `discoveryProfiling.results.multi-semantic-table-info-headers.${ProfilingConstants.MULTISEMANTICINFOTABLE[key]}`
      );
    }

    return key;
  }

  private loadDateTable() {
    this.cols = [
      {
        field: 'pattern',
        header: this.translocoService.translate('discoveryProfiling.results.patternColumn')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        pattern: key,
        count: value[key]
      });
    });
  }
  private loadPhoneCountryTable() {
    this.cols = [
      {
        field: 'phoneCountry',
        header: this.translocoService.translate('discoveryProfiling.results.phoneCountry')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        phoneCountry: key,
        count: value[key]
      });
    });
  }
  private loadPhoneTypeTable() {
    this.cols = [
      {
        field: 'phoneType',
        header: this.translocoService.translate('discoveryProfiling.results.phoneType')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        phoneType: key,
        count: value[key]
      });
    });
  }
  private loadPhoneRegionTable() {
    this.cols = [
      {
        field: 'phoneRegion',
        header: this.translocoService.translate('discoveryProfiling.results.phoneRegion')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        phoneRegion: key,
        count: value[key]
      });
    });
  }

  private loadCreditCardTable() {
    this.cols = [
      {
        field: 'pattern',
        header: this.translocoService.translate('discoveryProfiling.results.creditCardColumn')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        pattern: key,
        count: value[key]
      });
    });
  }
  private loadEmailTable() {
    this.cols = [
      {
        field: 'email',
        header: this.translocoService.translate('discoveryProfiling.results.emailColumn')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        email: key,
        count: value[key]
      });
    });
  }
  private loadVinTable() {
    this.cols = [
      {
        field: 'vinCountry',
        header: this.translocoService.translate('discoveryProfiling.results.phoneCountry')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        vinCountry: key,
        count: value[key]
      });
    });
  }

  private loadIbanTable() {
    this.cols = [
      {
        field: 'ibanCountry',
        header: this.translocoService.translate('discoveryProfiling.results.patternColumn')
      },
      {
        field: 'count',
        header: this.translocoService.translate('discoveryProfiling.results.countColumn')
      }
    ];
    this.defaultSort = 'count';
    const value = this.statistic['frequency'];
    Object.keys(value).forEach((key) => {
      this.data.push({
        ibanCountry: key,
        count: value[key]
      });
    });
  }
}
