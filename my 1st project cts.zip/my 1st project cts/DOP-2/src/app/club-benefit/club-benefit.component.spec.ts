import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClubBenefitComponent } from './club-benefit.component';
import { BccComponent } from '../shared/bcc/bcc.component';



describe('ClubBenefitComponent', () => {
  // let component: ClubBenefitComponent;
  // let fixture: ComponentFixture<ClubBenefitComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ClubBenefitComponent, BccComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    spyOn(console, 'log');
  });

  it('ClubBenefitComponent should be created', () => {
    const fixture = TestBed.createComponent(ClubBenefitComponent);
    const component = fixture.debugElement.componentInstance;
    expect(component).toBeTruthy();
  });

  it('should call joinCVSClub() and print console.log', () => {
    const fixture = TestBed.createComponent(ClubBenefitComponent);
    const component = fixture.debugElement.componentInstance;
    component.joinCVSClub();
    expect(console.log).toHaveBeenCalledWith('Join club logic goes here!!!');
  });
});

describe('1st tests', () => {
  it('true is true', () => expect(true).toBe(true));
});
