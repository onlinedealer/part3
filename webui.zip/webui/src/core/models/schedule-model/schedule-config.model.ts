import { ScheduleModel } from './schedule.model';

export class ScheduleConfigModel {
  enabled: boolean;
  status: string;
  schedule: ScheduleModel = new ScheduleModel();
  lastStatusUpdatedDateTime: number;
  constructor(scheduleData) {
    if (scheduleData) {
      this.enabled = scheduleData.enabled ? scheduleData.enabled : false;
      this.schedule.daysOfWeek = scheduleData.schedule.daysOfWeek;
      this.schedule.occurence = scheduleData.schedule.occurence;
      this.schedule.runAtTime = scheduleData.schedule.runAtTime;
      this.schedule.timezone = scheduleData.schedule.timezone;
    }
  }
}
