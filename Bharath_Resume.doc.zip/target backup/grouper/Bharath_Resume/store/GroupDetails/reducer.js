import { fromJS } from 'immutable'
import {
  GET_GROUP_DETAILS_SUCCESS,
  ADD_TCINS,
  ADD_TCINS_SUCCESS,
  REMOVE_TCINS,
  UPDATE_GROUP_NAME,
  UPDATE_GROUP_NAME_SUCCESS,
  REMOVE_TCINS_SUCCESS,
  CLEAR_GROUP_DETAILS_REQUEST_TYPE,
  SET_ADDITEM_ERROR_TCINS,
  SET_DETAILS_ERROR_TCINS,
  UPDATE_ITEMS_ORDER,
  UPDATE_ITEMS_ORDER_ERROR,
  UPDATE_ITEMS_ORDER_SUCCESS,
  CLEAR_ADD_ITEM_TCIN_ERROR,
  CLEAR_GROUP_DETAILS,
  UPDATE_VARIATION_GROUP_NAME_DETAILS,
  SET_GROUP_DETAILS,
  ADD_ITEMS_TO_GROUP_DETAILS,
} from './actionType'

export const initialState = fromJS({
  groupDetails: {},
  requestType: '',
  addItemErrorTcins: [],
  groupDetailsErrorTcins: [],
})

export default function grouperReducer (state = initialState, action) {
  switch (action.type) {
    case GET_GROUP_DETAILS_SUCCESS:
      return state
        .set('requestType', fromJS('GROUP_DETAILS'))
        .set('groupDetails', fromJS(action.data))
        .set('addItemErrorTcins', fromJS([]))

    case ADD_TCINS:
      return state
        .set('requestType', fromJS(''))
        .set('addItemErrorTcins', fromJS([]))

    case ADD_TCINS_SUCCESS:
      return state
        .set('requestType', fromJS('ADDED_TCINS'))
        .set('addItemErrorTcins', fromJS([]))

    case REMOVE_TCINS:
      return state
        .set('requestType', fromJS(''))
        .set('addItemErrorTcins', fromJS([]))

    case REMOVE_TCINS_SUCCESS:
      return state

    case UPDATE_GROUP_NAME:
      return state
        .set('requestType', fromJS(''))
        .set('addItemErrorTcins', fromJS([]))

    case UPDATE_GROUP_NAME_SUCCESS:
      return state
        .set('requestType', fromJS('GROUP_NAME_UPDATED'))
        .set('addItemErrorTcins', fromJS([]))

    case UPDATE_ITEMS_ORDER:
      return state
        .set('requestType', fromJS(''))

    case UPDATE_ITEMS_ORDER_SUCCESS:
      return state
        .set('requestType', fromJS('ORDER_UPDATED'))

    case UPDATE_ITEMS_ORDER_ERROR:
      return state
        .set('requestType', fromJS(''))

    case CLEAR_GROUP_DETAILS_REQUEST_TYPE:
      return state
        .set('requestType', fromJS(''))
        .set('addItemErrorTcins', fromJS([]))

    case SET_ADDITEM_ERROR_TCINS:
      return state
        .set('addItemErrorTcins', fromJS(action.errorTcins))

    case SET_DETAILS_ERROR_TCINS:
      return state
        .set('groupDetailsErrorTcins', fromJS(action.errorTcins))

    case CLEAR_ADD_ITEM_TCIN_ERROR:
      return state
        .set('addItemErrorTcins', fromJS([]))

    case CLEAR_GROUP_DETAILS:
      return state
        .set('groupDetails', fromJS({}))

    case UPDATE_VARIATION_GROUP_NAME_DETAILS:
      return state
        .setIn(['groupDetails', 'group_name'], action.groupName)
        .set('requestType', fromJS('GROUP_NAME_UPDATED'))

    case SET_GROUP_DETAILS:
      return state
        .set('groupDetails', fromJS(action.payload))

    case ADD_ITEMS_TO_GROUP_DETAILS:
      let updatedItems = state.toJS().groupDetails.items ? state.toJS().groupDetails.items : []
      let currentThemes = state.toJS().groupDetails.themes ? state.toJS().groupDetails.themes : []
      let itemCount = updatedItems.length
      action.payload.map((itemObj) => {
        let newItem = {}
        itemCount++
        newItem.business_process_status = itemObj.business_process_status
        newItem.dpci = itemObj.dpci
        newItem.intended_launch_date_time = itemObj.intended_launch_date_time
        newItem.is_merchant_approved_for_publishing = itemObj.is_merchant_approved_for_publishing
        newItem.is_ready_for_omnichannel = itemObj.is_ready_for_omnichannel
        newItem.item_state = itemObj.item_state
        newItem.item_type = itemObj.item_type
        newItem.item_type_id = itemObj.item_type_id
        newItem.launch_date = itemObj.launch_date
        newItem.product_title = itemObj.product_title
        newItem.relationship_type_code = itemObj.relationship_type_code
        newItem.tcin = itemObj.tcin
        newItem.sort_order = itemCount
        newItem.variation_theme_values = {}
        currentThemes.map((themeobj) => {
          newItem.variation_theme_values[themeobj.attribute] = ''
        })
        newItem.newelyAdded = true
        updatedItems.push(newItem)
      })
      return state
        .setIn(['groupDetails', 'items'], updatedItems)

    default:
      return state
  }
}
