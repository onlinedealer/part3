import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProfileConfigureComponent } from './profile-configure/profile-configure.component';
import { ProfileListingComponent } from './profile-listing/profile-listing.component';
import { ProfileResultsComponent } from './profile-results/profile-results.component';

const routes: Routes = [
  {
    path: '',
    component: ProfileListingComponent
  },
  {
    path: 'new',
    component: ProfileConfigureComponent
  },
  {
    path: 'edit/:profileId',
    component: ProfileConfigureComponent
  },
  {
    path: 'copy/:profileId',
    component: ProfileConfigureComponent
  },
  {
    path: 'profile-results/:profileName/:profileId',
    component: ProfileResultsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProfilingRoutingModule {}
