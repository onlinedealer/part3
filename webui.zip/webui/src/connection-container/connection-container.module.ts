import { NgModule } from '@angular/core';
import { ConnectionContainerComponent } from './connection-container.component';
import { SharedModule } from 'discovery-shared';
import { ConnectionRoutingModule } from './connection-container-routing.module';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { catalogLoader, connectLoader, sharedLoader } from 'core/i18n-loaders';
import { ConnectionListModule } from 'dqcore-catalog';

@NgModule({
  declarations: [ConnectionContainerComponent],
  imports: [SharedModule, ConnectionRoutingModule, ConnectionListModule],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'discoveryConnect', loader: connectLoader },
        { scope: 'discoveryShared', loader: sharedLoader },
        { scope: 'catalog', loader: catalogLoader }
      ]
    }
  ]
})
export class ConnectionContainerModule {}
