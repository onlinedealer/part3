import { AfterViewChecked, Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ObserverConstants } from 'observer/observer-constants';
import { WarningAlertModel } from '../warning-alert.model';
import { SliderModel } from './slider.model';

@Component({
  selector: 'discovery-slider',
  templateUrl: './slider.component.html',
  styleUrls: ['./slider.component.scss']
})
export class SliderComponent implements OnInit, AfterViewChecked {
  @Input() sliderSettings: SliderModel;
  @Output() threshold: EventEmitter<WarningAlertModel> = new EventEmitter<WarningAlertModel>();
  @ViewChild('slider', { static: true }) slider: ElementRef;
  selection = {
    lowerThreshold: 0,
    upperThreshold: 100
  };
  confidenceNoAlertString = {
    yellowAlert: ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.YELLOW,
    redAlert: ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.RED
  };
  thresholdNoAlertString = {
    yellowAlert: ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.YELLOW,
    redAlert: ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.RED
  };

  ngOnInit(): void {
    this.initialize();
  }

  ngAfterViewChecked() {
    const sliderElement = this.slider['el'].nativeElement.getElementsByClassName('p-slider-horizontal')[0];
    //use this.selection.lowerThreshold and this.selection.upperThreshold along with your colors to define background colors between sliders
    // eslint-disable-next-line max-len
    sliderElement.style.background = `linear-gradient(to right, #8A8A8A 20%, #6AC400 20% ${this.selection.lowerThreshold}%, #FFC400 ${this.selection.lowerThreshold}% ${this.selection.upperThreshold}%, #CB0350 ${this.selection.upperThreshold}%)`;
    const sliders = this.slider['el'].nativeElement.getElementsByClassName('p-slider-handle');

    this.sliderSettings.rangeValues.forEach((value: number, index) => {
      const tooltip =
        index === 0
          ? sliders[index].getElementsByClassName('slider-tooltip-lower')
          : sliders[index].getElementsByClassName('slider-tooltip-upper');

      // Update the DOM after the current change detection cycle runs.  Otherwise, this can cause an infinite loop.
      setTimeout(() => {
        if (tooltip.length === 0) {
          const el = document.createElement('span');
          el.className = index === 0 ? 'slider-tooltip-lower' : 'slider-tooltip-upper';
          el.innerHTML = value + '%';
          sliders[index].appendChild(el);
        } else {
          tooltip[0].innerHTML = this.sliderSettings.rangeValues[index] + '%';
        }
      });
    });
  }

  handleChange(e) {
    if (e.values[0] >= 20) {
      if (e.values[0] <= this.selection.upperThreshold) {
        this.selection.lowerThreshold = e.values[0];
      }
      if (e.values[1] >= this.selection.lowerThreshold) {
        this.selection.upperThreshold = e.values[1];
      }
    } else {
      this.selection.lowerThreshold = 20;
    }
    this.updateRanges();
  }

  onLowerThresholdChange(el) {
    const lowerThreshold = +el.value.replace(/\%/g, '');
    if (lowerThreshold !== 100 && el.value.length >= 4) {
      el.value = this.selection.upperThreshold.toString();
    }
    if (lowerThreshold > this.selection.upperThreshold) {
      el.value = this.selection.upperThreshold.toString();
    }
    if (this.sliderSettings.sliderVisible) {
      if (lowerThreshold >= 20) {
        this.selection.lowerThreshold = +el.value.replace(/\%/g, '');
      } else {
        this.selection.lowerThreshold = 20;
        el.value = '20';
      }
    } else {
      this.selection.lowerThreshold = +el.value.replace(/\%/g, '');
    }
    this.updateRanges();
  }

  onUpperThresholdChange(el) {
    const upperThreshold = +el.value.replace(/\%/g, '');
    if (upperThreshold <= 0) {
      el.value = this.selection.lowerThreshold.toString();
    }
    if (upperThreshold !== 100 && el.value.length >= 4) {
      el.value = this.selection.lowerThreshold.toString();
    }

    if (upperThreshold < this.selection.lowerThreshold) {
      el.value = this.selection.lowerThreshold.toString();
    }
    this.selection.upperThreshold = +el.value.replace(/\%/g, '');
    this.updateRanges();
  }

  initialize() {
    this.selection.lowerThreshold = this.sliderSettings?.rangeValues[0];
    this.selection.upperThreshold = this.sliderSettings?.rangeValues[1];
    this.confidenceNoAlertString.yellowAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.YELLOW;
    this.confidenceNoAlertString.redAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.RED;
    this.getAlertMessage();
  }

  private updateRanges() {
    this.sliderSettings.rangeValues = [this.selection.lowerThreshold, this.selection.upperThreshold];
    this.getAlertMessage();
    const warningAlert: WarningAlertModel = {
      minimum: this.selection.lowerThreshold,
      maximum: this.selection.upperThreshold
    };
    this.threshold.emit(warningAlert);
  }
  private getAlertMessage() {
    if (
      this.selection.lowerThreshold === this.selection.upperThreshold &&
      this.selection.lowerThreshold !== 100 &&
      this.selection.upperThreshold !== 100
    ) {
      if (this.sliderSettings.sliderVisible) {
        this.confidenceNoAlertString.yellowAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.NOYELLOW;
        this.confidenceNoAlertString.redAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.RED;
      } else {
        this.thresholdNoAlertString.yellowAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.NOYELLOW;
        this.thresholdNoAlertString.redAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.RED;
      }
    } else if (this.selection.upperThreshold === 100) {
      if (this.sliderSettings.sliderVisible && this.selection.lowerThreshold !== 100) {
        this.confidenceNoAlertString.redAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.NORED;
      } else {
        this.thresholdNoAlertString.yellowAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.YELLOW;
        this.thresholdNoAlertString.redAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.NORED;
      }
    } else {
      if (this.sliderSettings.sliderVisible) {
        this.confidenceNoAlertString.yellowAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.YELLOW;
        this.confidenceNoAlertString.redAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.RED;
      } else {
        this.thresholdNoAlertString.yellowAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.YELLOW;
        this.thresholdNoAlertString.redAlert = ObserverConstants.DATA_VOLUME_NO_ALERT_STRINGS.RED;
      }
    }
  }
}
