import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import * as fromContainers from "./containers";

export const MeteringPointsRoutes: Routes = [
    {
        path: "",
        component: fromContainers.MeteringPointsFeatureComponent,
        children: [
            {
                path: "details/:meteringPointId",
                component: fromContainers.MeteringPointSideviewContainerComponent,
                children: [
                    {
                        path: "",
                        pathMatch: "full",
                        redirectTo: "overview"
                    },
                    {
                        path: "overview",

                        children: [
                            {
                                path: "stateDetails"
                            },
                            {
                                path: "contracts"
                            },
                            {
                                path: "customProperties"
                            }
                        ]
                    },
                    {
                        path: "devices",

                        children: [
                            {
                                path: "relays"
                            },
                            {
                                path: "configurationsRegisters"
                            },
                            {
                                path: "transformer"
                            },
                            {
                                path: "parametersAndStatuses"
                            }
                        ]
                    },
                    {
                        path: "meterings",

                        children: [
                            {
                                path: "profile/:meteringId",

                                children: [
                                    {
                                        path: "table"
                                    },
                                    {
                                        path: "chart"
                                    }
                                ]
                            },

                            {
                                path: "periodic/:meteringId",
                                children: [
                                    {
                                        path: "table"
                                    },
                                    {
                                        path: "chart"
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        path: "events",

                        children: [
                            {
                                path: "eventtable"
                            },
                            {
                                path: "powerQuality",
                                children: [
                                    {
                                        path: "tableview"
                                    },
                                    {
                                        path: "chartview"
                                    }
                                ]
                            }
                        ]
                    },
                    {
                        path: "prepayment",

                        children: [
                            {
                                path: "table"
                            },
                            {
                                path: "chart"
                            },
                            {
                                path: "tokenLog"
                            }
                        ]
                    }
                ]
            }
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(MeteringPointsRoutes)],
    exports: [RouterModule]
})
export class MeteringPointsRoutingModule {}
