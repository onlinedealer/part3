import {Injectable} from "@angular/core";
import {Http, Response} from "@angular/http";
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from "rxjs";

@Injectable()
export class dataService {

  constructor(public http: Http) { 
  }

  public getFetchingData(): Observable<any> {
  	console.log("Service file called")
    let url = 'https://reqres.in/api/users?page=2';
    return this.http.get(url);
  }
}
