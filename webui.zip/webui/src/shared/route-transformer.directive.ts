import { Directive, ElementRef, HostListener } from '@angular/core';
import { Router } from '@angular/router';

@Directive({
  selector: '[discoveryRouteTransformer]'
})
export class RouteTransformerDirective {
  /**
   *
   * @param elementRef
   * @param uiRouter
   */
  constructor(private elementRef: ElementRef, private router: Router) {}

  /**
   *
   * @param mouseEvent
   */
  @HostListener('click', ['$event'])
  public onClick(mouseEvent: MouseEvent) {
    if ((mouseEvent.target as HTMLElement).tagName === 'A') {
      this.router.navigateByUrl([(mouseEvent.target as HTMLElement).getAttribute('routerLink')][0]);
      mouseEvent.preventDefault();
    }
  }
}
