import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormControl, FormsModule, ReactiveFormsModule, FormGroup, Validators } from '@angular/forms';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { Pipeline, PIPELINE_ENTITY_TYPE } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { PipelineFinalizeComponent } from './pipeline-finalize.component';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { PipelinesMonitoringApiService } from '../../shared/pipelines-monitoring-api.service';
import { EMPTY, of } from 'rxjs';
import { PipelinesMonitoringStatus } from '../../shared/pipelines-monitoring-status';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { By } from '@angular/platform-browser';
import { ResourcePermissionDirective } from '@shared/directives/resource-permission.directive';
import { ResourcePermissionService } from '@shared/services/resource-permission.service';
import { ProjectsApiService } from '../shared/projects-api.service';
import { Project } from '../shared/project';

describe('PipelineFinalizeComponent', () => {
  let component: PipelineFinalizeComponent;
  let fixture: ComponentFixture<PipelineFinalizeComponent>;
  let pipelineEntityService: PipelineEntityService;
  let pipelinesMonitoringApiService: PipelinesMonitoringApiService;
  let mockFeatureFlagService: any;
  let projectsApiService: ProjectsApiService;

  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['initiateProgressSteps', 'setActiveStepByRouterLink', 'setIsValid']
  );

  const mockedPipeline: Pipeline = {
    id: '1',
    name: 'pipeline',
    dataFlowType: 'type',
    description: 'description',
    properties: [],
    filters: [],
    source: {
      dataConnection: { name: 'source', connectionType: 'ORACLE' },
      selectedTables: [
        {
          key: 'schema1',
          value: {
            tableExtractType: '',
            tableAndKeys: [
              { tableName: 'test1', keys: [] },
              { tableName: 'test2', keys: [] }
            ]
          }
        }
      ]
    },
    target: { dataConnection: { name: 'target', connectionType: 'KAFKA' }, cdcRowMetadatas: [], parameters: [] }
  };

  beforeEach(async () => {
    mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);
    TestBed.overrideComponent(PipelineFinalizeComponent, {
      set: {
        providers: [
          { provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService },
          { provide: FeatureFlagService, useValue: mockFeatureFlagService }
        ]
      }
    });
    TestBed.overrideDirective(ResourcePermissionDirective, {
      set: {
        providers: [
          { provide: ResourcePermissionService, useValue: { hasResourcePermission: () => true, roles$: EMPTY, userResources$: EMPTY } }
        ]
      }
    });

    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule, HttpClientTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [PipelineFinalizeComponent, ResourcePermissionDirective]
    }).compileComponents();
  });

  describe('Replication', () => {
    beforeEach(() => {
      pipelineEntityService = TestBed.inject(PipelineEntityService);
      pipelinesMonitoringApiService = TestBed.inject(PipelinesMonitoringApiService);
      projectsApiService = TestBed.inject(ProjectsApiService);
      pipelineEntityService.setPipeline(mockedPipeline);
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockedPipeline);
      spyOn(pipelinesMonitoringApiService, 'getStatus').and.returnValue(
        of({ dataFlows: [{ captureStatus: 'OK' }] } as PipelinesMonitoringStatus)
      );
      spyOn(projectsApiService, 'get').and.returnValue(of({ name: 'abcd', id: 'abcd' } as Project));
      fixture = TestBed.createComponent(PipelineFinalizeComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.applyConfigurationFormGroup.addControl('stageChanges', new FormControl(true));
      component.applyConfigurationFormGroup.addControl('startPipeline', new FormControl(true));
    });

    it('should create', () => {
      component.ngAfterViewInit();
      expect(component).toBeTruthy();
    });

    it('should destroy', waitForAsync(() => {
      fixture.whenStable().then(() => {
        component.ngOnDestroy();
        expect(component.applyFormValueChanges$.closed).toBe(true);
        expect(component.pipelineChangedSubscription$.closed).toBe(true);
      });
    }));

    it('should set error message if downloadJclCompleted with errors', () => {
      component.downloadJclCompleted({ error: { message: 'error message' } });
      expect(component.deployErrorMessage).toBe('error message');
      component.downloadJclCompleted({ message: 'new error message' });
      expect(component.deployErrorMessage).toBe('new error message');
      component.downloadJclCompleted(null);
      expect(component.deployErrorMessage).toBe('');
    });

    it('should update summary information when pipeline changes', waitForAsync(() => {
      const pipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters: [],
        source: {
          dataConnection: { name: 'source', connectionType: 'ORACLE' },
          selectedTables: [
            {
              key: 'schema1',
              value: {
                tableExtractType: '',
                tableAndKeys: [
                  { tableName: 'test1', keys: [] },
                  { tableName: 'test2', keys: [] }
                ]
              }
            }
          ]
        },
        target: { dataConnection: { name: 'target', connectionType: 'KAFKA' }, cdcRowMetadatas: [], parameters: [] }
      };

      fixture.whenStable().then(() => {
        pipelineEntityService.setPipeline(pipeline);
        expect(component.summaryData.name).toBe('pipeline');
        expect(component.summaryData.selectedSourceData.noOfSchemasOrLibraries).toBe(1);
        expect(component.summaryData.selectedSourceData.noOfTables).toBe(2);
      });
    }));

    it('should disable stage changes flag if stage changes is not checked', waitForAsync(() => {
      component.applyConfigurationFormGroup.patchValue({ stageChanges: false });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isStageChangesEnabled).toBe(false);
        expect(component.applyConfigurationFormGroup.controls.deployChangesFormGroup.enabled).toBe(false);
      });
    }));

    it('should enable stage changes flag and deploy changes form if stage changes is checked', waitForAsync(() => {
      component.applyConfigurationFormGroup.patchValue({ stageChanges: true });
      component.stateChangesChanged(true);
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isStageChangesEnabled).toBe(true);
        expect(component.applyConfigurationFormGroup.controls.deployChangesFormGroup.enabled).toBe(true);
      });
    }));

    it('should enable deploy changes flag if deploy changes is checked', waitForAsync(() => {
      const fg = component.applyConfigurationFormGroup.controls.deployChangesFormGroup as FormGroup;
      fg.addControl('makeChangesActive', new FormControl(true));
      component.anyPipelinesComitted = true;
      component.stateChangesChanged(true);
      fg.patchValue({ makeChangesActive: true });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isDeployChangesEnabled).toBe(true);
      });
    }));

    it('should disable deploy changes flag if deploy changes is not checked', waitForAsync(() => {
      const fg = component.applyConfigurationFormGroup.controls.deployChangesFormGroup as FormGroup;
      fg.addControl('makeChangesActive', new FormControl(true));
      component.anyPipelinesComitted = true;
      component.stateChangesChanged(true);
      fg.patchValue({ makeChangesActive: false });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isDeployChangesEnabled).toBe(false);
      });
    }));

    it('should enable display alerts flag if deploy changes is checked and monitor progress is checked', waitForAsync(() => {
      const fg = component.applyConfigurationFormGroup.controls.deployChangesFormGroup as FormGroup;
      fg.addControl('makeChangesActive', new FormControl(true));
      fg.addControl('monitorProgress', new FormControl(false));
      component.anyPipelinesComitted = true;
      component.stateChangesChanged(true);
      fg.patchValue({ monitorProgress: true });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isDisplayAlertsEnabled).toBe(true);
      });
    }));

    it('should disable display alerts if deploy changes is not checked or monitor progress is not checked', waitForAsync(() => {
      const fg = component.applyConfigurationFormGroup.controls.deployChangesFormGroup as FormGroup;
      fg.addControl('makeChangesActive', new FormControl(true));
      fg.addControl('monitorProgress', new FormControl(true));
      component.anyPipelinesComitted = true;
      component.stateChangesChanged(true);
      fg.patchValue({ makeChangesActive: false });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isDisplayAlertsEnabled).toBe(false);
        fg.patchValue({ makeChangesActive: true });
        fg.patchValue({ monitorProgress: false });
        fixture.detectChanges();
        fixture.whenStable().then(() => {
          expect(pipelineEntityService.isDisplayAlertsEnabled).toBe(false);
        });
      });
    }));

    it('should disable finish button if deploy changes is checked and deploy form has an error', waitForAsync(() => {
      const fg = component.applyConfigurationFormGroup.controls.deployChangesFormGroup as FormGroup;
      fg.addControl('makeChangesActive', new FormControl(true));
      fg.addControl(
        'backlogEmpty',
        new FormControl('4', [Validators.required, Validators.min(4), Validators.max(999), Validators.pattern('^[0-9]*$')])
      );
      component.anyPipelinesComitted = true;
      component.stateChangesChanged(true);
      fg.patchValue({ makeChangesActive: true });
      fg.patchValue({ backlogEmpty: 3 });
      const finalizeStep = mockProgressIndicatorStateService.progressSteps?.findIndex((p) => p.id === 'finalize');
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(mockProgressIndicatorStateService.setIsValid).toHaveBeenCalledWith(finalizeStep, false);
      });
    }));

    it('should enable start pipeline flag if start pipeline is checked', waitForAsync(() => {
      component.applyConfigurationFormGroup.patchValue({ startPipeline: true });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isStartPipelineRequested).toBe(true);
      });
    }));

    it('should disable start pipeline flag if start pipeline is not checked', waitForAsync(() => {
      component.applyConfigurationFormGroup.patchValue({ startPipeline: false });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.isStartPipelineRequested).toBe(false);
      });
    }));

    it('should disable start pipeline flag if start pipeline is not checked with featureflag enabled for incremmental commit', waitForAsync(() => {
      mockFeatureFlagService.isFeatureEnabled.and.returnValue(true);
      component.applyConfigurationFormGroup.addControl('setStage', new FormControl('INCREMENTAL_COMMIT'));
      component.ngAfterViewInit();
      component.applyConfigurationFormGroup.patchValue({ startPipeline: false });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.incrementalStage).toEqual('INCREMENTAL_COMMIT');
      });
    }));

    it('should set deploy info if deploy changes is checked and force deployed is checked', waitForAsync(() => {
      const fg = component.applyConfigurationFormGroup.controls.deployChangesFormGroup as FormGroup;
      fg.addControl('makeChangesActive', new FormControl(true));
      fg.addControl('forceDeploy', new FormControl(true));
      fg.addControl('backlogEmpty', new FormControl(5));
      fg.addControl('tableCaptureDisabled', new FormControl(9));
      fg.addControl('replicationStopped', new FormControl(6));
      component.applyConfigurationFormGroup.patchValue({ startPipeline: false });
      component.anyPipelinesComitted = true;
      component.stateChangesChanged(true);
      fg.patchValue({ makeChangesActive: true });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.deployInfo.forceDeploy).toBe(true);
        expect(pipelineEntityService.deployInfo.queueTimeoutInMinutes).toBe(5);
        expect(pipelineEntityService.deployInfo.tableCaptureTimeoutInMinutes).toBe(9);
        expect(pipelineEntityService.deployInfo.stopRequestTimeoutInMinutes).toBe(6);
        expect(pipelineEntityService.deployInfo.dataFlowNames.length).toBe(0);
      });
    }));

    it('should set the pipeline to start if deploy changes is checked and start pipeline is checked', waitForAsync(() => {
      const fg = component.applyConfigurationFormGroup.controls.deployChangesFormGroup as FormGroup;
      fg.addControl('makeChangesActive', new FormControl(true));
      component.applyConfigurationFormGroup.patchValue({ startPipeline: true });
      component.anyPipelinesComitted = true;
      const pipelineName = 'pipeline1';
      component.pipelineName = pipelineName;
      component.stateChangesChanged(true);
      fg.patchValue({ makeChangesActive: true });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.deployInfo.dataFlowNames).toEqual([mockedPipeline.name]);
      });
    }));

    it('should disable start pipeline flag if start pipeline is not checked with featureflag enabled for incremmental commit', waitForAsync(() => {
      mockFeatureFlagService.isFeatureEnabled.and.returnValue(true);
      component.applyConfigurationFormGroup.addControl('setStage', new FormControl('INCREMENTAL_COMMIT'));
      component.ngAfterViewInit();
      component.applyConfigurationFormGroup.patchValue({ startPipeline: false });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(pipelineEntityService.incrementalStage).toEqual('INCREMENTAL_COMMIT');
      });
    }));

    it('should have 3 cards', async () => {
      fixture.detectChanges();
      await fixture.whenStable();
      expect(fixture.debugElement.queryAll(By.css('.card')).length).toBe(3);
    });
  });

  describe('Scheduled', () => {
    beforeEach(() => {
      pipelineEntityService = TestBed.inject(PipelineEntityService);
      pipelinesMonitoringApiService = TestBed.inject(PipelinesMonitoringApiService);
      projectsApiService = TestBed.inject(ProjectsApiService);
      pipelineEntityService.setPipeline(mockedPipeline);
      pipelineEntityService.pipelineEntityType = PIPELINE_ENTITY_TYPE.SCHEDULED;
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockedPipeline);
      spyOn(pipelinesMonitoringApiService, 'getStatus').and.returnValue(
        of({ dataFlows: [{ captureStatus: 'OK' }] } as PipelinesMonitoringStatus)
      );
      spyOn(projectsApiService, 'get').and.returnValue(of({ name: 'abcd', id: 'abcd' } as Project));
      fixture = TestBed.createComponent(PipelineFinalizeComponent);
      component = fixture.componentInstance;
      fixture.detectChanges();
      component.applyConfigurationFormGroup.addControl('stageChanges', new FormControl(true));
      component.applyConfigurationFormGroup.addControl('startPipeline', new FormControl(true));
    });

    it('should have 1 card', async () => {
      fixture.detectChanges();
      await fixture.whenStable();
      expect(fixture.debugElement.queryAll(By.css('.card')).length).toBe(1);
    });
  });
});
