import { Component, HostBinding, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SecondaryNavItemsService } from 'discovery-shared';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'discovery-connection-container',
  templateUrl: './connection-container.component.html'
})
export class ConnectionContainerComponent implements OnInit {
  @HostBinding('class') hostClasses = ['d-block'];

  navItems: MenuItem[];
  activeItem: MenuItem;
  constructor(private translocoService: TranslocoService, private navItemsService: SecondaryNavItemsService) {}

  ngOnInit(): void {
    this.navItems = this.navItemsService.getNavItems();
    this.activeItem = this.navItemsService.getActiveNav('do-data-connection');
  }
}
