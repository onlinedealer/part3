import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-expiring',
  templateUrl: './expiring.component.html',
  styleUrls: ['./expiring.component.scss']
})
export class ExpiringComponent implements OnInit {

  @Input() couponList: any ;

  constructor() { }

  ngOnInit() {
  }

}
