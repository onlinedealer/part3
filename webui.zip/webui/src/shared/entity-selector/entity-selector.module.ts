import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TableModule } from 'primeng/table';
import { EntityCardComponent } from './entity-card/entity-card.component';
import { EntityFilterComponent } from './filter/entity-filter.component';
import { DatasourceEntitySelectorComponent } from './datasource-entity-selector/datasource-entity-selector.component';
import { TriStateCheckboxModule } from 'primeng/tristatecheckbox';
import { FormsModule } from '@angular/forms';
import { TranslocoModule } from '@ngneat/transloco';
import { TooltipModule } from 'primeng/tooltip';

@NgModule({
  declarations: [EntityCardComponent, DatasourceEntitySelectorComponent, EntityFilterComponent],
  imports: [TableModule, CommonModule, TriStateCheckboxModule, FormsModule, TranslocoModule, TooltipModule],
  exports: [EntityCardComponent, DatasourceEntitySelectorComponent, EntityFilterComponent]
})
export class EntitySelectorModule {}
