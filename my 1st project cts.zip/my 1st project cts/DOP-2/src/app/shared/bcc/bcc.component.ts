import { element } from 'protractor';
import { Component, OnInit, Input } from '@angular/core';
import { AjaxUtilityService } from '../utility/ajax-utility.service';

@Component({
  selector: 'app-bcc',
  templateUrl: './bcc.component.html',
  styleUrls: ['./bcc.component.scss']
})
export class BccComponent implements OnInit {

  @Input() slotId:string;

  constructor(private ajaxutility:AjaxUtilityService) { }

  ngOnInit() {
    this.ajaxutility.sendRequest("bccContent",{},{contentId:"29910"}).subscribe((data) => {},
       err => {
         console.error(err);
       },
       () => {}
      )
  }

}
