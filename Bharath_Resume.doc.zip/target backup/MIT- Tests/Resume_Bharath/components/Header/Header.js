import React from 'react'
import {object, string, func} from 'prop-types'
import AppBar from 'material-ui/AppBar'
import IconButton from 'material-ui/IconButton'
import MenuIcon from 'material-ui-icons/Menu'
import Toolbar from 'material-ui/Toolbar'
import Typography from 'material-ui/Typography'
import { withStyles } from 'material-ui/styles'
import { appBarStyles } from 'react-praxis-components/SecondaryNav'

export function Header ({ classes, title, menuAction }) {
  return (
    <div className={classes.header}>
      <AppBar className={classes.appBar}>
        <Toolbar>
          { menuAction && (
            <IconButton onClick={menuAction} classes={{ root: classes.button }} aria-label="Menu">
              <MenuIcon />
            </IconButton>
          ) }
          <Typography variant="title" color="inherit">{title}</Typography>
        </Toolbar>
      </AppBar>
    </div>
  )
}

Header.displayName = 'Header'

Header.propTypes = {
  classes: object,
  title: string.isRequired,
  menuAction: func,
}

Header.defaultProps = {
  classes: {},
}

const styles = theme => ({
  header: {
    height: 56,
    [`${theme.breakpoints.up('xs')} and (orientation: landscape)`]: {
      height: 48,
    },
    [theme.breakpoints.up('sm')]: {
      height: 64,
    },
  },
  appBar: {
    ...appBarStyles,
  },
  logo: {
    height: 40,
    margin: '0 18px 0 6px',
    width: 35,
  },
  button: {
    color: theme.palette.primary.contrastText,
  },
})

export default withStyles(styles)(Header)
