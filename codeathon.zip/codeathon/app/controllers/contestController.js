(function() {
    'use strict';

    codeathonApp.controller("contestController", ['$scope', '$ajaxFactory', 'uiRouters', '$location', contestController]);

    function contestController($scope, $ajaxFactory, uiRouters, $location) {
        // Data Sources
        $scope.technologyDataSource = [];
        $scope.hostDataSource = [];
        $scope.domainDataSource = [];
        $scope.contestDataSource = [];
        $scope.contestQuestionsDataSource = [];
        // drop downs data
        $scope.contestTypeList = [];
        $scope.TeamTypeList = [];
        $scope.locationList = [];

        $scope.isEditOrAddPage = false;
        $scope.isAddPage = false;
        $scope.isQuestionsPage = false;
        $scope.buttonText = "";
        $scope.headerText = "";
        var contestId = "";
        var userId = "";
        var url = "";

        // Questions
        $scope.answersDefaultData = [{
            'label': "1",
            "value": "1"
        }, {
            'label': "2",
            "value": "2"
        }, {
            'label': "3",
            "value": "3"
        }, {
            'label': "4",
            "value": "4"
        }];
        $scope.questionTypeData = [];
        $scope.answersData = [];
        $scope.isChkBoxType = false;
        $scope.selectedQuestionType = "";
        $scope.questionText = "";
        $scope.questionMaxScore = "";
        $scope.isFirstanswerChecked = false;
        $scope.isSecondanswerChecked = false;
        $scope.isThirdanswerChecked = false;
        $scope.isFouranswerChecked = false;
        $scope.firstanswer = "";
        $scope.secondanswer = "";
        $scope.thirdanswer = "";
        $scope.fouranswer = "";
        $scope.firstanswerSelected = "";
        $scope.secondanswerSelected = "";
        $scope.thirdanswerSelected = "";
        $scope.fouranswerSelected = "";
        $scope.questionBtnText = "Add";
        $scope.questionHeader = "Create New";
        $scope.isDiaplyGrid = false;
        $scope.addorSavequestionItemData = "";


        // redirecting to /login page
        if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        };
        $scope.addOrSaveQuestion = function() {
            var index = $scope.contestQuestionsDataSource.indexOf($scope.addorSavequestionItemData);
            var obj = {};
            obj.question = $scope.questionText;
            obj.questionType = $scope.selectedQuestionType;
            obj.maxScore = $scope.questionMaxScore;
            obj.status = "";
            obj.sequence = 1;
            obj.answers = [];
            if ($scope.selectedQuestionType.toLowerCase() == 'checkbox') {
                var firstAnsObj = {};
                firstAnsObj.flag = $scope.isFirstanswerChecked;
                firstAnsObj.sequence = $scope.firstanswerSelected;
                firstAnsObj.answerText = $scope.firstanswer;
                obj.answers.push(firstAnsObj);

                var secondAnsObj = {};
                secondAnsObj.flag = $scope.isSecondanswerChecked;
                secondAnsObj.sequence = $scope.secondanswerSelected;
                secondAnsObj.answerText = $scope.secondanswer;
                obj.answers.push(secondAnsObj);

                var thirdAnsObj = {};
                thirdAnsObj.flag = $scope.isThirdanswerChecked;
                thirdAnsObj.sequence = $scope.thirdanswerSelected;
                thirdAnsObj.answerText = $scope.thirdanswer;
                obj.answers.push(thirdAnsObj);

                var fouthAnsObj = {};
                fouthAnsObj.flag = $scope.isFouranswerChecked;
                fouthAnsObj.sequence = $scope.fouranswerSelected;
                fouthAnsObj.answerText = $scope.fouranswer;
                obj.answers.push(fouthAnsObj);
            }
            if (index > 0) {
                var tempObj = $scope.contestQuestionsDataSource[index];
                obj.id = tempObj.id;
                obj.status = tempObj.status;
                $scope.contestQuestionsDataSource.splice(index, 1);
                $scope.contestQuestionsDataSource.splice(index, 0, obj);
            } else {
                $scope.contestQuestionsDataSource.push(obj);
            }

            $scope.firstanswer = "";
            $scope.secondanswer = "";
            $scope.thirdanswer = "";
            $scope.fouranswer = "";
            $scope.firstanswerSelected = "";
            $scope.secondanswerSelected = "";
            $scope.thirdanswerSelected = "";
            $scope.fouranswerSelected = "";
            $scope.questionText = "";
            $scope.questionMaxScore = "";
            $scope.selectedQuestionType = "";
            $scope.isFirstanswerChecked = false;
            $scope.isSecondanswerChecked = false;
            $scope.isThirdanswerChecked = false;
            $scope.isFouranswerChecked = false;
        };
        $scope.deleteItem = function(id) {
            //url = "/delete/contest/"+contestId+"question/"+id+"/user/" + userId + "/";            
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/contest/questions.json', 'POST', {});

            promise.then(function(d) {
                $scope.contestQuestionsDataSource = d;

            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        }
        $scope.questionTypeChange = function() {
            $scope.isChkBoxType = false;
            if ($scope.selectedQuestionType.toLowerCase() == 'checkbox') {
                $scope.isChkBoxType = true;
            }
        };
        $scope.saveAnswers = function() {
            if ($scope.questionBtnText == "Add") {
                $scope.contestQuestionsDataSource = [];
                $scope.addOrSaveQuestion();
            }
            indicatorStart("Loading....");
            $scope.resetDefaultValues();

            //url = "add/questions/contest/"+contestId+"/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/contest/questions.json', 'POST', $scope.contestQuestionsDataSource);

            promise.then(function(d) {
                $scope.contestQuestionsDataSource = d;
                $scope.isEditOrAddPage = false;
                $scope.isAddPage = false;
                $scope.isQuestionsPage = false;

            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });

        };
        $scope.expandAnswer = function(item) {
            $scope.isChkBoxType = false;
            $scope.isFirstanswerChecked = false;
            $scope.isSecondanswerChecked = false;
            $scope.isThirdanswerChecked = false;
            $scope.isFouranswerChecked = false;
            //$scope.questionBtnText ="Save";
            $scope.questionText = item.question;
            $scope.questionMaxScore = item.maxScore;
            $scope.selectedQuestionType = item.questionType;
            $scope.addorSavequestionItemData = item;
            if ($scope.selectedQuestionType.toLowerCase() == 'checkbox') {
                $scope.isChkBoxType = true;
                var ansObj = item.answers;
                if (!Codeathon.utils.isNullOrEmpty(ansObj) && ansObj.length > 0) {
                    $scope.isFirstanswerChecked = ansObj[0].flag;
                    $scope.isSecondanswerChecked = ansObj[1].flag;
                    $scope.isThirdanswerChecked = ansObj[2].flag;
                    $scope.isFouranswerChecked = ansObj[3].flag;

                    $scope.firstanswer = ansObj[0].answerText;
                    $scope.secondanswer = ansObj[1].answerText;
                    $scope.thirdanswer = ansObj[2].answerText;
                    $scope.fouranswer = ansObj[3].answerText;

                    $scope.firstanswerSelected = ansObj[0].sequence;
                    $scope.secondanswerSelected = ansObj[1].sequence;
                    $scope.thirdanswerSelected = ansObj[2].sequence;
                    $scope.fouranswerSelected = ansObj[3].sequence;

                }

            }
        };
        $scope.addQuestions = function(id) {
            indicatorStart("Loading....");
            $scope.isQuestionsPage = true;
            $scope.isEditOrAddPage = false;
            contestId = id;
            //url = " /view/questions/contest/" + id + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/contest/questions.json', 'GET', {});

            promise.then(function(d) {
                $scope.contestQuestionsDataSource = d;
                $scope.questionTypeData = Codeathon.utils.getListByProperty(d, 'questionType', 'questionType');

            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };
        $scope.editItem = function(item) {
            $scope.resetDefaultValues();
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = false;
            $scope.buttonText = "Update";
            $scope.headerText = "Edit";
            $scope.questionHeader = "Edit";

            //url = " /view/contest/" + item.id + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/contest/edit.json', 'GET', {});

            promise.then(function(d) {
                $scope.contestTypeValue = d.contestType;
                $scope.TeamTypeValue = d.teamType;
                $scope.locationValue = d.location;
                $scope.contestName = d.contestName;
                $scope.contestDesc = d.description;
                $scope.contestPeriodStart = d.fromDate;
                $scope.contestPeriodEnd = d.toDate;
                $scope.contestCycleData = d.contestCycle;
                $scope.registrationRequired = (Codeathon.utils.isNullOrEmpty(d.registration)) ? false : true;
                $scope.applicationRequired = (Codeathon.utils.isNullOrEmpty(d.application)) ? false : true;
                $scope.hostDataSource = Codeathon.utils.makeChecked($scope.hostDataSource, d.host);
                $scope.domainDataSource = Codeathon.utils.makeChecked($scope.domainDataSource, d.domain);
                $scope.technologyDataSource = Codeathon.utils.makeChecked($scope.technologyDataSource, d.technology);

                $scope.selectedHostData = d.host;
                $scope.selectedDoaminData = d.domain;
                $scope.selectedTechData = d.technology;

                contestId = item.id;


            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.removeItem = function(contestId) {
            indicatorStart("Deleting contest..");
            url = "/delete/contest/" + contestId + "/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'POST', {});

            promise.then(function(d) {
                $scope.contestDataSource = d;
                console.log('Delete Success');
                $scope.fetchDataSource();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.saveAction = function() {
            if (Codeathon.utils.isNullOrEmpty($scope.contestTypeValue) || Codeathon.utils.isNullOrEmpty($scope.TeamTypeValue) ||
                Codeathon.utils.isNullOrEmpty($scope.locationValue) || Codeathon.utils.isNullOrEmpty($scope.contestName) ||
                Codeathon.utils.isNullOrEmpty($scope.contestDesc)
            ) {
                alert("All Fields Required");
                return;
            }
            var obj = {};
            obj.contestName = $scope.contestName;
            obj.description = $scope.contestDesc;
            obj.contestType = $scope.contestTypeValue;
            obj.teamType = $scope.TeamTypeValue;
            obj.location = $scope.locationValue;
            obj.domain = JSON.stringify($scope.selectedDoaminData);
            obj.host = JSON.stringify($scope.selectedHostData);
            obj.technology = JSON.stringify($scope.selectedTechData);
            obj.registrationApproval = ($scope.registrationRequired) ? 1 : 0;
            obj.applicationApproval = ($scope.applicationRequired) ? 1 : 0;
            obj.startDate = $scope.contestPeriodStart;
            obj.expiryDate = $scope.contestPeriodEnd;
            obj.contestCycle = JSON.stringify($scope.contestCycleData);


            // if isAddPage true : Adding New Contest
            // if isAddPage False : Editing Contest
            if ($scope.isAddPage) {
                indicatorStart("Adding Contest..");
                url = uiRouters.urlpath + "/add/new/contest/user/" + userId + "/";

            } else {
                indicatorStart("Updating Contest..");
                url = uiRouters.urlpath + "/modify/contest/" + contestId + "/user/" + userId + "/";
                $scope.isDiaplyGrid = true;
            }
            var url = uiRouters.filepath + '/contest/contestIdTest.json';

            var promise = $ajaxFactory.getDataFromServer(url, 'POST', obj);

            promise.then(function(d) {
                $scope.hostDataSource = d;
                $scope.isEditOrAddPage = false;
                $scope.isAddPage = false;
                console.log('Success');
                // adding Questions 
                $scope.addQuestions(d.contestId);
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.removeTypeItem = function(item) {
            var index = $scope.contestCycleData.indexOf(item);
            $scope.contestCycleData.splice(index, 1);
        };

        $scope.moveUp = function(incrementNo, ItemData) {
            var data = $scope.contestCycleData;
            var index = $scope.contestQuestionsDataSource.indexOf(ItemData);
            console.log(index);
            if (index > 0) {
                var tempObj = $scope.contestQuestionsDataSource[index];
                if (incrementNo == 1) {
                    $scope.contestQuestionsDataSource.splice(index, 1);
                    $scope.contestQuestionsDataSource.splice((index - 1), 0, tempObj);
                }

                if (incrementNo == 2 && index > 1) {
                    $scope.contestQuestionsDataSource.splice(index, 1);
                    $scope.contestQuestionsDataSource.splice((index - 2), 0, tempObj);
                }
            }
        };

        $scope.addNew = function() {
            if (Codeathon.utils.isNullOrEmpty($scope.cycleName) || Codeathon.utils.isNullOrEmpty($scope.cycleDesc) ||
                Codeathon.utils.isNullOrEmpty($scope.cyclePeriodStart) || Codeathon.utils.isNullOrEmpty($scope.cyclePeriodEnd)) {
                alert("All Contest Cycle Fields Required");
                return;
            }
            var obj = {}
            obj.name = $scope.cycleName;
            obj.description = $scope.cycleDesc;
            obj.fromDate = $scope.cyclePeriodStart;
            obj.toDate = $scope.cyclePeriodEnd;
            obj.detail = "";
            $scope.contestCycleData.push(obj);
        };

        $scope.cancelNew = function() {
            $scope.cycleName = "";
            $scope.cycleDesc = "";
            $scope.cyclePeriodStart = "";
            $scope.cyclePeriodEnd = "";
        };

        $scope.resetDefaultValues = function() {
            $scope.contestTypeValue = "";
            $scope.TeamTypeValue = "";
            $scope.locationValue = "";
            $scope.contestName = "";
            $scope.contestDesc = "";
            $scope.registrationRequired = false;
            $scope.applicationRequired = false;
            $scope.contestPeriodStart = "";
            $scope.contestPeriodEnd = "";
            $scope.maxScore = "";
            $scope.cycleName = "";
            $scope.cycleDesc = "";
            $scope.cyclePeriodStart = "";
            $scope.cyclePeriodEnd = "";
            $scope.selectedHostData = [];
            $scope.selectedDoaminData = [];
            $scope.selectedTechData = [];
            $scope.contestCycleData = [];
            $scope.hostDataSource = Codeathon.utils.makeUnChecked($scope.hostDataSource);
            $scope.domainDataSource = Codeathon.utils.makeUnChecked($scope.domainDataSource);
            $scope.technologyDataSource = Codeathon.utils.makeUnChecked($scope.technologyDataSource);
            $scope.questionTypeData = [];
            $scope.contestQuestionsDataSource = [];
            $scope.answersData = [];
            $scope.selectedQuestionType = "";
            $scope.questionText = "";
            $scope.questionMaxScore = "";
            $scope.isChkBoxType = false;
            $scope.isFirstanswerChecked = false;
            $scope.isSecondanswerChecked = false;
            $scope.isThirdanswerChecked = false;
            $scope.isFouranswerChecked = false;
            $scope.firstanswer = "";
            $scope.secondanswer = "";
            $scope.thirdanswer = "";
            $scope.fouranswer = "";
            $scope.firstanswerSelected = "";
            $scope.secondanswerSelected = "";
            $scope.thirdanswerSelected = "";
            $scope.fouranswerSelected = "";
            $scope.questionBtnText = "Add";
            $scope.questionHeader = "";
            $scope.isDiaplyGrid = false;
            $scope.addorSavequestionItemData = "";
        };

        $scope.addItem = function() {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = true;
            $scope.buttonText = "Add";
            $scope.headerText = "Create";
            $scope.resetDefaultValues();
        };

        $scope.fetchDataSource = function() {
            indicatorStart("Loading....");
            var url = "/list/active/contests/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/contest/data.json', 'GET', {});
            // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.contestDataSource = d;
                $scope.contestTypeList = Codeathon.utils.getListByProperty(d, 'type', 'type');
                $scope.TeamTypeList = Codeathon.utils.getListByProperty(d, 'participation', 'participation');
                $scope.locationList = Codeathon.utils.getListByProperty(d, 'id', 'location');
            });
            promise.catch(function(d) {
                return d;
            });
            promise.finally(function(d) {
                indicatorStop();
            });
        };

        $scope.fetchDomainDataSource = function() {

            url = "/get/list/of/domain/for/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/domain/data.json', 'GET', {});
            // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.domainDataSource = Codeathon.utils.getListByProperty(d, 'id', 'domainName');
            });
            promise.catch(function(d) {
                return d;
            });
            promise.finally(function(d) {
                indicatorStop();
            });
        };

        $scope.fetchHostDataSource = function() {
            var url = "/get/list/of/host/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/host/data.json', 'GET', {});
            //var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.hostDataSource = Codeathon.utils.getListByProperty(d, 'id', 'name');
            });
            promise.catch(function(d) {
                return d;
            });
            promise.finally(function(d) {
                indicatorStop();
            });
        };

        $scope.fetchTechnologyDataSource = function() {
            url = "/get/list/of/technology/user/" + userId + "/";
            // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/technology/data.json', 'GET', {});

            promise.then(function(d) {
                $scope.technologyDataSource = Codeathon.utils.getListByProperty(d, 'id', 'techName');
            });
            promise.catch(function(d) {
                return d;
            });
            promise.finally(function(d) {
                indicatorStop();
            });
        };

        $scope.cancel = function() {
            $scope.isEditOrAddPage = false;
            $scope.isAddPage = false;
            $scope.isQuestionsPage = false;
            $scope.resetDefaultValues();
        };

        $scope.selectDomainItem = function(value) {
            $scope.selectedDoaminData.push(value);
        };

        $scope.selectHostItem = function(value) {
            $scope.selectedHostData.push(value);
        };

        $scope.selectTechItem = function(value) {
            $scope.selectedTechData.push(value);
        };

        $scope.loadCalenders = function() {

            $('.form-field input.datefield').datepicker({
                autoclose: true,
                format: 'yyyy/mm/dd'
            });

            $('.form-field input.datefield').on('show', function(e) {
                /* if(!Codeathon.utils.isNullOrEmpty($(this).val())){
                     e.date = new Date($(this).val());
                 }*/
                if (e.date) {
                    $(this).data('stickyDate', e.date);
                } else {
                    $(this).data('stickyDate', null);
                }
            });

            $('.form-field input.datefield').on('hide', function(e) {
                var stickyDate = $(this).data('stickyDate');
                if (!e.date && stickyDate) {
                    $(this).datepicker('setDate', stickyDate);
                    $(this).data('stickyDate', null);
                }
            });
        };
        $scope.resetDefaultValues();
        $scope.fetchDataSource();
        $scope.fetchDomainDataSource();
        $scope.fetchHostDataSource();
        $scope.fetchTechnologyDataSource();
        $scope.loadCalenders();
    }

})();
