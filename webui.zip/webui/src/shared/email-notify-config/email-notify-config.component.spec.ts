import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormGroup, Validators } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { TranslocoModule } from '@ngneat/transloco';
import { NotifyConfig } from 'core/models/notification-config/email-config.model';
import { AuthenticationService, SharedModule } from 'discovery-shared';
import { Spies } from 'discovery-test';

import { EmailNotifyConfigComponent } from './email-notify-config.component';

const MockEnabledConfig: NotifyConfig = {
  notifications: [
    {
      recipients: [],
      type: 'email',
      enabled: true
    }
  ]
};
const MockDisabledConfig: NotifyConfig = {
  notifications: [
    {
      recipients: [],
      type: 'email',
      enabled: false
    }
  ]
};

function immutableMock(mockObj: Object) {
  return JSON.parse(JSON.stringify(mockObj));
}

describe('EmailNotifyConfigComponent', () => {
  let component: EmailNotifyConfigComponent;
  let fixture: ComponentFixture<EmailNotifyConfigComponent>;

  beforeEach(async () => {
    Spies.init();
    await TestBed.configureTestingModule({
      imports: [CommonModule, TranslocoModule, SharedModule],
      declarations: [EmailNotifyConfigComponent],
      providers: [{ provide: AuthenticationService, useValue: Spies.AuthenticationService }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailNotifyConfigComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    component.emailConfigForm.get('recipients').setValue(null);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should create Email config form with `recipients` and `emailNotifyEnabled` formControls', () => {
    const form: FormGroup = component.createForm();
    expect(form).toBeTruthy();
    expect(form.get('recipients')).toBeTruthy();
    expect(form.get('emailNotifyEnabled')).toBeTruthy();
    expect(component.emailConfigForm).toBeTruthy();
  });

  /**
   * test case for `isFormValid`
   */
  it('should validate `false` recipient if notification ENABLED and no email present', () => {
    component.notifConfig = immutableMock(MockEnabledConfig);
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.onSubmitForm();
    expect(component.isFormValid).toBeFalsy();
  });

  it('should validate `false` recipient if notification ENABLED and if recipients more than 25 ', () => {
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockEnabledConfig);
    component.emailConfigForm.get('recipients').setValue(new Array(26));
    component.onSubmitForm();
    expect(component.isFormValid).toBeFalsy();
  });

  it('should validate `false` recipient if notification ENABLED and if any invalid email present ', () => {
    component.invalidEmailPool.length = 1;
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockEnabledConfig);
    component.onSubmitForm();
    expect(component.isFormValid).toBeFalsy();
  });

  it('should validate `false` recipient if notification DISABLED but invalid email present ', () => {
    component.invalidEmailPool.length = 1;
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockDisabledConfig);
    component.onSubmitForm();
    expect(component.isFormValid).toBeFalsy();
  });

  it('should validate `false` recipient if notification DISABLED but recipient list is more than 25 ', () => {
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockDisabledConfig);
    component.emailConfigForm.get('recipients').setValue(new Array(26));
    component.onSubmitForm();
    expect(component.isFormValid).toBeFalsy();
  });

  it('should validate `true` recipient if notification ENABLED and email are present ', () => {
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockDisabledConfig);
    component.emailConfigForm.get('recipients').setValue(['test@mail.com']);
    component.onSubmitForm();
    expect(component.isFormValid).toBeTruthy();
  });

  it('should validate `true` recipient if notification DISABLED and no email present ', () => {
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockDisabledConfig);
    component.onSubmitForm();
    expect(component.isFormValid).toBeTruthy();
  });

  it('should return `false` recipient if notification ENABLED and no email present', () => {
    component.notifConfig = MockEnabledConfig;
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.onSubmitForm();
    expect(component.isFormValid).toBeFalsy();
  });

  it('should have at least one email if config is ENABLED', () => {
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockEnabledConfig);
    component.onSubmitForm();
    fixture.detectChanges();
    const errorElem = fixture.debugElement.query(By.css('#recipient-email-min-limit'));
    expect(component.emailConfigForm.get('recipients').errors).not.toBeNull();
    expect(errorElem).toBeTruthy();
  });

  it('should have email separator as `,`(Comma) for copy paste multiple email', () => {
    expect(component.emailSeparator).toBe(',');
  });

  it('should return true if email is correct ', () => {
    const email = 'test@mail.com';
    const isValid = component.validateEmail(email);
    expect(isValid).toBeTruthy();
  });

  it('should return false if email is incorrect ', () => {
    const isValid = component.validateEmail('test.com');
    expect(isValid).toBeFalsy();
  });

  it('getter should return true if no recipient ', () => {
    component.notifConfig = immutableMock(MockEnabledConfig);
    component.emailConfigForm.get('recipients').setValue(null);
    fixture.detectChanges();
    const isValid = component.hasRecipientError;
    expect(isValid).toBeTruthy();
  });

  it('getter should return false if has recipient ', () => {
    component.emailConfigForm.get('recipients').setValue(['test@gmail.com']);
    const isValid = component.hasRecipientError;
    expect(isValid).toBeFalsy();
  });

  it('should return true if has recipient list more than 25 ', () => {
    component.emailConfigForm.get('recipients').setValue(new Array(26));
    component.onSubmitForm();
    fixture.detectChanges();
    const reachedLimit = component.maxRecipientLimit;
    const errorElem = fixture.debugElement.query(By.css('#recipient-email-max-limit'));
    expect(errorElem).toBeTruthy();
    expect(reachedLimit).toBeTruthy();
  });

  it('should return invalid email list ', () => {
    component.emailConfigForm.get('recipients').setValue(['a', 'b', 'c']);
    component.setInvalidEmailList();
    expect(component.invalidEmailList).toBe('a, b, c');
  });

  it('should display error on HTML for max email list ', () => {
    component.emailConfigForm.get('recipients').setValue(['a', 'b', 'c']);
    component.setInvalidEmailList();
    fixture.detectChanges();
    const errorElem = fixture.debugElement.query(By.css('#invalid-email-list'));
    expect(component.invalidEmailList).toBe('a, b, c');
    expect(errorElem).toBeTruthy();
  });

  it('should update Valition for recipient ', () => {
    component.updateValidation(true);
    expect(component.emailConfigForm.get('recipients').hasValidator(Validators.required)).toBeTrue();
    component.updateValidation(false);
    expect(component.emailConfigForm.get('recipients').errors).toBeNull();
  });

  it('should set invalid email list after filter ', () => {
    component.emailConfigForm.get('recipients').setValue(['a', 'test@gmail.com', 'c']);
    component.setInvalidEmailList();
    expect(component.invalidEmailPool.length).toBe(2);
  });

  it('should update original notifConfig Object only if form is Valid ', () => {
    component.notifConfig = immutableMock(MockEnabledConfig);
    component.emailConfigForm.get('recipients').setValue(['test@gmail.com']);
    component.onSubmitForm();
    expect(component.notifConfig.notifications[0].recipients).toEqual(['test@gmail.com']);
    expect(component.notifConfig.notifications[0].enabled).toBeTrue();
  });

  it('should not set default email if config is DISABLED ', () => {
    Spies.AuthenticationService.getEmail.and.returnValue(null);
    component.notifConfig = immutableMock(MockDisabledConfig);
    const recipients = component.emailConfigForm.get('recipients').value;
    expect(recipients).toBeNull();
  });

  it('should set default email if config is ENABLED ', () => {
    Spies.AuthenticationService.getEmail.and.returnValue('enabledconfig@test.com');
    component.notifConfig = immutableMock(MockEnabledConfig);
    const recipients = component.emailConfigForm.get('recipients').value;
    expect(recipients).toEqual(['enabledconfig@test.com']);
  });

  it('should remove duplicate emails on Add and display unique emails ', () => {
    const duplicateEmails = ['test1@mail.com', 'test2@mail.com', 'test1@mail.com', 'test2@mail.com', 'test3@mail.com'];
    const uniqueEmails = ['test1@mail.com', 'test2@mail.com', 'test3@mail.com'];
    component.emailConfigForm.get('recipients').setValue(duplicateEmails);
    component.onAddEmail();
    const recipients = component.emailConfigForm.get('recipients').value;
    expect(recipients).toEqual(uniqueEmails);
  });

  it('should set emails after trimming whitespaces', () => {
    const emailWithWhitespace = ['   testtrimm1@mail.com', '  testtrim2@mail.com  ', 'testtrim3@mail.com    '];
    const expectedEmails = ['testtrimm1@mail.com', 'testtrim2@mail.com', 'testtrim3@mail.com'];
    component.emailConfigForm.get('recipients').setValue(emailWithWhitespace);
    component.onAddEmail();
    const recipients = component.emailConfigForm.get('recipients').value;
    expect(recipients).toEqual(expectedEmails);
  });

  it('should report invalid emails on add', () => {
    const emailList = [
      'valid@mail.com',
      'valid_user_name@mail.com',
      'valid_user+name@mail.com',
      'valid_user.name@mail.com',
      'valid_user_name@mail.com',
      'valid_user22name@mail.com',
      'subdomain_test@test.domain.shop',
      '$dollarSign@test.domain.shop',
      '.usernamestartwithdot@email.com',
      'havingtwo..consecutivedotsintheusername@email.com',
      'login@dom1.dom2.dom-3.dom-4.',
      'lama.loca.loca123@inca.com,',
      'test@mail@mail'
    ];
    const expectedInValidEmails = [
      '.usernamestartwithdot@email.com',
      'havingtwo..consecutivedotsintheusername@email.com',
      'login@dom1.dom2.dom-3.dom-4.',
      'lama.loca.loca123@inca.com,',
      'test@mail@mail'
    ];
    component.emailConfigForm.get('recipients').setValue(emailList);
    component.onAddEmail();
    expect(component.invalidEmailPool).toEqual(expectedInValidEmails);
  });

  it('should set emails in lowercase', () => {
    const duplicateEmailsWithDifferentCase = [
      'test1@mail.com',
      'test2@mail.com',
      'TEst1@mail.com',
      'TEST2@mail.com',
      'test3@mail.com'
    ];
    const uniqueEmails = ['test1@mail.com', 'test2@mail.com', 'test3@mail.com'];
    component.emailConfigForm.get('recipients').setValue(duplicateEmailsWithDifferentCase);
    component.onAddEmail();
    const recipients = component.emailConfigForm.get('recipients').value;
    expect(recipients).toEqual(uniqueEmails);
  });
});
