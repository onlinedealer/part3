import React from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
import Select from 'react-select'
import { withStyles } from '@material-ui/core/styles'
import FormLabel from '@material-ui/core/FormLabel'
import Typography from '@material-ui/core/Typography'
// import NoSsr from '@material-ui/core/NoSsr';
import TextField from '@material-ui/core/TextField'
import Chip from '@material-ui/core/Chip'
import MenuItem from '@material-ui/core/MenuItem'
import { emphasize } from '@material-ui/core/styles/colorManipulator'

const styles = theme => ({
  root: {
    flexGrow: 1,
    width: '280px',
  },
  input: {
    display: 'flex',
    padding: 0,
    width: '280px',
  },
  input1: {
    display: 'flex',
    padding: 0,
    width: '250px',
  },
  valueContainer: {
    display: 'flex',
    flex: 1,
    alignItems: 'center',
  },
  selectLabel: {
    color: 'rgba(0, 0, 0, 0.54)',
    lineHeight: 1.2,
    fontSize: '12px',
    marginBottom: '0',
  },
  chip: {
    margin: `${theme.spacing.unit / 2}px ${theme.spacing.unit / 4}px`,
  },
  chipFocused: {
    backgroundColor: emphasize(
      theme.palette.type === 'light' ? theme.palette.grey[300] : theme.palette.grey[700],
      0.08,
    ),
  },
  noOptionsMessage: {
    fontSize: 16,
    padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`,
  },
  options: {
    position: 'fixed',
  },
  singleValue: {
    fontSize: 16,
  },
  inputRoot: {
    width: '100%',
  },
  placeholder: {
    position: 'absolute',
    left: 2,
    fontSize: 16,
  },
})

function NoOptionsMessage (props) {
  return (
    <Typography
      color="textSecondary"
      className={props.selectProps.classes.noOptionsMessage}
      {...props.innerProps}
    >
      {props.children}
    </Typography>
  )
}

function inputComponent ({ inputRef, ...props }) {
  return <div ref={inputRef} {...props} />
}

function Control (props) {
  return (
    <TextField
      InputProps={{
        inputComponent,
        inputProps: {
          className: (props.selectProps.inputType === 2) ? props.selectProps.classes.input1 : props.selectProps.classes.input,
          ref: props.innerRef,
          children: props.children,
          ...props.innerProps,
        },
      }}
    />
  )
}

function Option (props) {
  return (
    <MenuItem
      buttonRef={props.innerRef}
      selected={props.isFocused}
      component="div"
      style={{
        fontWeight: props.isSelected ? 500 : 400,
      }}
      {...props.innerProps}
    >
      {props.children}
    </MenuItem>
  )
}

function Placeholder (props) {
  return (
    <Typography
      color="textSecondary"
      className={props.selectProps.classes.placeholder}
      {...props.innerProps}
    >
      {props.children}
    </Typography>
  )
}

function SingleValue (props) {
  return (
    <Typography className={props.selectProps.classes.singleValue} {...props.innerProps}>
      {props.children}
    </Typography>
  )
}

function ValueContainer (props) {
  return <div className={props.selectProps.classes.valueContainer}>{props.children}</div>
}

function MultiValue (props) {
  return (
    <Chip
      tabIndex={-1}
      label={props.children}
      className={classNames(props.selectProps.classes.chip, {
        [props.selectProps.classes.chipFocused]: props.isFocused,
      })}
      onDelete={event => {
        props.removeProps.onClick()
        props.removeProps.onMouseDown(event)
      }}
    />
  )
}

const components = {
  Option,
  Control,
  NoOptionsMessage,
  Placeholder,
  SingleValue,
  MultiValue,
  ValueContainer,
}

class GrouperAutoComplete extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      currentValue: {value: '', label: ''},
      isMultiOption: false,
    }
  }

  componentWillMount () {
    if (this.props.currentValue !== this.state.currentValue.value) {
      if (!this.props.currentValue) {
        this.setState({ currentValue: {value: '', label: ''} })
      } else {
        const selected = this.props.options.filter((optn) => {
          return optn.value === this.props.currentValue
        })
        if (selected.length > 0) { this.setState({ currentValue: selected[0] }) }
      }
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.currentValue !== this.state.currentValue.value) {
      if (!nextProps.currentValue) {
        this.setState({ currentValue: {value: '', label: ''} })
      } else {
        const selected = nextProps.options.filter((optn) => {
          return optn.value === nextProps.currentValue
        })
        if (selected.length > 0) { this.setState({ currentValue: selected[0] }) }
      }
    }
  }

  handleChange = name => changedValue => {
    if (this.state.isMultiOption) {
      this.setState({
        [name]: changedValue,
      })
      let changedSelected = []
      changedValue.map((option) => {
        changedSelected.push(option.value)
        this.props.handleSelectChange(this.props.column_id, option.value)
      })
      this.setState({
        [name]: changedSelected,
      })
    } else {
      if (changedValue && changedValue.value) {
        // this.setState({
        //   [name]: changedValue,
        // })
        this.props.handleSelectChange(this.props.column_id, changedValue.value)
      } else {
        this.props.handleSelectChange(this.props.column_id, '')
      }
    }
  };
  handlekeyDown = evt => {
    let tarVal = evt.target
    setTimeout(() => {
      if (typeof this.props.handlekeyDown === 'function') {
        this.props.handlekeyDown(this.props.column_id, tarVal.value)
      }
    }, 300)
  }

  render () {
    const { classes } = this.props
    return (
      <div className={classes.root}>
        <FormLabel component="legend" className={classes.selectLabel}>{this.props.placeholderMsg}</FormLabel>
        <Select
          classes={classes}
          textFieldProps={{
            label: 'welcome',
            InputLabelProps: {
              shrink: true,
            },
          }}
          disabled
          options={this.props.options}
          value={this.state.currentValue}
          components={components}
          onChange={this.handleChange('currentValue')}
          onKeyDown={this.handlekeyDown.bind(this)}
          isMulti={this.state.isMultiOption}
          inputType={this.props.inputType}
          placeholder="Select multiple countries"
        />
      </div>
    )
  }
}

GrouperAutoComplete.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(GrouperAutoComplete)
