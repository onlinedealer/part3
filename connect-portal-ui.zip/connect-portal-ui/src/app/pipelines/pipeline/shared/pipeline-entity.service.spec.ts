import { TestBed } from '@angular/core/testing';
import { Filter } from '../filters/filter';
import { Pipeline } from './pipeline';
import { PipelineEntityService } from './pipeline-entity.service';

describe('PipelineEntityService', () => {
  let service: PipelineEntityService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(PipelineEntityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  describe('getPipelineChanges', () => {
    it('should console log any changes', () => {
      const pipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters: []
      };
      service.setPipeline(pipeline);
      service.patchPipeline({ name: 'new name' });
      spyOn(window.console, 'log');
      service.getPipelineChanges();
      expect(window.console.log).toHaveBeenCalled();
    });
  });

  describe('setPipeline()', () => {
    it('should set the pipeline', () => {
      const pipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters: []
      };
      service.setPipeline(pipeline);

      const pipelineFromService: Pipeline = service.getPipeline();
      expect(pipelineFromService).toEqual(pipeline);
    });
  });

  describe('patchPipeline', () => {
    let originalPipeline;
    beforeEach(() => {
      const originalPipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [{ key: 'one', value: 'one' }],
        filters: []
      };
      service.setPipeline(originalPipeline);
    });

    it('should only update the properties specified', () => {
      const expectedPipe = jasmine.objectContaining({
        id: '1',
        name: 'patched pipeline',
        dataFlowType: 'type',
        description: 'this has been patched',
        properties: [{ key: 'one', value: 'one' }]
      });

      const patchedPipeline: Partial<Pipeline> = {
        name: 'patched pipeline',
        description: 'this has been patched'
      };
      service.patchPipeline(patchedPipeline);

      const actualPipe: Pipeline = service.getPipeline();
      expect(actualPipe).toEqual(expectedPipe);
    });

    it('merges properties', () => {
      const expectedPipe = jasmine.objectContaining({
        name: 'patched pipeline',
        properties: [
          { key: 'one', value: 'one' },
          { key: 'two', value: 'two' }
        ]
      });

      const patchedPipeline: Partial<Pipeline> = {
        name: 'patched pipeline',
        properties: [{ key: 'two', value: 'two' }]
      };
      service.patchPipeline(patchedPipeline);

      const actualPipe: Pipeline = service.getPipeline();
      expect(actualPipe).toEqual(expectedPipe);
    });

    it('mergeProperties works correct', () => {
      let origProperties = [
        { key: 'one', value: 'one' },
        { key: 'two', value: 'two' },
        { key: 'three', value: 'three' }
      ];
      let newProperties = [{ key: 'two' }, { key: 'three', value: '3' }, { key: 'four' }, { key: 'five', value: 'five' }];

      let expectedProperties = [
        // one: preserves values from the original not in new
        { key: 'one', value: 'one' },
        // two and four: does not keep ones with missing value property
        // three: Overwrites with new value
        { key: 'three', value: '3' },
        // five: adds new value
        { key: 'five', value: 'five' }
      ];

      let actualProperties = service.mergeProperties(newProperties, origProperties);
      expect(actualProperties.length).toBe(expectedProperties.length);
      expect(actualProperties).toEqual(expectedProperties);
    });
  });

  describe('getUpdatePipelineData', () => {
    it('should update the pipeline data for comparision', () => {
      const originalPipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters: [],
        source: {
          dataConnection: {},
          selectedTables: [
            {
              key: 'HR',
              value: {
                tableExtractType: 'INCLUDE',
                tableAndKeys: [{ tableName: 'JOBS', keys: [] }]
              }
            }
          ]
        },
        target: {
          dataConnection: {},
          cdcRowMetadatas: [
            {
              key: 'TEST-EXCLUDE',
              value: 'EXCLUDE'
            },
            {
              key: 'TEST-INCLUDE',
              value: 'INCLUDE'
            }
          ],
          parameters: []
        }
      };
      service.getUpdatePipelineData(originalPipeline);

      const value = originalPipeline.source.selectedTables[0].value as any;
      expect(value.tableAndKeys).toBeDefined();

      const cdcRowMetadatas = originalPipeline.target.cdcRowMetadatas;
      expect(cdcRowMetadatas.length).toBe(1);
    });
  });

  it('should add a filter to the pipeline', () => {
    const originalPipeline: Pipeline = {
      id: '1',
      name: 'pipeline',
      dataFlowType: 'type',
      description: 'description',
      properties: [],
      filters: []
    };
    service.setPipeline(originalPipeline);
    service.addFilter({} as Filter);
    expect(service.getPipeline().filters.length).toBe(1);
  });

  describe('deleteFilters', () => {
    it('should remove specified filter from the pipeline', () => {
      const pipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters: [
          { schema: 'a', table: 'a', expression: 'a' },
          { schema: 'b', table: 'b', expression: 'b' }
        ]
      };
      service.setPipeline(pipeline);
      service.deleteFilter({ schema: 'b', table: 'b', expression: 'b' });
      expect(service.getPipeline().filters).toEqual([{ schema: 'a', table: 'a', expression: 'a' }]);
      service.notifyChange();
    });
  });

  describe('notifyChange', () => {
    it('should notify the observers that the pipeline has changed', () => {
      service.pipelineChanged$.subscribe((changedPipeline) => {
        expect(changedPipeline).toEqual(service.getPipeline());
      });
      service.notifyChange();
    });
  });

  describe('editFilters', () => {
    it('should edit the specified filter in the pipeline', () => {
      const filters = [{ schema: 'a', table: 'a', expression: 'a > b' }];
      const editedFilter = { schema: 'a', table: 'b', expression: 'c > d' };
      const pipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters
      };
      service.setPipeline(pipeline);
      service.editFilter(filters[0], editedFilter);
      expect(service.getPipeline().filters).toEqual([editedFilter]);
      service.notifyChange();
    });

    it('should not change the filters in the pipeline if the filter to be edited is not found', () => {
      const filters = [{ schema: 'a', table: 'a', expression: 'a > b' }];
      const editedFilter = { schema: 'a', table: 'b', expression: 'c > d' };
      const pipeline: Pipeline = {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters
      };
      service.setPipeline(pipeline);
      service.editFilter(editedFilter, editedFilter);
      expect(service.getPipeline().filters).toEqual(filters);
      service.notifyChange();
    });
  });
});
