import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { MenuItem } from 'primeng/api';
import { Subscription } from 'rxjs';
import { BaseComponent } from '../../../core/base.component';
import { TableConfiguration, TableField, TableMessage, TableMessageType } from '../../../shared/components/generic-table/generic-table';
import { PipelineService } from '../pipeline.service';
import { Pipeline, SelectedTables } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { Filter } from './filter';
import { FiltersSidebarComponent } from './filters-sidebar/filters-sidebar.component';

type FilterListItem = Filter & { actions: string };

@Component({
  selector: 'p-connect-filters',
  templateUrl: './filters.component.html',
  styleUrls: ['./filters.component.scss']
})
export class FiltersComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild(FiltersSidebarComponent) filtersSidebarComponent: FiltersSidebarComponent;
  isFilterSidebarVisible = false;
  filterList: FilterListItem[];
  invalidFilters: FilterListItem[] = [];

  fields: TableField[] = [
    {
      header: 'filters.FILTERS_TABLE.FIELDS.SCHEMA',
      name: 'schema',
      isKey: true
    },
    {
      header: 'filters.FILTERS_TABLE.FIELDS.TABLE',
      name: 'table'
    },
    { header: 'filters.FILTERS_TABLE.FIELDS.EXPRESSION', name: 'expression' },
    { header: 'filters.FILTERS_TABLE.FIELDS.ACTIONS', name: 'actions' }
  ];

  actionDropdownMenuItems: MenuItem[] = [
    {
      id: 'editMenuItem',
      label: 'common.BUTTONS.EDIT',
      command: (event) => {
        this.editFilter(event.item.target);
      }
    },
    {
      id: 'deleteMenuItem',
      label: 'common.BUTTONS.DELETE',
      command: (event) => {
        this.deleteFilters([{ ...event.item.target }]);
      }
    }
  ];

  emptyTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'filters.FILTERS_TABLE.MESSAGES.NO_FILTERS_CONFIGURED.HEAD',
    messageCaption: 'filters.FILTERS_TABLE.MESSAGES.NO_FILTERS_CONFIGURED.CAPTION'
  };

  errorTableMessage: TableMessage = {
    messageType: TableMessageType.ALERT,
    messageHead: 'filters.FILTERS_TABLE.MESSAGES.ERROR.HEAD',
    messageCaption: 'filters.FILTERS_TABLE.MESSAGES.ERROR.CAPTION'
  };

  toolbarMenuItems: MenuItem[] = [
    {
      id: 'editSelected',
      label: 'common.BUTTONS.EDIT',
      disabled: true,
      command: () => {
        this.editFilter(this.selectedFilters[0]);
      }
    },
    {
      id: 'deleteSelected',
      label: 'common.BUTTONS.DELETE',
      command: () => {
        this.deleteFilters(this.selectedFilters);
      },
      disabled: true
    }
  ];

  tableConfiguration: TableConfiguration = {
    isFilterShown: false,
    isLoading: false,
    visibleRows: 25,
    fields: this.fields,
    tableToolbar: {
      style: { width: '24rem', height: '60px' },
      menuItems: this.toolbarMenuItems
    },
    rowAction: {
      fieldIndex: 3,
      menuItems: this.actionDropdownMenuItems
    },
    tableMessages: {
      emptyTableMessage: this.emptyTableMessage,
      filterTableMessage: this.emptyTableMessage,
      errorTableMessage: this.errorTableMessage
    },
    primaryButtonText: 'filters.FILTERS_TABLE.BUTTONS.ADD_FILTER',
    createButtonClicked: () => {
      this.showFilterSidebar();
    },
    rowSelectionChangedEvent: (checkedItems: FilterListItem[]) => {
      this.selectedFilters = checkedItems;
      this.toolbarMenuItems[0].disabled = this.selectedFilters.length !== 1;
      this.toolbarMenuItems[1].disabled = this.selectedFilters.length === 0;
    }
  };

  schemasAndTables: SelectedTables[] = [];

  private pipelineSubscription: Subscription;
  private selectedFilters: FilterListItem[];

  constructor(private readonly pipelineEntityService: PipelineEntityService, private readonly pipelineService: PipelineService) {
    super();
  }

  ngOnInit(): void {
    this.pipelineSubscription = this.pipelineEntityService.pipelineChanged$.subscribe(this.setFilterList);
    this.schemasAndTables = this.pipelineEntityService.getPipeline().source?.selectedTables;
  }

  ngOnDestroy(): void {
    this.pipelineSubscription.unsubscribe();
  }

  showFilterSidebar(): void {
    this.isFilterSidebarVisible = true;
  }

  private readonly setFilterList = (pipeline: Pipeline) => {
    this.filterList =
      pipeline.filters?.map((filter) => {
        return {
          ...filter,
          actions: ' '
        };
      }) || [];
    this.invalidFilters.length = 0;
    for (const filter of this.filterList) {
      // @TODO when implementing filters test this condition, it might require change
      if (this.schemas.indexOf(filter.schema) < 0 || !this.getTables(filter.schema).filter((f) => f.tableName === filter.table).length) {
        this.invalidFilters.push(filter);
      }
    }
  };

  private get schemas() {
    return this.schemasAndTables?.map((obj) => obj.key);
  }

  private getTables(schema) {
    const selectedSchema = this.schemasAndTables?.find((obj) => obj.key === schema);
    return selectedSchema ? selectedSchema.value.tableAndKeys : [];
  }

  private deleteFilters(filterListItems: FilterListItem[]) {
    for (const filterListItem of filterListItems) {
      this.pipelineEntityService.deleteFilter(filterListItem);
    }
    this.pipelineService.savePipeline().then(() => {
      this.pipelineEntityService.notifyChange();
    });
  }

  private editFilter(selectedFilter: FilterListItem) {
    this.showFilterSidebar();
    this.filtersSidebarComponent.setFilter(selectedFilter);
  }
}
