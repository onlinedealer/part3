import { createSelector } from "@ngrx/store";
import * as fromRoot from "../reducers";
import * as fromNetworkSpecificConfig from "../reducers/network-specific-config.reducer";

export const getNetworkSpecificConfigurations = createSelector(
    fromRoot.getNetworkSpecificConfigState,
    (networkConfigState: fromNetworkSpecificConfig.NetworkSpecificConfigurationState) => networkConfigState.entities
);

export const getMissingDataLimit = createSelector(getNetworkSpecificConfigurations, state => {
    for (const config of Object.values(state)) {
        if (config.identifier === "AIMUIMissingDataLimit_Hours" && config.value) {
            return config.value;
        }
    }
    return "";
});

export const getGapDataLimit = createSelector(getNetworkSpecificConfigurations, state => {
    const networkControlParam = Object.values(state);
    for (const config of networkControlParam) {
        if (config.identifier === "AIMUIGapDataLimit_Days" && config.value) {
            return config.value;
        }
    }
    return "";
});

export const getNumberOfRelays = createSelector(getNetworkSpecificConfigurations, state => {
    for (const config of Object.values(state)) {
        if (config.identifier === "AIMUINumberOfRelays" && config.value) {
            return Number(config.value);
        }
    }
    return "";
});
