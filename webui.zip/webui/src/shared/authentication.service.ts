import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { OpenIdConnectService } from '@precisely/prism-ng/angular-auth-oidc-client';
import { OidcSecurityService } from 'angular-auth-oidc-client';
import { OIDC } from './oidc.model';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  constructor(private oidc: OpenIdConnectService) {}

  getToken(): string {
    return this.oidc.getToken();
  }

  fullName(): string {
    return this.oidc.getFullName();
  }

  getRoles(): string[] {
    return this.oidc.getClientRoles(OIDC.APP_CLIENT_ID);
  }

  logout() {
    this.oidc.logoff();
  }

  getAccountId(): string {
    return this.oidc.getCurrentWorkspaceId();
  }

  getEmail(): string {
    return this.oidc.getEmail();
  }

  getHttpHeaders(): HttpHeaders {
    let headers = new HttpHeaders();
    headers = headers.append('Content-Type', 'application/json');
    headers = headers.append('X-TenantID', 'default');
    headers = headers.append('Authorization', `Bearer ${this.getToken()}`);
    headers = headers.append('X-Content-Type-Options', 'nosniff');
    headers = headers.append('Content-Security-Policy', `default-src 'none'`);
    return headers;
  }
}
