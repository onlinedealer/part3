export class ColumnMap {
  sourceColumnName?: string;
  sourceColType: string;
  action: string;
  isKey: boolean;
  targetColumnName: string;
  targetColType: string;
  isExpression: boolean;
  state: string;
}

export class ColumnList {
  columnDataType: string;
  columnName: string;
  isPrimaryKey: boolean;
  isCDCRowMetaDataColumn: boolean;
  displayLabel?: string;
}

export const ColumnMapMetadata = {
  sourceColumnName: { type: 'string' },
  sourceColType: { type: 'string' },
  action: { type: 'string' },
  isKey: { type: 'boolean' },
  targetColumnName: { type: 'string' },
  targetColType: { type: 'string' },
  isExpression: { type: 'boolean' },
  state: { type: 'string' }
};
