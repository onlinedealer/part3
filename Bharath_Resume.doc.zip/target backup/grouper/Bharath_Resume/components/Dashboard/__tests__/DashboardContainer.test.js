import React from 'react'
import { shallow, mount } from 'enzyme'
import { Provider } from 'react-redux'
import configureStore from '../../../store/configureStore'
import DashboardContainer, { DashboardContainer as DashboardContainerComponent } from '../DashboardContainer'

describe('DashboardContainer component', () => {
  let store, wrapper, wrapperBlock
  store = configureStore
  let grouperList = [{'group_id': 5, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534306000, 'department': {'department_id': 244, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962800000, 'status': 'Active'}]
  let props = {
    classes: {},
    grouperList: grouperList,
    headerTitle: 'Dashboard',
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }
  it('renders without props', () => {
    const div = document.createElement('div')
    wrapper = mount(
      <Provider store={store}>
        <DashboardContainer />
      </Provider>, div)
    expect(wrapper).toHaveLength(1)
  })

  it('renders with props', () => {
    wrapper = mount(
      <Provider store={store}>
        <DashboardContainer {...props} />
      </Provider>)
    expect(wrapper).toHaveLength(1)
  })

  it('invoking shallow component ', () => {
    wrapperBlock = shallow(
      <DashboardContainerComponent
        {...props}
      />)
    expect(wrapperBlock).toHaveLength(1)
  })
})
