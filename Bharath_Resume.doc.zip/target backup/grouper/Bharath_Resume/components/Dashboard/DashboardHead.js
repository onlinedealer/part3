import React from 'react'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import TableHead from '@material-ui/core/TableHead'
import TableCell from '@material-ui/core/TableCell'
import TableRow from '@material-ui/core/TableRow'
import Tooltip from '@material-ui/core/Tooltip'
import TableSortLabel from '@material-ui/core/TableSortLabel'

const styles = theme => ({
  regRoot: {
    padding: 0,
    textAlign: 'center',
  },
  regRootLeft: {
    padding: 0,
    paddingLeft: 5,
    textAlign: 'left',
  },
  regRootLink: {
    padding: '0px 0px 0px 16px',
    textAlign: 'center',
  },
  regRootdDefault: {
    padding: 0,
    textAlign: 'center',
    '&:last-child': {
      paddingRight: 0,
    },
  },
  lastRoot: {
    paddingRight: 0,
  },
  rootTd: {
    padding: 0,
    textAlign: 'center',
    backgroundColor: '#1976d2',
    color: '#fff',
    '&:hover': {
      color: '#fff',
    },
  },
  rootTdLeft: {
    padding: 0,
    paddingLeft: 5,
    textAlign: 'left',
    backgroundColor: '#1976d2',
    color: '#fff',
    '&:hover': {
      color: '#fff',
    },
  },
  activeTd: {
    color: '#fff !important',
    '&:hover': {
      color: '#fff !important',
    },
  },
  rootLink: {
    color: '#2d81d4b5',
  },
  tableHeadHeight: {
    height: 40,
  },
})

const columnData = [
  { id: 'id', numeric: false, disablePadding: false, label: 'Group Id', sortStatus: true },
  { id: 'parent_tcin', numeric: false, disablePadding: false, label: 'Parent TCIN', sortStatus: false },
  { id: 'group_type', numeric: false, disablePadding: false, label: 'Group type', sortStatus: false },
  { id: 'primary_image', numeric: false, disablePadding: false, label: 'Primary Image', sortStatus: false },
  { id: 'group_name', numeric: false, disablePadding: false, label: 'Group Name', sortStatus: false },
  { id: 'departmentId', numeric: false, disablePadding: false, label: 'Dept', sortStatus: true },
  { id: 'item_type', numeric: false, disablePadding: false, label: 'Item Type', sortStatus: false },
  { id: 'noOfChildren', numeric: false, disablePadding: false, label: '# of items', sortStatus: true },
  { id: 'lastUpdatedDt', numeric: false, disablePadding: false, label: 'Last Modified', sortStatus: true },
  { id: 'launchDate', numeric: false, disablePadding: false, label: 'Launch Date', sortStatus: true },
  { id: 'group_state', numeric: false, disablePadding: false, label: 'Status', sortStatus: false },
  { id: 'delete_status', numeric: false, disablePadding: true, label: 'Delete', sortStatus: false },
]

export class DashboardHead extends React.Component {
    createSortHandler = property => event => {
      this.props.onRequestSort(property)
    };

    render () {
      const { classes, order, orderBy } = this.props

      return (
        <TableHead>
          <TableRow>
            {columnData.map(column => {
              const defaultRootStyle = (!column.sortStatus) ? classes.regRootdDefault : (column.id === 'group_name') ? classes.regRootLeft : classes.regRootLink
              const defaultRootTDStyle = (column.id === 'group_name') ? classes.rootTdLeft : classes.rootTd
              return (
                <TableCell
                  key={column.id}
                  numeric={column.numeric}
                  padding="none"
                  sortDirection={orderBy === column.id ? order : false}
                  classes={{ root: orderBy === column.id ? defaultRootTDStyle : defaultRootStyle }}
                >
                  {(column.sortStatus) ? (
                    <Tooltip
                      title="Sort"
                      placement="bottom-start"
                      enterDelay={300}
                    >
                      <TableSortLabel
                        active={orderBy === column.id}
                        direction={order}
                        onClick={this.createSortHandler(column.id)}
                        classes={{ active: classes.activeTd, root: orderBy !== column.id ? classes.rootLink : '' }}
                      >
                        {column.label}
                      </TableSortLabel>
                    </Tooltip>
                  ) : (
                    <span>{column.label}</span>
                  )}
                </TableCell>
              )
            }, this)}
          </TableRow>
        </TableHead>
      )
    }
}

DashboardHead.propTypes = {
  onRequestSort: PropTypes.func.isRequired,
  order: PropTypes.string.isRequired,
  orderBy: PropTypes.string.isRequired,
}

export default withStyles(styles)(DashboardHead)
