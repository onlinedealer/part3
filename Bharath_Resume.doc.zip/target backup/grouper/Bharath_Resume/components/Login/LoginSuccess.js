import React from 'react'
import { connect } from 'react-redux'
import { OAuthProvider, getPayload, getKey } from 'react-oauth-openid'
import { bindActionCreators } from 'redux'
import * as userActions from '../../store/auth'
import * as notificationActions from '../../store/notification/actionCreator'
import OAuthProviderConfig from '../../config/OAuthProviderConfig'

class LoginSuccess extends React.Component {
  onOAuthProviderLogin = () => {
    const idPayload = getPayload('id_token')
    idPayload.accessToken = getKey('access_token')
    this.props.userActions.signInSuccess(idPayload)
    this.props.history.replace('/')
  }

  onOAuthProviderLoginFailure = (error) => {
    /* this.props.errorActions.setErrorMessage({
      type: 'auth',
      level: 'warning',
      message: error.message,
    }) */
    this.props.notificationActions.showNotification(true, error.message)
  }

  render () {
    return (<OAuthProvider
      config={OAuthProviderConfig}
      errorCallback={this.onOAuthProviderLoginFailure}
      successCallback={this.onOAuthProviderLogin}
      isFullPageLogin
    />)
  }
}

function mapStateToProps (state) {
  return {
    userInfo: state.get('auth'),
  }
}

function mapDispatchToProps (dispatch) {
  return {
    userActions: bindActionCreators(userActions, dispatch),
    // errorActions: bindActionCreators(errorActions, dispatch),
    notificationActions: bindActionCreators(notificationActions, dispatch),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(LoginSuccess)
