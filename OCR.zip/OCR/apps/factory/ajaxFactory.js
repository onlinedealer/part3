(function() {
    'use strict';
    fileuploader.factory('$ajaxFactory', ['$http', '$q', ajaxFactory]);

    function ajaxFactory($http, $q) {

        var methods = {
            getDataFromServer: getDataFromServer,
            getUpload: getUpload

        }

        return methods;
        /* Implimentations*/
        function getDataFromServer(path, method, params) {
            var deferred = $q.defer();
            $http({
                    method: method,
                    url: path,
                    data: JSON.stringify(params)
                })
                .success(function(data, status, headers, config) {
                    deferred.resolve(data);
                })
                .error(function(data, status, headers, config) {
                    deferred.reject(data);
                });

            return deferred.promise;
        }

        /* function getUpload(path, method, params) {
             var deferred = $q.defer();
             var fd = new FormData();
             fd.append('file',$scope.myFile);
             $http.post(uploadUrl, fd, {
                     transformRequest: angular.identity,
                     headers: {
                         'Content-Type': undefined
                     }
                 })
                 .success(function(data, status, headers, config) {
                     deferred.resolve(data);
                 })
                 .error(function(data, status, headers, config) {
                     deferred.reject(data);
                 });

             return deferred.promise;

         }*/

        function getUpload(path, method, params) {
            var deferred = $q.defer();
            var fd = new FormData();
            fd.append('file', file);
            $http.post(uploadUrl, fd, {
                    transformRequest: angular.identity,
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .success(function(data) {
                    console.log(data);
                    $scope.uploadResponse = data;
                })
                .error(function(data, status, headers, config) {
                    deferred.reject(data);
                });

            return deferred.promise;

        }




    }

})();