import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { BaseConnectApiService } from '../../../core/base-connect-api.service';
import { Pipeline } from './pipeline';

@Injectable({
  providedIn: 'root'
})
export class ScheduledPipelinesApiService extends BaseConnectApiService<Pipeline> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient, 'scheduled/pipeline');
  }

  baseServiceUrl = `${environment.connectApiBaseURL}/scheduled/pipeline`;

  run(pipelineId: string) {
    return this.httpClient.get(`${this.baseServiceUrl}s/run`, { params: { pipeline_id: pipelineId } });
  }

  statusAll() {
    return this.httpClient.get(`${this.baseServiceUrl}/monitoring/status/all`);
  }
}
