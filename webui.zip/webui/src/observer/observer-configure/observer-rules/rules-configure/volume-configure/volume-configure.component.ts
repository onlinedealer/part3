import { Component, OnInit, Output, EventEmitter, ViewChild, Input, ChangeDetectorRef } from '@angular/core';
import { EventBusService } from 'core/eventBusService';
import { Helper } from 'discovery-shared';
import { ObserverConstants } from 'observer/observer-constants';
import { ObserverService } from 'observer/observer.service';
import { SliderComponent } from '../slider/slider.component';
import { SliderModel } from '../slider/slider.model';
import { WarningAlertModel } from '../warning-alert.model';
import { AlertAgainstTypeEnum } from './alert-against-type.enum';
import { VolumeConfigureModel } from './volume-configure.model';

@Component({
  selector: 'discovery-volume-configure',
  templateUrl: './volume-configure.component.html',
  styleUrls: ['./volume-configure.component.scss']
})
export class VolumeConfigureComponent implements OnInit {
  @Output() configVolumeSidebarVisible: EventEmitter<boolean> = new EventEmitter<boolean>();
  @ViewChild('slider')
  sliderComponent: SliderComponent;
  @Input() savedConfig;
  volumeModel = new VolumeConfigureModel();
  confidenceSliderSettings: SliderModel;
  thresholdSliderSettings: SliderModel;
  volumeThresholds: WarningAlertModel;
  validationCheck: ReturnType<typeof setTimeout>;
  constructor(
    private observerService: ObserverService,
    private eventBusService: EventBusService,
    private changeDetector: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.initialize();
  }
  cancelCreate(): void {
    this.configVolumeSidebarVisible.emit(false);
  }
  getThresholdUpdate(threshold: WarningAlertModel): void {
    if (this.validationCheck) {
      clearTimeout(this.validationCheck);
    }
    this.volumeThresholds = threshold;
    this.validationCheck = setTimeout(() => {
      if (
        this.volumeModel.configType === ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE &&
        threshold.minimum === 100 &&
        threshold.maximum === 100
      ) {
        this.confidenceSliderSettings.rangeValues = this.observerService.getDefaultRanges().confidence;
        this.sliderComponent?.initialize();
      }
    }, 500);
  }
  initialize(): void {
    const volumeConfig = this.observerService.getDefaultsConfigForObserverRules().volumeConfig;
    if (
      !Helper.isEmpty(this.savedConfig?.confidence?.warningAlerts) ||
      !Helper.isEmpty(this.savedConfig?.threshold?.warningAlerts)
    ) {
      this.volumeModel.configType = this.savedConfig.configType;
      if (this.savedConfig.configType === ObserverConstants.RULE_CONFIG_VOLUME_TYPES.THRESHOLD) {
        this.thresholdSliderSettings = new SliderModel();
        this.thresholdSliderSettings.sliderVisible = false;
        this.thresholdSliderSettings.rangeValues = [
          this.savedConfig.threshold.warningAlerts.minimum,
          this.savedConfig.threshold.warningAlerts.maximum
        ];
        this.volumeModel.threshold = Object.assign({}, this.savedConfig.threshold);
        this.volumeModel.threshold.movingAverage = this.volumeModel.threshold.movingAverage
          ? this.volumeModel.threshold.movingAverage
          : 7;
        this.setDefaultsForConfidence(volumeConfig);
      } else {
        this.confidenceSliderSettings = new SliderModel();
        this.confidenceSliderSettings.sliderVisible = true;
        this.confidenceSliderSettings.rangeValues = [
          this.savedConfig.confidence.warningAlerts.minimum,
          this.savedConfig.confidence.warningAlerts.maximum
        ];
        this.volumeModel.confidence = Object.assign({}, this.savedConfig.confidence);
        this.setDefaultsForThreshold();
      }
    } else {
      this.volumeModel.configType = volumeConfig.configType;
      this.setDefaultsForConfidence(volumeConfig);
      this.setDefaultsForThreshold();
    }
  }
  onDataPointsChanged(e) {
    if (!e.target.value || !Number(e.target.value)) {
      this.changeDetector.detectChanges();
      e.target.value = '7';
      this.volumeModel.threshold.movingAverage = 7;
    }
  }
  onTabOpen(e) {
    if (e.index) {
      this.volumeModel.configType = ObserverConstants.RULE_CONFIG_VOLUME_TYPES.THRESHOLD;
    } else {
      this.volumeModel.configType = ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE;
    }
  }
  saveChanges() {
    if (this.volumeThresholds) {
      if (this.volumeModel.configType === ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE) {
        this.volumeModel.confidence.warningAlerts = this.volumeThresholds;
      } else {
        this.volumeModel.threshold.warningAlerts = this.volumeThresholds;
      }
    }
    if (this.volumeModel.threshold.alertAgainst === AlertAgainstTypeEnum.LAST_PROFILE_RUN) {
      this.volumeModel.threshold.movingAverage = null;
    }
    this.eventBusService.emit('OBSRuleConfig', {
      data: this.volumeModel,
      ruleType: Helper.getCamcelCaseString(ObserverConstants.RULE_METRIC_TYPES.VOLUME)
    });
    this.cancelCreate();
  }

  private setDefaultsForThreshold() {
    this.thresholdSliderSettings = new SliderModel();
    this.thresholdSliderSettings.sliderVisible = false;
    this.thresholdSliderSettings.rangeValues = this.observerService.getDefaultRanges().threshold;
    this.volumeModel.threshold.warningAlerts.minimum = this.thresholdSliderSettings.rangeValues[0];
    this.volumeModel.threshold.warningAlerts.maximum = this.thresholdSliderSettings.rangeValues[1];
    this.volumeModel.threshold.alertAgainst = AlertAgainstTypeEnum.MOVING_AVERAGE;
    this.volumeModel.threshold.movingAverage = 7;
  }
  private setDefaultsForConfidence(config) {
    this.confidenceSliderSettings = new SliderModel();
    this.confidenceSliderSettings.sliderVisible = true;
    this.confidenceSliderSettings.rangeValues = this.observerService.getDefaultRanges().confidence;
    this.volumeModel.confidence.warningAlerts = config.warningAlerts;
  }
}
