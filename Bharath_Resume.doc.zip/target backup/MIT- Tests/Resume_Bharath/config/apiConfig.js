import merge from 'lodash/merge'

const commonConfig = {
  auth: {
    authorizationPath: '/auth/oauth/v2/authorize',
    logoutPath: '/login/responses/logoff.html',
    popupOptions: { width: 482, height: 680 },
    redirectUri: `${window.location.origin}/auth/login`,
    responseType: 'token id_token',
    scope: ['openid profile email'],
    storageType: 'localStorage',
    tokenType: 'Bearer',
  },
  piwik: {
  },
}

const envConfigs = {
  qa: {
    auth: {
      host: 'https://oauth.iam.perf.target.com',
      logoutHost: 'https://logonservices.iam.perf.target.com',
      clientId: 'mit_ui_ropc_npe_im',
      nonce: '1234',
      accessDeniedHost: 'https://logonservices.iam.perf.target.com/login/responses/accessdenied.html',
      adGroup: 'APP-LPP-STG-Mass-Maintain',
    },
    piwik: {
      url: 'https://site-management-qa.target.com/piwik/',
      siteId: 60,
    },
    lpLinks: {
      home: 'https://xycpre-launchpad.target.com/',
      search: 'https://xycpre-launchpad.target.com/item-search/base',
      help: 'https://xycpre-launchpad.target.com/help-center',
    },
    massItemMaintain: {
      commonPath: 'https://itemmit.dev.target.com/item_mit/v1/',
      getMaintenanceDetails: 'https://itemmit.dev.target.com/item_mit/v1/getMaintenanceDetails',
      getItems: 'https://itemmit.dev.target.com/item_mit/v1/fetchJiraDetails?jiraId=',
      saveItems: 'https://itemmit.dev.target.com/item_mit/v1/processMitItems',
    },
  },
  stg: {
    auth: {
      host: 'https://oauth.iam.perf.target.com',
      logoutHost: 'https://logonservices.iam.perf.target.com',
      clientId: '<%= authClientIdLower %>',
      nonce: '1234',
    },
  },
  prod: {
    auth: {
      host: 'https://oauth.iam.target.com',
      logoutHost: 'https://logonservices.iam.target.com',
      clientId: 'mit_ui_ropc_prod_im',
      nonce: '1234',
      accessDeniedHost: 'https://logonservices.iam.target.com/login/responses/accessdenied.html',
      adGroup: 'APP-LPP-Mass-Maintain',
    },
    piwik: {
      url: 'https://site-management-qa.target.com/piwik/',
      siteId: 60,
    },
    lpLinks: {
      home: 'https://launchpad.target.com/',
      search: 'https://launchpad.target.com/item-search/base',
      help: 'https://launchpad.target.com/help-center',
    },
    massItemMaintain: {
      commonPath: 'https://itemmit.prod.target.com/item_mit/v1/',
      getMaintenanceDetails: 'https://itemmit.prod.target.com/item_mit/v1/getMaintenanceDetails',
      getItems: 'https://itemmit.prod.target.com/item_mit/v1/fetchJiraDetails?jiraId=',
      saveItems: 'https://itemmit.prod.target.com/item_mit/v1/processMitItems',
    },
  },
}

// env.js sets APP_ENV
const appEnv = process.env.APP_ENV
const config = envConfigs[appEnv]
const apiConfig = merge(commonConfig, config)

export default apiConfig
