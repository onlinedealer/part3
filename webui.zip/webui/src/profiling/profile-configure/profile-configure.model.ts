import { ProfileConfigureConnectionModel, TableModel, ColumnModel, ScheduleConfigModel } from 'discovery-core';

export class ProfileConfigureModel {
  name: string;
  description: string;
  connection: ProfileConfigureConnectionModel;
  tables: TableModel[];
  rules: { [ruleid: string]: { [optionId: string]: [optionValue: any] } };
  scheduleConfig: ScheduleConfigModel;

  constructor() {
    this.connection = new ProfileConfigureConnectionModel();
    this.tables = [];
    this.rules = {};
    this.scheduleConfig = new ScheduleConfigModel(null);
  }

  loadFromSettings(settings) {
    this.name = settings.name;
    this.description = settings.description;
    this.connection.id = settings.connection.id;
    settings.tables.forEach((settingsTable) => {
      const table: TableModel = new TableModel();
      table.name = settingsTable.name;
      table.schema = settingsTable.schema;
      table.type = settingsTable.type;
      settingsTable.columns.forEach((settingsColumn) => {
        const column: ColumnModel = new ColumnModel();
        column.name = settingsColumn.name;
        column.type = settingsColumn.type;
        table.columns.push(column);
      });
      this.tables.push(table);
    });
    this.rules = settings.rules;
    this.scheduleConfig = settings.scheduleConfig;
  }
}
