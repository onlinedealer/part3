import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../../../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class MetadataApiService {
  baseUrl: any;

  constructor(private readonly httpClient: HttpClient) {
    this.baseUrl = `${environment.connectApiBaseURL}/metadata`;
  }

  createTopic(connectionId: string, topic: string) {
    const data = {
      name: topic
    };
    return this.httpClient.post(`${this.baseUrl}/${connectionId}/createtopic`, data);
  }

  getSchemas(connectionId: string, projectId?: string, headers?: HttpHeaders) {
    const params = {
      connection_id: connectionId
    };

    if (projectId) {
      params['project_id'] = projectId;
    }

    return this.httpClient.get(`${this.baseUrl}/schemas`, { params, headers });
  }

  getSubjects(connectionId: string, projectId?: string, headers?: HttpHeaders) {
    const params = {
      connection_id: connectionId
    };

    if (projectId) {
      params['project_id'] = projectId;
    }

    return this.httpClient.get(`${this.baseUrl}/subjects`, { params, headers });
  }

  getTables(connectionId: string, projectId?: string, schemaName?: string, headers?: HttpHeaders) {
    let params = new HttpParams();

    params = params.append('connection_id', connectionId);

    if (projectId) {
      params = params.append('project_id', projectId);
    }

    if (schemaName) {
      params = params.append('schema_name', schemaName);
    }

    return this.httpClient.get(`${this.baseUrl}/tables`, { params, headers });
  }

  getColumns(connectionId: string, projectId: string, schemaName: string, tableName: string, headers?: HttpHeaders) {
    const params = {
      connection_id: connectionId,
      project_id: projectId,
      schema_name: schemaName,
      table_name: tableName
    };

    return this.httpClient.get(`${this.baseUrl}/columns`, { params, headers });
  }

  getJournals(connectionId: string, projectId: string, headers?: HttpHeaders): Observable<any> {
    const params = {
      connection_id: connectionId,
      project_id: projectId
    };

    return this.httpClient.get(`${this.baseUrl}/journalList`, { params, headers });
  }

  getPublicKey(serverName: string, headers?: HttpHeaders): Observable<any> {
    const params = {
      server_name: serverName
    };

    return this.httpClient.get(`${this.baseUrl}/publickey`, { params, headers, responseType: 'text' });
  }
}
