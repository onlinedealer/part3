import { Injectable } from '@angular/core';
import * as _ from 'lodash';
import { BehaviorSubject, Observable } from 'rxjs';
import { DeployInfo } from '../../shared/deploy-configuration-form/deploy-info';
import { Filter } from '../filters/filter';
import { Pipeline, PipeLineMetadata, PIPELINE_ENTITY_TYPE } from './pipeline';
import { compareObject } from './pipeline-compare';
@Injectable({
  providedIn: 'root'
})
export class PipelineEntityService {
  private pipeline: Pipeline = new Pipeline();

  private pipelineSnapshot: Pipeline = new Pipeline();

  private pipelineSubject$ = new BehaviorSubject<Pipeline>(this.pipeline);

  public readonly pipelineChanged$: Observable<Pipeline> = this.pipelineSubject$.asObservable();

  public isStageChangesEnabled = true;

  public isStartPipelineRequested: boolean;

  // deploy pipeline related properties
  public isDeployChangesEnabled = false;

  // this flag just tells us that display alerts was selected in the deploy form of the pipeline
  // we cannot just simply use this flag to display the alerts sidebar because the user
  // may save the pipeline to commit or edit it at a later point
  public isDisplayAlertsEnabled = false;

  public incrementalStage = 'INCREMENTAL_COMMIT';

  public deployInfo: DeployInfo = {
    queueTimeoutInMinutes: 4,
    tableCaptureTimeoutInMinutes: 8,
    stopRequestTimeoutInMinutes: 4,
    forceDeploy: false,
    dataFlowNames: []
  };

  /**
   * The type of pipeline, can be one of the following: SCHEDULED or CONTINUOUS. Default is CONTINUOUS.
   */
  public pipelineEntityType = PIPELINE_ENTITY_TYPE.REPLICATION;

  constructor() {}

  setPipeline(pipeline: Pipeline): void {
    this.pipeline = pipeline;
    this.pipelineSnapshot = _.cloneDeep(pipeline);
    this.pipelineSubject$.next(this.pipeline);
  }

  patchPipeline(newPipeline: Partial<Pipeline>): void {
    if (newPipeline.properties) {
      newPipeline.properties = this.mergeProperties(newPipeline.properties, this.pipeline.properties);
    }
    this.pipeline = Object.assign(this.pipeline, newPipeline);
    this.pipelineSubject$.next(this.pipeline);
  }

  /**
   * Merges new and original set of properties.
   * Prioritize the new properties and remove elements without values.
   * @param newProperties
   * @param origProperties
   * @returns
   */
  mergeProperties(newProperties: { key?: string; value?: string }[], origProperties: { key?: string; value?: string }[]) {
    // Do not include properties without values. They are only used to filter the original properties.
    let newValues = newProperties.filter((element1) => element1.hasOwnProperty('value'));
    // Preserve keyValues that are not in the new properties.
    let oldValues = origProperties
      ? origProperties.filter((element1) => !newProperties.find((element2) => element2.key === element1.key))
      : [];

    return [...oldValues, ...newValues];
  }

  getPipeline(): Pipeline {
    return this.pipeline;
  }

  getLatestPipeline(): Observable<Pipeline> {
    return this.pipelineSubject$;
  }

  getConnectionType(): Pipeline {
    const connectionType: any = this.pipeline?.source?.dataConnection?.connectionType;
    return connectionType;
  }

  resetPipeline() {
    this.pipeline = new Pipeline();
  }

  getUpdatePipelineData(pipeline: Pipeline): Pipeline {
    if (pipeline?.target?.cdcRowMetadatas?.length > 0) {
      pipeline.target.cdcRowMetadatas = pipeline.target.cdcRowMetadatas.filter((item) => item.value === 'INCLUDE');
    }
    return pipeline;
  }

  updatePipelineSnapshot(pipeline: any) {
    this.pipelineSnapshot = _.cloneDeep(pipeline);
  }

  getPipelineChanges() {
    const comparePipeline = compareObject(this.pipeline, this.pipelineSnapshot, PipeLineMetadata);
    if (comparePipeline.hasChanges) {
      console.group('Changes found in pipeline, pipeline will be saved');
      console.log('UI Pipeline');
      console.debug(this.pipeline);
      console.log('API Pipeline');
      console.debug(this.pipelineSnapshot);
      console.log('Differences in UI pipeline compared with pipeline returned from API');
      console.debug(comparePipeline.objDiff);
      console.groupEnd();
    }
    return comparePipeline;
  }

  addFilter(filter: Filter): void {
    this.pipeline.filters.push(filter);
    this.pipelineSubject$.next(this.pipeline);
  }

  removeLatestFilter(): void {
    this.pipeline.filters.pop();
    this.pipelineSubject$.next(this.pipeline);
  }

  /**
   * Remove provided filter from the list
   * @param filterToDelete filter to be deleted
   */
  deleteFilter(filterToDelete: Filter): void {
    const filterIndex = this.findFilter(filterToDelete);
    if (filterIndex !== -1) {
      this.pipeline.filters.splice(filterIndex, 1);
    }
  }

  editFilter(originalFilter: Filter, newFilter: Filter): void {
    const filterIndex = this.findFilter(originalFilter);
    if (filterIndex !== -1) {
      this.pipeline.filters[filterIndex] = newFilter;
      this.pipelineSubject$.next(this.pipeline);
    }
  }

  private findFilter(filterToDelete: Filter) {
    for (let filterIndex = 0; filterIndex < this.pipeline.filters.length; filterIndex++) {
      if (
        this.pipeline.filters[filterIndex].table === filterToDelete.table &&
        this.pipeline.filters[filterIndex].schema === filterToDelete.schema &&
        this.pipeline.filters[filterIndex].expression === filterToDelete.expression
      ) {
        return filterIndex;
      }
    }
    return -1;
  }
  /**
   * Notify observers of the pipeline change
   */
  notifyChange() {
    this.pipelineSubject$.next(this.pipeline);
  }
}
