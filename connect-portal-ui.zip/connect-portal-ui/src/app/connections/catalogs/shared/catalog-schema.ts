import { CatalogTableStatus } from './catalog-table-status';

export interface CatalogSchema {
  lastCompleted: string;
  triggeredAt?: string;
  lastUpdated?: string;
  schema: string;
  status: string;
  tablesCompleted: number;
  tablesCount: number;
  tablesStatus: CatalogTableStatus[];
  // Error message in json format
  errorMessage?: string;
}
