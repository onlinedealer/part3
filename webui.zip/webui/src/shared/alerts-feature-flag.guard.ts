import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot } from '@angular/router';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { SharedConstants } from './shared.constant';

@Injectable({ providedIn: 'root' })
export class AlertsFeatureFlagGuard implements CanActivate {
  constructor(private router: Router, private launchDarklyService: LaunchDarklyService) {}

  canActivate(next: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    const redirectRoute = state.url.includes('data-alerts')
      ? '/data-observability/invalid-account'
      : '/data-observability/data-profiling';
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.ALERT)
      ? true
      : this.router.parseUrl(redirectRoute);
  }
}
