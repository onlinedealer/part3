import { Observable, Subject } from 'rxjs';

/**
 * Provides an Event Bus for communicating across components.
 * @example
 * // Subscribe to an event...
 * const subscription = eventBus.on<string>('foo').subscribe(
 *              data => {
 *                // ...do stuff w/data
 *              }
 * );
 * @example
 * // Emit an event...
 * eventBus.emit<string>('foo', 'bar');
 */

export class EventBusService {
  private events: { [key: string]: Subject<any> } = {};

  /**
   * Emits an even on the event bus.
   * @param event Name of the event.
   * @param data The data to emit.
   */
  public emit<T>(event: string, data: T): void {
    this.register<T>(event);
    this.events[event].next(data);
  }

  /**
   * Observe an event on the event bus.  As with all observables, the caller is responsible for subscribing
   * to the observable and, more importantly, unsubscribing.
   * @param event Name of the event to observe.
   */
  public on<T>(event: string): Observable<T> {
    this.register<T>(event);
    return this.events[event];
  }

  private register<T>(event: string) {
    if (!this.events[event]) {
      this.events[event] = new Subject<T>();
    }
  }
}
