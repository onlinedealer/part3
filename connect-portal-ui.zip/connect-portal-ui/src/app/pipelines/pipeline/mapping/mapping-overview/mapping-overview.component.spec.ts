import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Connection } from 'src/app/connections/shared/connection';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { MappingOverviewComponent } from './mapping-overview.component';
import { ResetToDefaultSidebarComponent } from '../reset-to-default/sidebar/reset-to-default-sidebar.component';
import { Component, CUSTOM_ELEMENTS_SCHEMA, inject, SimpleChange, SimpleChanges } from '@angular/core';
import { ChangeTableMappingSidebarComponent } from '../change-mapping/change-table-mapping/change-table-mapping-sidebar/change-table-mapping-sidebar.component';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { of } from 'rxjs';
import { EventApiService } from '../shared/event-api.service';
import { CreateTopicsSubjectsErrorsSidebarComponent } from '../create-topic-subjects/create-topics-subjects-errors-sidebar/create-topics-subjects-errors-sidebar.component';

describe('OverviewComponent', () => {
  let component: MappingOverviewComponent;
  let fixture: ComponentFixture<MappingOverviewComponent>;
  let catalogApiService: CatalogApiService;
  let eventApiService: EventApiService;
  @Component({
    selector: 'p-connect-mapping-overview',
    template: '',
    providers: [
      {
        provide: ResetToDefaultSidebarComponent,
        useClass: MockResetToDefaultSidebarComponent
      }
    ]
  })
  class MockResetToDefaultSidebarComponent {
    open() {}
  }

  const mockedSourceConnection = {
    id: '1',
    connectionType: 'ORACLE',
    journalName: 'JDBC',
    name: 'OracleConnection'
  } as Connection;

  const mockedTargetConnection = {
    id: '1',
    connectionType: 'DB2i',
    journalName: 'JDBC',
    name: 'DB2iConnection'
  } as Connection;
  const mockedresetToDefaultClicked = [];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [MappingOverviewComponent, MockResetToDefaultSidebarComponent],
      imports: [getTranslocoModule(), HttpClientTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MappingOverviewComponent);
    component = fixture.componentInstance;
    component.sourceDataConnection = mockedSourceConnection;
    component.targetDataConnection = mockedTargetConnection;
    fixture.detectChanges();
    component.changeMappingSidebar = jasmine.createSpyObj<ChangeTableMappingSidebarComponent>(['open']);
    component.resetToDefaultSidebar = jasmine.createSpyObj<ResetToDefaultSidebarComponent>(['open']);
    component.createTopicSubjectsErrorsSidebar = jasmine.createSpyObj<CreateTopicsSubjectsErrorsSidebarComponent>(['open']);

    catalogApiService = TestBed.inject(CatalogApiService);
    eventApiService = TestBed.inject(EventApiService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger mapping sidebar open method', () => {
    component.changeMappingClicked();
    expect(component.changeMappingSidebar.open).toHaveBeenCalled();
  });

  it('should trigger topic checkbox selection method', () => {
    spyOn(component.topicCheckBox, 'emit');
    const event = { checked: true };
    component.onChangeTopicCheckBox(event);
    expect(component.topicCheckBox.emit).toHaveBeenCalled();
  });

  it('should trigger subject checkbox selection method', () => {
    spyOn(component.subjectCheckbox, 'emit');
    const event = { checked: true };
    component.onChangeSubjectCheckBox(event);
    expect(component.subjectCheckbox.emit).toHaveBeenCalled();
  });

  it('should trigger reset to default sidebar open method', () => {
    component.resetToDefaultClicked();
    spyOn(component.getAllSelectedSourceData, 'emit').and.returnValue();
    expect(true).toBeTrue();
  });

  it('should reset to default', () => {
    const event = {};
    spyOn(component.resetSideViewClicked, 'emit');
    component.resetClicked(event);
    expect(component.resetSideViewClicked.emit).toHaveBeenCalled();
  });

  describe('catalog status component', () => {
    beforeEach(() => {
      jasmine.getEnv().allowRespy(true);
    });
    it('should fetch target connections catalog status if scalable commit feature flag is enabled', () => {
      spyOn(catalogApiService, 'status').and.returnValue(of({}));
      const changesObj: SimpleChanges = { targetDataConnection: new SimpleChange(true, true, false) };
      component.ngOnChanges(changesObj);
      expect(catalogApiService.status).toHaveBeenCalled();
    });
  });

  it('emitSubjectFailureErrors() should emit data to subjectFailureErrors$ Subject', () => {
    eventApiService.subjectFailureErrors$.subscribe((message) => {
      expect(message).toBe('error');
    });
    eventApiService.emitSubjectFailureErrors('error');
    component.getTopicAndSubjectErrors();
  });

  it('should open the sidebar with subject failure errors', () => {
    component.openErrorMsgSidebar();
    expect(component.createTopicSubjectsErrorsSidebar.open).toHaveBeenCalled();
  });
});
