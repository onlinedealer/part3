import { Component, ChangeDetectionStrategy } from "@angular/core";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { Contract } from "../../../models/contract.model";
import { TranslationsService } from "../../../../app/services/translations-service";
import { ContractsSorter } from "./contracts-sorter";
import * as ContractSelectors from "../../../store/selectors/contracts.selectors";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import * as ContractActions from "../../../store/actions/contracts.actions";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { MeteringPoint } from "../../../models/meteringpoint.model";

@Component({
    selector: "landisgyr-ss-contracts",
    templateUrl: "./ss-contracts.component.html",
    styleUrls: ["./ss-contracts.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSContractsComponent {
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    contracts$: Observable<Contract[]> = this.store.select(ContractSelectors.getSelectedMeteringPointContractsWithPartyData);
    contractsLoading$: Observable<boolean> = this.store.select(ContractSelectors.getSelectedMeteringPointContractsLoading);
    refreshDataLoading$: Observable<boolean> = this.store.select(ContractSelectors.getLoadingData);

    contractsLoadErrorMessage$: Observable<string | undefined> = this.store.select(
        ContractSelectors.getSelectedMeteringPointContractsError
    );

    contractsSorter = new ContractsSorter();
    sortedContracts$ = this.contractsSorter.getSortedContracts(this.contracts$);

    selectedContract$: Observable<Contract | undefined> = this.store.select(
        ContractSelectors.getSelectedMeteringPointContractWithPartyData
    );

    defaultSelectedcontract$: Observable<Contract> = this.store.select(
        ContractSelectors.getCurrentlyActiveConnectionContractOfSelectedMeteringPoint
    );

    infoMessage = $localize`:|@@ssContracts.noContractsMessage:No contracts`;

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {}

    onSelectContract(meteringPointId: number | undefined, contractId: number) {
        if (meteringPointId) {
            this.store.dispatch(ContractActions.SelectMeteringPointContract({ meteringPointId, contractId }));
        }
    }

    getTitle(): string {
        return (
            ": " + $localize`:|Title of Contracts side view after the name of the metering point@@ssContracts.title:Contracts`.toUpperCase()
        );
    }
}
