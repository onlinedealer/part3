import { Component, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Connection } from 'src/app/connections/shared/connection';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { environment } from 'src/environments/environment';
import { Bundle } from '../shared/bundles';
import { BundleDetailsFormComponent } from './bundle-details-form/bundle-details-form.component';

@Component({
  selector: 'p-connect-bundle-details-sidebar',
  templateUrl: './bundle-details-sidebar.component.html'
})
export class BundleDetailsSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(BundleDetailsFormComponent) bundleDetailsFormComponent: BundleDetailsFormComponent;

  primaryButton: SidebarButton = {
    isHidden: true
  };

  cancelButton: SidebarButton = {
    id: 'manageCatalogCancel',
    text: 'common.BUTTONS.CANCEL'
  };

  bundleDetails: Bundle;

  manageDiagnosticBundlesURL = environment.manageDiagnosticBundlesURL;

  open(bundleDetails: Bundle, sourceConnectionsInProject: Connection[], project: Project): void {
    this.bundleDetails = bundleDetails;

    this.bundleDetailsFormComponent.getFilesInTheBundle(bundleDetails.logMetadataList);
    this.bundleDetailsFormComponent.projectName = project.name;
    this.bundleDetailsFormComponent.runtimeEngineName =
      bundleDetails.logMetadataList.serverMetadataList.map((data) => data.server)[0]?.name || '';
    this.bundleDetailsFormComponent.checkIfIBMIConnectionUsedInProject(sourceConnectionsInProject, project);

    this.sidebarComponent.open();
  }

  closeButtonClicked() {
    this.sidebarComponent.close();
  }
}
