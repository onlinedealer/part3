(function () {
    'use strict';

    angular.module('arm').controller('activityAddCtrl',
                ['$rootScope', '$scope', '$state', '$stateParams', 'authService', 'activityService', 'utility', '$ionicModal', 'MASTER_TABLE', 'ALERT_MESSAGE', 'GENERAL_CONFIG', 'contactService', '$cordovaDialogs', '$cordovaLocalNotification', '$window','productService', 'noteService', activityAddCtrl]);

    function activityAddCtrl($rootScope, $scope, $state, $stateParams, authService, activityService, utility, $ionicModal, MASTER_TABLE, ALERT_MESSAGE, GENERAL_CONFIG, contactService, $cordovaDialogs, $cordovaLocalNotification, $window,productService,noteService) {

        $scope.title = 'Add Activity';
        var isEditModeFlag = utility.bitValCheck($stateParams.editModeFlag);
        var actScreenType = $stateParams.screenType;
        $scope.selCntPar = [];
        $scope.selUsrPar = [];
        $scope.fields = [];
        var actID = $stateParams.actId;
        // var screenType = $stateParams.screenType;
        $scope.actModel = activityService.activityMod().uiObject;
        var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.value = false;
        var dataSourceArr = [];
        $scope.selActTypeIndx = 0;
        $scope.IsEditFlag = false;

        //selected date/time/duration section
        $scope.selDate = {
            selDt: '',
            selTm: '',
            selDur: '',
            selectedDate: '',
            selTimeAM: '',
            otherDuration: 0
        };

        //user list
        $scope.userList = [];

        //its used for field controls
        $scope.IsContact = false;

        //displayed the final value in the date/time/duration
        $scope.SelTimeDurDate = '';

        $scope.contactDisplayArr = [];
        $scope.individualContactArr = [];
        $scope.companyContactArr = [];
        $scope.cntPars = [];

        //update the final value as per selected datetime control
        $scope.$watch(function (scope) { return scope.selDate.selectedDate },
              function (newValue, oldValue) {
                  if (newValue == null || newValue == '') return;
                  loadSelIndx(-1);
                  if ($scope.actModel.ActivityDuration > 0)
                      $scope.SelTimeDurDate = utility.getDateTimeInDisplayFormat(newValue) + ' | ' + $scope.actModel.ActivityDuration;
                  else {
                      $scope.SelTimeDurDate = utility.getDateTimeInDisplayFormat(newValue);
                  }
              }
             );

        //master date controls data
        $scope.actDates = [
            { Date: "6", Month: 'MAY', Year: '2016', Day: 'TODAY', Key: 'C' },
            { Date: "7", Month: 'MAY', Year: '2016', Day: 'TOMORROW', Key: 'M' },
            { Date: "13", Month: 'MAY', Year: '2016', Day: 'NEXT WEEK', Key: 'S' },
            { Date: "6", Month: 'JUNE', Year: '2016', Day: 'NEXT MONTH', Key: 'E' }
        ];

        //load contrrol
        function init() {

            var curDate = new Date();
            curDate.setDate(curDate.getDate());
            var dt = loadDates(curDate, 0, 0, 'D');
            //tomm date
            loadDates(dt, 1, 1, 'D');
            //week date
            loadDates(curDate, 7, 2, 'D');
            //month
            loadDates(curDate, 1, 3, 'M');
            loadActTypes();
            
            $scope.actModel.CreatorID = lgnUser.UserID;
            $scope.actModel.ModifiedBy = lgnUser.UserID;
            $scope.actModel.CreatorName = lgnUser.FullName;
            $scope.actModel.ModifiedByName = lgnUser.FullName;
            $scope.selUserOwners = {
                activeUser: $scope.actModel.CreatorID,
                tempUser: $scope.actModel.CreatorID
            };
            //edit mode
            if (isEditModeFlag) {
                $scope.title = 'Edit Activity';
                $scope.actModel.Address = '';
                editMode();
            }
            else {
                $scope.actModel.Address = '';
                if ($rootScope.previousState.name == 'tab.activityHappen') {
                    var exitingModel = [];
                    if (actScreenType == GENERAL_CONFIG.ScreenType.ContactList || actScreenType == GENERAL_CONFIG.ScreenType.ContactDetail || actScreenType == GENERAL_CONFIG.ScreenType.HomeContact) {
                        var cmpModel = [];
                        var indModel = [];
                        if (contactService.getSelectWhathappened() == contactService.constants().contactType.Individual) {
                            indModel = contactService.getSelectedIndividualContact();
                            if (indModel.IsRepresentative == false) {
                                $scope.actModel.EmployerID = indModel.EmployerID;
                                $scope.actModel.EmployerName = indModel.EmployerName;
                                $scope.actModel.ContactDisplayName = indModel.FirstName + ' ' + indModel.LastName;
                                $scope.actModel.CompanyName = $scope.actModel.EmployerName;
                                $scope.actModel.ContactName = $scope.actModel.ContactDisplayName;
                                $scope.actModel.ContactID = indModel.ContactID;
                                $scope.actModel.ContactTypeID = indModel.ContactTypeID;
                                $scope.actModel.OwnerID = indModel.OwnerID;
                                $scope.actModel.OwnerName = indModel.OwnerName;
                                $scope.actModel.ContactTierID = indModel.ContactTierID;
                                $scope.actModel.ContactTierName = indModel.ContactTierName;
                                $scope.actModel.ContactSegmentID = indModel.ContactSegmentID;
                                $scope.actModel.ContactSegmentName = indModel.ContactSegmentName;
                                $scope.actModel.ContactDeviceObjID = indModel.DeviceObjID;
                            } else {
                                setCmpModel(cmpModel, indModel);
                            }
                        }
                        else {
                            setCmpModel(cmpModel, indModel);
                        }
                    }
                    else {
                        exitingModel = angular.copy(activityService.getActivity()[0]);
                        $scope.actModel.EmployerID = CheckNull(exitingModel.EmployerID);
                        $scope.actModel.EmployerName = exitingModel.EmployerName;
                        $scope.actModel.RepresentativeID = CheckNull(exitingModel.RepresentativeID);
                        $scope.actModel.RepresentativeDeviceObjID = exitingModel.RepresentativeDeviceObjID;
                        $scope.actModel.RepresentativeName = exitingModel.RepresentativeName;
                        $scope.actModel.ContactDisplayName = exitingModel.ContactDisplayName;
                        $scope.actModel.CompanyName = exitingModel.CompanyName;
                        $scope.actModel.ContactOwnerID = exitingModel.ContactOwnerID;
                        $scope.actModel.ContactTypeID = exitingModel.ContactTypeID;
                        $scope.actModel.ContactDeviceObjID = exitingModel.ContactDeviceObjID;
                        $scope.actModel.ContactID = exitingModel.ContactID;
                        $scope.actModel.ContactName = exitingModel.ContactName;
                        $scope.actModel.ContactTierID = exitingModel.ContactTierID;
                        $scope.actModel.ContactTierName = exitingModel.ContactTierName;
                        $scope.actModel.ContactSegmentID = exitingModel.ContactSegmentID;
                        $scope.actModel.ContactSegmentName = exitingModel.ContactSegmentName;
                    }
                    actID = 0;
                }
                loadFields();
                SetCalDate($scope.actDates[0]['Date'], $scope.actDates[0]['Month'], $scope.actDates[0]['Year']);
                $scope.actModel.ActivityTime = $scope.actTimes[0]['Time'];
                $scope.actModel.ActivityDuration = $scope.actDurations[3]['Duration'];
                $scope.selDate.selTimeAM = $scope.actTimes[0]['Meridiem'];
                SetDateTime();
                loadSelIndx(0);
                $scope.selDurIndx = 3;
                loadSubject();

            }
            loadContacts();
            loadUsersData();
            getCurrentLoc();
        }


        function setCmpModel(cmpModel, indModel) {
            cmpModel = contactService.getSelectedCompanyContact();
            indModel = contactService.getSelectedIndividualContact();
            $scope.actModel.RepresentativeID = indModel.ContactID;
            $scope.actModel.RepresentativeDeviceObjID = indModel.DeviceObjID;
            $scope.actModel.RepresentativeName = indModel.FirstName + ' ' + indModel.LastName;
            $scope.actModel.ContactDisplayName = indModel.FirstName + ' ' + indModel.LastName;
            $scope.actModel.CompanyName = cmpModel.CompanyName;
            $scope.actModel.ContactName = cmpModel.CompanyName;
            $scope.actModel.ContactID = cmpModel.ContactID;
            $scope.actModel.ContactTypeID = cmpModel.ContactTypeID;
            $scope.actModel.OwnerID = cmpModel.OwnerID;
            $scope.actModel.OwnerName = cmpModel.OwnerName;
            $scope.actModel.ContactTierID = cmpModel.ContactTierID;
            $scope.actModel.ContactTierName = cmpModel.ContactTierName;
            $scope.actModel.ContactSegmentID = cmpModel.ContactSegmentID;
            $scope.actModel.ContactSegmentName = cmpModel.ContactSegmentName;
            $scope.actModel.ContactDeviceObjID = cmpModel.DeviceObjID;
        }
        function getCurrentLoc() {
            var curAt = '';
            var options = {
                enableHighAccuracy: true,
                timeout: 3000,
                maximumAge: 0
            };
            utility.busyCursorStart();
            navigator.geolocation.getCurrentPosition(function (position) {
                curAt = position.coords.latitude + ' ' + position.coords.longitude;
                $scope.actModel.CreatedAt = curAt;
                $scope.actModel.ModifiedAt = curAt;
                //$scope.actModel.LocLat = position.coords.latitude;
                //$scope.actModel.LocLog = position.coords.longitude;
                utility.busyCursorEnd();
            }, function () { utility.busyCursorEnd();}, options);
        }


        var selCntPar = [];
        var selUsrPar = [];
        function editMode() {
            $scope.IsEditFlag = true;
            $scope.actModel = angular.copy(activityService.getActivity()[0]);
            $scope.value = utility.bitValCheck($scope.actModel.IsConfidential);
            $scope.actModel.Fields = [];
            $scope.actModel.ActivityAttendees = [];
            $scope.actModel.ParInternal = [];
            $scope.actModel.Notes = [];
            loadFields();
            selCntPar = angular.copy(activityService.getParUser());
            //utility.selectedUserList(exitingCntPar, $scope.selCntPar);
            selUsrPar = angular.copy(activityService.getParInternal());

            // utility.selectedUserList($scope.cntPars, $scope.selCntPar);
            // utility.selectedUserList($scope.userPars, $scope.selUsrPar);

            $scope.fields = angular.copy(activityService.getFields());
            utility.updateFldArrValues($scope.fields, $scope.actModel.Fields);

            $scope.actModel.Address = $scope.actModel.Address;
            $scope.actModel.LocLat = $scope.actModel.LocLat;
            $scope.actModel.LocLog = $scope.actModel.LocLog;
            $scope.selUserOwners.activeUser = $scope.actModel.OwnerID;
            //note displayed in edit mode..right now removed as per suggested by bhusan
            //var notes = angular.copy(activityService.getNotes());

            //var noteLength = notes.length;

            //if (noteLength > 0) {
            //    var objNotes = notes[noteLength - 1];
            //    $scope.actModel.Notes.push(objNotes);
            //    $scope.actModel.Description = $scope.actModel.Notes[0].Description;
            //}

            //var dt = utility.getLocalDateFromUTC($scope.actModel.ActivityDate);
            var arrDate = $scope.actModel.ActivityDate.split('-');
            //var month=dt.getMonth() + 1;
            //SetCalDate(dt.getDate(), month, dt.getFullYear());// arrDate[2], arrDate[1], arrDate[0]);
            var monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
            SetCalDate(arrDate[2], monthNames[arrDate[1] - 1], arrDate[0]);// arrDate[2], arrDate[1], arrDate[0]);
            SetDateTime();
            $scope.selDate.SelectedDate = new Date(arrDate[0], ([arrDate[1] - 1]), arrDate[2]);

            $scope.selActTypeIndx = loadEditIndx($scope.actTypes, $scope.actModel.ActivityTypeID, 'ActivityTypeID');
            $scope.selTimeIndx = loadEditIndx($scope.actTimes, $scope.actModel.ActivityTime, 'Time');
            $scope.selDateIndx = loadEditDateIndx();
            $scope.selDurIndx = loadEditIndx($scope.actDurations, $scope.actModel.ActivityDuration, 'Duration');

        }

        function loadEditDateIndx() {
            var retIndx = -1;
            for (var i = 0; i < $scope.actDates.length; i++) {
                var dt = new Date();
                dt.setDate($scope.actDates[i]['Date']);
                dt.setMonth((utility.monthNameToNum($scope.actDates[i]['Month']) - 1));
                dt.setFullYear($scope.actDates[i]['Year']);
                if ($scope.selDate.selDt == utility.getDateInDisplayFormat(dt)) {
                    retIndx = i;
                }
            }
            return retIndx;

        }

        function loadEditIndx(arr, val, colName) {
            var retIndx = -1;
            for (var i = 0; i < arr.length; i++) {
                if (val == arr[i][colName]) {
                    retIndx = i;
                }
            }
            return retIndx;
        }

        function loadSubject() {
            if ($scope.actModel.ContactName == '')
                return '';
            var obj = new Object();
            obj.ContactName = $scope.actModel.ContactDisplayName;
            obj.CompanyName = $scope.actModel.CompanyName;
            obj.ContactTypeID = $scope.actModel.ContactTypeID;
            obj.ActivityType = $scope.actModel.ActivityType + ' ';
            obj.RepresentativeName = $scope.actModel.RepresentativeName;
            obj.Type = 'A';
            $scope.actModel.ActivitySubject = utility.getSubject(obj);

        }

        //indx changed as per selected date/time/duration controls
        function loadSelIndx(val) {
            $scope.selDateIndx = val;
            $scope.selTimeIndx = val;
        }

        //date calculate
        function loadDates(date, val, indx, type) {
            var retDt;
            if (val == 0) {
                retDt = date;
            }
            else {
                retDt = utility.dateCal(date, val, type);
            }

            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
            $scope.actDates[indx]["Date"] = retDt.getDate();
            $scope.actDates[indx]["Month"] = monthNames[retDt.getMonth()];
            $scope.actDates[indx]["Year"] = retDt.getFullYear();
            return retDt;
        }

        init();

        //load all the master data
        function loadActTypes() {
            $scope.actTypes = utility.getMasterDataByKey(MASTER_TABLE.ActType);
            $scope.actTimes = utility.getMasterDataByKey(MASTER_TABLE.ActTime);
            $scope.actDurations = utility.getMasterDataByKey(MASTER_TABLE.ActDur);
            $scope.fieldSet = utility.getMasterDataByKey(MASTER_TABLE.ActFldSet);

            //debugger
            $scope.TierList = utility.getMasterDataByKey(MASTER_TABLE.Tier);
            $scope.ConSegList = utility.getMasterDataByKey(MASTER_TABLE.ConSeg);
            $scope.actModel.ActivityTypeID = $scope.actTypes[0].ActivityTypeID;
            $scope.actModel.ActivityType = $scope.actTypes[0].Name;
            var actStages = utility.getMasterDataByKey(MASTER_TABLE.ActStag);
            $scope.actModel.ActivityStageID = actStages[0].ActivityStageID;
        }

        //not used right
        $scope.contact = {
            created: ''
        }
        var curdate = new Date();
        $scope.contact.created = curdate.toDateString()

        $scope.actionSelDate = function (selVal) {
            alert(selVal);
        }
        /////////////////////////////END////////////////////////

        //change the toggle cntrl
        $scope.toggleChange = function () {
            if (utility.bitValCheck($scope.value) == false) {
                $scope.value = true;
            } else
                $scope.value = false;
            $scope.actModel.IsConfidential = $scope.value;
        };

        //event for selected the date/time/duration
        $scope.actionType = function ($index, val, name) {
            $scope.selActTypeIndx = $index;
            $scope.actModel.ActivityType = name;
            $scope.actModel.ActivityTypeID = val;
            loadSubject();
        }

        //event for selected the date
        $scope.actionDate = function ($index, val, month, year) {
            $scope.selDateIndx = $index;
            SetCalDate(val, month, year);
            SetDateTime();
        }

        //event for selected the time
        $scope.actionTime = function ($index, val, am) {
            $scope.selTimeIndx = $index;
            $scope.actModel.ActivityTime = val;
            $scope.selDate.selTimeAM = am;
            SetDateTime();
        }

        //event for selected the duration
        $scope.actionDur = function ($index, val) {
            $scope.selDurIndx = $index;
            $scope.actModel.ActivityDuration = val;
            SetDateTime();
        }

        //event for add/save activity
        $scope.addActivity = function () {

            if ($rootScope.isNetworkAvailable == false) {
                $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                   .then(function () {
                                   });
                return;
            }
        productService.getAttachments(0).then(function(){
            var valActFlag = true;

            if ($scope.actModel.ContactDisplayName == '' && $scope.actModel.CompanyName == '') {
                $cordovaDialogs.alert(ALERT_MESSAGE.SELECT_COMPANY, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                    .then(function () {
                    });
                return false;
            }

            valActFlag = utility.commonValidation($scope.selUserOwners.activeUser, valActFlag, 'Activity Owner');


            if (!valActFlag) return false;

            if ($scope.actModel.ActivityDuration == "0") {
                $scope.actModel.IsActivityEvent = 0;//task
            }
            else
                $scope.actModel.IsActivityEvent = 1;//event


            var selDateArr = $scope.SelTimeDurDate.split('|');
            $scope.selDate.selDt = selDateArr[0];
            var selTime = selDateArr[1].trim();
            //$scope.actModel.ActivityTime = //selTime.substring(0, selTime.length - 2);
            $scope.actModel.ActivityTime = utility.convertTime24Format(selTime);


            $scope.actModel.ActivityDate = utility.getDateInServerFormat($scope.selDate.selDt);//utility.getDateStringInUTC($scope.selDate.selDateFormat);//utility.saveDateStringUTC($scope.selDate.selDt).toString();
            $scope.actModel.ActivityDateForSort = $scope.actModel.ActivityDate;//utility.getLocalDateFromUTC($scope.selDate.selDt).getDate();
            selectPar($scope.selCntPar, $scope.actModel.ActivityAttendees, GENERAL_CONFIG.MODULES.Activity, 'CP', true);
            selectPar($scope.selUsrPar, $scope.actModel.ActivityAttendees, GENERAL_CONFIG.MODULES.Activity, 'UP', false);
            $scope.actModel.OwnerID = $scope.selUserOwners.activeUser;
            $scope.actModel.OwnerName = $scope.selActivityOwner;
            $scope.actModel.CreatorName = lgnUser.FullName;
            $scope.actModel.ModifiedByName = lgnUser.FullName;
            
            //$scope.actModel.SegmentName = "Gold";
            if ($scope.actModel.Description != '' && typeof $scope.actModel.Description != 'undefined') {
                var noteObjModel = noteService.noteMod().noteModel;
                noteObjModel.EntityID = $scope.actModel.ActivityID;
                noteObjModel.ModuleID = GENERAL_CONFIG.MODULES.Activity;
                noteObjModel.ParentDeviceObjID = $scope.actModel.DeviceObjID;
                noteObjModel.Description = $scope.actModel.Description;
                noteObjModel.CreatorID = $scope.actModel.CreatorID;
                noteObjModel.CreatorName = $scope.actModel.CreatorName;
                noteObjModel.CreatedOn = utility.getDateStringInUTC(new Date());
                noteObjModel.CreatedAt = $scope.actModel.CreatedAt;
                $scope.actModel.Notes.push(noteObjModel);
            }
            $scope.actModel.Correspondences = [];
            var objCor = new Object();
            objCor.DeviceObjID = utility.generateUUID();
            objCor.ModuleID = GENERAL_CONFIG.MODULES.Activity;
            objCor.Address = $scope.actModel.Address;
            objCor.GoogleLat = $scope.actModel.LocLat;
            objCor.GoogleLong = $scope.actModel.LocLog;
            if ($scope.actModel.LocLat != '' || $scope.actModel.LocLog != '' || $scope.actModel.Address != '')
                $scope.actModel.Correspondences.push(objCor);

            if (isEditModeFlag) {
                //$scope.actModel.ModifiedAt = $scope.actModel.LocLat + ' ' + $scope.actModel.LocLog;
                $scope.actModel.ModifiedOn = utility.getDateStringInUTC(new Date());
                activityService.sqlActUpdate($scope.actModel, $scope.actModel.ActivityAttendees, 'E').then(function (result) {
                    activityService.actAdd($scope.actModel).then(function (res) {
                        activityService.sqlActSync(res[0].Data).then(function (result) {
                            $scope.scheduleDelayedNotification($scope.actModel.ActivityDate, $scope.actModel.ActivityTime, $scope.actModel.ActivityRemainderInterval, $scope.actModel.DeviceObjID, $scope.actModel.ActivitySubject);
                            //$state.go('tab.activity');
                            navigateURL();
                        });
                    },
                    function (err) {
                        $scope.errorMessage = err;
                    });
                });
            }
            else {
                //$scope.actModel.CreatedAt = $scope.actModel.LocLat + ' ' + $scope.actModel.LocLog;
                if ($scope.actModel.ContactID == 0) {
                    $cordovaDialogs.alert(ALERT_MESSAGE.CONTACT_NOT_SYNC, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                               .then(function () {
                                               });
                    return;
                }
                if ($rootScope.previousState.name == 'tab.activityHappen') {
                    activityService.setActStatus('S');
                }
                $scope.actModel.DeviceObjID = utility.generateUUID();
                activityService.sqlActAdd($scope.actModel, $scope.actModel.ActivityAttendees, 'E').then(function (result) {
                    activityService.actAdd($scope.actModel).then(function (res) {
                        activityService.sqlActSync(res[0].Data).then(function (result) {
                            $scope.scheduleDelayedNotification($scope.actModel.ActivityDate, $scope.actModel.ActivityTime, $scope.actModel.ActivityRemainderInterval, $scope.actModel.DeviceObjID, $scope.actModel.ActivitySubject);
                            //$state.go('tab.activity');
                            navigateURL();
                        });

                    },
                        function (err) {
                            $scope.errorMessage = err;
                        });
                });
            }
          });
        }

        //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $scope.scheduleDelayedNotification = function (actDate, actTime, actRemainderInterval, actID, actSubject) {
            var activityDate = new Date();
            var actDateArr = actDate.toString().split("-");
            var actTimeArr = actTime.toString().split(":");
            activityDate.setFullYear(actDateArr[0], (actDateArr[1] - 1), actDateArr[2]);
            activityDate.setHours(actTimeArr[0], actTimeArr[1], 0);
            activityDate.setMinutes(activityDate.getMinutes() - actRemainderInterval);

            //var reminderTime = new Date(actTime - duration * 1000);
            var curDt=new Date();
            if (activityDate < curDt) return;
            $window.cordova.plugins.notification.local.schedule({
                id: actID,
                title: 'SalesARM',
                text: 'You have activity scheduled at ' + actTime + ' with Subject ' + actSubject,
                at: activityDate
            });
        };


        // Loading the User Contacts
        $scope.selContacts = {
            activeContact: "",
            tempContact: ""
        };

        function loadContacts() {
            utility.sqlGetAllContacts().then(function (result) {
                //console.log("Contacts result is" + JSON.stringify(result));
                for (var i = 0; i < result.rows.length; i++) {
                    //console.log('FirstName' + result.rows.item(i).FirstName + ' and Company Name' + result.rows.item(i).CompanyName);
                    if (result.rows.item(i).ContactTypeID == 1) {
                        $scope.individualContactArr.push(result.rows.item(i));
                    } else if (result.rows.item(i).ContactTypeID == 2) {
                        $scope.companyContactArr.push(result.rows.item(i));
                    }
                }
                //console.log('indi contact' + JSON.stringify($scope.individualContactArr));
                //console.log('rep contact' + JSON.stringify($scope.companyContactArr));

                for (var i = 0; i < $scope.individualContactArr.length; i++) {
                    //console.log('device obj id to send' + $scope.individualContactArr[i].DeviceObjID);
                    if ($scope.individualContactArr[i].EmployerDeviceObjID == "" || $scope.individualContactArr[i].EmployerDeviceObjID == "undefined" || $scope.individualContactArr[i].EmployerDeviceObjID == "null") {
                        $scope.contactSelectionModel = utility.contactSelectionMod().uiObject;
                        $scope.contactSelectionModel.ContactName = $scope.individualContactArr[i].FirstName + " " + $scope.individualContactArr[i].LastName;
                        $scope.contactSelectionModel.AttendeeDeviceObjID = $scope.individualContactArr[i].DeviceObjID;
                        $scope.contactSelectionModel.ContactDeviceObjID = $scope.individualContactArr[i].DeviceObjID;
                        $scope.contactSelectionModel.ContactID = $scope.individualContactArr[i].ContactID;
                        $scope.contactSelectionModel.UserID = $scope.individualContactArr[i].ContactID;
                        $scope.contactSelectionModel.ContactTypeID = $scope.individualContactArr[i].ContactTypeID;
                        $scope.contactSelectionModel.ContactOwnerID = $scope.individualContactArr[i].OwnerID;
                        $scope.contactSelectionModel.ContactOwnerName = $scope.individualContactArr[i].OwnerName;
                        $scope.contactSelectionModel.DisplayName = $scope.contactSelectionModel.ContactName;
                        $scope.contactSelectionModel.CompanyName = "";
                        $scope.contactSelectionModel.EmployerID = $scope.individualContactArr[i].EmployerID;
                        $scope.contactSelectionModel.EmployerName = "";
                        $scope.contactSelectionModel.CompanyID = 0;
                        $scope.contactSelectionModel.CompanyDeviceObjID = '';
                        $scope.contactSelectionModel.UserName = $scope.contactSelectionModel.DisplayName;
                        $scope.contactSelectionModel.IsChecked = false;
                        $scope.contactSelectionModel.ContactTierName = $scope.individualContactArr[i].ContactTierName;
                        $scope.contactSelectionModel.ContactTierID = $scope.individualContactArr[i].ContactTierID;
                        $scope.contactSelectionModel.ContactSegmentName = $scope.individualContactArr[i].ContactSegmentName;
                        $scope.contactSelectionModel.ContactSegmentID = $scope.individualContactArr[i].ContactSegmentID;

                        if ($scope.isEditModeFlag != 0) {
                            utility.editSelUserList($scope.selCntPar, $scope.contactSelectionModel, selCntPar);
                        }

                        $scope.contactDisplayArr.push($scope.contactSelectionModel);
                        $scope.cntPars.push($scope.contactSelectionModel);
                    } else {
                        utility.sqlGetAllIndividualContactsRelationships($scope.individualContactArr[i]).then(function (contactResult) {
                            //console.log('contact result' + JSON.stringify(contactResult));
                            $scope.contactSelectionModel = utility.contactSelectionMod().uiObject;
                            $scope.contactSelectionModel.ContactName = contactResult[0].FirstName + " " + contactResult[0].LastName;
                            $scope.contactSelectionModel.AttendeeDeviceObjID = contactResult[0].DeviceObjID;
                            $scope.contactSelectionModel.ContactDeviceObjID = contactResult[0].DeviceObjID;
                            $scope.contactSelectionModel.ContactID = contactResult[0].ContactID;
                            $scope.contactSelectionModel.UserID = contactResult[0].ContactID;
                            $scope.contactSelectionModel.ContactTypeID = contactResult[0].ContactTypeID;
                            $scope.contactSelectionModel.ContactOwnerID = contactResult[0].OwnerID;
                            $scope.contactSelectionModel.ContactOwnerName = contactResult[0].OwnerName;
                            $scope.contactSelectionModel.DisplayName = $scope.contactSelectionModel.ContactName;
                            $scope.contactSelectionModel.CompanyName = contactResult[1].rows.item(0).CompanyName;
                            $scope.contactSelectionModel.CompanyID = contactResult[1].rows.item(0).ContactID;
                            $scope.contactSelectionModel.CompanyDeviceObjID = contactResult[1].rows.item(0).DeviceObjID;
                            $scope.contactSelectionModel.DisplayName += '(' + $scope.contactSelectionModel.CompanyName + ')';
                            $scope.contactSelectionModel.UserName = $scope.contactSelectionModel.DisplayName;
                            $scope.contactSelectionModel.EmployerID = contactResult[0].EmployerID;
                            $scope.contactSelectionModel.EmployerName = contactResult[0].EmployerName;
                            $scope.contactSelectionModel.ContactTierName = contactResult[0].ContactTierName;
                            $scope.contactSelectionModel.ContactTierID = contactResult[0].ContactTierID;
                            $scope.contactSelectionModel.ContactSegmentName = contactResult[0].ContactSegmentName;
                            $scope.contactSelectionModel.ContactSegmentID = contactResult[0].ContactSegmentID;

                            $scope.contactSelectionModel.IsChecked = false;
                            if (isEditModeFlag) {
                                //$scope.contactSelectionModel.IsChecked = utility.editSelUserList($scope.selCntPar, $scope.contactSelectionModel, selCntPar);;
                                utility.editSelUserList($scope.selCntPar, $scope.contactSelectionModel, selCntPar);
                            }

                            $scope.contactDisplayArr.push($scope.contactSelectionModel);
                            $scope.cntPars.push($scope.contactSelectionModel);

                            //console.log('contact model is' + JSON.stringify($scope.contactSelectionModel));
                            //console.log('contactDisplayArrObj is' + JSON.stringify($scope.contactDisplayArr));
                        }, function (err) {
                            alert(err);
                        });
                    }

                }

                for (var i = 0; i < $scope.companyContactArr.length; i++) {

                    utility.sqlGetAllRepresentativeDetails($scope.companyContactArr[i]).then(function (repResult) {
                        for (var k = 0; k < repResult[1].rows.length; k++) {
                            $scope.contactRepModel = utility.contactSelectionMod().uiObject;
                            $scope.contactRepModel.ContactName = repResult[0].CompanyName;
                            $scope.contactRepModel.ContactDeviceObjID = repResult[0].DeviceObjID;
                            $scope.contactRepModel.AttendeeDeviceObjID = repResult[0].DeviceObjID;
                            $scope.contactRepModel.ContactID = repResult[0].ContactID;
                            $scope.contactRepModel.UserID = $scope.contactRepModel.ContactID;
                            $scope.contactRepModel.ContactTypeID = repResult[0].ContactTypeID;
                            $scope.contactRepModel.ContactOwnerID = repResult[0].OwnerID;
                            $scope.contactRepModel.ContactOwnerName = repResult[0].OwnerName;
                            $scope.contactRepModel.CompanyName = repResult[0].CompanyName;
                            $scope.contactRepModel.CompanyID = repResult[0].ContactID;
                            $scope.contactRepModel.CompanyDeviceObjID = repResult[0].DeviceObjID;
                            $scope.contactRepModel.RepresentativeName = repResult[1].rows.item(k).FirstName + " " + repResult[1].rows.item(k).LastName;
                            $scope.contactRepModel.RepresentativeDeviceObjID = repResult[1].rows.item(k).DeviceObjID;
                            $scope.contactRepModel.RepresentativeID = repResult[1].rows.item(k).ContactID;
                            $scope.contactRepModel.DisplayName = $scope.contactRepModel.RepresentativeName + '(' + $scope.contactRepModel.CompanyName + ')';
                            $scope.contactRepModel.UserName = $scope.contactRepModel.DisplayName;

                            $scope.contactRepModel.ContactTierName = repResult[0].ContactTierName;
                            $scope.contactRepModel.ContactTierID = repResult[0].ContactTierID;
                            $scope.contactRepModel.ContactSegmentName = repResult[0].ContactSegmentName;
                            $scope.contactRepModel.ContactSegmentID = repResult[0].ContactSegmentID;

                            $scope.contactRepModel.IsChecked = false;
                            if (isEditModeFlag) {
                                utility.editSelUserList($scope.selCntPar, $scope.contactRepModel, selCntPar);
                                //$scope.contactRepModel.IsChecked = utility.editSelUserList($scope.selCntPar, $scope.contactRepModel);;
                            }
                            $scope.contactDisplayArr.push($scope.contactRepModel);

                            $scope.cntPars.push($scope.contactRepModel);
                            //console.log('contact model is' + JSON.stringify($scope.contactRepModel));
                            //console.log('contactDisplayArrObj is' + JSON.stringify($scope.contactDisplayArr));

                        }

                    }, function (err) {
                        alert(err);
                    });

                }

            }, function (err) {
                alert(err);
            });

        }


        function selectPar(selLst, tarLst, parType, type, isContact) {
            angular.forEach(selLst, function (obj, key) {
                var conUsrID = obj.EntityAttendeeID;
                var devParId = utility.generateUUID();
                if (typeof conUsrID == 'undefined' || conUsrID == null) {
                    conUsrID = 0;
                }
                if (isEditModeFlag) {
                    if (conUsrID != 0)
                        devParId = obj.DeviceObjID;
                }
                tarLst.push(
                    {
                        EntityAttendeeID: conUsrID,//obj.ActivityAttendeeID,//didn't get this value right now..hardcoded 0
                        AttendeeID: obj.UserID,
                        UserName: obj.UserName,
                        Type: type,
                        ParentDeviceObjType: parType,
                        DeviceObjID: devParId,
                        IsContact: isContact,
                        AttendeeDeviceObjID: obj.AttendeeDeviceObjID
                    });
            });
        }

        //close add actitvity screen
        $scope.closeActivity = function () {
            navigateURL();
        }

        function navigateURL() {
            if ($rootScope.previousState.name == 'tab.activityHappen') {
                $state.go($rootScope.previousState.name, $rootScope.previousStateParm);
            }
            else
                $state.go('tab.activity');
        }

        //diaplyed the date/time/duration
        function SetDateTime() {
            if ($scope.actModel.ActivityDuration > 0) {
                $scope.SelTimeDurDate = $scope.selDate.selDt + ' | ' + utility.convertTimeFormat($scope.actModel.ActivityTime) + ' | ' + $scope.actModel.ActivityDuration + ' min'
            }
            else {
                $scope.SelTimeDurDate = $scope.selDate.selDt + ' | ' + utility.convertTimeFormat($scope.actModel.ActivityTime);
            }
        }

        //set the cal date for displayed the textbox
        function SetCalDate(val, month, year) {
            var dt = new Date();
            dt.setDate(val);
            dt.setMonth((utility.monthNameToNum(month) - 1));
            dt.setFullYear(year);
            $scope.selDate.selDt = utility.getDateInDisplayFormat(dt);
            $scope.selDate.selDateFormat = dt;
        }

        ///////////////////////////////////model for the add fields start ////////////////////////////////

        function loadFields() {
            $scope.fields = [];
            for (var i = 0; i < $scope.fieldSet.length; i++) {
                $scope.actModel.Fields.push({
                    EntityID: $scope.actModel.ActivityID,
                    ModuleID: $scope.actModel.ModuleID,
                    ParentDeviceObjID: $scope.actModel.DeviceObjID,
                    FieldLabel: $scope.fieldSet[i].FieldLabel,
                    FieldName: $scope.fieldSet[i].FieldName,
                    FieldValue: '',
                    FieldID: $scope.fieldSet[i].FieldID,
                    IsConfidential: $scope.fieldSet[i].IsConfidential,
                    IsMandatory: $scope.fieldSet[i].IsMandatory,
                    IsVisible: $scope.fieldSet[i].IsVisible
                });
            }

            angular.copy($scope.actModel.Fields, $scope.fields);
        }

        $ionicModal.fromTemplateUrl('app/views/common/fields.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAddDet = modal;

        });

        $scope.openAddDetails = function () {
            $scope.modalAddDet.show();
        };

        $scope.closeAddDetails = function () {
            // utility.updateFieldList($scope.fields, $scope.selFields);
            utility.updateFldArrValues($scope.actModel.Fields, $scope.fields);
            $scope.modalAddDet.hide();
        };

        //save the field data
        $scope.actionField = function () {
            var validationFlag = true;

            validationFlag = utility.commonValidationDynamic($scope.fields);
            if (!validationFlag) {
                return false;
            }
            utility.updateFldArrValues($scope.fields, $scope.actModel.Fields);
            // angular.forEach($scope.fields, function (obj, key) {
            //     var indx = -1;
            //     indx = containsObject(obj, selLst);
            //     if (indx < 0)
            //         obj.Value = '';
            //     else
            //         obj.Value = selLst[indx].Value;
            // });
            // utility.updateFieldList($scope.fields, $scope.selFields);
            // utility.selectedFieldList($scope.fields, $scope.selFields);

            //var fielddb = $scope.fields;
            $scope.modalAddDet.hide();
        };
        //////////////////////////////////////////Fields END //////////////////////////////////////////////

        ///////////////////////////////////model for the location start ////////////////////////////////
        $scope.geoLocationArr = {}
        $ionicModal.fromTemplateUrl('app/views/common/geolocation.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalLocation = modal;
            //$scope.initMap();
        });

        $scope.openAddLocation = function () {
            $scope.geoLocationArr.address = $scope.actModel.Address;
            $scope.geoLocationArr.lat = $scope.actModel.LocLat;
            $scope.geoLocationArr.log = $scope.actModel.LocLog;
            $scope.$broadcast('changeText', {});
            $scope.modalLocation.show();
        };
        $scope.closeLocation = function () {
            $scope.modalLocation.hide();
        };

        //save the field data
        $scope.actionLocation = function () {
            //var field = $scope.actModel;
            $scope.actModel.Address = $scope.geoLocationArr.address;
            $scope.actModel.LocLat = $scope.geoLocationArr.lat;
            $scope.actModel.LocLog = $scope.geoLocationArr.log;

            $scope.modalLocation.hide();
        };

        //////////////////////////////////////////location END //////////////////////////////////////////////


        ////////////////////////////////// Modal for user list start//////////////////////////////////////////

        //$scope.selUserOwners = {
        //    activeUser: $scope.actModel.CreatorID,
        //    tempUser: $scope.actModel.CreatorID
        //};

        /*$scope.cntPars = [
           { ActivityAttendeeID: 0, UserID: 1, Type: 'CP', UserName: "int John", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 2, Type: 'CP', UserName: "int James", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 3, Type: 'CP', UserName: "int Maria", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 4, Type: 'CP', UserName: "int David", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 5, Type: 'CP', UserName: "Reese", IsChecked: false }
        ];
        $scope.actOwners = [
            { value: "1", Text: 'Randhir' },
            { value: "2", Text: 'Aman' },
            { value: "3", Text: 'Raja' },
            { value: "4", Text: 'Rock' }
        ];
        $scope.userPars = [
           { ActivityAttendeeID:0 ,UserID: 1, Type: 'UP', PermissionType: '', UserName: "John", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 2, Type: 'UP', PermissionType: '', UserName: "James", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 3, Type: 'UP', PermissionType: '', UserName: "Maria", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 4, Type: 'UP', PermissionType: '', UserName: "David", IsChecked: false },
           { ActivityAttendeeID: 0, UserID: 5, Type: 'UP', PermissionType: '', UserName: "Reese", IsChecked: false }
        ];*/
        function loadUsersData() {
            $scope.userPars = [];
            $scope.userActivityOwner = [];
            authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.OtherAttendeeUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var newObj = result.rows.item(i);
                    newObj.AttendeeDeviceObjID = "0";
                    newObj.IsChecked = false;
                    if (isEditModeFlag) {
                        utility.editSelUserList($scope.selUsrPar, newObj, selUsrPar);
                        //newObj.IsChecked = utility.editSelUserList($scope.selUsrPar, newObj);;
                    }
                    $scope.userPars.push(newObj);
                }
                //if (actID != 0) {
                //    utility.updateUserList($scope.userPars, $scope.selUsrPar);
                //}
                //console.log($scope.userPars);
            });
            authService.userListLoadByUserCategory(GENERAL_CONFIG.UsersCategory.ActivityOwnershipUsers).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.userActivityOwner.push(result.rows.item(i));
                }
                for (var i = $scope.userActivityOwner.length - 1; i >= 0; i--) {
                    if ($scope.userActivityOwner[i].UserID == $scope.selUserOwners.activeUser) {
                        $scope.selActivityOwner = $scope.userActivityOwner[i].UserName;
                    }
                }
            });
        }

        $scope.modelSelected = '';
        $ionicModal.fromTemplateUrl('app/views/common/userList.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalUser = modal;
        });

        $scope.openUserList = function (val) {
            if (actID != 0 && val == 'CN') {
                return;
            }
            if (val == 'CN' && $rootScope.previousState.name == 'tab.activityHappen') {
                return;
            }
            ////console.log($scope.userPars);
            $scope.modelSelected = val;
            if ($scope.modelSelected == 'AO') {
                $scope.selUserOwners.tempUser = $scope.selUserOwners.activeUser;
            }
            else if ($scope.modelSelected == 'CN') {
                $scope.selContacts.activeContact = $scope.selContacts.tempContact;
            }
            $scope.modalUser.show();
        };
        $scope.closeUserList = function () {
            if ($scope.modelSelected == 'C') {
                utility.updateUserList($scope.cntPars, $scope.selCntPar);
            }
            else if ($scope.modelSelected == 'I') {
                utility.updateUserList($scope.userPars, $scope.selUsrPar);
            }
            else if ($scope.modelSelected == 'AO') {
            }
            $scope.modalUser.hide();
        };

        function CheckNull(val) {
            if (typeof val == null || val == "null" || typeof val == 'undefined') {
                return null;
            }
            return val;
        }

        $scope.CheckRepresentativeDeviceObjID = '';
        $scope.radioLink = function (devId) {
            $scope.CheckRepresentativeDeviceObjID = devId;
        }

        $scope.actionUserList = function () {
            //var userLst = $scope.userList;
            if ($scope.modelSelected == 'C') {
                utility.selectedUserList($scope.cntPars, $scope.selCntPar);
            }
            else if ($scope.modelSelected == 'I') {
                utility.selectedUserList($scope.userPars, $scope.selUsrPar);
                //console.log($scope.selUsrPar);
            }
            else if ($scope.modelSelected == 'AO') {
                $scope.selUserOwners.activeUser = $scope.selUserOwners.tempUser;
                for (var i = $scope.userActivityOwner.length - 1; i >= 0; i--) {
                    if ($scope.userActivityOwner[i].UserID == $scope.selUserOwners.activeUser) {
                        $scope.selActivityOwner = $scope.userActivityOwner[i].UserName;
                    }
                }
            }
            else if ($scope.modelSelected == 'CN') {
                $scope.selContacts.tempContact = $scope.selContacts.activeContact;
                for (var i = 0; i < $scope.contactDisplayArr.length; i++) {
                    if ($scope.contactDisplayArr[i].ContactDeviceObjID == $scope.selContacts.activeContact) {
                        //$scope.actModel.ContactDisplayName = $scope.contactDisplayArr[i].ContactName;
                        $scope.actModel.ContactName = $scope.contactDisplayArr[i].ContactName;
                        $scope.actModel.CompanyName = $scope.contactDisplayArr[i].CompanyName;
                        $scope.actModel.ContactID = $scope.contactDisplayArr[i].ContactID;//temp commented
                        $scope.actModel.ContactTypeID = $scope.contactDisplayArr[i].ContactTypeID;

                        if ($scope.actModel.ContactTypeID == 1) {
                            $scope.actModel.EmployerID = CheckNull($scope.contactDisplayArr[i].EmployerID);
                            $scope.actModel.ContactDisplayName = $scope.contactDisplayArr[i].ContactName;
                            $scope.actModel.EmployerName = $scope.contactDisplayArr[i].EmployerName;
                        }
                        else {
                            if ($scope.CheckRepresentativeDeviceObjID == $scope.contactDisplayArr[i].RepresentativeDeviceObjID) {
                                $scope.actModel.RepresentativeID = CheckNull($scope.contactDisplayArr[i].RepresentativeID);
                                $scope.actModel.ContactDisplayName = $scope.contactDisplayArr[i].RepresentativeName;
                                $scope.actModel.RepresentativeName = $scope.contactDisplayArr[i].RepresentativeName;
                                $scope.actModel.RepresentativeDeviceObjID = $scope.contactDisplayArr[i].RepresentativeDeviceObjID;
                            }
                        }

                        $scope.actModel.ContactDeviceObjID = $scope.contactDisplayArr[i].ContactDeviceObjID;
                        $scope.actModel.ContactTierName = $scope.contactDisplayArr[i].ContactTierName;
                        $scope.actModel.ContactTierID = utility.CheckModelNull($scope.contactDisplayArr[i].ContactTierID);
                        $scope.actModel.ContactSegmentName = $scope.contactDisplayArr[i].ContactSegmentName;
                        $scope.actModel.ContactSegmentID = utility.CheckModelNull($scope.contactDisplayArr[i].ContactSegmentID);

                        loadSubject();
                    }
                }
            }
            $scope.modalUser.hide();
        };
        ////////////////////////////////// user list END//////////////////////////////////////////
    };
})();
