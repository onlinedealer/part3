import * as express from "express";
import * as bodyParser from "body-parser";

import { SessionService } from "./services/session.service";
import { securityRouter } from "./routers/security.router";

import * as cors from "cors";
import { timer } from "rxjs";

SessionService.getSession();
timer(60000, 300000).subscribe(() => SessionService.refreshSession());

const app = express();
app.use(bodyParser.text());
app.use(cors());

app.use("/AIMUI/security", securityRouter);

export default app;
