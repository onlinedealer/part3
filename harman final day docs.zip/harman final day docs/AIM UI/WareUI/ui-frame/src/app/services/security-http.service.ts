import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";

@Injectable({
    providedIn: "root"
})
export class SecurityHTTPService {
    constructor(private http: HttpClient) {}

    public put<T>(url: string, body: any, options?: any): Observable<any> {
        return this.http.put<T>(url, body, options);
    }

    public get<T>(url: string, options?: any): Observable<any> {
        return this.http.get(url, options);
    }

    public post<T>(url: string, body: any, options?: any): Observable<any> {
        return this.http.post(url, body, options);
    }

    public delete<T>(url: string, options?: any): Observable<any> {
        return this.http.delete(url, options);
    }
}
