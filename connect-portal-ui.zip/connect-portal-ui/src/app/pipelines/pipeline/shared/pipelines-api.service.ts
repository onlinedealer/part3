import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { BaseConnectApiService } from '../../../core/base-connect-api.service';
import { Pipeline } from './pipeline';

@Injectable({
  providedIn: 'root'
})
export class PipelinesApiService extends BaseConnectApiService<Pipeline> {
  constructor(protected httpClient: HttpClient) {
    super(httpClient, 'cdc/dataflows');
  }
  baseServiceUrl = `${environment.connectApiBaseURL}/cdc/dataflows`;

  validateFilter(id: string, table: string, expression: string): Observable<any> {
    const requestBody = {
      table,
      expression
    };
    return this.httpClient.post(`${this.baseServiceUrl}/${id}/filters/validate`, requestBody);
  }
}
