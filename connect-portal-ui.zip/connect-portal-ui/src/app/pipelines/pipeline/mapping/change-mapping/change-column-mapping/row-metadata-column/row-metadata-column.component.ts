import { Component, EventEmitter, Input, Output } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';

@Component({
  selector: 'p-connect-row-metadata-column',
  templateUrl: './row-metadata-column.component.html',
  styleUrls: ['./row-metadata-column.component.scss']
})
export class RowMetadataColumnComponent {
  @Output() emitMetaData = new EventEmitter<any>();
  @Input() metaData;
  sortedFlag = false;

  constructor(public readonly translocoService: TranslocoService) {}
  onChangeMetaDataCheckbox(event) {
    const getIndex = this.metaData
      .map(function (x) {
        return x.key;
      })
      .indexOf(event.key);
    if (this.metaData[getIndex].isChecked) {
      this.metaData[getIndex].cdcRowMetadataType = 'INCLUDE';
    } else {
      this.metaData[getIndex].cdcRowMetadataType = 'EXCLUDE';
    }
    this.emitMetaData.emit(this.metaData);
  }
}
