(function() {
    'use strict';

    fileuploader.controller("viewTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', '$location', '$route', '$window', '$http', viewTemplateCtrl]);

    function viewTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, $location, $route, $http) {

        $scope.uploadPreviewTemplate = "";
        $rootScope.globalListTempData = "";
        var rowData = $rootScope.globalTemplateD;

        $scope.fetchpreviewData = function() {
            var id = rowData.tiffid;
            var url = "/ocr/rest/v1/service/get/tiffimageString/tiff/file/" + id;
            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
            $scope.getId = id;
            promise.then(function(data) {
                var outputimage = data;
                $scope.templateViewData = data;
                var output = "data:image/tiff;base64," + outputimage.inputdata;
                $scope.uploadPreviewTemplate = output;
                //$rootScope.globalImgPreview = $scope.uploadPreviewTemplate;
                //console.log($scope.uploadpreview)
            });
            promise.catch(function(data) {
                console.log('catch block executed', data);
                return data;
            });
        };
        $scope.fetchpreviewData();


        $scope.dataOfRowFun = function() {
            var tempData = $rootScope.globalListTempData;
            for (var i = tempData.length - 1; i >= 0; i--) {
                var obj = tempData[i]
                if (obj._id == rowData_id) {
                    obj = $scope.ViewImageArray;
                    console.log(obj)
                        //break;
                }
            }
        };
        $scope.dataOfRowFun();

        var dataOfRow = $rootScope.templateViewData;
        //var rows = [{"x":8,"y":167,"h":466,"w":68}];
        /*var dimenstions = $scope.templateViewData;
        console.log($scope.templateViewData)*/
        var width = dataOfRow.imagewidth;
        var height = dataOfRow.imageheight;
        var rows = dataOfRow.rows;
        $(document).ready(function() {
            var d_canvas = document.getElementById('canvas');
            var context = d_canvas.getContext('2d');
            var background = document.getElementById('background');
            context.drawImage(background, 0, 0);

            for (var i = 0; i < rows.length; i++) {
                var x = ((rows[i].x) * width) / 100;
                var y = ((rows[i].y) * height) / 100;
                var h = ((rows[i].h) * height) / 100;
                var w = ((rows[i].w) * width) / 100;
                context.strokeRect(rows[i].x, rows[i].y, rows[i].h, rows[i].w);
            }

        });

    }

})();
