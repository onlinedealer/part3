import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

/**
 * @internal
 */
@Component({
  selector: 'discovery-ok',
  templateUrl: './ok.component.html'
})
export class OkComponent {
  title: string;

  titleParams?: Record<string, string>;
  message: string;

  messageParams?: Record<string, string>;

  constructor(public activeModal: NgbActiveModal) {}
}
