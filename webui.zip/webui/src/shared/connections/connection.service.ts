import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { ISchemas } from 'core/entities/schema.model';
import { TableModel } from 'discovery-core';
import { AuthenticationService } from 'discovery-shared';
import { Observable } from 'rxjs';
import { ConnectionModel } from './connection.model';

@Injectable({
  providedIn: 'root'
})
export class ConnectionService {
  /**
   *
   */
  baseUrl: string;

  /**
   *
   * @param httpClient
   * @param authenticationService
   */
  constructor(
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('configapi', 'profiling', 'api/v1/');
  }

  /**
   *
   */
  getConnectionList(): Observable<ConnectionModel[]> {
    return this.httpClient.get(this.baseUrl + 'connections', {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<ConnectionModel[]>;
  }

  /**
   *
   * @param connectionId
   */
  testConnectionByID(connectionId: string): Observable<any> {
    return this.httpClient.get(this.baseUrl + 'connection/test/' + connectionId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  /**
   *
   * @param connectionModel
   */
  testConnectionByObject(connectionModel: ConnectionModel) {
    return this.httpClient.post(this.baseUrl + 'connection/test/', connectionModel, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  /**
   *
   * @param connectionId
   */
  deleteConnection(connectionId: string): Observable<any> {
    return this.httpClient.delete(this.baseUrl + 'connection/' + connectionId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  /**
   *
   * @param connectionModel
   * @param newConnection
   */
  saveConnection(connectionModel: ConnectionModel, newConnection: boolean) {
    if (newConnection) {
      return this.httpClient.post(this.baseUrl + 'connection', connectionModel, {
        headers: this.authenticationService.getHttpHeaders()
      });
    } else {
      return this.httpClient.put(this.baseUrl + 'connection/' + connectionModel.id, connectionModel, {
        headers: this.authenticationService.getHttpHeaders()
      });
    }
  }

  /**
   *
   * @param connectionId
   */
  getConnectionById(connectionId: string): Observable<ConnectionModel> {
    return this.httpClient.get(this.baseUrl + 'connection/' + connectionId, {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<ConnectionModel>;
  }

  getGovernSchemaByConnectionId(connectionId: string): Observable<ISchemas[]> {
    return this.httpClient.get<ISchemas[]>(this.baseUrl + 'connection/listSchema/' + connectionId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  /**
   *
   * @param connectionType
   * @param connectionName
   */
  getTableList(
    connectionType: string,
    connectionName: string,
    isCatalog: boolean,
    connectionId?: string,
    schemaName?: string
  ): Observable<TableModel[]> {
    if (isCatalog) {
      return this.fetchGovernTablesApi(connectionId, schemaName);
    } else {
      return this.httpClient.get(
        this.baseUrl + 'connection/configuration/datasource/' + connectionType + '/' + connectionName,
        {
          headers: this.authenticationService.getHttpHeaders()
        }
      ) as Observable<TableModel[]>;
    }
  }

  fetchGovernTablesApi(connectionId: string, schemaName: string): Observable<TableModel[]> {
    return this.httpClient.get<TableModel[]>(this.baseUrl + 'connection/listTable/' + connectionId + '/' + schemaName, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  fetchGovernColumnsApi(connectionId: string, schemaName: string, tableName: string, type: string) {
    return this.httpClient.get<TableModel[]>(
      this.baseUrl + `connection/listColumn/${connectionId}/schema/table/columns`,
      {
        headers: this.authenticationService.getHttpHeaders(),
        params: new HttpParams().set('schemaName', schemaName).set('tableName', tableName).set('TYPE', type)
      }
    );
  }

  getColumnList(
    connectionType: string,
    connectionName: string,
    tableColumnModel: TableModel,
    isCatalog: boolean,
    connectionId?: string
  ): Observable<TableModel[]> {
    if (isCatalog) {
      return this.fetchGovernColumnsApi(
        connectionId,
        tableColumnModel.schema,
        tableColumnModel.name,
        tableColumnModel.type
      );
    } else {
      return this.httpClient.get(
        this.baseUrl +
          'connection/configuration/datasource/' +
          connectionType +
          '/' +
          connectionName +
          '/table' +
          '/columns',
        {
          headers: this.authenticationService.getHttpHeaders(),
          params: new HttpParams()
            .set('SCHEMA', tableColumnModel.schema)
            .set('TYPE', tableColumnModel.type)
            .set('table', tableColumnModel.name)
        }
      ) as Observable<TableModel[]>;
    }
  }
}
