import { Injectable } from "@angular/core";

// This class implements a service which can be used to share translations of
// common words/texts between several classes.

@Injectable({ providedIn: "root" })
export class TranslationsService {
    private translationMap: Map<string, string> = new Map([
        ["Alarm flag", $localize`:|@@commonTranslations.alarmFlag:Alarm flag`],
        ["Alarm", $localize`:|@@commonTranslations.alarm:Alarm`],
        ["Cancel", $localize`:|@@commonTranslations.cancel:Cancel`],
        ["Close", $localize`:|@@commonTranslations.close:Close`],
        ["Send", $localize`:|@@commonTranslations.send:Send`],
        ["Next", $localize`:|@@commonTranslations.next:Next`],
        ["Metering point", $localize`:|@@commonTranslations.meteringPoint:Metering point`],
        ["Name", $localize`:|@@commonTranslations.name:Name`],
        ["Address", $localize`:|@@commonTranslations.address:Address`],
        ["Street name", $localize`:|@@commonTranslations.streetName:Street name`],
        ["Device number", $localize`:|@@commonTranslations.deviceNumber:Device serial number`],
        ["Meter number", $localize`:|@@commonTranslations.meterNumber:Meter number`],
        ["Measurement unit", $localize`:|@@commonTranslations.measurementUnit:Measurement unit`],
        ["Customer number", $localize`:|@@commonTranslations.customerNumber:Customer number`],
        ["Customer name", $localize`:|@@commonTranslations.customerName:Customer name`],
        ["Customer property number", $localize`:|@@meteringPointDevices.source:Customer property number`],
        ["Customer address", $localize`:|@@commonTranslations.customerAddress:Customer address`],
        ["Postal code", $localize`:|@@commonTranslations.postalCode:Postal code`],
        ["GSRN", "GSRN"], // Probably no need to translate. $localize`:|@@commonTranslations.gsrn:GSRN`],
        ["OBIS code", $localize`:|@@commonTranslations.obisCode:OBIS code`],
        ["Period length", $localize`:|@@commonTranslations.periodLength:Period length`],
        [
            "No data available for the selected time period",
            $localize`:|@@commonTranslations.noDataForPeriod:No data available for the selected time period`
        ],
        ["Register", $localize`:|@@commonTranslations.register:Register`],
        ["Registers", $localize`:|@@commonTranslations.registers:Registers`],
        ["Overview", $localize`:|@@commonTranslations.overview:Overview`],
        ["Metering", $localize`:|@@commonTranslations.metering:Metering`],
        ["Meterings", $localize`:|@@commonTranslations.meterings:Meterings`],
        ["Event", $localize`:|@@commonTranslations.event:Event`],
        ["Events", $localize`:|@@commonTranslations.events:Events`],
        ["Devices", $localize`:|@@commonTranslations.devices:Devices`],
        ["Reading time", $localize`:|@@commonTranslations.readingTime:Reading time`],
        ["Relays", $localize`:|@@commonTranslations.relays:Relays`],
        ["Configurations and registers", $localize`:|@@commonTranslations.configurationsRegisters:Configurations and registers`],
        ["Transformers", $localize`:|@@commonTranslations.transformerView:Transformers`],
        ["Transformer area", $localize`:|@@commonTranslations.transformerArea:Transformer area`],

        ["States", $localize`:|@@commonTranslations.states:States`],
        ["Selected relay:", $localize`:|@@commonTranslations.selectedRelay:Selected relay:`],
        ["Current state:", $localize`:|@@commonTranslations.currentState:Current state:`],
        ["Current state read:", $localize`:|@@commonTranslations.currentStateRead:Current state read:`],

        ["Custom properties", $localize`:|@@commonTranslations.customProperties:Custom properties`],
        ["Property", $localize`:|@@commonTranslations.Property:Property`],
        ["Parameters and statuses", $localize`:|@@commonTranslations.parameterStatuses:Parameters and statuses`],
        ["Custom property", $localize`:|@@commonTranslations.customProperty:Custom property`],
        ["Category", $localize`:|@@commonTranslations.category:Category`],
        ["Serial Number", $localize`:|@@commonTranslations.serialNumber:Serial Number`],
        ["Connection Type", $localize`:|@@commonTranslations.connectionType:Connection Type`],
        ["Configuration", $localize`:|@@commonTranslations.configuration:Configuration`],
        ["From", $localize`:|@@commonTranslations.from:From`],
        ["To", $localize`:|@@commonTranslations.to:To`],
        ["Valid from", $localize`:|@@commonTranslations.validFrom:Valid from`],
        ["Valid to", $localize`:|@@commonTranslations.validTo:Valid to`],
        // NOTE! "Valid until" is translated as "Valid to" because of consistency
        ["Valid until", $localize`:|@@commonTranslations.validTo:Valid to`],
        ["Time", $localize`:|@@commonTranslations.time:Time`],
        ["Start time", $localize`:|@@commonTranslations.startTime:Start time`],
        ["Status", $localize`:|@@commonTranslations.status:Status`],
        ["End time", $localize`:|@@commonTranslations.endTime:End time`],
        ["Type", $localize`:|@@commonTranslations.type:Type`],
        ["Phase", $localize`:|@@commonTranslations.phase:Phase`],
        ["Duration", $localize`:|@@commonTranslations.duration:Duration`],
        ["d,h,min,s", $localize`:|@@commonTranslations.durationUnits:d,h,min,s`],
        ["Level", $localize`:|@@commonTranslations.level:Level`],
        ["Title", $localize`:|@@commonTranslations.title:Title`],
        ["Token log", $localize`:|@@commonTranslations.tokenLog:Token log`],
        ["Restore default settings", $localize`:|@@commonTranslations.RestoreDefaultSettings:Restore default settings`],
        ["Value", $localize`:|@@commonTranslations.value:Value`],
        ["Cum. value", $localize`:|@@commonTranslations.cumValue:Cum. value`],
        ["Cumulative value", $localize`:|@@commonTranslations.cumulativeValue:Cumulative value`],
        ["Cum. pulse value", $localize`:|@@commonTranslations.cumPulseValue:Cum. pulse value`],
        ["Cumulative pulse value", $localize`:|@@commonTranslations.cumulativePulseValue:Cumulative pulse value`],
        ["Original value", $localize`:|@@commonTranslations.originalValue:Original value`],
        ["Period ending", $localize`:|@@commonTranslations.periodEnding:Period ending`],
        ["Peak time", $localize`:|@@commonTranslations.peakTime:Peak time`],
        ["Original cum. value", $localize`:|@@commonTranslations.originalCumValue:Original cum. value`],
        ["Original cumulative value", $localize`:|@@commonTranslations.originalCumulativeValue:Original cumulative value`],
        ["Description", $localize`:|@@commonTranslations.description:Description`],
        ["Product", $localize`:|@@commonTranslations.product:Product`],
        ["Loading data...", $localize`:|@@commonTranslations.loadingData:Loading data...`],
        ["Edit columns", $localize`:|@@commonTranslations.editColumn:Edit columns`],
        ["Expanded", $localize`:|@@commonTranslations.expanded:Expanded`],
        ["Chart options", $localize`:|@@commonTranslations.chartOptions:Chart options`],
        ["Show", $localize`:|@@commonTranslations.show:Show`],
        ["Years", $localize`:|@@commonTranslations.years:Years`],
        ["Months", $localize`:|@@commonTranslations.months:Months`],
        ["Week", $localize`:|@@commonTranslations.week:Week`],
        ["Weeks", $localize`:|@@commonTranslations.weeks:Weeks`],
        ["Days", $localize`:|@@commonTranslations.days:Days`],
        ["All readings", $localize`:|@@commonTranslations.allReadings:All readings`],
        ["Min", $localize`:|@@commonTranslations.min:Min`],
        ["Max", $localize`:|@@commonTranslations.max:Max`],
        ["Total", $localize`:|@@commonTranslations.total:Total`],
        ["Command", $localize`:|@@commonTranslations.command:Command`],
        ["Details", $localize`:|@@commonTranslations.details:Details`],

        ["Edit y-axis", $localize`:|@@commonTranslations.graphs.editYAxis:Edit y-axis`],
        ["Scale visible", $localize`:|@@commonTranslations.graphs.scaleVisible:Scale visible`],
        ["Auto-scaling", $localize`:|@@commonTranslations.graphs.autoScaling:Auto-scaling`],
        ["Primary y-axis", $localize`:|@@commonTranslations.graphs.primaryYAxis:Primary y-axis`],
        ["Secondary y-axis", $localize`:|@@commonTranslations.graphs.secondaryYAxis:Secondary y-axis`],

        ["Export table", $localize`:|@@commonTranslations.exportTable:Export table`],

        ["Change password", $localize`:|@@commonTranslations.changePassword:Change password`],
        ["User settings", $localize`:|@@commonTranslations.userSettings:User settings`],
        ["Edit profile", $localize`:|@@commonTranslations.editProfile:Edit profile`],
        ["fi", $localize`:|@@commonTranslations.userSettingsLanguage.Finnish:Finnish`],
        ["sv", $localize`:|@@commonTranslations.userSettings.userSettingsLanguage.Swedish:Swedish`],
        ["en", $localize`:|@@commonTranslations.userSettings.userSettingsLanguage.English:English`],
        ["pl", $localize`:|@@commonTranslations.userSettings.userSettingsLanguage.Polish:Polish`],
        ["da", $localize`:|@@commonTranslations.userSettings.userSettingsLanguage.Danish:Danish`],
        ["no", $localize`:|@@commonTranslations.userSettings.userSettingsLanguage.Norwegian:Norwegian`],
        ["de", $localize`:|@@commonTranslations.userSettings.userSettingsLanguage.German:German`],

        ["Status", $localize`:|@@commonTranslations.status:Status`],
        ["Original status", $localize`:|@@commonTranslations.originalStatus:Original status`],
        ["Validated status", $localize`:|@@commonTranslations.validatedStatus:Validated status`],
        ["Source", $localize`:|@@commonTranslations.source:Source`],
        ["timeZonesOthers", $localize`:|@@timeZonesOthers:Other time zones`],
        ["Product component", $localize`:|@@productComponents.productComponents:Product component`],
        ["System", $localize`:|@@commonTranslations.system:System`],
        ["Local tool", $localize`:|@@commonTranslations.localTool:Local tool`],
        ["Manual", $localize`:|@@commonTranslations.manual:Manual`],
        ["Add", $localize`:|@@commonTranslations.add:Add`],
        ["Add new", $localize`:|@@commonTranslations.addNew:Add new`],
        ["Mains", $localize`:|@@commonTranslations.mains:Mains`],
        ["Normal", $localize`:|@@commonTranslations.normal:Normal`],
        ["Delete", $localize`:|@@commonTranslations.delete:Delete`],
        ["Delete Relay", $localize`:|@@commonTranslations.deleteRelay:Delete relay`],
        ["Save", $localize`:|@@commonTranslations.save:Save`],
        ["Add new relay", $localize`:|@@commonTranslations.addNewRelay:Add new relay`],
        ["Edit relay", $localize`:|@@commonTranslations.editRelay:Edit relay`],
        ["RELAY 1", $localize`:|@@commonTranslations.relay1:Relay 1`],
        ["AdvancedFilter", $localize`:@@commonTranslations.AdvanceFilter: Advanced filter`],
        ["NoDataFound", $localize`:@@commonTranslations.NoDataFound:No results found`],
        ["SearchText", $localize`:@@commonTranslations.SearchText:Search `],
        ["SearchPlaceHolder", $localize`:@@commonTranslations.searchPlaceHolder:Search...`],
        ["Scheduled reading", $localize`:@@commonTranslations.scheduledReading: Scheduled reading`],
        ["Select a usage...", $localize`:@@commonTranslations.selectUsage: Select a usage...`],
        ["Select a relay...", $localize`:@@commonTranslations.selectRelay: Select a relay...`],
        ["Select time range...", $localize`:@@commonTranslations.selectTimeRange: Select time range...`],
        ["Task name", $localize`:@@commonTranslations.taskName: Task name`],
        ["Modified", $localize`:@@commonTranslations.modified: Modified`],
        ["Success", $localize`:@@commonTranslations.success: Success`],
        ["Operation", $localize`:@@commonTranslations.operation: Operation`],
        ["Multiplication", $localize`:@@commonTranslations.multiplication: Multiplication`],
        ["Subtraction", $localize`:@@commonTranslations.subtraction: Subtraction`],
        ["Addition", $localize`:@@commonTranslations.addition: Addition`],
        ["Division", $localize`:@@commonTranslations.division:Division `],
        ["Constant", $localize`:@@commonTranslations.constant: Constant`],
        ["Created by", $localize`:@@commonTranslations.createdBy: Created by`],
        ["Target name", $localize`:@@commonTranslations.targetName: Target name`],
        ["Remark", $localize`:@@commonTranslations.remark: Remark`],
        ["Remark modified by", $localize`:@@commonTranslations.remarkModifiedBy: Remark modified by`],
        ["Active connections", $localize`:@@commonTranslations.activeConnections: Active connections`],
        ["Inactive connections", $localize`:@@commonTranslations.inactiveConnections: Inactive connections`],
        ["No connections", $localize`:@@commonTranslations.noConnections: No connections`],
        ["Deleted connections", $localize`:@@commonTranslations.deletedConnections: Deleted connections`],
        ["Remark modified", $localize`:@@commonTranslations.remarkModified: Remark modified`],
        ["Handling status", $localize`:@@commonTranslations.handlingStatus: Handling status`]
    ]);

    private errorTranslationMap: Map<string, string> = new Map([
        ["400", $localize`:|@@commonErrorTranslations.400:System error. Please contact your system administrator.`],
        ["401", $localize`:|@@commonErrorTranslations.401:Session is invalid. Please re-login.`],
        [
            "403",
            // tslint:disable-next-line: max-line-length
            $localize`:|@@commonErrorTranslations.403:Connection to AIM forbidden. Please contact your system administrator to check permissions in UAM.`
        ],
        ["404", $localize`:|@@commonErrorTranslations.404:The requested resource was not found. Please contact your system administrator.`],
        ["408", $localize`:|@@commonErrorTranslations.408:Failed to connect to the server. Please contact your system administrator.`],
        [
            "504",
            // tslint:disable-next-line: max-line-length
            $localize`:|@@commonErrorTranslations.504:Request timed out. Please try again later. If the problem persists, please contact your system administrator.`
        ],
        [
            "CONN_REFUSED",
            // tslint:disable-next-line: max-line-length
            $localize`:|@@commonErrorTranslations.CONN_REFUSED:Failed to connect to the server. Please try again later. If the problem persists, please contact your system administrator.`
        ],
        [
            "SESSION_EXPIRED",
            // tslint:disable-next-line: max-line-length
            $localize`:|@@commonErrorTranslations.SESSION_EXPIRED:Session expired, please re-login. If the problem persists, please contact your system administrator.`
        ]
    ]);
    constructor() {}

    public getTranslation(text: string): string {
        const translation = this.translationMap.get(text);
        return translation ? translation : "?" + text;
    }

    public getErrorTranslation(text: string): string {
        const translation = this.errorTranslationMap.get(text);
        return translation ? translation : "?" + text;
    }
}
