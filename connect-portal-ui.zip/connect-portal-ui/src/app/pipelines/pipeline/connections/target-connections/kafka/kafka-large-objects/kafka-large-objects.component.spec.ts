import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from '../../../../../../core/transloco-testing.module';
import { KafkaLargeObjectsComponent } from './kafka-large-objects.component';

describe('KafkaLargeObjectsComponent', () => {
  let component: KafkaLargeObjectsComponent;
  let fixture: ComponentFixture<KafkaLargeObjectsComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [KafkaLargeObjectsComponent],
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule, DropdownModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: '' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(KafkaLargeObjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should validate maxlob when size is bytes', () => {
    component.largeObjectsForm.get('maxLOB').setValue(55);
    component.largeObjectsForm.get('sizeFormat').setValue('bytes');
    component.largeObjectsForm.updateValueAndValidity();
    expect(component.largeObjectsForm.get('maxLOB').hasError('invalidSizeFormat')).toBeTruthy();
  });

  it('should validate maxlob when size is KB', () => {
    component.largeObjectsForm.get('maxLOB').setValue('2000001');
    component.largeObjectsForm.get('sizeFormat').setValue('KB');
    component.largeObjectsForm.updateValueAndValidity();
    expect(component.largeObjectsForm.get('maxLOB').hasError('invalidSizeFormat')).toBeTruthy();
  });

  it('should validate maxlob when size is MB', () => {
    component.largeObjectsForm.get('maxLOB').setValue('2001');
    component.largeObjectsForm.get('sizeFormat').setValue('MB');
    component.largeObjectsForm.updateValueAndValidity();
    expect(component.largeObjectsForm.get('maxLOB').hasError('invalidSizeFormat')).toBeTruthy();
  });

  it('should validate maxlob when size is GB', () => {
    component.largeObjectsForm.get('maxLOB').setValue('3');
    component.largeObjectsForm.get('sizeFormat').setValue('GB');
    component.largeObjectsForm.updateValueAndValidity();
    expect(component.largeObjectsForm.get('maxLOB').hasError('invalidSizeFormat')).toBeTruthy();
  });
});
