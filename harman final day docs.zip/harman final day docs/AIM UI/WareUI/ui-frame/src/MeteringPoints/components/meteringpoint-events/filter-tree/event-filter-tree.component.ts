import { Component, OnInit, OnDestroy } from "@angular/core";
import { FlatTreeControl } from "@angular/cdk/tree";
import { MatTreeFlatDataSource, MatTreeFlattener } from "@angular/material/tree";
import { SelectionModel, SelectionChange } from "@angular/cdk/collections";
import { Store } from "@ngrx/store";
import { Subscription, combineLatest } from "rxjs";
import { takeUntil, tap } from "rxjs/operators";
import { TodoItemFlatNode, TodoItemNode } from "../../../store/reducers/event-definitions.reducer";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { EventDefinitionsSelectors, EventsSelectors } from "../../../store/selectors";
import { EventsActions, PqiDataActions } from "../../../store/actions";

enum tabOptions {
    Events = "events",
    Table = "eventtable",
    PowerQuality = "powerQuality"
}

@Component({
    selector: "landisgyr-event-filter-tree",
    templateUrl: "./event-filter-tree.component.html",
    styleUrls: ["./event-filter-tree.component.scss"]
})
export class EventFilterTreeComponent implements OnInit, OnDestroy {
    allEventsExpanded = true;
    parentNode!: TodoItemFlatNode;

    flatNodeMap = new Map<TodoItemFlatNode, TodoItemNode>();

    nestedNodeMap = new Map<TodoItemNode, TodoItemFlatNode>();

    selectedParent: TodoItemFlatNode | null = null;

    treeControl!: FlatTreeControl<TodoItemFlatNode>;

    treeFlattener!: MatTreeFlattener<TodoItemNode, TodoItemFlatNode>;

    dataSource!: MatTreeFlatDataSource<TodoItemNode, TodoItemFlatNode>;

    checklistSelection = new SelectionModel<TodoItemFlatNode>(true /* multiple */);

    combineSub!: Subscription;
    filterChangeSub!: Subscription;
    filterFormSub!: Subscription;
    tab!: string;
    searchTerm!: string;
    addToUndo!: boolean;

    constructor(private store: Store<MeteringPointsFeatureState>) {
        this.treeFlattener = new MatTreeFlattener(this.transformer, this.getLevel, this.isExpandable, this.getChildren);
        this.treeControl = new FlatTreeControl<TodoItemFlatNode>(this.getLevel, this.isExpandable);
        this.dataSource = new MatTreeFlatDataSource(this.treeControl, this.treeFlattener);

        this.combineSub = combineLatest([
            this.store.select(EventDefinitionsSelectors.getEventTreeTypes),
            this.store.select(EventDefinitionsSelectors.getSelectedEventDefinitionIDs),
            this.store.select(EventsSelectors.getEventsActiveView),
            this.store.select(EventDefinitionsSelectors.getPqiTreeTypes),
            this.store.select(EventDefinitionsSelectors.getSelectedPqiDefinitionIDs)
        ])
            .pipe(
                tap(([EventsFilters, eventselectedDefsIds, activeView, pqiFilter, pqiSelectedDefsIds]) => {
                    if (activeView === tabOptions.Table) {
                        this.dataSource.data = EventsFilters;
                        this.preSelectedNodes(eventselectedDefsIds);
                        this.tab = tabOptions.Events;
                    }
                    if (activeView === tabOptions.PowerQuality) {
                        this.dataSource.data = pqiFilter;
                        this.preSelectedNodes(pqiSelectedDefsIds);
                        this.tab = tabOptions.PowerQuality;
                    }
                }),
                takeUntil(this.checklistSelection.changed)
            )
            .subscribe();

        this.filterFormSub = this.store
            .select(EventDefinitionsSelectors.getSearchTermForFilter)
            .pipe(
                tap((term) => {
                    this.searchTerm = term;
                    this.filterByName(term);
                })
            )
            .subscribe();
    }
    ngOnInit(): void {
        this.filterChangeSub = this.checklistSelection.changed.subscribe((changedVal: SelectionChange<TodoItemFlatNode>) => {
            this.valueChanged(changedVal.added, changedVal.removed);
        });
        this.treeControl.expand(this.parentNode);
    }
    valueChanged(added: TodoItemFlatNode[], removed: TodoItemFlatNode[]) {
        if (this.addToUndo) {
            if (this.tab === tabOptions.Events) {
                this.store.dispatch(EventsActions.AddToUndoEvent());
                this.addToUndo = false;
            } else if (this.tab === tabOptions.PowerQuality) {
                this.store.dispatch(PqiDataActions.AddToUndoPQI());
                this.addToUndo = false;
            }
        }

        if (added.length || removed.length) {
            if (this.tab === tabOptions.Events) {
                this.store.dispatch(
                    EventsActions.SelectMeteringPointEventDefinitions({
                        added: added.filter((node) => node.hasOwnProperty("id")).map((d) => d.id),
                        removed: removed.filter((node) => node.hasOwnProperty("id")).map((d) => d.id)
                    })
                );
            } else if (this.tab === tabOptions.PowerQuality) {
                this.store.dispatch(
                    PqiDataActions.SelectMeteringPointPqiDefinitions({
                        added: added.filter((node) => node.hasOwnProperty("id")).map((d) => d.id),
                        removed: removed.filter((node) => node.hasOwnProperty("id")).map((d) => d.id)
                    })
                );
            }
        }
    }
    private filterByName(term: string): void {
        const termLower = term.toLowerCase();
        if (term.length > 0) {
            this.treeControl.dataNodes.forEach((typeNode) => {
                if (typeNode.item.toLowerCase().indexOf(termLower) > -1) {
                    typeNode.visible = true;
                    let node: TodoItemFlatNode | null = typeNode;
                    while (true) {
                        try {
                            node = this.getParentNode(node);
                            if (node === null) {
                                break;
                            } else {
                                node.visible = true;
                                this.treeControl.expand(node);
                            }
                        } catch (ex) {
                            console.log(ex);
                            break;
                        }
                    }
                } else {
                    typeNode.visible = false;
                }
            });
        } else {
            this.treeControl.collapseAll();
            this.treeControl.expand(this.parentNode);
            this.clearFilter();
        }
    }

    private clearFilter(): void {
        this.treeControl.dataNodes.forEach((x) => (x.visible = true));
    }
    ngOnDestroy(): void {
        this.combineSub.unsubscribe();
        this.filterChangeSub.unsubscribe();
        this.filterFormSub.unsubscribe();
    }

    preSelectedNodes(ids: number[]): void {
        if (this.treeControl.dataNodes) {
            this.treeControl.dataNodes.forEach((node) => {
                if (node.hasOwnProperty("id")) {
                    if (ids.includes(node.id)) {
                        this.todoItemSelectionToggle(node);
                    }
                }
            });
        }
    }

    getLevel = (node: TodoItemFlatNode) => node.level;

    isExpandable = (node: TodoItemFlatNode) => node.expandable;

    getChildren = (node: TodoItemNode): TodoItemNode[] => node.children;

    hasChild = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.expandable;

    hasNoContent = (_: number, _nodeData: TodoItemFlatNode) => _nodeData.item === "";

    /**
     * Transformer to convert nested node to flat node. Record the nodes in maps for later use.
     */
    transformer = (node: TodoItemNode, level: number) => {
        const existingNode = this.nestedNodeMap.get(node);
        const flatNode = existingNode && existingNode.item === node.item ? existingNode : new TodoItemFlatNode();
        flatNode.item = node.item;
        flatNode.visible = true;
        if (node.hasOwnProperty("id")) {
            flatNode.id = node.id;
        }
        flatNode.level = level;
        if (flatNode.level === 0) {
            this.parentNode = flatNode;
        }
        flatNode.expandable = !!node.children;
        this.flatNodeMap.set(flatNode, node);
        this.nestedNodeMap.set(node, flatNode);
        return flatNode;
    };

    /** Whether all the descendants of the node are selected. */
    descendantsAllSelected(node: TodoItemFlatNode): boolean {
        const descendants = this.treeControl.getDescendants(node);
        const descAllSelected = descendants.every((child) => this.checklistSelection.isSelected(child));
        return descAllSelected;
    }
    /** Whether part of the descendants are selected */
    descendantsPartiallySelected(node: TodoItemFlatNode): boolean {
        const descendants = this.treeControl.getDescendants(node);
        const result = descendants.some((child) => this.checklistSelection.isSelected(child));
        return result && !this.descendantsAllSelected(node);
    }

    /** Toggle the to-do item selection. Select/deselect all the descendants node */
    todoItemSelectionToggle(node: TodoItemFlatNode): void {
        this.addToUndo = true; // this is just to add the old definition to undo array only once per item select
        this.checklistSelection.toggle(node);
        const descendants = this.treeControl.getDescendants(node);
        this.checklistSelection.isSelected(node)
            ? this.checklistSelection.select(...descendants)
            : this.checklistSelection.deselect(...descendants);
        // Force update for the parent
        descendants.forEach((child) => this.checklistSelection.isSelected(child));
        this.checkAllParentsSelection(node);
    }
    /** Toggle a leaf to-do item selection. Check all the parents to see if they changed */
    todoLeafItemSelectionToggle(node: TodoItemFlatNode): void {
        this.checklistSelection.toggle(node);
        this.checkAllParentsSelection(node);
    }

    /* Checks all the parents when a leaf node is selected/unselected */
    checkAllParentsSelection(node: TodoItemFlatNode): void {
        let parent: TodoItemFlatNode | null = this.getParentNode(node);
        while (parent) {
            this.checkRootNodeSelection(parent);
            parent = this.getParentNode(parent);
        }
    }
    /** Check root node checked state and change it accordingly */
    checkRootNodeSelection(node: TodoItemFlatNode): void {
        const nodeSelected = this.checklistSelection.isSelected(node);
        const descendants = this.treeControl.getDescendants(node);
        const descAllSelected = descendants.every((child) => this.checklistSelection.isSelected(child));
        if (nodeSelected && !descAllSelected) {
            this.checklistSelection.deselect(node);
        } else if (!nodeSelected && descAllSelected) {
            this.checklistSelection.select(node);
        }
    }

    /* Get the parent node of a node */
    getParentNode(node: TodoItemFlatNode): TodoItemFlatNode | null {
        const currentLevel = this.getLevel(node);
        if (currentLevel < 1) {
            return null;
        }
        const startIndex = this.treeControl.dataNodes.indexOf(node) - 1;
        for (let i = startIndex; i >= 0; i--) {
            const currentNode = this.treeControl.dataNodes[i];

            if (this.getLevel(currentNode) < currentLevel) {
                return currentNode;
            }
        }
        return null;
    }
}
