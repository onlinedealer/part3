import { Component, Input } from '@angular/core';

@Component({
  selector: 'discovery-pie-chart',
  templateUrl: './pie-chart.component.html',
  styleUrls: ['./pie-chart.component.css']
})
export class PieChartComponent {
  @Input() pieData: number[];
  basicOptions: Record<string, Record<string, boolean>>;
  data: {
    datasets: {
      backgroundColor: string[];
      data: any[];
      hoverBackgroundColor: string[];
    }[];
  };

  constructor() {
    this.basicOptions = {
      legend: {
        display: false
      }
    };

    this.data = {
      datasets: [
        {
          data: [],
          backgroundColor: [
            '#39006B',
            '#8017E1',
            '#E5007E',
            '#FAB512',
            '#FD7E08',
            '#C8CCEE',
            '#D058D0',
            '#565358',
            '#CCA2F3',
            '#FECB9C',
            '#3C85FF',
            '#4BB269'
          ],
          hoverBackgroundColor: [
            '#39006Bcc',
            '#8017E1cc',
            '#E5007Ecc',
            '#FAB512cc',
            '#FD7E08cc',
            '#C8CCEEcc',
            '#D058D0cc',
            '#565358cc',
            '#CCA2F3cc',
            '#FECB9Ccc',
            '#3C85FFcc',
            '#4BB269cc'
          ]
        }
      ]
    };
  }
}
