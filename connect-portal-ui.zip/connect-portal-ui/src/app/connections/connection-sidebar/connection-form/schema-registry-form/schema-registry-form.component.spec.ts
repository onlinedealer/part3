import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { ServiceInjector } from '@shared/services/service.injector';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { Server } from 'src/app/servers/shared/server';
import { ServersApiService } from 'src/app/servers/shared/servers-api.service';
import { OrderbyascPipe } from 'src/app/shared/pipes/dynamic-dropdown-sort.pipe';
import { Connection } from '../../../shared/connection';
import { SchemaRegistryFormComponent, SCHEMA_CONNECTION_PARAMETERS } from './schema-registry-form.component';

describe('SchemaRegistryFormComponent', () => {
  let component: SchemaRegistryFormComponent;
  let fixture: ComponentFixture<SchemaRegistryFormComponent>;
  let serversService: ServersApiService;

  const runtimeServer = {
    id: '1',
    hostname: 'test'
  } as Server;
  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  const mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

  class mockInjector {
    get() {
      return mockFeatureFlagService;
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule, DropdownModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ],
      declarations: [SchemaRegistryFormComponent, OrderbyascPipe]
    }).compileComponents();
  });

  beforeEach(() => {
    ServiceInjector.injector = new mockInjector();
    fixture = TestBed.createComponent(SchemaRegistryFormComponent);
    component = fixture.componentInstance;
    serversService = TestBed.inject(ServersApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should return connection', () => {
    component.schemaRegistryFormGroup.patchValue({
      database: 'test',
      schemaRegistryVendor: 'Confluence',
      schemaRegistryConfig: '1',
      schemaRegistryUrl: 'url'
    });
    const connection: Connection = component.getConnection(true);
    expect(connection.database).toBe('url');
    expect(connection.parameters.find((parameter) => parameter.key === 'SCHEMA_REGISTRY_TYPE').value).toBe('Confluence');
    expect(connection.parameters.find((parameter) => parameter.key === 'SCHEMA_REGISTRY_CONFIG_FILE_PATH').value).toBe('1');
  });

  it('should set connection form for Confluent', () => {
    const dataConnection = {
      accessFromServer: { id: '1' },
      database: 'test',
      parameters: [
        { key: SCHEMA_CONNECTION_PARAMETERS.SCHEMA_REGISTRY_TYPE, value: 'CONFLUENT' },
        { key: SCHEMA_CONNECTION_PARAMETERS.SCHEMA_REGISTRY_CONFIG_FILE_PATH, value: 'test' }
      ]
    } as Connection;
    component.selectedRuntimeServer = runtimeServer;
    component.connection = dataConnection;
    expect(component.schemaRegistryFormGroup.get('database').value).toBe('test');
    expect(component.schemaRegistryFormGroup.get('database').value).toBe('test');
  });
});
