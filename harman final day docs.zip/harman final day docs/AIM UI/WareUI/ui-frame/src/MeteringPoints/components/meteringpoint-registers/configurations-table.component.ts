import { Component, Input, ChangeDetectionStrategy, OnChanges, SimpleChanges } from "@angular/core";
import { ConfigurationVO } from "../../models/view-objects/configuration-vo.model";
import { slideCloseOpenAnimation } from "../../../Shared/Animations/slide-close-open.animation";
import { TranslationsService } from "../../../app/services/translations-service";
import { ConfigurationsSorter } from "./configurations-sorter";

@Component({
    selector: "landisgyr-configurations-table",
    templateUrl: "./configurations-table.component.html",
    styleUrls: ["./configurations-table.component.scss"],
    animations: slideCloseOpenAnimation(),
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ConfigurationsTableComponent implements OnChanges {
    @Input()
    configurations!: ConfigurationVO[];
    @Input() loading!: boolean;
    @Input() tableDataLoading!: boolean;
    @Input() refreshDataLoading!: boolean;

    contentOpen = "open";

    configurationsSorter = new ConfigurationsSorter();
    sortedConfigurations$ = this.configurationsSorter.getSortedConfigurations();

    infoMessage = $localize`:|@@ssRegisters.noConfigurationsMessage:No configurations`;

    ngOnChanges(changes: SimpleChanges) {
        this.configurationsSorter.setConfigurations(this.configurations);
    }

    toggleContent() {
        this.contentOpen = this.contentOpen === "open" ? "closed" : "open";
    }

    isCollapsed() {
        return this.contentOpen === "closed";
    }

    constructor(public translations: TranslationsService) {}
}
