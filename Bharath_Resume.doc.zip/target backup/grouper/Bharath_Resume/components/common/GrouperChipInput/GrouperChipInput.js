import React from 'react'
import ChipInput from 'material-ui-chip-input'
import Chip from '@material-ui/core/Chip'
import { withStyles } from '@material-ui/core/styles'
import * as Constants from '../../common/Utils/Constants'

const styles = theme => ({
  error: {
    background: '#EF9A9A',
    float: 'left',
    margin: '0 8px 8px 0',
  },
  errorText: {
    color: '#f44336',
    fontSize: '0.75rem',
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
  },
  regText: {
    fontSize: '0.75rem',
    fontFamily: '"Roboto", "Helvetica", "Arial", sans-serif',
    color: '#0000008a',
  },
  chipBlock: {
    width: '100%',
  },
})
class GrouperChipInput extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      chips: [],
      errorMsg: '',
      dispMsg: '',
      msgStyle: 'regText',
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.value.length === 0) {
      this.setState({errorMsg: ''})
    } else if (nextProps.errors.length > 0) {
      const errorMsg = nextProps.tcinExistsStatus ? Constants.TCIN_EXISTS : Constants.INVALID_TCIN_TEXT
      this.setState({ errorMsg })
    }
    if (nextProps.mode === 'WhileCreate' && nextProps.errors.length <= 0) {
      const dispMsg = Constants.ERROR_TCIN_REQ
      this.setState({ dispMsg, errorMsg: '' })
    }
    /* if (nextProps.mode === 'WhileCreate' && nextProps.value.length === 1) {
      this.setState({msgStyle: 'errorText'})
    } else {
      this.setState({msgStyle: 'regText'})
    } */
  }

  chipRenderer= (x, y) => {
    const cls = (this.props.errors.indexOf(parseInt(x.value)) !== -1) ? this.props.classes.error : x.className
    return (<Chip
      key={x.value}
      label={x.value}
      className={cls}
      onDelete={x.handleDelete}
      onClick={x.handleClick}
      disabled={x.isDisbaled}
      focused={x.isFocused}
    />)
  }

  onUpdateInput = (evt) => {
    const listValue = evt.currentTarget.value.split(' ')
    if (listValue.length >= 2) {
      listValue.map((opt) => {
        this.props.handleAddTcin(opt)
      })
      this.nameInput.blur()
      this.nameInput.focus()
    }
  }

  onCopyPaste = (evt) => {
    if (evt.keyCode === 86) {
      const listValue = evt.currentTarget.value.split(' ')
      if (listValue.length >= 1) {
        listValue.map((opt) => {
          this.props.handleAddTcin(opt)
        })
        this.nameInput.blur()
        this.nameInput.focus()
      }
    }
  }

  onBlurChipInput = (event) => {
    if (this.props.mode === 'WhileCreate' && this.props.value.length < 2) {
      this.setState({msgStyle: 'errorText'})
    } else {
      this.setState({msgStyle: 'regText'})
    }
  }

  render () {
    const { classes, value, handleAddTcin, handleDeleteTcin, placeholder, chipContainerCls } = this.props
    const { errorMsg, dispMsg, msgStyle } = this.state
    const keyCodes = [188, 32, 13]
    return (
      <div className={classes.chipBlock}>
        <ChipInput
          inputRef={(input) => { this.nameInput = input }}
          classes={{ chipContainer: chipContainerCls }}
          value={value}
          onAdd={handleAddTcin}
          onDelete={handleDeleteTcin}
          fullWidth
          placeholder={placeholder}
          chipRenderer={this.chipRenderer}
          newChipKeyCodes={keyCodes}
          // onUpdateInput={this.onUpdateInput}
          InputProps={{ onKeyUp: this.onCopyPaste }}
          onBlur={this.onBlurChipInput}
        />
        {(errorMsg !== '') && <span className={classes.errorText}>{errorMsg}</span> }
        {(dispMsg !== '') && <span className={classes[msgStyle]}>{Constants.ERROR_TCIN_REQ}</span> }
      </div>
    )
  }
}

export default (withStyles(styles)(GrouperChipInput))
