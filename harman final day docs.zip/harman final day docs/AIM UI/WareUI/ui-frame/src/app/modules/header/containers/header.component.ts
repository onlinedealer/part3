import { Component, Output, EventEmitter, Input, ChangeDetectionStrategy } from "@angular/core";
import { Observable } from "rxjs";
import { MatDialog } from "@angular/material/dialog";
import { HeaderDataProvider, HeaderData } from "../common/header-data-provider";
import {
    UserMenuTimeZoneInformation,
    UserMenuComponentChangeUiConfigurationSettingsPayload
} from "../components/user-menu/user-menu.component";

@Component({
    selector: "landisgyr-header",
    templateUrl: "./header.component.html",
    styleUrls: ["./header.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class HeaderComponent {
    @Input()
    environmentText!: string;

    @Input()
    environmentTextColor!: string;

    @Input()
    environmentIndicatorBackgroundColor!: string;

    @Input()
    userMenuOpen!: boolean;
    @Input()
    network!: string;
    @Output()
    logout = new EventEmitter();

    @Output()
    userMenuVisibilityChanged = new EventEmitter();
    @Output()
    settingsChange = new EventEmitter<UserMenuComponentChangeUiConfigurationSettingsPayload>();
    _headerData$: Observable<HeaderData>;
    _availableLanguages$: Observable<Array<{ code: string; name: string }>>;
    _timeZoneInformation$: Observable<UserMenuTimeZoneInformation>;
    constructor(public dialog: MatDialog, private headerDataProvider: HeaderDataProvider) {
        this._headerData$ = this.headerDataProvider.getHeaderData();
        this._availableLanguages$ = this.headerDataProvider.getAvailableUILanguages();
        this._timeZoneInformation$ = this.headerDataProvider.getUITimeZoneInformation();
    }

    onLogout() {
        this.logout.emit();
    }

    applySettingChanges(data: UserMenuComponentChangeUiConfigurationSettingsPayload) {
        this.dialog.closeAll();
        this.settingsChange.emit(data);
    }

    handleUserMenuOpenValue() {
        this.userMenuVisibilityChanged.emit();
    }
}
