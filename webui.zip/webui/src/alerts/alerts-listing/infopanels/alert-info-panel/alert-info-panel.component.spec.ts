import { DatePipe } from '@angular/common';
import { TestBed } from '@angular/core/testing';
import { IConfigureMetric } from 'alerts/alert-dialog.type';
import { AlertMetricModel } from 'alerts/alert-metric.model';
import { AlertModel } from 'alerts/alert.model';
import { Spies } from 'discovery-test';
import { DialogService as PrimeNgDialogService } from 'primeng/dynamicdialog';
import { of } from 'rxjs';
import { AlertInfoPanelComponent } from './alert-info-panel.component';

describe('AlertInfoPanelComponent', () => {
  let component: AlertInfoPanelComponent;
  let mockProfileService: any;
  let mockAlert: AlertModel;
  let dialogService: PrimeNgDialogService;
  let datePipe: DatePipe;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AlertInfoPanelComponent],
      providers: [PrimeNgDialogService, DatePipe]
    }).compileComponents();
  });

  beforeEach(() => {
    mockAlert = {
      id: '1',
      alertType: 'VOLUME',
      alertLevel: 'WARNING',
      summary: 'summary',
      assetName: 1,
      assetNameClipped: 'ABC',
      assetType: 'TABLE',
      assetParentName: 'parent',
      assetParentType: 'table',
      raisedAt: new Date('2022-06-01T00:00:00Z'),
      confidence: 43.7767,
      assetUid: '12938102qsjkldhal',
      tableName: 'customers',
      schema: 'customers',
      source: 'snowflake',
      sourceType: 'database',
      observer: 'obsv32',
      alertConfiguration: 'Confidence-based alerts',
      profileStartTime: new Date('2022-06-01T00:00:00Z'),
      thresholdAlertMetrics: [
        {
          metricType: 'VALUE_MIN',
          metricName: 'Minimum Value',
          metricDetails: [
            {
              currentMetric: '130',
              comparisonMetric: '10',
              alertLevel: 'CRITICAL',
              percentageChange: 99.0,
              alertAgainst: 'MOVING_AVERAGE'
            }
          ]
        }
      ],
      confidenceAlertMetrics: [
        {
          metricType: 'VALUE_MIN',
          metricName: 'Minimum Value',
          metricDetails: [
            {
              currentMetric: '130',
              comparisonMetric: '10',
              alertLevel: 'CRITICAL',
              probability: 99.0,
              sampleKey: 'JPY'
            }
          ]
        },
        {
          metricType: 'CARDINALITY_DETAIL',
          metricName: 'Distribution of value count',
          metricDetails: [
            {
              currentMetric: '1',
              comparisonMetric: '0',
              alertLevel: 'CRITICAL',
              probability: 100.0,
              sampleKey: '999999911',
              isNew: true
            }
          ]
        }
      ]
    };

    mockProfileService = jasmine.createSpyObj('AlertProfileMetricsService', ['getTrendsHistory']);
    mockProfileService.getTrendsHistory.and.returnValue(
      of([
        {
          startTime: '2022-05-02T00:00:00Z',
          value: '2010'
        },
        {
          startTime: '2022-05-03T00:00:00Z',
          value: '3060'
        },
        {
          startTime: '2022-05-04T00:00:00Z',
          value: '4079'
        },
        {
          startTime: '2022-05-05T00:00:00Z',
          value: '5108'
        }
      ])
    );

    dialogService = jasmine.createSpyObj('PrimeNgDialogService', ['open']);
    datePipe = jasmine.createSpyObj('DatePipe', ['transform']);
    component = new AlertInfoPanelComponent(
      mockProfileService,
      Spies.TranslateService,
      dialogService,
      Spies.launchDarklyService,
      datePipe
    );
    component.alert = mockAlert;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Load Chart Options', () => {
    component.loadChartOptions('ROW COUNT', 'ROW_COUNT', false);
  });

  it('Test LoadDetailPanel', () => {
    component.loadDetailPanel();
  });

  it('Load Chart Options', () => {
    component.loadChartOptions('Volume', 'ROW_COUNT', true);
  });

  it('Get Threshold metrics', () => {
    component.alert.alertConfiguration = component.THRESHOLD_BASED;
    let metrics = component.getAlertMetrics();
    expect(metrics.length).toBeGreaterThan(0);
  });

  it('Get Confidence metrics', () => {
    component.alert.alertConfiguration = component.CONFIDENCE_BASED;
    let metrics = component.getAlertMetrics();
    expect(metrics.length).toBeGreaterThan(0);
  });

  it('Show Impacted Metrics Links', () => {
    let value = component.showImpactedStatsLinks();

    expect(value).toBeTrue();
  });

  it('Should convert label and tooltip for date', () => {
    component.alert = { ...component.alert, columnType: 'DATE' };
    let tooltipItems = [
      { label: 'Sat Aug 06 2022 21:10:54 GMT+0530 (India Standard Time)', parsed: { x: 3, y: 1535797800000 } }
    ];
    component.dateFormate(tooltipItems);
    component.label();
    component.tooltipText(tooltipItems, 'Minimum Value', 'CARDINALITY_DETAIL', false);
  });

  it('should convert label and tooltip for dateTime', () => {
    component.alert = { ...component.alert, columnType: 'DATETIME' };
    let tooltipItems = [
      {
        label: 'Sat Aug 02 2022 21:10:54 GMT+0530 (India Standard Time)',
        parsed: { x: 3, y: 1535797800000 },
        dataset: { label: 'test label' }
      }
    ];
    component.loadChartOptions('Minimum Value', 'ROW_COUNT', false);
    component.dateFormate(tooltipItems);
    component.label();
    component.tooltipText(tooltipItems, 'ROW COUNT', 'CARDINALITY_DETAIL', true);
  });

  it('should convert label and tooltip for Time stamp', () => {
    component.alert = { ...component.alert, columnType: 'TIMESTAMP' };
    let tooltipItems = [
      { label: 'Sat Aug 06 2022 21:10:54 GMT+0530 (India Standard Time)', parsed: { x: 3, y: 1535797800000 } }
    ];
    let element = {
      startTime: '2022-08-14T06:16:50.871Z',
      value: 2010
    };
    component.getTrendsValue(element, 'VALUE_MIN');
    component.loadChartOptions('Minimum Value', 'VALUE_MIN', true);
    component.dateFormate(tooltipItems);
    component.label();
    component.tooltipText(tooltipItems, 'Minimum Value', 'VALUE_MIN', false);
  });

  it('should show tooltip for other datatype', () => {
    let tooltipItems = [
      { label: 'Sat Aug 06 2022 21:10:54 GMT+0530 (India Standard Time)', parsed: { x: 3, y: 1535797800000 } }
    ];
    component.tooltipText(tooltipItems, 'ROW COUNT', 'ROW_COUNT', false);
  });

  it('Test getMetricsHistoryDataSet', () => {
    component.getMetricsHistoryDataSet(mockAlert.assetUid, mockAlert.confidenceAlertMetrics[0], 'all');
  });

  it('Test getTrendsValue', () => {
    let element = {
      startTime: '2022-08-14T06:16:50.871Z',
      details: [
        {
          key: 'Benny',
          value: '10'
        },
        {
          key: 'DBrandie',
          value: '20'
        },
        { key: 'Dalia', value: '1' }
      ]
    };
    let sampleKeyArray = ['Benny', 'DBrandie', 'Dalia'];
    let finalValues = new Map();
    sampleKeyArray.forEach((item) => {
      finalValues.set(item, []);
    });
    let metricType = 'CARDINALITY_DETAIL';
    component.getTrendsValue(element, metricType, sampleKeyArray, finalValues);
    expect(finalValues.size).toBeGreaterThan(1);
  });

  it('Test showLegend', () => {
    const item = { text: 'sample legend' };
    component.showLegend(item);
  });

  it('Test yAxisLabel', () => {
    component.alert.alertType = 'Volume';
    component.yAxisLabel(1, 'VALUE_MAX', false);
    component.yAxisLabel('2022-08-14T06:16:50.871Z', 'VALUE_MAX', true);
  });

  it('Test Highlighted line segment', () => {
    let context = {
      p0DataIndex: 0,
      p1DataIndex: 1
    };

    let alertDate = new Date('2022-09-25T09:39:11.053Z');
    let dateData = [alertDate];
    let result = component.highlightLineSegment(context, dateData, alertDate, 'TEST', false);
    expect(result).toBe(undefined);
  });

  it('Test Highlighted line segment for critical', () => {
    let context = {
      p1DataIndex: 0
    };
    let alertDate = new Date('2022-09-25T09:39:11.053Z');
    let dateData = [alertDate];
    component.CRITICAL = 'CRITICAL';
    let result = component.highlightLineSegment(context, dateData, alertDate, '#cb0350', false);
    expect(result).toBe('#cb0350');
  });

  it('Test Highlighted line segment for warning', () => {
    let context = {
      p1DataIndex: 0
    };
    let alertDate = new Date('2022-09-25T09:39:11.053Z');
    let dateData = [alertDate];
    let result = component.highlightLineSegment(context, dateData, alertDate, '#eac010', false);
    expect(result).toBe('#eac010');
  });

  it('Test highlightPointStyling for success', () => {
    let context = {
      dataIndex: 0
    };
    let alertDate = new Date('2022-09-25T09:39:11.053Z');
    let dateData = [alertDate];
    let result = component.highlightPointStyling(context, dateData, alertDate, 'success', 'failure');
    expect(result).toBe('success');
  });

  it('Test highlightPointStyling for failure', () => {
    let context = {
      dataIndex: 1
    };
    let alertDate = new Date('2022-09-25T09:39:11.053Z');
    let dateData = [alertDate];
    let result = component.highlightPointStyling(context, dateData, alertDate, 'success', 'failure');
    expect(result).toBe('failure');
  });

  it('should have unique key string separator', () => {
    const expectedSeparator = '___';
    expect(component.uuidSeparator).toBe(expectedSeparator);
  });

  it('should save updated value', () => {
    const alertassetId = 'test_id';
    const expectedSeparator = '___';
    const metricToSave: IConfigureMetric = {
      metric: {
        metricType: 'CARDINALITY_DETAIL',
        metricName: 'Minimum Value'
      } as AlertMetricModel,
      selectedSample: 'a,b,c,d',
      timeframe: 'year',
      alertId: 'test_id'
    } as IConfigureMetric;
    component.updateStateForSavedMetrics(alertassetId, metricToSave);
    const shouldHaveId = alertassetId + expectedSeparator + metricToSave.metric.metricName;
    const savedMetric = component.persistConfiguredMetrics.get(shouldHaveId);
    expect(savedMetric).not.toBeUndefined();
    expect(JSON.stringify(savedMetric)).toBe(JSON.stringify(metricToSave));
  });

  it('should update existing value if already available', () => {
    const alertassetId = 'test_id';
    const expectedSeparator = '___';
    const metricToSave: IConfigureMetric = {
      metric: {
        metricType: 'CARDINALITY_DETAIL',
        metricName: 'Minimum Value',
        metricDetails: [
          {
            currentMetric: '1',
            comparisonMetric: '0',
            alertLevel: 'CRITICAL',
            probability: 100.0,
            sampleKey: '999999911',
            isNew: true
          }
        ]
      } as AlertMetricModel,
      selectedSample: 'a,b,c,d',
      timeframe: 'year',
      alertId: 'test_id'
    } as IConfigureMetric;
    component.updateStateForSavedMetrics(alertassetId, metricToSave);
    const shouldHaveId = alertassetId + expectedSeparator + metricToSave.metric.metricName;
    const savedMetric = component.persistConfiguredMetrics.get(shouldHaveId);
    expect(JSON.stringify(savedMetric)).toBe(JSON.stringify(metricToSave));
    let updatedMetricToSave = {
      ...metricToSave,
      selectedSample: 'x,y,z',
      timeframe: 'week'
    };
    component.updateStateForSavedMetrics(alertassetId, updatedMetricToSave);
    const updatedMetric = component.persistConfiguredMetrics.get(shouldHaveId);
    expect(JSON.stringify(updatedMetric)).toBe(JSON.stringify(updatedMetricToSave));
  });

  it('should have updated timeframe value for selected metric', () => {
    const alertassetId = 'test_id';
    const metricToSave: IConfigureMetric = {
      metric: {
        metricType: 'CARDINALITY_DETAIL',
        metricName: 'Minimum Value',
        metricDetails: [
          {
            currentMetric: '1',
            comparisonMetric: '0',
            alertLevel: 'CRITICAL',
            probability: 100.0,
            sampleKey: '999999911',
            isNew: true
          }
        ]
      } as AlertMetricModel,
      selectedSample: 'a,b,c,d',
      timeframe: 'year',
      alertId: 'test_id'
    } as IConfigureMetric;
    component.updateStateForSavedMetrics(alertassetId, metricToSave);
    const updatedValue = component.graphTimeframes['Minimum Value'];
    expect(updatedValue).toBe('year');
  });

  // checkPersistedState

  it('should return persisted state for sample keys and timeframe if available', () => {
    const assetUid = 'test_id';
    const expectedSeparator = '___';
    const metricToSave: IConfigureMetric = {
      metric: {
        metricType: 'CARDINALITY_DETAIL',
        metricName: 'Minimum Value',
        metricDetails: [
          {
            currentMetric: '1',
            comparisonMetric: '0',
            alertLevel: 'CRITICAL',
            probability: 100.0,
            sampleKey: '999999911',
            isNew: true
          }
        ]
      } as AlertMetricModel,
      selectedSample: 'a,b,c,d',
      timeframe: 'year',
      alertId: 'test_id'
    } as IConfigureMetric;
    const samplekey = 'a,b,c,d';
    const timeframe = 'year';
    const shouldHaveId = assetUid + expectedSeparator + metricToSave.metric.metricName;
    component.persistConfiguredMetrics.set(shouldHaveId, metricToSave);

    const output = component.checkPersistedState(assetUid, metricToSave.metric, samplekey, timeframe);
    expect(output.timeframe).toBe('year');
    expect(output.selectedSample).toBe(samplekey);
  });

  it('should return passed state for sample keys and timeframe if no persisted value metric found ', () => {
    const assetUid = 'test_id';
    const expectedSeparator = '___';
    const metricToSave: IConfigureMetric = {
      metric: {
        metricType: 'CARDINALITY_DETAIL',
        metricName: 'Minimum Value',
        metricDetails: [
          {
            currentMetric: '1',
            comparisonMetric: '0',
            alertLevel: 'CRITICAL',
            probability: 100.0,
            sampleKey: '999999911',
            isNew: true
          }
        ]
      } as AlertMetricModel,
      selectedSample: 'a,b,c,d',
      timeframe: 'year',
      alertId: 'test_id'
    } as IConfigureMetric;
    const expectedSamplekey = '1,2,3,4';
    const expectedTimeframe = 'week';
    const shouldHaveId = assetUid + expectedSeparator + metricToSave.metric.metricName;
    component.persistConfiguredMetrics.set(shouldHaveId, metricToSave);

    const output = component.checkPersistedState(
      'another_asset_id',
      metricToSave.metric,
      expectedSamplekey,
      expectedTimeframe
    );
    expect(output.timeframe).toBe(expectedTimeframe);
    expect(output.selectedSample).toBe(expectedSamplekey);
  });

  it('should open export report dialog', () => {
    component.showExportDialog();
  });

  it('should show values as per percentage', () => {
    let metric = {
      metricName: 'Distribution of value count',
      metricType: 'CARDINALITY_DETAIL',
      metricDetails: [
        {
          currentMetric: '2',
          comparisonMetric: '1',
          alertLevel: 'CRITICAL',
          alertReason: 'ALERT_RULE_CONSTANT_HISTORY_TO_NEW_VALUE',
          probability: 100,
          sampleKey: '101,100',
          isSampled: false,
          isNew: false
        }
      ]
    };
    component.showByPercentageData = {
      labels: [
        '2022-12-16T07:32:46.549Z',
        '2022-12-17T07:32:46.519Z',
        '2022-12-18T07:32:52.852Z',
        '2022-12-19T07:32:58.331Z',
        '2022-12-21T07:32:54.476Z',
        '2022-12-22T07:32:58.599Z',
        '2022-12-23T07:32:54.435Z'
      ],
      values: [
        {
          label: '101',
          value: ['1', '1', '1', '1', '1', '1', '2']
        },
        {
          label: '100',
          value: ['1', '1', '1', '1', '1', '1', '1']
        }
      ],
      alertDate: '2022-12-23T07:33:00.000Z',
      isNew: false,
      trendTotalCountArray: [2, 2, 2, 2, 2, 2, 3]
    };
    component.isShowPercentage = true;
    component.populateChartValueByPercentage(metric);
  });
});
