import { Component, ChangeDetectorRef, EventEmitter, Input, Output } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';
import { first } from 'rxjs/operators';
import { BundlesApiService } from '../shared/bundles-api.service';
import { Bundle } from '../shared/bundles';

@Component({
  selector: 'p-connect-stop-bundle-dialog',
  templateUrl: './stop-bundle-dialog.component.html'
})
export class StopBundleDialogComponent {
  /**
   * Visibility flag
   */
  @Input() isVisible: boolean;

  /**
   * Event that is fired when visibility changes
   */
  @Output() isVisibleChanged = new EventEmitter<boolean>();

  /**
   * Event that is fired when bundling has been stopped
   */
  @Output() bundleStoppedEvent = new EventEmitter<{ id: number }>();

  /**
   * The number of bundles selected
   */
  bundlesCount = 0;

  /**
   * List of bundles that can be stopped
   */
  stoppableBundles: Bundle[] = [];

  isStoppingBundle: boolean;

  constructor(private readonly bundlesApiService: BundlesApiService, private readonly changeDetectorRef: ChangeDetectorRef) {}

  /**
   * Open the dialog
   */
  open(stoppableBundles: Bundle[], bundlesCount): void {
    this.stoppableBundles = stoppableBundles;
    this.bundlesCount = bundlesCount;
    this.isStoppingBundle = false;
  }

  /**
   * Click event for the stop button
   */
  stopButtonClicked(): void {
    this.isStoppingBundle = true;
    const ids = this.stoppableBundles.map((bundle) => bundle.id);
    this.bundlesApiService
      .stopBundle(ids, new HttpHeaders().set(InterceptorSkipHeader, ''))
      .pipe(first())
      .subscribe({
        next: (response: any) => {
          this.bundleStoppedEvent.emit(response);
        }
      })
      .add(() => {
        this.isStoppingBundle = false;
        this.changeDetectorRef.markForCheck();
        this.cancelButtonClicked();
      });
  }

  /**
   * Click event for the cancel button
   */
  cancelButtonClicked(): void {
    this.isVisible = false;
    this.isVisibleChanged.emit(false);
  }
}
