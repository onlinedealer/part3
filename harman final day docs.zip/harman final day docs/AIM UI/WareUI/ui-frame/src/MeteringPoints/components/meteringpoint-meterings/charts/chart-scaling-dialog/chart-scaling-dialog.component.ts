import { Component, OnInit } from "@angular/core";
import { FormControl, FormGroup, FormArray } from "@angular/forms";

import { MeteringDataChartActions } from "../../../../store/actions";
import { MeteringDataChartSelectors } from "../../../../store/selectors";
import { MeteringPointsFeatureState } from "../../../../store/reducers";
import { Store } from "@ngrx/store";
import { Subscription } from "rxjs";
import { TranslationsService } from "../../../../../app/services/translations-service";
import { MatDialogRef } from "@angular/material/dialog";

@Component({
    selector: "landisgyr-chart-scaling-dialog",
    templateUrl: "./chart-scaling-dialog.component.html",
    styleUrls: ["./chart-scaling-dialog.component.scss"]
})
export class ChartScalingDialogComponent implements OnInit {
    chartScalesSub!: Subscription;
    axises: any;

    ScaleVisibleVisible = true;
    axisForm = new FormGroup({
        units: new FormArray([])
    });

    get units() {
        return this.axisForm.get("units") as FormArray;
    }

    scalingAutomated(scalingAutomated: boolean) {
        if (scalingAutomated) {
            return true;
        } else {
            return false;
        }
    }
    ngOnInit(): void {
        this.chartScalesSub = this.store.select(MeteringDataChartSelectors.getChartScales).subscribe((scales) => {
            this.axises = scales;
            scales.forEach((unitObject) => {
                this.units.push(
                    new FormGroup({
                        inUse: new FormControl(unitObject.inUse),
                        scalingAutomated: new FormControl({ value: unitObject.scalingAutomated, disabled: false }),
                        min: new FormControl({ value: unitObject.min, disabled: this.scalingAutomated(unitObject.scalingAutomated) }),
                        max: new FormControl({ value: unitObject.max, disabled: this.scalingAutomated(unitObject.scalingAutomated) })
                    })
                );
            });
        });
        this.chartScalesSub.unsubscribe();
    }

    constructor(
        public dialogRef: MatDialogRef<ChartScalingDialogComponent>,
        private store: Store<MeteringPointsFeatureState>,
        public translations: TranslationsService
    ) {}

    disableEnableInUse(index: number, checkBoxValue: any) {
        if (checkBoxValue) {
            const group = this.units.controls as FormGroup[];
            let indexCounter = 0;
            group.forEach((scaleValueObject) => {
                if (indexCounter !== 0 && indexCounter !== index && scaleValueObject.value.inUse === true) {
                    scaleValueObject.controls.inUse.patchValue(false);
                }
                indexCounter++;
            });
        }
    }

    autoScaling(index: number) {
        const group = this.units.controls[index] as FormGroup;
        if (group.controls.scalingAutomated.value === true) {
            group.controls.min.patchValue(undefined);
            group.controls.max.patchValue(undefined);
            group.controls.min.disable();
            group.controls.max.disable();
        } else {
            group.controls.min.patchValue(0);
            group.controls.max.patchValue(0);
            group.controls.min.enable();
            group.controls.max.enable();
        }
    }

    applyScales() {
        const group = this.units.controls as FormGroup[];
        const scaleValues: any[] = [];
        group.forEach((scaleValueObject) => {
            scaleValues.push({ ...scaleValueObject.value });
        });
        this.store.dispatch(MeteringDataChartActions.SetChartDataScales({ scaleValues }));
        this.dialogRef.close();
    }
    closeDialog() {
        this.dialogRef.close();
    }
}
