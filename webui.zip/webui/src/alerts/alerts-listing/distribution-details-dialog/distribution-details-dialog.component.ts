import { DatePipe } from '@angular/common';
import { Component } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { IConfigureMetric } from 'alerts/alert-dialog.type';
import { AlertMetricModel } from 'alerts/alert-metric.model';
import { AlertModel } from 'alerts/alert.model';
import { AlertProfileMetricsService } from 'alerts/alert.profilemetrics.services';
import { TrendsMetricModel } from 'alerts/alertcounts.model';
import { Helper } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { AlertConstants } from '../alert-constants';
import { showByPercentageCalculation } from '../alerts-chart-config';
import {
  getChartConfig,
  getTrendsValue,
  IChart,
  plotLargeCardinalityDetailChart,
  populateChartValues,
  setGraphData
} from './chart-config';

export interface IDistibution {
  label: string;
  startTime: string;
  totalCount: number;
  isChecked?: boolean;
  percentage: number;
}

let severityMap = new Map<string, string>([
  ['WARNING', 'warning'],
  ['CRITICAL', 'danger'],
  ['Non-Alert', 'success']
]);

const MAX_SELECT_ALLOWED: number = 10;
const MIN_SELECT_ALLOWED: number = 1;
const FILTER_OPTIONS = {
  clear: 'clear',
  top: 'top',
  bottom: 'bottom'
};

@Component({
  selector: 'discovery-distribution-details-dialog',
  templateUrl: './distribution-details-dialog.component.html',
  styleUrls: ['./distribution-details-dialog.component.scss']
})
export class DistributionDetailsDialogComponent {
  sectionHeight: string = '70vh';
  title: string = '';
  assetName: string = '';
  metric: AlertMetricModel;
  alertLevel: string = '';
  probability: string = '';
  severity: string = '';
  severityText: string = '';
  selectedTimeFrame: string = '';
  allSampleKeys: string = '';
  selectedSampleKeys: string = '';
  isSampled: boolean = false;
  graphData: IChart = {} as IChart;
  completeGraphData: IChart = {} as IChart;
  lastUncheckedLabel: string;
  chartConfig: any;
  distributionList: IDistibution[] = [];
  filteredDistributionList: IDistibution[] = [];
  alert: AlertModel;
  searchText: string = '';
  isLoading: boolean = false;
  alertFromDate: Date;
  availableColorsPool: string[] = [];
  filterOptions = FILTER_OPTIONS;
  selectedDistribution: IDistibution[] = [];
  skipFilter: boolean = false;
  alertReason: string = '';
  reasonText: string = '';
  isShowPercentage: boolean = true;
  percentageChartData: any;

  constructor(
    public ref: DynamicDialogRef,
    private datePipe: DatePipe,
    private translocoService: TranslocoService,
    public config: DynamicDialogConfig,
    private alertMetricsService: AlertProfileMetricsService,
    private toastrService: ToastrService
  ) {
    this.assetName = config.data.assetName;
    this.metric = config.data.metric;
    this.probability = config.data.probability;
    this.alertLevel = config.data.alertLevel;
    this.alertReason = config.data.alertReason;
    this.alert = config.data.alert;
    this.selectedTimeFrame = config.data.timeframe;
    this.selectedSampleKeys = config.data.selectedSampleKeys;
    this.allSampleKeys = config.data.allSampleKeys;
    this.isSampled = config.data.isSampled;
    this.isShowPercentage = config.data.isShowPercentage;
    const assetStat = this.translocoService.translate('discoveryAlerts.infoPanel.stats.totalRowCountValue', {
      stat: this.assetName
    });
    this.title = this.metric.metricName + ' ' + assetStat;
    this.severity = severityMap.get(this.alertLevel);
    this.severityText = this.alertLevel.toLowerCase() + ' ' + this.probability + '%';

    const xAxisLabel = translocoService.translate('discoveryAlerts.infoPanel.stats.xAxisLabel');
    const yAxisLabel = this.metric.metricName;
    this.chartConfig = getChartConfig(xAxisLabel, yAxisLabel, this.metric, this.alert, this.isShowPercentage);
    this.getTrendsHistory(
      this.metric.metricType,
      this.selectedTimeFrame,
      new Date(this.alert.raisedAt),
      this.allSampleKeys
    );
    this.reasonText = this.getAlertReasonText(this.alertReason);
  }

  /**
   *
   * @param metricType = 'CARDINATLITY_DETAIL' always, as per current requirement
   * @param timeframe = selected value in dropdown
   * @param alertDate = raisedAt Date
   * @param allsampleKey = passed samplekeys in API
   */
  getTrendsHistory(metricType: string, timeframe: string, alertDate: Date, allsampleKey: string) {
    const fromDate = Helper.getFromDate(timeframe, alertDate);
    this.alertFromDate = alertDate;
    const assetId: string = this.alert.assetUid;
    this.isLoading = true;
    this.alertMetricsService
      .getTrendsHistory(assetId, metricType, fromDate, alertDate, allsampleKey)
      .subscribe((trends: TrendsMetricModel[]) => {
        this.createDistributionListAndGraph(trends, allsampleKey);
        this.isLoading = false;
      });
  }

  /**
   * @param reasonKey
   */
  getAlertReasonText(reasonKey: string) {
    if (reasonKey) {
      return this.translocoService?.translate('discoveryAlerts.infoPanel.stats.reasons.' + reasonKey);
    }
  }

  /**
   *
   * @param trends
   * @param allsampleKey
   * Common method to create to call create List and Graph Data from API response
   * and reset any predefined filters applied if any
   */
  createDistributionListAndGraph(trends: TrendsMetricModel[], allsampleKey: string) {
    // this.selectedSampleKeys to select checkboxes
    this.searchText = '';
    // Need to reverse beacuse we will Pop the color from colors array pool when required
    this.skipFilter = true;
    this.addAllColorsToAvailableColorPool();
    this.createChartData(trends, allsampleKey);
    this.createDistributionList(trends);
  }

  /**
   *
   * @param trends
   * @param allsampleKey
   * To Create Complete Chart Data from API response despite selected sample keys
   */
  createChartData(trends: TrendsMetricModel[], allsampleKey: string) {
    // value for y-axis on chart could be number or date so we are setting its type as any
    // finalValues > Map <key, value: Array<string>>
    let chart_values: any[] = [];
    let chart_labels: Date[] = [];
    let trendTotalCountArray: number[] = [];
    let staticKeyArray = allsampleKey ? allsampleKey.split(',') : [];
    let sampleKeyArray = [...staticKeyArray];
    // Create Map of values based on keys
    let finalValues = new Map();
    sampleKeyArray.forEach((item) => {
      finalValues.set(item, []);
    });

    trends.forEach((element: TrendsMetricModel) => {
      let dataPointDate = new Date(element.startTime);
      chart_labels.push(dataPointDate);
      trendTotalCountArray.push(element.totalCount);
      // valuePoints could be number or Date or anyother datatype
      sampleKeyArray = [...staticKeyArray];
      let valuePoints = getTrendsValue(
        element,
        this.metric.metricType,
        this.alert?.columnType,
        sampleKeyArray,
        finalValues
      );
      chart_values = populateChartValues(chart_values, valuePoints, this.metric.metricType);
    });
    this.percentageChartData = {
      labels: chart_labels,
      values: chart_values,
      alertDate: new Date(this.alert.raisedAt),
      trendTotalCountArray: trendTotalCountArray,
      isNew: false
    };
    let criticality = this.metric.metricDetails[0].alertLevel;
    // Note: We will not assign Color to any dataset Until that dataset is displayed.
    // Later in the execution we are assigning colors from 'availableColorsPool' to dataset for only selected records
    this.completeGraphData = setGraphData(
      this.metric,
      criticality,
      chart_labels,
      chart_values,
      new Date(this.alert.raisedAt),
      this.isShowPercentage,
      this.percentageChartData
    );
  }

  createDistributionList(trendsList: TrendsMetricModel[]) {
    this.filteredDistributionList = this.distributionList = [];
    if (!trendsList.length) return;

    // Select Trend only which has the Alert generated Date;
    const alertFromDate = this.datePipe.transform(this.alertFromDate, 'yyyy-MM-dd');
    const trendToSelect = trendsList.filter((trend) => {
      const trendStartDate = this.datePipe.transform(new Date(trend.startTime), 'yyyy-MM-dd');
      return trendStartDate === alertFromDate;
    });
    const trendLength = trendToSelect.length;
    if (trendLength) {
      this.distributionList = trendToSelect[trendLength - 1].details.map((item) => {
        return {
          label: item.key,
          totalCount: trendToSelect[trendLength - 1].totalCount,
          isChecked: false,
          startTime: trendToSelect[trendLength - 1].startTime,
          percentage: Number(((Number(item.value) / trendToSelect[trendLength - 1].totalCount) * 100).toFixed(2))
        };
      });

      // set Data for Graph and List
      this.setSelectedDataset();
    }
  }

  /**
   * Set the selected Data(Samplekeys) on Distibution list and Graph after API response
   */
  setSelectedDataset() {
    const selectedSampleKeys: string[] = this.selectedSampleKeys.split(',');
    this.selectedDistribution = this.distributionList.filter((item) => {
      if (selectedSampleKeys.includes(item.label)) {
        return {
          ...item,
          isChecked: true
        };
      }
    });

    this.syncnListAndGraph();
  }

  syncnListAndGraph() {
    this.syncSelectedListAndDistributionList();
    this.syncGraphWIthSelectedDistribution();
  }

  /**
   * on Dialog close
   */
  selfClose() {
    this.ref.close({ action: 'close' } as IConfigureMetric);
  }

  /**
   * on change of toggle for percentage values updating values directly to graphData
   */

  showLegendInPercentage() {
    if (this.percentageChartData?.trendTotalCountArray?.length) {
      let plotData = showByPercentageCalculation(this.percentageChartData, this.metric, this.isShowPercentage);
      let dataSets = plotLargeCardinalityDetailChart(
        plotData.values,
        plotData.lables,
        plotData.raisedOnDate,
        plotData.criticalColor,
        false
      );
      this.completeGraphData = {
        labels: plotData.lables,
        datasets: dataSets
      };
      let newDataSet = [];
      if (this.graphData?.datasets?.length && plotData?.values?.length) {
        this.graphData.datasets.forEach((dataSet) => {
          plotData.values.forEach((item) => {
            if (dataSet.label === item.label) {
              newDataSet.push({ ...dataSet, data: item.value });
            }
          });
        });
        this.graphData = {
          labels: plotData.lables,
          datasets: newDataSet
        };
      }
      const xAxisLabel = this.translocoService.translate('discoveryAlerts.infoPanel.stats.xAxisLabel');
      const yAxisLabel = this.metric.metricName;
      this.chartConfig = getChartConfig(xAxisLabel, yAxisLabel, this.metric, this.alert, this.isShowPercentage);
    }
  }

  /**
   * Pass Back State of selected data sets and timeframe to Parent component
   */
  onSaveChanges() {
    if (this.selectedDistribution.length < MIN_SELECT_ALLOWED) {
      this.toastrService.error(this.translocoService.translate('discoveryAlerts.infoPanel.minSelectionError'));
      return false;
    }
    this.ref.close({
      action: 'save',
      timeframe: this.selectedTimeFrame,
      selectedSample: this.getSelectedSampleKeys(),
      alertId: this.alert.assetUid,
      metric: this.metric,
      isShowPercentage: this.isShowPercentage
    } as IConfigureMetric);
  }

  getSelectedSampleKeys(): string {
    return this.selectedDistribution.map(({ label }) => label).join(',');
  }

  /**
   *
   * @param selectedTime
   * Called upon change of Timeframe dropdown
   */
  onUpdateTimeFrame(selectedTime: string) {
    this.selectedTimeFrame = selectedTime;
    if (selectedTime) {
      this.getTrendsHistory(
        this.metric.metricType,
        this.selectedTimeFrame,
        new Date(this.alert.raisedAt),
        this.allSampleKeys
      );
    }
  }

  /**
   *
   * @param searchText
   * @returns
   * Callback function to filter records when user input text
   */
  onSearch(searchText: string = '') {
    this.searchText = searchText;
    if (!searchText) {
      this.filteredDistributionList = this.distributionList;
      return;
    }
    this.filteredDistributionList = this.distributionList.filter((item) =>
      item.label.toLowerCase().includes(searchText.toLowerCase().trim())
    );
  }

  /**
   * Click Event binding for predefined filters i.e. Clear | Top 10 | Bottom 10
   * Reset Search filter if applied;
   * set skipFilter to true since we have added everything in color Array pool and filtering is not required
   */
  updateFilter(value: string) {
    this.searchText = '';
    this.filteredDistributionList = this.distributionList;
    switch (value) {
      case this.filterOptions.clear:
        this.addAllColorsToAvailableColorPool();
        this.skipFilter = true;
        this.selectedDistribution = [];
        break;
      case this.filterOptions.top:
      case this.filterOptions.bottom:
        this.filteredDistributionList = this.distributionList = this.onSortDistribution(this.distributionList, value);
        this.addAllColorsToAvailableColorPool();
        this.skipFilter = true;
        this.selectedDistribution = this.filteredDistributionList.slice(0, 10);
        break;
    }

    this.syncnListAndGraph();
  }

  /**
   * Add colors it to Available Colors Pool Array
   */
  addAllColorsToAvailableColorPool() {
    // Need to reverse beacuse we will Pop the color from colors array pool when required
    this.availableColorsPool = [...AlertConstants.MULTILINE_COLORS].reverse();
  }

  /**
   *
   * @param param0
   * @param sortType
   * @returns
   * Sort List based on percentage
   */
  onSortDistribution(arr: IDistibution[], sortType: string) {
    let sortedList = [];
    if (sortType === this.filterOptions.bottom) {
      sortedList = [...arr].sort((a, b) => a.percentage - b.percentage);
    }
    if (sortType === this.filterOptions.top) {
      sortedList = [...arr].sort((a, b) => b.percentage - a.percentage);
    }

    return sortedList;
  }

  onRowSelectUnselect(event, selectionType: string) {
    if (selectionType === 'uncheck') {
      // push available color to color Array Pool
      const dataSet = this.graphData.datasets.filter((elem) => elem.label === event?.data?.label);
      if (dataSet.length) {
        this.lastUncheckedLabel = dataSet[0]['label'];
        this.availableColorsPool.push(dataSet[0]['backgroundColor']);
      }
    }

    this.syncnListAndGraph();
  }

  /**
   * Selected Distribution List and Actual list should be in sync for `isChecked` attribute
   */
  syncSelectedListAndDistributionList() {
    this.distributionList = this.distributionList.map((item: IDistibution) => {
      const index = this.selectedDistribution.findIndex((selectedItem) => selectedItem.label === item.label);
      return {
        ...item,
        isChecked: index > -1 ? true : false
      };
    });

    // Sync filtered List and Actual list
    this.filteredDistributionList = this.distributionList;
    this.onSearch(this.searchText);
  }

  /**
   *
   * @param selectedDataSet
   * @returns
   * New Data Set might have records which doesnt have colors
   * and does not present in the Visual Data set for Graph i.e 'graphData'
   */
  getSelectedDataSetWithoutColors(selectedDataSet) {
    if (!this.graphData.datasets.length) {
      return selectedDataSet;
    }
    return selectedDataSet.filter(
      (dataset1) => !this.graphData.datasets.find((dataset2) => dataset1['label'] === dataset2['label'])
    );
  }

  /**
   *
   * @param selectedDataSet
   * @returns
   * Remove the recently removed record from the list i.e 'graphData'
   */
  removeDataSet([...visualGraphArray], [...selectedDataSet]) {
    if (!visualGraphArray.length) {
      return selectedDataSet;
    }
    const toRemove = visualGraphArray
      .filter((dataset1) => !selectedDataSet.find((dataset2) => dataset1['label'] === dataset2['label']))
      .map((dataset) => dataset['label'])
      .join(',');
    return visualGraphArray.filter((dataset1) => !toRemove.includes(dataset1['label']));
  }

  /**
   * Sync Graph with selected List
   * check 'skipFilter' and skip if we have added everything in color Array pool and filtering is not required
   * to be done in case of Top 10 and bottom 10 filters
   */
  syncGraphWIthSelectedDistribution() {
    if (this.selectedDistribution.length) {
      const selectedSampleKeys = this.selectedDistribution.map((sample) => sample.label);

      // all records which are currently selected but with bgcolor undefined
      let selectedDataSet = this.completeGraphData.datasets.filter((item) => {
        return selectedSampleKeys.includes(item.label);
      });

      if (!this.skipFilter) {
        let newDataSetRecord = this.getSelectedDataSetWithoutColors(selectedDataSet);
        if (newDataSetRecord.length) {
          // if we find any new record then add to visial graph data set
          selectedDataSet = this.graphData.datasets.concat(newDataSetRecord);
        } else {
          // start removing record from visual records of Graph
          selectedDataSet = this.removeDataSet(this.graphData.datasets, selectedDataSet);
        }
      }

      this.graphData = {
        datasets: this.assignColorToDataSet(selectedDataSet),
        labels: this.completeGraphData.labels
      };
    } else {
      this.graphData = {
        datasets: [],
        labels: this.completeGraphData.labels
      };
    }
    this.skipFilter = false;
  }

  /**
   *
   * find dataSet which has undefined color and assign it from pool
   *
   */
  assignColorToDataSet(selectedDataSet) {
    selectedDataSet = selectedDataSet.map((dataset) => {
      if (!dataset['backgroundColor'] && this.availableColorsPool.length) {
        const bgcolor = this.availableColorsPool.pop();
        return {
          ...dataset,
          backgroundColor: bgcolor,
          borderColor: bgcolor,
          pointBackgroundColor: dataset['pointBackgroundColor'](bgcolor),
          pointBorderColor: dataset['pointBorderColor'](bgcolor)
        };
      } else {
        return dataset;
      }
    });
    return selectedDataSet;
  }

  /**
   *
   * @param distribution
   * @returns
   * Condition require so that Maximum of 10 selection is allowed.
   */
  isMaxSelectLimit(distribution: IDistibution) {
    return !distribution.isChecked && this.selectedDistribution.length >= MAX_SELECT_ALLOWED;
  }
}
