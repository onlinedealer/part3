import { catchError } from "rxjs/operators";
import { environment } from "../../environments/environment";
import { Injectable } from "@angular/core";
import { NetworkControlParam } from "../models/network-specific-config.model";
import { Observable, throwError } from "rxjs";
import { SecurityHTTPService } from "./security-http.service";

@Injectable({
    providedIn: "root"
})
export class NetworkSpecificConfigurationService {
    constructor(private http: SecurityHTTPService) {}

    getNetworkSpecificConfigurations(): Observable<NetworkControlParam> {
        return this.http
            .get<NetworkControlParam>(`${environment.backend_api_prefix}/config/controlparams/`)
            .pipe(catchError((error: any) => throwError(error.json())));
    }
}
