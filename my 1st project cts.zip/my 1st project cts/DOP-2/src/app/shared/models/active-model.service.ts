import { Injectable } from '@angular/core';
import { DigitalProfileModel } from './digital-profile-model';
import { SubscriptionModel } from './subscription-model';
import { OrderModel } from './order-model';


@Injectable()
export class ActiveModelService {

  public profile: DigitalProfileModel;
  public subscription: SubscriptionModel[];
  public order: OrderModel;
  public paymentContent: any;

  constructor() { }

  setProfile(profile: DigitalProfileModel) {
    this.profile = profile;
  }
  getProfile(): DigitalProfileModel {
    return this.profile;
  }

  setSubscription(subscription: SubscriptionModel[]) {
    this.subscription = subscription;
  }
  getSubscription(): SubscriptionModel[]{
    return this.subscription;
  }

  setOrder(order: OrderModel) {
    this.order = order;
  }
  getOrder(): OrderModel {
    return this.order;
  }

  setPaymentConstants(paymentConst: any) {
    this.paymentContent = paymentConst;
  }
  getPaymentConstants(): OrderModel {
    return this.paymentContent;
  }
}
