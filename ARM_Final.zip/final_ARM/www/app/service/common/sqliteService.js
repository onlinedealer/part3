﻿(function () {
    'use strict';

    angular.module('arm').service("sqliteService",
        ['$http', '$q', 'GENERAL_CONFIG',
            function ($http, $q, GENERAL_CONFIG) {
                var self = this;
                //                self.db = null;
                self.init = function () {
                    if (window.cordova) {
                        //var isAndroid = ionic.Platform.isAndroid();
                        self.db = window.sqlitePlugin.openDatabase({ name: GENERAL_CONFIG.Name, location: 2 });//window.sqlitePlugin.openDatabase({ name: "salesArm.db", androidDatabaseImplementation: 2, androidLockWorkaround: 1 });
                    }

                    angular.forEach(GENERAL_CONFIG.Tables, function (table) {
                        var columns = [];

                        angular.forEach(table.columns, function (column) {
                            columns.push(column.name + ' ' + column.type);
                        });

                        var query = 'CREATE TABLE IF NOT EXISTS ' + table.name + ' (' + columns.join(',') + ')';
                        self.query(query);
                    });
                     self.deferTransaction = $q.defer();
                };
                self.query = function (query, bindings) {
                    //check if table exists.
                    if (!self.db)
                        this.init();

                    var defer = $q.defer();
                    self.db.transaction(function (transaction) {
                        transaction.executeSql(query, bindings, function (transaction, result) {
                            defer.resolve(result);
                            //console.log('Sql query sucess');
                        }, function (transaction, error) {
                            //console.log(error);
                            defer.reject(error);
                        });
                    });
                    return defer.promise
                };

                self.multipleQueries = function (queryBindingsArr){
                 if (!self.db)
                    this.init();

                 self.db.transaction(function (transaction) {
                                     for (var i = 0; i < queryBindingsArr.length; i++) {
                                     //console.log(queryBindingsArr[i].Query);
                                     transaction.executeSql(queryBindingsArr[i].Query, queryBindingsArr[i].Bindings, function (transaction, result) {
                                                            //console.log('Sql query sucess');
                                                            }, function (transaction, error) {
                                                            //console.log(error);
                                                            });
                                     }},transactionFailure,transactionSuccess);
                 return self.deferTransaction.promise
                 
                 };
                 function transactionSuccess(){
                 //alert('Transaction Success');
                    self.deferTransaction.resolve("Success");
                 };
                 function transactionFailure(error){
                 //alert('Transaction Failed' + error);
                    self.deferTransaction.reject(error);
                 };
            }]);
})();