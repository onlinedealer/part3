import { Component, OnInit, Input, AfterViewChecked, HostListener, Output, EventEmitter } from '@angular/core';
import { TouchSequence } from 'selenium-webdriver';
declare var $: any;

@Component({
  selector: 'app-left-nav',
  templateUrl: './left-nav.component.html',
  styleUrls: ['./left-nav.component.scss'],
})
export class LeftNavComponent implements OnInit {

  @Input() activeLink: string;
  @Output() linkClickEvent: EventEmitter<string> = new EventEmitter<string>();

  public tabSwitch: boolean = true;
  appStickyScrollBoolean: boolean;
  alldealsAriaSelected: boolean = false;
  yourfeedAriaSelected: boolean = false;
  oncardAriaSelected: boolean = false;
  expiringAriaSelected: boolean = false;
  newAriaSelected: boolean = false;

  constructor() {
    if((window.screen.width) > 450){
      this.appStickyScrollBoolean = true;
    }else{
      this.appStickyScrollBoolean = false;
    }
   }
  

  selectTab(tabValue) {
    //todo need to change the logic
    if (tabValue === 'All deals' || tabValue === 'Your feed') {
      $('nav').scrollLeft(-92);
    }
    else if (tabValue === 'On card') {
      $('nav').scrollLeft();
    }
    else {
      $('nav').scrollLeft(150);
    }
    
    this.activeLink = tabValue; /* Set the active for highlighting the left nav */
    this.linkClickEvent.emit(this.activeLink); /* Sends the value to parent so that right view gets changed */

  }

  ngOnInit() { 
    
  }

}