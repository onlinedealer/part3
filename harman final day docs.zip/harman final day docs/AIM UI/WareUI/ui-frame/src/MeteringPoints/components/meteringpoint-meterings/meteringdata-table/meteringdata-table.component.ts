import {
    Component,
    Input,
    ViewChild,
    Output,
    EventEmitter,
    AfterViewInit,
    ElementRef,
    SimpleChanges,
    OnChanges,
    OnInit
} from "@angular/core";
import { ValuesForTable } from "../../../models/view-objects/summarytable-vo.model";
import { CdkVirtualScrollViewport, ScrollDispatcher } from "@angular/cdk/scrolling";
import { filter } from "rxjs/operators";
import { getWindowHeight } from "../../../../app/store/selectors/ui.selectors";
import { Subscription } from "rxjs";
import { Store } from "@ngrx/store";
import { cloneDeep } from "lodash";
import { ExportDialogComponent } from "../../export-dialog/export-dialog.component";
import { MatDialog } from "@angular/material/dialog";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { MeterConnectionVO } from "../../../models/view-objects/meterconnection-vo.model";
import { TranslationsService } from "../../../../app/services/translations-service";
import { NumberFormatService } from "../../../../Shared/services/number-format.service";
import { State } from "../../../../app/store/reducers";
import { RegistersSelectors } from "../../../store/selectors";
import { EditColumnDialogComponent } from "../../edit-column-dialog/edit-column-dialog.component";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { RegisterLite } from "../../../models/register.model";
import { ExportDataColHeaderService } from "../../../../MeteringPoints/services/export-data-col-header.service";
import { ProfileDataActions } from "../../../store/actions";
import { ValueType } from "../../../services";

@Component({
    selector: "landisgyr-meteringdata-table",
    templateUrl: "./meteringdata-table.component.html",
    styleUrls: ["./meteringdata-table.component.scss"]
})
export class MeteringDatatableComponent implements AfterViewInit, OnChanges, OnInit {
    @ViewChild(CdkVirtualScrollViewport) virtualScrollViewport!: CdkVirtualScrollViewport;
    @ViewChild("table", { static: true }) table!: ElementRef;
    @Input() showExpanded!: boolean;
    @Input() detailsExpanded = false;
    @Input() detailsExpandedPrepayment = false;
    @Input() data!: ValuesForTable[];
    @Input() dataToExport!: ValuesForTable[];
    @Input() dates!: string[];
    @Input() meteringPoint!: MeteringPoint;
    @Input() meteringDataForExport!: any;
    @Input() decimalCount!: number;
    @Input() fromTab!: string;
    binaryZeroArray = "00000000".split("");
    @Input() profilePeriodicColumnConfig: {
        columnId: string;
        columnName: string;
        showColumn: boolean;
        draggedColumn?: boolean;
        columnWidth: number;
    }[] = [];
    @Input() sortColumnname!: string;
    @Input() editMode!: boolean;
    @Input() selectedMeteringId!: number;
    @Input() devices: MeterConnectionVO[] = [];
    @Input() undoRedoDisabled!: { undoDisabled: boolean; redoDisabled: boolean };
    @Input() editDisabled!: { valuesDisabled: boolean; cumulativeValuesDisabled: boolean };
    @Input() operationsDisabled!: { multiplyDisabled: boolean; interpolationDisabled: boolean };
    @Input() allSelected!: { allValuesSelected: boolean; allCumulativeValuesSelected: boolean };
    @Input() isProfileDataEdited!: boolean;
    @Input() editSuccess!: boolean;
    @Input() editError!: string;
    @Input() viewName!: string;
    @Output()
    changeRangeDateFiltersFromTableData = new EventEmitter();
    @Output() sortChangeEvent: EventEmitter<SortOrder> = new EventEmitter();

    hideEndOfResultsMessage = true;
    infoMessage = $localize`:|@@meteringdataTable.endOfPeriodReached:End of the selected time period`;
    noDataMessage = this.translations.getTranslation("No data available for the selected time period");
    missingDataInfoMessage1!: string;
    missingDataInfoMessage2!: string;
    windowHeightSub!: Subscription;
    scrollVisible!: boolean;
    deviceList!: MeterConnectionVO[];
    registersList: RegisterLite[] = [];
    @Input() deviceMeterRegisterIds!: { [id: number]: number[] };

    @Input() timeRange!: { from: number; until: number };

    constructor(
        private scrollDispatcher: ScrollDispatcher,
        private store: Store<State>,
        private dialog: MatDialog,
        private translations: TranslationsService,
        private numberFormatService: NumberFormatService,
        private exportDataColHeaderService: ExportDataColHeaderService
    ) {}
    ngOnInit() {
        this.missingDataInfoMessage1 = $localize`:|@@meteringdataTable.dataMissingFor:Data missing for`;
        this.missingDataInfoMessage2 = $localize`:|@@meteringdataTable.showEmptyXxRows:Show # empty rows`;
    }
    ngOnChanges(changes: SimpleChanges) {
        this.checkTableScroll();
        if ((changes.columns || changes.data) && this.virtualScrollViewport) {
            this.virtualScrollViewport.checkViewportSize();
        }
    }

    ngAfterViewInit(): void {
        this.scrollDispatcher
            .scrolled()
            .pipe(filter(() => this.isShowEndResultsToBeToggled()))
            .subscribe(() => {
                if (this.isScrolledCloseToEnd()) {
                    this.hideEndOfResultsMessage = false;
                    this.virtualScrollViewport.scrollToIndex(this.virtualScrollViewport.getDataLength());
                } else {
                    this.hideEndOfResultsMessage = true;
                }
            });

        setTimeout(() => {
            if (this.isScrolledCloseToEnd()) {
                this.hideEndOfResultsMessage = false;
            }
        });
        this.windowHeightSub = this.store.select(getWindowHeight).subscribe((data) => {
            this.checkTableScroll();
            if (this.virtualScrollViewport) {
                this.virtualScrollViewport.checkViewportSize();
            }
        });
    }

    addPreviousPeriod(data: any) {
        this.changeRangeDateFiltersFromTableData.emit({
            from: data.from,
            until: JSON.parse(data.until),
            dateRangeChecked: data.dateRangeChecked
        });
    }

    private isShowEndResultsToBeToggled() {
        if (this.virtualScrollViewport === undefined) {
            return false;
        }

        return this.hideEndOfResultsMessage === this.isScrolledCloseToEnd();
    }

    private isScrolledCloseToEnd() {
        return (
            this.virtualScrollViewport && this.virtualScrollViewport.getRenderedRange().end > this.virtualScrollViewport.getDataLength() - 5
        );
    }
    checkTableScroll() {
        const tableContentHeight = this.data.length * 40;
        if (tableContentHeight / this.table.nativeElement.offsetHeight >= 1) {
            this.scrollVisible = true;
        } else {
            this.scrollVisible = false;
        }
    }
    onSortChange(event: SortOrder) {
        this.sortChangeEvent.next(event);
    }
    binaryConversion(decimalValue: number | undefined | null): string | null {
        if (decimalValue === undefined || decimalValue === null) {
            return null;
        } else if (decimalValue >= 0) {
            const binaryArray = parseInt(decimalValue.toString(), 10).toString(2).split("");
            if (binaryArray.length < 8) {
                const loop = 8 - binaryArray.length;
                for (let i = 0; i < loop; i++) {
                    binaryArray.unshift("0");
                }
            }
            return binaryArray.join("");
        } else {
            return null;
        }
    }

    getDeviceSerialNumber(id: number): string {
        const device = this.devices.find((item) => {
            return item.deviceMeterId === id;
        });
        return device ? device.meterSerialNumber : "";
    }

    findDeviceByRegister(regId: number): string {
        const getDeviceKeys: number[] = Object.keys(this.deviceMeterRegisterIds).map((item) => parseInt(item, 10));
        const deviceIds: number[] = [];
        for (let i = 0; i < getDeviceKeys.length; i++) {
            if (this.deviceMeterRegisterIds[getDeviceKeys[i]].indexOf(regId) > -1) {
                deviceIds.push(getDeviceKeys[i]);
            }
        }
        if (deviceIds.length === 0) {
            return "";
        }
        if (deviceIds.length === 1) {
            return this.getDeviceSerialNumber(deviceIds[0]);
        }
        if (deviceIds.length > 1) {
            return $localize`:|@@meteringdataTable.invalidRegisters:Invalid registers`;
        }
        return "";
    }

    getTimestamp(dateStr: string | number): number {
        const date = new Date(dateStr);
        return date.getTime();
    }

    getMeterNumber(metering: any): string {
        const meterings = cloneDeep(metering);
        this.registersList = this.registersList.filter((register) => {
            return (
                (register.periodicMeteringId && register.periodicMeteringId === meterings.meteringId) ||
                (register.profileMeteringId && register.profileMeteringId === meterings.meteringId)
            );
        });
        for (let i = 0; i < this.registersList.length; i++) {
            if (this.registersList[i].validUntil) {
                if (
                    meterings.valueEndFullDate >= this.registersList[i].validFrom &&
                    // tslint:disable-next-line:no-non-null-assertion
                    meterings.valueEndFullDate <= this.registersList[i].validUntil!
                ) {
                    return this.findDeviceByRegister(this.registersList[i].registerId);
                }
            } else if (meterings.valueEndFullDate > this.registersList[i].validFrom) {
                return this.findDeviceByRegister(this.registersList[i].registerId);
            }
        }
        return "";
    }

    loadRegisters() {
        this.store.select(RegistersSelectors.getRegistersOfSelectedMeteringPoint).subscribe((registers: RegisterLite[]) => {
            this.registersList = registers;
        });
    }

    openExportDialog() {
        const exportData: any[] = cloneDeep(this.dataToExport);
        exportData.forEach((item) => {
            if (this.meteringDataForExport) {
                item["unit"] = this.meteringDataForExport.unit;
                item["meteringName"] = this.meteringDataForExport.meteringName;
                item["meteringNumber"] = this.meteringDataForExport.meteringNumber;
            }
            item["status"] = this.binaryConversion(item.status);
            item["validatedStatus"] = this.binaryConversion(item.validatedStatus);
            item["deviceNumber"] = this.getMeterNumber(item);
        });

        this.dialog.open(ExportDialogComponent, {
            width: "850px",
            maxWidth: "850px",
            height: "600px",
            maxHeight: "600px",
            disableClose: true,
            data: {
                fileName: this.meteringPoint.name + "_" + this.meteringDataForExport.meteringName,
                results: exportData,
                includePageRange: false,
                includeTimeRange: true,
                timeRangeInput: this.timeRange,
                havingBinaryConvertedData: true,
                header: this.exportDataColHeaderService.meteringsHeader
            }
        });
    }
    openEditColumnDialog() {
        this.dialog.open(EditColumnDialogComponent, {
            width: "550px",
            maxWidth: "550px",
            height: "620px",
            maxHeight: "700px",
            disableClose: true,
            data: {
                results: [],
                header: this.profilePeriodicColumnConfig,
                tabSelectionFlag: this.viewName,
                Expansion: this.showExpanded
            }
        });
    }

    getFormattedNumber(value: number | undefined): string | null {
        if (value != null) {
            if (this.decimalCount != null) {
                const dc = this.decimalCount.toString();
                return this.numberFormatService.toLocaleNumberString(value, "1." + dc + "-" + dc);
            } else {
                return value.toString();
            }
        } else {
            return "";
        }
    }

    toggleEditMode(editMode: boolean) {
        this.store.dispatch(ProfileDataActions.SwitchEditMode({ editMode: editMode, selectedMeteringId: this.selectedMeteringId }));
    }

    selectAll(event: any, element: any, colValueType: string) {
        event.preventDefault();
        if (event.target !== element) {
            event.stopPropagation();
        }
        const valueType = colValueType === "Value" ? ValueType.value : ValueType.cumulativeValue;
        let selected = true;
        if (
            (valueType === ValueType.value && !this.editDisabled.valuesDisabled) ||
            (valueType === ValueType.cumulativeValue && !this.editDisabled.cumulativeValuesDisabled)
        ) {
            if (
                (valueType === ValueType.value && this.allSelected.allValuesSelected) ||
                (valueType === ValueType.cumulativeValue && this.allSelected.allCumulativeValuesSelected)
            ) {
                selected = false;
            } else if (
                (valueType === ValueType.value && !this.allSelected.allValuesSelected) ||
                (valueType === ValueType.cumulativeValue && !this.allSelected.allCumulativeValuesSelected)
            ) {
                selected = true;
            }
            this.store.dispatch(
                ProfileDataActions.SelectAllValues({
                    selectedMeteringId: this.selectedMeteringId,
                    selected: selected,
                    valueType: valueType
                })
            );
        }
    }
    showMissingRows(readingsToShow: number[]) {
        this.store.dispatch(
            ProfileDataActions.ShowMissingRows({
                readingsToShow: readingsToShow,
                selectedMeteringId: this.selectedMeteringId
            })
        );
    }

    compileMissingDataText(missingTime: string) {
        return ` ${this.missingDataInfoMessage1} ${missingTime}`;
    }

    compileShowRowsText(missingRows: number) {
        return this.missingDataInfoMessage2.replace("#", missingRows.toString());
    }

    trackByFn(index: any, item: any) {
        // This mysteriously fixes so much weird behavior from the table edit mode
        // Something to do with tracking indexes and not rerendering stuff again unnecessarly
        return index;
    }
}
