import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { ErrorMessagesService } from '@precisely/prism-ng/cloud';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { of } from 'rxjs';
import { AppInitializerService } from './app-initializer.service';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;

  const mockAppInitializerService = {
    isAppInitialized: true
  };

  const mockLaunchDarklyService = jasmine.createSpyObj({
    dispose: () => of(),
    identify: () => of(),
    variation: () => {}
  });

  const mockErrorMessagesService = {
    messages: []
  };

  const mockRouter = jasmine.createSpyObj('Router', ['navigate']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule, HttpClientTestingModule],
      providers: [
        { provide: AppInitializerService, useValue: mockAppInitializerService },
        { provide: LaunchDarklyService, useValue: mockLaunchDarklyService },
        { provide: Router, useValue: mockRouter }
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [AppComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  beforeEach(() => {
    mockAppInitializerService.isAppInitialized = true;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('navigates to error page when not initialized', () => {
    mockAppInitializerService.isAppInitialized = false;
    component.ngOnInit();
    expect(mockRouter.navigate).toHaveBeenCalledWith(['data-integration/error']);
  });

  it('should call close method of launch darkly service,', () => {
    component.closeLaunchDarkly();
    expect(mockLaunchDarklyService.dispose).toHaveBeenCalled();
  });
});
