import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../../connections/shared/connection';
import { Metabase } from '../../../shared/metabase.model';
import { Subscription } from 'rxjs';
import { MetabasesApiService } from '../../../shared/metabases-api.service';
import { EncryptionService } from '@shared/services/encryption.service';

export enum SQLSERVER_METABASE_PARAMETERS {
  REPLICATION_USER_ID = 'REPLICATION_USER_ID',
  REPLICATION_USER_PASSWORD = 'REPLICATION_USER_PASSWORD',
  ENABLE_CDC = 'ENABLE_CDC',
  MAX_NUM_ROWS = 'MAX_NUM_ROWS',
  DATA_LOGICAL_NAME = 'DATA_LOGICAL_NAME',
  DATA_PHYSICAL_NAME = 'DATA_PHYSICAL_NAME',
  DATA_SIZE_MB = 'DATA_SIZE_MB',
  LOG_LOGICAL_NAME = 'LOG_LOGICAL_NAME',
  LOG_PHYSICAL_NAME = 'LOG_PHYSICAL_NAME',
  LOG_SIZE_MB = 'LOG_SIZE_MB'
}

/**
 * Partial form for creating metabases for SQLSERVER data connections
 */
@Component({
  selector: 'p-connect-sqlserver-metabase-form',
  templateUrl: './sqlserver-metabase-form.component.html'
})
export class SqlServerMetabaseFormComponent implements OnInit, OnDestroy {
  sqlserverMetabaseForm: FormGroup;

  sqlServerDirectoryPath: string;

  sqlServerPathsReturned = false;

  @Input() maximumTransactionRowOptions = [
    { label: '400000', value: '400000' },
    { label: '800000', value: '800000' },
    { label: '1200000', value: '1200000' },
    { label: '1600000', value: '1600000' },
    { label: '2000000', value: '2000000' },
    { label: '2400000', value: '2400000' },
    { label: '2800000', value: '2800000' },
    { label: '3200000', value: '3200000' },
    { label: '3600000', value: '3600000' },
    { label: '4000000', value: '4000000' },
    { label: '4400000', value: '4400000' },
    { label: '4800000', value: '4800000' },
    { label: '5200000', value: '5200000' },
    { label: '5600000', value: '5600000' },
    { label: '6000000', value: '6000000' },
    { label: '6400000', value: '6400000' },
    { label: '6800000', value: '6800000' },
    { label: '7200000', value: '7200000' },
    { label: '7600000', value: '7600000' },
    { label: '8000000', value: '8000000' }
  ];

  private readonly subscriptions: any[] = [];

  /**
   * handles an event to set a progress indicator when the form is running a potentially long running process, such as an API request
   */
  @Output() setInProgressEvent = new EventEmitter<boolean>();

  /**
   * handles an event from the form when an error messsage needs to be set
   */
  @Output() setErrorMessageEvent = new EventEmitter<any>();

  /**
   * Data connection that applies to this form
   */
  @Input() dataConnection: Connection;
  isProcessingRequest = false;

  constructor(
    private readonly controlContainer: ControlContainer,
    private readonly metabaseService: MetabasesApiService,
    private readonly encryptionApiService: EncryptionService
  ) {}

  ngOnInit() {
    this.configureForm();

    if (this.dataConnection) {
      this.sqlserverMetabaseForm.get('databaseServer').setValue(`${this.dataConnection.database}:${this.dataConnection.port}`);
    }
  }
  ngOnDestroy() {
    this.subscriptions.forEach((s) => s.unsubscribe());
    this.removeForm();
  }

  /**
   * Removes form and any form specific translations or validation
   */
  private removeForm(): void {
    if (this.sqlserverMetabaseForm) {
      this.sqlserverMetabaseForm.clearValidators();
      this.sqlserverMetabaseForm.updateValueAndValidity();

      Object.keys(this.sqlserverMetabaseForm.controls).forEach((key) => {
        if (key !== 'dataConnection') {
          this.sqlserverMetabaseForm.removeControl(key);
        }
      });
    }
  }

  private configureForm(): void {
    this.sqlserverMetabaseForm = this.controlContainer.control as FormGroup;
    this.sqlserverMetabaseForm.addControl('databaseServer', new FormControl({ value: '', disabled: true }));
    this.sqlserverMetabaseForm.addControl('userID', new FormControl('sa', Validators.required));
    this.sqlserverMetabaseForm.addControl('password', new FormControl('', Validators.required));
    this.sqlserverMetabaseForm.addControl('replicationUserID', new FormControl({ value: 'rpuser', disabled: true }, Validators.required));
    this.sqlserverMetabaseForm.addControl('replicationPassword', new FormControl('', Validators.required));
    this.sqlserverMetabaseForm.addControl('metabaseName', new FormControl('omnirep'));
    // this.sqlserverMetabaseForm.addControl('captureType', new FormControl({ value: 'LOG_BASED', disabled: true }));
    this.sqlserverMetabaseForm.addControl(
      'maximumTransactionRow',
      new FormControl({ value: '400000', disabled: true }, Validators.required)
    );
    this.sqlserverMetabaseForm.addControl(
      'dataLogicalName',
      new FormControl({ value: 'omnirep_data', disabled: true }, Validators.required)
    );
    this.sqlserverMetabaseForm.addControl('dataSize', new FormControl({ value: '64', disabled: true }, Validators.required));
    this.sqlserverMetabaseForm.addControl(
      'dataPhysicalName',
      new FormControl({ value: '...\\omnirep_data.mdf', disabled: true }, Validators.required)
    );
    this.sqlserverMetabaseForm.addControl('logLogicalName', new FormControl({ value: 'omnirep_log', disabled: true }, Validators.required));
    this.sqlserverMetabaseForm.addControl('logSize', new FormControl({ value: '64', disabled: true }, Validators.required));
    this.sqlserverMetabaseForm.addControl(
      'logPhysicalName',
      new FormControl({ value: '...\\omnirep_data.ldf', disabled: true }, Validators.required)
    );

    this.sqlserverMetabaseForm.get('metabaseName').valueChanges.subscribe((value) => {
      this.enableSQLServerControls(value !== '');
    });
  }

  private enableSQLServerControls(enableControls: boolean): void {
    if (enableControls && this.sqlServerPathsReturned) {
      // this.sqlserverMetabaseForm.get('captureType').enable();
      this.sqlserverMetabaseForm.get('dataLogicalName').enable();
      this.sqlserverMetabaseForm.get('dataSize').enable();
      this.sqlserverMetabaseForm.get('dataPhysicalName').enable();
      this.sqlserverMetabaseForm.get('logLogicalName').enable();
      this.sqlserverMetabaseForm.get('logSize').enable();
      this.sqlserverMetabaseForm.get('logPhysicalName').enable();
    } else {
      // this.sqlserverMetabaseForm.get('captureType').disable();
      this.sqlserverMetabaseForm.get('dataLogicalName').disable();
      this.sqlserverMetabaseForm.get('dataSize').disable();
      this.sqlserverMetabaseForm.get('dataPhysicalName').disable();
      this.sqlserverMetabaseForm.get('logLogicalName').disable();
      this.sqlserverMetabaseForm.get('logSize').disable();
      this.sqlserverMetabaseForm.get('logPhysicalName').disable();
    }
  }

  get metabase(): Metabase {
    return {
      name: this.sqlserverMetabaseForm.get('metabaseName').value,
      adminUserId: this.sqlserverMetabaseForm.get('userID').value,
      adminUserPassword: this.sqlserverMetabaseForm.get('password').value,
      dataConnection: {
        id: (this.sqlserverMetabaseForm.get('dataConnection').value as Connection).id,
        accessFromServer: (this.sqlserverMetabaseForm.get('dataConnection').value as Connection).accessFromServer
      },
      parameters: [
        {
          key: SQLSERVER_METABASE_PARAMETERS.REPLICATION_USER_ID,
          value: this.sqlserverMetabaseForm.get('replicationUserID').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.REPLICATION_USER_PASSWORD,
          value: this.sqlserverMetabaseForm.get('replicationPassword').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.ENABLE_CDC,
          value: 'true'
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.MAX_NUM_ROWS,
          value: this.sqlserverMetabaseForm.get('maximumTransactionRow').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.DATA_LOGICAL_NAME,
          value: this.sqlserverMetabaseForm.get('dataLogicalName').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.DATA_PHYSICAL_NAME,
          value: this.sqlserverMetabaseForm.get('dataPhysicalName').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.DATA_SIZE_MB,
          value: this.sqlserverMetabaseForm.get('dataSize').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.LOG_LOGICAL_NAME,
          value: this.sqlserverMetabaseForm.get('logLogicalName').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.LOG_PHYSICAL_NAME,
          value: this.sqlserverMetabaseForm.get('logPhysicalName').value
        },
        {
          key: SQLSERVER_METABASE_PARAMETERS.LOG_SIZE_MB,
          value: this.sqlserverMetabaseForm.get('logSize').value
        }
      ]
    };
  }

  // /**
  //  * This function is used to fix a bug with p-radiobuttons when used in a reactive form https://github.com/primefaces/primeng/issues/9162
  //  * It is also used to enable or disable the maximum transaction row form control
  //  * @param value the selected value
  //  */
  // setCaptureTypeValue(value) {
  //   this.sqlserverMetabaseForm.get('captureType').setValue(value, { emitEvent: false });
  //   if (value === 'LOG_BASED') {
  //     this.sqlserverMetabaseForm.get('maximumTransactionRow').disable();
  //   } else {
  //     this.sqlserverMetabaseForm.get('maximumTransactionRow').enable();
  //   }
  // }

  async retrieveSQLServerPaths() {
    this.isProcessingRequest = true;
    const connectionId = this.sqlserverMetabaseForm.get('dataConnection').value.id;
    const userId = this.sqlserverMetabaseForm.get('userID').value;
    let encryptedPassword: any = await this.encryptionApiService.encrypt(
      this.dataConnection.accessFromServer.name,
      this.sqlserverMetabaseForm.get('password').value
    );
    const password = encryptedPassword;

    this.setInProgressEvent.emit(true);
    this.setErrorMessageEvent.emit();

    this.subscriptions.push(
      this.metabaseService
        .getPhysicalSQLServerPaths(connectionId, { adminUserId: userId, adminUserPassword: password })
        .subscribe({
          next: (response: { directoryPath: string }) => {
            const metabaseName = this.sqlserverMetabaseForm.get('metabaseName').value;

            this.sqlServerPathsReturned = true;
            this.sqlServerDirectoryPath = response.directoryPath;

            this.sqlserverMetabaseForm.patchValue({
              dataPhysicalName: `${this.sqlServerDirectoryPath}\\${metabaseName}_data.mdf`,
              logPhysicalName: `${this.sqlServerDirectoryPath}\\${metabaseName}_log.ldf`
            });

            this.enableSQLServerControls(true);
          },
          error: (error) => {
            this.enableSQLServerControls(false);
            this.setErrorMessageEvent.emit(error);
          }
        })
        .add(() => {
          this.isProcessingRequest = false;
          this.setInProgressEvent.emit(false);
        })
    );
  }

  metabaseNameKeyupEvent(event: KeyboardEvent) {
    const metabaseName = (event.target as HTMLInputElement).value;

    if (this.sqlServerPathsReturned === true) {
      this.sqlserverMetabaseForm.patchValue({
        dataLogicalName: `${metabaseName}_data`,
        dataPhysicalName: `${this.sqlServerDirectoryPath}\\${metabaseName}_data.mdf`,
        logLogicalName: `${metabaseName}_log`,
        logPhysicalName: `${this.sqlServerDirectoryPath}\\${metabaseName}_log.ldf`
      });
    } else {
      this.sqlserverMetabaseForm.patchValue({
        dataLogicalName: `${metabaseName}_data`,
        dataPhysicalName: `C:\\Program Files\\Microsoft SQL Server\\MSSQL13.MSSQLSERVER\\MSSQL\\DATA\\${metabaseName}_data.mdf`,
        logLogicalName: `${metabaseName}_log`,
        logPhysicalName: `C:\\Program Files\\Microsoft SQL Server\\MSSQL13.MSSQLSERVER\\MSSQL\\DATA\\${metabaseName}_log.ldf`
      });
    }
  }
}
