import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';
import { CouponHelperService } from '../../services/coupon-helper.service';

@Component({
  selector: 'app-earned-xtrabucks',
  templateUrl: './earned-xtrabucks.component.html',
  styleUrls: ['./earned-xtrabucks.component.scss']
})
export class EarnedXtrabucksComponent implements OnInit {
  @Input() data: any;

  imagesPaths:Object = ImagePaths;

  constructor(public utilityService:UtilityService, public couponHelperService: CouponHelperService) { }

  ngOnInit() {
  }

}
