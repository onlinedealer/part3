import { Component, Input } from '@angular/core';
import { CatalogStatus, CATALOG_STATUS } from '../../catalogs/shared/catalog-status';
import { CatalogStatusSummary } from '../../catalogs/shared/catalog-status-summary';

/**
 * Component for displaying the catalog status, use either the status or the statusSummary to display the status for the catalog
 */
@Component({
  selector: 'p-connect-catalog-status',
  templateUrl: './catalog-status.component.html'
})
export class CatalogStatusComponent {
  /**
   * The catalog status as returned from the status API
   */
  @Input() catalogStatus: CatalogStatus;

  /**
   * The catalog status summary as returned from the statusSummary API
   */
  @Input() catalogStatusSummary: CatalogStatusSummary;

  /**
   * The connection type
   */
  @Input() connectionType: string;

  get isCatalogComplete(): boolean {
    return (
      (this.catalogStatus && this.catalogStatus.status === CATALOG_STATUS.COMPLETE) ||
      (this.catalogStatusSummary && this.catalogStatusSummary.status === CATALOG_STATUS.COMPLETE)
    );
  }

  /**
   * Get text and icon for the catalog status
   */
  getStatusIcon(status: string): string[] {
    let statusIcon = [];

    if (status) {
      switch (status.toUpperCase()) {
        case 'NOT_CATALOGED':
          statusIcon = ['png-disabled', 'text-muted'];
          break;
        case 'INPROGRESS':
          statusIcon = ['png-alert-inprogress', 'text-success'];
          break;
        case 'COMPLETE':
          statusIcon = ['png-alert-open', 'text-success'];
          break;
        default:
          statusIcon = [];
      }
    }

    return statusIcon;
  }

  /**
   * Returns the item count based on the connection type
   * @returns The number of items in the catalog
   */
  getItemCount() {
    switch (this.connectionType) {
      case 'SCHEMAREGISTRY':
        return this.catalogStatus?.subjects.length || this.catalogStatusSummary?.subjects.total || 0;
      case 'KAFKA':
        return this.catalogStatus?.topics.length || this.catalogStatusSummary?.topics.total || 0;
      default:
        return this.catalogStatus?.schemas.length || this.catalogStatusSummary?.schemas.total || 0;
    }
  }

  /**
   * Returns the item label based on the connection type
   * @returns The item label
   */
  getItemLabel() {
    switch (this.connectionType) {
      case 'SCHEMAREGISTRY':
        return this.getItemCount() !== 1
          ? 'connections.CATALOG_STATUS.ITEM_TYPES.SUBJECTS'
          : 'connections.CATALOG_STATUS.ITEM_TYPES.SUBJECT';
      case 'DB2':
        return this.getItemCount() !== 1
          ? 'connections.CATALOG_STATUS.ITEM_TYPES.LIBRARIES'
          : 'connections.CATALOG_STATUS.ITEM_TYPES.LIBRARY';
      case 'KAFKA':
        return this.getItemCount() !== 1 ? 'connections.CATALOG_STATUS.ITEM_TYPES.TOPICS' : 'connections.CATALOG_STATUS.ITEM_TYPES.TOPIC';
      case 'SQLSERVER':
        return this.getItemCount() !== 1
          ? 'connections.CATALOG_STATUS.ITEM_TYPES.DATABASES'
          : 'connections.CATALOG_STATUS.ITEM_TYPES.DATABASE';
      default:
        return this.getItemCount() !== 1 ? 'connections.CATALOG_STATUS.ITEM_TYPES.SCHEMAS' : 'connections.CATALOG_STATUS.ITEM_TYPES.SCHEMA';
    }
  }

  /**
   * Returns the translation for catalog status as per passed object
   * @returns The item catalog status
   */
  getTranslatedCatalogStatus(catalogStatus, catalogStatusSummary, name: string) {
    if (catalogStatus?.status) {
      return 'connections.CATALOG_STATUS.' + catalogStatus?.status.toUpperCase() + name;
    } else {
      return 'connections.CATALOG_STATUS.' + catalogStatusSummary?.status.toUpperCase() + name;
    }
  }
}
