export class ColumnModel {
  name: string;
  type: string;
  selected: boolean;
  uniqueKey: number | string;
  observed?: boolean;
  rowDisabled?: boolean;
  checkboxDisabled?: boolean;
  tooltip?: string;
  schema?: string;
  /**
   * display name data type of the column table
   */
  columnDataType?: string;
  constructor(column?: ColumnModel) {
    this.selected = column ? column.selected : true;
    if (column) {
      this.name = column.name;
      this.columnDataType = column.columnDataType;
      this.type = column.type;
      this.uniqueKey = column.uniqueKey;
      this.observed = column.observed;
      this.rowDisabled = column.rowDisabled;
      this.checkboxDisabled = column.checkboxDisabled;
      this.tooltip = column.tooltip;
      this.schema = column.schema;
    }
  }
}
