import { Mocks, Spies } from 'discovery-test';
import { of } from 'rxjs';
import { ConnectionService } from './connection.service';

describe('ConnectionService', () => {
  let service: ConnectionService;

  beforeEach(() => {
    Spies.init();
    service = new ConnectionService(Spies.HttpClient, Spies.AuthenticationService, Spies.HttpUtilService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should get list of connection on getConnectionList', () => {
    Spies.ConnectionService.getConnectionList.and.returnValue();
    service.getConnectionList();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should test connection by id on testConnectionByID', () => {
    const connectionList = Mocks.MockConnections;
    expect(service.testConnectionByID(connectionList[0]['id'])).toBeDefined();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should test connection by object on testConnectionByObject', () => {
    const connectionList = Mocks.MockConnections;
    expect(service.testConnectionByObject(connectionList[0])).toBeDefined();
  });

  it('should load connection on getConnectionById', () => {
    const connectionList = Mocks.MockConnections;
    Spies.ConnectionService.getConnectionById.and.returnValue(of(connectionList[0]['id']));
    service.getConnectionById(connectionList[0]['id']);
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should load table on getTableList', () => {
    const tableList = Mocks.MockTables;
    Spies.ConnectionService.getTableList.and.returnValue(of(tableList));
    service.getTableList(tableList[0]['type'], tableList[0]['name'], false);
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should load column on getColumnList', () => {
    const columnList = Mocks.MockColumns;
    const tableList = Mocks.MockTables;
    Spies.ConnectionService.getColumnList.and.returnValue(of(columnList));
    service.getColumnList(columnList[0]['type'], columnList[0]['name'], tableList[0], false);
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should save connection on saveConnection', () => {
    const connectionList = Mocks.MockConnections;
    Spies.ConnectionService.saveConnection.and.returnValue(of(connectionList[0]));
    service.saveConnection(connectionList[0], true);
  });
});
