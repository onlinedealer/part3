export interface EventResponse {
  status: string;
  successCount: number;
  failureCount: number;
  totalCount: number;
  errResponse: [];
}
