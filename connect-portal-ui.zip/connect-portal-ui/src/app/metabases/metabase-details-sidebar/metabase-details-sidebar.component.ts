import { Component, ViewChild } from '@angular/core';
import { SidebarButton } from '../../shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';
import { Metabase } from '../shared/metabase.model';
import { MetabaseDetailsFormComponent } from './metabase-details-form/metabase-details-form.component';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { ProjectsApiService } from '../../pipelines/pipeline/shared/projects-api.service';
import { mergeMap } from 'rxjs/operators';

@Component({
  selector: 'p-connect-metabase-details-sidebar',
  templateUrl: './metabase-details-sidebar.component.html'
})
export class MetabaseDetailsSidebarComponent {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * Reference to the MetabaseDetailsFormComponent child component
   */
  @ViewChild(MetabaseDetailsFormComponent) metabaseDetailsFormComponent: MetabaseDetailsFormComponent;
  /**
   * Close button
   */
  closeButton: SidebarButton = {
    id: 'metabaseDetailsCloseButton',
    text: 'common.BUTTONS.CLOSE'
  };

  selectedMetabase: Metabase;

  constructor(private readonly metabasesApiService: MetabasesApiService, private readonly projectsApiService: ProjectsApiService) {}

  /**
   * Opens the metabase details sidebar
   * @param selectedMetabase The selected metabase
   */
  open(selectedMetabase: Metabase) {
    this.selectedMetabase = selectedMetabase;
    this.getAllMetabases();
  }

  /**
   * Event handler for when the close button is clicked
   */
  closeButtonClicked(): void {
    this.sidebarComponent.close();
  }

  getAllMetabases() {
    this.sidebarComponent.isProcessingRequest = true;
    this.projectsApiService
      .getDefaultProject()
      .pipe(
        mergeMap((project) => {
          this.metabasesApiService.serviceURL = `projects/${project.id}/metabases`;
          return this.metabasesApiService.getAll();
        })
      )
      .subscribe({
        next: (metabases) => {
          let data = metabases.map((metabase: Metabase) => {
            return {
              ...metabase
            };
          });
          const metabaseName = this.selectedMetabase.name;
          if (data.filter((metabase: Metabase) => metabase.name === this.selectedMetabase.name).length === 0) {
            this.selectedMetabase = null;
          }
          this.sidebarComponent.open();
          this.metabaseDetailsFormComponent.open(this.selectedMetabase, metabaseName);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }
}
