/**
 *
 */
export enum ConnectionsStatesModel {
  connections = 'connections',
  newConnection = 'newConnection',
  editConnection = 'editConnection',
  copyConnection = 'copyConnection',
  connectionDetail = 'connectionDetail'
}
