import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslocoService, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { DropdownModule } from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import { of } from 'rxjs';
import { ConnectionsApiService } from '../../../../../../connections/shared/connections-api.service';
import { getTranslocoModule } from '../../../../../../core/transloco-testing.module';
import { FeatureFlagService } from '../../../../../../shared/services/feature-flag.service';
import { KafkaTargetOptionsComponent } from './kafka-target-options.component';

describe('KafkaTargetOptionsComponent', () => {
  let component: KafkaTargetOptionsComponent;
  let fixture: ComponentFixture<KafkaTargetOptionsComponent>;
  let translocoService: TranslocoService;
  let featureFlagService: any;
  let connectionsService: any;

  const mockConnections = [
    { id: '1', name: 'name1', connectionType: 'SCHEMAREGISTRY' },
    { id: '2', name: 'name2', connectionType: 'ORACLE' },
    { id: '3', name: 'name3', connectionType: 'SCHEMAREGISTRY' }
  ];

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });
  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(async () => {
    featureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);
    connectionsService = jasmine.createSpyObj('ConnectionsApiService', ['getAll']);

    await TestBed.configureTestingModule({
      declarations: [KafkaTargetOptionsComponent],
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule, DropdownModule, RadioButtonModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: '' } },
        {
          provide: ControlContainer,
          useValue: fgd
        },
        { provide: FeatureFlagService, useValue: featureFlagService },
        { provide: ConnectionsApiService, useValue: connectionsService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    spyOn(connectionsService, 'getAll').and.returnValue(of(mockConnections));
    fixture = TestBed.createComponent(KafkaTargetOptionsComponent);
    component = fixture.componentInstance;
    translocoService = TestBed.inject(TranslocoService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('changes to message format', () => {
    it('should set default values for json specific fields when message format changes', () => {
      component.targetForm.controls.omitNulls.setValue(undefined);
      component.targetForm.controls.removeTrailingBlanks.setValue(undefined);
      component.onMessageFormatChange({ value: 'JSON' });
      expect(component.targetForm.controls.omitNulls.value).toBe('1');
      expect(component.targetForm.controls.removeTrailingBlanks.value).toBe('0');
    });

    it('should not set the default values for json specific fields if the vlaues have been set', () => {
      component.targetForm.controls.omitNulls.setValue('1');
      component.targetForm.controls.removeTrailingBlanks.setValue('0');
      component.onMessageFormatChange({ value: 'JSON' });
      expect(component.targetForm.controls.omitNulls.value).toBe('1');
      expect(component.targetForm.controls.removeTrailingBlanks.value).toBe('0');
    });

    it('should not set default values for json specific fields if the message format is CSV', () => {
      component.targetForm.controls.omitNulls.setValue(undefined);
      component.targetForm.controls.removeTrailingBlanks.setValue(undefined);
      component.onMessageFormatChange({ value: 'CSV' });
      expect(component.targetForm.controls.omitNulls.value).toBe(undefined);
      expect(component.targetForm.controls.removeTrailingBlanks.value).toBe(undefined);
    });
  });

  it('should get message formats & if feature flag is false', () => {
    spyOnProperty(component, 'isFeatureFlagEnabled', 'get').and.returnValue(false);
    spyOn(translocoService, 'selectTranslate').and.returnValue(of('Delimited'));
    component.ngOnInit();
    component.messageFormats$.subscribe((formats) => {
      expect(formats).toEqual([
        {
          label: `CSV (Delimited)`,
          value: 'CSV'
        },
        { label: 'JSON', value: 'JSON' }
      ]);
    });
  });

  it('should get message formats & if feature flag is true', () => {
    spyOnProperty(component, 'isFeatureFlagEnabled', 'get').and.returnValue(true);
    spyOn(translocoService, 'selectTranslate').and.returnValue(of('Delimited'));
    component.ngOnInit();

    component.messageFormats$.subscribe((formats) => {
      expect(formats).toEqual([
        { label: 'Avro', value: 'AVRO' },
        {
          label: `CSV (Delimited)`,
          value: 'CSV'
        },
        { label: 'JSON', value: 'JSON' }
      ]);
    });
  });

  it('should update image options depending on the message format', () => {
    spyOn(translocoService, 'selectTranslateObject').and.returnValue(of([]));
    component.messageFormats$.subscribe((formats) => {
      expect(component.targetForm.controls.imagesToInclude.value).toBe('AFTER_ONLY');

      /* commented out as the test asserts that the following shoudl be 0 and not 'BOTH'... need to investigate */

      //component.targetForm.controls.messageFormat.setValue('JSON');
      //expect(component.targetForm.controls.imagesToInclude.value).toBe('BOTH');
    });
  });

  it('should transform translation keys to dropdown options', () => {
    spyOn(translocoService, 'selectTranslateObject').and.returnValue(of([{ key: 'value' }]));
    component.ngOnInit();
    component.acknowledgementOptions$.subscribe((b: any) => {
      expect(b[0].label.key).toBe('value');
    });
  });

  it('should transform translation keys to dropdown options', () => {
    spyOn(translocoService, 'selectTranslateObject').and.returnValue(of([{ key: 'value' }]));
    component.ngOnInit();
    component.acknowledgementOptions$.subscribe((b: any) => {
      expect(b[0].label.key).toBe('value');
    });
  });

  describe('schema registry', () => {
    it('should get connections filtered to schema registries', (done) => {
      component.getSchemaRegistryDataConnections();

      component.schemaRegistries$.subscribe((result) => {
        expect(connectionsService.getAll).toHaveBeenCalled();
        expect(result.length).toBe(2);
        expect(result[0].label).toBe(mockConnections[0].name);
        expect(result[1].label).toBe(mockConnections[2].name);
        done();
      });
    });

    it('selects the correct schema connection', (done) => {
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      component.ngOnInit();
      component.getSchemaRegistryDataConnections(mockConnections[2]);

      component.schemaRegistries$.subscribe((result) => {
        expect(component.targetForm.get('schemaRegistries').value).toBe(mockConnections[2].id);
        done();
      });
    });

    it('should open new data connection on add', () => {
      component.addSchemaRegistryConnection();
      expect(component.isConnectionSidebarVisible).toBe(true);
    });
  });
});
