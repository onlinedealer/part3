import { Injectable, LOCALE_ID, Inject } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from "@angular/common/http";
import { Observable } from "rxjs";
import { InterceptorFilterService } from "./interceptor-filter.service";

@Injectable()
export class AcceptLanguageInterceptorService implements HttpInterceptor {
    constructor(@Inject(LOCALE_ID) private localeId: string, private filterService: InterceptorFilterService) {}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (this.filterService.isRequestFiltered(req)) {
            return next.handle(req);
        }
        const newHeaders = req.headers.set("Accept-Language", this.localeId);
        const newRequest = req.clone({ headers: newHeaders });
        return next.handle(newRequest);
    }
}
