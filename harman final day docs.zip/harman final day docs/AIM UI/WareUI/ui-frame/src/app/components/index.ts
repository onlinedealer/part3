import { LogoComponent } from "./logo/logo.component";
import { SidenavComponent } from "./sidenav/sidenav.component";
import { TimeoutDialogComponent } from "./timeout-dialog/timeout-dialog.component";

export const components: any[] = [LogoComponent, SidenavComponent, TimeoutDialogComponent];
