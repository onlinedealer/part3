import { Component, HostListener, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ErrorMessagesService } from '@precisely/prism-ng/cloud';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { AppInitializerService } from './app-initializer.service';
/**
 * Application root
 */
@Component({
  selector: 'p-connect-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  constructor(
    private readonly launchDarklyService: LaunchDarklyService,
    private readonly appInitializerService: AppInitializerService,
    private readonly router: Router,
    public readonly errorMessagesService: ErrorMessagesService
  ) {}

  ngOnInit(): void {
    console.debug('AppComponent.ngOnInit');
    if (!this.appInitializerService.isAppInitialized) {
      this.router.navigate(['data-integration/error']);
    }
  }

  // Log out LaunchDarkly client.
  @HostListener('window:beforeunload')
  closeLaunchDarkly(): void {
    this.launchDarklyService.dispose();
  }
}
