import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Spies } from 'discovery-test';
import { TextPatternComponent } from './text-pattern.component';
import { TreePath } from '../../tree-path.model';

describe('TextPatternComponent', () => {
  let component: TextPatternComponent;

  beforeEach(() => {
    Spies.init();
    component = new TextPatternComponent(Spies.TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with TextPatternStatistics', () => {
    component.defaultSort = 'count';
    component.statistics = {
      type: 'TextPatternStatistics',
      groups: [
        {
          groupPattern: 'Aa{1,9}',
          groupRegex: '[A-Z][a-z]{1,9}',
          patterns: {
            Aaaa: {
              '[A-Z][a-z]{3}': 112
            },
            Aaaaaa: {
              '[A-Z][a-z]{5}': 297
            },
            Aaa: {
              '[A-Z][a-z]{2}': 42
            },
            Aaaaa: {
              '[A-Z][a-z]{4}': 211
            },
            Aaaaaaaaa: {
              '[A-Z][a-z]{8}': 45
            },
            Aaaaaaa: {
              '[A-Z][a-z]{6}': 174
            },
            Aa: {
              '[A-Z][a-z]': 1
            },
            Aaaaaaaaaa: {
              '[A-Z][a-z]{9}': 13
            },
            Aaaaaaaa: {
              '[A-Z][a-z]{7}': 102
            }
          }
        },
        {
          groupPattern: 'Aa{1,3}-a{4,5}',
          groupRegex: '[A-Z][a-z]{1,3}-[a-z]{4,5}',
          patterns: {
            'Aa-aaaa': {
              '[A-Z][a-z][-][a-z]{4}': 1
            },
            'Aaaa-aaaaa': {
              '[A-Z][a-z]{3}[-][a-z]{5}': 1
            }
          }
        },
        {
          groupPattern: 'Aa a{5}',
          groupRegex: '[A-Z][a-z]\\s[a-z]{5}',
          patterns: {
            'Aa aaaaa': {
              '[A-Z][a-z]\\s[a-z]{5}': 1
            }
          }
        }
      ]
    } as any;
    component.treePath = new TreePath();
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.tableValues.length).toEqual(3);
    expect(component.tableValues[0].data.count).toEqual(997);
    expect(component.tableValues[0].data.percentage).toBeGreaterThan(95);
    expect(component.tableValues[0].children.length).toEqual(9);
    expect(component.cols.length).toEqual(5);
    expect(component.cols[1].field).toMatch('pattern');
    expect(component.cols[2].field).toMatch('regex');
  });
});
