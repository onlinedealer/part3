import { Action, createReducer, on } from "@ngrx/store";
import { EnvironmentIndicatorActions } from "../actions";
import { EnvironmentIndicator } from "../../models/environment-indicator.model";

export interface EnvironmentIndicatorState {
    entities?: EnvironmentIndicator;
}

export const initialState: EnvironmentIndicatorState = {
    entities: undefined
};

const environmentIndicatorReducer = createReducer(
    initialState,
    on(EnvironmentIndicatorActions.LoadEnvironmentIndicatorSuccess, (state, payload: any) => {
        return {
            ...state,
            entities: payload.response
        };
    })
);

export function reducer(state: EnvironmentIndicatorState | undefined, action: Action): EnvironmentIndicatorState {
    return environmentIndicatorReducer(state, action);
}
