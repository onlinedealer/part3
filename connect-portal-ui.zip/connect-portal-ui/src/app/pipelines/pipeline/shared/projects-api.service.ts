import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { environment } from 'src/environments/environment';
import { BaseConnectApiService } from '../../../core/base-connect-api.service';
import { DebugResponse } from './debug-response';
import { Project } from './project';
import { ProjectCommitResponse } from './project-commit-response';

@Injectable({
  providedIn: 'root'
})
export class ProjectsApiService extends BaseConnectApiService<Project> {
  /**
   * Tempoary flag used to determine if the incremental commit feature is enabled
   */
  isIncrementalCommitFeatureEnabled = false;

  constructor(protected httpClient: HttpClient, private readonly featureFlagService: FeatureFlagService) {
    super(httpClient, 'projects');
  }

  getDefaultProject(): Observable<Project> {
    return this.getFirst();
  }

  commit(projectId: string, forceCommit?: boolean, commitType?: string): Observable<ProjectCommitResponse> {
    this.isIncrementalCommitFeatureEnabled = this.featureFlagService.isFeatureEnabled('CDCIncrementalCommitTemp20220822');
    let url = '';
    if (this.isIncrementalCommitFeatureEnabled) {
      url = forceCommit
        ? `${this.serviceURL}/${projectId}/commit?forced=true`
        : `${this.serviceURL}/${projectId}/commit?commitType=${commitType}`;
    } else {
      url = forceCommit ? `${this.serviceURL}/${projectId}/commit?forced=true` : `${this.serviceURL}/${projectId}/commit`;
    }

    return this.httpClient.put(url, null).pipe(
      map((response: any) => {
        return {
          isCommited: response.committed,
          validationResponse: !response.projectValidation
            ? {}
            : {
                error: response.projectValidation.error,
                fatal: response.projectValidation.fatal,
                incomplete: response.projectValidation.incomplete,
                message: response.projectValidation.message,
                severityLevel: response.projectValidation.severityLevel,
                total: response.projectValidation.total,
                warning: response.projectValidation.warning
              }
        } as ProjectCommitResponse;
      })
    );
  }

  /**
   * Validates a project configuration
   * @param projectId The project id
   */
  async validate(projectId: string): Promise<any> {
    console.log(`Validating project: ${projectId}`);
    return this.httpClient.put(`${this.serviceURL}/${projectId}/validate`, null).toPromise();
  }

  /**
   * Gets the status of the project after a commit or validate asyn request
   * @param projectId The project id
   */
  async status(projectId: string): Promise<any> {
    console.log(`Getting project status: ${projectId}`);
    return this.httpClient.get(`${this.serviceURL}/${projectId}/status`).toPromise();
  }

  debugProject(projectId: string, setting: string): Observable<DebugResponse> {
    const url = `${this.serviceURL}/${projectId}/debug?setting=${setting}`;
    return this.httpClient.put(url, null);
  }

  /**
   * API to debug single server provided: https://jira.syncsort.com/browse/DMX-34327
   * However is not available at the moment. Comment will be removed once available.
   */
  debugSingleServer(projectId: string, setting: string, runtimeServerName: string): Observable<DebugResponse> {
    const url = `${this.serviceURL}/${projectId}/debug?setting=${setting}&host_label=${runtimeServerName}`;
    return this.httpClient.put(url, null);
  }

  /**
   * Response currently does not contain information on latest logged information, but only whether SQL information has
   * been logged or not. API currently being updated to give correct response. Comment will be removed once resolved.
   */
  getLatestLoggedInformation(projectId: string): Observable<DebugResponse> {
    const url = `${this.serviceURL}/${projectId}/debug`;
    return this.httpClient.put(url, null);
  }

  downloadJcl(projectId: string, headers?: HttpHeaders): Observable<any> {
    return this.httpClient.get(`${this.serviceURL}/${projectId}/jcl`, { headers, observe: 'response', responseType: 'arraybuffer' });
  }

  /**
   * Gets the selected projects and exports them
   * @param projectsId The projects id / projectName The name for file / userNames boolean that will determine if username details are included on file.
   */
  exportProject(projectsId: string, projectName: string, userNames: boolean, headers?: HttpHeaders): Observable<any> {
    return this.httpClient.get(`${this.serviceURL}/exportRP?ids=${projectsId}&filename=${projectName}&exportUsernames=${userNames}`, {
      headers,
      observe: 'response',
      responseType: 'arraybuffer'
    });
  }
  /**
   * Gets all projects and exports them
   * @param projectName The name for file / userNames boolean that will determine if username details are included on file.
   */
  exportAllProjects(projectName: string, userNames: boolean, headers?: HttpHeaders): Observable<any> {
    return this.httpClient.get(`${this.serviceURL}/exportRP/all?filename=${projectName}&exportUsernames=${userNames}`, {
      headers,
      observe: 'response',
      responseType: 'arraybuffer'
    });
  }

  /**
   * Starts Projects
   * @param The projects id
   */
  start(projectIds: string): Observable<any> {
    const apiEndpoint = `${environment.connectApiBaseURL}/cdc/monitoring/${projectIds}/servers/startall`;
    const body = {};
    return this.httpClient.put(apiEndpoint, body);
  }
  /**
   * Stops Projects
   * @param The projects id
   */
  stop(projectIds: string): Observable<any> {
    const apiEndpoint = `${environment.connectApiBaseURL}/cdc/monitoring/${projectIds}/servers/stopall`;
    const body = {};
    return this.httpClient.put(apiEndpoint, body);
  }
}
