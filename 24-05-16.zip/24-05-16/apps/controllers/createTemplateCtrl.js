(function() {
    'use strict';

    fileuploader.controller("createTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', createTemplateCtrl]);

    function createTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.uploadpreview = "apps/images/income.jpg";
        $scope.rows = [];
        
        $scope.onClick = function(event){
            var x = event.x;
            var y = event.y;
            var offsetX = event.offsetX;
            var offsetY = event.offsetY;
            console.log(offsetX, offsetY);
        };

        $scope.addRow = function(){     
            $scope.companies.push({  });
            $scope.name='';
            $scope.employees='';
            $scope.headoffice='';
        };

    }

    
})();