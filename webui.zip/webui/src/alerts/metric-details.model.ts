export class MetricDetailsModel {
  currentMetric: string;
  comparisonMetric: string;
  alertLevel: string;
  percentageChange?: number;
  alertAgainst?: string;
  probability?: number;
  sampleKey?: string;
  isNew?: boolean;
  alertReason?: string;
  isSampled?: boolean;
}
