import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import {BehaviorSubject} from 'rxjs/BehaviorSubject';





@Injectable()
export class InterceptorEmitter {

  private _counter = new BehaviorSubject<number>(0);
  counter$ = this._counter.asObservable();
  setCounterValue(number) {
    this._counter.next(number);
  }
  constructor() {
  }
}
