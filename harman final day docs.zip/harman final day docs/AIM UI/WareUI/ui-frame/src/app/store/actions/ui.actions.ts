import { createAction, props } from "@ngrx/store";

export const WindowInitialized = createAction(
    "[UI] Window Initialized",
    props<{
        windowWidth: number;
        windowHeight: number;
    }>()
);

export const WindowResized = createAction(
    "[UI] Window Resized",
    props<{
        windowWidth: number;
        windowHeight: number;
    }>()
);

export const FeatureModuleInitialized = createAction(
    "[UI] Feature Module Initialized",
    props<{
        title: string;
    }>()
);
