import { Component, OnInit, Input } from '@angular/core';
import { UtilityService } from '../../services/utility.service';
import { CouponHelperService } from '../../services/coupon-helper.service';

@Component({
  selector: 'app-all-deals',
  templateUrl: './all-deals.component.html',
  styleUrls: ['./all-deals.component.scss']
})
export class AllDealsComponent implements OnInit {
  @Input() couponList: any;

  allCoupons: any = [];
  serviceUrls:Object;
  subscriber:any;
  constructor(public utilityService: UtilityService, private chs:CouponHelperService) {
  }

  ngOnInit() {
    this.carepassCouponLists();
    this.extrabucksCouponLists();
    this.lockedCouponLists();
    this.pebCouponLists()
    this.basedOnPurchaseCoupons();
    this.mfrCouponLists();
    this.displayPHRLockedCoupons();
    this.displayBeautyClubCoupons();
  }

  ngOnChanges() {
  }

  /**
   * Find carepass coupons from the cpns array and store it in different array 
   */
  carepassCouponLists(){
    if (this.couponList.hasOwnProperty('cpns')) {
      this.allCoupons['carepassCoupons'] = [];
      for (let i = 0; i < this.couponList.cpns.length; i++) {
        if (this.couponList.cpns[i].mktgPrgCd === 'C' && this.couponList.cpns[i].cmpgnTypeCd === 'E') {
          this.couponList.cpns[i].cpnFmtCd = 'CE';
          this.chs.isCouponOnCard(this.couponList.cpns[i]);
          this.couponList.cpns[i]['couponIndex'] = this.allCoupons['carepassCoupons'].length + 1 ;
          if(this.chs.isCouponViewable(this.couponList.cpns[i])){
           this.allCoupons['carepassCoupons'].push(this.couponList.cpns[i]);
          }
        } 
        if (this.couponList.cpns[i].mktgPrgCd === 'C' && this.couponList.cpns[i].cmpgnTypeCd === 'P') {
          this.couponList.cpns[i].cpnFmtCd = 'CP';
          this.chs.isCouponOnCard(this.couponList.cpns[i]);
          this.couponList.cpns[i]['couponIndex'] = this.allCoupons['carepassCoupons'].length + 1 ;
          if(this.chs.isCouponViewable(this.couponList.cpns[i])){
            this.allCoupons['carepassCoupons'].push(this.couponList.cpns[i]);
          }
        }
      };
    }
  }

  /**
   * Find extrabucks coupons from the cpns array and store it in different array 
   */
  extrabucksCouponLists(){
    if (this.couponList.hasOwnProperty('cpns')) {
      this.allCoupons['extrabucksCoupons'] = [];
      for (var i = 0; i < this.couponList.cpns.length; i++) {
        if (this.couponList.cpns[i].cmpgnTypeCd === 'E' || this.couponList.cpns[i].cmpgnTypeCd === 'I' ) {
          this.chs.isCouponOnCard(this.couponList.cpns[i]);
          this.couponList.cpns[i]['couponIndex'] = this.allCoupons['extrabucksCoupons'].length + 1 ;
          if(this.chs.isCouponViewable(this.couponList.cpns[i])){
              this.allCoupons['extrabucksCoupons'].push(this.couponList.cpns[i]);
          }
          
        }
      }
    }
    console.log(this.allCoupons['extrabucksCoupons']);
  }

  /**
   * Get locked coupons from pts array, pebAvailPool array and store it in different array 
   */
  lockedCouponLists(){
     if (this.couponList.hasOwnProperty('pts')){
        this.allCoupons['lockedCoupons']=[];
        for(let i=0; i < this.couponList.pts.length; i++){
      if(this.couponList.pts[i].ptsQty !== '0' && this.couponList.pts[i].cmpgnTypeCd !== 'E' && this.couponList.pts[i].cmpgnSubtypeCd !== 'T' && this.couponList.pts[i].mktgPrgCd == ''){
      this.couponList.pts[i]['couponIndex'] = this.allCoupons['lockedCoupons'].length + 1;
      this.allCoupons['lockedCoupons'].push(this.couponList.pts[i]);
      }
     }
     }
     //console.log( this.allCoupons['lockedCoupons']);
    //todo - need to implement the logic here to get coupon data from pebAvailPool array
  }

  pebCouponLists(){
     if (this.couponList.hasOwnProperty('pts') || this.couponList.hasOwnProperty('pebAvailPool')) { 
       this.allCoupons['pebCoupons'] = [];
        for(let i=0; i < this.couponList.pebAvailPool.length; i++){       
       this.couponList.pebAvailPool[i]['couponIndex'] = this.allCoupons['pebCoupons'].length + 1
        this.allCoupons['pebCoupons'].push(this.couponList['pebAvailPool'][i]);  
        } 
        for(let i=0; i < this.couponList.pts.length; i++){
        if(this.couponList.pts[i].ptsQty == '0' && this.couponList.pts[i].cmpgnTypeCd == 'E' && this.couponList.pts[i].cmpgnSubtypeCd == 'T'){
          this.couponList.pts[i]['couponIndex'] = this.allCoupons['pebCoupons'].length + 1
          this.allCoupons['pebCoupons'].push(this.couponList.pts[i]);
        }
      }      
     
     }
    // console.log( this.allCoupons['pebCoupons']);
  }

  /**
   * Get all coupons from cpns array except carepass, extrabucks and actioned manufacturer coupons
   */
  
 basedOnPurchaseCoupons(){
     if (this.couponList.hasOwnProperty('cpns')) {
      this.allCoupons['basedOnPurchaseCoupons'] = [];
       for (var i = 0; i < this.couponList.cpns.length; i++) {
      if(!(this.couponList.cpns[i].cmpgnTypeCd === 'E' || this.couponList.cpns[i].cmpgnTypeCd === 'I'  ) && !(this.couponList.cpns[i].cpnFmtCd === 'M')  && !(this.couponList.cpns[i].mktgPrgCd === 'C' && this.couponList.cpns[i].cmpgnTypeCd === 'E') && !(this.couponList.cpns[i].mktgPrgCd === 'C' && this.couponList.cpns[i].cmpgnTypeCd === 'P')){
        this.chs.isCouponOnCard(this.couponList.cpns[i]);
         this.couponList.cpns[i]['couponIndex'] = this.allCoupons['basedOnPurchaseCoupons'].length + 1 ;
         if(this.chs.isCouponViewable(this.couponList.cpns[i])){
            this.allCoupons['basedOnPurchaseCoupons'].push(this.couponList.cpns[i]);
         }
        }
      }
     }
    //todo - need to implement the logic here to find the coupons from the cpns array excluding carpass, extrabucks and actioned manufacturer coupons
  }

  /**
   * Get unactioned manufacturer coupons from mfrCpnAvailPool array, actioned manufacturer coupons from cpns array and store it in different array
   */
  mfrCouponLists() {
    if (this.couponList.hasOwnProperty('cpns') || this.couponList.hasOwnProperty('mfrCpnAvailPool')) {
      this.allCoupons['manufacturerCoupons']=[];
      for (let i = 0; i < this.couponList.mfrCpnAvailPool.length; i++) {
       this.couponList.mfrCpnAvailPool[i]['couponIndex'] = this.allCoupons['manufacturerCoupons'].length + 1 ;
      this.allCoupons['manufacturerCoupons'].push(this.couponList['mfrCpnAvailPool'][i]);
      }
      for (let i = 0; i < this.couponList.cpns.length; i++) {
        if (this.couponList.cpns[i].cpnFmtCd === 'M') {
          this.couponList.cpns[i]['couponIndex'] = this.allCoupons['manufacturerCoupons'].length + 1 ;
          this.allCoupons['manufacturerCoupons'].push(this.couponList.cpns[i]);
        }
      }
    }
  }

/**
 * Display phr locked component if phrEnrolled = N
 */
  displayPHRLockedCoupons(){
    this.allCoupons['phrLockedCoupons'] = false;
    if (this.couponList.hasOwnProperty('prefs') && this.couponList['prefs']['phrEnrolled']  == 'N') {
        this.allCoupons['phrLockedCoupons'] = true;
    }
  }

/**
 * Display beauty club component if beautyClubEnrolled = N
 */
  displayBeautyClubCoupons(){
    this.allCoupons['beautyClubCoupons'] = false;
    this.allCoupons['beautyClubCouponData'] = {
      'type':''
    }
    if (this.couponList.hasOwnProperty('prefs') && this.couponList['prefs']['beautyClubEnrolled']  == 'N') {
        this.allCoupons['beautyClubCoupons'] = true;
        this.allCoupons['beautyClubCouponData']['type'] = 'not_joined';
    }
    else if(this.couponList.hasOwnProperty('prefs') && this.couponList['prefs']['beautyClubEnrolled']  == 'Y'){
      let flag = false;
      for (let i = 0; i < this.couponList.pts.length; i++) {
        if (this.couponList.pts[i].mktgPrgCd === 'B') {
           flag = true;
          break;
        }
      }
      if(!flag){
        this.allCoupons['beautyClubCoupons'] = true;
        this.allCoupons['beautyClubCouponData']['type'] = 'zero_state';
      }
        
    }
  }


  private _isCouponViewable(couponObj){
    let viewable = false;
    if(couponObj.viewableInd == 'Y' && (couponObj.appOnlyInd == 'N' ||(couponObj.appOnlyInd == 'Y' && couponObj.loadActlDt != ''))){
      viewable = true; 
    }
    return viewable;
  }
}
