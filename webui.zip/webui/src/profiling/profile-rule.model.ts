import { ProfileRuleInformationModel } from './profile-rule-information.model';
import { ProfileRuleOptionModel } from './profile-rule-option.model';

export class ProfileRuleModel {
  nodeType: string;
  displayName: string;
  description: string;
  ruleConfigurationOptions: ProfileRuleOptionModel[];
  children: ProfileRuleModel[];
  id: string;
  default: boolean;
  selected: boolean;
  uniqueKey: string;
}
