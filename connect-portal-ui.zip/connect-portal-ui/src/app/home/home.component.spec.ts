import { HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of, throwError } from 'rxjs';
import { Agent } from '../agents/shared/agent';
import { AgentsApiService } from '../agents/shared/agents-api.service';
import { getTranslocoModule } from '../core/transloco-testing.module';
import { Pipeline } from '../pipelines/pipeline/shared/pipeline';
import { PipelinesApiService } from '../pipelines/pipeline/shared/pipelines-api.service';
import { Server } from '../servers/shared/server';
import { ServersApiService } from '../servers/shared/servers-api.service';
import { ProgressIndicatorStateService } from '../shared/components/progress-indicator/progress-indicator-state.service';
import { HomeComponent } from './home.component';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { ProjectsApiService } from '../pipelines/pipeline/shared/projects-api.service';
import { Project } from '../pipelines/pipeline/shared/project';

describe('HomeComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;
  let pipelinesApiService: PipelinesApiService;
  let agentsService: AgentsApiService;
  let serversService: ServersApiService;
  let projectsApiService: ProjectsApiService;
  let mockFeatureFlagService: any;

  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['initiateProgressSteps', 'setActiveStepByRouterLink', 'setIsValid', 'setIsComplete', 'setActiveStepIndex']
  );

  beforeEach(async () => {
    mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

    TestBed.overrideComponent(HomeComponent, {
      set: {
        providers: [{ provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService }]
      }
    });

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, RouterTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [HomeComponent],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'home' } },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);

    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    serversService = TestBed.inject(ServersApiService);
    pipelinesApiService = TestBed.inject(PipelinesApiService);
    agentsService = TestBed.inject(AgentsApiService);
    projectsApiService = TestBed.inject(ProjectsApiService);

    spyOn(serversService, 'getAll').and.returnValue(of([]));
    spyOn(agentsService, 'getAll').and.returnValue(of([]));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of([]));
    spyOn(projectsApiService, 'getAll').and.returnValue(of([]));
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(false);

    spyOn(component, 'navigateTo').and.returnValue();
    fixture.detectChanges();
  });

  it('should navigate to pipelines if we have a pipeline configured', () => {
    spyOn(agentsService, 'getAll').and.returnValue(of([{} as Agent]));
    spyOn(serversService, 'getAll').and.returnValue(of([{} as Server]));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of([{} as Pipeline]));
    component.ngOnInit();
    expect(component.navigateTo).toHaveBeenCalledWith('pipelines');
  });

  it('should navigate to pipeline home page with we have an agent and a server', () => {
    spyOn(agentsService, 'getAll').and.returnValue(of([{} as Agent]));
    spyOn(serversService, 'getAll').and.returnValue(of([{} as Server]));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of([]));
    component.ngOnInit();
    expect(component.navigateTo).toHaveBeenCalledWith('home/pipeline');
  });

  it('should navigate to agents home page if we do not have an agent configured', () => {
    spyOn(agentsService, 'getAll').and.returnValue(of([]));
    spyOn(serversService, 'getAll').and.returnValue(of([]));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of([]));
    component.ngOnInit();
    expect(component.navigateTo).toHaveBeenCalledWith('home/agent');
  });

  it('should navigate to server home page if we have an agent but do not have an server configured', () => {
    spyOn(agentsService, 'getAll').and.returnValue(of([{} as Agent]));
    spyOn(serversService, 'getAll').and.returnValue(of([]));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of([]));
    component.ngOnInit();
    expect(component.navigateTo).toHaveBeenCalledWith('home/server');
  });

  it('should navigate to the agents page if there is an error returning the agents', () => {
    spyOn(agentsService, 'getAll').and.returnValue(throwError(new HttpErrorResponse({ error: 'error', status: 401 })));
    spyOn(serversService, 'getAll').and.returnValue(of([{} as Server]));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of([]));
    component.ngOnInit();
    expect(component.navigateTo).toHaveBeenCalledWith('home/agent');
  });

  it('should navigate to the servers page if there is an error returning the servers', () => {
    spyOn(agentsService, 'getAll').and.returnValue(of([{} as Agent]));
    spyOn(serversService, 'getAll').and.returnValue(throwError(new HttpErrorResponse({ error: 'error', status: 401 })));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(of([]));
    component.ngOnInit();
    expect(component.navigateTo).toHaveBeenCalledWith('home/server');
  });

  it('should navigate to the servers page if there is an error returning the servers', () => {
    spyOn(agentsService, 'getAll').and.returnValue(of([{} as Agent]));
    spyOn(serversService, 'getAll').and.returnValue(of([{} as Server]));
    spyOn(pipelinesApiService, 'getAll').and.returnValue(throwError(new HttpErrorResponse({ error: 'error', status: 401 })));
    component.ngOnInit();
    expect(component.navigateTo).toHaveBeenCalledWith('home/pipeline');
  });

  describe('project step, multiple projects feature flag', () => {
    beforeEach(() => {
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
      spyOn(agentsService, 'getAll').and.returnValue(of([{} as Agent]));
      spyOn(serversService, 'getAll').and.returnValue(of([{} as Server]));
      spyOn(pipelinesApiService, 'getAll').and.returnValue(of([]));
    });
    it('should navigate to the projects page if we have an agent and a server', () => {
      spyOn(projectsApiService, 'getAll').and.returnValue(of([]));
      component.ngOnInit();
      expect(component.navigateTo).toHaveBeenCalledWith('home/project');
    });

    it('should navigate to the projects page if there is an error returning the projects', () => {
      spyOn(projectsApiService, 'getAll').and.returnValue(throwError(new HttpErrorResponse({ error: 'error', status: 401 })));
      component.ngOnInit();
      expect(component.navigateTo).toHaveBeenCalledWith('home/project');
    });

    it('should navigate to the pipelines page if a project is created', () => {
      spyOn(projectsApiService, 'getAll').and.returnValue(of([{} as Project]));
      component.ngOnInit();
      expect(component.navigateTo).toHaveBeenCalledWith('home/pipeline');
    });
  });
});
