import { Component, Output, EventEmitter, OnInit, Input, OnDestroy } from "@angular/core";
import { FormGroup, FormControl } from "@angular/forms";
import { Subscription } from "rxjs";
import { getMeteringpointsXSFSearchFields } from "../../../containers/meteringpoints-search/meteringpoints-search-form-fields";
import { MeteringpointsSearchfieldMenuService } from "./searchfield-menu/menu.service";

@Component({
    selector: "landisgyr-meteringpoints-search-xsf-form",
    templateUrl: "./mp-search-xsf-form.component.html",
    styleUrls: ["./mp-search-xsf-form.component.scss"],
    providers: [MeteringpointsSearchfieldMenuService]
})
export class MeteringpointsSearchXSFFormComponent implements OnInit, OnDestroy {
    @Input()
    xsfSearchFormValues!: any;

    @Input()
    isSearching!: boolean;

    @Input()
    defaultSearchField!: string;

    @Output()
    defaultSearchFieldChanged = new EventEmitter<string>();

    @Output()
    xsfSearchFormSubmit = new EventEmitter<any>();

    defaultSearchFieldSelectSubscription!: Subscription;
    searchFieldMenuClosedSubscription!: Subscription;
    trimValuesSubscription!: Subscription;

    meteringpointsXSFSearchForm = new FormGroup({
        meteringPointName: new FormControl(""),
        gsrn: new FormControl(""),
        deviceNumber: new FormControl(""),
        streetName: new FormControl(""),
        zipCode: new FormControl(""),
        customerName: new FormControl(""),
        customerNumber: new FormControl(""),
        utilitySerialNumber: new FormControl("")
    });

    meteringpointsXSFSearchFields = getMeteringpointsXSFSearchFields();

    hoveredIndex = -1;
    openedIndex = -1;

    constructor(private meteringpointsSearchfieldMenuService: MeteringpointsSearchfieldMenuService) {
        this.trimValuesSubscription = this.meteringpointsXSFSearchForm.valueChanges.subscribe(values => {
            const trimmedValues: { [key: string]: string } = { ...this.meteringpointsXSFSearchForm.value };
            trimmedValues.meteringPointName = trimmedValues.meteringPointName.replace(/\s/g, "");
            trimmedValues.gsrn = trimmedValues.gsrn.replace(/\s/g, "");
            trimmedValues.deviceNumber = trimmedValues.deviceNumber.replace(/\s/g, "");
            trimmedValues.customerNumber = trimmedValues.customerNumber.replace(/\s/g, "");
            trimmedValues.utilitySerialNumber = trimmedValues.utilitySerialNumber.replace(/\s/g, "");
            this.meteringpointsXSFSearchForm.patchValue(trimmedValues, { emitEvent: false, onlySelf: true });
        });
    }

    ngOnInit() {
        this.meteringpointsXSFSearchForm.patchValue(this.xsfSearchFormValues);
    }

    mouseOverSearchField(index: number) {
        this.hoveredIndex = index;
    }

    mouseLeftSearchField(index: number) {
        if (this.hoveredIndex === index) {
            this.hoveredIndex = -1;
        }
    }

    onDefaultSearchFieldChanged(field: { key: string; value: string }) {
        this.defaultSearchFieldChanged.emit(field.key);
    }

    onSubmit() {
        const emitValues: { [key: string]: string } = { ...this.meteringpointsXSFSearchForm.value };
        emitValues.meteringPointName = emitValues.meteringPointName.replace(/\s/g, "");
        emitValues.streetName = emitValues.streetName.trim();
        emitValues.gsrn = emitValues.gsrn.replace(/\s/g, "");
        emitValues.deviceNumber = emitValues.deviceNumber.replace(/\s/g, "");
        emitValues.customerName = emitValues.customerName.trim();
        emitValues.customerNumber = emitValues.customerNumber.replace(/\s/g, "");
        emitValues.utilitySerialNumber = emitValues.utilitySerialNumber.replace(/\s/g, "");
        this.meteringpointsXSFSearchForm.patchValue(emitValues, { emitEvent: false, onlySelf: true });
        this.xsfSearchFormSubmit.emit(emitValues);
        return false;
    }

    private isFormEmpty() {
        const formControlValues = Object.entries(this.meteringpointsXSFSearchForm.value);
        return formControlValues.filter(([key, value]) => value && (value as string).trim().length > 0).length === 0;
    }

    isFormDisabled() {
        return this.isSearching || this.isFormEmpty();
    }

    openSearchfieldMenu(event: any, searchFieldKey: string, index: number) {
        this.openedIndex = index;

        const origin = event.target || event.srcElement || event.currentTarget;
        const menuRef = this.meteringpointsSearchfieldMenuService.show({ searchField: searchFieldKey }, origin);

        this.defaultSearchFieldSelectSubscription = menuRef.defaultSearchFieldSelect$.subscribe(searchField => {
            this.defaultSearchFieldChanged.emit(searchField);
        });

        this.searchFieldMenuClosedSubscription = menuRef.closed$.subscribe(() => {
            this.openedIndex = -1;
            this.unsubscribeSearchFieldMenuClosedSubscription();
            this.unsubscribeDefaultSearchFieldSubscription();
        });

        return false;
    }

    ngOnDestroy() {
        this.unssubscribeTrimValuesSubscription();
        this.unsubscribeDefaultSearchFieldSubscription();
        this.unsubscribeSearchFieldMenuClosedSubscription();
    }

    private unssubscribeTrimValuesSubscription() {
        if (this.trimValuesSubscription) {
            this.trimValuesSubscription.unsubscribe();
        }
    }
    private unsubscribeSearchFieldMenuClosedSubscription() {
        if (this.searchFieldMenuClosedSubscription) {
            this.searchFieldMenuClosedSubscription.unsubscribe();
        }
    }

    private unsubscribeDefaultSearchFieldSubscription() {
        if (this.defaultSearchFieldSelectSubscription) {
            this.defaultSearchFieldSelectSubscription.unsubscribe();
        }
    }

    clearInputField(fieldName: string) {
        this.meteringpointsXSFSearchForm.controls[fieldName].setValue("");
    }

    hasFieldValue(fieldName: string) {
        return this.meteringpointsXSFSearchForm.controls[fieldName].value.length > 0;
    }

    automationIdHelper(str: string, id: string) {
        return (str + id).toLocaleLowerCase();
    }
}
