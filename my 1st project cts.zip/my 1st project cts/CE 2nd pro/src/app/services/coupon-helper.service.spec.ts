import { TestBed, inject } from '@angular/core/testing';

import { CouponHelperService } from './coupon-helper.service';

describe('CouponHelperService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [CouponHelperService]
    });
  });

  it('should be created', inject([CouponHelperService], (service: CouponHelperService) => {
    expect(service).toBeTruthy();
  }));
});
