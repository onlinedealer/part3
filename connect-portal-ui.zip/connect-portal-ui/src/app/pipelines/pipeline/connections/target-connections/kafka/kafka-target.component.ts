import { Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ControlContainer, FormGroup } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FeatureFlagService } from '../../../../../shared/services/feature-flag.service';

@Component({
  selector: 'p-connect-kafka-target',
  templateUrl: './kafka-target.component.html'
})
export class KafkaTargetComponent implements OnInit, OnDestroy {
  @Input() sourceConnectionType: string;

  kafkaForm: FormGroup;
  private unsubscribeSignal$ = new Subject<void>();
  showTableOptionPrefix = true;
  isFeatureEnabled;
  constructor(private readonly controlContainer: ControlContainer, private readonly featureFlagService: FeatureFlagService) {}
  messageFormat = 'targetOptions.messageFormat';
  isRetrievingKafkaTopics = false;

  ngOnInit(): void {
    this.createForm();
    this.isFeatureEnabled = this.isFeatureFlagEnabled;
  }

  get isFeatureFlagEnabled() {
    return this.featureFlagService.isFeatureEnabled('CDCTableMappingTemp20220217');
  }

  ngOnDestroy() {
    this.unsubscribeSignal$.next();
    this.unsubscribeSignal$.complete();
  }

  get targetConnectionParameters() {
    let parameters: { key: string; value: string }[] = [];

    parameters = parameters.concat(this.targetOptionsParameters);
    parameters = parameters.concat(this.optionsParameters);
    parameters = parameters.concat(this.largeObjectsParameters);

    parameters.forEach((parameter) => {
      parameter.value = this.returnFormValue(parameter.value);
    });

    return parameters;
  }

  set targetConnectionParameters(params) {
    this.targetOptionsParameters = params;
    this.optionsParameters = params;
    this.largeObjectsParameters = params;
  }

  get targetConnectionMetadata() {
    return this.targetRowMetadata;
  }

  set targetConnectionMetadata(params) {
    this.targetRowMetadata = params;
  }

  private get targetOptionsParameters(): { key: string; value: string }[] {
    const keys: { key: string; value: string }[] = [
      { key: 'ACKNOWLEDGMENT', value: 'targetOptions.acknowledgement' },
      { key: 'CLIENT_ID', value: 'targetOptions.clientId' },
      { key: 'MESSAGE_FORMAT', value: 'targetOptions.messageFormat' },
      { key: 'PARTITION_MESSAGES_BY', value: 'targetOptions.messagePartitionBy' }
    ];

    if (this.returnFormValue(this.messageFormat) === 'CSV') {
      keys.push(
        { key: 'INCLUDE_IMAGE_OPTION', value: 'targetOptions.imagesToInclude' },
        { key: 'MESSAGE_FORMAT_QUOTE_CHARACTER', value: 'targetOptions.enclosingCharacter' },
        { key: 'MESSAGE_FORMAT_NULL_STRING', value: 'targetOptions.nullString' },
        { key: 'MESSAGE_FORMAT_FIELD_DELIMITER', value: 'targetOptions.fieldDelimiter' },
        { key: 'MESSAGE_FORMAT_RECORD_DELIMITER', value: 'targetOptions.recordDelimiter' },
        { key: 'PREFIX_MESSAGES_WITH_TABLENAME', value: 'targetOptions.prefixMessagesWithTableName' }
      );
    } else if (this.returnFormValue(this.messageFormat) === 'JSON') {
      keys.push(
        { key: 'INCLUDE_IMAGE_OPTION', value: 'targetOptions.imagesToInclude' },
        { key: 'OMIT_NULL', value: 'targetOptions.omitNulls' },
        { key: 'REMOVE_TRAILING_BLANKS', value: 'targetOptions.removeTrailingBlanks' }
      );
    } else if (this.returnFormValue(this.messageFormat) === 'AVRO') {
      keys.push({ key: 'SCHEMA_REGISTRY_ID', value: 'targetOptions.schemaRegistries' });
      keys.push({ key: 'INCLUDE_IMAGE_OPTION', value: 'targetOptions.imagesToInclude' });
    }

    return keys;
  }

  private set targetOptionsParameters(params) {
    const isSchemaRegistryFeatureEnabled = this.featureFlagService.isFeatureEnabled('CDCKafkaSchemaRegistryTemp20220628');
    // this timeout puts the execution at the end of the event stack
    // which ensures that we have the kafkaForm instance available
    setTimeout(() => {
      this.kafkaForm.controls.targetOptions.patchValue({
        acknowledgement: params.find((d) => d.key === 'ACKNOWLEDGMENT')?.value || 'WAIT_SINGLE_BROKER',
        clientId: params.find((d) => d.key === 'CLIENT_ID')?.value,
        messageFormat: params.find((d) => d.key === 'MESSAGE_FORMAT')?.value,
        recordDelimiter: params.find((d) => d.key === 'MESSAGE_FORMAT_RECORD_DELIMITER')?.value || '\\n',
        fieldDelimiter: params.find((d) => d.key === 'MESSAGE_FORMAT_FIELD_DELIMITER')?.value || ',',
        enclosingCharacter: params.find((d) => d.key === 'MESSAGE_FORMAT_QUOTE_CHARACTER')?.value || '"',
        nullString: params.find((d) => d.key === 'MESSAGE_FORMAT_NULL_STRING')?.value || '~',
        schemaRegistries: isSchemaRegistryFeatureEnabled ? params.find((d) => d.key === 'SCHEMA_REGISTRY_ID')?.value : undefined,
        imagesToInclude: params.find((d) => d.key === 'INCLUDE_IMAGE_OPTION')?.value,
        omitNulls: params.find((d) => d.key === 'OMIT_NULL')?.value,
        messagePartitionBy: params.find((d) => d.key === 'PARTITION_MESSAGES_BY')?.value,
        removeTrailingBlanks: params.find((d) => d.key === 'REMOVE_TRAILING_BLANKS')?.value,
        prefixMessagesWithTableName: params.find((d) => d.key === 'PREFIX_MESSAGES_WITH_TABLENAME')?.value
      });
    }, 500);
  }

  private get optionsParameters(): { key: string; value: string }[] {
    const keys: { key: string; value: string }[] = [
      { key: 'ENABLE_TRANSACTION_BUNDLING', value: 'options.enableBundling' },
      { key: 'TRANSACTION_BUNDLING_LIMIT', value: 'options.bundlingLimit' }
    ];

    return keys;
  }

  private set optionsParameters(params) {
    // this zero timeout puts the execution at the end of the event stack
    // which ensures that we have the kafkaForm instance available
    setTimeout(() => {
      this.kafkaForm.controls.options.patchValue({
        enableBundling: params.find((d) => d.key === 'ENABLE_TRANSACTION_BUNDLING')?.value === 'true' ? true : false,
        bundlingLimit: params.find((d) => d.key === 'TRANSACTION_BUNDLING_LIMIT')?.value
      });
    }, 0);
  }

  private get largeObjectsParameters(): { key: string; value: string }[] {
    const keys: { key: string; value: string }[] = [
      { key: 'LOB_SEND_BEFORE', value: 'largeObjects.alwaysSend' },
      { key: 'LOB_NO_CHANGES_MESSAGE', value: 'largeObjects.beforeImageValue' },
      { key: 'LOB_MAX_SIZE', value: 'largeObjects.maxLOB' },
      { key: 'LOB_MAX_SIZE_FORMAT', value: 'largeObjects.sizeFormat' }
    ];

    return keys;
  }

  private set largeObjectsParameters(params) {
    // this zero timeout puts the execution at the end of the event stack
    // which ensures that we have the kafkaForm instance available
    setTimeout(() => {
      this.kafkaForm.controls.largeObjects.patchValue({
        alwaysSend: params.find((d) => d.key === 'LOB_SEND_BEFORE')?.value === 'true' ? true : false,
        beforeImageValue: params.find((d) => d.key === 'LOB_NO_CHANGES_MESSAGE')?.value,
        maxLOB: params.find((d) => d.key === 'LOB_MAX_SIZE')?.value,
        sizeFormat: params.find((d) => d.key === 'LOB_MAX_SIZE_FORMAT')?.value
      });
    }, 0);
  }

  private get targetRowMetadata() {
    const parameters: { key: string; value: string }[] = [];

    this.kafkaForm?.get('rowMetaData.rowMetaDataOptions')?.value.forEach((metaDataOption) => {
      parameters.push({ key: metaDataOption, value: 'INCLUDE' });
    });

    return parameters;
  }

  private set targetRowMetadata(params) {
    const rowMetaOptions = params.filter((d) => d.value === 'INCLUDE');
    // this zero timeout puts the execution at the end of the event stack
    // which ensures that we have the kafkaForm instance available
    setTimeout(() => {
      this.kafkaForm.controls.rowMetaData.patchValue({
        rowMetaData: params.filter((d) => d.value === 'INCLUDE').length ? '' : 'NO_ROW_METADATA',
        rowMetaDataOptions: rowMetaOptions.map((d) => d.key)
      });
    }, 0);
  }

  private returnFormValue(formControlName) {
    return this.kafkaForm?.get(formControlName)?.value?.toString();
  }

  private readonly createForm = () => {
    this.kafkaForm = this.controlContainer.control as FormGroup;
    this.kafkaForm.addControl('targetOptions', new FormGroup({}));
    this.kafkaForm.addControl('rowMetaData', new FormGroup({}));
    this.kafkaForm.addControl('options', new FormGroup({}));
    this.kafkaForm.addControl('largeObjects', new FormGroup({}));

    this.kafkaForm.valueChanges.pipe(takeUntil(this.unsubscribeSignal$)).subscribe((formData) => {
      if (formData?.targetOptions?.messageFormat === 'JSON') {
        this.showTableOptionPrefix = false;
      } else {
        this.showTableOptionPrefix = true;
      }
    });
  };
}
