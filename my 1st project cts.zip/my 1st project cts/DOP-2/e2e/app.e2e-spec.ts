import { CVSClubPage } from './app.po';
import { browser, by, element, protractor } from 'protractor';

describe('cvs-club App', () => {
  let page: CVSClubPage;

  beforeEach(() => {
    page = new CVSClubPage();
    page.navigateToRegistration(); 
    browser.manage().deleteAllCookies();
    browser.driver.sleep(2000);
  });

 it('should load registration page and create account', () => {
    const currDate:Date = new Date();
    const currTime = currDate.getTime();
    const userEmail = currTime+'@cvs.com';
    browser.waitForAngular();
    expect(page.getParagraphTextByClass('lets-get-started')).toEqual('Let\'s get started!').then(function(result){
       expect(page.getParagraphTextByClass('secQuestionDropDwn')).toContain('What is my mother\'s maiden name?').then(function(res){
          browser.driver.sleep(3000);
          element(by.id('regFormFirstName')).sendKeys('Test');
          element(by.id('regFormLastName')).sendKeys('No EC card');
          element(by.id('regFormMobNum')).sendKeys('9346547891');
          element(by.id('regFormEmailAdr')).sendKeys(userEmail);
          browser.driver.sleep(3000);
          element(by.id('regFormPwd')).sendKeys('qwerty1234');
          element(by.id('regFormConfPwd')).sendKeys('qwerty1234');
          element(by.id('regFormSecAns')).sendKeys('e2etesting');
          element(by.id('regFormPwd')).clear();
          element(by.id('regFormPwd')).sendKeys('qwerty1234');
          element(by.id('regFormEcNumber')).sendKeys('4872000369052');
          page.getElementByClass('red-btn').click();
          browser.driver.sleep(3000);
       },() =>{
      console.log("Error loading security questions.");
    });
    });
  });

    it('should open lookup modal', () => {
    browser.waitForAngular();
    element.all(by.buttonText('Look up')).click();
    browser.waitForAngular(); 
    expect(element(by.css('.modal-header h2')).getText()).toContain('Let\'s find your ExtraCare').then(function (result){
      browser.driver.sleep(2000);
      element(by.id('ecLookUpFormEmail')).sendKeys('sample.test@gmail.com');
      element(by.id('ecLookUpFormLastName')).sendKeys('mitra');
      element(by.id('ecLookUpFormPhone')).sendKeys('9325874123');
      element(by.id('ecLookUpFormZip')).sendKeys('10015');
      element.all(by.buttonText('Continue')).click(); 
      browser.driver.sleep(3000);   
     });
  });

  it('should load registration page with EC lookup alone for loggedIn user', () => {
    browser.waitForAngular();
    (browser.manage() as any).addCookie({name:'SCC_COOKIE', value: '1234'});
    element.all(by.buttonText('Sign In')).click();
    browser.waitForAngular(); 
    element(by.css('.email .sign-in-inp')).sendKeys('sample.test@cvs.com');
    element(by.css('.password .sign-in-inp')).sendKeys('abcd1234');
    element(by.css('.signin-button button')).click();
        browser.waitForAngular();
    browser.driver.sleep(3000);
    expect(element(by.className('username')).getText()).toContain('Welcome').then(function (result){
      expect(element(by.css('.link-ec-logged h2')).getText()).toContain('Link your ExtraCare');
    },() =>{
      console.log("Error from service while logging in");
    });

  });

    it('should prepopulate extracare number for loggedIn and ecTied user', () => {
    browser.waitForAngular();
    (browser.manage() as any).addCookie({name:'SCC_COOKIE', value: '1234'});
    (browser.manage() as any).addCookie({name:'EC_TIED', value: 'true'});
    expect(element(by.className('username')).getText()).toContain('Welcome').then(function (result){
      element.all(by.buttonText('Sign Out')).click();
       browser.waitForAngular(); 
    page = new CVSClubPage();
    page.navigateToRegistration(); 
    browser.manage().deleteAllCookies();
    browser.waitForAngular(); 
    browser.driver.sleep(2000);
    },() => {
          element.all(by.buttonText('Sign In')).click();
    } );
    browser.waitForAngular(); 
    element(by.css('.email .sign-in-inp')).sendKeys('it1.test@cvs.com');
    element(by.css('.password .sign-in-inp')).sendKeys('welcome2011');
    element(by.css('.signin-button button')).click();
    browser.waitForAngular();
    browser.driver.sleep(3000);
    expect(element(by.className('username')).getText()).toContain('Welcome').then(function (result){
      browser.waitForAngular();
      expect(element(by.className('ec-card-number')).getText()).length > 0;
    },() =>{
      console.log("Error from service while logging in");
    });
    browser.pause();
  });
});
