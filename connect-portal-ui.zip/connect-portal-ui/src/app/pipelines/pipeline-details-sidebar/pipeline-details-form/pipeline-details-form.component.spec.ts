import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { ClearBacklogSidebarComponent } from '../../pipeline-summary-panel/shared/backlog-summary-details/clear-backlog-sidebar/clear-backlog-sidebar.component';
import { PipelineDetailsFormComponent } from './pipeline-details-form.component';

describe('PipelineDetailsFormComponent', () => {
  let component: PipelineDetailsFormComponent;
  let fixture: ComponentFixture<PipelineDetailsFormComponent>;
  @Component({
    selector: 'p-connect-clear-backlog-sidebar',
    template: '',
    providers: [
      {
        provide: ClearBacklogSidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    open() {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule],
      declarations: [PipelineDetailsFormComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipelineDetailsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit event to open the alerts modal', () => {
    spyOn(component.alertsButtonClickEvent, 'emit');
    component.alertsButtonClicked();
    expect(component.alertsButtonClickEvent.emit).toHaveBeenCalled();
  });

  it('should return true if the pipeline has monitoring values', () => {
    component.selectedPipeline = { replicationStatus: 'OK' };
    expect(component.hasMonitoringStatusValues()).toBe(true);
  });
});
