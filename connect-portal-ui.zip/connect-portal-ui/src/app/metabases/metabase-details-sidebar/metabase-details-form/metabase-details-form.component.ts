import { Component } from '@angular/core';
import { Metabase } from '../../shared/metabase.model';
import { BaseComponent } from '../../../core/base.component';
import { Connection } from '../../../connections/shared/connection';
import { DB2I_CONNECTION_PARAMETERS } from '../../../connections/connection-sidebar/connection-form/db2i-connection-form/db2i-form.component';
import { DB2I_METABASE_PARAMETERS } from '../../metabase-sidebar/metabase-form/db2i-metabase-form/db2i-metabase-form.component';
import { ORACLE_METABASE_PARAMETERS } from '../../metabase-sidebar/metabase-form/oracle-metabase-form/oracle-metabase-form.component';
import { SQLSERVER_METABASE_PARAMETERS } from '../../metabase-sidebar/metabase-form/sqlserver-metabase-form/sqlserver-metabase-form.component';
import { EMPTY } from 'rxjs';

@Component({
  selector: 'p-connect-metabase-details-form',
  templateUrl: './metabase-details-form.component.html'
})
export class MetabaseDetailsFormComponent extends BaseComponent {
  /**
   * Selected Metabase
   */
  selectedMetabase: Metabase;
  selectedMetabaseName: string;
  /**
   * Metabase version available for upgrade
   */
  upgradedMetabaseVersion: any;
  /**
   * The Metabase Details
   */
  metabaseDetails: { label: string; value: any }[][];

  /**
   * Displays the metabase details form
   * @param selectedMetabase The selected metabase
   */
  open(selectedMetabase: Metabase, metabaseName: string) {
    this.selectedMetabaseName = metabaseName;
    this.selectedMetabase = selectedMetabase;
    this.handleForm(selectedMetabase);
  }

  handleForm(item: any) {
    if (item != null) {
      this.setDefaultDetails();
      this.setConnectionDetails(this.selectedMetabase.dataConnection.connectionType);
    }
    return EMPTY;
  }

  /**
   * Gets the database server
   * @param dataConnection The data connection associated with the metabase
   */
  private getDatabaseServer(dataConnection: Connection) {
    let databaseServer = '';
    switch (dataConnection.connectionType) {
      case 'DB2I':
        databaseServer = dataConnection.database;
        break;
      case 'DB2':
      case 'ORACLE':
      case 'SQLSERVER':
        databaseServer = `${dataConnection.database}:${dataConnection.port}`;
        break;
    }
    return databaseServer;
  }

  /**
   * Sets the default details common to all connection types
   */
  private setDefaultDetails() {
    this.metabaseDetails = [
      [
        {
          label: 'METABASE_NAME',
          value: this.selectedMetabase.name
        }
      ],
      [
        {
          label: 'DATABASE_SERVER',
          value: this.getDatabaseServer(this.selectedMetabase.dataConnection)
        }
      ],
      [
        {
          label: 'DATA_CONNECTION',
          value: this.selectedMetabase.dataConnection.name
        },
        {
          label: 'CONNECTION_TYPE',
          value: `connections.CONNECTION_TYPES.${this.selectedMetabase.dataConnection.connectionType}`
        }
      ],
      [
        {
          label: 'REPLICATION_USER_ID',
          value: this.getParameterValue(this.selectedMetabase.parameters, 'REPLICATION_USER_ID')
        },
        {
          label: 'METABASE_VERSION',
          value: this.selectedMetabase.version
        }
      ]
    ];
  }

  /**
   * Sets additional details specific to the connection
   * @param connectionType The connection type
   */
  private setConnectionDetails(connectionType: string) {
    switch (connectionType) {
      case 'DB2I':
        this.setDB2IDetails();
        break;
      case 'ORACLE':
        this.setOracleDetails();
        break;
      case 'SQLSERVER':
        this.setSQLServerDetails();
        break;
    }
  }

  /**
   * Sets additional details for DB2 for IBM i connections
   */
  private setDB2IDetails() {
    // DB2 for IBM i uses Metabase library instead of Metabase name
    this.metabaseDetails[0][0].label = 'DB2I.METABASE_LIBRARY';

    if (this.getParameterValue(this.selectedMetabase.parameters, DB2I_METABASE_PARAMETERS.IN_SYSBAS) === 'false') {
      this.metabaseDetails.push([
        {
          label: 'DB2I.IASP_NAME',
          value: this.getParameterValue(this.selectedMetabase.dataConnection.parameters, DB2I_CONNECTION_PARAMETERS.DB2_I_IASP_NAME)
        },
        {
          label: 'DB2I.RDB_NAME',
          value: this.getParameterValue(this.selectedMetabase.dataConnection.parameters, DB2I_CONNECTION_PARAMETERS.DB2_I_RDB_NAME)
        }
      ]);
    }
  }

  /**
   * Sets additional details for Oracle connections
   */
  private setOracleDetails() {
    this.metabaseDetails.push(
      [
        {
          label: 'ORACLE.METABASE_TABLESPACE',
          value: this.getParameterValue(this.selectedMetabase.parameters, ORACLE_METABASE_PARAMETERS.TABLESPACE_NAME)
        },
        {
          label: 'ORACLE.DATA_FILE_NAME',
          value: this.getParameterValue(this.selectedMetabase.parameters, ORACLE_METABASE_PARAMETERS.TABLESPACE_FILE)
        }
      ],
      [
        {
          label: 'ORACLE.METABASE_TEMP_TABLESPACE',
          value: this.getParameterValue(this.selectedMetabase.parameters, ORACLE_METABASE_PARAMETERS.TEMP_TABLESPACE_NAME)
        },
        {
          label: 'ORACLE.TEMP_FILE_NAME',
          value: this.getParameterValue(this.selectedMetabase.parameters, ORACLE_METABASE_PARAMETERS.TEMP_TABLESPACE_FILE)
        }
      ]
    );
  }

  /**
   * Sets additional details for SQL Server connections
   */
  private setSQLServerDetails() {
    this.metabaseDetails.push(
      [
        {
          label: 'SQLSERVER.MAX_TRANSACTION_ROWS',
          value: this.getParameterValue(this.selectedMetabase.parameters, SQLSERVER_METABASE_PARAMETERS.MAX_NUM_ROWS)
        }
      ],
      [
        {
          label: 'SQLSERVER.DATA_LOGICAL_NAME',
          value: this.getParameterValue(this.selectedMetabase.parameters, SQLSERVER_METABASE_PARAMETERS.DATA_LOGICAL_NAME)
        },
        {
          label: 'SQLSERVER.LOG_LOGICAL_NAME',
          value: this.getParameterValue(this.selectedMetabase.parameters, SQLSERVER_METABASE_PARAMETERS.LOG_LOGICAL_NAME)
        }
      ]
    );
  }
}
