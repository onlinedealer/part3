import { TestBed, inject } from '@angular/core/testing';

import { VantivModelService } from './vantiv-model.service';

describe('VantivModelService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [VantivModelService]
    });
  });

  it('should be created', inject([VantivModelService], (service: VantivModelService) => {
    expect(service).toBeTruthy();
  }));
});
