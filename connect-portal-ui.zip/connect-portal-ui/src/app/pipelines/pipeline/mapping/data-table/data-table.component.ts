import { ChangeDetectorRef, Component, Input, OnInit, ViewChild, EventEmitter, Output, OnChanges } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { TableConfiguration } from '@shared/components/generic-table/generic-table';
import { Connection } from 'src/app/connections/shared/connection';
import { GenericTableComponent } from 'src/app/shared/components/generic-table/generic-table.component';
import { FeatureFlagService } from 'src/app/shared/services/feature-flag.service';
import { PipelineService } from '../../pipeline.service';
import { Pipeline, TableMapping } from '../../shared/pipeline';
import { ChangeColumnMappingSidebarComponent } from '../change-mapping/change-column-mapping/change-column-mapping-sidebar.component';
import { PipelineMappingService } from '../pipeline-mapping.service';
import { ColumnMappingSidebarComponent } from './column-mapping-sidebar/column-mapping-sidebar.component';
import { SidebarComponent } from '../../../../shared/components/sidebar/sidebar.component';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { DiscardColumnMappingSidebarComponent } from './discard-column-mapping-sidebar/discard-column-mapping-sidebar.component';
import { cloneDeep } from 'lodash';
import { MAPPING_CONST } from '../shared/mapping_constants';
import { ErrorMessagesService } from '@precisely/prism-ng/cloud';
@Component({
  selector: 'p-connect-data-table',
  templateUrl: './data-table.component.html',
  styleUrls: ['./data-table.component.scss']
})
export class DataTableComponent extends GenericTableComponent implements OnInit, OnChanges {
  @ViewChild(ChangeColumnMappingSidebarComponent) changeColumnMappingSidebar: ChangeColumnMappingSidebarComponent;
  @ViewChild(ColumnMappingSidebarComponent) columnMappingSidebar: ColumnMappingSidebarComponent;
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild('dt1') dataTable: any;
  @ViewChild(DiscardColumnMappingSidebarComponent) discardColumnMappingSidebar: DiscardColumnMappingSidebarComponent;
  @Input() targetColumnField: string[];
  @Input() topics: string[];
  @Input() subjects: string[];
  @Input() selectedData: any;
  @Input() checkedItems: any;
  @Input() patchPipeline: () => void;
  @Input() sourceDataConnection: Connection;
  @Input() targetDataConnection: Connection;
  @Input() tableConfiguration: TableConfiguration;
  @Input() tableMappingLoadingSpinner: any;
  @Input() data: any[];
  @Input() isSchemaRegistryThere;
  @Input() pipeline: Pipeline;
  @Output() emitSelectedSourceData = new EventEmitter<any>();
  @Output() enableRestToDefaultBtn = new EventEmitter<any>();
  @Output() duplicateRow = new EventEmitter<object>();
  @Output() tableMappingUpdateChange = new EventEmitter<any>();
  filteredTargets: any[];
  filteredSubjects: any[];
  spinnerForChangeColumnMapping: boolean;
  visible: boolean = true;
  topicTextInputError: boolean = false;

  rowMetaDataAllcheck = 1;
  tableMapping: TableMapping[];
  checkingData: any[];
  constructor(
    public readonly changeDetectorRef: ChangeDetectorRef,
    public readonly translocoService: TranslocoService,
    private readonly mappingService: PipelineMappingService,
    private readonly pipelineService: PipelineService,
    private readonly pipelineEntityService: PipelineEntityService,
    public readonly errorMessagesService: ErrorMessagesService
  ) {
    super(changeDetectorRef, translocoService);
  }

  ngOnInit(): void {
    this.pipelineService.mappingNextAction.subscribe(() => {
      this.updateTextBox();
    });
    this.tableMapping = this.pipelineEntityService.getPipeline().tableMapping;
  }
  ngOnChanges(): void {
    this.checkingData = cloneDeep(this.data);
  }

  updateTextBox() {
    this.data.forEach((ele) => {
      if (ele.topic.name === '' || ele.topic.name.match(MAPPING_CONST.REGEX_TARGET_NAME)) {
        ele.topic.class = 'danger';
      }
      if (ele.subject?.name === '') {
        ele.subject.class = 'danger';
      }
    });
  }

  filterTarget(event: { query: any }) {
    const input = event.query;
    // check for special characters
    this.data.forEach((tRow) => {
      if (tRow.topic.name.match(MAPPING_CONST.REGEX_TARGET_NAME)) {
        tRow.error = this.translocoService.translate('pipelines.STAGES.MAPPING.SPECIAL_CHAR_ERROR', {
          topic_name: tRow.topic.name
        });
        tRow.topicTextInputError = true;
      } else {
        tRow.error = '';
        tRow.topicTextInputError = false;
      }
    });

    this.filteredTargets = this.topics?.filter((c: string) => c.toLowerCase().includes(input.toLowerCase()));
  }

  onSelectTopic(row, event) {
    const topicFound = this.topics?.find((ele) => ele === event);
    this.setMappingIcon(event, row, 'select', topicFound, 'topic');
    if (this.isSchemaRegistryThere) {
      const subjectFound = this.subjects?.find((ele) => ele === row.subject?.name);
      this.setMappingIcon(row.subject?.name, row, 'select', subjectFound, 'subject');
    }
    this.patchPipeline();
  }

  onManualInputTopic(row, enteredText) {
    row.topic.class = null;
    if (enteredText.trim() !== '') {
      const topicFound = this.topics?.find((ele) => ele === enteredText);
      this.setMappingIcon(enteredText, row, 'keychange', topicFound, 'topic');
      if (this.isSchemaRegistryThere) {
        const subjectFound = this.subjects?.find((ele) => ele === row.subject?.name);
        this.setMappingIcon(row.subject?.name, row, 'keychange', subjectFound, 'subject');
      }
    } else {
      row.topic.mappingIcon = this.mappingService.getMappingIcon('NA', '').icon;
      row.topic.iconTooltip = this.mappingService.getMappingIcon('NA', 'Topic').tooltip;
      if (row.placeholder === 'pipelines.STAGES.MAPPING.TABLE.DUP_ROW_PLACEHOLDER.TEXT') {
        row.placeholder = 'pipelines.STAGES.MAPPING.TABLE.DUP_ROW_PLACEHOLDER.TEXT';
      } else {
        row.placeholder = row.table.trim();
      }
    }
    this.patchPipeline();
  }

  onPasteTopic(row, event: ClipboardEvent) {
    let pastedText = event.clipboardData.getData('text');
    this.onManualInputTopic(row, pastedText);
  }

  filterSubject(event: { query: any }) {
    const query = event.query;
    this.filteredSubjects = this.subjects?.filter((c: string) => c.toLowerCase().includes(query.toLowerCase()));
  }

  onSelectSubject(row, event) {
    const subjectFound = this.subjects?.find((ele) => ele === event);
    this.setMappingIcon(event, row, 'select', subjectFound, 'subject');
    this.patchPipeline();
  }

  onManualInputSubject(row, event) {
    if (event.target.value.trim() !== '') {
      const subjectFound = this.subjects?.find((ele) => ele === event.target.value);
      this.setMappingIcon(event.target.value, row, 'keychange', subjectFound, 'subject');
    } else {
      row.subject.mappingIcon = this.mappingService.getMappingIcon('NA').icon;
      row.subject.iconTooltip = this.mappingService.getMappingIcon('NA', 'Subject').tooltip;
    }
    this.patchPipeline();
  }

  setMappingIcon(event, row, type, targetFound, targetColumn) {
    const checkingColumn = targetColumn === 'topic' ? row.table.trim() : row.topic.name;
    if (event !== checkingColumn && type === 'keychange') {
      this.setIconOnManualInput(targetFound, row, targetColumn);
    } else if (event !== checkingColumn && type === 'select') {
      this.setIconOnSelectionInput(targetFound, row, targetColumn);
    } else {
      if (targetFound) {
        row[targetColumn].mappingIcon = '';
        row[targetColumn].iconTooltip = '';
      } else {
        row[targetColumn].mappingIcon = this.mappingService.getMappingIcon('NEW').icon;
        row[targetColumn].iconTooltip = this.mappingService.getMappingIcon('NEW', targetColumn).tooltip;
      }
      this.setIconifTopicExistsandNoSelection(targetFound, row, targetColumn);
    }
    row[targetColumn].class = null;
  }

  setIconOnSelectionInput(targetFound, row, targetColumn: string) {
    if (targetFound) {
      const tooltipInput1 = targetColumn === 'topic' ? 'Source' : 'Dataset';
      const tooltipInput2 = targetColumn === 'topic' ? 'target' : 'subject';
      row[targetColumn].mappingIcon = this.mappingService.getMappingIcon('MISMATCH').icon;
      row[targetColumn].iconTooltip = this.mappingService.getMappingIcon('MISMATCH', tooltipInput1, tooltipInput2).tooltip;
    } else if (row[targetColumn].name != '') {
      row[targetColumn].mappingIcon = this.mappingService.getMappingIcon('NEW').icon;
      row[targetColumn].iconTooltip = this.mappingService.getMappingIcon('NEW', targetColumn).tooltip;
    }
  }
  setIconOnManualInput(targetFound, row, targetColumn: string) {
    if (targetFound) {
      const tooltipInput1 = targetColumn === 'topic' ? 'Source' : 'Dataset';
      const tooltipInput2 = targetColumn === 'topic' ? 'target' : 'subject';
      row[targetColumn].mappingIcon = this.mappingService.getMappingIcon('MISMATCH').icon;
      row[targetColumn].iconTooltip = this.mappingService.getMappingIcon('MISMATCH', tooltipInput1, tooltipInput2).tooltip;
    } else if (row[targetColumn].name !== '') {
      row[targetColumn].mappingIcon = this.mappingService.getMappingIcon('NEW')?.icon;
      row[targetColumn].iconTooltip = this.mappingService.getMappingIcon('NEW', targetColumn)?.tooltip;
    }
  }
  setIconifTopicExistsandNoSelection(targetFound, row, targetColumn: string) {
    if (targetFound) {
      row[targetColumn].mappingIcon = '';
      row[targetColumn].iconTooltip = '';
    } else {
      row[targetColumn].mappingIcon = this.mappingService.getMappingIcon('NEW').icon;
      row[targetColumn].iconTooltip = this.mappingService.getMappingIcon('NEW', targetColumn).tooltip;
    }
  }

  open(row): void {
    this.columnMappingSidebar.open(row);
  }

  openDiscardWarningDialog(row): void {
    this.discardColumnMappingSidebar.open(row);
  }

  /*
    Discard custom column mappings with a warning dialog in the following scenarios:
    Kafka Schema Registry connection exists and subject was changed from:
      1.  Existing to existing
      2.  Non-existing to existing
  */
  isDiscardScenario(row): Boolean {
    let oldTablemapping = this.checkingData.find((mapping) => {
      if (mapping.id === row.id) return mapping;
    });

    if (
      row.hasCustomColMappings &&
      oldTablemapping.subject?.name != row.subject?.name &&
      (oldTablemapping.subject?.mappingIcon === 'ATTENTION' || oldTablemapping.subject?.mappingIcon === 'ATTENTION_BLUE') &&
      row.subject?.mappingIcon === 'ATTENTION_BLUE'
    ) {
      return true;
    }
    return false;
  }

  openChangeColumnMappingSideBar() {
    this.tableMapping = this.pipelineEntityService.getPipeline().tableMapping;
    this.spinnerForChangeColumnMapping = true;
    this.changeColumnMappingSidebar.tableMapping = this.tableMapping;
    this.saveTableMappings();
    this.mappingService?.getChangeColumnMappingDefaults(this.pipeline?.id)?.subscribe({
      next: (data) => {
        this.spinnerForChangeColumnMapping = false;
        const defaultsData = data;
        defaultsData?.cdcRowMetadatas?.forEach((element) => {
          if (this.rowMetaDataAllcheck === 1 && element.cdcRowMetadataType == 'INCLUDE') {
            element['isChecked'] = true;
          } else {
            element['isChecked'] = element.cdcRowMetadataType === 'INCLUDE';
          }
        });
        this.changeColumnMappingSidebar.open(
          this.isSchemaRegistryThere,
          defaultsData.cdcRowMetadatas,
          defaultsData.columnMappingType === 'ORDINAL' ? 'COLUMN_ORDER' : 'COLUMN_NAME'
        );
        this.rowMetaDataAllcheck++;
      },
      error: (errorResponse) => {
        this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
      }
    });
  }

  saveTableMappings() {
    this.spinnerForChangeColumnMapping = true;
    this.mappingService?.saveTableMapping(this.pipeline?.id, this.tableMapping)?.subscribe({
      next: () => {
        this.spinnerForChangeColumnMapping = false;
        this.checkingData = cloneDeep(this.data);
      },
      error: (error) => {
        this.sidebarComponent.parseHttpClientResponseMessage('error', error);
      }
    });
  }

  ngModelChange(row): void {
    if (row.topic.name === '') {
      row.isButtonEnabled = false;
    } else {
      row.isButtonEnabled = true;
    }
  }

  emitSelectedData() {
    this.emitSelectedSourceData.emit(this.checkedItems);
  }

  resetSelectedSourceData() {
    this.checkedItems = [];
  }

  resetDefaultChecked() {
    const enableRestToDefaultBoolean = this.mappingService.checkIfButtonDisabled(this.checkedItems);
    this.enableRestToDefaultBtn.emit(enableRestToDefaultBoolean);
  }

  dupRow(row, index) {
    const random = () => crypto.getRandomValues(new Uint32Array(1))[0] / 2 ** 32;
    const newRowData = Object.assign({}, row, {
      id: 'mapping_' + random().toString(36).substring(2, 8) + random().toString(36).substring(2, 8),
      placeholder: 'pipelines.STAGES.MAPPING.TABLE.DUP_ROW_PLACEHOLDER.TEXT',
      topic: {
        name: '',
        mappingIcon: this.mappingService.getMappingIcon('NA').icon,
        iconTooltip: this.mappingService.getMappingIcon('NA', 'Topic').tooltip
      },
      subject: {
        name: '',
        mappingIcon: this.mappingService.getMappingIcon('NA').icon,
        iconTooltip: this.mappingService.getMappingIcon('NA', 'Subject').tooltip
      }
    });
    newRowData.isDuplicate = true;
    this.data.splice(index + 1, 0, newRowData);
    this.visible = false;
    setTimeout(() => (this.visible = true), 0);
    this.patchPipeline();
  }

  removeRow(index: number) {
    this.data.splice(index, 1);
    this.visible = false;
    setTimeout(() => (this.visible = true), 0);
    this.patchPipeline();
  }

  filterColumn(event: { target: any }, column: string) {
    if (this.targetColumnField?.includes(column)) {
      this.dataTable.filter(event.target.value, column + '.' + 'name', 'contains');
    } else {
      this.dataTable.filter(event.target.value, column, 'contains');
    }
  }

  updatedTableMapping(event) {
    this.data.forEach((element) => {
      if (element.id === event.rowId) {
        element.hasCustomColMappings = event.hasCustomColMappings;
      }
    });
    this.tableMappingUpdateChange.emit(event);
    this.patchPipeline();
  }
  //To keep track of the data persisted in mongo
  updateCheckingData() {
    this.checkingData = cloneDeep(this.data);
  }
}
