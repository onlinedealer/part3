import { RuleProperties } from "json-rules-engine";
import { Metering } from "../metering.model";
import { ProfileDataWithEditProperties } from "../profiledata.model";

export const simpleChangeObjectArray = [{ index: 4, value: 2 }];

export const multipleChangeObjectArray = [
    { index: 2, value: 2 },
    { index: 3, value: 4 },
    { index: 4, value: 6 }
];

export const multipleChangeObjectArrayWithIndexGap = [
    { index: 2, value: 2 },
    { index: 3, value: 4 },
    { index: 6, value: 6 },
    { index: 7, value: 5 }
];

export const electricityMetering: Metering = {
    loadedFrom: 1562741778000,
    loadedUntil: 1567498012000,
    measuredUnit: {
        factor: 1,
        measuredUnitId: 9,
        name: "Wh"
    },
    measurementType: {
        baseUnitId: 9,
        commodity: "ELECTRICITY_SECONDARY_METERED",
        directionOfFlow: "TOTAL",
        kind: "ENERGY",
        measurementTypeId: 175,
        meteringMode: "CUMULATIVE",
        obisA: 1,
        obisB: 1,
        obisC: 15,
        obisD: 8,
        obisE: 0,
        obisF: 255,
        phase: "NONE",
        tou: "NONE"
    },
    meteringId: 2301,
    meteringMode: "CUMULATIVE",
    meteringPointId: 742,
    meteringType: "UNDEFINED",
    name: "Combined |+A|+|-A| energy 60",
    obis: "1-1:15.8.0*255",
    periodLength: 60,
    powerDimension: "Cb",
    timeZone: {
        javaTimeZone: "EET",
        name: "Eastern European Summer/Winter Time",
        oracleTimeZone: "EET",
        timeZoneId: 6
    },
    type: "profile",
    validFrom: 1562741778000,
    validUntil: 1567498012000
};

// All details not valid, measurementType.kind just changed for testing
export const temperatureMetering: Metering = {
    loadedFrom: 1562741778000,
    loadedUntil: 1567498012000,
    measuredUnit: {
        factor: 1,
        measuredUnitId: 9,
        name: "C"
    },
    measurementType: {
        baseUnitId: 9,
        commodity: "ELECTRICITY_SECONDARY_METERED",
        directionOfFlow: "TOTAL",
        kind: "TEMPERATURE",
        measurementTypeId: 175,
        meteringMode: "CUMULATIVE",
        obisA: 1,
        obisB: 1,
        obisC: 15,
        obisD: 8,
        obisE: 0,
        obisF: 255,
        phase: "NONE",
        tou: "NONE"
    },
    meteringId: 2301,
    meteringMode: "CUMULATIVE",
    meteringPointId: 742,
    meteringType: "UNDEFINED",
    name: "Temperature",
    obis: "1-1:15.8.0*255",
    periodLength: 60,
    powerDimension: "Cb",
    timeZone: {
        javaTimeZone: "EET",
        name: "Eastern European Summer/Winter Time",
        oracleTimeZone: "EET",
        timeZoneId: 6
    },
    type: "profile",
    validFrom: 1562741778000,
    validUntil: 1567498012000
};

// All details not valid, measurementType.kind just changed for testing
export const powerMetering: Metering = {
    loadedFrom: -30609799200000,
    loadedUntil: 1568883643000,
    measuredUnit: {
        factor: 1,
        measuredUnitId: 1,
        name: "W"
    },
    measurementType: {
        baseUnitId: 1,
        commodity: "NONE",
        directionOfFlow: "FORWARD",
        kind: "POWER",
        measurementTypeId: 28,
        meteringMode: "INSTANTANEOUS",
        obisA: 1,
        obisB: 1,
        obisC: 1,
        obisD: 7,
        obisE: 0,
        obisF: 255,
        phase: "NONE",
        tou: "NONE"
    },
    meteringId: 1822,
    meteringMode: "INSTANTANEOUS",
    meteringPointId: 66,
    name: "A+ power",
    obis: "1-1:1.7.0*255",
    powerDimension: "A+",
    type: "periodic",
    validFrom: 1562741778000,
    validUntil: 1567498012000
};

export const simpleProfileDataValidationRule: RuleProperties = {
    conditions: {
        any: [
            // Cumulative value not negative
            {
                fact: "profileValue",
                operator: "lessThan",
                value: 0,
                path: "$.editCumulativeValue"
            },
            // Value not negative
            {
                fact: "profileValue",
                operator: "lessThan",
                value: 0,
                path: "$.editValue"
            },
            // Value not greater than reference max value
            // Multiplier used to allow nine times bigger value than reference
            {
                fact: "profileValue",
                operator: "greaterThan",
                value: {
                    fact: "referenceValue",
                    params: {
                        multiplier: 9
                    }
                },
                path: "$.editValue"
            },
            // Value is continuous
            // Value is same as delta from current and previous cumulative value
            {
                fact: "profileValue",
                operator: "notEqual",
                value: {
                    fact: "continuityValue"
                },
                path: "$.editValue"
            }
        ]
    },
    event: {
        type: "Invalid profile data"
    }
};

export const defaultProfileDataValidationRule: RuleProperties = {
    conditions: {
        any: [
            // Energy
            {
                all: [
                    // Guard condition
                    {
                        fact: "metering",
                        operator: "equal",
                        value: "ENERGY",
                        path: "$.measurementType.kind",
                        // This enhances performance, other rules won't get run for this metering
                        // if priority is high
                        priority: 100,
                    },
                    // Value validation rules
                    {
                        any: [
                            // Cumulative value not negative
                            {
                                fact: "profileValue",
                                operator: "lessThan",
                                value: 0,
                                path: "$.editCumulativeValue"
                            },
                            // Value not negative
                            {
                                fact: "profileValue",
                                operator: "lessThan",
                                value: 0,
                                path: "$.editValue"
                            },
                            // Value less than reference max value
                            // Multiplier used to allow nine times bigger value than reference
                            {
                                fact: "profileValue",
                                operator: "greaterThan",
                                value: {
                                    fact: "referenceValue",
                                    params: {
                                        multiplier: 9,
                                    }
                                },
                                path: "$.editValue",
                            },
                            // Value is continuous
                            // Value is same as delta from current and previous cumulative value
                            {
                                fact: "profileValue",
                                operator: "notEqual",
                                value: {
                                    fact: "continuityValue",
                                },
                                path: "$.editValue",
                            },
                        ],
                    }
                ]
            },
            // Power
            {
                all: [
                    // Guard condition
                    {
                        fact: "metering",
                        operator: "equal",
                        value: "POWER",
                        path: "$.measurementType.kind",
                        priority: 100,
                    },
                    // Value validation rules
                    {
                        any: [
                            // Value not negative
                            {
                                fact: "profileValue",
                                operator: "lessThan",
                                value: 0,
                                path: "$.editValue"
                            },
                        ]
                    }
                ]
            },
            // Temperature
            {
                all: [
                    // Guard condition
                    {
                        fact: "metering",
                        operator: "equal",
                        value: "TEMPERATURE",
                        path: "$.measurementType.kind",
                        priority: 100,
                    },
                    // Value validation rules
                    {
                        any: [
                            // Value not less than -100
                            {
                                fact: "profileValue",
                                operator: "lessThan",
                                value: -100,
                                path: "$.editValue",
                            },
                            // Value not greater than 100
                            {
                                fact: "profileValue",
                                operator: "greaterThan",
                                value: 100,
                                path: "$.editValue",
                            }
                        ],
                    }
                ]
            },
        ]
    },
    event: {
        type: "Invalid profile data"
    }
};

export const baseArray = [
    {
        index: 0,
        editValue: 1,
        editCumulativeValue: 1,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        editValue: 1,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        editValue: 1,
        editCumulativeValue: 3,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 3,
        editValue: 1,
        editCumulativeValue: 4,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 4,
        editValue: 1,
        editCumulativeValue: 5,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 5,
        editValue: 1,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 6,
        editValue: 1,
        editCumulativeValue: 7,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 7,
        editValue: 1,
        editCumulativeValue: 8,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 8,
        editValue: 1,
        editCumulativeValue: 9,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];
export const resultValue = [
    {
        index: 0,
        editValue: 1,
        editCumulativeValue: 1,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        editValue: 1,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        editValue: 1,
        editCumulativeValue: 3,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 3,
        editValue: 1,
        editCumulativeValue: 4,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 4,
        editValue: 2,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 5,
        editValue: 1,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 6,
        editValue: 1,
        editCumulativeValue: 7,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 7,
        editValue: 1,
        editCumulativeValue: 8,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 8,
        editValue: 1,
        editCumulativeValue: 9,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const resultCumulative = [
    {
        index: 0,
        editValue: 1,
        editCumulativeValue: 1,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        editValue: 1,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        editValue: 1,
        editCumulativeValue: 3,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 3,
        editValue: 1,
        editCumulativeValue: 4,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 4,
        editValue: -2,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 5,
        editValue: 4,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 6,
        editValue: 1,
        editCumulativeValue: 7,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 7,
        editValue: 1,
        editCumulativeValue: 8,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 8,
        editValue: 1,
        editCumulativeValue: 9,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const resultMultipleValue = [
    {
        index: 0,
        editValue: 1,
        editCumulativeValue: 1,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        editValue: 1,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        editValue: 2,
        editCumulativeValue: 4,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 3,
        editValue: 4,
        editCumulativeValue: 8,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 4,
        editValue: 6,
        editCumulativeValue: 14,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 5,
        editValue: 1,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 6,
        editValue: 1,
        editCumulativeValue: 7,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 7,
        editValue: 1,
        editCumulativeValue: 8,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 8,
        editValue: 1,
        editCumulativeValue: 9,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const resultMultipleCumulative = [
    {
        index: 0,
        editValue: 1,
        editCumulativeValue: 1,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        editValue: 1,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        editValue: 0,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 3,
        editValue: 2,
        editCumulativeValue: 4,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 4,
        editValue: 2,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 5,
        editValue: 0,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 6,
        editValue: 1,
        editCumulativeValue: 7,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 7,
        editValue: 1,
        editCumulativeValue: 8,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 8,
        editValue: 1,
        editCumulativeValue: 9,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const resultMultipleValueGap = [
    {
        index: 0,
        editValue: 1,
        editCumulativeValue: 1,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        editValue: 1,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        editValue: 2,
        editCumulativeValue: 4,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 3,
        editValue: 4,
        editCumulativeValue: 8,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 4,
        editValue: 1,
        editCumulativeValue: 5,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 5,
        editValue: 1,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 6,
        editValue: 6,
        editCumulativeValue: 12,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 7,
        editValue: 5,
        editCumulativeValue: 17,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 8,
        editValue: 1,
        editCumulativeValue: 9,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const resultCumulativeGap = [
    {
        index: 0,
        editValue: 1,
        editCumulativeValue: 1,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        editValue: 1,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        editValue: 0,
        editCumulativeValue: 2,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 3,
        editValue: 2,
        editCumulativeValue: 4,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 4,
        editValue: 1,
        editCumulativeValue: 5,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 5,
        editValue: 1,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 6,
        editValue: 0,
        editCumulativeValue: 6,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 7,
        editValue: -1,
        editCumulativeValue: 5,
        manuallyEditedCumulativeValue: true,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 8,
        editValue: 4,
        editCumulativeValue: 9,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        valueSelected: false,
        cumulativeValueSelected: false,
        autoEditedValue: true,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const historyStateObject = {
    changeNumber: 0,
    changes: [
        {
            beforeChange: [
                {
                    index: 4,
                    editValue: 1,
                    editCumulativeValue: 5,
                    manuallyEditedCumulativeValue: false,
                    manuallyEditedValue: false,
                    discontinuityValue: false,
                    discontinuityCumulativeValue: false,
                    valueSelected: false,
                    cumulativeValueSelected: false,
                    autoEditedValue: false,
                    autoEditedCumulativeValue: false,
                    highValue: false,
                    highCumulativeValue: false,
                    lowValue: false,
                    lowCumulativeValue: false
                },
                {
                    index: 5,
                    editValue: 1,
                    editCumulativeValue: 6,
                    manuallyEditedCumulativeValue: false,
                    manuallyEditedValue: false,
                    discontinuityValue: false,
                    discontinuityCumulativeValue: false,
                    valueSelected: false,
                    cumulativeValueSelected: false,
                    autoEditedValue: false,
                    autoEditedCumulativeValue: false,
                    highValue: false,
                    highCumulativeValue: false,
                    lowValue: false,
                    lowCumulativeValue: false
                }
            ] as ProfileDataWithEditProperties[],
            afterChange: [
                {
                    index: 4,
                    editValue: 2,
                    editCumulativeValue: 6,
                    manuallyEditedCumulativeValue: false,
                    manuallyEditedValue: true,
                    discontinuityValue: false,
                    discontinuityCumulativeValue: false,
                    valueSelected: false,
                    cumulativeValueSelected: false,
                    autoEditedValue: false,
                    autoEditedCumulativeValue: true,
                    highValue: false,
                    highCumulativeValue: false,
                    lowValue: false,
                    lowCumulativeValue: false
                },
                {
                    index: 5,
                    editValue: 1,
                    editCumulativeValue: 6,
                    manuallyEditedCumulativeValue: false,
                    manuallyEditedValue: false,
                    discontinuityValue: false,
                    discontinuityCumulativeValue: false,
                    valueSelected: false,
                    cumulativeValueSelected: false,
                    autoEditedValue: false,
                    autoEditedCumulativeValue: false,
                    highValue: false,
                    highCumulativeValue: false,
                    lowValue: false,
                    lowCumulativeValue: false
                }
            ] as ProfileDataWithEditProperties[]
        }
    ]
};

export const afterAndBeforeEdit = {
    beforeChange: [
        {
            index: 1,
            editValue: 1,
            editCumulativeValue: 2,
            manuallyEditedCumulativeValue: false,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        },
        {
            index: 2,
            editValue: 0,
            editCumulativeValue: 2,
            manuallyEditedCumulativeValue: true,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        },
        {
            index: 3,
            editValue: 2,
            editCumulativeValue: 4,
            manuallyEditedCumulativeValue: true,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        },
        {
            index: 4,
            editValue: 2,
            editCumulativeValue: 6,
            manuallyEditedCumulativeValue: true,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        }
    ] as ProfileDataWithEditProperties[],
    afterChange: [
        {
            index: 1,
            editValue: 3,
            editCumulativeValue: 4,
            manuallyEditedCumulativeValue: true,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        },
        {
            index: 2,
            editValue: 1,
            editCumulativeValue: 5,
            manuallyEditedCumulativeValue: true,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        },
        {
            index: 3,
            editValue: 1,
            editCumulativeValue: 6,
            manuallyEditedCumulativeValue: true,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        },
        {
            index: 4,
            editValue: 0,
            editCumulativeValue: 6,
            manuallyEditedCumulativeValue: false,
            manuallyEditedValue: false,
            discontinuityValue: false,
            discontinuityCumulativeValue: false,
            valueSelected: false,
            cumulativeValueSelected: false
        }
    ] as ProfileDataWithEditProperties[]
};

export const timeSeriesToEdit = [
    {
        index: 0,
        originalIndex: 3,
        value: 1,
        cumulativeValue: 100,
        valueSelected: false,
        cumulativeValueSelected: false,
        editValue: undefined,
        editCumulativeValue: undefined,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        originalIndex: 4,
        value: 1,
        cumulativeValue: 101,
        valueSelected: true,
        cumulativeValueSelected: false,
        editValue: undefined,
        editCumulativeValue: undefined,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        originalIndex: 5,
        value: 1,
        cumulativeValue: 102,
        valueSelected: true,
        cumulativeValueSelected: false,
        editValue: undefined,
        editCumulativeValue: undefined,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const resultAddValueOperation = [
    {
        index: 0,
        originalIndex: 3,
        value: 1,
        cumulativeValue: 100,
        valueSelected: false,
        cumulativeValueSelected: false,
        editValue: undefined,
        editCumulativeValue: undefined,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        originalIndex: 4,
        value: 1,
        cumulativeValue: 101,
        valueSelected: true,
        cumulativeValueSelected: false,
        editValue: 3,
        editCumulativeValue: 103,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        originalIndex: 5,
        value: 1,
        cumulativeValue: 102,
        valueSelected: true,
        cumulativeValueSelected: false,
        editValue: 3,
        editCumulativeValue: 106,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];

export const resultMultiplyValueOperation = [
    {
        index: 0,
        originalIndex: 3,
        value: 1,
        cumulativeValue: 100,
        valueSelected: false,
        cumulativeValueSelected: false,
        editValue: undefined,
        editCumulativeValue: undefined,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: false,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: false,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 1,
        originalIndex: 4,
        value: 1,
        cumulativeValue: 101,
        valueSelected: true,
        cumulativeValueSelected: false,
        editValue: 3,
        editCumulativeValue: 103,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    },
    {
        index: 2,
        originalIndex: 5,
        value: 1,
        cumulativeValue: 102,
        valueSelected: true,
        cumulativeValueSelected: false,
        editValue: 3,
        editCumulativeValue: 106,
        manuallyEditedCumulativeValue: false,
        manuallyEditedValue: true,
        discontinuityValue: false,
        discontinuityCumulativeValue: false,
        autoEditedValue: false,
        autoEditedCumulativeValue: true,
        highValue: false,
        highCumulativeValue: false,
        lowValue: false,
        lowCumulativeValue: false
    }
];
