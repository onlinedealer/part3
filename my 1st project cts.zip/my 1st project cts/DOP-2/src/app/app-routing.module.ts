import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ClubBenefitComponent } from './club-benefit/club-benefit.component';
import { ClubDashboardComponent } from './club-dashboard/club-dashboard.component';
import { RegistrationComponent } from './registration/registration/registration.component';
import { PaymentBillingComponent } from './payment-billing/payment-billing/payment-billing.component';
import { ProfileCompletionComponent } from './profile-completion/profile-completion.component';
import { ClubOrderConfirmationComponent } from './club-order-confirmation/club-order-confirmation.component';
import { GetDigitalProfileResolver } from './shared/resolvers/get-digital-profile-resolver.service';
import { ValidateProfileEmailResolver } from './shared/resolvers/validate-profile-email-resolver.service';
import { RegistrationNavResolverService } from './shared/resolvers/registration-nav-resolver.service';
import { GetEligibleClubSubscription } from './shared/resolvers/get-eligible-club-subscription-resolver';
import { CarepassLookupComponent } from './carepass-lookup/carepass-lookup.component';
import { RouteConfigurations } from './shared/utility/club-constants.service';
import { CarepassSelfUnenrollComponent } from './carepass-self-unenroll/carepass-self-unenroll.component';
import { GetCancellationInfoResolver } from './shared/resolvers/get-cancellation-info.resolver.service';

const routes: Routes = [
  { path: RouteConfigurations.clubBenefits,  component: ClubBenefitComponent },
  { path: RouteConfigurations.clubDashboard,  component: ClubDashboardComponent },
  { path: RouteConfigurations.carepassLookUp,  component: CarepassLookupComponent },
  { path: RouteConfigurations.clubRegistration,
    component: RegistrationComponent,
    resolve: {
      regDataObj: RegistrationNavResolverService
    }
  },
  {
    path: RouteConfigurations.profileCompletion,
    component: ProfileCompletionComponent,
    resolve: {
      enrollmentDetails: ValidateProfileEmailResolver
    }
   },
  { path: RouteConfigurations.clubOrderConfirmation, component: ClubOrderConfirmationComponent },
  {
    path: RouteConfigurations.clubPaymentBillingDetails,
    component: PaymentBillingComponent,
    resolve: {
      profile: GetDigitalProfileResolver,
      subscription: GetEligibleClubSubscription
    }
  },
  {
    path: RouteConfigurations.carepassSelfUnenroll,
    component: CarepassSelfUnenrollComponent,
    resolve: {
      getCancellationInfo: GetCancellationInfoResolver
    }
   }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})

export class AppRoutingModule {

}
