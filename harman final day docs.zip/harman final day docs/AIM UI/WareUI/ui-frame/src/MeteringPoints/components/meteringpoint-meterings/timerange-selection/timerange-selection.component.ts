import {
    Component,
    Input,
    Output,
    EventEmitter,
    ChangeDetectionStrategy,
    ViewChild,
    OnDestroy,
    SimpleChanges,
    OnInit,
    ElementRef,
    Renderer2,
    OnChanges
} from "@angular/core";
import { MatDatepicker, MatDatepickerInputEvent } from "@angular/material/datepicker";
import { FormGroup, FormBuilder } from "@angular/forms";
import { DateRangeValue } from "../../../../Shared/components/date-range-picker/date-range-picker.component";
import * as moment from "moment";
import { Subscription } from "rxjs";
import { TranslationsService } from "../../../../app/services/translations-service";
@Component({
    selector: "landisgyr-timerange-selection",
    templateUrl: "./timerange-selection.component.html",
    styleUrls: ["./timerange-selection.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class TimeRangeSelectionComponent implements OnDestroy, OnInit, OnChanges {
    @Input()
    idName!: any;

    @Input()
    disabled = false;

    @Input()
    from!: number;

    @Input()
    until!: number;

    @Output()
    timePeriodChanged = new EventEmitter<{ from: number; until: number }>();

    @Input()
    rangeDisable!: boolean;
    @ViewChild("datePicker") datepicker!: MatDatepicker<Date>;
    @ViewChild("endDate") endDate!: ElementRef;
    @ViewChild("dateRangePicker") daterangepicker!: MatDatepicker<Date>;
    separator = "-";
    datePickerForm!: FormGroup;
    timeSubscription: Subscription;
    timePlaceHolder = "TimeFormat";
    startDatePlaceHolder = "";
    endDatePlaceHolder = "";

    @Input() minDate!: Date | null;
    @Input() maxDate!: Date | null;

    constructor(public formBuilder: FormBuilder, private renderer: Renderer2, public translations: TranslationsService) {
        this.datePickerForm = this.formBuilder.group({
            datePickerControl: this.formBuilder.group({
                begin: moment(this.from),
                end: moment(this.until)
            }),
            date: [],
            timePickerControl: []
        });
        this.timeSubscription = this.datePickerForm.controls["timePickerControl"].valueChanges.subscribe(() => {
            this.emitDateTime();
        });
    }

    ngOnInit() {
        this.datePickerForm = this.formBuilder.group({
            datePickerControl: this.formBuilder.group({
                begin: moment(this.from),
                end: moment(this.until)
            }),
            date: [],
            timePickerControl: []
        });
    }

    ngOnChanges(changes: SimpleChanges) {
        if (
            changes &&
            changes.from &&
            changes.until &&
            changes.from.currentValue !== changes.from.previousValue &&
            changes.until.currentValue !== changes.until.previousValue
        ) {
            this.datePickerForm.controls.datePickerControl.setValue({
                begin: moment(changes.from.currentValue),
                end: moment(changes.until.currentValue)
            });
        }
    }

    openDatePicker() {
        this.daterangepicker.open();
    }
    onDateChange(event: MatDatepickerInputEvent<Date>) {
        const dateRange = this.datePickerForm.controls.datePickerControl.value;
        if (dateRange.begin !== null && dateRange.end === null) {
            this.renderer.removeClass(this.endDate.nativeElement, "mat-date-range-input-inner");
        }
        if (dateRange.begin !== null && dateRange.end !== null) {
            this.separator = "-";
            this.timePeriodChanged.emit(this.transformToTimePeriod(dateRange));
        }
    }

    emitDateTime() {
        const selectedDate = this.datePickerForm.controls["date"].value;
        this.timePeriodChanged.emit(this.transformToTimePeriod(selectedDate));
    }

    onCloseDateRangePicker(event: any) {
        const dateRange = this.datePickerForm.controls.datePickerControl.value;
        if (dateRange.begin === null || dateRange.end === null) {
            this.separator = "";
            this.startDatePlaceHolder = this.translations.getTranslation("Select time range...");
            this.endDatePlaceHolder = "";
            this.datePickerForm.controls.datePickerControl.setValue({ begin: null, end: null });
            this.timePeriodChanged.emit();
        }
    }

    onOpenDateRangePicker(event: any) {
        this.startDatePlaceHolder = "StartDate";
        this.endDatePlaceHolder = "EndDate";
    }

    transformToTimePeriod(value: DateRangeValue | moment.Moment): { from: number; until: number } {
        if (moment.isMoment(value)) {
            return {
                from: value.valueOf(),
                until: value.valueOf()
            };
        } else {
            return {
                from: value.begin.valueOf(),
                until: value.end.valueOf()
            };
        }
    }

    getRangePickerDate(): DateRangeValue {
        return {
            begin: moment(this.from),
            end: moment(this.until)
        };
    }

    ngOnDestroy() {
        if (this.timeSubscription) {
            this.timeSubscription.unsubscribe();
        }
    }
}
