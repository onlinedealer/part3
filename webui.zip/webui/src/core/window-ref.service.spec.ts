import { WindowRefService } from './window-ref.service';

describe('WindowRefService', () => {
  let service: WindowRefService;

  beforeEach(() => {
    service = new WindowRefService();
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return native window', () => {
    expect(service.nativeWindow).toBe(window);
  });
});
