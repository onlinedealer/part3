import { Action, createReducer, on } from "@ngrx/store";
import { NetworkControlParam } from "../../models/network-specific-config.model";
import { NetworkSpecificConfigActions } from "../actions";

export interface NetworkSpecificConfigurationState {
    entities: NetworkControlParam[];
}

export const initialState: NetworkSpecificConfigurationState = {
    entities: []
};

const networkSpecificConfigStateReducer = createReducer(
    initialState,
    on(NetworkSpecificConfigActions.LoadNetworkSpecificConfigurationSuccess, (state, payload: any) => {
        return {
            ...state,
            entities: payload
        };
    })
);

export function reducer(state: NetworkSpecificConfigurationState | undefined, action: Action): NetworkSpecificConfigurationState {
    return networkSpecificConfigStateReducer(state, action);
}
