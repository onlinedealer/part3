import { ChartScalingDialogComponent } from "./chart-scaling-dialog/chart-scaling-dialog.component";
import { Component, Input, ChangeDetectionStrategy, EventEmitter, Output, OnChanges } from "@angular/core";
import { MatDialog } from "@angular/material/dialog";
import { BehaviorSubject } from "rxjs";
import { Metering } from "../../../models/metering.model";
import { clone } from "lodash";

@Component({
    selector: "landisgyr-metering-charts",
    templateUrl: "./metering-charts.component.html",
    styleUrls: ["./metering-charts.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringChartsComponent implements OnChanges {
    @Input()
    chartDataGrouping!: string;

    @Input()
    chartDataAvailableGroupingOptions!: string[];

    @Output()
    chartDataGroupingSelection = new EventEmitter<string>();

    @Input()
    selectedMeteringPointOtherMeterings!: Metering[];

    @Input()
    selectedMeteringPointsChartDataSelectedMeterings!: { meteringId: number; meteringType: string }[];

    @Output()
    changeMeteringSelection = new EventEmitter<{ meteringPointId: number; meteringId: number; meteringType: string; selected: boolean }>();

    @Input()
    yAxisScales!:
        | {
              unit: string | undefined;
              inUse: boolean;
              scalingAutomated: boolean;
              min: number | undefined;
              max: number | undefined;
          }[]
        | [];

    @Input()
    chartUnits!: (string | undefined)[];

    @Input()
    allSelectedMeteringsProfile!: any;

    @Input()
    chartData!: any[];

    @Input()
    sideviewExpanded!: boolean;

    constructor(public dialog: MatDialog) {}

    optionsOpen = new BehaviorSubject<boolean>(false);
    optionsOpen$ = this.optionsOpen.asObservable();

    colors = ["#42a340", "#1abc9c", "#50abec", "#3d44a0", "#9b59b6", "#e74c3c", "#f7a536", "#f1c40f", "#bdc3c7"];

    colorScheme: { name: string; selectable: boolean; group: string; domain: string[] } = {
        name: "coolthree",
        selectable: true,
        group: "Ordinal",
        domain: []
    };

    colorSchemeTooltip: { name: string; selectable: boolean; group: string; domain: string[] } = {
        name: "coolthree",
        selectable: true,
        group: "Ordinal",
        domain: []
    };
    customColors: { name: string; value: string }[] = [];
    leftYaxisColors!: string[];
    rightYaxisColors!: string[];

    animationInProgress = false;

    ngOnChanges() {
        if (this.chartData && this.chartData.length > 0) {
            const meteringNames = this.selectedMeteringPointOtherMeterings
                ? this.selectedMeteringPointOtherMeterings.map((metering: any) => metering.name)
                : [];
            if (meteringNames.length > this.colors.length) {
                this.pushEnoughColorsForAdditionalMeterings(meteringNames);
            }
            const additionalColors: string[] = [];
            const leftColors: string[] = [];
            const rightColors: string[] = [];
            const tooltipColors: string[] = [];
            const firstUnit = this.chartData[0].type;
            const customColors: { name: string; value: string }[] = [];
            this.chartData.forEach((chartMetering: any) => {
                let index: number;
                if (meteringNames.includes(chartMetering.name)) {
                    index = meteringNames.findIndex((metering: string) => metering === chartMetering.name);
                    if (chartMetering.type !== firstUnit) {
                        rightColors.push(this.colors[index]);
                    } else {
                        leftColors.push(this.colors[index]);
                        additionalColors.push(this.colors[index]);
                    }
                    customColors.push({ name: chartMetering.name, value: this.colors[index] });
                    tooltipColors.push(this.colors[index]);
                }
            });
            this.customColors = [{ name: this.chartData[0].name, value: "#89c649" }, ...customColors];
            this.colorScheme.domain = ["#89c649", ...additionalColors];
            this.colorSchemeTooltip.domain = ["#89c649", ...tooltipColors];
            this.rightYaxisColors = rightColors;
            this.leftYaxisColors = leftColors;
        }
    }

    onAnimationInProgress() {
        this.animationInProgress = true;
    }
    onAnimationDone(isOpen: boolean) {
        this.animationInProgress = false;
    }
    openScaleControl() {
        this.dialog.open(ChartScalingDialogComponent, {
            width: "500px",
            height: "300px",
            disableClose: true
        });
    }
    pushEnoughColorsForAdditionalMeterings(meterings: any[]) {
        const originalColorsLenght = this.colors.length;
        const originalColorsArray = clone(this.colors);
        for (let i = this.colors.length; i < meterings.length; i = i + originalColorsLenght) {
            this.colors = [...this.colors, ...originalColorsArray];
        }
    }
}
