(function() {
    'use strict';

    FirstApp.controller("homeCtrl", ['$scope', '$ajaxFactory', '$rootScope','fileModel', homeCtrl]);

    function homeCtrl($scope, $ajaxFactory, $rootScope, fileModel) {
    	$scope.viewbtn = true;
        $scope.uploadFile = function(){
	
		
		var filepath = $('#fileUploadId').val();
		var isValidFileFormate = new RegExp("^(?:[\w]\:|\\)(\\[a-z_\-\s0-9\.]+)+\.(txt|gif|pdf|doc|docx|xls|xlsx)$").test(filepath);
		
		if(!isValidFileFormate){
			alert("Please Enter Valid Format");
			return;
		}
        var file = $scope.myFile;      
         var fd = new FormData();
		 fd.append('file', file);
		 var uploadUrl = "/fileUpload"; //fileUpload?path:'C/bharath/xyz.txt'  
		 
		 // paranet :: key  : filePath   value = u shoiuld set
		 var multiplefile = [] ;
		 
		 var obj = {};
		 obj.filePath = $('#fileUploadId').val();
		 obj.fileType = fd;	 
		 
		 multiplefile.push(obj);
      
		  var promise = fileModel.uploadFileToUrl(uploadUrl,fd,multiplefile)
                promise.then(function(data) {
                   console.log(data);
                });
                promise.catch(function(d) { 
					console.log(d);
                    return d;
                });
        
    };
 
    }


})();
