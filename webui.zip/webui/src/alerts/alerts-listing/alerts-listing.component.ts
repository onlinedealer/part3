import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoService } from '@ngneat/transloco';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { AlertService } from 'alerts/alert.service';
import { AlertCountsModel, TotalAlertCount } from 'alerts/alertcounts.model';
import { EventBusService } from 'core/eventBusService';
import { SecondaryNavItemsService, SharedConstants } from 'discovery-shared';
import { CircleProgressOptions } from 'ng-circle-progress';
import { ToastrService } from 'ngx-toastr';
import { ObserverListModel } from 'observer/observer-listing/observer-list.model';
import { ObserverService } from 'observer/observer.service';
import { MenuItem, SortEvent } from 'primeng/api';
import { DialogService as PrimeNgDialogService } from 'primeng/dynamicdialog';
import { Table } from 'primeng/table';
import { AlertModel } from '../alert.model';
import { AlertConstants } from './alert-constants';
import { ExportDialogComponent } from './infopanels/export-dialog/export-dialog.component';

@Component({
  selector: 'discovery-alerts-listing',
  templateUrl: './alerts-listing.component.html',
  styleUrls: ['./alerts-listing.component.css']
})
export class AlertsListingComponent implements OnInit {
  @ViewChild('alertsTable') alertsTable: Table;

  items: MenuItem[];
  isLoading = false;
  initialSetupLoading = true;

  CRITICAL = AlertConstants.CRITICAL;
  WARNING = AlertConstants.WARNING;
  VOLUME = 'volume';
  DATA_DRIFT = 'data drift';

  selectedAlert: AlertModel;
  selectedAlertDetail: AlertModel;

  alerts: AlertModel[] = [];
  public optionsVolume: CircleProgressOptions = new CircleProgressOptions();

  alertCounts: AlertCountsModel[] = [];

  navItems: MenuItem[];

  showNonAlerts: boolean = false;

  searchValue: string;
  observerList: ObserverListModel[] = [];
  totalAlertCount: number = 0;
  baseUrl: string;

  observerId: string;
  isObserverDetailView: boolean = false;

  get hasObserver() {
    return !this.initialSetupLoading && this.observerList.length > 0;
  }

  get hasAlerts() {
    return !this.initialSetupLoading && this.totalAlertCount > 0;
  }

  get exportExcelFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.EXPORTTOEXCEL);
  }

  constructor(
    private navItemsService: SecondaryNavItemsService,
    private alertService: AlertService,
    private toastrService: ToastrService,
    private observerService: ObserverService,
    private translocoService: TranslocoService,
    private dialogService: PrimeNgDialogService,
    private launchDarklyService: LaunchDarklyService,
    private eventBusService: EventBusService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {}
  ngOnInit(): void {
    this.navItems = this.navItemsService.getNavItems();
    this.onReportDownload();
    if (this.router.url.includes('observer-detail')) {
      this.isObserverDetailView = true;
      this.observerId = this.activatedRoute.parent.snapshot?.paramMap.get('observerId');
      this.getTotalAlerts();
    } else {
      this.loadObserverList();
    }
  }

  /**
   * Fetch Observer list and alerts count on first page load only
   *
   */
  loadObserverList() {
    this.observerService.getObserverList().subscribe(
      (observers: ObserverListModel[]) => {
        this.observerList = observers;
        if (observers.length) {
          this.getTotalAlerts();
        } else {
          this.initialSetupLoading = false;
        }
      },
      () => {
        this.initialSetupLoading = false;
      }
    );
  }

  getTotalAlerts() {
    this.updateOptions();
    this.alertService.getTotalAlertsCount(this.observerId).subscribe(
      (alertCount: TotalAlertCount) => {
        this.totalAlertCount = alertCount.count;
        this.initialSetupLoading = false;
        if (this.totalAlertCount > 0) {
          this.getAlerts();
        }
      },
      () => {
        this.initialSetupLoading = false;
      }
    );
  }

  getAlerts() {
    this.isLoading = true;
    this.alertService.getAlerts(this.showNonAlerts, this.observerId).subscribe(
      (alertList: AlertModel[]) => {
        this.alerts = alertList;
        if (this.alerts && this.alerts.length > 0) {
          this.selectAlert(
            this.alerts.reduce(function (prev: AlertModel, current: AlertModel) {
              return prev.raisedAt > current.raisedAt ? prev : current;
            })
          );
        }
        this.isLoading = false;
      },
      (httpErrorResponse) => {
        this.isLoading = false;
        this.toastrService.error(httpErrorResponse.message);
      }
    );

    this.alertService.getAlertsCount(this.observerId).subscribe((counts) => {
      this.alertCounts = counts;
    });
  }

  onReportDownload() {
    this.eventBusService?.on<any>('DOBReportingJob')?.subscribe((data) => {
      if (data.jobId) {
        const jobId = data.jobId;
        let assetName = data.assetName;
        const toastInfo = this.toastrService.info(
          this.translocoService?.translate('discoveryAlerts.infoPanel.excelDialog.loadingBannerText', {
            alertName: assetName
          }),
          '',
          { disableTimeOut: true }
        );
        this.alertService.getExcelStatus(jobId, assetName).subscribe(() => {
          this.toastrService.remove(toastInfo.toastId);
        });
      }
    });
  }

  showAlerts(): boolean {
    return this.alerts && this.alerts.length > 0;
  }

  filterGlobal($event: Event, contains: string) {
    this.alertsTable.filterGlobal(($event.target as HTMLInputElement).value, contains);
  }

  onContextMenu(rowData: AlertModel) {
    this.items = [
      {
        label: this.translocoService.translate('discoveryAlerts.infoPanel.exportToExcel'),
        command: () => {
          this.dialogService.open(ExportDialogComponent, {
            header: this.translocoService?.translate('discoveryAlerts.infoPanel.exportToExcel'),
            data: {
              alertId: rowData.id,
              toDate: new Date(rowData.raisedAt),
              assetName: rowData.assetName
            }
          });
        }
      }
    ];
  }

  public getAlertPercent(type: string): number {
    let alertCountInformation = this.alertCounts.find((x) => x.category.toLowerCase() === type.toLowerCase());

    return alertCountInformation ? (alertCountInformation.crticalCount / alertCountInformation.total) * 100 : 0;
  }

  public getAlertCount(type: string, level?: string): any {
    let count: number = 0;

    if (this.alertCounts) {
      let alertCountInfo = this.alertCounts.find((y) => y.category.toLowerCase() === type.toLowerCase());

      if (alertCountInfo) {
        if (level && level.toLowerCase() === this.CRITICAL.toLowerCase()) {
          count = alertCountInfo.crticalCount;
        } else if (level && level.toLowerCase() == this.WARNING.toLowerCase()) {
          count = alertCountInfo.warningCount;
        } else {
          count = alertCountInfo.total;
        }
      }
    }

    if (count === 0 && (level === null || level === undefined)) {
      this.optionsVolume.innerStrokeColor = '#6AC400';
    } else {
      this.optionsVolume.innerStrokeColor = '#FFCC00';
    }

    return count;
  }

  public updateOptions() {
    this.optionsVolume.maxPercent = 100;
    this.optionsVolume.radius = 40;
    this.optionsVolume.showTitle = true;
    this.optionsVolume.title = '6';
    this.optionsVolume.titleFontSize = '30';
    this.optionsVolume.showSubtitle = false;
    this.optionsVolume.outerStrokeWidth = 6;
    this.optionsVolume.outerStrokeColor = '#C9302C';
    this.optionsVolume.innerStrokeWidth = 6;
    this.optionsVolume.innerStrokeColor = '#FFCC00';
    this.optionsVolume.showInnerStroke = true;
    this.optionsVolume.renderOnClick = false;
    this.optionsVolume.space = -6;
    this.optionsVolume.showUnits = false;
    this.optionsVolume.outerStrokeLinecap = 'butt';
  }

  public onAlertSelect(event: { data: AlertModel }) {
    this.selectAlert(event.data);
  }

  selectAlert(alert: AlertModel) {
    this.selectedAlert = alert;

    let detail: AlertModel;

    this.alertService.getAlertDetail(alert.id).subscribe((element) => {
      detail = element;
      this.selectedAlertDetail = detail;
    });
  }

  customSort(event: SortEvent) {
    event.data.sort((data1, data2) => {
      let value1 = data1[event.field];
      let value2 = data2[event.field];
      let result = null;

      if (value1 == null && value2 != null) result = -1;
      else if (value1 != null && value2 == null) result = 1;
      else if (value1 == null && value2 == null) result = 0;
      else if (event.field === 'alertLevel') {
        result = this.alertLevelCompare(value1, value2);
      } else if (typeof value1 === 'string' && typeof value2 === 'string') result = value1.localeCompare(value2);
      else if (value1 > value2) {
        result = 1;
      } else {
        result = value1 < value2 ? -1 : 0;
      }

      return event.order * result;
    });
  }

  private alertLevelCompare(value1: string, value2: string): number {
    if (value1.toUpperCase() === this.CRITICAL && value2.toUpperCase() !== this.CRITICAL) {
      return 1;
    } else if (value2.toUpperCase() === this.CRITICAL && value1.toUpperCase() !== this.CRITICAL) {
      return -1;
    } else if (value2.toUpperCase() === this.CRITICAL && value1.toUpperCase() === this.CRITICAL) {
      return 0;
    } else if (value1.toUpperCase() === this.WARNING && value2.toUpperCase() !== this.WARNING) {
      return 1;
    } else if (value2.toUpperCase() === this.WARNING && value1.toUpperCase() !== this.WARNING) {
      return -1;
    } else if (value2.toUpperCase() === this.WARNING && value1.toUpperCase() === this.WARNING) {
      return 0;
    } else {
      return value1.localeCompare(value2);
    }
  }
}
