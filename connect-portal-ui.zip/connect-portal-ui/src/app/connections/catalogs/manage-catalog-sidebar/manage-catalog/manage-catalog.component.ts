import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnDestroy, OnInit, Output, ViewChild } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { ErrorMessage } from '@precisely/prism-ng/cloud';
import { TableConfiguration, TableMessageType } from '@shared/components/generic-table/generic-table';
import { forkJoin, Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { BaseComponent } from 'src/app/core/base.component';
import { MetadataApiService } from 'src/app/pipelines/pipeline/data/schema-table-selector/metadata-api.service';
import { Connection, CONNECTION_TYPE } from '../../../shared/connection';
import { CatalogingErrorSidebarComponent } from '../../cataloging-error-sidebar/cataloging-error-sidebar.component';
import { CatalogingErrorSidebarService } from '../../cataloging-error-sidebar/cataloging-error-sidebar.service';
import { CatalogApiService, UPDATE_CATALOG_ACTION } from '../../shared/catalog-api.service';
import { CatalogSchema } from '../../shared/catalog-schema';
import { CatalogStatus, CATALOG_STATUS } from '../../shared/catalog-status';
import { CatalogTableStatus } from '../../shared/catalog-table-status';
import { DeleteCatalogSidebarComponent } from '../delete-catalog-sidebar/delete-catalog-sidebar.component';
import { manageCatalogTableConfiguration } from './manage-catalog-configuration';
import { DatePipe } from '@angular/common';

/**
 * Component for managing and displaying the catalogs associated with a Data Connection.
 */
@Component({
  selector: 'p-connect-manage-catalog',
  templateUrl: './manage-catalog.component.html',
  styleUrls: ['./manage-catalog.component.scss'],
  providers: [DatePipe]
})
export class ManageCatalogComponent extends BaseComponent implements OnInit, OnDestroy {
  /**
   * The connection that the catalogs are related to
   */
  @Input() connection: Connection;

  /**
   * Passes on any error that should be displayed in the parent component.
   */
  @Output() serviceError = new EventEmitter<any>();

  /**
   * Event that is emitted when the catalog action has been perfomed
   */
  @Output() actionCompleted = new EventEmitter<any>();

  /**
   * Event that is triggered when the user performs and action on the catalogs
   */
  @Output() processingRequest = new EventEmitter<boolean>();

  /**
   * Event that is emitted when start cataloging button is clicked for the selected schemas, topics or subjects.
   */
  @Output() startCatalogingEvent = new EventEmitter<boolean>();

  /**
   * Event that is emitted when data connection has schemas/topics/subjects cataloged
   */
  @Output() connectionCataloged = new EventEmitter<CatalogStatus>();

  @ViewChild(DeleteCatalogSidebarComponent) deleteCatalogSidebarComponent: DeleteCatalogSidebarComponent;

  @ViewChild(CatalogingErrorSidebarComponent) catalogingErrorSidebarComponent: CatalogingErrorSidebarComponent;

  /**
   * The list of selected schemas from the table.
   */
  selectedSchemas = [];

  /**
   * The data for the catalogs table.
   */
  catalogsData = [];

  refreshCatalogDataTimeout: NodeJS.Timeout;

  /**
   * The current project id, required for the get schemas and get calalogs API calls
   */
  projectId: string;

  /**
   * List of schemas cataloged
   */
  schemasCataloged: CatalogSchema[];

  get hasItemsSelected(): boolean {
    if (this.isCatalogTableHidden) {
      return true;
    } else {
      return this.selectedSchemas && this.selectedSchemas.length !== 0;
    }
  }

  /**
   * Checks whether Start cataloging should be disabled
   */
  get isStartCatalogingDisabled(): boolean {
    return this.isButtonDisabled([CATALOG_STATUS.INPROGRESS]);
  }

  /**
   * Checks whether Stop cataloging should be disabled
   */
  get isStopCatalogingDisabled(): boolean {
    return this.isButtonDisabled([CATALOG_STATUS.COMPLETE, CATALOG_STATUS.NOT_CATALOGED]);
  }

  /**
   * Checks whether Remove catalog should be disabled
   */
  get isRemoveCatalogDisabled(): boolean {
    return this.isButtonDisabled([CATALOG_STATUS.INPROGRESS, CATALOG_STATUS.NOT_CATALOGED]);
  }

  /**
   * For unstructured data sets, the flag indicated if the table is hidden
   */
  get isCatalogTableHidden(): boolean {
    return (
      (this.connection && this.connection.connectionType === CONNECTION_TYPE.KAFKA) ||
      this.connection.connectionType === CONNECTION_TYPE.SCHEMAREGISTRY
    );
  }

  /**
   * Table configuration for the catalogs table.
   */
  catalogsTable: TableConfiguration = manageCatalogTableConfiguration;

  /**
   * Indicates whether we are updating the catalogs or creating a new catalog.
   */
  isUpdatingCatalog = false;

  catalogStatus: {
    status: string;
    tooltip: string;
    params: any;
    icons: string[];
  };

  lastCatalogedKafkaTopicDate: string;

  constructor(
    private readonly catalogApiService: CatalogApiService,
    private readonly metadataApiService: MetadataApiService,
    public readonly translocoService: TranslocoService,
    private readonly catalogingErrorSidebarService: CatalogingErrorSidebarService,
    private datePipe: DatePipe
  ) {
    super();
  }

  get catalogErrorMessages(): ErrorMessage[] {
    return this.catalogingErrorSidebarService.errorMessages;
  }

  ngOnInit(): void {
    this.catalogsTable.rowSelectionChangedEvent = (checkedItems) => {
      this.selectedSchemas = checkedItems;
    };

    this.catalogsTable.tableMessages.emptyTableMessage = {
      messageType: TableMessageType.INFO,
      messageHead: 'connections.MANAGE_CATALOG.MESSAGES.INFO_NOT_RETRIEVED.HEAD',
      messageCaption: 'connections.MANAGE_CATALOG.MESSAGES.INFO_NOT_RETRIEVED.CAPTION'
    };

    this.selectedSchemas = [];

    this.onCatalogUpdated();

    this.catalogingErrorSidebarService.resetErrorMessages();
  }

  ngOnDestroy(): void {
    clearInterval(this.refreshCatalogDataTimeout);
  }

  /**
   * Start cataloging the selected schemas.
   */
  onStartCatalogingButtonClicked(): void {
    this.startCatalogingEvent.emit(true);
    this.processingRequest.emit(true);
    const schemas = this.selectedSchemas.map((schema) => {
      return schema.schema;
    });
    const catalogServiceRequest = !this.isUpdatingCatalog
      ? this.catalogApiService.createCatalog(schemas, this.connection, this.projectId)
      : this.catalogApiService.updateCatalog(schemas, this.connection, this.projectId);

    this.handleCatalogRequest(catalogServiceRequest);
  }

  /**
   * Stop cataloging the selected schemas.
   */
  onStopCatalogingButtonClicked(): void {
    this.processingRequest.emit(true);

    const schemas = this.selectedSchemas.map((schema) => {
      return schema.schema;
    });

    const catalogServiceRequest = this.catalogApiService.updateCatalog(
      schemas,
      this.connection,
      this.projectId,
      UPDATE_CATALOG_ACTION.STOP
    );
    this.handleCatalogRequest(catalogServiceRequest);
  }

  /**
   * Delete the catalogs for the selected schemas.
   */
  onDeleteCatalogButtonClicked(): void {
    this.deleteCatalogSidebarComponent.open();
  }

  updateAutoRefreshTimeout(): void {
    clearInterval(this.refreshCatalogDataTimeout);
    this.refreshCatalogDataTimeout = setInterval(() => {
      this.catalogingErrorSidebarService.errorMessages = [];
      this.getSchemaAndCatalogData();
    }, 30000);
  }

  /**
   * Refreshes the catalogs table.
   */
  onCatalogUpdated(): void {
    this.getSchemaAndCatalogData();
    this.updateAutoRefreshTimeout();
  }

  /**
   * Handle the catalog API request.
   */
  private handleCatalogRequest(request: Observable<object>) {
    request
      .subscribe({
        next: () => {
          this.onCatalogUpdated();
          this.actionCompleted.emit();
        },
        error: (errorResponse) => {
          this.serviceError.emit(errorResponse);
        }
      })
      .add(() => {
        this.processingRequest.emit(false);
      });
  }

  /**
   * Get Schema data as per the data connection
   */
  getSchemasData(connectionType: string): Observable<any> {
    if (connectionType === CONNECTION_TYPE.SCHEMAREGISTRY || connectionType === CONNECTION_TYPE.KAFKA) {
      return of(null);
    } else {
      return this.metadataApiService.getSchemas(this.connection.id).pipe(
        map((res) => res),
        catchError((errorResponse) => {
          this.catalogingErrorSidebarService.add([errorResponse]);
          return of(null);
        })
      );
    }
  }

  /**
   * Get cataloged Schema data as per the data connection
   */
  getCatalogedSchemaData(connectionType: string, results) {
    if (connectionType === CONNECTION_TYPE.KAFKA || connectionType === CONNECTION_TYPE.SCHEMAREGISTRY) {
      const catalogSchemas = results[1]?.topics || results[1]?.subjects || [];
      this.lastCatalogedKafkaTopicDate =
        catalogSchemas.length > 0
          ? this.datePipe.transform(
              new Date(
                Math.max(
                  ...catalogSchemas.map((element) => {
                    return new Date(element.lastUpdated);
                  })
                )
              ),
              'yyyy/MM/dd HH:mm:ss'
            )
          : '-';
      return catalogSchemas;
    } else {
      return results[1]?.schemas || [];
    }
  }

  /**
   * Merge the results of the schema from the data connection and the catalogs
   */
  private getSchemaAndCatalogData() {
    let schemas$: Observable<any> = this.getSchemasData(this.connection.connectionType);
    this.catalogsTable.isLoading = true;
    this.catalogStatus = null;

    const catalogSchemasOrTopicsOrSubjects$ = this.catalogApiService.status(this.connection.id, true).pipe(
      map((res) => res),
      catchError((errorResponse: HttpErrorResponse) => {
        if (errorResponse?.error.status !== 404) {
          this.catalogingErrorSidebarService.add([errorResponse]);
        }
        return of(null);
      })
    ) as Observable<CatalogStatus>;

    forkJoin([schemas$, catalogSchemasOrTopicsOrSubjects$])
      .subscribe({
        next: (results) => {
          const schemas = Array.isArray(results[0]) ? results[0] : results[0]?.subjects || [];
          let catalogSchemas: any = this.getCatalogedSchemaData(this.connection.connectionType, results);
          const status = results[1] instanceof HttpErrorResponse ? null : results[1];
          if (status) {
            this.connectionCataloged.emit(status);
            this.schemasCataloged = status.schemas;
            this.getCatalogErrors(status);
          }
          this.setOverallStatus(status);
          this.isUpdatingCatalog = status !== null;

          this.catalogsData = schemas.map((schema) => {
            let lastCataloged = catalogSchemas.find((catalogSchema) => catalogSchema.schema === schema.name)?.lastUpdated || '-';
            let matchingCatalogSchema = catalogSchemas.find((catalogSchema) => catalogSchema.schema === schema.name);
            const tableError =
              matchingCatalogSchema && matchingCatalogSchema.tablesStatus
                ? matchingCatalogSchema.tablesStatus.filter((table) => table.errorMessage)
                : [];
            if (lastCataloged !== '-') {
              lastCataloged = this.datePipe.transform(new Date(lastCataloged), 'yyyy/MM/dd HH:mm:ss');
            }
            return {
              schema: schema.name,
              status: matchingCatalogSchema?.status?.toUpperCase() || 'NOT_CATALOGED',
              statusParams: {
                partialNumber: matchingCatalogSchema?.tablesCompleted,
                totalNumber: matchingCatalogSchema?.tablesCount
              },
              lastCataloged: lastCataloged,
              schemaError: matchingCatalogSchema?.errorMessage ? true : false,
              tableError: tableError.length ? true : false
            };
          });
        }
      })
      .add(() => {
        this.updateButtonDisableState();
        this.catalogsTable.isLoading = false;
      });
  }

  /**
   * Updates disable state of start/stop/remove catalog buttons, by getting the latest status of the selected schema.
   */
  private updateButtonDisableState(): void {
    if (this.schemasCataloged && this.selectedSchemas.length) {
      this.selectedSchemas = this.selectedSchemas.map((selectedSchema) => {
        const status = this.schemasCataloged.find((schema) => schema.schema === selectedSchema.schema).status;
        return { ...selectedSchema, status: status };
      });
    }
  }

  /**
   * Get text and icon for the catalog status
   */
  getStatusIcon(status: string): string[] {
    if (status) {
      switch (status.toUpperCase()) {
        case 'FAILED':
          return ['png-alert-actionrequired-solid', 'text-danger'];
        case 'STOPPED':
          return ['png-alert-partial', 'text-danger'];
        case 'INPROGRESS':
          return ['png-alert-inprogress', 'text-success'];
        case 'COMPLETE':
          return ['png-alert-open', 'text-success'];
        case 'NOT_CATALOGED':
          return ['png-disabled', 'text-muted'];
        default:
          return [];
      }
    }
  }

  /**
   * Using the catalog status, sets everything related to the overall status for manage catalog.
   * @param catalogStatus returned status from API
   */
  setOverallStatus(catalogStatus: CatalogStatus) {
    const status = catalogStatus?.status ? catalogStatus.status.toUpperCase() : 'NOT_CATALOGED';
    const tooltip = this.getOverallStatusTooltip(status);

    // Parameters are used for complete and stopped statuses
    let schemaOrTopics: any = catalogStatus?.schemas || catalogStatus?.topics || catalogStatus?.subjects || [];
    const partialNumber = schemaOrTopics.filter((schemaOrTopic) => schemaOrTopic.status === CATALOG_STATUS.COMPLETE).length;

    const totalNumber = schemaOrTopics.length;
    const params = {
      partialNumber: partialNumber,
      totalNumber: totalNumber,
      structureType: this.translocoService
        .translate(`connections.CATALOG_STATUS.ITEM_TYPES.${this.structureType(this.connection.connectionType, totalNumber)}`)
        .toLowerCase()
    };

    // When complete, do not display anything for the icon
    const icons = status === 'COMPLETE' ? [] : this.getStatusIcon(status);

    this.catalogStatus = {
      status,
      tooltip,
      params,
      icons
    };
  }

  /**
   * @internal
   * Gets the tooltip translation. For stopped status, changes wording based on the structure.
   * @param status
   * @returns tooltip to translate
   */
  private getOverallStatusTooltip(status: string) {
    let isStopped = status === 'STOPPED';

    if (isStopped && !this.isCatalogTableHidden) {
      return `connections.CATALOG_STATUS.STOPPED.STRUCTURE_TOOLTIP`;
    } else if (isStopped && this.isCatalogTableHidden) {
      return `connections.CATALOG_STATUS.STOPPED.NO_STRUCTURE_TOOLTIP`;
    } else {
      return `connections.CATALOG_STATUS.${status}.TOOLTIP`;
    }
  }

  /**
   * @internal
   * Takes connection and gets the single/plural structure type
   * @param connectionType
   * @param length
   * @returns string to be translated
   */
  private structureType(connectionType: string, length: number = 2): string {
    let type: string;

    switch (connectionType) {
      case 'DB2':
      case 'DB2I':
        type = length === 1 ? 'LIBRARY' : 'LIBRARIES';
        break;
      case 'SQLSERVER':
        type = length === 1 ? 'DATABASE' : 'DATABASES';
        break;
      case 'KAFKA':
        type = length === 1 ? 'TOPIC' : 'TOPICS';
        break;
      case 'SCHEMAREGISTRY':
        type = length === 1 ? 'SUBJECT' : 'SUBJECTS';
        break;
      case 'ORACLE':
      default:
        type = length === 1 ? 'SCHEMA' : 'SCHEMAS';
        break;
    }

    return type;
  }

  /**
   * Checks whether button should be disabled
   */
  private isButtonDisabled(disableStatuses: string[]): boolean {
    if (this.isCatalogTableHidden) {
      return (this.catalogStatus && disableStatuses.indexOf(this.catalogStatus.status.toLowerCase()) >= 0) || false;
    } else {
      return this.selectedSchemas.every((selectedItem) => {
        return disableStatuses.indexOf(selectedItem.status.toLowerCase()) >= 0;
      });
    }
  }

  openCatalogingErrorSidebar(schemaName?: string): void {
    let errorMessages = this.catalogErrorMessages;
    if (schemaName) {
      const selectedSchema = this.schemasCataloged.find((schema) => schema.schema === schemaName);
      const schemaError = selectedSchema.errorMessage ? [this.parseErrorResponse(selectedSchema.errorMessage)] : [];
      const tableError = selectedSchema.tablesStatus
        ? selectedSchema.tablesStatus.filter((table) => table.errorMessage).map((table) => this.parseErrorResponse(table.errorMessage))
        : [];
      errorMessages = [...schemaError, ...tableError];
    }
    this.catalogingErrorSidebarComponent.open(errorMessages);
  }

  /**
   * @param status
   * Finds all catalog errors in host/connection level, schema level & table level & adds them to service.
   */
  getCatalogErrors(status: CatalogStatus): void {
    if (status.errorMessage) {
      this.catalogingErrorSidebarService.add([this.parseErrorResponse(status.errorMessage)]);
    }
    const schemasWithFailedStatus = status.schemas?.filter((schema) => schema.status === 'failed');
    if (schemasWithFailedStatus?.length) {
      schemasWithFailedStatus.forEach((schema) => {
        // Empty array returned if there is no schema or table errors
        const schemaError = schema.errorMessage ? [this.parseErrorResponse(schema.errorMessage)] : [];
        const tableError = schema.tablesStatus
          ? schema.tablesStatus.filter((table) => table.errorMessage).map((table) => this.parseErrorResponse(table.errorMessage))
          : [];
        this.catalogingErrorSidebarService.add([...schemaError, ...tableError]);
      });
    }
  }

  /**
   * @param error: JSON catalog error comes in two formats
   * "{\"timestamp\":\"2022-08-16T10:51:08.856Z\",\"status\":404,\"error\":\"Schema Error\",\"message\":\"Schema Error\",\"path\":\"/api/v1\"}\"}"
   * Above is a simple JSON catalog error object, which the function parses and returns.
   *
   * "{\"status\":404,\"error\":\"{\\\"timestamp\\\":\\\"2022-08-16T10:51:08.856Z\\\",\\\"status\\\":404,\\\"error\\\":\\\"Schema Error\\\",\\\"message\\\":\\\"Schema Error\\\",\\\"path\\\":\\\"/api/v1\\\"}\"}"
   * Above is a JSON object, where the JSON catalog error object is nested under the 'error' key. Function ensures nested JSON error object is parsed and returned.
   */
  private parseErrorResponse(error: string): HttpErrorResponse {
    let errorResponse = JSON.parse(error);
    errorResponse =
      typeof errorResponse.error === 'string' && errorResponse.error.includes('{') ? JSON.parse(errorResponse.error) : errorResponse;
    return errorResponse;
  }
}
