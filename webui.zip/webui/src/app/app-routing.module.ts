import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { Error403Component } from '@precisely/prism-ng/error-display';
import { AutoLoginAllRoutesGuard } from 'angular-auth-oidc-client';
import { TenantGuard } from '../shared/tenant.guard';
import { ResolveHomeService } from './resolvers/resolve-home.service';

const routes: Routes = [
  {
    path: 'data-observability',
    loadChildren: () => import('../alerts/alerts.module').then((m) => m.AlertsModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard],
    resolve: { data: ResolveHomeService }
  },
  {
    path: 'data-observability/data-connection',
    loadChildren: () => import('../connections/connections.module').then((m) => m.ConnectionsModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard]
  },
  {
    path: 'data-observability/data-profiling',
    loadChildren: () => import('../profiling/profiling.module').then((m) => m.ProfilingModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard]
  },
  {
    path: 'data-observability/observers',
    loadChildren: () => import('../observer/observer.module').then((m) => m.ObserverModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard]
  },
  {
    path: 'data-observability/data-alerts',
    loadChildren: () => import('../alerts/alerts.module').then((m) => m.AlertsModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard]
  },
  {
    path: 'data-observability/catalogs-connections',
    loadChildren: () =>
      import('../connection-container/connection-container.module').then((m) => m.ConnectionContainerModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard]
  },
  {
    path: 'data-observability/catalogs-datasets',
    loadChildren: () =>
      import('../data-catalog-container/data-catalog-container.module').then((m) => m.DataCatalogContainerModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard]
  },
  {
    path: 'data-observability/catalogs-dataset-view/:datasetId',
    loadChildren: () =>
      import('../dataset-view-container/dataset-view-container.module').then((m) => m.DatasetViewContainerModule),
    canActivate: [AutoLoginAllRoutesGuard, TenantGuard]
  },
  {
    path: 'error/forbidden', // Matches existing route in shell...do not change.
    component: Error403Component,
    canActivate: [AutoLoginAllRoutesGuard]
  },
  { path: '**', redirectTo: 'data-observability', pathMatch: 'full' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { relativeLinkResolution: 'legacy', scrollPositionRestoration: 'enabled' })],
  exports: [RouterModule]
})
export class AppRoutingModule {}
