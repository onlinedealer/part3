/**
 * @internal
 */
export class Styles {
  static CLASS: string = 'color: #8017E1';
  static MSG: string = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'color: #FFF' : 'color: #111111';
  static TRACE: string = 'color: #0C0';
  static DEBUG: string = 'color: #0C0';
  static INFO: string = 'color: #4B8BFF';
  static WARN: string = 'color: #C9302C';
  static ERROR: string = 'color: #C9302C';
}
