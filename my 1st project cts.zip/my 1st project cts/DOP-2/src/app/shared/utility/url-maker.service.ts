import { Injectable } from '@angular/core';
import { serviceConfigs } from './service-config.service';
import { Env } from './envConfig.service'
import { HttpRequest, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';


@Injectable()
export class UrlMakerService {

    queryParams: Object;
    endpoint: String;
    constructor(private _env: Env) {

        this.queryParams = {
            appName: _env.appName,
            apiSecret: _env.configValues.apiSecretDep || _env.configValues.apiSecret,
            channelName: _env.channelName,
            deviceToken: '12232434',
            deviceType: _env.deviceType,
            lineOfBusiness: 'RETAIL',
            apiKey: _env.configValues.apiKeyDep || _env.configValues.apiKey
        };
        this.endpoint = _env.configValues.endPoint
    }
    getQueryParams(data: String) {
        let ret = [];
        for (let d in data)
            ret.push(encodeURIComponent(d) + '=' + encodeURIComponent(data[d]));
        return ret.join('&');
    }

    getServiceUrl(serviceName, optionalParams?): string {
        let config = serviceConfigs[serviceName];
        let queryParams = this.getQueryParams(Object.assign({}, this.queryParams, (config ? config.queryParams : {}), optionalParams));
        let url;
        try {
            let hostUrl = config.url || this.endpoint;
            let serviceUrl = (hostUrl.slice(-1) === '/' || hostUrl.slice(-1) === '?') ? hostUrl : hostUrl + '/';
            url = serviceUrl + (config.subdomain ? config.subdomain : '') + queryParams;
        } catch (e) { }
        return url;
    }

    getServiceHeaders(serviceName) {
        let headerEnv = window['envName'] ? window['envName'] : this._env.environment;
        const ptUrls = ['cdcpt.cvs.com', 'm-cdcpt.cvs.com'];
        ptUrls.map(function(url){
        if ((window.location.href).indexOf(url) !== -1) {
            headerEnv = window.location.protocol + '//' + window.location.host;
        }
        });
        return new HttpHeaders(
            {
                'ENV': headerEnv,
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            }
        )
    }

    getServiceMethod(serviceName): string {
        let config = serviceConfigs[serviceName];
        return config.method;
    }

}
