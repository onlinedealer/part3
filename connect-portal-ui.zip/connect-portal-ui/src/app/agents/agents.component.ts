import { Component, OnInit, ViewChild } from '@angular/core';
import { DeleteSidebarConfiguration } from '@shared/components/delete-sidebar/delete-sidebar-configuration';
import { MenuItem } from 'primeng/api';
import { Subject } from 'rxjs';
import { first } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { BaseComponent } from '../core/base.component';
import { BreadcrumbItem } from '@shared/components/breadcrumb/breadcrumb-item';
import { TableConfiguration, TableField, TableMessage, TableMessageType } from '@shared/components/generic-table/generic-table';
import { ResourcePermissionService } from '@shared/services/resource-permission.service';
import { AgentSidebarComponent } from './agent-sidebar/agent-sidebar.component';
import { Agent, AGENT_STATUS } from './shared/agent';
import { AgentsApiService } from './shared/agents-api.service';

/**
 * Component for manageing agents
 */
@Component({
  selector: 'p-connect-agents',
  templateUrl: './agents.component.html',
  styleUrls: ['./agents.component.scss']
})
export class AgentsComponent extends BaseComponent implements OnInit {
  @ViewChild(AgentSidebarComponent) agentSidebarComponent: AgentSidebarComponent;

  /**
   * breadcrumb items
   */
  breadcrumbs: BreadcrumbItem[] = [
    { text: 'common.BREADCRUMBS.APP_ROOT', isActive: true },
    { text: 'common.BREADCRUMBS.AGENTS', isActive: true }
  ];

  /**
   * columns to be displayed in the table
   */
  fields: TableField[] = [
    { header: 'agents.AGENTS_TABLE.COLUMNS.HEALTH', name: 'agentUpOrDownStatus', columnStyle: { width: '5rem', minWidth: '5rem' } },
    {
      header: 'agents.AGENTS_TABLE.COLUMNS.NAME',
      name: 'agentName',
      isSearchable: true,
      columnStyle: { width: '18rem', minWidth: '18rem' }
    },
    { header: 'agents.AGENTS_TABLE.COLUMNS.LAST_CHECKIN', name: 'formattedLastCheckinDate', isSearchable: true },
    { header: 'agents.AGENTS_TABLE.COLUMNS.HOST_NAME', name: 'hostName', isSearchable: true },
    { header: 'agents.AGENTS_TABLE.COLUMNS.VERSION', name: 'properties.agentVersion', isSearchable: true },
    { header: 'agents.AGENTS_TABLE.COLUMNS.ID', name: 'agentId', isSearchable: true }
  ];

  /**
   * Empty table message
   */
  emptyTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'agents.AGENTS_TABLE.MESSAGES.NO_AGENTS_CONFIGURED.HEAD',
    messageCaption: 'agents.AGENTS_TABLE.MESSAGES.NO_AGENTS_CONFIGURED.CAPTION'
  };

  /**
   * Empty table message when filter is applied
   */
  filterTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'agents.AGENTS_TABLE.MESSAGES.NO_FILTER_RESULTS.HEAD',
    messageCaption: 'agents.AGENTS_TABLE.MESSAGES.NO_FILTER_RESULTS.CAPTION'
  };

  /**
   * Error table message
   */
  errorTableMessage: TableMessage = {
    messageType: TableMessageType.ALERT,
    messageHead: 'agents.AGENTS_TABLE.MESSAGES.ERROR.HEAD',
    messageCaption: 'agents.AGENTS_TABLE.MESSAGES.ERROR.CAPTION'
  };

  toolbarMenuItems: MenuItem[] = [];

  actionDropdownMenuItems: MenuItem[] = [
    {
      id: 'editMenuItem',
      label: 'common.BUTTONS.EDIT',
      command: (event) => {
        this.isAgentSidebarVisible = true;
        this.agentSidebarComponent.setAgent(event.item.target);
      },
      visible: this.resourcePermissionService.hasResourcePermission('AGENT.EDIT')
    },
    {
      id: 'deleteMenuItem',
      label: 'common.BUTTONS.REMOVE',
      command: (event) => {
        this.deleteSidebarConfiguration.dynamicBodyTextValue = event.item.target.agentName;
        this.deleteSidebarConfiguration.bodyText =
          event.item.target.agentUpOrDownStatus === AGENT_STATUS.UP
            ? 'agents.REMOVE_AGENT_DIALOG.MESSAGE_AGENT_ACTIVE'
            : 'agents.REMOVE_AGENT_DIALOG.MESSAGE_AGENT_INACTIVE';
        this.deleteSidebarConfiguration.isDeleteButtonDisabled = event.item.target.agentUpOrDownStatus === AGENT_STATUS.UP;
        this.deleteSidebarConfiguration.targetItemsTableData = [event.item.target];
        this.deleteSidebarConfiguration.isSidebarVisible = true;
      },
      visible: this.resourcePermissionService.hasResourcePermission('AGENT.DELETE')
    }
  ];

  /**
   * Table configuration.
   */
  tableConfiguration: TableConfiguration = {
    isLoading: false,
    visibleRows: 25,
    isFilterShown: true,
    fields: this.fields,
    styleClass: 'agents-table',
    rowAction: {
      fieldIndex: 1,
      menuItems: this.actionDropdownMenuItems
    },
    hideCheckboxColumn: true,
    tableToolbar: {
      style: { width: '23em', height: '60px' },
      menuItems: this.toolbarMenuItems
    },
    tableMessages: {
      emptyTableMessage: this.emptyTableMessage,
      filterTableMessage: this.filterTableMessage,
      errorTableMessage: this.errorTableMessage
    },
    primaryButtonStyle: 'png-download',
    primaryButtonText: this.resourcePermissionService.hasResourcePermission('AGENT.DOWNLOAD')
      ? 'agents.AGENTS_TABLE.BUTTONS.DOWNLOAD_AGENT'
      : undefined,
    createButtonClicked: () => {
      window.open(environment.agentDownloadURL, '_self');
    },
    autoRefreshTimeInMilliseconds: 30000,
    autoRefreshTimeElapsedEvent: () => {
      this.getAllAgents(false);
    }
  };

  /**
   * Delete complete event handler.
   */
  deleteCompleted: Subject<any> = new Subject<any>();

  /**
   * Configuration for the shared delete dialog
   */
  deleteSidebarConfiguration: DeleteSidebarConfiguration = {
    isSidebarVisible: false,
    isTargetItemsTableHidden: true,
    sidebarTitle: 'agents.REMOVE_AGENT_DIALOG.HEADING',
    bodyText: 'agents.REMOVE_AGENT_DIALOG.MESSAGE_AGENT_INACTIVE',
    dynamicBodyTextValue: '',
    deleteButtonText: 'common.BUTTONS.REMOVE',
    deleteCompletedEvent: this.deleteCompleted.asObservable(),
    deleteButtonClicked: ($event) => {
      this.deleteAgent($event[0]);
    }
  };

  selectedAgents: Agent[];
  agents: Agent[];
  isAgentSidebarVisible = false;

  /** @internal */
  constructor(private readonly agentsApiService: AgentsApiService, private readonly resourcePermissionService: ResourcePermissionService) {
    super();
  }

  /** @internal */
  ngOnInit(): void {
    this.getAllAgents();
  }

  /**
   * Data to be displayed in the table.
   * @param showLoadingIndicator if true, the loading indicator will be shown
   */
  getAllAgents(showLoadingIndicator = true): void {
    this.tableConfiguration.isLoading = showLoadingIndicator;
    this.agentsApiService
      .getAll()
      .pipe(first())
      .subscribe({
        next: (agents) => {
          let data = agents.map((agent: Agent) => {
            return {
              ...agent,
              formattedLastCheckinDate: this.getDateFromEpoch(agent.lastHeartBeatAsLongInMilliSeconds / 1000).toLocaleString()
            };
          });

          this.agents = data;
        }
      })
      .add(() => {
        this.tableConfiguration.isLoading = false;
      });
  }

  /**
   * Delete agent
   * @param agent Agent to be removed
   */
  private deleteAgent(agent: Agent): void {
    this.agentsApiService
      .deleteAgent({
        tenantId: agent.tenantId,
        productName: agent.productName,
        agentIds: [agent.agentId]
      })
      .subscribe({
        next: (response) => {
          this.getAllAgents();
          this.deleteCompleted.next(response);
        },
        error: (error) => {
          this.deleteCompleted.next(error);
        }
      });
  }
}
