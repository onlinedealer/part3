import { TRANSLOCO_CONFIG, translocoConfig, TranslocoModule, TranslocoService } from '@ngneat/transloco';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';
import { NgModule } from '@angular/core';
import { environment } from 'environments/environment';

@NgModule({
  imports: [TranslocoLocaleModule.forRoot()],
  exports: [TranslocoLocaleModule, TranslocoModule],
  providers: [
    {
      provide: TRANSLOCO_CONFIG,
      useValue: translocoConfig({
        availableLangs: ['de', 'en', 'es', 'fr', 'hi', 'iw', 'ja', 'te'],
        defaultLang: 'en',
        fallbackLang: 'en',
        reRenderOnLangChange: true,
        prodMode: environment.production,
        missingHandler: {
          logMissingKey: false,
          useFallbackTranslation: true
        }
      })
    }
  ]
})
export class TranslocoRootModule {
  constructor(transloco: TranslocoService) {
    transloco.setTranslation(
      {
        png: {
          test: {
            navItem1: 'Nav Item 1',
            navItem2: 'Nav Item 2'
          }
        }
      },
      'en'
    );
  }
}
