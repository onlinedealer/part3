import { AfterViewInit, Component, Input, ViewChild } from '@angular/core';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { ChangeTableMappingComponent } from '../change-table-mapping.component';

@Component({
  selector: 'p-connect-change-table-mapping-sidebar',
  templateUrl: './change-table-mapping-sidebar.component.html',
  styleUrls: ['./change-table-mapping-sidebar.component.scss']
})
export class ChangeTableMappingSidebarComponent implements AfterViewInit {
  @Input() baseZIndex = 10000;
  @Input() checkedItems: any[];
  @Input() topics: string[];
  @Input() tableData: string[];
  @Input() setTargetDetails: (row, topic) => void;
  @Input() patchPipeline: () => void;
  @Input() setMappingIcon: (row, topic, topicFound) => void;
  @Input() fields: string[];
  @Input() getSubjectDetails: (row) => void;
  @Input() setTopicSubject: (row, subject) => void;

  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(ChangeTableMappingComponent) changeTableMapping: ChangeTableMappingComponent;

  cancelButton: SidebarButton = {
    id: 'cancelButton',
    text: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.CANCEL_BUTTON'
  };
  applyButton: SidebarButton = {
    id: 'applyButton',
    text: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.APPLY_BUTTON',
    isDisabled: true
  };

  constructor() {}

  ngAfterViewInit() {
    this.changeTableMapping.getPrimaryObject(this.applyButton);
  }

  open() {
    this.sidebarComponent.open();
  }

  cancelSidebarButtonClicked() {
    this.sidebarComponent.close();
  }

  onApplyClicked() {
    this.changeTableMapping.onApply();
  }
}
