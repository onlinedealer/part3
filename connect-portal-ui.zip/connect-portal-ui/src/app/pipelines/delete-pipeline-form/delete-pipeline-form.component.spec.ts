import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';

import { DeletePipelineFormComponent } from './delete-pipeline-form.component';

describe('DeletePipelineFormComponent', () => {
  let component: DeletePipelineFormComponent;
  let fixture: ComponentFixture<DeletePipelineFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [DeletePipelineFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DeletePipelineFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the stop pipeline sidebar when clicking the stop button', () => {
    spyOn(component.stopPipelineButtonClickEvent, 'emit');
    component.stopPipelineButtonClicked();
    expect(component.stopPipelineButtonClickEvent.emit).toHaveBeenCalled();
  });

  it('should open the manage capture sidebar when clicking the manage capture button', () => {
    spyOn(component.manageCaptureButtonClickEvent, 'emit');
    component.manageCaptureButtonClicked();
    expect(component.manageCaptureButtonClickEvent.emit).toHaveBeenCalled();
  });

  it('should open the clear backlog sidebar when clicking the clear backlog button', () => {
    spyOn(component.clearBacklogButtonClickEvent, 'emit');
    component.clearBacklogButtonClicked();
    expect(component.clearBacklogButtonClickEvent.emit).toHaveBeenCalled();
  });
});
