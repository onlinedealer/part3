import React from 'react'
import { Link } from 'react-router-dom'
import apiConfig from '../../config/apiConfig'
import ListItem from '@material-ui/core/ListItem'
import ListItemIcon from '@material-ui/core/ListItemIcon'
import ListItemText from '@material-ui/core/ListItemText'
import Search from '@material-ui/icons/Search'
import Home from '@material-ui/icons/Home'
import AccountBox from '@material-ui/icons/AccountBox'
import Help from '@material-ui/icons/Help'

let menuDefinitions = []
const getmenu = (props) => {
  menuDefinitions = [
    { title: 'HOME', to: apiConfig.lpLinks.home, exact: true, linkTarget: '_self', icon: <Home className={props.color} /> },
    { title: 'SEARCH', to: apiConfig.lpLinks.search, exact: true, linkTarget: '_self', icon: <Search className={props.color} /> },
    { title: 'HELP CENTER', to: apiConfig.lpLinks.help, exact: true, linkTarget: '_self', icon: <Help className={props.color} /> },
    { title: 'Logout', to: '/logout', icon: <AccountBox className={props.color} /> },
  ]
}

const MailFolderListItems = (props) => {
  getmenu(props)
  return (<div>
    {menuDefinitions.map((option, keyOption) => {
      return (
        <ListItem button key={keyOption} component={Link} to={option.to} className={props.bg} target={option.linkTarget}>
          <ListItemIcon>
            {option.icon}
          </ListItemIcon>
          <ListItemText classes={{ primary: props.color }}>{option.title}</ListItemText>
        </ListItem>
      )
    })}
  </div>)
}
// className={props.styles}
export default MailFolderListItems
