import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { AuthModule } from 'angular-auth-oidc-client';
import { Connection } from '../../../../connections/shared/connection';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { SharedModule } from '../../../../shared/shared.module';
import { DB2MetabaseFormComponent } from './db2-metabase-form.component';

describe('DB2MetabaseFormComponent', () => {
  let component: DB2MetabaseFormComponent;
  let fixture: ComponentFixture<DB2MetabaseFormComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [DB2MetabaseFormComponent],
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule, AuthModule.forRoot({}), RouterModule.forRoot([]), SharedModule],
      providers: [
        {
          provide: TRANSLOCO_SCOPE,
          useValue: { scope: 'metabases' }
        },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DB2MetabaseFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the database server control value if a data connection is passed', () => {
    component.dataConnection = { database: 'test', port: 50000 } as Connection;
    component.ngOnInit();
    expect(component.db2MetabaseForm.get('databaseServer').value).toBe('test:50000');
  });

  it('should NOT set the database server control value if a data connection is NOT passed', () => {
    component.ngOnInit();
    expect(component.db2MetabaseForm.get('databaseServer').value).toBe('');
  });

  it('should return a metabase object from the form', () => {
    component.ngOnInit();
    component.db2MetabaseForm.patchValue({
      replicationUserID: 'sa',
      replicationPassword: ''
    });
    component.db2MetabaseForm.addControl('dataConnection', new FormControl('1'));
    const metabase = component.metabase;
    expect(metabase.parameters.length).toBe(2);
  });

  it('should not clear validators if form does not exist', () => {
    component.db2MetabaseForm = null;
    component.ngOnDestroy();
    expect(component.db2MetabaseForm).toBeNull();
  });
});
