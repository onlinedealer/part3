import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { Observable } from 'rxjs';
import { PipelineService } from '../pipeline.service';
import { Pipeline } from './pipeline';

@Injectable()
export class PipelineResolverService implements Resolve<Pipeline> {
  constructor(private readonly pipelineService: PipelineService) {}
  resolve(route: ActivatedRouteSnapshot): Observable<Pipeline> {
    return this.pipelineService.loadPipeline(route.params.id);
  }
}
