import { Component, Input, EventEmitter, Output, OnChanges, SimpleChanges } from "@angular/core";
import { MeteringVO, MeteringVOStatusIndicator } from "../../../models/view-objects/metering-vo.model";
import { slideCloseOpenAnimation } from "../../../../Shared/Animations/slide-close-open.animation";
import { MeteringsSorter } from "./meterings-sorter";
import { TranslationsService } from "../../../../app/services/translations-service";
import { SorterService } from "../../../../Shared/services/sorter.service";
import { Observable } from "rxjs";

@Component({
    selector: "landisgyr-meterings-list",
    templateUrl: "./meterings-list.component.html",
    styleUrls: ["./meterings-list.component.scss"],
    animations: slideCloseOpenAnimation()
})
export class MeteringsListComponent implements OnChanges {
    @Input()
    meterings!: MeteringVO[];

    @Input()
    title!: string;

    @Input()
    IsTheOnlyMeteringType!: boolean;

    @Output()
    meteringSelected: EventEmitter<{ meteringPointId: number; meteringId: number; meteringType: string }> = new EventEmitter();

    meteringsSorter: MeteringsSorter;
    sortedMeterings$: Observable<MeteringVO[]>;

    contentOpen = "open";

    infoMessage = $localize`:|@@meteringsList.noMeteringsFound:No meterings found`;

    statusMessages = {
        // tslint:disable-next-line:max-line-length
        inRegistersWithValidUntil: $localize`:|@@meteringsList.meteringInRegistersWithValidUntil:Was connected to a device but is not anymore`,
        inRegisters: $localize`:|@@meteringsList.meteringInRegistersNeverConnected:Has never been connected to a device`,
        inRegistersAndDevices: $localize`:|@@meteringsList.meteringInRegistersAndDevices:Metering is connected to a device`,
        inRegistersMarkedDelete: $localize`:|@@meteringsList.meteringInRegistersMarkedDelete:Connection to the device has been cancelled`,
        active: $localize`:|@@ssRegisters.statusActive:Active`,
        inactive: $localize`:|@@ssRegisters.statusInactive:Inactive`,
        calculated: $localize`:|@@meteringsList.calculated:Calculated`,
        typeCurve: $localize`:|@@meteringsList.typeCurve:Type curve`,
        temperatureCurve: $localize`:|@@meteringsList.temperatureCurve:Temperature curve`
    };

    constructor(public translations: TranslationsService, private sorter: SorterService) {
        this.meteringsSorter = new MeteringsSorter(sorter);
        this.sortedMeterings$ = this.meteringsSorter.getSortedMeterings();
    }

    getTooltipText(metering: MeteringVO) {
        if (
            metering.meteringType !== null &&
            metering.meteringType !== undefined &&
            (metering.meteringType === "CALCULATED" ||
                metering.meteringType === "TYPE_CURVE" ||
                metering.meteringType === "TEMPERATURE_CURVE")
        ) {
            switch (metering.meteringType) {
                case "CALCULATED":
                    return this.statusMessages.calculated;
                case "TYPE_CURVE":
                    return this.statusMessages.typeCurve;
                case "TEMPERATURE_CURVE":
                    return this.statusMessages.temperatureCurve;
                default:
                    return metering.active ? this.statusMessages.active : this.statusMessages.inactive;
            }
        } else {
            switch (metering.meteringStatusIndicators) {
                case MeteringVOStatusIndicator.InRegistersWithValidUntil:
                    return this.statusMessages.inRegistersWithValidUntil;
                case MeteringVOStatusIndicator.InRegisters:
                    return this.statusMessages.inRegisters;
                case MeteringVOStatusIndicator.InRegistersAndDevices:
                    return this.statusMessages.inRegistersAndDevices;
                case MeteringVOStatusIndicator.InRegistersMarkedDelete:
                    return this.statusMessages.inRegistersMarkedDelete;
                default:
                    return metering.active ? this.statusMessages.active : this.statusMessages.inactive;
            }
        }
    }

    getClass(metering: MeteringVO) {
        switch (metering.meteringStatusIndicators) {
            case MeteringVOStatusIndicator.InRegistersWithValidUntil:
                return "status status-dark-grey";
            case MeteringVOStatusIndicator.InRegisters:
                return "status status-grey";
            case MeteringVOStatusIndicator.InRegistersAndDevices:
                return "status status-green";
            case MeteringVOStatusIndicator.InRegistersMarkedDelete:
                return "status status-orange";
            default:
                return metering.active ? "status status-forest-green" : "status status-invalid-type";
        }
    }
    ngOnChanges(changes: SimpleChanges) {
        this.meteringsSorter.setMeterings(this.meterings);
    }

    onSelectMetering(metering: MeteringVO) {
        this.meteringSelected.emit({
            meteringPointId: metering.meteringPointId,
            meteringId: metering.id,
            meteringType: metering.type
        });
    }

    toggleContent() {
        this.contentOpen = this.contentOpen === "open" ? "closed" : "open";
    }

    isCollapsed() {
        return this.contentOpen === "closed";
    }
}
