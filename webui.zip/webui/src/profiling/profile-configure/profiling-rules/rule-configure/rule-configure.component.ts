import { Component, EventEmitter, OnInit, Input, Output, ViewChild } from '@angular/core';
import { ProfileRuleModel } from 'profiling/profile-rule.model';
import { ProfilingRuleOptionType } from '../profiling-rule-option-type.enum';

@Component({
  selector: 'discovery-profiling-rule-configure',
  templateUrl: './rule-configure.component.html',
  styleUrls: ['./rule-configure.component.css']
})
export class RuleConfigureComponent {
  @Input() ruleModelForConfiguration: ProfileRuleModel;
  @Input() showRuleSettingsSideBar: boolean;
  @Output() showRuleSettingsSideBarChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() ruleModelForConfigurationChange: EventEmitter<ProfileRuleModel> = new EventEmitter<ProfileRuleModel>();

  configuredOptionValues = new Map<string, any>();

  ProfilingRuleOptionType = ProfilingRuleOptionType;

  save() {
    this.ruleModelForConfiguration.ruleConfigurationOptions.forEach((ruleConfigurationOption) => {
      if (this.configuredOptionValues.has(ruleConfigurationOption.id)) {
        ruleConfigurationOption.configuredOptionValue = this.configuredOptionValues.get(ruleConfigurationOption.id);
      }
    });
    this.ruleModelForConfigurationChange.emit(this.ruleModelForConfiguration);
    this.showRuleSettingsSideBarChange.emit(false);
  }

  cancel() {
    this.configuredOptionValues.clear();
    this.showRuleSettingsSideBarChange.emit(false);
  }
}
