export class SubscriptionModel {
    public price: number;
    public subscriptionType: string;
    public skuId: string;
    public taxProductCode: string;
    public listPrice: number;
    public discount: number;
    public displayPriority: string;

    constructor(details: any) {
        const subscription = details;
        this.price = subscription.price;
        this.subscriptionType = subscription.subscriptionType;
        this.skuId = subscription.skuId;
        this.taxProductCode = subscription.taxProductCode;
        this.listPrice = subscription.listPrice;
        this.discount = subscription.discount;
        this.displayPriority = subscription.displayPriority;
    }
}
