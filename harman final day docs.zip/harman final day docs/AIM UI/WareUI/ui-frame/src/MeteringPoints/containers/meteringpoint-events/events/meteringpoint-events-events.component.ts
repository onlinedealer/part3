import { Component, OnDestroy, Input, OnInit, ViewChild, TemplateRef, Output, EventEmitter } from "@angular/core";
import { DateFormatService, DateFormats } from "../../../../Shared/services/date-format.service";
import { EventsActions, ExportDataActions } from "../../../store/actions";
import { EventsSelectors, MeteringPointsUISelectors, EventDefinitionsSelectors } from "../../../store/selectors";
import { EventVO } from "../../../models/view-objects/event-vo.model";
import { FormControl, FormGroup } from "@angular/forms";
import { getSelectedEventDefinitionPlaceholderText } from "./selected-eventdefinitions-placeholder.selector";
import { cloneDeep } from "lodash";
import { map, debounceTime } from "rxjs/operators";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { Observable, Subscription } from "rxjs";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { Store } from "@ngrx/store";
import { ToastMessageComponent } from "../../../../Shared/modules/toast/toast-message.component";
import { ToastRef } from "../../../../Shared/modules/toast/toast-ref";
import { ToastService } from "../../../../Shared/modules/toast";
import { TranslationsService } from "../../../../app/services/translations-service";
import { trigger, state, style, transition, animate } from "@angular/animations";
import { ExportDataColHeaderService } from "../../../services/export-data-col-header.service";
import { ExportTableDataService } from "../../../services/export-data.service";
import { LocalStorageKeys, LocalStorageService } from "../../../../app/services/local-storage.service";
import { MatDialog } from "@angular/material/dialog";
import { EditColumnDialogComponent } from "../../../components/edit-column-dialog/edit-column-dialog.component";

interface ColumnTitles {
    [key: string]: string;
}

@Component({
    selector: "landisgyr-meteringpoint-events-events-container",
    templateUrl: "./meteringpoint-events-events.component.html",
    styleUrls: ["./meteringpoint-events-events.component.scss"],
    animations: [
        trigger("openCloseSideView", [
            // ...
            state(
                "closed",
                style({
                    width: "100%"
                })
            ),
            state(
                "open",
                style({
                    width: "66.67%"
                })
            ),
            transition("closed => open", [animate("0.2s")]),
            transition("open => closed", [animate("0.2s")])
        ])
    ]
})
export class MeteringPointEventsEventsComponent implements OnInit, OnDestroy {
    @ViewChild("toastMessageOrigin")
    toastMessageOrigin!: HTMLElement;

    @ViewChild("toastmessage", { static: true })
    toastMessage!: TemplateRef<any>;

    @ViewChild("alarmFlag") alarmFlag!: TemplateRef<any>;

    @ViewChild("eventTypeContextMenu") eventTypeContextMenu!: TemplateRef<any>;

    @ViewChild("eventContextMenu") eventContextMenu!: TemplateRef<any>;

    @Input()
    meteringPoint!: MeteringPoint;

    @Input()
    selectedTimeRange!: any;

    @Input()
    selectedTimeRangeRadio!: string;

    @Input()
    selectedEvent!: EventVO;

    @Input()
    allEventDefinition!: any;

    @Output()
    eventSelected = new EventEmitter<{ meteringPointId: number; eventId: number }>();

    @Output()
    eventSideviewClosed = new EventEmitter<number>();

    currentToast!: ToastRef;

    events$: Observable<EventVO[]> = this.store.select(EventsSelectors.getEventsSortedAndPaginatedForTable).pipe(
        map((events) => {
            return events.map((event) => {
                return {
                    ...event,
                    savingTime: this.formatService.toLocaleString(event.savingTime, DateFormats.DATETIME),
                    eventTime: this.formatService.toLocaleString(event.eventTime, DateFormats.DATETIME)
                };
            });
        })
    );

    eventsForExport$: Observable<any> = this.store.select(EventsSelectors.getEventsExportData).pipe(
        map((events) => {
            return events.map((event: any) => {
                return {
                    ...event,
                    savingTime: this.formatService.toLocaleString(event.savingTime, DateFormats.DATETIME),
                    eventTime: this.formatService.toLocaleString(event.eventTime, DateFormats.DATETIME)
                };
            });
        })
    );

    eventsCount$: Observable<number> = this.store.select(EventsSelectors.getSelectedMeteringPointFilteredEventsCount);
    eventsTablePageCount$: Observable<number> = this.store.select(EventsSelectors.getEventsTablePagesCount);
    eventsTablePage$: Observable<number> = this.store.select(EventsSelectors.getEventsPage);
    selectedEventFiltersPlaceholderText$: Observable<any> = this.store.select(getSelectedEventDefinitionPlaceholderText);
    eventsLoading$: Observable<boolean> = this.store.select(EventsSelectors.getSelectedMeteringPointEventsLoading);
    showUndo$: Observable<number> = this.store.select(EventDefinitionsSelectors.getUndoEventCount);
    showRedo$: Observable<number> = this.store.select(EventDefinitionsSelectors.getRedoEventCount);
    eventsRadioButtonData$: Observable<string> = this.store.select(EventsSelectors.getEventsTimeRangeRadio);

    showCategories = false;
    showUndo!: boolean;
    eventDataDateFrom = new FormControl();
    eventDataDateTo = new FormControl();
    infoMessage = this.translations.getTranslation("No data available for the selected time period");

    filterFormSub!: Subscription;
    localStorageSubscription!: Subscription;
    columnConfigInitialSubs!: Subscription;
    eventsColumnConfig: any;
    changed = false;
    exportData!: any;
    selectedEventId!: number | undefined;

    TABLE_COLUMN_TITLES: ColumnTitles = {
        eventTime: this.translations.getTranslation("Time"),
        name: this.translations.getTranslation("Event"),
        eventType: this.translations.getTranslation("Type"),
        description: this.translations.getTranslation("Description"),
        AlarmFlag: this.translations.getTranslation("Alarm flag")
    };

    // tslint:disable-next-line: max-line-length
    toastMessageSubCategoryChanged = $localize`:|Toast message that is shown when user filters events based on a specific events type shown on the table.@@pqiView.toastmessage.filterchanged:Selected filter was changed`;

    filterForm: FormGroup = new FormGroup({
        filter: new FormControl("")
    });

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private formatService: DateFormatService,
        private toastService: ToastService,
        public translations: TranslationsService,
        private exportDataColHeaderService: ExportDataColHeaderService,
        public exportTableDataService: ExportTableDataService,
        private localStorage: LocalStorageService,
        private dialog: MatDialog
    ) {}

    ngOnInit() {
        this.localStorageSubscription = this.localStorage.changedColumnInfo.subscribe((data) => {
            if (data.key === LocalStorageKeys.eventTime) {
                this.changed = true;
                this.eventsColumnConfig = data.value;
            }
        });
        if (!this.changed) {
            if (this.localStorage.getColumnConfiguration(LocalStorageKeys.eventTime)) {
                this.eventsColumnConfig = this.localStorage.getColumnConfiguration(LocalStorageKeys.eventTime);
            } else {
                this.columnConfigInitialSubs = this.store
                    .select(MeteringPointsUISelectors.getEventsColumnConfigInitial)
                    .subscribe((data) => {
                        this.eventsColumnConfig = data;
                    });
            }
        }
        this.filterFormSub = this.filterForm.valueChanges
            .pipe(
                map((val: { filter: string }) => val.filter),
                debounceTime(500)
            )
            .subscribe((searchTerm) => this.store.dispatch(EventsActions.SearchFromFilterTree({ searchTerm })));
        this.eventsForExport$.subscribe((data) => (this.exportData = data));
    }

    ngOnDestroy(): void {
        if (this.filterFormSub) {
            this.filterFormSub.unsubscribe();
        }
        if (this.localStorageSubscription) {
            this.localStorageSubscription.unsubscribe();
        }
        if (this.columnConfigInitialSubs) {
            this.columnConfigInitialSubs.unsubscribe();
        }
    }

    onSelect(event: EventVO) {
        this.eventSelected.emit({
            meteringPointId: this.meteringPoint.id,
            eventId: event.id
        });
        this.selectedEventId = event.id;
    }
    onClose() {
        this.eventSideviewClosed.emit(this.meteringPoint.id);
        this.selectedEventId = undefined;
    }
    onShowCategories() {
        this.showCategories = !this.showCategories;
    }

    showOnlyThisType(event: EventVO) {
        this.store.dispatch(EventsActions.AddToUndoEvent());
        this.store.dispatch(EventsActions.ShowEventOfSelectedType({ event }));
        this.showSubCategoryChangeToastMessage();
    }
    showOnlyThisEventCategory(event: EventVO) {
        this.store.dispatch(EventsActions.AddToUndoEvent());
        this.store.dispatch(EventsActions.ShowEventOfSelectedEvent({ event }));
        this.showSubCategoryChangeToastMessage();
    }
    hideOnlyThisEventCategory(event: EventVO) {
        this.store.dispatch(EventsActions.AddToUndoEvent());
        this.store.dispatch(EventsActions.HideEventOfSelectedEvent({ event }));
        this.showSubCategoryChangeToastMessage();
    }
    hideThisType(event: EventVO) {
        this.store.dispatch(EventsActions.AddToUndoEvent());
        this.store.dispatch(EventsActions.HideEventOfSelectedType({ event }));
        this.showSubCategoryChangeToastMessage();
    }
    onPageChange(page: number): void {
        this.store.dispatch(EventsActions.SetEventsTablePage({ page }));
    }
    onSortChange(sortOrder: SortOrder): void {
        this.store.dispatch(EventsActions.SetEventsTableSorting({ sortOrder }));
    }
    onUndoClick() {
        this.store.dispatch(EventsActions.UndoEventFilter());
        this.showSubCategoryChangeToastMessage();
    }
    onRedoClick() {
        this.store.dispatch(EventsActions.RedoEventFilter());
        this.showSubCategoryChangeToastMessage();
    }

    showSubCategoryChangeToastMessage() {
        this.currentToast = this.toastService.replaceToast(
            this.currentToast,
            {
                component: ToastMessageComponent,
                componentData: {
                    message: this.toastMessageSubCategoryChanged,
                    icon: "info"
                }
            },
            {
                origin: this.toastMessageOrigin,
                positions: [
                    {
                        originX: "start",
                        originY: "top",
                        overlayX: "start",
                        overlayY: "top"
                    }
                ]
            }
        );
    }
    onEventsExportDataClick() {
        const exportData: any[] = cloneDeep(this.exportData);
        const data = {
            fileName: this.meteringPoint.name + "_events",
            results: exportData,
            header: this.exportDataColHeaderService.eventsHeaderObj,
            includePageRange: true,
            includeTimeRange: false
        };
        this.store.dispatch(ExportDataActions.OpenExportTableDialog({ data: data }));
    }

    openEditColumnDialog() {
        this.dialog.open(EditColumnDialogComponent, {
            width: "550px",
            maxWidth: "550px",
            height: "620px",
            maxHeight: "620px",
            data: {
                results: [],
                header: this.eventsColumnConfig,
                tabSelectionFlag: "eventTime"
            }
        });
    }
}
