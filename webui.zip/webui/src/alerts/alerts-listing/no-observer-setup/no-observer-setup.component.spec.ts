import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TranslocoModule } from '@ngneat/transloco';

import { NoObserverSetupComponent } from './no-observer-setup.component';

describe('NoObserverSetupComponent', () => {
  let component: NoObserverSetupComponent;
  let fixture: ComponentFixture<NoObserverSetupComponent>;
  let elementSelector: any;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [NoObserverSetupComponent],
      imports: [CommonModule, TranslocoModule]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(NoObserverSetupComponent);
    component = fixture.componentInstance;
    elementSelector = fixture.debugElement.nativeElement;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display those messages when there is no observer', () => {
    component.hasObserver = false;
    fixture.detectChanges();
    const welcomeMessage1 = elementSelector.querySelector('#alert-noobserver-welcome-message1');
    const welcomeMessage2 = elementSelector.querySelector('#alert-noobserver-welcome-message2');
    const createObserverButton = elementSelector.querySelector('#create-observer-button');
    const hasObserverMessageSection = elementSelector.querySelector('#observer-message-section');
    expect(welcomeMessage1).not.toBeNull();
    expect(welcomeMessage2).not.toBeNull();
    expect(createObserverButton).not.toBeNull();
    expect(hasObserverMessageSection).toBeNull();
  });

  it('should display those messages when there is observer but no alerts', () => {
    component.hasObserver = true;
    fixture.detectChanges();
    const welcomeMessage1 = elementSelector.querySelector('#alert-noobserver-welcome-message1');
    const welcomeMessage2 = elementSelector.querySelector('#alert-noobserver-welcome-message2');
    const createObserverButton = elementSelector.querySelector('#create-observer-button');
    const hasObserverMessageSection = elementSelector.querySelector('#observer-message-section');
    expect(welcomeMessage1).toBeNull();
    expect(welcomeMessage2).toBeNull();
    expect(createObserverButton).toBeNull();
    expect(hasObserverMessageSection).not.toBeNull();
  });

  it('should display four messages when there is observer but no alerts', () => {
    component.hasObserver = true;
    fixture.detectChanges();
    const messageCount = elementSelector.querySelectorAll('#observer-message-section p');
    expect(messageCount.length).toBe(4);
  });
});
