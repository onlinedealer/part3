import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { BaseApiService } from './base-api.service';

/**
 * Abstract class that provides basic CRUD endpoints
 * Any service that interacts with the Connect API should extend this base service
 * e.g. export class ServersService extends BaseConnectService<Server>
 */
export abstract class BaseConnectApiService<T> extends BaseApiService<T> {
  constructor(protected httpClient: HttpClient, protected url?: string) {
    super(httpClient, environment.connectApiBaseURL, url);
  }
}
