import { DatePipe } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';

import { CatalogingErrorFormComponent } from './cataloging-error-form.component';

describe('CatalogingErrorFormComponent', () => {
  let component: CatalogingErrorFormComponent;
  let fixture: ComponentFixture<CatalogingErrorFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [DatePipe],
      imports: [getTranslocoModule()],
      declarations: [CatalogingErrorFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CatalogingErrorFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('returning values for template', () => {
    it('should return the message', () => {
      component.errorMessage = { message: 'error' };
      expect(component.messageText).toBe('error');
      component.errorMessage = { message: '' };
      expect(component.detailedMessageText).toBe('-');
    });

    it('should return the status', () => {
      component.errorMessage = { status: 500 };
      expect(component.statusText).toBe(500);
      component.errorMessage = { status: '' };
      expect(component.statusText).toBe('-');
    });

    it('should return the path', () => {
      component.errorMessage = { path: '/error' };
      expect(component.pathText).toBe('/error');
      component.errorMessage = { path: '' };
      expect(component.pathText).toBe('-');
    });

    it('should return the timestamp', () => {
      component.errorMessage = { timeStamp: '2022-08-16 17:27:44' };
      expect(component.timestampText).toBe('2022-08-16 17:27:44');
      component.errorMessage = { timeStamp: '' };
      expect(component.timestampText).toBe('-');
    });

    it('should return the detailed message', () => {
      component.errorMessage = { detailedMessage: 'error' };
      expect(component.detailedMessageText).toBe('error');
      component.errorMessage = { detailedMessage: '' };
      expect(component.detailedMessageText).toBe('-');
    });

    it('should return error text', () => {
      component.errorMessage = { error: 'schema not cataloged' };
      expect(component.errorTypeText).toBe('schema not cataloged');
      component.errorMessage = { error: '' };
      expect(component.errorTypeText).toBe('-');
    });
  });
});
