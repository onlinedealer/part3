import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { Observable, of } from 'rxjs';
import { catchError, first } from 'rxjs/operators';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { Connection } from '../../../../connections/shared/connection';
import { BaseComponent } from '../../../../core/base.component';
import { PIPELINE_ENTITY_TYPE } from '../../shared/pipeline';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { LogReader } from '../shared/logreader';
import { LogReadersApiService } from '../shared/logreaders-api.service';

/**
 * Source general component
 */
@Component({
  selector: 'p-connect-source-general',
  templateUrl: './source-general.component.html',
  styleUrls: ['./source-general.component.scss']
})
export class SourceGeneralComponent extends BaseComponent implements OnInit, OnChanges {
  /**
   * Source data connection
   */
  @Input() sourceDataConnection: Connection;

  /**
   * Source data connection catalog status
   */
  sourceCatalogStatus$: Observable<CatalogStatus>;

  /**
   * Event when the configuation button is clicked
   */
  @Output() configurationClickEvent = new EventEmitter();
  /**
   * Event when the selected log reader changes
   */
  @Output() selectedLogReaderChanged = new EventEmitter<LogReader>();

  // source data connection type friendly name
  connectionTypeFriendlyName: string;
  logReadersList: { label: string; value: LogReader }[] = [];
  selectedLogReader: LogReader = null;

  isManageCatalogSidebarVisible = false;

  constructor(
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly logReadersApiService: LogReadersApiService,
    private readonly catalogApiService: CatalogApiService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly changeDectorRef: ChangeDetectorRef
  ) {
    super();
  }

  ngOnInit(): void {
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.connectionTypeFriendlyName = this.sourceDataConnection.connectionType;
    } else {
      this.connectionTypeFriendlyName = `connections.CONNECTION_TYPES.${this.sourceDataConnection.connectionType}`;
    }

    if (this.areLogReadersRequired()) {
      this.getLogReaders();
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.sourceDataConnection.currentValue) {
      this.sourceCatalogStatus$ = this.catalogApiService.status(this.sourceDataConnection.id, false).pipe(catchError(() => of(null)));
    }
  }

  catalogButtonClicked(): void {
    this.isManageCatalogSidebarVisible = true;
  }

  configurationButtonClicked(): void {
    this.configurationClickEvent.emit();
  }

  isDB2I(): boolean {
    return this.sourceDataConnection.connectionType === 'DB2I';
  }

  getLogReaders(): void {
    if (this.sourceDataConnection.connectionType === 'DB2I') {
      this.logReadersList.length = 0;
      this.logReadersList.push({ label: 'Autogenerate', value: { name: 'Autogenerate', journalName: '' } });
    }
    this.logReadersApiService
      .getLogReaders(this.sourceDataConnection.id, this.pipelineEntityService.getPipeline().projectId)
      .pipe(first())
      .subscribe({
        next: (logReaders) => {
          const logReadersList = logReaders.map((logReader: LogReader) => {
            return {
              label: logReader.name,
              // we could save all the log reader info, but there is no need to carry around the parameters
              value: { name: logReader.name, journalName: logReader.journalName }
            };
          });
          this.logReadersList = this.logReadersList.concat(logReadersList);
          this.loadProperties();

          this.changeDectorRef.markForCheck();
        }
      });
  }
  isLogreaderConfigured(): string {
    if (this.logReadersList.length === 0) {
      return 'Not Configured';
    } else {
      return 'UDBCS1';
    }
  }
  areLogReadersRequired(): boolean {
    return (
      (this.sourceDataConnection.connectionType === 'DB2I' || this.sourceDataConnection.connectionType === 'DB2') &&
      this.pipelineEntityService.getPipeline().dataFlowType !== 'COPY'
    );
  }

  onLogReaderChange(selectedLogReader): void {
    this.selectedLogReaderChanged.emit(selectedLogReader.value);
  }

  private loadProperties(): void {
    const properties = this.pipelineEntityService.getPipeline().properties;

    if (properties) {
      if (this.sourceDataConnection.connectionType === 'DB2I') {
        this.selectLogReader(this.getParameterValue(properties, 'IBMI_LOG_READER_NAME'));
      } else if (this.sourceDataConnection.connectionType === 'DB2') {
        this.selectLogReader(this.getParameterValue(properties, 'LUW_LOG_READER_NAME'));
      }
    }
  }

  /**
   * Returns the found log reader, if not it returns null
   */
  private getLogReader(logReaderName: string): LogReader {
    const selectedLogReader = this.logReadersList.find((logReader) => logReader.value.name === logReaderName);
    return selectedLogReader ? selectedLogReader.value : null;
  }

  private selectLogReader(logReaderName: string): void {
    this.selectedLogReader = this.getLogReader(logReaderName);
    if (this.selectedLogReader) {
      this.selectedLogReaderChanged.emit(this.selectedLogReader);
    }
  }
}
