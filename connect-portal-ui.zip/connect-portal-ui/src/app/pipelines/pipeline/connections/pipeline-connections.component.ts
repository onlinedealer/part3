import { Component, ComponentFactoryResolver, ComponentRef, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { FeatureFlagService } from 'src/app/shared/services/feature-flag.service';
import { environment } from '../../../../environments/environment';
import { Connection } from '../../../connections/shared/connection';
import { BaseComponent } from '../../../core/base.component';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { DynamicHostDirective } from '../../../shared/directives/dynamic-host.directive';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { targetConnectionMap } from './target-connections/target-connection';
import { PIPELINE_ENTITY_TYPE } from '../shared/pipeline';

@Component({
  selector: 'p-connect-connections',
  templateUrl: './pipeline-connections.component.html'
})
export class PipelineConnectionsComponent extends BaseComponent implements OnInit, OnDestroy {
  @Input() targetConnectionType: string;

  connectionsForm: FormGroup;
  selectedSourceConnection: Connection;
  selectedTargetConnection: Connection;
  visibleConnectionTypes: { connectionType: string; accessMethods: string[] }[];
  visibleTargetConnectionTypes: { connectionType: string; accessMethods: string[] }[];

  @ViewChild(DynamicHostDirective, { static: true })
  dynamicHost!: DynamicHostDirective;

  childComponentReference: ComponentRef<any>;

  private unsubscribeSignal$ = new Subject<void>();
  private sourceConnectionType: string;

  readonly PIPELINE_TYPE = PIPELINE_ENTITY_TYPE;

  get pipelineType(): string {
    return this.pipelineEntityService.pipelineEntityType;
  }

  constructor(
    public readonly router: Router,
    private readonly componentFactoryResolver: ComponentFactoryResolver,
    private readonly formBuilder: FormBuilder,
    private readonly progressIndicatorStateService: ProgressIndicatorStateService,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly featureFlagService: FeatureFlagService
  ) {
    super();
  }

  ngOnDestroy() {
    this.unsubscribeSignal$.next();
    this.unsubscribeSignal$.complete();
  }

  ngOnInit(): void {
    this.filterVisibleConnectionTypes();
    this.filterVisibleTargetConnectionTypes();
    this.createForm();
    this.initializeNextButtonState();
  }

  createTargetChildComponent() {
    const targetComponent = targetConnectionMap.get(this.targetConnectionType);
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(targetComponent);
    if (this.pipelineEntityService.pipelineEntityType !== PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.dynamicHost.viewContainerRef.clear();
      this.childComponentReference = this.dynamicHost.viewContainerRef.createComponent(componentFactory);
      this.childComponentReference.instance.sourceConnectionType = this.sourceConnectionType;
    }
    this.loadAndSetPipelineConnection();
  }

  selectTargetConnectionType(targetConnection) {
    this.targetConnectionType = targetConnection.connectionType;
    this.createTargetChildComponent();
  }

  private filterVisibleConnectionTypes(): void {
    let sourceTypes = [...environment.supportedSourceConnectionTypes];

    // Synchronization data flow types are not supported by DB2ZOS, so remove them as a supported type
    if (this.pipelineEntityService.getPipeline().dataFlowType === 'SYNCHRONIZE') {
      sourceTypes = sourceTypes.filter((type) => type.connectionType !== 'DB2ZOS');
    }

    // If flag is not present, remove connection type
    if (!this.featureFlagService.isFeatureEnabled('CDCEnableDB2LUWTemp20220407')) {
      sourceTypes = sourceTypes.filter((type) => type.connectionType !== 'DB2');
    }
    if (!this.featureFlagService.isFeatureEnabled('CDCEnableSQLTemp20220407')) {
      sourceTypes = sourceTypes.filter((type) => type.connectionType !== 'SQLSERVER');
    }

    this.visibleConnectionTypes = sourceTypes;
  }

  private filterVisibleTargetConnectionTypes(): void {
    this.visibleTargetConnectionTypes = environment.supportedTargetConnectionTypes.filter(
      (supportedConnectionType) => supportedConnectionType.connectionType !== 'SCHEMAREGISTRY'
    );
    if (!this.featureFlagService.isFeatureEnabled('CDCKafkaSchemaRegistryTemp20220628')) {
      if (this.visibleConnectionTypes.find((connection) => connection.connectionType === 'SCHEMAREGISTRY')) {
        this.visibleTargetConnectionTypes.splice(
          this.visibleTargetConnectionTypes.findIndex((connection) => connection.connectionType === 'SCHEMAREGISTRY')
        );
      }
    }
  }

  private readonly createForm = (): void => {
    this.connectionsForm = this.formBuilder.group({
      dataConnections: this.formBuilder.group({}),
      targetConnectionOptions: this.formBuilder.group({})
    });
  };

  get pipelineConnectionsObject() {
    // create a loose object so we can add any property to it
    let connections: { [key: string]: any } = {};

    if (this.connectionsForm.get('dataConnections.sourceConnection').value) {
      connections.source = {
        dataConnection: this.connectionsForm.get('dataConnections.sourceConnection').value,
        selectedTables: this.pipelineEntityService.getPipeline().source?.selectedTables,
        parameters: []
      };
    }

    if (this.connectionsForm.get('dataConnections.targetConnection')?.value) {
      connections.target = {
        dataConnection: this.connectionsForm.get('dataConnections.targetConnection')?.value,
        cdcRowMetadatas: this.childComponentReference?.instance.targetConnectionMetadata,
        parameters: this.childComponentReference?.instance.targetConnectionParameters
      };
    }

    return connections;
  }

  private listenForFormValueChanges(): void {
    this.connectionsForm.valueChanges.pipe(takeUntil(this.unsubscribeSignal$)).subscribe(() => {
      this.pipelineEntityService.patchPipeline(this.pipelineConnectionsObject);
    });
  }

  private readonly initializeNextButtonState = (): void => {
    this.connectionsForm.statusChanges.subscribe((status: string) => {
      const isValid = status.toUpperCase() === 'VALID';
      this.progressIndicatorStateService.setIsValid(1, isValid);
    });
  };

  private loadAndSetPipelineConnection() {
    const pipeLineConnection = this.pipelineEntityService.getPipeline();
    if (
      pipeLineConnection.source &&
      pipeLineConnection.source.dataConnection &&
      pipeLineConnection.target &&
      pipeLineConnection.target.dataConnection
    ) {
      this.setSourceConnection(pipeLineConnection);
      this.setTargetConnectionDetails(pipeLineConnection);
    }
    this.listenForFormValueChanges();
  }

  private setSourceConnection(pipelineData) {
    if (pipelineData.source.dataConnection) {
      this.selectedSourceConnection = pipelineData.source.dataConnection;
      this.selectedTargetConnection = pipelineData.target.dataConnection;
    }
  }

  private setTargetConnectionDetails(pipelineData) {
    this.childComponentReference.instance.targetConnectionMetadata = pipelineData.target.cdcRowMetadatas;
    this.childComponentReference.instance.targetConnectionParameters = pipelineData.target.parameters;
  }

  selectSourceConnectionType(sourceConnection: Connection) {
    this.sourceConnectionType = sourceConnection.connectionType;
    if (this.childComponentReference) {
      this.childComponentReference.instance.sourceConnectionType = this.sourceConnectionType;
    }
  }
}
