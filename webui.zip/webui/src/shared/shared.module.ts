import { AccordionModule } from 'primeng/accordion';
import { TreeModule } from 'primeng/tree';
import { TabViewModule } from 'primeng/tabview';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ButtonModule } from 'primeng/button';
import { SelectButtonModule } from 'primeng/selectbutton';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputSwitchModule } from 'primeng/inputswitch';
import { CalendarModule } from 'primeng/calendar';
import { InputNumberModule } from 'primeng/inputnumber';
import { ChartModule } from 'primeng/chart';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbPopoverModule, NgbTooltipModule } from '@ng-bootstrap/ng-bootstrap';
import { TranslocoModule, TranslocoPipe, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { ToastrModule } from 'ngx-toastr';
import { DropdownModule } from 'primeng/dropdown';
import { ProgressBarModule } from 'primeng/progressbar';
import { SliderModule } from 'primeng/slider';
import { TableModule } from 'primeng/table';
import { TriStateCheckboxModule } from 'primeng/tristatecheckbox';
import { OkComponent } from './dialogs/ok/ok.component';
import { YesnoComponent } from './dialogs/yesno/yesno.component';
import { YesNoCancelComponent } from './dialogs/yesnocancel/yes-no-cancel.component';
import { FormValidationMessageComponent } from './form-validation-message/form-validation-message.component';
import { OverlaySpinnerComponent } from './overlay-spinner/overlay-spinner.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { RouteTransformerDirective } from './route-transformer.directive';
import { SafeHtmlPipe } from './safe-html.pipe';
import { RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { AppSwitcherModule } from '@precisely/prism-ng/app-switcher';
import { TreeTableModule } from 'primeng/treetable';
import { SidebarModule } from 'primeng/sidebar';
import { ChipsModule } from 'primeng/chips';
import { PanelModule } from 'primeng/panel';
import { SecondaryNavModule } from '@precisely/prism-ng/secondary-nav';
import { EntitySelectorModule } from './entity-selector/entity-selector.module';
import { NgCircleProgressModule } from 'ng-circle-progress';
import { ContextMenuModule } from '@precisely/prism-ng/context-menu';
import { UserAccountModule } from '@precisely/prism-ng/user-account';
import { SharedConstants } from './shared.constant';
import { HelpMenuModule } from '@precisely/prism-ng/help-menu';
import { TooltipModule } from 'primeng/tooltip';
import { DialogModule } from 'primeng/dialog';
import { DynamicDialogModule } from 'primeng/dynamicdialog';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TagModule } from 'primeng/tag';
import { InputTextModule } from 'primeng/inputtext';
import { HistoryTableComponent } from './history-table/history-table.component';
import { SnowflakeConnectionConfigureComponent } from './connections/snowflake/snowflake-connection.component';
import { SelectSourceComponent } from './select-source/select-source.component';
import { ScheduleComponent } from './schedule/schedule.component';
import { ScheduleDetailComponent } from './schedule/schedule-detail/schedule-detail.component';
import { CheckboxModule } from 'primeng/checkbox';
import { ConnectionButtonComponent } from './connections/create-connection-button/connection-button/connection-button.component';
import { DatabrickConnectionConfigureComponent } from './connections/databrick/databrick-connection.component';
import { ConnectionConfigureComponent } from './connections/connection-configure/connection-configure.component';
import { EventBusService } from 'core/eventBusService';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';
import { sharedLoader } from '../core/i18n-loaders';
import { SearchInputComponent } from './search-input/search-input.component';
import { TimeframeSelectorComponent } from './timeframe-selector/timeframe-selector.component';
import { EmailNotifyConfigComponent } from './email-notify-config/email-notify-config.component';

/**
 * SharedModule is a conventional name for an NgModule with the components, directives, and pipes
 * that you use everywhere in your app. This module should consist entirely of declarations, most
 * of them exported.
 *
 * The SharedModule may re-export other widget modules, such as CommonModule, FormsModule, and
 * NgModules with the UI controls that you use most widely.
 *
 * The SharedModule should not have providers for reasons explained previously. Nor should any
 * of its imported or re-exported modules have providers.  Any services in this module must have
 * the providedIn: 'root' configuration.
 *
 * Import the SharedModule in your feature modules, both those loaded when the app starts and
 * those you lazy load later.
 */

@NgModule({
  declarations: [
    FormValidationMessageComponent,
    HeaderComponent,
    OkComponent,
    OverlaySpinnerComponent,
    PieChartComponent,
    RouteTransformerDirective,
    SafeHtmlPipe,
    YesNoCancelComponent,
    YesnoComponent,
    HistoryTableComponent,
    ConnectionConfigureComponent,
    SelectSourceComponent,
    ScheduleDetailComponent,
    ScheduleComponent,
    ConnectionButtonComponent,
    DatabrickConnectionConfigureComponent,
    SnowflakeConnectionConfigureComponent,
    SearchInputComponent,
    TimeframeSelectorComponent,
    EmailNotifyConfigComponent
  ],
  imports: [
    AccordionModule,
    AppSwitcherModule,
    ButtonModule,
    CommonModule,
    ConfirmDialogModule,
    ChartModule,
    DropdownModule,
    FormsModule,
    ReactiveFormsModule,
    NgbTooltipModule,
    NgbPopoverModule,
    ProgressBarModule,
    RouterModule,
    SliderModule,
    ToastrModule.forRoot({
      enableHtml: true,
      newestOnTop: false
    }),
    TableModule,
    TabViewModule,
    TranslocoModule,
    TranslocoLocaleModule,
    TreeModule,
    TriStateCheckboxModule,
    TreeTableModule,
    SidebarModule,
    SecondaryNavModule,
    EntitySelectorModule,
    NgCircleProgressModule.forRoot({
      toFixed: 2,
      radius: 23,
      showSubtitle: false,
      outerStrokeColor: SharedConstants.PROGRESS_BAR_COLORS.PERCENTAGE,
      innerStrokeColor: SharedConstants.PROGRESS_BAR_COLORS.REMAINING,
      space: -5,
      outerStrokeWidth: 5,
      innerStrokeWidth: 5,
      showInnerStroke: true,
      outerStrokeGradient: false,
      backgroundGradient: false,
      animation: false,
      backgroundStrokeWidth: 0,
      animationDuration: 0,
      titleFontSize: '10'
    }),
    ContextMenuModule,
    UserAccountModule,
    HelpMenuModule,
    TooltipModule,
    SelectButtonModule,
    RadioButtonModule,
    InputSwitchModule,
    CalendarModule,
    InputNumberModule,
    CheckboxModule,
    DialogModule,
    DynamicDialogModule,
    TagModule,
    InputTextModule,
    ChipsModule
  ],
  providers: [
    EventBusService,
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [{ scope: 'discoveryShared', loader: sharedLoader }]
    }
  ],
  exports: [
    AccordionModule,
    ButtonModule,
    CommonModule,
    ConfirmDialogModule,
    ChartModule,
    DropdownModule,
    FormsModule,
    ReactiveFormsModule,
    FormValidationMessageComponent,
    HeaderComponent,
    NgbTooltipModule,
    NgbPopoverModule,
    OverlaySpinnerComponent,
    ProgressBarModule,
    RouteTransformerDirective,
    SafeHtmlPipe,
    SliderModule,
    TableModule,
    TabViewModule,
    ToastrModule,
    TranslocoModule,
    TranslocoPipe,
    TranslocoLocaleModule,
    TreeModule,
    TriStateCheckboxModule,
    TreeTableModule,
    SidebarModule,
    ChipsModule,
    PanelModule,
    SecondaryNavModule,
    EntitySelectorModule,
    NgCircleProgressModule,
    ContextMenuModule,
    TooltipModule,
    SelectButtonModule,
    RadioButtonModule,
    InputSwitchModule,
    CalendarModule,
    InputNumberModule,
    HistoryTableComponent,
    ConnectionConfigureComponent,
    SelectSourceComponent,
    ScheduleDetailComponent,
    ScheduleComponent,
    CheckboxModule,
    ConnectionButtonComponent,
    DatabrickConnectionConfigureComponent,
    SnowflakeConnectionConfigureComponent,
    DialogModule,
    DynamicDialogModule,
    TagModule,
    InputTextModule,
    SearchInputComponent,
    TimeframeSelectorComponent,
    EmailNotifyConfigComponent
  ]
})
export class SharedModule {}
