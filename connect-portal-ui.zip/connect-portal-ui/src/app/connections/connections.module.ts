import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslocoModule, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { TooltipModule } from 'primeng/tooltip';
import { ServersModule } from '../servers/servers.module';
import { SharedModule } from '../shared/shared.module';
import { CatalogsModule } from './catalogs/catalogs.module';
import { BaseConnectionFormComponent } from './connection-sidebar/connection-form/base-connection-form/base-connection-form.component';
import { ConnectionFormComponent } from './connection-sidebar/connection-form/connection-form.component';
import { Db2iFormComponent } from './connection-sidebar/connection-form/db2i-connection-form/db2i-form.component';
import { Db2zFormComponent } from './connection-sidebar/connection-form/db2z-connection-form/db2z-form.component';
import { KafkaFormComponent } from './connection-sidebar/connection-form/kafka-connection-form/kafka-form.component';
import { OracleFormComponent } from './connection-sidebar/connection-form/oracle-connection-form/oracle-form.component';
import { ConnectionSidebarComponent } from './connection-sidebar/connection-sidebar.component';
import { ConnectionsRoutingModule } from './connections-routing.module';
import { ConnectionsComponent } from './connections.component';
import { ConnectionsApiService } from './shared/connections-api.service';
import { StepsModule } from '@precisely/prism-ng/steps';
import { Db2FormComponent } from './connection-sidebar/connection-form/db2-connection-form/db2-form.component';
import { SqlServerFormComponent } from './connection-sidebar/connection-form/sqlserver-connection-form/sqlserver-form.component';
import { ConnectionRuntimeEngineFormComponent } from './connection-sidebar/connection-form/shared/connection-runtime-engine-form/connection-runtime-engine-form.component';
import { ConnectionTestCredentialsFormComponent } from './connection-sidebar/connection-form/shared/connection-test-credentials-form/connection-test-credentials-form.component';
import { SchemaRegistryFormComponent } from './connection-sidebar/connection-form/schema-registry-form/schema-registry-form.component';
import { CatalogStatusComponent } from './shared/catalog-status/catalog-status.component';
import { ConnectionCredentialsFormComponent } from './connection-sidebar/connection-form/shared/connection-credentials-form/connection-credentials-form.component';
import { commonLoader, serversLoader, connectionsLoader, pngLoader, dqcoreCatalogLoader } from '../i18n-loaders';
import { SharedConnectionsComponent } from './shared-connections/shared-connections.component';
import { ConnectionListModule } from 'dqcore-catalog';
import { ToastModule } from 'primeng/toast';

@NgModule({
  declarations: [
    ConnectionSidebarComponent,
    ConnectionsComponent,
    BaseConnectionFormComponent,
    OracleFormComponent,
    ConnectionFormComponent,
    Db2iFormComponent,
    Db2zFormComponent,
    KafkaFormComponent,
    Db2FormComponent,
    SqlServerFormComponent,
    ConnectionRuntimeEngineFormComponent,
    ConnectionTestCredentialsFormComponent,
    SchemaRegistryFormComponent,
    CatalogStatusComponent,
    ConnectionCredentialsFormComponent,
    SharedConnectionsComponent
  ],
  providers: [
    ConnectionsApiService,
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'catalog', loader: dqcoreCatalogLoader },
        { scope: 'common', loader: commonLoader },
        { scope: 'servers', loader: serversLoader },
        { scope: 'connections', loader: connectionsLoader },
        { scope: 'png', loader: pngLoader }
      ]
    }
  ],
  imports: [
    ConnectionsRoutingModule,
    CommonModule,
    SharedModule,
    TranslocoModule,
    FormsModule,
    ReactiveFormsModule,
    DropdownModule,
    CheckboxModule,
    ServersModule,
    TooltipModule,
    CatalogsModule,
    StepsModule,
    ConnectionListModule,
    ToastModule
  ],
  exports: [ConnectionSidebarComponent]
})
export class ConnectionsModule {}
