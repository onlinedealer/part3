import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber, isString } from "lodash";
import { RegisterVO } from "../../models/view-objects/register-vo.model";

export class RegistersSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" }> = new BehaviorSubject({
        active: "status",
        direction: "asc"
    } as any);

    registers: RegisterVO[] = [];

    public setRegisters(registers: RegisterVO[]) {
        this.registers = registers;
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedRegisters(): Observable<RegisterVO[]> {
        return this.sortingSubject.asObservable().pipe(map(() => [...this.registers].sort(this.registerComparator)));
    }

    public onSortEvent(event: { active: string; direction: "asc" | "desc" }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    registerComparator = (r1: RegisterVO, r2: RegisterVO): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "status":
                return this.sortByStatusBeforeMeteringName(r1, r2, directionMultiplier);
            case "metering":
                return this.sortByString(r1.metering, r2.metering, directionMultiplier);
            case "obisCode":
                return this.sortByString(r1.obisCode, r2.obisCode, directionMultiplier);
            case "powerDimension":
                return this.sortByString(r1.powerDimension, r2.powerDimension, directionMultiplier);
            case "validFrom":
                return this.sortByNumberOverString(r1.validFrom, r2.validFrom, directionMultiplier);
            case "validUntil":
                return this.sortByValidUntilBeforeMeteringName(r1, r2, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByStatusBeforeMeteringName(r1: RegisterVO, r2: RegisterVO, directionMultiplier: number) {
        if (isNumber(r1.validUntil) && isNumber(r2.validUntil)) {
            return this.sortByString(r1.metering, r2.metering, 1);
        }

        if (isNil(r1.validUntil) && isNil(r2.validUntil)) {
            return this.sortByString(r1.metering, r2.metering, 1);
        }

        if (isNil(r1.validUntil)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.validUntil)) {
            return directionMultiplier;
        }

        return 0;
    }

    sortByValidUntilBeforeMeteringName(r1: RegisterVO, r2: RegisterVO, directionMultiplier: number) {
        if (isNumber(r1.validUntil) && isNumber(r2.validUntil)) {
            return r1.validUntil > r2.validUntil ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(r1.validUntil) && isNil(r2.validUntil)) {
            return this.sortByString(r1.metering, r2.metering, 1);
        }

        if (isNil(r1.validUntil)) {
            return -1 * directionMultiplier;
        }

        if (isNil(r2.validUntil)) {
            return directionMultiplier;
        }

        return 0;
    }

    sortByString(value1: string, value2: string, directionMultiplier: number) {
        if (isNil(value2) || value2.trim().length < 1) {
            return -1 * directionMultiplier;
        }

        if (isNil(value1) || value1.trim().length < 1) {
            return directionMultiplier;
        }

        if (value1.trim().toUpperCase() < value2.trim().toUpperCase()) {
            return -1 * directionMultiplier;
        }

        return directionMultiplier;
    }

    sortByNumberOverString(value1: number | string | null, value2: number | string | null, directionMultiplier: number) {
        if (isNumber(value1) && isNumber(value2)) {
            return value1 > value2 ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNumber(value1) && isString(value2)) {
            return -1 * directionMultiplier;
        }

        if (isString(value1) && isNumber(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value1) || isNil(value2)) {
            return directionMultiplier;
        }

        if (isNumber(value2) || isNil(value1)) {
            return -1 * directionMultiplier;
        }

        return value1.toUpperCase() < value2.toUpperCase() ? directionMultiplier : -1 * directionMultiplier;
    }
}
