/**
 * This model is used to hole the information displayed in the Entity Card Header.
 */
export interface EntityCardHeaderModel {
  /**
   * Name for the field (not displayed).
   */
  fieldName: string;

  /**
   * The value displayed for the field in the entity card.
   */
  displayName: string;

  /**
   * This property determines if the card contents can be sorted by this field.
   */
  sortable?: boolean;
}
