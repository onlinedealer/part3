import { Component, Input } from '@angular/core';
import { DatePipe } from '@angular/common';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'p-connect-cataloging-error-form',
  templateUrl: './cataloging-error-form.component.html',
  styleUrls: ['./cataloging-error-form.component.scss']
})
export class CatalogingErrorFormComponent {
  @Input() errorMessage;
  @Input() displayErrorType: boolean = false;

  constructor(private datePipe: DatePipe) {}

  get messageText() {
    return this.errorMessage && this.errorMessage.message ? this.errorMessage.message : '-';
  }

  get statusText() {
    return this.errorMessage?.status ? this.errorMessage.status : '-';
  }

  get pathText() {
    return this.errorMessage && this.errorMessage.path ? this.errorMessage.path : '-';
  }

  get errorTypeText() {
    return this.errorMessage && this.errorMessage.error ? this.errorMessage.error : '-';
  }

  /**
   * API error response does not include exception key.
   */
  get exceptionText() {
    return '-';
  }

  /**
   * Returns timestamp in 'YYYY-MM-DD HH:MM:SS' format.
   */
  get timestampText() {
    const time = this.errorMessage?.timeStamp || this.errorMessage?.timestamp;
    return this.errorMessage && time ? this.datePipe.transform(new Date(time), 'yyyy-MM-dd HH:mm:ss') : '-';
  }

  get detailedMessageText() {
    return this.errorMessage && this.errorMessage.detailedMessage ? this.errorMessage.detailedMessage : '-';
  }
}
