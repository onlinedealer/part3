import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpiringComponent } from './expiring.component';

describe('ExpiringComponent', () => {
  let component: ExpiringComponent;
  let fixture: ComponentFixture<ExpiringComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpiringComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpiringComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
