import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../../connections/shared/connection';
import { Metabase } from '../../../shared/metabase.model';

export enum DB2I_METABASE_PARAMETERS {
  IN_SYSBAS = 'IN_SYSBAS',
  REPLICATION_USER_ID = 'REPLICATION_USER_ID',
  REPLICATION_USER_PASSWORD = 'REPLICATION_USER_PASSWORD'
}

@Component({
  selector: 'p-connect-db2i-metabase-form',
  templateUrl: './db2i-metabase-form.component.html'
})
export class DB2IMetabaseFormComponent implements OnInit, OnDestroy {
  db2iMetabaseForm: FormGroup;
  isIASPEnabledInConnection = false;

  @Input() dataConnection: Connection;

  constructor(private readonly controlContainer: ControlContainer) {}

  ngOnInit() {
    this.configureForm();

    if (this.dataConnection) {
      this.db2iMetabaseForm.get('databaseServer').setValue(this.dataConnection.database);

      const isIASPEnabled = this.dataConnection.parameters.find((param) => param.key === 'DB2_I_ENABLE_IASP');
      this.isIASPEnabledInConnection = isIASPEnabled.value === 'YES';
    }
  }

  ngOnDestroy() {
    this.removeForm();
  }

  /**
   * Removes form and any form specific translations or validation
   */
  private removeForm(): void {
    if (this.db2iMetabaseForm) {
      this.db2iMetabaseForm.clearValidators();
      this.db2iMetabaseForm.updateValueAndValidity();

      Object.keys(this.db2iMetabaseForm.controls).forEach((key) => {
        if (key !== 'dataConnection') {
          this.db2iMetabaseForm.removeControl(key);
        }
      });
    }
  }

  /**
   * setup the form for the db2 ibmi metabase
   */
  private configureForm(): void {
    this.db2iMetabaseForm = this.controlContainer.control as FormGroup;
    this.db2iMetabaseForm.addControl('databaseServer', new FormControl({ value: '', disabled: true }));
    this.db2iMetabaseForm.addControl('replicationUserID', new FormControl('', Validators.required));
    this.db2iMetabaseForm.addControl('replicationPassword', new FormControl('', Validators.required));
    this.db2iMetabaseForm.addControl('metabaseLibrary', new FormControl('SHAREMB'));
    this.db2iMetabaseForm.addControl('journalLocation', new FormControl('SYSBAS'));
  }

  /**
   * Returns a metabase object that is passed to the create metabase API
   */
  get metabase(): Metabase {
    return {
      name: this.db2iMetabaseForm.get('metabaseLibrary').value.toUpperCase(), // the metabase name needs to be passed in uppercase
      dataConnection: {
        id: (this.db2iMetabaseForm.get('dataConnection').value as Connection).id,
        accessFromServer: (this.db2iMetabaseForm.get('dataConnection').value as Connection).accessFromServer
      },
      parameters: [
        {
          key: DB2I_METABASE_PARAMETERS.IN_SYSBAS,
          value: (this.db2iMetabaseForm.get('journalLocation').value === 'SYSBAS').toString()
        },
        {
          key: DB2I_METABASE_PARAMETERS.REPLICATION_USER_ID,
          value: this.db2iMetabaseForm.get('replicationUserID').value
        },
        {
          key: DB2I_METABASE_PARAMETERS.REPLICATION_USER_PASSWORD,
          value: this.db2iMetabaseForm.get('replicationPassword').value
        }
      ]
    };
  }
}
