import React from 'react'
import { shallow } from 'enzyme'
import { AuthModal } from '../AuthModal'

describe('AuthModal component', () => {
  it('renders', () => {
    const wrapper = shallow(<AuthModal />)
    expect(wrapper).toHaveLength(1)
  })
})
