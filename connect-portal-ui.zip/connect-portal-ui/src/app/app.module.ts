import { HttpClientModule, HttpInterceptor, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, Inject, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CoreModule } from './core/core.module';
import { TokenInterceptor } from '@precisely/prism-ng/angular-auth-oidc-client';
import { FooterModule } from '@precisely/prism-ng/footer';
import { HttpErrorInterceptor } from '@precisely/prism-ng/di-suite';
import { SharedModule } from './shared/shared.module';
import { AuthConfigModule } from './auth/auth-config.module';
import { translocoConfig, TRANSLOCO_CONFIG, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { AppInitializerService } from './app-initializer.service';
import { commonLoader, pngLoader } from './i18n-loaders';
import { ErrorHeaderModule } from '@precisely/prism-ng/error-header';
import { CatalogConfigModule } from 'dqcore-catalog';
import { GraphQLModule } from './graphql.module';

@NgModule({
  declarations: [AppComponent],
  imports: [
    AuthConfigModule,
    BrowserModule,
    AppRoutingModule,
    FooterModule,
    HttpClientModule,
    SharedModule,
    CoreModule,
    ErrorHeaderModule,
    BrowserAnimationsModule,
    GraphQLModule
    // CatalogConfigModule.forRoot({ app: 'gateway', namespace: 'dqcore', path: 'catalog/v1/graphql' })
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: (appInitializerService: AppInitializerService) => () => appInitializerService.init(),
      deps: [AppInitializerService],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: TokenInterceptor,
      multi: true
    },
    {
      provide: TRANSLOCO_CONFIG,
      useValue: translocoConfig({
        availableLangs: ['de', 'en', 'es', 'fr', 'ja', 'te'],
        defaultLang: 'en',
        fallbackLang: 'en',
        missingHandler: {
          logMissingKey: false,
          useFallbackTranslation: true
        },
        reRenderOnLangChange: true
      })
    },
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'common', loader: commonLoader },
        { scope: 'png', loader: pngLoader }
      ]
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(@Inject(HTTP_INTERCEPTORS) interceptors: HttpInterceptor[]) {
    const tokenInterceptor = interceptors.find((i) => i instanceof TokenInterceptor) as TokenInterceptor; //NOSONAR
    tokenInterceptor.exclude('api/v1/config'); // config endpoint does not require or support bearer token
  }
}
