﻿(function () {
    'use strict';

    angular.module('arm').controller('noteCtrl',
            ['$scope', '$state', noteCtrl]);
    function noteCtrl($scope, $state) {

    };

})();