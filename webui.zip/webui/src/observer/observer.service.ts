import { Helper, AuthenticationService } from 'discovery-shared';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { ObserverConfigureModel } from './observer-configure/observer-configure.model';
import { ObserverRulesModel } from './observer-configure/observer-rules/observerRules.model';
import { ObserverListModel } from './observer-listing/observer-list.model';
import { ObserverConstants } from './observer-constants';
import { DataDriftType } from './observer-configure/observer-rules/rules-configure/data-drift-configure/data-drift-type.enum';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

@Injectable({
  providedIn: 'root'
})
export class ObserverService {
  /**
   *
   */
  baseUrl: string;

  /**
   *
   */
  constructor(
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('dataobservabilityconfig', 'profiling', 'api/v1/');
  }

  /**
   *
   */
  saveObserver(observeConfigureModel: ObserverConfigureModel, newObserver: boolean, observerId: string) {
    if (observeConfigureModel.scheduleConfig && Helper.isEmpty(observeConfigureModel.scheduleConfig.schedule)) {
      delete observeConfigureModel.scheduleConfig.schedule;
    }
    if (newObserver) {
      return this.httpClient.post(this.baseUrl + 'observable', observeConfigureModel, {
        headers: this.authenticationService.getHttpHeaders(),
        responseType: 'text'
      });
    } else {
      return this.httpClient.put(this.baseUrl + 'observable/' + observerId, observeConfigureModel, {
        headers: this.authenticationService.getHttpHeaders(),
        responseType: 'text'
      });
    }
  }

  getObserver(observerId: string) {
    return this.httpClient.get(this.baseUrl + 'observables/' + observerId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  getObservationRulesList(): Observable<ObserverRulesModel[]> {
    return this.httpClient.get(this.baseUrl + 'observable/metrics', {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<ObserverRulesModel[]>;
  }

  getObserverList(): Observable<ObserverListModel[]> {
    return this.httpClient.get(this.baseUrl + 'observables', {
      headers: this.authenticationService.getHttpHeaders()
    }) as Observable<ObserverListModel[]>;
  }

  deleteObserver(observerId: string): Observable<any> {
    return this.httpClient.delete(this.baseUrl + 'observables/' + observerId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }
  getDefaultsConfigForObserverRules() {
    return {
      volumeConfig: {
        configType: ObserverConstants.RULE_CONFIG_VOLUME_TYPES.CONFIDENCE,
        warningAlerts: {
          minimum: this.getDefaultRanges().confidence[0],
          maximum: this.getDefaultRanges().confidence[1]
        }
      },
      dataConfig: {
        confidence: {
          warningAlerts: {
            minimum: this.getDefaultRanges().confidence[0],
            maximum: this.getDefaultRanges().confidence[1]
          },
          numericData: [
            DataDriftType.VALUE_MIN,
            DataDriftType.VALUE_MAX,
            DataDriftType.VALUE_MEAN,
            DataDriftType.VALUE_STDEV
          ],
          textualData: [DataDriftType.TEXT_LENGTH_MIN, DataDriftType.TEXT_LENGTH_MAX],
          detailDrift: [DataDriftType.CARDINALITY_DETAIL],
          uniqueValueCount: true
        }
      }
    };
  }
  getDefaultRanges() {
    return {
      confidence: [60, 80],
      threshold: [3, 8]
    };
  }
}
