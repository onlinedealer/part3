import { ObserverService } from './observer.service';
import { Mocks, Spies } from 'discovery-test';
import { of } from 'rxjs';

describe('ObserverService', () => {
  let service: ObserverService;
  let observerList;
  beforeEach(() => {
    Spies.init();
    service = new ObserverService(Spies.HttpClient, Spies.AuthenticationService, Spies.HttpUtilService);
    observerList = Mocks.MockProfiles;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getObserverList be called', () => {
    service.getObserverList().subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('deleteObserver be called', () => {
    service.deleteObserver(observerList[0]['id']).subscribe();
    expect(Spies.HttpClient.delete.calls.count()).toBe(1);
  });

  it('getObservationRulesList be called', () => {
    service.getObservationRulesList().subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('should save observer with new id on saveObserver', () => {
    Spies.ProfileService.saveProfile.and.returnValue(of(observerList));
    service.saveObserver(observerList[0], true, observerList[0]['id']);
  });

  it('should save observer on saveObserver', () => {
    Spies.ProfileService.saveProfile.and.returnValue(of(observerList));
    service.saveObserver(observerList[0], false, observerList[0]['id']);
  });
});
