(function() {
    'use strict';

    fileuploader.controller("createTemplateCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', 'Lightbox', '$uibModal', createTemplateCtrl]);

    function createTemplateCtrl($scope, $ajaxFactory, $rootScope, uiRouters, Lightbox, $uibModal) {

        $scope.uploadpreview = "apps/images/income.jpg";
        $scope.rows = [];

        $scope.onClick = function(event) {
            var x = event.x;
            var y = event.y;
            var offsetX = event.offsetX;
            var offsetY = event.offsetY;
            console.log(offsetX, offsetY);
        };

        $scope.addRow = function() {
           var obj = $rootScope.globalDimenData;
           fileuploader.utils.addingObj(obj);
        };


    $(function(){
    var tarGet = document.getElementById("target");
    var imgW = tarGet.clientWidth;
    var imgH = tarGet.clientHeight;
    var newW = 200;
    var jcrop_api;
    $('#target').Jcrop({
        /*setSelect: [400, 200, 50, 50], */
        //aspectRatio: 16 / 8,
        onSelect: showCords, 
        onChange: showCords
    }/*, function(){
        jcrop_api = this;
    }*/);
    
    function showCords(c){
        var obj = {};
        obj["x"] = c.x;
        obj["y"] = c.y;
        obj["w"] = c.w;
        obj["h"] = c.h;
        //console.log(obj);
        $scope.bindingX = obj.x;
        $scope.bindingY = c.y;
        $scope.bindingW = c.w;
        $scope.bindingH = c.h;
        $('input[name="x"]').val(c.x);
        $('input[name="y"]').val(c.y);
        $('input[name="w"]').val(c.w);
        $('input[name="h"]').val(c.h);
        $rootScope.globalDimenData = obj;
        /*$('input[name="x"]').val(c.x);
        $('input[name="y"]').val(c.y);
        $('input[name="w"]').val(c.w);
        $('input[name="h"]').val(c.h);*/
    }
    /*
    $('#imgCon').click(function(e){
        jcrop_api.animateTo([400, 200, 50, 50]);
        return false;
    });
    */
})



    }
})();