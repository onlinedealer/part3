import { DatePipe } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';
import { Connection } from 'src/app/connections/shared/connection';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { CreateBundleSidebarComponent } from './create-bundle-sidebar.component';
import { BundlesApiService } from '../shared/bundles-api.service';
import { of, throwError } from 'rxjs';
import { LogFileMetadata, LogMetadataList } from '../shared/bundles';
import { Component } from '@angular/core';
import { CreateBundleFormComponent } from './create-bundle-form/create-bundle-form.component';
import { FormControl, FormGroup } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';

describe('CreateBundleSidebarComponent', () => {
  let component: CreateBundleSidebarComponent;
  let fixture: ComponentFixture<CreateBundleSidebarComponent>;
  let bundlesApiService: BundlesApiService;

  @Component({
    selector: 'p-connect-create-bundle-form',
    template: '',
    providers: [
      {
        provide: CreateBundleFormComponent,
        useClass: MockCreateBundleFormComponent
      }
    ]
  })
  class MockCreateBundleFormComponent {
    open() {}
    createBundleForm = new FormGroup({
      bundleName: new FormControl(''),
      bundleDescription: new FormControl('')
    });
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [DatePipe],
      imports: [HttpClientTestingModule],
      declarations: [CreateBundleSidebarComponent, MockSidebarComponent, MockCreateBundleFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateBundleSidebarComponent);
    bundlesApiService = TestBed.inject(BundlesApiService);
    spyOn(bundlesApiService, 'getLogsFileMetadata').and.returnValue(
      of({ agentName: 'agent', projectName: 'test', bundleLocation: 'abc', logMetadataList: {} as LogMetadataList } as LogFileMetadata)
    );
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display the sidebar', () => {
    spyOn(component.sidebarComponent, 'open');
    component.open({} as Project, [{} as Connection]);
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should close sidebar', () => {
    spyOn(component.sidebarComponent, 'close');
    component.cancelButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should reset form values when sidebar opens', () => {
    spyOn(component.createBundleFormComponent.createBundleForm, 'patchValue');
    component.open({ id: '1' } as Project, [{} as Connection]);
    expect(component.createBundleFormComponent.createBundleForm.patchValue).toHaveBeenCalled();
  });

  it('should get project information and list of source connection used in project when sidebar opens', () => {
    component.open({ id: '1' } as Project, [{} as Connection]);
    expect(component.project.id).toEqual('1');
    expect(component.listOfSourceConnectionsInProject.length).toEqual(1);
  });

  it('should get list of files to be bundled when sidebar opens', () => {
    component.open({ id: '1' } as Project, [{} as Connection]);
    expect(bundlesApiService.getLogsFileMetadata).toHaveBeenCalled();
    expect(component.listOfFilesToBeBundled.bundleLocation).toEqual('abc');
    expect(component.listOfFilesToBeBundled.agentName).toEqual('agent');
    expect(component.listOfFilesToBeBundled.projectName).toEqual('test');
    expect(component.listOfFilesToBeBundled.logMetadataList).toBeTruthy();
  });

  it('should display error message when get logs metadata API fails', () => {
    jasmine.getEnv().allowRespy(true);
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(bundlesApiService, 'getLogsFileMetadata').and.returnValue(throwError(new HttpErrorResponse({ status: 404 })));
    component.open({ id: '1' } as Project, [{} as Connection]);
    expect(bundlesApiService.getLogsFileMetadata).toHaveBeenCalled();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should get latest time when sidebar opens', () => {
    spyOn(component, 'setTimeStampFormatForBundleName');
    component.open({ id: '1' } as Project, [{} as Connection]);
    expect(component.setTimeStampFormatForBundleName).toHaveBeenCalled();
  });

  describe('create bundle', () => {
    beforeEach(() => {
      spyOn(component.bundleCreatedEvent, 'emit');
      spyOn(component.sidebarComponent, 'close');
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      component.project = { id: '1' } as Project;
    });
    it('should create a bundle', () => {
      spyOn(bundlesApiService, 'createBundle').and.returnValue(of('test-bundle'));
      component.createButtonClicked();
      expect(bundlesApiService.createBundle).toHaveBeenCalled();
      expect(component.bundleCreatedEvent.emit).toHaveBeenCalled();
      expect(component.sidebarComponent.close).toHaveBeenCalled();
    });
    it('should still create a bundle if API is successfull but HTTP error is returned with status of 200', () => {
      spyOn(bundlesApiService, 'createBundle').and.returnValue(throwError(new HttpErrorResponse({ status: 200 })));
      component.createButtonClicked();
      expect(bundlesApiService.createBundle).toHaveBeenCalled();
      expect(component.bundleCreatedEvent.emit).toHaveBeenCalled();
      expect(component.sidebarComponent.close).toHaveBeenCalled();
    });
    it('should display error message in sidebar if create bundle API returns error', () => {
      spyOn(bundlesApiService, 'createBundle').and.returnValue(throwError(new HttpErrorResponse({ status: 404 })));
      component.createButtonClicked();
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
    });
  });
});
