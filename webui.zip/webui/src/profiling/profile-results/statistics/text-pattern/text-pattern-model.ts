import { TreeNode } from 'primeng/api';
import { PatternGroupModel } from './pattern-group-model';

export class TextPatternModel implements TreeNode {
  data: PatternGroupModel;
  parent: TreeNode;
  children: TextPatternModel[];
  constructor(group: PatternGroupModel, childs: TextPatternModel[]) {
    this.data = group;
    this.children = childs;
  }
}
