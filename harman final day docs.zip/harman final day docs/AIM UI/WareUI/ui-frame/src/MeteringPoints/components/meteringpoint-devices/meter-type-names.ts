export class MeterTypeNames {
    private interpretationMap: Map<string, string> = new Map([
        ["OTHER", $localize`:|@@deviceCategory.other:Other`],
        ["OIL", $localize`:|@@deviceCategory.oil:Oil`],
        ["ELECTRICITY", $localize`:|@@deviceCategory.electricity:Electricity`],
        ["GAS", $localize`:|@@deviceCategory.gas:Gas`],
        ["HEAT", $localize`:|@@deviceCategory.heat:Heat`],
        ["STEAM", $localize`:|@@deviceCategory.steam:Steam`],
        ["WARM_WATER_30_TO_90_C", $localize`:|@@deviceCategory.warmWater30to90:Warm water 30 to 90 °C`],
        ["WATER", $localize`:|@@deviceCategory.water:Water`],
        ["HEAT_COST_ALLOCATOR", $localize`:|@@deviceCategory.heatCostAllocator:Heat cost allocator:`],
        ["COMPRESSED_AIR", $localize`:|@@deviceCategory.compressedAir:Compressed air`],
        ["COOLING_LOAD_METER_OUTLET", $localize`:|@@deviceCategory.coolingLoadMeterOutlet:Cooling load meter outlet`],
        ["COOLING_LOAD_METER_INLET", $localize`:|@@deviceCategory.coolingLoadMeterInlet:Cooling load meter intlet`],
        ["HEAT_INLET", $localize`:|@@deviceCategory.heatInlet:Heat inlet`],
        ["HEAT_COOLING_LOAD_METER", $localize`:|@@deviceCategory.heatCoolingLoadMeter:Heat cooling load meter`],
        ["BUS_SYSTEM_COMPONENT", $localize`:|@@deviceCategory.busSystemComponent:Bus system component`],
        ["UNKNOWN_MEDIUM", $localize`:|@@deviceCategory.unknownMedium:Unknown medium`],
        ["LOAD_MANAGEMENT", $localize`:|@@deviceCategory.loadManagement:Load management`],
        ["RESERVED_1", "RESERVED_1"],
        ["RESERVED_2", "RESERVED_2"],
        ["RESERVED_3", "RESERVED_3"],
        ["RESERVED_4", "RESERVED_4"],
        ["HOT_WATER_OVER_90_C", $localize`:|@@deviceCategory.hotWaterOver90:Hot water over 90 °C`],
        ["COLD_WATER", $localize`:|@@deviceCategory.coldWater:Cold water`],
        ["DUAL_REGISTER_WATER_METER", $localize`:|@@deviceCategory.dualRegisterWaterMeter:Dual register water meter`],
        ["PRESSURE", $localize`:|@@deviceCategory.pressure:Pressure`],
        ["AD_CONVERTER", $localize`:|@@deviceCategory.adConverter:AD converter`]
    ]);

    public getInterpretation(enumCategory: string): string {
        const category = this.interpretationMap.get(enumCategory);
        return category ? category : "?" + enumCategory;
    }
}
