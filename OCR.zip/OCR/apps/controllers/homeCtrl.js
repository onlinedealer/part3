(function() {
    'use strict';

    fileuploader.controller("homeCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileModel', 'uiRouters', '$location', homeCtrl]);

    function homeCtrl($scope, $ajaxFactory, $rootScope, fileModel, uiRouters, $location) {
        $scope.viewbtn = true;
        $scope.DataSource = [];
        $scope.uploadFile = function() {


            var filepath = $('#fileUploadId').val();
            var isValidFileFormate = new RegExp("^(?:[\w]\:|\\)(\\[a-z_\-\s0-9\.]+)+\.(txt|gif|pdf|doc|docx|xls|xlsx)$").test(filepath);

            if (!isValidFileFormate) {
                alert("Please Enter Valid Format");
                return;
            }
            var file = $scope.myFile;
            var fd = new FormData();
            fd.append('file', file);
            var uploadUrl = "/fileUpload"; //fileUpload?path:'C/bharath/xyz.txt'  

            // paranet :: key  : filePath   value = u shoiuld set
            var multiplefile = [];

            var obj = {};
            obj.filePath = $('#fileUploadId').val();
            obj.fileType = fd;

            multiplefile.push(obj);

            var promise = fileModel.uploadFileToUrl(uploadUrl, fd, multiplefile)
            promise.then(function(data) {
                console.log(data);
            });
            promise.catch(function(d) {
                console.log(d);
                return d;
            });

        };


        $scope.open = function(checkeditem) {
            $rootScope.pagedisplay = checkeditem;
            $location.url(uiRouters.dashboard);
        };


        $scope.fetchDataSource = function() {

            //var url = "/get/list/of/domain/for/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/data.json', 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.DataSource = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });
        }
        $scope.fetchDataSource();

    }
})();