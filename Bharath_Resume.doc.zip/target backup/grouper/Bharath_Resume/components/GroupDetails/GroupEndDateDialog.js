import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Button from '@material-ui/core/Button'
import Grid from '@material-ui/core/Grid'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormHelperText from '@material-ui/core/FormHelperText'
import FormControl from '@material-ui/core/FormControl'
import * as Constants from '../common/Utils/Constants'
import CircularProgress from '@material-ui/core/CircularProgress'
import { changeLaunchDateEditFormat, changeDateToTimestamp } from '../common/Utils/CommonUtils'

const styles = theme => ({
  heading: {
    fontSize: 18,
    fontWeight: 500,
    paddingBottom: '16px',
  },
  helperText: {
    marginTop: 8,
  },
  formControl: {
    marginTop: 24,
    width: '100%',
  },
  field: {
    marginTop: 24,
    width: '100%',
  },
  textHead1: {
    fontSize: 13,
    fontWeight: 500,
  },
  textSmall: {
    fontSize: 11,
    fontWeight: 300,
    fontStyle: 'italic',
  },
  actionContainer: {
    padding: '24px 16px',
  },
  updateButtonStyle: {
    color: '#fff',
    float: 'right',
    background: '#1976d2',
    fontWeight: 300,
    marginLeft: 10,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  content: {
    /* minHeight: '490px', */
    overflowY: 'visible',
  },
  dialog: {
    width: '328px',
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  errorMessageRedColor: {
    color: 'red',
    fontSize: '10px',
  },
})
class GroupendDateDialog extends React.Component {
  constructor (props) {
    super(props)

    this.state = {

      errorText: '',
      formData: {
        endDate: props.groupDetails.collection_end_date,
      },
      launch_date: props.groupDetails.launch_date,
      errors: {

      },
      errorMessageEndDate: false,
    }
  }

  handleChange = name => event => {
    var endDate = Date.parse(event.target.value)
    var launchDate = Date.parse(changeLaunchDateEditFormat(this.state.launch_date))
    if (launchDate < endDate) {
      const formData = { ...this.state.formData }
      const errors = { ...this.state.errors }
      this.setState({ errorMessageEndDate: false })
      if (name === 'collection_end_date') {
        if (!event.target.value) {
          formData.endDate = event.target.value
          errors.name = Constants.ERROR_LAUNCH_DATE_REQ
        } else {
          formData.endDate = changeDateToTimestamp(event.target.value)
          errors.name = ''
        }
      }
      this.setState({ formData, errors })
    } else {
      this.setState({ errorMessageEndDate: true })
    }
  }

  validateSubmit = () => {
    const formData = { ...this.state.formData }
    const errors = { ...this.state.errors }
    const { groupDetails, auth } = this.props
    let payload = {}
    payload.group_name_updated = false
    payload.theme_updated = false
    let isValid = true
    if (!formData.endDate) {
      errors.name = Constants.ERROR_LAUNCH_DATE_REQ
      isValid = false
    } else {
      if (groupDetails.collection_end_date !== formData.endDate) {
        payload.group_name_updated = true
      }
      payload.collection_end_date = formData.endDate
      errors.name = ''
    }

    if (isValid && groupDetails && groupDetails.group_id) {
      payload.description = groupDetails.description
      payload.group_type = groupDetails.group_type
      payload.group_id = groupDetails.group_id
      payload.group_type_id = groupDetails.group_type_id
      payload.status = groupDetails.status
      payload.item_type_id = groupDetails.item_type_id
      payload.item_type = groupDetails.item_type
      payload.themes = groupDetails.themes
      payload.tcin_data = []
      payload.update_request_for_variation = true
      payload.launch_date = groupDetails.launch_date
      this.props.updateGroupName(payload, auth.memberOf, auth.lanId)
    } else {
      this.setState({ errors })
    }
  }

  changeendDateVariation = () => {
    // Implement in future when have required to change in create flow
  }
  render () {
    const { classes, closeDrawer, groupDetails, loadingBtnStatus } = this.props
    const { formData, errors } = this.state

    let saveDisableState = true
    if (groupDetails.launch_date !== formData.endDate) {
      saveDisableState = false
    }
    let btnText = groupDetails.group_id ? 'Save' : 'Change'
    let btnClickEvent = groupDetails.group_id ? this.validateSubmit : this.changeendDateVariation
    return (
      <div>
        <Grid container>
          <Grid item xs={12}>
            <h4>Edit End Date</h4>
          </Grid>
          {this.state.errorMessageEndDate === true && <Grid item xs={12} className={classes.errorMessageRedColor}>
            <p>End Date should be greater than Launch Date</p>
          </Grid>}
          <Grid item xs={12}>
            <FormControl className={classes.formControl} aria-describedby="name-helper-text">
              <InputLabel htmlFor="name-helper" required>Launch Date</InputLabel>
              <Input id="name-helper" value={changeLaunchDateEditFormat(formData.endDate)} onChange={this.handleChange('collection_end_date')} required type="date" />
              {(errors.name) &&
                <FormHelperText error className={classes.helperText}>{errors.name}</FormHelperText>
              }
            </FormControl>
          </Grid>
          <Grid item xs={12} className={classes.actionContainer}>
            <Button onClick={btnClickEvent} color="primary" className={classes.updateButtonStyle} disabled={saveDisableState}>
              {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Save') &&
                <CircularProgress
                  className={classes.progress}
                  size={25}
                />
              }
              {btnText}
            </Button>
            <Button onClick={closeDrawer} color="primary" className={classes.cancelButtonStyle} >
              Cancel
            </Button>
          </Grid>
        </Grid>
      </div>
    )
  }
}

export default withStyles(styles)(GroupendDateDialog)
