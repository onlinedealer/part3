import { NotifyConfig } from 'core/models/notification-config/email-config.model';
import { TableModel, ColumnModel, ScheduleConfigModel } from 'discovery-core';
import { MetricRuleModel } from './observer-rules/rules-configure/metric-rule-model';

export class ObserverConfigureModel {
  name: string;
  description: string;
  connectionId: string;
  tables: TableModel[];
  scheduleConfig: ScheduleConfigModel;
  metrics: string[];
  metricRule: MetricRuleModel;
  notificationConfig: NotifyConfig;

  constructor() {
    this.tables = [];
    this.scheduleConfig = new ScheduleConfigModel(null);
    this.notificationConfig = new NotifyConfig(null);
    this.metricRule = new MetricRuleModel();
    this.metrics = [];
  }

  loadFromSettings(settings) {
    this.name = settings.name;
    this.description = settings.description;
    this.connectionId = settings.connectionId;
    settings.tables.forEach((settingsTable) => {
      const table: TableModel = new TableModel();
      table.name = settingsTable.name;
      table.schema = settingsTable.schema;
      table.type = settingsTable.type;
      settingsTable.columns.forEach((settingsColumn) => {
        const column: ColumnModel = new ColumnModel();
        column.name = settingsColumn.name;
        column.type = settingsColumn.type;
        table.columns.push(column);
      });
      this.tables.push(table);
    });
    this.metrics = settings.metrics;
    this.scheduleConfig = settings.scheduleConfig;
    this.metricRule = settings.metricRule;
    this.notificationConfig = settings.notificationConfig;
  }
}
