export interface NetworkControlParam {
    parameterId: string;
    identifier: string;
    value: string;
}
