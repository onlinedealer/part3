(function() {
    'use strict';
    codeathonApp.directive('appPopup', ['uiRouters', appPopup]);

    function appPopup(uiRouters) {
        return {
            restrict: 'E',
            replace: true,
            templateUrl: uiRouters.directivesHtmlPath + '/popup.html',
            controller: function($scope, $element, $attrs) {
                $scope.headerMessage = "";
                $scope.bodyMessage ="";
                $scope.initPopup = function(e) {
                    e.preventDefault();
                    $("body").append("<div class='modal-overlay js-modal-close'></div>");
                    $(".modal-overlay").fadeTo(500, 0.7);
                    var modalBox = $(e.currentTarget).attr('data-modal-id');
                    $('#'+modalBox).fadeIn($(this).data());
                    resizeWidow();
                };

                function resizeWidow() {
                    $(".modal-box").css({
                        top: ($(window).height() - $('.modal-box').outerHeight()) / 2,
                        position: 'fixed',
                        left: "30%",
                        width: 'auto'
                    });
                };
                $scope.editorCancel = function() {
                    $(".modal-box, .modal-overlay").fadeOut(500, function() {
                        $(".modal-overlay").remove();
                    });
                };
                $(window).resize(function() {
                    resizeWidow();
                });
                $(window).resize();
            },
            link: function(scope, element, attrs) {

                scope.$on('openPopupEvent', function(e, data) {
                    if ($('body').find('.modal-overlay').length == 0) {
                        scope.headerMessage = data.message;
                        scope.bodyMessage = data.content;
                        scope.initPopup(data.eventObj);
                    }
                });
            }
        }
    }

})();
