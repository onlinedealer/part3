import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.scss']
})
export class LoaderComponent implements OnInit {
  @ViewChild('loaderContainer') loaderContainer: ElementRef;

  constructor() { }

  ngOnInit() {
    this.loaderContainer.nativeElement.focus();
  }

}
