import { Mocks, Spies } from 'discovery-test';
import { of, throwError } from 'rxjs';
import { ScheduleOccurenceTypeEnum, ScheduleRunsModel } from 'discovery-core';
import { ScheduleDetailComponent } from './schedule-detail.component';
describe('ScheduleDetailComponent', () => {
  let component: ScheduleDetailComponent;

  beforeEach(() => {
    Spies.init();
    component = new ScheduleDetailComponent(
      Spies.ScheduleService,
      Spies.TranslateService,
      Spies.ToastrService,
      Spies.Router
    );
    component.scheduleType = { viewType: 'Enabled', id: 'asdf556e', editEnabled: false, source: 'Profiling' };
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should run ngOnInit', () => {
    component.scheduleType = { viewType: 'Enabled', id: 'asdf556e', editEnabled: false, source: 'Profiling' };
    const profileRunInformationList: ScheduleRunsModel[] = [
      {
        id: '2c9280877fb08fbb017fb09c8df30007',
        runDateTime: 1647935524325,
        duration: '00:00:00',
        status: 'INPROGRESS',
        errorMessage: ''
      }
    ];
    const response = {
      profileId: '2c9280877fb08fbb017fb09564260001',
      profileName: 'abc',
      scheduleId: '62397e506bdedb4055d82ffe',
      scheduleConfig: {
        enabled: false,
        status: 'Disabled',
        lastStatusUpdatedDateTime: 1649156962027,
        schedule: {
          occurence: ScheduleOccurenceTypeEnum.WEEKLY,
          timezone: '',
          runAtTime: {
            hour: '02',
            minute: '14',
            meridiemIndicator: 'PM'
          },
          daysOfWeek: ['MON', 'TUE']
        }
      },
      profileRunInformationList: profileRunInformationList ? profileRunInformationList : []
    };
    component.scheduleHistoryDetails = response;
    Spies.ScheduleService.getScheduleHistory.and.returnValue(of(response));
    component.ngOnInit();
    expect(component.tableSetting.tableHeader.length).toBeGreaterThan(0);
    expect(component.isTableVisible).toBe(true);
    expect(component.scheduleHistoryDetails).toBeDefined();
  });
  it('check history with disabled status', () => {
    component.scheduleType = { viewType: 'Disabled', id: 'asdf556e', editEnabled: false, source: 'Profiling' };
    const profileRunInformationList: ScheduleRunsModel[] = [
      {
        id: '2c9280877fb08fbb017fb09c8df30007',
        runDateTime: 1647935524325,
        duration: '00:00:00',
        status: 'INPROGRESS',
        errorMessage: ''
      }
    ];
    const response = {
      profileId: '2c9280877fb08fbb017fb09564260001',
      profileName: 'abc',
      scheduleId: '62397e506bdedb4055d82ffe',
      scheduleConfig: {
        enabled: false,
        status: 'Disabled',
        lastStatusUpdatedDateTime: 1649156962027,
        schedule: {
          occurence: ScheduleOccurenceTypeEnum.WEEKLY,
          timezone: '',
          runAtTime: {
            hour: '04',
            minute: '14',
            meridiemIndicator: 'PM'
          },
          daysOfWeek: ['MON', 'TUE']
        }
      },
      profileRunInformationList: profileRunInformationList ? profileRunInformationList : []
    };
    component.scheduleHistoryDetails = response;
    Spies.ScheduleService.getScheduleHistory.and.returnValue(of(response));
    component.ngOnInit();
    expect(component.isTableVisible).toBe(true);
  });
  it('check history with disabled status without last disabled date', () => {
    component.scheduleType = { viewType: 'Disabled', id: 'asdf556e', editEnabled: false, source: 'Profiling' };
    const profileRunInformationList: ScheduleRunsModel[] = [
      {
        id: '2c9280877fb08fbb017fb09c8df30007',
        runDateTime: 1647935524325,
        duration: '00:00:00',
        status: 'INPROGRESS',
        errorMessage: ''
      }
    ];
    const response = {
      profileId: '2c9280877fb08fbb017fb09564260001',
      profileName: 'abc',
      scheduleId: '62397e506bdedb4055d82ffe',
      scheduleConfig: {
        enabled: false,
        status: 'Disabled',
        lastStatusUpdatedDateTime: null,
        schedule: {
          occurence: ScheduleOccurenceTypeEnum.WEEKLY,
          timezone: '',
          runAtTime: {
            hour: '01',
            minute: '14',
            meridiemIndicator: 'PM'
          },
          daysOfWeek: ['MON', 'TUE']
        }
      },
      profileRunInformationList: profileRunInformationList ? profileRunInformationList : []
    };
    component.scheduleHistoryDetails = response;
    Spies.ScheduleService.getScheduleHistory.and.returnValue(of(response));
    component.ngOnInit();
    expect(component.isTableVisible).toBe(true);
  });
  it('check history with suspended status', () => {
    component.scheduleType = { viewType: 'Suspended', id: 'asdf556e', editEnabled: false, source: 'Profiling' };
    const response = {
      profileId: '2c9280877fb08fbb017fb09564260001',
      profileName: 'abc',
      scheduleId: '62397e506bdedb4055d82ffe',
      scheduleConfig: {
        enabled: false,
        status: 'Suspended',
        schedule: {
          occurence: 'weekly',
          timezone: '',
          runAtTime: {
            hour: '5',
            minute: '4',
            meridiemIndicator: 'AM'
          },
          daysOfWeek: ['MON', 'TUE']
        }
      },
      profileRunInformationList: [
        {
          id: '2c9280877fb08fbb017fb09c8df30007',
          runDateTime: 1647935524325,
          duration: '00:00:00',
          status: 'INPROGRESS',
          errorMessages: []
        }
      ]
    };

    Spies.ScheduleService.getScheduleHistory.and.returnValue(of(response));
    component.ngOnInit();
    expect(component.switchScheduler).toBe(false);
  });
  it('check history with not configured status', () => {
    component.scheduleType = { viewType: 'Not Configured', id: 'asdf556e', editEnabled: false, source: 'Profiling' };
    const response = {
      scheduleConfig: {
        enabled: false,
        status: 'Not Configured'
      }
    };

    Spies.ScheduleService.getScheduleHistory.and.returnValue(of(response));
    component.ngOnInit();
    expect(component.isTableVisible).toBe(true);
  });
  it('should run toggleSchedule with toggle value enabled', () => {
    component.switchScheduler = true;
    Spies.ScheduleService.toggleSchedule.and.returnValue(of(true));
    spyOn(component.refresh, 'emit');
    component.toggleSchedule();
    expect(component.refresh.emit).toHaveBeenCalled();
    expect(component.failureMessages.length).toBe(0);
  });
  it('should run toggleSchedule with toggle value disabled', () => {
    component.switchScheduler = false;
    Spies.ScheduleService.toggleSchedule.and.returnValue(of(true));
    spyOn(component.refresh, 'emit');
    component.toggleSchedule();
    expect(component.refresh.emit).toHaveBeenCalled();
  });
  it('test toggleSchedule failed at server side', () => {
    Spies.ScheduleService.toggleSchedule.and.returnValue(throwError({ error: { message: 'dummy' } }));
    component.toggleSchedule();
    expect(Spies.ToastrService['error']).toHaveBeenCalled();
  });
  it('test schedule history failed at server side', () => {
    Spies.ScheduleService.getScheduleHistory.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.ngOnInit();
    expect(Spies.ToastrService['error']).toHaveBeenCalled();
  });
  it('test schedule history failed at server side if other than 404', () => {
    Spies.ScheduleService.getScheduleHistory.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[1]));
    component.ngOnInit();
    expect(component.isTableVisible).toBe(false);
  });
  it('test cancelCreate fn', () => {
    spyOn(component.showScheduleSidebarChange, 'emit');
    component.cancelCreate();
    expect(component.showScheduleSidebarChange.emit).toHaveBeenCalled();
  });
  it('should show suspended message in case of suspended schedule', () => {
    component.scheduleType = {
      viewType: 'Suspended',
      id: 'asdf556e',
      editEnabled: false,
      source: 'observer',
      name: 'test'
    };
    const response = {
      profileId: '2c9280877fb08fbb017fb09564260001',
      profileName: 'abc',
      scheduleId: '62397e506bdedb4055d82ffe',
      scheduleConfig: {
        enabled: false,
        status: 'Suspended',
        schedule: {
          occurence: 'weekly',
          timezone: '',
          runAtTime: {
            hour: '5',
            minute: '4',
            meridiemIndicator: 'AM'
          },
          daysOfWeek: ['MON', 'TUE']
        }
      },
      profileRunInformationList: [
        {
          id: '2c9280877fb08fbb017fb09c8df30007',
          runDateTime: 1647935524325,
          duration: '00:00:00',
          status: 'INPROGRESS',
          errorMessages: []
        }
      ]
    };
    Spies.ScheduleService.getScheduleHistory.and.returnValue(of(response));
    component.ngOnInit();
    expect(component.failureActionMessages.length).toBe(1);
  });
});
