import { Component, EventEmitter, Output, ViewChild } from '@angular/core';
import { SidebarButton } from '../../shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '../../shared/components/sidebar/sidebar.component';

@Component({
  selector: 'p-connect-pipeline-details-sidebar',
  templateUrl: './pipeline-details-sidebar.component.html'
})
export class PipelineDetailsSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  @Output() primaryButtonClickedEvent = new EventEmitter();
  @Output() alertsButtonClickEvent = new EventEmitter();

  primaryButton: SidebarButton = {
    id: 'pipelineDetailsRefresh',
    text: 'common.BUTTONS.REFRESH'
  };

  cancelButton: SidebarButton = {
    id: 'pipelineDetailsClose',
    text: 'common.BUTTONS.CLOSE'
  };

  selectedPipeline: any = {};
  projectName = '';

  open(selectedPipeline: any, projectName?: string) {
    this.selectedPipeline = selectedPipeline;
    this.projectName = projectName;
    this.sidebarComponent.open();
  }

  primaryButtonClicked(): void {
    this.primaryButtonClickedEvent.emit(this.selectedPipeline);
  }

  cancelButtonClicked(): void {
    this.sidebarComponent.close();
  }

  alertsButtonClicked() {
    this.alertsButtonClickEvent.emit();
  }
}
