import { Observable } from "rxjs";

export interface HeaderHelpMenuItem {
    id: string;
    name: string;
}

export abstract class HeaderHelpMenuProvider {
    abstract getMenuItems(): Observable<Array<HeaderHelpMenuItem>>;
    abstract menuItemClicked(id: string): void;
}
