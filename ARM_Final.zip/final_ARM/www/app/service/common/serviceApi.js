(function () {
    'use strict';

    angular.module('arm').service('serviceApi',
        ['$http', '$q', '$ionicLoading', 'ENVIRONMENT', 'utility', 'GENERAL_CONFIG','$rootScope','$cordovaDialogs','ALERT_MESSAGE', serviceApi]);
    function serviceApi($http, $q, $ionicLoading, ENVIRONMENT, utility, GENERAL_CONFIG,$rootScope,$cordovaDialogs,ALERT_MESSAGE) {
        var serviceArr = this;
        serviceArr.headerConfg = {
                    headers:
                          {
                            'content-type': 'application/x-www-form-urlencoded;charset=utf-8;'
                          }};
        var url = '';
        serviceArr.doPostWithData = function (functionName, serviceType, data, config) {
            
            //serviceArr.sslValidation();

            config['headers']['token'] = $rootScope.token;
            //console.log( "Token" + $rootScope.token);

            var deferred = $q.defer();

            serviceArr.bindServerDateTimeForRequest(config);

            url = ENVIRONMENT[GENERAL_CONFIG.BUILD_ENVIRONMENT] +serviceType;

            if ($rootScope.isNetworkAvailable == false) {
                $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                   .then(function () {
                });
                return;
            }

            busyCursorStart();
            var sendData = utility.encrypt(data);

            var finalSend = { "finalData": sendData };

            $http.post(url, finalSend, config)
                .success(function (response, status, headers, responseConfig) {
                   
                    if (typeof responseConfig.WebServiceType != 'undefined') {
                        //console.log("Config response service type" + responseConfig.WebServiceType);
                        var headersValues = headers();
                        serviceArr.bindServerDateTimeFromResponse(responseConfig,headersValues);
                      }
                    //console.log(functionName + " Success");
                    var retData = '';
                    var dcrptRes = utility.decrypt(response);
                    //console.log("Response####" + JSON.stringify(dcrptRes));
                    if (dcrptRes.results != null) {
                        if (responseConfig.WebServiceType == GENERAL_CONFIG.WebServiceType.Login) {
                            if(dcrptRes.results.Status == 'Success')
                            {
                                retData = dcrptRes.results.Data;
                                if (typeof retData == 'undefined') {
                                    retData = dcrptRes.results;
                                }
                                deferred.resolve(retData);
                            }else
                            {
                                deferred.reject(dcrptRes.results.Message);
                            }

                        }else
                        {
                            retData = dcrptRes.results.Data;
                            if (typeof retData == 'undefined') {
                                retData = dcrptRes.results;
                            }
                            deferred.resolve(retData);
                       }

                    }else
                    {
                        $cordovaDialogs.alert(ALERT_MESSAGE.DECRYPTION_ERROR, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                            .then(function () {
                        });
                        deferred.reject(ALERT_MESSAGE.DECRYPTION_ERROR);
                    }
                    busyCursorEnd();


                }).error(function (error, status, headers, config) {

                    busyCursorEnd();
    
                    deferred.reject($rootScope.httpErrorMessage);
                });

            return deferred.promise;
        };

        serviceArr.doGetWithData = function (functionName, serviceType, data, config) {

            config['headers']['token'] = $rootScope.token;
            //console.log( "Token" + $rootScope.token);

            var deferred = $q.defer();

            serviceArr.bindServerDateTimeForRequest(config);

            url = ENVIRONMENT[GENERAL_CONFIG.BUILD_ENVIRONMENT] + serviceType;

            if ($rootScope.isNetworkAvailable == false) {
                $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                   .then(function () {
                });
                return;
            }

            busyCursorStart();
            var sendData = utility.encrypt(data);

            $http.get(url, { params: sendData }, config)
                .success(function (response, status, headers, responseConfig) {
                    
                    if (typeof responseConfig.WebServiceType != 'undefined') {
                        ////console.log("Config response service type" + responseConfig.WebServiceType);
                        var headersValues = headers();
                        serviceArr.bindServerDateTimeFromResponse(responseConfig,headersValues);
                      }
                    //console.log(functionName + "Success");

                    var dcrptRes = utility.decrypt(response);
                    var retData = dcrptRes.results.Data;
                    busyCursorEnd();

                    deferred.resolve(retData);
                }).error(function (error, status, headers, config) {
                    //console.log(functionName + "Time Out Error :" + error + status);

                    busyCursorEnd();
    
                    deferred.reject($rootScope.httpErrorMessage);
                });

            return deferred.promise;
        };

        serviceArr.doGetWithoutData = function (functionName, serviceType, config) {

            config['headers']['token'] = $rootScope.token;
            //console.log( "Token" + $rootScope.token);

            var deferred = $q.defer();

            serviceArr.bindServerDateTimeForRequest(config);

            url = ENVIRONMENT[GENERAL_CONFIG.BUILD_ENVIRONMENT] + serviceType;

            if ($rootScope.isNetworkAvailable == false) {
                $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                   .then(function () {
                });
                return;
            }

            busyCursorStart();

            $http.get(url, config)
                .success(function (response, status, headers, responseConfig) {

                    if (typeof responseConfig.WebServiceType != 'undefined') {
                        //console.log("Config response service type" + responseConfig.WebServiceType);
                      var headersValues = headers();
                        serviceArr.bindServerDateTimeFromResponse(responseConfig,headersValues);
                         }
                    //console.log(functionName + "Success");
                    //console.log("Status: " + status);
                    busyCursorEnd();
                    if (status == '204') {
                        deferred.resolve(status);
                    }
                    else {
                        var dcrptRes = utility.decrypt(response);
                        if(dcrptRes.results != null)
                         {
                            var retData = dcrptRes.results.Data;
                            deferred.resolve(retData);
                         }else
                         {
                            deferred.reject("Invalid server response");
                         }
                    }

                }).error(function (error, status, headers, config) {
                    //console.log(functionName + "Time Out Error :" + error + status);

                    busyCursorEnd();
    
                    deferred.reject($rootScope.httpErrorMessage);
                });

            return deferred.promise;
        };

        serviceArr.doPutWithData = function (data, serviceType, functionName) {

            config['headers']['token'] = $rootScope.token;
            //console.log( "Token" + $rootScope.token);

            var deferred = $q.defer();

            serviceArr.bindServerDateTimeForRequest(config);

            url = ENVIRONMENT[GENERAL_CONFIG.BUILD_ENVIRONMENT] + serviceType;

            if ($rootScope.isNetworkAvailable == false) {
                $cordovaDialogs.alert(ALERT_MESSAGE.NETWORK, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                   .then(function () {
                });
                return;
            }
            busyCursorStart();
            var sendData = utility.encrypt(data);

            $http(
            {
                method: 'PUT',
                url: url,
                data: sendData
            })
            .success(function (response, status, headers, responseConfig) {
                
                if (typeof responseConfig.WebServiceType != 'undefined') {
                        //console.log("Config response service type" + responseConfig.WebServiceType);
                        var headersValues = headers();
                        serviceArr.bindServerDateTimeFromResponse(responseConfig,headersValues);
                    };
                //console.log(functionName + "Success");
                //console.log("Status: " + status);
                busyCursorEnd();
                if (status == '204') {
                    deferred.resolve(status);ßß
                }
                else {
                    deferred.resolve(response);
                }

            }).error(function (error, status, headers, config) {
                    //console.log(functionName + "Time Out Error :" + error + status);

                    busyCursorEnd();
    
                    deferred.reject($rootScope.httpErrorMessage);
                });

            return deferred.promise;
        };

        serviceArr.bindServerDateTimeForRequest = function(config)
        {
            var webServiceType = config.WebServiceType;
            if (webServiceType == GENERAL_CONFIG.WebServiceType.Login) { return ;};
            var serverDateTimes = null;
            var dateStringInUTC = utility.getDateStringInUTC(new Date());
              if( $rootScope.isAccessingOtherUserProfile == false)
                {
                    serverDateTimes = utility.getMasterDataByKey(GENERAL_CONFIG.ServerDateTimes).LoggedInuser;
                }else
                {
                    serverDateTimes = utility.getMasterDataByKey(GENERAL_CONFIG.ServerDateTimes).LoggedInAsOtheruser;
                }
                //console.log("Date Time Request Before" + JSON.stringify(serverDateTimes));
                switch (webServiceType) {
                        case GENERAL_CONFIG.WebServiceType.Master:
                        {
                             if (serverDateTimes.MasterDateTime == '') {
                                serverDateTimes.MasterDateTime = dateStringInUTC;
                             }
                             config['headers']['masterdatetime'] = serverDateTimes.MasterDateTime;
                        }
                         break;
                        case GENERAL_CONFIG.WebServiceType.ContactListPrev:
                        {
                             if (serverDateTimes.ContactDateTime.Prev == '') {
                                serverDateTimes.ContactDateTime.Prev = dateStringInUTC;
                                serverDateTimes.ContactDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['contactdatetime'] = serverDateTimes.ContactDateTime.Prev;
                        }
                         break;
                        case GENERAL_CONFIG.WebServiceType.ContactListNext:
                        {
                             if (serverDateTimes.ContactDateTime.Next == '') {
                                serverDateTimes.ContactDateTime.Prev = dateStringInUTC;
                                serverDateTimes.ContactDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['contactdatetime'] = serverDateTimes.ContactDateTime.Next;
                        }
                         break;

                        case GENERAL_CONFIG.WebServiceType.ActivityListPrev:
                        {
                             if (serverDateTimes.ActivityDateTime.Prev == '') {
                                serverDateTimes.ActivityDateTime.Prev = dateStringInUTC;
                                serverDateTimes.ActivityDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['activitydatetime'] = serverDateTimes.ActivityDateTime.Prev;
                        }
                         break;
                        case GENERAL_CONFIG.WebServiceType.ActivityListNext:
                        {
                             if (serverDateTimes.ActivityDateTime.Next == '') {
                                serverDateTimes.ActivityDateTime.Prev = dateStringInUTC;
                                serverDateTimes.ActivityDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['activitydatetime'] = serverDateTimes.ActivityDateTime.Next;
                        }
                         break;
                         case GENERAL_CONFIG.WebServiceType.DealListPrev:
                        {
                             if (serverDateTimes.DealDateTime.Prev == '') {
                                serverDateTimes.DealDateTime.Prev = dateStringInUTC;
                                serverDateTimes.DealDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['dealdatetime'] = serverDateTimes.DealDateTime.Prev;
                        }
                         break;
                        case GENERAL_CONFIG.WebServiceType.DealListNext:
                        {
                             if (serverDateTimes.DealDateTime.Next == '') {
                                serverDateTimes.DealDateTime.Prev = dateStringInUTC;
                                serverDateTimes.DealDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['dealdatetime'] = serverDateTimes.DealDateTime.Next;
                        }
                        break;
                        case GENERAL_CONFIG.WebServiceType.HomeList:
                        {
                            if (serverDateTimes.HomeDateTime == '') {
                                serverDateTimes.HomeDateTime = dateStringInUTC;
                            }
                            config['headers']['homedatetime'] = serverDateTimes.HomeDateTime;
                        }
                        break;
                        case GENERAL_CONFIG.WebServiceType.UserListPrev:
                        {
                             if (serverDateTimes.UserDateTime.Prev == '') {
                                serverDateTimes.UserDateTime.Prev = dateStringInUTC;
                                serverDateTimes.UserDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['userdatetime'] = serverDateTimes.UserDateTime.Prev;
                        }
                         break;
                        case GENERAL_CONFIG.WebServiceType.UserListNext:
                        {
                             if (serverDateTimes.UserDateTime.Next == '') {
                                serverDateTimes.UserDateTime.Prev = dateStringInUTC;
                                serverDateTimes.UserDateTime.Next = dateStringInUTC;
                             }
                             config['headers']['userdatetime'] = serverDateTimes.UserDateTime.Next;
                        }
                        break;

                        default:
                    }

                    //console.log("Date Time Request After" + JSON.stringify(config));
        };

        serviceArr.bindServerDateTimeFromResponse = function(config,resHeaders)
        {
            var  webServiceType = config.WebServiceType;
            if (webServiceType == GENERAL_CONFIG.WebServiceType.Login) { return ;};

            var serverDateTimes = utility.getMasterDataByKey(GENERAL_CONFIG.ServerDateTimes);
            var dateTimes = null;
            if( $rootScope.isAccessingOtherUserProfile == false)
                {
                    dateTimes = serverDateTimes.LoggedInuser;
                }else
                {
                    dateTimes = serverDateTimes.LoggedInAsOtheruser;
                }
                //console.log("Date Time response Before Storage" + JSON.stringify(config));
                switch (webServiceType) {
                        case GENERAL_CONFIG.WebServiceType.Master:
                        {
                            if ($rootScope.loadNewMasterDataForLoggedInAsUser == false) {
                                serverDateTimes.LoggedInuser.MasterDateTime = resHeaders['masterdatetime'];
                                serverDateTimes.LoggedInAsOtheruser.MasterDateTime = resHeaders['masterdatetime'];
                            }else
                            {
                                dateTimes.MasterDateTime = resHeaders['masterdatetime'];
                            }
                        }
                         break;
                         case GENERAL_CONFIG.WebServiceType.ContactListPrev:
                        {
                             dateTimes.ContactDateTime.Prev = resHeaders['contactdatetime'];
                        }
                         break;
                         case GENERAL_CONFIG.WebServiceType.ContactListNext:
                        {
                             dateTimes.ContactDateTime.Next = resHeaders['contactdatetime'];
                        }
                         break;
                        case GENERAL_CONFIG.WebServiceType.ActivityListPrev:
                        {
                             dateTimes.ActivityDateTime.Prev = resHeaders['activitydatetime'];
                        }
                         break;
                         case GENERAL_CONFIG.WebServiceType.ActivityListNext:
                        {
                             dateTimes.ActivityDateTime.Next = resHeaders['activitydatetime'];
                        }
                         break;
                          case GENERAL_CONFIG.WebServiceType.DealListPrev:
                        {
                             dateTimes.DealDateTime.Prev = resHeaders['dealdatetime'];
                        }
                         break;
                         case GENERAL_CONFIG.WebServiceType.DealListNext:
                        {
                             dateTimes.DealDateTime.Next = resHeaders['dealdatetime'];
                        }
                        break;
                        case GENERAL_CONFIG.WebServiceType.HomeDateTime:
                        {
                             dateTimes.HomeDateTime.Next = resHeaders['homedatetime'];
                        }
                        break;
                        case GENERAL_CONFIG.WebServiceType.UserListPrev:
                        {
                             dateTimes.UserDateTime.Prev = resHeaders['userdatetime'];
                        }
                         break;
                         case GENERAL_CONFIG.WebServiceType.UserListNext:
                        {
                             dateTimes.UserDateTime.Next = resHeaders['userdatetime'];
                        }
                        break;
                        

                        default:
                    }
                if( $rootScope.isAccessingOtherUserProfile == false)
                {
                     serverDateTimes.LoggedInuser = dateTimes;
                }else
                {
                     serverDateTimes.LoggedInAsOtheruser = dateTimes;
                }
                //console.log("Date Time response " + JSON.stringify(serverDateTimes));
            utility.setMasterData(GENERAL_CONFIG.ServerDateTimes, serverDateTimes);
        };
        
        
        serviceArr.sslValidation = function()
        {

              var server = ENVIRONMENT[GENERAL_CONFIG.BUILD_ENVIRONMENT];
              var fingerprint = "22 F1 08 9B 45 C2 92 E2 31 13 53 5C 09 AC E1 3B 6E 2C 5C 01"; // valid until sep 2014

              window.plugins.sslCertificateChecker.check(
                      successCallback,
                      errorCallback,
                      server,
                      fingerprint);

               function successCallback(message) {
                alert(message);
                 // Message is always: CONNECTION_SECURE.
                 // Now do something with the trusted server.
                 //console.log("######YUPEEE### secured");
                 // return serviceApi.doPostWithData("authService",
                 //    SERVICE_TYPE.LOGIN, credentials, serviceApi.headerConfg).then(function (response) {
                 //        //console.log("response" + response);
                 //        return response;
                 //    });
                //  var headerConfg = {
                //     headers:
                //           {
                //             'Content-Type': 'application/json'
                //           }};
                // serviceArr.doGetWithoutData('GetAllEnums', 'https://salestool.emiratesnbd.com/SATIPhoneService/UtilityService.svc/GetAllEnums', headerConfg).then(function (response) {
                //     //console.log(JSON.stringify(response));
                // });

               }

               function errorCallback(message) {
                 alert(message);
                 if (message == "CONNECTION_NOT_SECURE") {
                   // There is likely a man in the middle attack going on, be careful!
                   //console.log("### Not secured" + message);
                 } else if (message == "CONNECTION_FAILED") {
                   // There was no connection (yet). Internet may be down. Try again (a few times) after a little timeout.
                    //console.log("### Connection failed" + message);

                 }
               }
        }

        function busyCursorStart() {
            $ionicLoading.show({
                template: 'Loading...'
            });
        };

        function busyCursorEnd() {

            $ionicLoading.hide();
        };
    };
})();
