const PROXY_CONFIG = [
  {
    context: ['/api/v1/report'],
    target: 'https://dobreporting-dev.profiling.cloud.precisely.services',
    secure: true,
    changeOrigin: true,
    logLevel: 'debug'
  },
  {
    context: ['/api/v1/dataprofiles', '/api/v1/dataprofiles/trends/metric'],
    target: 'https://obsmetrics-dev.profiling.cloud.precisely.services',
    secure: true,
    changeOrigin: true,
    logLevel: 'debug'
  },
  {
    context: ['/api/v1/alerts', '/api/v1/observables', '/api/v1/observable'],
    target: 'https://dataobservabilityconfig-dev.profiling.cloud.precisely.services',
    secure: true,
    changeOrigin: true,
    logLevel: 'debug'
  },
  {
    context: ['/api'],
    target: 'https://configapi-dev.profiling.cloud.precisely.services',
    secure: true,
    changeOrigin: true,
    logLevel: 'debug'
  },
  {
    context: ['/v1/files', '/catalog'],
    target: 'https://gateway-dev.dqcore.cloud.precisely.services',
    secure: true,
    changeOrigin: true,
    logLevel: 'debug'
  }
];
module.exports = PROXY_CONFIG;
