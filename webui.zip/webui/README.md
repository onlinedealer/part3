# Discovery App

This project was generated with [Angular CLI](https://angular.io/cli) version 11.2.4.

### 1. Get the Code

```
git clone https://gitlab.com/preciselydata/data-quality/discovery-cloud/ui/webui.git
```

### 2. Install dependencies

you should have .npmrc FILE with your credential in your %USERPROFILE%
In the webui folder, run

```

npm run setup

```

which will install dependencies in the client folders

### 3. Build the application

In the webui folder, run

```
npm run build
```

from the project root. The build artifacts will be stored in the `dist` directory.

### 4. Running in Docker

**Configuration**

**Install Docker for Desktop**

NOTE: Make sure you have the proper resources (memory, disk, processors, etc...) configured for Docker. This is configured under Preferences -> Resources. I have mine set to 8 CPUs, 12 Gigs RAM and 1 GB swap.

1.  Run the following command:
    docker login registry.gitlab.com
    you need to have security access token for accessing to gitlab registry
    https://gitlab.com/-/profile/personal_access_tokens
    check read registry checkbox and create token
    Enter company credentials to access repository (vinay.nijhawan@precisely.com/xxxxxxxx) and enter above token as passowrd.

### 5. Starting web application for development using docker-compose

1.  Navigate to webui folder in command window. Please make sure you will have .npmrc file with your credentials @ root.
2.  To start the web application , enter the following command:
    docker-compose up --build
3.  open localhost:4200 you will see the landing page in live mode within the running container

## Notes-

## Build & Run Application in Docker

```
docker build -t discoverycloud:Production .
docker run --rm -d  -p 4200:8081 --env CONFIG_SERVER_URL="https://configapi-qa.profiling.cloud.precisely.services" --env CLIENT_ID="OIDC-Discovery" --env STS_SERVER="https://auth-qa.cloud.precisely.services/auth/realms/Precisely" discoverycloud:Production
```

## Run Application in Docker using Image from GitLab Registry

```
docker login registry.gitlab.com -u user_precisely_email -p gitlab_access_token

docker run --rm -d  -p 4200:8081 --env CONFIG_SERVER_URL="https://configapi-dev.profiling.cloud.precisely.services" --env CLIENT_ID="OIDC-Discovery" --env STS_SERVER="https://auth-dev.cloud.precisely.services/auth/realms/Precisely" registry.gitlab.com/preciselydata/data-quality/discovery-cloud/UI/webui/discoverycloud:gitlab_image_tag

## If you do not yet have a Node development environment set up:

Download and install [Node.js](https://nodejs.org) for your platform, version 8.9 or higher, Node Package Manager, [npm](https://www.npmjs.com/), will also be installed.(**Note:** we also recommend using Node Version Manager, [nvm](https://github.com/creationix/nvm) or [nvm-windows](https://github.com/coreybutler/nvm-windows))

Install Angular CLI globally by running

```

npm i -g @angular/cli

```

Refer to the [Angular CLI](https://angular.io/cli) documentation for detailed information.

Optionally install [Prettier](https://prettier.io/), [EditorConfig](http://editorconfig.org/), [HtmlHint](http://htmlhint.com/) and [Stylelint](https://stylelint.io/) for your code editor.
```

# runnig test cases

1.  npm run test-once chrome headless mode
2.  npm run test
3.  test coverage npm run test-coverage

# code check in instructions

1.  before submitted the merge request make sure you run **npm run build-prod**, this will fix all linting issue and notifies if something failing
2.  please send the merge request to Vinay and Gautam for approval.

# docker images proxy setup for UI development (local env)

1. Add/replace below lines in proxy.conf.ts file (root level):
    ```
    const PROXY_CONFIG = [
    {
    context: ['/api/v1/alerts', '/api/v1/observables', '/api/v1/observable'],
    target: 'http://observability-service:8095',
    secure: false
    },
    {
    context: ['/api/v1/dataprofiles', '/api/v1/dataprofiles/trends/metric'],
    target: 'http://metrics-service:8100',
    secure: false
    },
    {
    context: ['/api'],
    target: 'http://config-service:8090',
    secure: false
    }
    ];
    module.exports = PROXY_CONFIG;
    ```
2. run docker via docker-compose up --build
