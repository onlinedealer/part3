import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA, Input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { of, throwError } from 'rxjs';
import { Connection } from '../../../connections/shared/connection';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { MetabasesApiService } from '../../../metabases/shared/metabases-api.service';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { Pipeline } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { LogReaderConfigurationSidebarComponent } from './logreaders/logreader-configuration-sidebar/logreader-configuration-sidebar.component';
import { PipelineDataComponent } from './pipeline-data.component';
import { SchemaTableSelectorComponent } from './schema-table-selector/schema-table-selector.component';
import { SourceGeneralComponent } from './source-general/source-general.component';

@Component({
  selector: 'p-connect-schema-table-selector',
  template: '',
  providers: [
    {
      provide: SchemaTableSelectorComponent,
      useClass: MockSchemaTableSelectorComponent
    }
  ]
})
class MockSchemaTableSelectorComponent {
  @Input() projectId: string;
  @Input() sourceDataConnection: Connection;
  loadSchemaData() {}
  getJournals() {}
}

@Component({
  selector: 'p-connect-source-general',
  template: '',
  providers: [
    {
      provide: SourceGeneralComponent,
      useClass: MockSourceGeneralComponent
    }
  ]
})
class MockSourceGeneralComponent {
  getLogReaders() {}
}

@Component({
  selector: 'p-connect-logreader-configuration-sidebar',
  template: '',
  providers: [
    {
      provide: LogReaderConfigurationSidebarComponent,
      useClass: MockLogReaderConfigurationSidebarComponent
    }
  ]
})
class MockLogReaderConfigurationSidebarComponent {
  open() {}
}

const mockPipeline = {
  id: 'abc',
  projectId: 'abcd',
  source: {
    dataConnection: { id: 'abcd' }
  }
} as Pipeline;

describe('PipelineDataComponent', () => {
  let component: PipelineDataComponent;
  let fixture: ComponentFixture<PipelineDataComponent>;
  let pipelineEntityService: PipelineEntityService;
  let metabasesApiService: MetabasesApiService;

  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['setIsValid', 'setActiveStepIndex']
  );

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, RouterTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [
        PipelineDataComponent,
        MockSchemaTableSelectorComponent,
        MockSourceGeneralComponent,
        MockLogReaderConfigurationSidebarComponent
      ],
      providers: [{ provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService }]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(PipelineDataComponent);
    metabasesApiService = TestBed.inject(MetabasesApiService);
    pipelineEntityService = TestBed.inject(PipelineEntityService);

    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockPipeline);
    spyOn(metabasesApiService, 'get').and.returnValue(of({}));

    component = fixture.componentInstance;

    component.sourceDataConnection = { connectionType: 'ORACLE' } as Connection;
    component.projectId = 'abcd';

    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component.schemaTableSelectorComponent).toBeDefined();
    expect(component).toBeTruthy();
  });

  it('should not open metabase sidebar', () => {
    const pipeline = {
      projectId: 'abcd',
      source: {
        dataConnection: { id: 'abcd', connectionType: 'DB2ZOS' }
      }
    } as Pipeline;
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    component.ngOnInit();
    expect(component.isMetabaseSidebarVisible).toBe(false);
  });

  it('should call setIsValid when the status changes', () => {
    const saveSpy = spyOn(component, 'saveLogReaderParameter');
    component.sourceDataConnection.connectionType = 'DB2I';
    component.tableStatusChanged({ status: true, journal: 'newJournal' });
    expect(mockProgressIndicatorStateService.setIsValid).toHaveBeenCalled();
    expect(component.saveLogReaderParameter).toHaveBeenCalled();
    saveSpy.calls.reset();
    component.tableStatusChanged({ status: true, journal: 'newJournal', isLoading: true });
    expect(component.saveLogReaderParameter).not.toHaveBeenCalled();
  });

  it('should load schemas if a metabase already exists', () => {
    spyOn(metabasesApiService, 'get').and.returnValue(of({}));
    spyOn(component.schemaTableSelectorComponent, 'loadSchemaData').and.returnValue();
    component.sourceDataConnection = { connectionType: 'ORACLE' };
    const pipeline = {
      projectId: 'abcd',
      source: {
        dataConnection: { id: 'abcd', connectionType: 'ORACLE' }
      }
    } as Pipeline;
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    jasmine.clock().install();
    component.ngAfterViewInit();
    jasmine.clock().tick(500);
    expect(component.schemaTableSelectorComponent.loadSchemaData).toHaveBeenCalled();
    jasmine.clock().uninstall();
  });

  it('should open sidebar to create a metabase if one does not exist', () => {
    spyOn(metabasesApiService, 'get').and.returnValue(throwError({ status: 404 }));
    component.sourceDataConnection = { connectionType: 'ORACLE' };
    const pipeline = {
      projectId: 'abcd',
      source: {
        dataConnection: { id: 'abcd', connectionType: 'ORACLE' }
      }
    } as Pipeline;
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    jasmine.clock().install();
    component.ngAfterViewInit();
    jasmine.clock().tick(500);
    expect(component.isMetabaseSidebarVisible).toBe(true);
    jasmine.clock().uninstall();
  });

  it('should not open sidebar to create a metabase for other errors', () => {
    spyOn(metabasesApiService, 'get').and.returnValue(throwError({ status: 500 }));
    component.sourceDataConnection = { connectionType: 'ORACLE' };
    const pipeline = {
      projectId: 'abcd',
      source: {
        dataConnection: { id: 'abcd', connectionType: 'ORACLE' }
      }
    } as Pipeline;
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    jasmine.clock().install();
    component.ngAfterViewInit();
    jasmine.clock().tick(500);
    expect(component.isMetabaseSidebarVisible).toBe(false);
    jasmine.clock().uninstall();
  });

  it('should handle saved event', () => {
    spyOn(component.schemaTableSelectorComponent, 'loadSchemaData').and.returnValue();
    spyOn(component.schemaTableSelectorComponent, 'getJournals').and.returnValue();
    component.sourceDataConnection.connectionType = 'DB2I';
    component.metabaseSavedEvent();
    expect(component.schemaTableSelectorComponent.loadSchemaData).toHaveBeenCalled();
    expect(component.schemaTableSelectorComponent.getJournals).toHaveBeenCalled();
  });

  it('should filter the tables based on the selected log reader', () => {
    const logReader = {
      name: '',
      journalName: ''
    };
    component.sourceDataConnection.connectionType = 'DB2I';
    component.selectedLogReaderChanged(logReader);
    component.selectedLogReader = null;
    const logReaders = {
      name: 'Autogenerate',
      journalName: ''
    };
    component.selectedLogReaderChanged(logReaders);
    component.selectedLogReader = logReaders;
    expect(component.selectedLogReader.name).toEqual('Autogenerate');
  });

  it('should filter the tables based on the selected log reader if data connection is DB2UDB', () => {
    const dataConnection = 'DB2UDB';
    const logReader = {
      name: '',
      journalName: ''
    };
    let logReaderParameters: { key: string; value: string }[];
    component.sourceDataConnection.connectionType = dataConnection;
    component.selectedLogReaderChanged(logReader);
    logReaderParameters = [
      {
        key: 'IBMI_LOG_READER_NAME',
        value: logReader.name
      },
      {
        key: 'IBMI_JOURNAL_NAME',
        value: logReader.journalName
      }
    ];
    expect(logReaderParameters).toEqual(logReaderParameters);
  });

  it('should filter the tables based on the selected log reader if data connection is DB2I and logReader is Autogenerate', () => {
    const dataConnection = 'DB2I';
    const logReader = {
      name: 'Autogenerate',
      journalName: ''
    };
    let logReaderParameters: { key: string; value: string }[];
    component.sourceDataConnection.connectionType = dataConnection;
    component.selectedLogReaderChanged(logReader);
    logReaderParameters = [
      {
        key: 'LUW_LOG_READER_NAME',
        value: logReader.name
      }
    ];
    expect(logReaderParameters).toEqual(logReaderParameters);
  });

  it('should filter the tables based on the selected log reader if data connection is DB2I', () => {
    const dataConnection = 'DB2I';
    const logReader = {
      name: null,
      journalName: ''
    };
    let logReaderParameters: { key: string; value: string }[];
    component.sourceDataConnection.connectionType = dataConnection;
    component.selectedLogReaderChanged(logReader);
    logReaderParameters = [
      {
        key: 'LUW_LOG_READER_NAME',
        value: logReader.name
      }
    ];
    expect(logReaderParameters).toEqual(logReaderParameters);
  });

  describe('on save', () => {
    beforeEach(() => {
      spyOn(pipelineEntityService, 'patchPipeline').and.stub();
      component.selectedLogReader = {
        name: 'name',
        journalName: 'journal'
      };
    });

    it('saves correct params for DB2I and not Autogenerate', () => {
      component.sourceDataConnection.connectionType = 'DB2I';

      component.saveLogReaderParameter();
      let expected = [
        { key: 'IBMI_LOG_READER_NAME', value: 'name' },
        { key: 'IBMI_JOURNAL_NAME', value: 'journal' },
        ...component.possibleKeys
      ];
      expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith({ properties: expected });
    });

    it('saves correct params for DB2I and Autogenerate', () => {
      component.sourceDataConnection.connectionType = 'DB2I';
      component.selectedLogReader.name = 'Autogenerate';
      component.selectedJournal = 'selectedJournal';

      component.saveLogReaderParameter();
      let expected = [{ key: 'IBMI_JOURNAL_NAME', value: 'selectedJournal' }, ...component.possibleKeys];
      expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith({ properties: expected });
    });

    it('saves correct params for DB2', () => {
      component.sourceDataConnection.connectionType = 'DB2';

      component.saveLogReaderParameter();
      let expected = [{ key: 'LUW_LOG_READER_NAME', value: 'name' }, ...component.possibleKeys];
      expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith({ properties: expected });
    });

    it('saves correct params for other connection type', () => {
      component.sourceDataConnection.connectionType = 'other';

      component.saveLogReaderParameter();
      let expected = component.possibleKeys;
      expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith({ properties: expected });
    });
  });

  it('should set previously saved schemas', () => {
    const pipeline = {
      projectId: 'abcd',
      source: {
        dataConnection: { id: 'abcd', connectionType: 'DB2ZOS' },
        selectedTables: [
          {
            key: 'schema1',
            value: {
              tableExtractType: 'INCLUDE',
              tableAndKeys: [
                { tableName: 'table1', keys: [] },
                { tableName: 'table2', keys: [] }
              ]
            }
          },
          {
            key: 'schema2',
            value: { tableExtractType: 'INCLUDE', tableAndKeys: [{ tableName: 'table1', keys: [] }] }
          }
        ]
      }
    } as Pipeline;
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    component.ngOnInit();
    expect(component.savedSchemas.length).toBe(2);
    expect(component.savedSchemas[0].name).toBe('schema1');
    expect(component.savedSchemas[0].tables.length).toBe(2);
    expect(component.savedSchemas[0].tables[0]).toBe('table1');
    expect(component.savedSchemas[0].tables[1]).toBe('table2');
    expect(component.savedSchemas[1].name).toBe('schema2');
    expect(component.savedSchemas[1].tables.length).toBe(1);
    expect(component.savedSchemas[1].tables[0]).toBe('table1');
  });

  it('should update the log readers', () => {
    spyOn(component.sourceGeneralComponent, 'getLogReaders');
    component.updateLogReaders();
    expect(component.sourceGeneralComponent.getLogReaders).toHaveBeenCalled();
  });

  it('should open the log reader configuration sidebar', () => {
    component.sourceDataConnection = { connectionType: 'DB2I' };
    fixture.detectChanges();
    spyOn(component.logReaderSidebar, 'open');
    component.configurationButtonClicked();
    expect(component.logReaderSidebar.open).toHaveBeenCalled();
  });

  it('should handle cancelling create metabase', () => {
    spyOn(component, 'navigateTo');
    component.metabaseCancelButtonClicked(true);
    expect(component.navigateTo).toHaveBeenCalledWith(`/pipelines/${mockPipeline.id}/edit/connections`);
    expect(mockProgressIndicatorStateService.setActiveStepIndex).toHaveBeenCalledWith(1);
  });

  it('should clear the saved schemas if the previous dataFlowType was COPY with an IBMi connection', () => {
    const pipeline = {
      ...mockPipeline,
      previousDataFlowType: 'COPY',
      source: {
        dataConnection: {
          connectionType: 'DB2I'
        }
      }
    };
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    component.ngOnInit();
    expect(component.savedSchemas).toEqual([]);
  });
});
