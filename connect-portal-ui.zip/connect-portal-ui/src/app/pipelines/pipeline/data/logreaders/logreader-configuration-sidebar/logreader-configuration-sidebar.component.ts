import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Connection } from 'src/app/connections/shared/connection';
import { BaseComponent } from 'src/app/core/base.component';
import { SidebarButton } from 'src/app/shared/components/sidebar/sidebar-button';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { LogReader } from '../../shared/logreader';
import { LogReaderConfigurationFormComponent } from '../logreader-configuration-form/logreader-configuration-form.component';

@Component({
  selector: 'p-connect-logreader-configuration-sidebar',
  templateUrl: './logreader-configuration-sidebar.component.html'
})
export class LogReaderConfigurationSidebarComponent extends BaseComponent {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  @ViewChild(LogReaderConfigurationFormComponent) logReaderFormComponent: LogReaderConfigurationFormComponent;

  @Input() sourceDataConnection: Connection;
  @Output() updateLogReadersEvent = new EventEmitter();
  selectedLogReader: LogReader = null;
  closeButton: SidebarButton = {
    id: 'closeButton',
    text: 'logreaders.CONFIGURATION_FORM.BUTTONS.CLOSE'
  };

  secondaryButton: SidebarButton = {
    isHidden: true
  };

  primaryButton: SidebarButton = {
    isHidden: true
  };

  open(logReader) {
    this.selectedLogReader = logReader;
    this.logReaderFormComponent.open(logReader);
    this.sidebarComponent.open();
  }

  cancelSidebarButtonClicked() {
    this.sidebarComponent.close();
    this.logReaderFormComponent.close();
    this.updateLogReadersEvent.emit();
  }
}
