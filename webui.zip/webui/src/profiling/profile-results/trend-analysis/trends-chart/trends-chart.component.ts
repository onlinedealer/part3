import { Component, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { Helper, SharedConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-trends-chart',
  templateUrl: './trends-chart.component.html'
})
export class TrendsChartComponent implements OnInit {
  _stat: any;
  _trends: any;
  get trends(): any {
    return this._trends;
  }
  @Input()
  set trends(val: any) {
    this._trends = val;
    this.loadChartOptions();
    this.loadChartData();
  }

  get stat(): any {
    return this._stat;
  }
  @Input()
  set stat(val: any) {
    this._stat = val;
    this.loadChartOptions();
    this.loadChartData();
  }
  percentOnYAxis: boolean;
  data: any;
  options: any;
  @Input() type: string;
  constructor(private translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.loadChartOptions();
    this.loadChartData();
  }

  loadChartOptions(): void {
    this.percentOnYAxis = SharedConstants.trendsKeys[this.stat]?.indexOf('PERCENTAGE') > 0;
    this.options = {
      plugins: {
        tooltip: {
          callbacks: {
            title: (tooltipItems) => this.createTooltip(tooltipItems, this.stat),
            label: this.emptyLabel,
            footer: this.dateFormat
          }
        },
        legend: {
          display: false
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            align: 'end',
            text: this.translocoService?.translate('discoveryProfiling.results.trends.xAxisLabel')
          },
          grid: {
            display: false,
            drawOnChartArea: false,
            drawTicks: false,
            color: SharedConstants.CHARTFONTSCOLORS.GRID
          },
          ticks: {
            callback: function (val) {
              let formatDate = Helper.getConvertedDateOnToolTip(this.getLabelForValue(val));
              return formatDate.date + '/' + formatDate.shortMonth + '/' + formatDate.year;
            },
            source: 'auto',
            color: SharedConstants.CHARTFONTSCOLORS.TICKS,
            display: true,
            padding: 10
          }
        },
        y: {
          title: {
            display: true,
            align: 'end',
            text: this.stat
          },
          grid: {
            drawTicks: false,
            color: '#f2f2f2'
          },
          ticks: {
            color: SharedConstants.CHARTFONTSCOLORS.TICKS,
            display: true,
            callback: (label) => this.createYAxisLabel(label),
            padding: 10,
            stepSize: 1
          }
        }
      }
    };
  }

  createTooltip(tooltipItems, stat) {
    if (
      (this.type === SharedConstants.trendDataType.DATE ||
        this.type === SharedConstants.trendDataType.DATETIME ||
        this.type === SharedConstants.trendDataType.TIMESTAMP) &&
      !this.percentOnYAxis
    ) {
      const convertedDate = Helper.getConvertedDateOnToolTip(tooltipItems[0].parsed.y);
      switch (this.type) {
        case SharedConstants.trendDataType.DATE:
          return `${stat}: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}`;
        case SharedConstants.trendDataType.DATETIME:
        case SharedConstants.trendDataType.TIMESTAMP:
          return `${stat}: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}, ${convertedDate.hour}:${convertedDate.min}:${convertedDate.sec}`;
      }
    } else if (this.type === SharedConstants.trendDataType.TIME && !this.percentOnYAxis) {
      let value = parseInt(tooltipItems[0].raw);
      let time = new Date(value * 1000).toISOString().slice(11, 19);
      return `${stat}: ${time}`;
    } else {
      return `${stat}: ${tooltipItems[0].formattedValue}${this.percentOnYAxis ? '%' : ''}`;
    }
  }

  createYAxisLabel(label) {
    if (
      (this.type === SharedConstants.trendDataType.DATE ||
        this.type === SharedConstants.trendDataType.DATETIME ||
        this.type === SharedConstants.trendDataType.TIMESTAMP) &&
      !this.percentOnYAxis
    ) {
      const formatDate = Helper.getConvertedDateOnToolTip(label);
      return formatDate.date + '/' + formatDate.shortMonth + '/' + formatDate.year;
    } else if (this.type === SharedConstants.trendDataType.TIME && !this.percentOnYAxis) {
      return new Date(label * 1000).toISOString().slice(11, 19);
    } else {
      return label;
    }
  }

  dateFormat(tooltipItems) {
    const convertedDate = Helper.getConvertedDateOnToolTip(tooltipItems[0].label);
    return `Date: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}, ${convertedDate.hour}:${convertedDate.min}:${convertedDate.sec}`;
  }

  emptyLabel() {
    return '';
  }

  loadChartData(): any {
    let labels: Date[] = [];
    // value for y-axis on chart could be number or date so we are setting its type as any
    let values: any[] = [];

    this.trends?.forEach((element: { startTime: string; value: any }) => {
      let dataPointDate = new Date(element.startTime);
      let valuePoints: any;
      if (
        (this.type === SharedConstants.trendDataType.DATE ||
          this.type === SharedConstants.trendDataType.DATETIME ||
          this.type === SharedConstants.trendDataType.TIMESTAMP) &&
        !this.percentOnYAxis
      ) {
        valuePoints = new Date(element.value);
      } else if (this.type === SharedConstants.trendDataType.TIME && !this.percentOnYAxis) {
        let timeArray = element.value.toString().split(':');
        valuePoints = +timeArray[0] * 60 * 60 + +timeArray[1] * 60 + +timeArray[2];
      } else {
        valuePoints = element.value;
      }
      labels.push(dataPointDate);
      values.push(valuePoints);
    });
    this.data = {
      labels: labels,
      datasets: [
        {
          label: '',
          data: values,
          barThickness: 80,
          maxBarThickness: 80,
          borderColor: '#AC72F9',
          backgroundColor: '#AC72F9',
          lineTension: 0,
          pointStyle: 'rectRounded',
          pointRadius: 6
        },
        {
          label: '',
          data: values,
          barThickness: 20,
          maxBarThickness: 20,
          borderColor: '#AC72F9',
          backgroundColor: '#AC72F9',
          lineTension: 0
        }
      ]
    };
  }
}
