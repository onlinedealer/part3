export class AlertConstants {
  public static COLUMN_TYPE = {
    DATE: 'DATE',
    DATETIME: 'DATETIME',
    TIMESTAMP: 'TIMESTAMP',
    TIME: 'TIME'
  };

  public static METRIC_TYPE = {
    MINIMUM_VALUE: 'VALUE_MIN',
    MAXIMUM_VALUE: 'VALUE_MAX',
    ROW_COUNT: 'ROW_COUNT',
    CARDINALITY_DETAIL: 'CARDINALITY_DETAIL'
  };

  public static ALERT_TYPE = {
    VOLUME: 'Volume',
    DATA_DRIFT: 'Data Drift'
  };

  public static HIGHLIGHT_COLOR = {
    CRITICAL: '#cb0350',
    WARNING: '#eac010'
  };

  public static MULTILINE_COLORS = [
    '#AC72F9',
    '#5B1CB5',
    '#FF7A00',
    '#2C0066',
    '#38A1E3',
    '#004151',
    '#F687D1',
    '#5B5F35',
    '#630041',
    '#0081A1'
  ];

  public static TRENDS_COUNT_LIMIT = 10;
  public static EXPORT_REPORT_PROCESS_COMPLETE = 'INPROGRESS';
  public static CRITICAL = 'CRITICAL';
  public static WARNING = 'WARNING';
}
