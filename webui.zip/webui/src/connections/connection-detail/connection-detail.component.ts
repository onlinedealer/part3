import { Component, Input, OnInit } from '@angular/core';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

@Component({
  selector: 'discovery-connection-detail',
  templateUrl: './connection-detail.component.html',
  styleUrls: ['./connection-detail.component.css']
})
export class ConnectionDetailComponent implements OnInit {
  data: any;
  basicOptions: any;

  constructor(public httpUtil: HttpUtilService) {}

  ngOnInit() {
    this.data = {
      labels: ['ABC', 'XYZ', 'PQR'],
      datasets: [
        {
          data: [300, 50, 100],
          backgroundColor: [
            '#39006B',
            '#8017E1',
            '#E5007E',
            '#FAB512',
            '#FD7E08',
            '#C8CCEE',
            '#D058D0',
            '#565358',
            '#CCA2F3',
            '#FECB9C',
            '#3C85FF',
            '#4BB269'
          ],
          hoverBackgroundColor: [
            '#39006Bcc',
            '#8017E1cc',
            '#E5007Ecc',
            '#FAB512cc',
            '#FD7E08cc',
            '#C8CCEEcc',
            '#D058D0cc',
            '#565358cc',
            '#CCA2F3cc',
            '#FECB9Ccc',
            '#3C85FFcc',
            '#4BB269cc'
          ]
        }
      ]
    };

    this.basicOptions = {
      legend: {
        align: 'top',
        position: 'right'
      }
    };
  }
}
