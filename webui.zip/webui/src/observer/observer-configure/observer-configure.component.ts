import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoService } from '@ngneat/transloco';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import {
  SelectSourceComponent,
  SharedConstants,
  ValidationMessage,
  ValidationMessageTypeModel
} from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { ObserverConstants } from 'observer/observer-constants';
import { ObserverService } from 'observer/observer.service';
import { ObserverConfigureModel } from './observer-configure.model';
import { ObserverDetailsComponent } from './observer-details/observer-details.component';
import { ObserverRulesComponent } from './observer-rules/observer-rules.component';
import { ObserverRulesModel } from './observer-rules/observerRules.model';

@Component({
  selector: 'discovery-observer-configure',
  templateUrl: './observer-configure.component.html',
  styleUrls: ['./observer-configure.component.css']
})
export class ObserverConfigureComponent implements OnInit {
  @ViewChild('selectSource', { static: false })
  selectSourceComponent: SelectSourceComponent;
  @ViewChild('observerRules', { static: false })
  observerRulesComponent: ObserverRulesComponent;
  @ViewChild('observerDetails', { static: false })
  observerDetailsComponent: ObserverDetailsComponent;
  catalogConnectionFlag: boolean = false;

  activeIndex: number;
  observeConfigureModel: ObserverConfigureModel;
  failureMessages: any[] = [];
  validationFailures: Set<string>;
  saveInProgress: boolean;
  isActionDisabled: boolean;
  ruleRequiredFlag: boolean = false;
  connectionIdKeyFlag: boolean = true;

  ValidationMessageType: typeof ValidationMessageTypeModel = ValidationMessageTypeModel;
  editMode: boolean = false;
  copyMode: boolean = false;
  observerId: string;
  progressDetails = [
    { progressLabel: 'discoveryObserver.observerConfigure.observerSelectSource' },
    { progressLabel: 'discoveryObserver.observerConfigure.configureObserver' },
    { progressLabel: 'discoveryObserver.observerConfigure.finalize' }
  ];

  get emailNotificationFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.EMAIL_NOTIFICATION);
  }

  constructor(
    private router: Router,
    private observerService: ObserverService,
    private translocoService: TranslocoService,
    private toastrService: ToastrService,
    private activatedRoute: ActivatedRoute,
    private launchDarklyService: LaunchDarklyService
  ) {
    this.activeIndex = 0;
    this.observeConfigureModel = new ObserverConfigureModel();
  }

  ngOnInit(): void {
    this.catalogConnectionFlag = this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.CATALOG);
    this.setActiveIndex();
    this.observerId = this.activatedRoute.snapshot.paramMap.get('observerId');
    if (this.observerId) {
      this.loadObserverById(this.observerId);
    }
  }

  cancelCreate(): void {
    this.router.navigateByUrl('/data-observability/observers');
  }

  saveObserver(): void {
    if (this.validate()) {
      this.saveInProgress = true;
      if (!this.emailNotificationFlag) {
        delete this.observeConfigureModel.notificationConfig;
      }

      this.observerService.saveObserver(this.observeConfigureModel, !this.editMode, this.observerId).subscribe(
        () => {
          this.saveInProgress = false;
          this.router.navigateByUrl('/data-observability/observers');
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.saveInProgress = false;
          if (httpErrorResponse.status === 409) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryObserver.observerConfigure.nameAlreadyExists', {
                  observerName: this.observeConfigureModel.name
                })
              )
            ];
          } else if (httpErrorResponse.status === 423) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryObserver.observerConfigure.observerAlreadyRunning')
              )
            ];
          } else if (httpErrorResponse.status === 404) {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryObserver.observerConfigure.observerNotFound')
              )
            ];
          } else {
            this.failureMessages = [
              new ValidationMessage(
                this.translocoService.translate('discoveryObserver.observerConfigure.observerSaveFailed', {
                  serverMessage:
                    httpErrorResponse && httpErrorResponse.error && JSON.parse(httpErrorResponse.error).message
                      ? JSON.parse(httpErrorResponse.error).message
                      : ''
                })
              )
            ];
          }
        }
      );
    }
  }

  observationRuleListChanges(selectedObservationRulesListChange: ObserverRulesModel[]) {
    this.observeConfigureModel.metrics = [];
    for (const observationRule of selectedObservationRulesListChange) {
      this.observeConfigureModel.metrics.push(observationRule.metricName);
    }
    this.ruleRequiredFlag = this.observeConfigureModel.metrics.length ? true : false;
  }

  moveNext() {
    if (this.validate()) {
      ++this.activeIndex;
    }
  }

  movePrevious() {
    --this.activeIndex;
  }

  validate(): boolean {
    if (this.activeIndex === 0) {
      this.validationFailures = this.selectSourceComponent.validate();
    } else if (this.activeIndex === 1) {
      this.validationFailures = this.observerRulesComponent.validate();
    } else if (this.activeIndex === 2) {
      this.validationFailures = this.observerDetailsComponent.validate();
    }

    return !(this.validationFailures && this.validationFailures.size > 0);
  }

  loadObserverById(observerId: string) {
    this.observerService.getObserver(observerId).subscribe(
      (response) => {
        this.observeConfigureModel.loadFromSettings(response);
        this.selectSourceComponent?.loadProfileSettings(this.observeConfigureModel);
        this.observerDetailsComponent?.loadObserverSettings(this.observeConfigureModel, this.editMode);
        this.observerRulesComponent?.loadObserverSettings(this.observeConfigureModel);
      },
      (httpErrorResponse: HttpErrorResponse) => {
        if (httpErrorResponse.status === 404) {
          this.toastrService.error(
            this.translocoService.translate('discoveryObserver.observerConfigure.observerNotFound')
          );
        }
      }
    );
  }

  //Output listening changes from select source for action buttons
  disableActions(disableFlag: boolean): void {
    this.isActionDisabled = disableFlag;
  }

  private setActiveIndex() {
    if (
      this.activatedRoute.snapshot.queryParamMap.get('index') === ObserverConstants.OBSERVER_CONFIGURE_STEPS.FINALIZE
    ) {
      this.activeIndex = 2;
      this.editMode = true;
    } else if (
      this.activatedRoute.snapshot.queryParamMap.get('index') ===
      ObserverConstants.OBSERVER_CONFIGURE_STEPS.OBSERVER_RULES
    ) {
      this.activeIndex = 1;
      this.editMode = true;
    } else if (
      this.activatedRoute.snapshot.queryParamMap.get('index') === ObserverConstants.OBSERVER_CONFIGURE_STEPS.SOURCE
    ) {
      this.activeIndex = 0;
      this.editMode = true;
    } else {
      if (this.router.url.indexOf('/edit') > -1) {
        this.editMode = true;
      } else if (this.router.url.indexOf('/copy') > -1) {
        this.copyMode = true;
      }
    }
  }
}
