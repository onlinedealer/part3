import { TreePath } from 'profiling/profile-results/tree-path.model';
import { TreeTableModel } from 'profiling/profile-results/tree-table.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { CharactorCategoryChartComponent } from './charactor-category-chart.component';

describe('CharactorCategoryChartComponent', () => {
  let component: CharactorCategoryChartComponent;

  beforeEach(() => {
    component = new CharactorCategoryChartComponent();
    component.barData = {
      labels: [],
      datasets: [
        {
          label: '',
          backgroundColor: ProfilingConstants.FREQUENCYCHARTCOLORS[0],
          data: [],
          barPercentage: 0.5,
          barThickness: 20,
          maxBarThickness: 20,
          minBarLength: 2
        }
      ]
    };
    component.horizontalOptions = {
      indexAxis: 'y',
      legend: {
        display: false
      },
      scales: {
        x: {
          ticks: {
            color: '#495057'
          },
          grid: {
            color: '#ebedef'
          }
        },
        y: {
          ticks: {
            color: '#495057'
          },
          grid: {
            color: '#ebedef'
          }
        }
      }
    };
    component.treePath = new TreePath();
    component.treePath.treeData = new TreeTableModel();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with Table View Completeness', () => {
    component.statistics = {
      type: 'CharacterSpacingStatistics',
      group: 'CHARACTER_ANALYSIS',
      frequency: { 'Multiple Spaces': 1, 'Single Space': 1 }
    } as any;
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.barData.labels[0]).toEqual(['Multiple Spaces']);
    expect(component.barData.datasets[0].data[0]).toBe(1);
  });
});
