import React from 'react';
import ReactDOM from 'react-dom';
import Reg from './Reg.js';
import view from './view.js';
import About from './About.js';
import Contact from './Contact.js';
import {  BrowserRouter as Router,  Route,  Link } from 'react-router-dom'

const BasicExample = () => (
  <Router>
    <div>
	    <nav className="navbar navbar-default navbar-fixed-top">
		  <div className="container">
		    <div className="navbar-header">

		    </div>
		    <div className="collapse navbar-collapse" id="myNavbar">
		      <ul className="nav navbar-nav">
		        <li><Link to="/Reg">Emp Registration</Link></li>
		        <li><Link to="/view">view Employees</Link></li>
		        <li><Link to="/About">About</Link></li>
		        <li><Link to="/Contact">Contact</Link></li>
		      </ul>
		    </div>
		  </div>
		</nav>
      	<hr/>
      <Route path="/Reg" component={Reg} />
      <Route path="/view" component={view} />
      <Route path="/About" component={About} />
      <Route path="/Contact" component={Contact} />
    </div>
  </Router>
)

ReactDOM.render(<BasicExample />, document.getElementById('app'));