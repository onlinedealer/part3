import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';

import { MetabasesApiService } from './metabases-api.service';

describe('MetabasesApiService', () => {
  let service: MetabasesApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(MetabasesApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should call API to delete metabase with credentials', () => {
    service.serviceURL = 'projects/1/metabases';

    const expectedRequestMethod = 'DELETE';
    const expectedEndpointUrl = service.serviceURL + '/test?removeConfigOnly=true';
    const ids = ['1', '2', '3'];
    let actualResponse = '';

    service.deleteMetabase('test', { userId: 'sys', password: '1234', removeConfigOnly: true }).subscribe((response) => {
      actualResponse = response;
    });

    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should call API to delete metabase without credentials', () => {
    service.serviceURL = 'projects/1/metabases';

    const expectedRequestMethod = 'DELETE';
    const expectedEndpointUrl = service.serviceURL + '/test?removeConfigOnly=false';
    const ids = ['1', '2', '3'];
    let actualResponse = '';

    service.deleteMetabase('test').subscribe((response) => {
      actualResponse = response;
    });

    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should call API to upgrade metabase', () => {
    service.serviceURL = 'projects/1/metabases';

    const expectedRequestMethod = 'POST';
    const expectedEndpointUrl = service.serviceURL + '/test/upgrade';
    let actualResponse;

    service.upgradeMetabase('test', { adminUserId: 'sys', adminUserPassword: '1234' }).subscribe((response) => {
      actualResponse = response;
    });

    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should call API to fetch the path from SQL instance', () => {
    let actualResponse;
    service.getPhysicalSQLServerPaths(1, { adminUserId: 'sys', adminUserPassword: '1234' }).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne('/api/v1/metadata/dataDirectory?connection_id=1');
    expect(req.request.method).toBe('POST');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should call API to get latest upgrade metabase version', () => {
    service.serviceURL = 'projects/1/metabases';

    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = service.serviceURL + '/test/availableVersion';
    let actualResponse;

    service.getMetabaseVersionForUpgrade('test').subscribe((response) => {
      actualResponse = response;
    });

    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });
});
