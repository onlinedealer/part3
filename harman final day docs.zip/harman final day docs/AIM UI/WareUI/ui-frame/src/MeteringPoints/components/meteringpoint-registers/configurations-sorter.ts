import { BehaviorSubject, Observable } from "rxjs";
import { map } from "rxjs/operators";
import { isNil, isNumber } from "lodash";
import { ConfigurationVO } from "../../models/view-objects/configuration-vo.model";

export class ConfigurationsSorter {
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" }> = new BehaviorSubject({
        active: "validUntil",
        direction: "desc"
    } as any);

    configurations: ConfigurationVO[] = [];

    public setConfigurations(configurations: ConfigurationVO[]) {
        this.configurations = configurations;
        this.sortingSubject.next(this.sortingSubject.value);
    }

    public getSortedConfigurations(): Observable<ConfigurationVO[]> {
        return this.sortingSubject.asObservable().pipe(map(() => [...this.configurations].sort(this.configurationComparator)));
    }

    public onSortEvent(event: { active: string; direction: "asc" | "desc" }) {
        this.sortingSubject.next(event);
    }

    public getSortActive(): string {
        return this.sortingSubject.value.active;
    }

    public getSortDirection(): string {
        return this.sortingSubject.value.direction;
    }

    configurationComparator = (c1: ConfigurationVO, c2: ConfigurationVO): number => {
        const directionMultiplier = this.sortingSubject.value.direction === "asc" ? 1 : -1;

        switch (this.sortingSubject.value.active) {
            case "configurationId":
                return c1.configurationId > c2.configurationId ? directionMultiplier : -1 * directionMultiplier;
            case "description":
                return this.sortByDescription(c1, c2, directionMultiplier);
            case "validFrom":
                return c1.validFrom > c2.validFrom ? directionMultiplier : -1 * directionMultiplier;
            case "validUntil":
                return this.sortByValidUntilBeforeValidFrom(c1, c2, directionMultiplier);
            default:
                return 0;
        }
    };

    sortByDescription(c1: ConfigurationVO, c2: ConfigurationVO, directionMultiplier: number) {
        if (isNil(c1.description) && isNil(c2.description)) {
            return this.sortByValidUntilBeforeValidFrom(c1, c2, directionMultiplier);
        }

        if (isNil(c1.description)) {
            return directionMultiplier;
        }

        if (isNil(c2.description)) {
            return -1 * directionMultiplier;
        }

        return c1.description > c2.description ? directionMultiplier : -1 * directionMultiplier;
    }

    sortByValidUntilBeforeValidFrom(m1: ConfigurationVO, m2: ConfigurationVO, directionMultiplier: number) {
        if (isNumber(m1.validUntil) && isNumber(m2.validUntil)) {
            return m1.validUntil > m2.validUntil ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(m1.validUntil) && isNil(m2.validUntil)) {
            return m1.validFrom > m2.validFrom ? directionMultiplier : -1 * directionMultiplier;
        }

        if (isNil(m1.validUntil)) {
            return directionMultiplier;
        }

        if (isNil(m2.validUntil)) {
            return -1 * directionMultiplier;
        }

        return 0;
    }
}
