import { ComponentFixture, TestBed } from '@angular/core/testing';
import { DynamicDialogConfig, DynamicDialogRef } from 'primeng/dynamicdialog';
import { Mocks, Spies } from 'discovery-test';
import { ExportDialogComponent } from './export-dialog.component';
import { TranslocoModule, TranslocoService } from '@ngneat/transloco';
import { AlertService } from 'alerts/alert.service';
import { EventBusService } from 'core/eventBusService';
import { SharedModule } from 'discovery-shared';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { of } from 'rxjs';
import { ReportStatusModel } from 'alerts/report-status.model';

const config = {
  data: { alertId: '6346a7c658a3e73fa616350c' }
} as DynamicDialogConfig;

describe('ExportDialogComponent', () => {
  let component: ExportDialogComponent;
  let fixture: ComponentFixture<ExportDialogComponent>;
  let translocoService;
  let mockReportRequest: ReportStatusModel;

  let alertMockService = jasmine.createSpyObj('AlertService', ['reportGenerationRequest']);
  alertMockService.reportGenerationRequest.and.returnValue(of([mockReportRequest]));
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ExportDialogComponent],
      imports: [TranslocoModule, HttpClientTestingModule, SharedModule],
      providers: [
        DynamicDialogRef,
        { provide: DynamicDialogConfig, useValue: config },
        { TranslocoService, useValue: Spies.TranslateService },
        { provide: AlertService, useValue: alertMockService },
        { provide: EventBusService, useValue: Spies.eventBusService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    mockReportRequest = Mocks.MockReportStatusResponse[0];
    fixture = TestBed.createComponent(ExportDialogComponent);
    component = fixture.componentInstance;
    translocoService = TestBed.inject(TranslocoService);
    spyOn(translocoService, 'translate');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call closeExport', () => {
    component.cancelExport();
  });

  it('should call submitExport', () => {
    component.dateRange = 'all';
    component.submitExport();
    expect(Spies.eventBusService['emit']).toHaveBeenCalled();
  });
});
