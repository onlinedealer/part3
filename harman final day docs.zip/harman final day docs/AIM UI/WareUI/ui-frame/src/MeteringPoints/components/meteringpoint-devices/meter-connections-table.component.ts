import { Component, Input, Output, EventEmitter, SimpleChanges, OnChanges, TemplateRef, ViewChild } from "@angular/core";
import { MeterConnectionVO } from "../../models/view-objects/meterconnection-vo.model";
import { TranslationsService } from "../../../app/services/translations-service";
import { MeterConnectionsSorter } from "./meter-connections-sorter";
import { Store } from "@ngrx/store";
import { isNumber } from "lodash";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { MeterTypeNames } from "./meter-type-names";
import { map } from "rxjs/operators";
import { DateFormats, DateFormatService } from "../../../Shared/services/date-format.service";

@Component({
    selector: "landisgyr-meter-connections-table",
    templateUrl: "./meter-connections-table.component.html",
    styleUrls: ["./meter-connections-table.component.scss"]
})
export class MeterConnectionsTableComponent implements OnChanges {
    @ViewChild("statusIndicator") statusIndicator!: TemplateRef<any>;

    @Input()
    meterConnections!: MeterConnectionVO[];

    @Input()
    selectedMeterConnectionId!: number;

    @Output()
    select: EventEmitter<MeterConnectionVO> = new EventEmitter();

    @Input()
    mpDeviceDetailsColConfig: {
        columnId: string;
        columnName: string;
        showColumn: boolean;
        draggedColumn: boolean;
        columnWidth: number;
        columnType?: string;
    }[] = [];

    meterConnectionsSorter = new MeterConnectionsSorter();
    sortedMeterConnections$ = this.meterConnectionsSorter.getSortedMeterConnections().pipe(
        map((meterConnectionEntity) => {
            return meterConnectionEntity.map((data) => {
                return {
                    ...data,
                    configuration:
                        data.configuration && data.configuration.name ? data.configuration.name + " " + data.configuration.description : "",
                    validUntil: this.dateFormatService.toLocaleString(data.validUntil, DateFormats.DURATION),
                    validFrom: this.dateFormatService.toLocaleString(data.validFrom, DateFormats.DATETIME)
                };
            });
        })
    );

    now = new Date().getTime();
    public meterTypeNames = new MeterTypeNames();

    constructor(public translations: TranslationsService, private dateFormatService: DateFormatService) {}

    ngOnChanges(changes: SimpleChanges) {
        this.meterConnectionsSorter.setMeterConnections(this.meterConnections);
    }

    onSelectMeterConnection(meterConnection: MeterConnectionVO) {
        this.select.emit(meterConnection);
    }

    isActiveMeterConnection(meterConnection: MeterConnectionVO) {
        return (
            !this.isDeletedMeterConnection(meterConnection) &&
            (meterConnection.validUntil === undefined || this.now < meterConnection.validUntil)
        );
    }

    isDisconnectedMeterConnection(meterConnection: MeterConnectionVO) {
        return !this.isDeletedMeterConnection(meterConnection) && !this.isActiveMeterConnection(meterConnection);
    }

    isDeletedMeterConnection(meterConnection: MeterConnectionVO) {
        return isNumber(meterConnection.deleted);
    }
}
