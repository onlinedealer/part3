import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '../environments/environment';
import { ProtectedAppInitializerService } from '@precisely/prism-ng/di-suite';
import { catchError, mergeMap } from 'rxjs/operators';
import { of } from 'rxjs';
import { OIDC } from './oidc.model';

@Injectable({
  providedIn: 'root'
})
export class AppInitializerService {
  isAppInitialized: boolean;

  constructor(private readonly httpClient: HttpClient, private readonly protectedAppInitializerService: ProtectedAppInitializerService) {}

  async init() {
    console.debug('Starting app initialization');
    await this.httpClient
      .get(`${environment.connectApiBaseURL}/config`)
      .pipe(
        mergeMap((config) => {
          console.debug('Starting portal initialization');
          return this.protectedAppInitializerService
            .init('portal', OIDC.CLIENT_ID)
            .toPromise()
            .then(() => {
              console.debug('Finished di suite app initialization');
              this.isAppInitialized = true;
              return;
            });
        }),
        catchError(() => {
          console.log('Error initialising application');
          this.isAppInitialized = false;
          return of();
        })
      )
      .toPromise();
  }
}
