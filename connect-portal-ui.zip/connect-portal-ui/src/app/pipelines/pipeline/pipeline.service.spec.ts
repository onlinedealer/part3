import { HttpClientTestingModule } from '@angular/common/http/testing';
import { fakeAsync, TestBed, tick } from '@angular/core/testing';
import { of } from 'rxjs';
import { PipelineService } from './pipeline.service';
import { Pipeline } from './shared/pipeline';
import { PipelinesApiService } from './shared/pipelines-api.service';
import { Project } from './shared/project';
import { ProjectsApiService } from './shared/projects-api.service';
import { PipelineEntityService } from './shared/pipeline-entity.service';
import { FeatureFlagService } from '../../shared/services/feature-flag.service';

describe('PipelineService', () => {
  let service: PipelineService;
  let projectsApiService: ProjectsApiService;
  let pipelinesApiService: PipelinesApiService;
  let pipelineEntityService: PipelineEntityService;
  let featureFlagService: FeatureFlagService;

  const mockFeatureFlagService = {
    ldClient: {
      close: () => of(),
      identify: () => of(),
      variation: () => of()
    },
    isFeatureEnabled: (f) => f === 'FLAG1',
    isFeatureDisabled: (f) => f === 'FLAG2'
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      providers: [{ provide: FeatureFlagService, useValue: mockFeatureFlagService }]
    }).compileComponents();
  });

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(PipelineService);
    projectsApiService = TestBed.inject(ProjectsApiService);
    pipelinesApiService = TestBed.inject(PipelinesApiService);
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    featureFlagService = TestBed.inject(FeatureFlagService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should set/get the project id', () => {
    service.setProjectId('1');
    expect(service.getProjectId()).toBe('1');
  });

  describe('savePipeline()', () => {
    const project: Project = {
      id: '',
      name: '',
      projectType: ''
    };
    const pipeline: Pipeline = {
      id: '',
      name: '',
      description: '',
      dataFlowType: '',
      properties: [],
      filters: [],
      tableMapping: []
    };

    it('should create new project if one does not exist', fakeAsync(() => {
      spyOn(projectsApiService, 'getAll').and.returnValue(of([]));
      spyOn(projectsApiService, 'create').and.returnValue(of(project));
      spyOn(mockFeatureFlagService, 'isFeatureDisabled').and.returnValue(true);

      service.savePipeline();
      tick();

      expect(projectsApiService.create).toHaveBeenCalled();
    }));

    it('should not create new project if one already exists', fakeAsync(() => {
      spyOn(projectsApiService, 'getAll').and.returnValue(of([project]));
      spyOn(projectsApiService, 'create').and.stub();
      spyOn(mockFeatureFlagService, 'isFeatureDisabled').and.returnValue(true);

      service.savePipeline();
      tick();

      expect(projectsApiService.create).not.toHaveBeenCalled();
    }));

    it('should create new pipeline if not previously saved', fakeAsync(() => {
      spyOn(projectsApiService, 'getAll').and.returnValue(of([project]));
      spyOn(pipelinesApiService, 'create').and.returnValue(of(pipeline));

      service.savePipeline();
      tick();

      expect(pipelinesApiService.create).toHaveBeenCalledTimes(1);
    }));

    it('should not attempt to re-create pipeline if already saved', fakeAsync(() => {
      const copyPipeline: Pipeline = {
        id: '',
        name: '',
        description: '',
        dataFlowType: 'COPY',
        properties: [],
        filters: [],
        tableMapping: [],
        source: {
          dataConnection: { connectionType: 'DB2I' },
          selectedTables: [
            {
              key: 'HR',
              value: {
                tableExtractType: 'INCLUDE',
                tableAndKeys: [{ tableName: 'JOBS', keys: [] }]
              }
            }
          ]
        }
      };

      spyOn(pipelineEntityService, 'getPipelineChanges').and.returnValue({
        hasChanges: true,
        hasKeyMismatch: true,
        hasValueMismatch: true,
        objDiff: {
          dataFlowType: {
            right: 'COPY',
            left: 'SYNCHRONIZE'
          }
        }
      });
      spyOn(pipelineEntityService, 'getLatestPipeline').and.returnValue(of(copyPipeline));
      spyOn(projectsApiService, 'getAll').and.returnValue(of([project]));
      spyOn(pipelinesApiService, 'create').and.returnValue(of(pipeline));

      service.savePipeline();
      tick();

      service.savePipeline();
      tick();

      expect(pipelinesApiService.create).toHaveBeenCalledTimes(1);
    }));

    it('should commit pipeline if not previously saved', () => {
      const result = service.commitPipeline();
      expect(result).toBeDefined();
    });

    it('should commit pipeline if not previously saved with incrementalcommit feature enabled', () => {
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
      const result = service.commitPipeline();
      expect(result).toBeDefined();
    });

    it('should deploy pipeline', () => {
      const result = service.deployPipeline();
      expect(result).toBeDefined();
    });

    it('should load pipeline', () => {
      const projectsApiServiceData: Project[] = [
        {
          id: '1',
          name: '',
          projectType: 'project Type'
        }
      ];
      const pipelinesApiServiceData: Pipeline = {
        id: '1',
        name: '',
        description: '',
        dataFlowType: '',
        properties: [],
        filters: []
      };
      spyOn(projectsApiService, 'getAll').and.returnValue(of(projectsApiServiceData));
      spyOn(pipelinesApiService, 'get').and.returnValue(of(pipelinesApiServiceData));
      spyOn(mockFeatureFlagService, 'isFeatureDisabled').and.returnValue(true);
      service.loadPipeline('1').subscribe((data) => {
        expect(data).toEqual({
          id: '1',
          name: '',
          description: '',
          dataFlowType: '',
          properties: [],
          filters: [],
          projectId: '1'
        });
      });
    });

    it('should load pipeline when project id is not set', () => {
      const projectsApiServiceData: Project[] = [
        {
          id: '1',
          name: '',
          projectType: 'project Type'
        }
      ];
      const pipelinesApiServiceData: Pipeline = {
        id: '1',
        name: '',
        projectId: '1',
        description: '',
        dataFlowType: '',
        properties: [],
        filters: []
      };
      spyOn(projectsApiService, 'getAll').and.returnValue(of(projectsApiServiceData));
      spyOn(pipelinesApiService, 'get').and.returnValue(of(pipelinesApiServiceData));
      spyOn(mockFeatureFlagService, 'isFeatureDisabled').and.returnValue(false);
      service.loadPipeline('1').subscribe((data) => {
        expect(data).toEqual({
          id: '1',
          name: '',
          description: '',
          dataFlowType: '',
          properties: [],
          filters: [],
          projectId: '1'
        });
      });
    });

    it('should clear the selected tables when we switch from COPY to NON-COPY pipeline type for IBM i', fakeAsync(() => {
      const copyPipeline: Pipeline = {
        id: '',
        name: '',
        description: '',
        dataFlowType: 'COPY',
        properties: [],
        filters: [],
        tableMapping: [],
        source: {
          dataConnection: { connectionType: 'DB2I' },
          selectedTables: [
            {
              key: 'HR',
              value: {
                tableExtractType: 'INCLUDE',
                tableAndKeys: [{ tableName: 'JOBS', keys: [] }]
              }
            }
          ]
        }
      };
      spyOn(projectsApiService, 'getAll').and.returnValue(of([project]));
      spyOn(pipelinesApiService, 'create').and.returnValue(of(copyPipeline));
      spyOn(featureFlagService, 'isFeatureEnabled').and.returnValue(true);
      service.savePipeline();
      tick();

      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(copyPipeline);
      spyOn(pipelineEntityService, 'getPipelineChanges').and.returnValue({
        hasChanges: true,
        hasKeyMismatch: true,
        hasValueMismatch: true,
        objDiff: {
          dataFlowType: {
            right: 'COPY',
            left: 'SYNCHRONIZE'
          }
        }
      });

      spyOn(pipelineEntityService, 'getLatestPipeline').and.returnValue(of(copyPipeline));

      copyPipeline.source.selectedTables = [];
      spyOn(pipelinesApiService, 'update').and.returnValue(of({}));
      service.savePipeline();
      tick();
      expect(pipelinesApiService.update).toHaveBeenCalledWith(copyPipeline, true);
    }));
  });
});
