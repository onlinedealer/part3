(function() {
    'use strict';
    angular.module('arm').controller('contactNoteCtrl', ['$scope', '$state', '$window', 'contactService', 'contactNoteService', 'utility', '$ionicModal', '$ionicSideMenuDelegate', 'GENERAL_CONFIG', 'MASTER_TABLE', 'ALERT_MESSAGE', '$cordovaDialogs','productService', 'noteService', contactNoteCtrl]);

    function contactNoteCtrl($scope, $state, $window, contactService, contactNoteService, utility, $ionicModal, $ionicSideMenuDelegate, GENERAL_CONFIG, MASTER_TABLE, ALERT_MESSAGE, $cordovaDialogs, productService, noteService) {

        $scope.selContacts = {
            tempContact: "",
            activeContact: {}
        };

        $scope.contactDisplayArr = [];
        $scope.individualContactArr = [];
        $scope.companyContactArr = [];
        $scope.contactNotes = [];
        $scope.user = {};
        var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        loadContacts();

        function loadContacts() {
            utility.sqlGetAllContacts().then(function(result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var contactObjList = contactService.models().contactModel;
                    $scope.contactType = contactService.constants().contactType;
                    if (result.rows.item(i).ContactTypeID == $scope.contactType.Individual) {
                        contactObjList = utility.syncModelWithCollection(result.rows.item(i),contactObjList);
                        $scope.individualContactArr.push(contactObjList);
                    } else if (result.rows.item(i).ContactTypeID == $scope.contactType.Company) {
                        contactObjList = utility.syncModelWithCollection(result.rows.item(i),contactObjList);
                        $scope.companyContactArr.push(contactObjList);
                    }
                }

                for (var i = 0; i < $scope.individualContactArr.length; i++) {
                    if ($scope.individualContactArr[i].EmployerDeviceObjID == "" || $scope.individualContactArr[i].EmployerDeviceObjID == null) {
                        $scope.contactSelectionModel = utility.contactSelectionMod().uiObject;
                        $scope.contactSelectionModel.ContactName = $scope.individualContactArr[i].FirstName + " " + $scope.individualContactArr[i].LastName;
                        $scope.contactSelectionModel.AttendeeDeviceObjID = $scope.individualContactArr[i].DeviceObjID;
                        $scope.contactSelectionModel.ContactDeviceObjID = $scope.individualContactArr[i].DeviceObjID;
                        $scope.contactSelectionModel.ContactID = $scope.individualContactArr[i].ContactID;
                        $scope.contactSelectionModel.UserID = $scope.individualContactArr[i].ContactID;
                        $scope.contactSelectionModel.ContactTypeID = $scope.individualContactArr[i].ContactTypeID;
                        $scope.contactSelectionModel.ContactOwnerID = $scope.individualContactArr[i].OwnerID;
                        $scope.contactSelectionModel.ContactOwnerName = $scope.individualContactArr[i].OwnerName;
                        $scope.contactSelectionModel.DisplayName = $scope.contactSelectionModel.ContactName;
                        $scope.contactSelectionModel.CompanyName = $scope.individualContactArr[i].CompanyName;
                        $scope.contactSelectionModel.CompanyID = 0;
                        $scope.contactSelectionModel.CompanyDeviceObjID = '';
                        $scope.contactSelectionModel.UserName = $scope.contactSelectionModel.DisplayName;
                        $scope.contactSelectionModel.IsChecked = false;
                        $scope.contactSelectionModel.ContactTierName = $scope.individualContactArr[i].ContactTierName;
                        $scope.contactSelectionModel.ContactTierID = $scope.individualContactArr[i].ContactTierID;
                        $scope.contactSelectionModel.ContactSegmentName = $scope.individualContactArr[i].ContactSegmentName;
                        $scope.contactSelectionModel.ContactSegmentID = $scope.individualContactArr[i].ContactSegmentID;

                        $scope.contactDisplayArr.push($scope.contactSelectionModel);
                    } else {
                        utility.sqlGetAllIndividualContactsRelationships($scope.individualContactArr[i]).then(function(contactResult) {
                            $scope.contactSelectionModel = utility.contactSelectionMod().uiObject;
                            $scope.contactSelectionModel.ContactName = contactResult[0].FirstName + " " + contactResult[0].LastName;
                            $scope.contactSelectionModel.AttendeeDeviceObjID = contactResult[0].DeviceObjID;
                            $scope.contactSelectionModel.ContactDeviceObjID = contactResult[0].DeviceObjID;
                            $scope.contactSelectionModel.ContactID = contactResult[0].ContactID;
                            $scope.contactSelectionModel.UserID = contactResult[0].ContactID;
                            $scope.contactSelectionModel.ContactTypeID = contactResult[0].ContactTypeID;
                            $scope.contactSelectionModel.ContactOwnerID = contactResult[0].OwnerID;
                            $scope.contactSelectionModel.ContactOwnerName = contactResult[0].OwnerName;
                            $scope.contactSelectionModel.DisplayName = $scope.contactSelectionModel.ContactName;
                            $scope.contactSelectionModel.CompanyName = contactResult[1].rows.item(0).CompanyName;
                            $scope.contactSelectionModel.CompanyID = contactResult[1].rows.item(0).ContactID;
                            $scope.contactSelectionModel.CompanyDeviceObjID = contactResult[1].rows.item(0).DeviceObjID;
                            $scope.contactSelectionModel.DisplayName += '(' + $scope.contactSelectionModel.CompanyName + ')';
                            $scope.contactSelectionModel.UserName = $scope.contactSelectionModel.DisplayName;
                            $scope.contactSelectionModel.ContactTierName = contactResult[0].ContactTierName;
                            $scope.contactSelectionModel.ContactTierID = contactResult[0].ContactTierID;
                            $scope.contactSelectionModel.ContactSegmentName = contactResult[0].ContactSegmentName;
                            $scope.contactSelectionModel.ContactSegmentID = contactResult[0].ContactSegmentID;
                            $scope.contactSelectionModel.IsChecked = false;
                            $scope.contactDisplayArr.push($scope.contactSelectionModel);
                        }, function(err) {
                            alert(err);
                        });
                    }
                }

                for (var i = 0; i < $scope.companyContactArr.length; i++) {
                    utility.sqlGetAllRepresentativeDetails($scope.companyContactArr[i]).then(function(repResult) {
                        for (var k = 0; k < repResult[1].rows.length; k++) {
                            $scope.contactRepModel = utility.contactSelectionMod().uiObject;
                            $scope.contactRepModel.ContactName = repResult[0].CompanyName;
                            $scope.contactRepModel.ContactDeviceObjID = repResult[0].DeviceObjID;
                            $scope.contactRepModel.AttendeeDeviceObjID = repResult[0].DeviceObjID;
                            $scope.contactRepModel.ContactID = repResult[0].ContactID;
                            $scope.contactRepModel.UserID = $scope.contactRepModel.ContactID;
                            $scope.contactRepModel.ContactTypeID = repResult[0].ContactTypeID;
                            $scope.contactRepModel.ContactOwnerID = repResult[0].OwnerID;
                            $scope.contactRepModel.ContactOwnerName = repResult[0].OwnerName;
                            $scope.contactRepModel.CompanyName = repResult[0].CompanyName;
                            $scope.contactRepModel.CompanyID = repResult[0].ContactID;
                            $scope.contactRepModel.CompanyDeviceObjID = repResult[0].DeviceObjID;
                            $scope.contactRepModel.RepresentativeName = repResult[1].rows.item(k).FirstName + " " + repResult[1].rows.item(k).LastName;
                            $scope.contactRepModel.RepresentativeDeviceObjID = repResult[1].rows.item(k).DeviceObjID;
                            $scope.contactRepModel.RepresentativeID = repResult[1].rows.item(k).ContactID;
                            $scope.contactRepModel.DisplayName = $scope.contactRepModel.RepresentativeName + '(' + $scope.contactRepModel.CompanyName + ')';
                            $scope.contactRepModel.UserName = $scope.contactRepModel.DisplayName;
                            $scope.contactRepModel.ContactTierName = repResult[0].ContactTierName;
                            $scope.contactRepModel.ContactTierID = repResult[0].ContactTierID;
                            $scope.contactRepModel.ContactSegmentName = repResult[0].ContactSegmentName;
                            $scope.contactRepModel.ContactSegmentID = repResult[0].ContactSegmentID;
                            $scope.contactRepModel.IsChecked = false;
                            if (isEditModeFlag) {
                                utility.editSelUserList($scope.selCntPar, $scope.contactRepModel, selCntPar);
                                //$scope.contactRepModel.IsChecked = utility.editSelUserList($scope.selCntPar, $scope.contactRepModel);;
                            }
                            $scope.contactDisplayArr.push($scope.contactRepModel);
                            $scope.cntPars.push($scope.contactRepModel);
                        }

                    }, function(err) {
                        alert(err);
                    });
                }
            }, function(err) {
                alert(err);
            });
        }

        $scope.modelSelected = '';
        $ionicModal.fromTemplateUrl('app/views/common/userList.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function(modal) {
            $scope.modalUser = modal;
        });

        $scope.openUserList = function(val) {
            $scope.modelSelected = val;
            if ($scope.modelSelected == 'CN') {
                $scope.selContacts.activeContact = $scope.selContacts.tempContact;
            }
            $scope.modalUser.show();
        };
        $scope.closeUserList = function() {
            $scope.modalUser.hide();
        };
        //close add Note screen
         $scope.closeNote = function () {
             //$state.go('tab.contact');
             $window.history.back();
         }
        $scope.actionUserList = function() {

            if ($scope.modelSelected == 'CN') {
                $scope.selContacts.tempContact = $scope.selContacts.activeContact;
                for (var i = 0; i < $scope.contactDisplayArr.length; i++) {
                    if ($scope.contactDisplayArr[i].ContactDeviceObjID == $scope.selContacts.activeContact) {
                        //alert($scope.contactDisplayArr[i].ContactName);
                        $scope.user.ContactDisplayName = $scope.contactDisplayArr[i].DisplayName;
                        $scope.user.CompanyName = $scope.contactDisplayArr[i].CompanyName;
                        $scope.user.ContactID = $scope.contactDisplayArr[i].ContactID;
                        $scope.user.DeviceObjID = $scope.contactDisplayArr[i].ContactDeviceObjID;
                        /*$scope.dealModel.ContactName = $scope.contactDisplayArr[i].ContactName;
                        $scope.dealModel.ContactDisplayName = $scope.contactDisplayArr[i].DisplayName;
                        $scope.dealModel.CompanyName = $scope.contactDisplayArr[i].CompanyName;
                        //$scope.dealModel.ContactID = $scope.contactDisplayArr[i].ContactID;
                        $scope.dealModel.ContactID = 5;
                        $scope.dealModel.ContactTypeID = $scope.contactDisplayArr[i].ContactTypeID;
                        $scope.dealModel.ContactDeviceObjID = $scope.contactDisplayArr[i].ContactDeviceObjID;
                        $scope.dealModel.RepresentativeDeviceObjID = $scope.contactDisplayArr[i].RepresentativeDeviceObjID;
                        loadSubject();*/
                    }
                }
            }
            $scope.modalUser.hide();
        };
        $scope.addNote = function() {
            $scope.activeNotes = [];
            if ($scope.user.notes != '') {
                productService.getAttachments(0).then(function(){
                var noteObjModel = noteService.noteMod().noteModel;
                noteObjModel.ContactID = $scope.user.ContactID;
                noteObjModel.ContactObjID = $scope.user.DeviceObjID;
                noteObjModel.CreatedOn = utility.getDateStringInUTC(new Date());
                noteObjModel.CreatorID = lgnUser.UserID;
                if(lgnUser.FullName.length >0)
                noteObjModel.CreatorName = lgnUser.FullName;
                else noteObjModel.CreatorName = lgnUser.UserName;
                noteObjModel.EntityID = $scope.user.ContactID;
                noteObjModel.ParentDeviceObjID = $scope.user.DeviceObjID;
                noteObjModel.ModuleID = GENERAL_CONFIG.MODULES.Contact;
                noteObjModel.Description = $scope.user.notes;

                $scope.activeNotes.push(noteObjModel);

                noteService.addNoteToSql($scope.activeNotes).then(function(res) {
                    noteService.addNoteToServer($scope.activeNotes).then(function(res) {
                        noteService.updateNotesQuery(res[0]).then(function(res) {
                            $cordovaDialogs.alert(ALERT_MESSAGE.NOTE_ADD, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                            .then(function() {
                                $state.go('tab.contact');
                            });
                        }, function(err) {
                        });
                    }, function(err) {
                    });
                }, function(err) {
                });
            });
           }
        }
    };
})();
