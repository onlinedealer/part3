import { Injectable } from '@angular/core';
import { Resolve, Router } from '@angular/router';
import { Observable } from 'rxjs/Observable';
import { HttpResponse } from '@angular/common/http';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import { ClubConstantsService } from '../utility/club-constants.service';
import { AjaxUtilityService } from '../utility/ajax-utility.service';
import { RouteConfigurations } from '../utility/club-constants.service';

@Injectable()
export class RegistrationNavResolverService implements Resolve<any>{

  // Created the return objject with all the necessary information that would be passed.
  registrationDataObj = {
                          "loggedInStatus": "Anonymous", 
                          "ecCardInfo":{
                                    "status": "noEc",
                                    "ecCardNumb":""
                          },
                          "clubMembershipStatus": "N"
                        };

  constructor(private _ajaxUtility: AjaxUtilityService,
              private _router:  Router, private _constants : ClubConstantsService) { }
  
  resolve(){
    // Check if user is already logged in user or not.
    // If user is already logged in call the get digital profile service
    if(document.cookie.indexOf('SCC_COOKIE') != -1){  
      this.registrationDataObj.loggedInStatus = "loggedIn";
      return this._ajaxUtility.sendRequest('getDigitalProfile')
      .map((data) => {
       return this.manipulateRegResponse(data);
      })
      .catch((err) => {
        // if service does not respond use the catch block
        return Observable.of({status:"Fail"});
      });
      
    }
    else{
      return this.registrationDataObj;
    }
  }

  /* This function receives the response from getDigitalProfile and then 
     based on the response performs navigation or manipulates the response object
     that the registration component can utilize */
  
  manipulateRegResponse(data){
    var digitalProfResponseObj = data['getDigitalProfileResponse']['additionalDetails'];
    if (data.hasOwnProperty('getDigitalProfileResponse') &&
    data['getDigitalProfileResponse'].hasOwnProperty('header') &&
    '0000' === data['getDigitalProfileResponse']['header']['statusCode']) {
      // If user is club enrolled, navigate user to dashboard
      if ('ENROLLED' == data['getDigitalProfileResponse']['additionalDetails']['carePassEnrollmentStatus']){
        this._router.navigate(['/' + RouteConfigurations.clubDashboard]);
      }
      // If not check if he is EC tied and then set the EC card in the return object
      else if(digitalProfResponseObj["ecTied"]) {
        this.registrationDataObj.ecCardInfo.status = "ecTied";
        this.registrationDataObj.ecCardInfo.ecCardNumb = digitalProfResponseObj["extracareCardNumber"];
        return this.registrationDataObj;
      }// Else pass the return object as it is
      else{
        return this.registrationDataObj;
      }
    }
    // If get digital profile call failed pass the response object just as logged in.
    else{
      return this.registrationDataObj;
    }
  }




/*   resolve(){
    console.log('debug me');
    var digitalProfileResponse;
    
      regNavResolverReturnObj.loggedInStatus = "Logged";
      // call getDigital profile to see if user has club membership and what
      // is the ec card info. 
      this._ajaxUtility.sendRequest('getDigitalProfile')
      .subscribe(
        (data: HttpResponse<any>) => {
          
          console.log(data);
          if(data["getDigitalProfileResponse"]["header"]["statusCode"] == "0000") {
            digitalProfileResponse = data["getDigitalProfileResponse"]["additionalDetails"];
          }
          else{            
            regNavResolverReturnObj;
          }
          
          else{
            return regNavResolverReturnObj;
          }         
        },
        (err) => {          
          regNavResolverReturnObj;          
        },
        () => {
          regNavResolverReturnObj;
        }
        );      
    }
    else{
      return regNavResolverReturnObj;
    }
  } */

}
