import { Injectable } from '@angular/core';
import { forkJoin, Observable, Subject, firstValueFrom } from 'rxjs';
import { map, tap } from 'rxjs/operators';
import { FeatureFlagService } from '../../shared/services/feature-flag.service';
import { PipelinesMonitoringApiService } from '../shared/pipelines-monitoring-api.service';
import { Pipeline, PipelineApiPayload, PIPELINE_ENTITY_TYPE, TableMapping } from './shared/pipeline';
import { PipelineCompareResult } from './shared/pipeline-compare';
import { PipelineEntityService } from './shared/pipeline-entity.service';
import { PipelinesApiService } from './shared/pipelines-api.service';
import { Project, ProjectType } from './shared/project';
import { ProjectCommitResponse } from './shared/project-commit-response';
import { ProjectsApiService } from './shared/projects-api.service';
import { ScheduledPipelinesApiService } from './shared/schedule-pipelines-api.service';

export type CreatePipelineApiResponse = { id: string };

@Injectable({
  providedIn: 'root'
})
export class PipelineService {
  mappingNextAction: Subject<Promise<any>> = new Subject<Promise<any>>();

  deployProjectFunction: Subject<void> = new Subject<void>();

  deployProjectApplyConfiguration: Subject<any> = new Subject<any>();

  /**
   * Tempoary flag used to determine if the incremental commit feature is enabled
   */
  isIncrementalCommitFeatureEnabled = false;
  tableMapping: TableMapping[];

  private projectId: string;

  constructor(
    private readonly projectsApiService: ProjectsApiService,
    private readonly pipelinesApiService: PipelinesApiService,
    private readonly schedulePipelinesApiService: ScheduledPipelinesApiService,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService,
    private readonly featureFlagService: FeatureFlagService
  ) {}

  async savePipeline(): Promise<CreatePipelineApiResponse> {
    await this.createProjectIfRequired();
    const promise = this.createOrUpdatePipeline();
    promise.then(() => {
      const pipeline = this.pipelineEntityService.getPipeline();
      this.pipelineEntityService.updatePipelineSnapshot(pipeline);
    });
    return promise;
  }

  async commitPipeline(): Promise<ProjectCommitResponse> {
    this.isIncrementalCommitFeatureEnabled = this.featureFlagService.isFeatureEnabled('CDCIncrementalCommitTemp20220822');
    if (this.isIncrementalCommitFeatureEnabled) {
      return firstValueFrom(this.projectsApiService.commit(this.projectId, false, this.pipelineEntityService.incrementalStage));
    } else {
      return firstValueFrom(this.projectsApiService.commit(this.projectId));
    }
  }

  async deployPipeline(): Promise<any> {
    return firstValueFrom(this.pipelinesMonitoringApiService.deploy(this.projectId, this.pipelineEntityService.deployInfo));
  }

  loadPipeline(pipelineId: string): Observable<Pipeline> {
    const projects$ = this.projectsApiService.getAll();

    const pipeline$ =
      this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.REPLICATION
        ? this.pipelinesApiService.get(pipelineId)
        : this.schedulePipelinesApiService.get(pipelineId);

    return forkJoin([projects$, pipeline$]).pipe(
      map(([projects, pipeline]: [Project[], Pipeline]) => {
        if (this.featureFlagService.isFeatureDisabled('CDCMultipleProjectsTemp20220421')) {
          this.projectId = projects[0].id;
        } else if (!this.projectId) {
          this.projectId = pipeline?.projectId;
        }
        return { ...pipeline, projectId: this.projectId };
      })
    );
  }

  start(projectId: string, dataFlowsNames: string[], resumeRequest: boolean): Observable<any> {
    return this.pipelinesMonitoringApiService.start(projectId, dataFlowsNames, resumeRequest);
  }

  stop(projectId: string, dataFlowsNames: string[]): Observable<any> {
    return this.pipelinesMonitoringApiService.stop(projectId, dataFlowsNames);
  }

  runScheduledPipeline(id: string) {
    return this.schedulePipelinesApiService.run(id);
  }

  setProjectId(projectId: string): void {
    this.projectId = projectId;
  }

  getProjectId(): string {
    return this.projectId;
  }

  readonly createProjectIfRequired = async () => {
    if (this.featureFlagService.isFeatureDisabled('CDCMultipleProjectsTemp20220421')) {
      const projects = await firstValueFrom(this.projectsApiService.getAll());
      // At the time of writing, the assumption is made that only one project should exist in the database.
      // Therefore this code simply checks if any exists and uses the first project returned as that project.
      if (projects.length === 0) {
        this.projectId = await this.createProject();
      } else {
        this.projectId = projects[0].id;
      }
    }
  };

  private readonly createProject = async (): Promise<string> => {
    const project = new Project();
    project.name = 'Default_Project';
    project.projectType = ProjectType.REPLICATION;
    const response = (await firstValueFrom(this.projectsApiService.create(project))) as { id: string };
    return response.id;
  };

  private readonly createOrUpdatePipeline = (): Promise<CreatePipelineApiResponse> => {
    if (!this.pipelineIsSaved()) {
      return this.createPipeline();
    } else {
      return this.updatePipeline();
    }
  };

  /**
   * Call the API to create new pipeline
   */
  private readonly createPipeline = (): Promise<any> => {
    const pipeline = this.pipelineEntityService.getPipeline();

    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.REPLICATION) {
      return firstValueFrom(this.pipelinesApiService.create(pipeline, { projectId: this.projectId }).pipe(tap(this.storePipelineId)));
    } else {
      return firstValueFrom(
        this.schedulePipelinesApiService.create(pipeline, { projectId: this.projectId }).pipe(tap(this.storePipelineId))
      );
    }
  };

  /**
   * Call the API to update existing pipeline
   */
  private readonly updatePipeline = (): Promise<any> => {
    let currentTableMappings;
    let pipeline = this.pipelineEntityService.getPipeline();
    const pipelineChanges = this.pipelineEntityService.getPipelineChanges();
    this.pipelineEntityService.getLatestPipeline().subscribe((pipeline) => (currentTableMappings = pipeline));

    const currentTableMappingCount = currentTableMappings.tableMapping?.length || 0;
    const newTableMappingCount = pipeline.tableMapping?.length || 0;

    if (pipelineChanges.hasChanges || (!pipelineChanges.hasChanges && currentTableMappingCount > newTableMappingCount)) {
      if (this.clearTablesOnPipelineTypeChanges(pipeline, pipelineChanges)) {
        pipeline.source.selectedTables = [];
      }
      const pipelinePayload: PipelineApiPayload = this.removeMetadataFromPipeline(pipeline);

      if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.REPLICATION) {
        return firstValueFrom(this.pipelinesApiService.update(pipelinePayload, true));
      } else {
        return firstValueFrom(this.schedulePipelinesApiService.update(pipelinePayload, true));
      }
    }
    return new Promise((resolve) => {
      resolve(null);
    });
  };

  // clear the selected tables when the pipeline type changes from COPY to NON-COPY for a pipeline with IBM i source
  private clearTablesOnPipelineTypeChanges(pipeline: Pipeline, pipelineChanges: PipelineCompareResult): boolean {
    const pipelineDiff: any = pipelineChanges.objDiff;
    if (pipelineDiff.hasOwnProperty('dataFlowType') && pipeline.source && pipeline.source.dataConnection?.connectionType === 'DB2I') {
      const dataFlowTypeDiff = pipelineDiff.dataFlowType;
      return dataFlowTypeDiff.right !== dataFlowTypeDiff.left && dataFlowTypeDiff.right === 'COPY';
    }
    return false;
  }

  private removeMetadataFromPipeline(pipeline: Pipeline): PipelineApiPayload {
    let cleanPipeline: PipelineApiPayload = { ...pipeline };
    if (pipeline.type === 'scheduledPipeline') {
      cleanPipeline.sourceDataConnectionId = cleanPipeline.source?.dataConnection?.id;
      cleanPipeline.selectedTables = cleanPipeline.source?.selectedTables;
      cleanPipeline.targetDataConnectionId = cleanPipeline.target?.dataConnection?.id;
      delete cleanPipeline.source;
      delete cleanPipeline.target;
    } else {
      delete cleanPipeline.source?.dataConnection?.catalogStatus;
      delete cleanPipeline.target?.dataConnection?.catalogStatus;
    }
    return cleanPipeline;
  }

  private readonly storePipelineId = (apiResponse: CreatePipelineApiResponse) => {
    const pipeline = { id: apiResponse.id, projectId: this.projectId, isEditing: false } as Partial<Pipeline>;
    this.pipelineEntityService.patchPipeline(pipeline);
  };

  private readonly pipelineIsSaved = (): boolean => {
    return typeof this.pipelineEntityService.getPipeline().id !== 'undefined';
  };
}
