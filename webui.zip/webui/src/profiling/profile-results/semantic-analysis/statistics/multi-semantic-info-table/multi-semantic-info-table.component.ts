import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-multi-semantic-info-table',
  templateUrl: './multi-semantic-info-table.component.html',
  styleUrls: ['./multi-semantic-info-table.component.css']
})
export class MultiSemanticInfoTableComponent implements OnInit {
  @Input() statistic: any;
  @Input() name: string;
  @Input() semanticType: string;
  @Output() tableRowData: EventEmitter<Record<string, unknown>> = new EventEmitter<Record<string, unknown>>();

  cols = [];
  data = [];
  defaultSort = '';
  selected: any;
  highlighted: any;
  showLinkMap = {};
  displayStats = [];
  hidevalidity: true;
  constructor(private translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.data = [];
    if (this.name === ProfilingConstants.SEMANTICSTATSFREQUENCY.MULTIPLE_SEMANTIC) {
      this.loadMultiSemanticTable();
    }
  }
  onTableRowClick(type, index) {
    const res = this.displayStats.find((element) => element.semanticType === type);
    this.selected = this.data[index];
    this.tableRowData.emit({ isInfo: true, data: res });
  }
  loadMultiSemanticTable() {
    this.cols = [
      {
        field: 'semanticType',
        header: this.translocoService.translate('discoveryProfiling.results.semanticTypeColumn'),
        type: 'showInfoLink',
        flagKey: 'isShowLink'
      },
      {
        field: 'confidence',
        header: this.translocoService.translate('discoveryProfiling.results.confidence'),
        type: 'progressBar'
      },
      {
        field: 'validity',
        header: this.translocoService.translate('discoveryProfiling.results.validityColumn'),
        type: 'progressBar'
      }
    ];
    this.defaultSort = 'validity';
    const foundSemanticTypes = {};
    for (const stat of this.statistic) {
      if (foundSemanticTypes[stat['semanticType']]) {
        const index = this.displayStats.findIndex((val) => val.semanticType === stat.semanticType);
        this.displayStats[index] = { ...this.displayStats[index], ...stat };
      } else {
        foundSemanticTypes[stat['semanticType']] = true;
        this.displayStats.push(stat);
      }
    }
    const validityValues = [];
    for (const val of this.displayStats) {
      if (val.validity) {
        validityValues.push(val.validity);
      }
      const valid = (val.validity?.validCount / (val.validity?.validCount + val.validity?.invalidCount)) * 100;
      const confidence = (val?.validCount / (val?.validCount + val?.invalidCount)) * 100;
      const isShowLink = Object.keys(val).some((key) => (val[key] && val[key]['frequency'] ? true : false));
      this.showLinkMap[val.semanticType] = !this.showLinkMap[val.semanticType] && isShowLink;
      this.data.push({
        semanticType: val.semanticType,
        validity: Number(valid),
        confidence: Number(confidence)
      });
      if (validityValues.length === 0) {
        this.cols.find((col) => col.field === ProfilingConstants.SEMANTICSTATSFREQUENCY.VALIDITY)['display'] = 'none';
      }
    }
  }
}
