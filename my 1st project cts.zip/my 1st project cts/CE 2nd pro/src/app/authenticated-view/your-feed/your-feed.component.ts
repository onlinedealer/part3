import { Component, OnInit, Input } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { HttpObserve } from '@angular/common/http/src/client';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-your-feed',
  templateUrl: './your-feed.component.html',
  styleUrls: ['./your-feed.component.scss'],
  providers: []
})

export class YourFeedComponent implements OnInit {
 @Input() couponList: any ;
  coupons:any;
  carepassDeals: boolean = true
  extrabucksDeals: boolean = true
  babyDeals: boolean = false
  beautyDeals: boolean = false
  groceryDeals: boolean = false
  healthcareDeals: boolean = false
  householdDeals: boolean = false
  personalcareDeals: boolean = false
  totalFollowing: number = 0
  totalFollowingMessage: string
  categoryButton: boolean = true
  editSection: boolean = true
  categoriesSection: boolean = false
  follow: boolean = false;
  listOfCategoriesSelected = ["CarePass", "ExtraBucks"];
  localStorageData = [];
  selectedCategoriesData = [];
  listOfSelectedCategories = [];
  imagesPaths:Object = ImagePaths;
  yourFeedLists = [
    { "name": "CarePass", "imagePath": ImagePaths.CAREPASS_HEART, "follow": false },
    { "name": "ExtraBucks", "imagePath": ImagePaths.CAREPASS_CAT, "follow": false },
    { "name": "Baby", "imagePath": ImagePaths.CAREPASS_BABY, "follow": true },
    { "name": "Beauty", "imagePath": ImagePaths.CAREPASS_BEAUTY, "follow": true },
    { "name": "Grocery", "imagePath": ImagePaths.CAREPASS_GROCERY, "follow": true },
    { "name": "Health care", "imagePath": ImagePaths.CAREPASS_HEALTH, "follow": true },
    { "name": "Household", "imagePath": ImagePaths.CAREPASS_HOUSEHOLD, "follow": true },
    { "name": "Personal care", "imagePath": ImagePaths.CAREPASS_PERSONAL, "follow": true }
  ];
  serviceUrls:Object;

  constructor(public utilityService: UtilityService) {
    /*this.coupons = this.cs.getCoupons()
    this.coupons.subscribe((data) => {
      const obsData = data;
      this.couponList = obsData.cusInfResp.cpns;
    })*/
   }

  ngOnInit() {
    var checkLocalStorageData = JSON.parse(localStorage.getItem("yourFeedLists"));
    this.selectedCategoriesData = JSON.parse(localStorage.getItem("selectedCategories"));
    if(checkLocalStorageData == null){  // if their is no record, then here setting all records.
      localStorage.setItem("yourFeedLists", JSON.stringify(this.yourFeedLists));
      localStorage.setItem("selectedCategories", JSON.stringify(this.listOfCategoriesSelected));
    }
    else{ // records taking from localStorage, and fetching to UI
      this.yourFeedLists = JSON.parse(localStorage.getItem("yourFeedLists"));
    }
    if (this.selectedCategoriesData.length === 0) {
       this.categoryButton = false;
    }
    else{
       this.categoryButton = true;
    }
    this.getServiceUrls();
  }

  getServiceUrls(){
    this.utilityService.fetchServiceUrls();
      this.utilityService.serviceUrlsObservable$.subscribe((data) => {
        if(!this.utilityService.isEmpty(data) && !data.hasOwnProperty('error')){
          this.serviceUrls = data;
          if(this.serviceUrls){              
              this.getCustomerProfile();
          }
        }else if(data.hasOwnProperty('error')){

        }
      });
  }

  getCustomerProfile(){
    let payload = {
    };

    let header = {
    };

    this.utilityService.sendRequest(this.serviceUrls['getCustomerProfile'],payload, header).subscribe((response)=>{
          if(response.hasOwnProperty('cusInfResp') && response['cusInfResp'].hasOwnProperty('xtraCard')){    
            if(response['cusInfResp'].hasOwnProperty('cpns') && !this.utilityService.isEmpty(response['cusInfResp']['cpns'])){
              this.couponList = response['cusInfResp']['cpns'];
            } else{
              console.log('error');
            }     
          }else{
            console.log('error');
          }
      },
      error =>{
        console.log(error);
      });
  }

  
  showEdit() {
    if (this.editSection === false) {
        this.editSection = true
        this.categoriesSection = false
    }
  }

  showCategories() {  // "I'm done, show me deals" or "You have no selections" button function
    if (this.categoriesSection === false) {
      this.categoriesSection = true
      this.editSection = false
      this.totalFollowing = JSON.parse(localStorage.getItem("selectedCategories")).length;
      localStorage.setItem("totalFollowing", JSON.stringify(this.totalFollowing));
    }
    this.localStorageData = JSON.parse(localStorage.getItem("yourFeedLists"));
    this.listOfSelectedCategories = JSON.parse(localStorage.getItem("selectedCategories"));

    if(this.totalFollowing === 1) {
      this.totalFollowingMessage = 'category'
    } else {
      this.totalFollowingMessage ='categories'
    }
  }

  selectCategory(rowRecord) { // selected category button
    this.localStorageData = JSON.parse(localStorage.getItem("yourFeedLists"));
    this.selectedCategoriesData = JSON.parse(localStorage.getItem("selectedCategories"));
    if (this.selectedCategoriesData.length === 1 && rowRecord.follow == false) {
       this.categoryButton = false;
    }
    else{
       this.categoryButton = true;
    }
    rowRecord.follow = !rowRecord.follow;
    for (var i = 0; i <= this.localStorageData.length; i++) {     //updating particular record if change in localStorage
      if(this.localStorageData[i].name == rowRecord.name){
        this.yourFeedLists[i] = rowRecord;
        localStorage.setItem("yourFeedLists", JSON.stringify(this.yourFeedLists));
        break;
      }
    }

    for (var i = 0; i <= this.selectedCategoriesData.length; i++) {
      if(rowRecord.follow == false && this.selectedCategoriesData.indexOf(this.selectedCategoriesData) === -1){
          this.selectedCategoriesData.push(rowRecord.name)
          localStorage.setItem("selectedCategories", JSON.stringify(this.selectedCategoriesData));
          break;
      }
      else{
        if(this.selectedCategoriesData[i] == rowRecord.name){
          this.selectedCategoriesData.splice(i,1);
          localStorage.setItem("selectedCategories", JSON.stringify(this.selectedCategoriesData));
          break;
        }
      }
    }
    
  };
  
  

  checkCpnsList = () => {
    let count = 0
    for(let i in this.couponList) {
      if(this.couponList[i].mktgPrgCd === "C") {
        count++
      }
    }
    return count > 0
  }

}
