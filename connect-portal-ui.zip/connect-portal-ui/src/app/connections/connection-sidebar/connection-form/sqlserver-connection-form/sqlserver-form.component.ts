import { AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ControlContainer, Form, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../shared/connection';
import { BaseConnectionForm } from '../base-connection-form/base-connection-form';
import { BaseConnectionFormComponent } from '../base-connection-form/base-connection-form.component';
import { Server } from '../../../../servers/shared/server';
import { ConnectionFormValidators } from '../shared/connection-form-validators';
import { ConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component';

/**
 * connection parameters for the sqlserver connection
 */
export enum SQLSERVER_CONNECTION_PARAMETERS {
  ENGINE_NAME = 'SQL_SERVER_INSTANCE_NAME'
}
/**
 * The sqlserver connection form
 */
@Component({
  selector: 'p-connect-sqlserver-form',
  templateUrl: './sqlserver-form.component.html'
})
export class SqlServerFormComponent extends BaseConnectionFormComponent implements OnInit, OnDestroy, AfterViewInit, BaseConnectionForm {
  /**
   * Selected Runtime Server
   */
  @Input() selectedRuntimeServer: Server;

  /**
   * Reference to the credentials child component
   */
  @ViewChild(ConnectionCredentialsFormComponent) credentialsComponent: ConnectionCredentialsFormComponent;

  /**
   * form group
   */
  sqlConnectionForm: FormGroup;

  constructor(private readonly controlContainer: ControlContainer, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }

  ngOnDestroy(): void {
    this.removeChildFormControls(this.sqlConnectionForm);
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.createForm();
  }

  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): Connection {
    const connection = this.credentialsComponent.getConnection(isTesting); // only populates the user & password properties
    connection.database = this.sqlConnectionForm.get('database').value;
    connection.port = this.sqlConnectionForm.get('databasePort').value;
    connection.parameters = [
      {
        key: SQLSERVER_CONNECTION_PARAMETERS.ENGINE_NAME,
        value: this.sqlConnectionForm.get('database').value
      }
    ];
    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   */
  set connection(connection: Connection) {
    this.sqlConnectionForm.patchValue({
      database: connection.database
    });

    this.credentialsComponent.connection = connection;
  }
  createForm(): void {
    this.sqlConnectionForm = this.controlContainer.control as FormGroup;
    this.sqlConnectionForm.addControl(
      'database',
      new FormControl('', [Validators.required, ConnectionFormValidators.noWhiteSpaceValidator])
    );
    this.sqlConnectionForm.addControl(
      'databasePort',
      new FormControl('1433', [Validators.required, Validators.min(1024), Validators.max(65535), Validators.pattern('^[0-9]*$')])
    );

    this.sqlConnectionForm.addControl('dbmsVersion', new FormControl('-'));
    this.sqlConnectionForm.addControl('driverVersion', new FormControl('-'));
    this.sqlConnectionForm.addControl('gmtOffset', new FormControl('-'));
  }
}
