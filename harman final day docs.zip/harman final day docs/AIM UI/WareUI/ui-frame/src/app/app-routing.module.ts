import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

export const AppRoutes: Routes = [
    {
        path: "meteringpoints",
        loadChildren: () => import("../MeteringPoints/meteringpoints.module").then(m => m.MeteringPointsModule)
    },
    {
        path: "tasks",
        loadChildren: () => import("../Tasks/tasks.module").then(m => m.TasksModule)
    },
    {
        path: "",
        pathMatch: "full",
        redirectTo: "/meteringpoints"
    }
];

@NgModule({
    imports: [RouterModule.forRoot(AppRoutes, { enableTracing: false })],
    exports: [RouterModule]
})
export class AppRoutingModule {}
