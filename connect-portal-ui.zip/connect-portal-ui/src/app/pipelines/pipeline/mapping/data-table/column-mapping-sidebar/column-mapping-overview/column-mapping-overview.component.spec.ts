import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { Connection } from 'src/app/connections/shared/connection';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
import { ColumnMappingOverviewComponent } from './column-mapping-overview.component';

describe('ColumnMappingOverviewComponent', () => {
  let component: ColumnMappingOverviewComponent;
  let fixture: ComponentFixture<ColumnMappingOverviewComponent>;
  let mappingService: PipelineMappingService;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ColumnMappingOverviewComponent],
      imports: [HttpClientTestingModule, getTranslocoModule()]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ColumnMappingOverviewComponent);
    mappingService = TestBed.inject(PipelineMappingService);
    component = fixture.componentInstance;
    component.sourceDataConnection = { connectionType: 'ORACLE' } as Connection;
    component.targetDataConnection = { connectionType: 'DB2i' } as Connection;
    spyOn(mappingService, 'getColumnHeaders').and.returnValue([
      { header: 'Topic1', name: 'topic1' },
      { header: 'Topic2', name: 'topic2' }
    ]);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should emit version when dropdown is changed', () => {
    const event = { version: 1 };
    const versionChangeSpy = spyOn(component.versionChange, 'emit');
    component.onDropdownChange(event);
    expect(versionChangeSpy).toHaveBeenCalledWith(event);
  });

  it('should have versions dropdown when schema registry exists', () => {
    component.schemaRegistryAvailable = true;
    const dropdownElement = fixture.debugElement.query(By.css('[data-cy="versionDropdown"]'));
    expect(dropdownElement).toBeDefined();
  });

  it('should set selected version to newest', () => {
    // the versions list will always arrive chronologically reversed into the overview component
    component.versionsList = [
      { key: '3', value: 'Newest' },
      { key: '2', value: '2' },
      { key: '1', value: '1' }
    ];
    component.selectedVersion = { key: '1', value: '1' };
    component.open();
    expect(component.selectedVersion.value).toBe('Newest');
  });
});
