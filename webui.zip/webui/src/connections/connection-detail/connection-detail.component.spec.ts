import { ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { AccordionModule } from 'primeng/accordion';
import { ChartModule } from 'primeng/chart';
import { Spies } from '../../test/spies.model';

import { ConnectionDetailComponent } from './connection-detail.component';

describe('ConnectionDetailComponent', () => {
  let component: ConnectionDetailComponent;
  let fixture: ComponentFixture<ConnectionDetailComponent>;

  beforeEach(async () => {
    Spies.init();
    await TestBed.configureTestingModule({
      declarations: [ConnectionDetailComponent],
      imports: [AccordionModule, BrowserAnimationsModule, ChartModule],
      providers: [{ provide: HttpUtilService, useValue: Spies.HttpUtilService }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ConnectionDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
