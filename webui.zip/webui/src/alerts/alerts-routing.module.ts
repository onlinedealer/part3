import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AlertsListingComponent } from './alerts-listing/alerts-listing.component';

const routes: Routes = [
  {
    path: '',
    component: AlertsListingComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AlertsRoutingModule {}
