import { Component, Input, AfterViewInit } from "@angular/core";
import { Contract } from "../../models/contract.model";
import { MeteringPoint, Customer } from "../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { MeteringPointsSelectors, ContractSelectors, MeteringsSelectors, MeterConnectionSelectors } from "../../store/selectors";
import { Observable, Subscription } from "rxjs";
import { RouterSelectors } from "../../../app/store/selectors";
import { SecondarySideviewActions } from "../../store/actions";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../app/services/translations-service";

@Component({
    selector: "landisgyr-meteringpoint-details",
    templateUrl: "./meteringpoint-details.component.html",
    styleUrls: ["./meteringpoint-details.component.scss"]
})
export class MeteringPointDetailsComponent implements AfterViewInit {
    @Input() meteringPoint!: MeteringPoint;

    loading$: Observable<boolean> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);
    refreshDataLoading$: Observable<boolean> = this.store.select(MeteringPointsSelectors.getLoadingData);
    routeSubscription!: Subscription;

    meteringPointCustomer$: Observable<Customer | undefined> = this.store.select(
        MeteringPointsSelectors.getSelectedMeteringPointCustomerInfo
    );

    activeContract$: Observable<Contract | undefined> = this.store.select(
        ContractSelectors.getCurrentlyActiveConnectionContractOfSelectedMeteringPoint
    );

    currentStateName$: Observable<string | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointActiveStateName);

    currentStatesCount$: Observable<number | undefined> = this.store.select(
        MeteringPointsSelectors.getSelectedMeteringPointActiveStatesCount
    );

    latestReadingDate$: Observable<number> = this.store.select(MeteringsSelectors.getSelectedMeteringPointLatestReading);

    missingMeterConnection$: Observable<boolean> = this.store.select(MeterConnectionSelectors.isMissingMeterConnection);

    missingDataForMetering$: Observable<any> = this.store.select(MeteringsSelectors.isSelectedMeteringPointMissingData);

    haveNoProfileMeterings$: Observable<boolean> = this.store.select(MeteringsSelectors.haveNoProfileMeterings);

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {}
    missingDataBasedOnLimit$: Observable<boolean> = this.store.select(MeteringsSelectors.isMissingDataBasedOnLimit);

    openMeteringPointContractsSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.OpenMeteringPointContractsSecondarySideview());
    }

    openMeteringPointCustomPropertiesSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.OpenMeteringPointCustomPropertiesSecondarySideview());
    }

    openMeteringPointStatesSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.OpenMeteringPointStatesSecondarySideview());
    }

    ngAfterViewInit() {
        setTimeout(() => this.checkURLForSecondarySideview());
    }

    checkURLForSecondarySideview() {
        this.store
            .select(RouterSelectors.getLastSegment)
            .subscribe((lastSegment) => {
                if (lastSegment === "stateDetails") {
                    this.openMeteringPointStatesSecondarySideview();
                } else if (lastSegment === "contracts") {
                    this.openMeteringPointContractsSecondarySideview();
                } else if (lastSegment === "customProperties") {
                    this.openMeteringPointCustomPropertiesSecondarySideview();
                }
            })
            .unsubscribe();
    }
}
