import { AnimationTriggerMetadata, trigger, state, transition, style, animate } from "@angular/animations";

export const menuAnimations: {
    readonly fadeMenu: AnimationTriggerMetadata;
} = {
    fadeMenu: trigger("fadeAnimation", [
        state("default", style({ opacity: 1 })),
        transition("void => *", [style({ opacity: 0 }), animate("200ms")]),
        transition("default => closing", animate("200ms", style({ opacity: 0 })))
    ])
};

export type MenuAnimationState = "default" | "closing";
