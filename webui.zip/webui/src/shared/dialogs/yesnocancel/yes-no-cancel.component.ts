import { Component } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { DialogResult } from '../dialog-result.model';

@Component({
  selector: 'discovery-yes-no-cancel',
  templateUrl: './yes-no-cancel.component.html'
})
export class YesNoCancelComponent {
  DialogResult = DialogResult;
  title: string;

  titleParams?: Record<string, string>;
  message: string;

  messageParams?: Record<string, string>;

  constructor(public activeModal: NgbActiveModal) {}
}
