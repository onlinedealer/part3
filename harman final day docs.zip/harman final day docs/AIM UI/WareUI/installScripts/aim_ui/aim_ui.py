'''AIMUI installation script'''
from lib.Module import Module
from lib.FileTasks import CopyFiles
from lib.WebLogicTasks import WLSTScript, WLCheck
from lib.EfecteTasks import (
	CreateEfecteConfigurations,
	ReadEfecteConnectionInformation,
	EfecteImportPermissions)

# Currently just containing stuff that are manually copied into dummy ICP which is also in the VCS
class aim_ui(Module):
	TIMEOUT=1800
	
	def init(self):
		#Check environment
		wlEnv = self.check(WLCheck(requireTargetServer=True, requireTargetJmsServer=True))
		
		#UAM installation here
		uam_info = self.task(ReadEfecteConnectionInformation(self.args.gsProductHome))
		asHost = lambda: wlEnv.result.targetServer.host
		javaHome = getattr(self.args, "javaHome", None)
		useHttps = bool(self.args.wareUIUseHttps == 'true')
		
		# Assertion consumer services POST URL. Processes the SAML responses of logins.
		acsPostUrlUI = lambda: CreateEfecteConfigurations.getDefaultAcsPostUrl(wlEnv, useHttps, 'AIMUI')
		# Single logout services redirect response URL. Processes the SAML responses of logout.
		sloRedirectResponseUrlUI = lambda: CreateEfecteConfigurations.getDefaultSloRedirectResponseUrl(wlEnv, useHttps, 'AIMUI')

		config = {'aim_ui' :'AIMUI:use'}
		self.task(CreateEfecteConfigurations(
			uam_info=uam_info,
			uamAdminPassword=self.args.uamAdminPassword,
			serviceHost=asHost,
			issuer='aim_ui',
			acsPostUrl=acsPostUrlUI,
			sloRedirectResponseUrl=sloRedirectResponseUrlUI,
			applicationsConfig=config,
			javaHome=javaHome,
			uiName='AIM application'))
		
		# Deploy application
		self.task(WLSTScript(
						script="weblogic/DeployApp.py",
						scriptArgs= ['--workspaceDir', self.env.workspaceDir],
						timeout=aim_ui.TIMEOUT),
				"Deploy aim_ui application")
