import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import CreateCollectionLoadMTAs from '../Dashboard/CreateCollectionLoadMTAs'
import CircularProgress from '@material-ui/core/CircularProgress'
//  import LoadingHOC from '../common/HOC/LoadingHOC'
import { connect } from 'react-redux'
//  import * as Constants from '../common/Utils/Constants'
import { bindActionCreators } from 'redux'
import IntegrationReactSelect from '../common/GrouperAutoComplete/IntegrationReactSelect'
import { getItemTypesOptions } from '../common/Utils/CommonUtils'
import { getCollectionItemTypes, getCollectionMtas, getItemThemes, clearItemThemes } from '../../store/Dashboard/actionCreator'

const styles = theme => ({
  container: {
    padding: 10,
  },
  formControl: {
    marginTop: 10,
    width: '100%',
  },
  field: {
    marginTop: 10,
  },
  mtaTitle: {
    fontSize: 13,
    paddingTop: 10,
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  createButtonStyle: {
    position: 'relative',
    color: '#fff',
    // float: 'right',
    background: '#1976d2',
    marginLeft: 10,
    fontWeight: 300,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    padding: 0,
    // float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  mtaBlock: {
    width: '100%',
  },
})

export class UpdateCollectionGroup extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      masterCollectionThemes: [],
      formData: {
        selectedMTAs: [],
      },
      errors: {
      },
      RequiredMTAs: [],
      formDataItenType: {
        group_type: 'variation',
        group_name: '',
        item_type: this.props.groupDetails.item_type,
        item_type_id: this.props.groupDetails.item_type_id,
        tcins: [],
      },
      //  isDisabled: true,
    }
  }

  componentWillMount () {
    if (this.props.collectionItemTypes.length === 0 && this.props.isItemType === true) {
      this.props.getCollectionItemTypes()
    }
    //  this.props.getCollectionItemTypes()
    const formData = { ...this.state.formData }
    formData.selectedMTAs = this.props.groupDetails.collection_themes
    this.setState({ formData })
  }

  validateRequiredMTAs = () => {
    let isRequiredMTAs = []
    this.props.collectionMTAs.required_collection_mta_info.map((option) => {
      const selCount = _.findIndex(this.state.formData.selectedMTAs, (n) => { return n.id === option.id })
      if (selCount === -1) {
        isRequiredMTAs.push(option.id)
      } else {
        if (option.uda_has_uom) {
          const selObj = _.find(this.state.formData.selectedMTAs, (n) => { return n.id === option.id })
          if (selObj.attribute_uom_value === '') {
            isRequiredMTAs.push(option.id)
          }
        }
      }
    })
    return isRequiredMTAs
  }

  handleUpdate = event => {
    const isValid = true // validate comes here
    const { groupDetails, auth } = this.props
    let payload = {}

    payload.collection_themes = this.state.formData.selectedMTAs
    /* if (compareCollectionThemes(groupDetails.collection_themes, tempArr)) {
        payload.collection_theme_value_updated = true
      } */
    payload.collection_theme_value_updated = true
    if (isValid && groupDetails && groupDetails.group_id) {
      payload.description = groupDetails.description
      payload.group_type = groupDetails.group_type
      payload.group_id = groupDetails.group_id
      payload.group_type_id = groupDetails.group_type_id
      payload.status = groupDetails.status
      payload.tcin_data = []
      if (this.state.formDataItenType.item_type_id !== groupDetails.item_type_id) {
        payload.item_type_id = this.state.formDataItenType.item_type_id
        var itemTypeList = getItemTypesOptions(this.props.collectionItemTypes)
        var trackById = itemTypeList.find(obj => { return obj.value === this.state.formDataItenType.item_type_id })
        this.state.formDataItenType.item_type = trackById.label
        payload.item_type = this.state.formDataItenType.item_type
        payload.group_name_updated = true
      } else {
        payload.item_type = groupDetails.item_type
        payload.item_type_id = groupDetails.item_type_id
      }
      const RequiredMTAs = this.validateRequiredMTAs()
      if (RequiredMTAs.length === 0) {
        this.props.updateGroupName(payload, auth.memberOf, auth.lanId)
        this.props.closeDrawer()
      } else {
        this.setState({ RequiredMTAs: RequiredMTAs })
      }
    } else {
      // this.setState({ errors })
    }
  }
  handleSelectChange = (name, value, itemName) => {
    const formDataItenType = { ...this.state.formDataItenType }
    const errors = { ...this.state.errors }
    if (name === 'item_type') {
      formDataItenType.item_type_id = value
      errors.item_type = ''
      this.setState({ formDataItenType, errors })
      //  this.props.onHandleChange(name, value)
      this.props.getCollectionMtas(value)
      this.state.formDataItenType.item_type_id = value
      //  this.state.isDisabled = false
    }
  }

  handlekeyDown = (name, value) => {
    if (name === 'item_type' && this.props.groupType === 'variation') {
      if (value.length >= 1) {
        // this.props.getItemTypes(value)
      }
    }
  }
  render () {
    const { classes, collectionMTAs, groupDetails, closeDrawer, loadingBtnStatus, isItemType } = this.props
    const { RequiredMTAs } = this.state
    const step2Data = (groupDetails.collection_themes) ? groupDetails.collection_themes : []
    return (
      <div>
        {collectionMTAs &&
          <Grid container>
            <Grid item xs={12}>
              <h4>Edit Group MTAs</h4>
            </Grid>
            {isItemType &&
              <Grid item xs={12} className={classes.field}>
                <IntegrationReactSelect
                  currentValue={this.state.formDataItenType.item_type_id}
                  column_id="item_type"
                  options={getItemTypesOptions(this.props.collectionItemTypes)}
                  //  isMultiOption={isMultiple}
                  handleSelectChange={this.handleSelectChange}
                  handlekeyDown={this.handlekeyDown}
                  labeledMsg="Item Type*"
                  columnId="itemType"
                />
              </Grid>
            }
            {collectionMTAs.required_collection_mta_info.length > 0 &&
              <div className={classes.mtaBlock}>
                <Grid item xs={12} className={classes.field}>
                  <span className={classes.mtaTitle}>Required MTAs</span>
                </Grid>
                <CreateCollectionLoadMTAs
                  mtaList={collectionMTAs.required_collection_mta_info}
                  handleSelectChange={this.handleSelectChange}
                  step2FormData={step2Data}
                  RequiredMTAs={RequiredMTAs}
                />
              </div>
            }
            {collectionMTAs.optional_collection_mta_info.length > 0 &&
              <div className={classes.mtaBlock}>
                <Grid item xs={12} className={classes.field}>
                  <span className={classes.mtaTitle}>Optional MTAs</span>
                </Grid>
                <CreateCollectionLoadMTAs
                  mtaList={collectionMTAs.optional_collection_mta_info}
                  handleSelectChange={this.handleSelectChange}
                  step2FormData={step2Data}
                  RequiredMTAs={RequiredMTAs}
                />
              </div>
            }
            <Grid item xs={12} className={classes.field}>
              <Button color="primary" className={classes.cancelButtonStyle} onClick={closeDrawer}>
                Cancel
              </Button>
              <Button
                variant="contained"
                color="primary"
                onClick={this.handleUpdate}
                className={classes.createButtonStyle}
              >
                {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Save') &&
                  <CircularProgress
                    className={classes.progress}
                    size={25}
                  />
                }
                Save
              </Button>
            </Grid>
          </Grid>
        }
      </div>
    )
  }
}

UpdateCollectionGroup.propTypes = {
  classes: PropTypes.object.isRequired,
}
const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getCollectionItemTypes,
    getCollectionMtas,
    getItemThemes,
    clearItemThemes,
  }, dispatch)

const mapStateToProps = state => ({
  auth: state.get('auth').toJS(),
  itemTypes: state.getIn(['grouperDashboard', 'itemTypes']).toJS(),
  collectionItemTypes: state.getIn(['grouperDashboard', 'collectionItemTypes']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(UpdateCollectionGroup))

//  export default LoadingHOC(['collectionMTAs'])(withStyles(styles)(UpdateCollectionGroup))
