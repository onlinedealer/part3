export class RadioConfig {
  label: string;
  value: string;
}
