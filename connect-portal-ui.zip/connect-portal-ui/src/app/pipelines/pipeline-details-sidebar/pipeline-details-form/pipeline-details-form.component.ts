import { Component, Input, Output, EventEmitter } from '@angular/core';
import { BaseComponent } from '../../../core/base.component';

@Component({
  selector: 'p-connect-pipeline-details-form',
  templateUrl: './pipeline-details-form.component.html'
})
export class PipelineDetailsFormComponent extends BaseComponent {
  @Input() selectedPipeline: any;
  @Input() projectName: string;
  @Output() alertsButtonClickEvent = new EventEmitter();

  get lastRefreshed(): string {
    return this.selectedPipeline && this.selectedPipeline.generationTimestamp
      ? this.getDateFromEpoch(this.selectedPipeline.generationTimestamp).toLocaleString()
      : '';
  }

  constructor() {
    super();
  }

  hasMonitoringStatusValues(): boolean {
    return this.selectedPipeline && this.selectedPipeline.hasOwnProperty('replicationStatus');
  }

  alertsButtonClicked() {
    this.alertsButtonClickEvent.emit();
  }
}
