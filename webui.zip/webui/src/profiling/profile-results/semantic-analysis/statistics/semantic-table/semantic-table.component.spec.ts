import { Spies } from 'discovery-test';
import { SemanticTableComponent } from './semantic-table.component';

describe('SemanticTableComponent', () => {
  let component: SemanticTableComponent;

  beforeEach(async () => {});

  beforeEach(() => {
    Spies.init();
    component = new SemanticTableComponent(Spies.TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with Email Frequency', () => {
    component.name = 'emailDomainFrequency';
    component.statistic = {
      frequency: {
        'brown.com': 7920,
        'davis.com': 5934,
        'gmail.com': 508776,
        'hotmail.com': 511469,
        'johnson.com': 10668
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(5);
    expect(component.data[0].email).toMatch('brown.com');
    expect(component.data[2].count).toEqual(component.statistic['frequency']['gmail.com']);
  });

  it('Initialize ngOnInit with Phone Country Frequency', () => {
    component.name = 'phoneCountryFrequency';
    component.statistic = {
      frequency: {
        Australia: 54,
        Canada: 26802,
        Egypt: 126,
        Greece: 3
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(4);
    expect(component.data[0].phoneCountry).toMatch('Australia');
    expect(component.data[2].count).toEqual(component.statistic['frequency']['Egypt']);
  });

  it('Initialize ngOnInit with Phone Type Frequency', () => {
    component.name = 'phoneTypeFrequency';
    component.statistic = {
      frequency: {
        FIXED_LINE: 183,
        FIXED_LINE_OR_MOBILE: 2690712
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(2);
    expect(component.data[0].phoneType).toMatch('FIXED_LINE');
    expect(component.data[1].count).toEqual(component.statistic['frequency']['FIXED_LINE_OR_MOBILE']);
  });

  it('Initialize ngOnInit with Phone Region Frequency', () => {
    component.name = 'phoneRegionFrequency';
    component.statistic = {
      frequency: {
        'Alexandria, ON': 30,
        'Smiths Falls, ON': 66,
        'Washington D.C.': 2663910
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(3);
    expect(component.data[0].phoneRegion).toMatch('Alexandria, ON');
    expect(component.data[2].count).toEqual(component.statistic['frequency']['Washington D.C.']);
  });

  it('Initialize ngOnInit with Credit Card Frequency', () => {
    component.name = 'cardTypeFrequency';
    component.statistic = {
      frequency: {
        AMEX: 254715,
        DINERS: 255057,
        DISCOVER: 253092
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(3);
    expect(component.data[0].pattern).toMatch('AMEX');
    expect(component.data[2].count).toEqual(component.statistic['frequency']['DISCOVER']);
  });

  it('Initialize ngOnInit with Date Frequency', () => {
    component.name = 'dateFormatFrequency';
    component.statistic = {
      frequency: {
        'MM/dd/yyyy': 7,
        'dd/MM/yyyy': 2,
        'yyyy-MM-dd': 3060000
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(3);
    expect(component.data[1].pattern).toMatch('dd/MM/yyyy');
    expect(component.data[2].count).toEqual(component.statistic['frequency']['yyyy-MM-dd']);
  });

  it('Initialize ngOnInit with Vin Frequency', () => {
    component.name = 'vinCountryFrequency';
    component.statistic = {
      frequency: {
        Australia: 5432,
        Canada: 2680,
        Japan: 3045,
        Belgium: 51964,
        Switzerland: 43912
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(5);
    expect(component.data[1].vinCountry).toMatch('Canada');
    expect(component.data[2].count).toEqual(component.statistic['frequency']['Japan']);
  });

  it('Initialize ngOnInit with Iban Frequency', () => {
    component.name = 'ibanCountryFrequency';
    component.statistic = {
      frequency: {
        France: 34323,
        Lithuania: 52124,
        Belgium: 51964,
        Switzerland: 43912
      },

      type: 'FrequencyStatistics'
    } as any;
    component.ngOnInit();
    expect(component.data.length).toBe(4);
    expect(component.data[0].ibanCountry).toMatch('France');
    expect(component.data[2].count).toEqual(component.statistic['frequency']['Belgium']);
  });
});
