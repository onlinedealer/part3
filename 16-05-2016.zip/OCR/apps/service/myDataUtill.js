(function() {
    'use strict';

    fileuploader.service('myDataUtill', ['$rootScope', myDataUtill]);

    function myDataUtill($rootScope) {

        

        
        
        this.tableData = function() {
            return $rootScope.myItemData.data;
        } 
        this.templateapplied = function() {
            return $rootScope.GridDataSource.template;
        } 

        



    }
})();
