import { Connection, ConnectionMetadata } from '../../../connections/shared/connection';
import { Filter, FilterMetadata } from '../filters/filter';
import { ColumnMap, ColumnMapMetadata } from '../mapping/shared/map-columns';

export const PIPELINE_ENTITY_TYPE = {
  SCHEDULED: 'scheduled',
  REPLICATION: 'replication'
};

export class SelectedTables {
  key: string;
  value: {
    tableExtractType: string;
    tableAndKeys: { tableName: string; keys: [] }[];
  };
}

export const SelectedTablesMetadata = {
  key: { type: 'string' },
  value: {
    type: 'object',
    attributes: {
      tableExtractType: { type: 'string' },
      tableAndKeys: {
        type: 'array',
        item: 'object',
        key: 'tableName',
        attributes: {
          tableName: { type: 'string' },
          keys: { type: 'array' }
        }
      }
    }
  }
};
export class SourceConnectionInfo {
  dataConnection: Connection;
  selectedTables?: SelectedTables[];
}

export const SourceConnectionInfoMetadata = {
  parameters: {
    type: 'array',
    item: 'object',
    key: 'key',
    ignoreMissing: {
      left: true,
      right: false
    },
    attributes: {
      key: { type: 'string' },
      value: { type: 'string' }
    }
  },
  dataConnection: {
    type: 'object',
    attributes: ConnectionMetadata
  },
  selectedTables: {
    type: 'array',
    item: 'object',
    key: 'key',
    attributes: SelectedTablesMetadata
  }
};

export class TargetConnectionInfo {
  dataConnection: Connection;
  cdcRowMetadatas?: { key?: string; value?: string }[];
  parameters?: { key: string; value: string }[];
}

export const TargetConnectionInfoMetadata = {
  dataConnection: {
    type: 'object',
    attributes: ConnectionMetadata
  },
  cdcRowMetadatas: {
    type: 'array',
    item: 'object',
    key: 'key',
    attributes: {
      key: { type: 'string' },
      value: { type: 'string' }
    }
  },
  parameters: {
    type: 'array',
    item: 'object',
    key: 'key',
    // ignoreMissing: {
    //  left: true,
    //  right: false
    // },
    attributes: {
      key: { type: 'string' },
      value: { type: 'string' }
    }
  }
};

export class Pipeline {
  id?: string;
  projectId?: string;
  name: string;
  description?: string;
  dataFlowType?: string;
  source?: SourceConnectionInfo;
  target?: TargetConnectionInfo;
  filters?: Filter[];
  properties?: { key?: string; value?: string }[];
  tableMapping?: TableMapping[];
  createTopic?: boolean;
  createSubject?: boolean;
  isEditing?: boolean;
  type?: string;
  sourceDataConnectionId?: string;
  targetDataConnectionId?: string;
}

export class PipelineApiPayload extends Pipeline {
  sourceDataConnectionId?: string;
  targetDataConnectionId?: string;
  selectedTables?: SelectedTables[];
}

export class TableMapping {
  id: string;
  key: string;
  value: string;
  hasCustomColMappings: boolean;
  type: string;
  columnMappings?: ColumnMap[];
  schemaVersion?: string;
}

export const PipeLineMetadata = {
  id: { type: 'string' },
  type: { type: 'string', ignoreCompare: true },
  dateEdited: { type: 'string', ignoreCompare: true },
  owner: { type: 'string', ignoreCompare: true },
  columnMappingType: { type: 'string' },
  projectId: { type: 'string' },
  name: { type: 'string' },
  description: { type: 'string' },
  dataFlowType: { type: 'string' },
  source: {
    type: 'object',
    attributes: SourceConnectionInfoMetadata
  },
  sourceTableDefinitionMetadata: {
    type: 'object',
    ignoreCompare: true
  },
  target: {
    type: 'object',
    attributes: TargetConnectionInfoMetadata
  },
  targetDefinitionMetadata: {
    type: 'object',
    ignoreCompare: true
  },
  filters: {
    type: 'array',
    item: 'object',
    key: 'key',
    attributes: FilterMetadata
  },
  properties: {
    type: 'array',
    item: 'object',
    key: 'key',
    attributes: {
      key: { type: 'string' },
      value: { type: 'string' }
    }
  },
  tableMapping: {
    type: 'array',
    item: 'object',
    key: 'value',
    attributes: {
      id: { type: 'string' },
      key: { type: 'string' },
      value: { type: 'string' },
      hasColumnMappings: { type: 'boolean' },
      hasCustomColMappings: { type: 'boolean' },
      includedCDCRowMetadata: { type: 'array' },
      type: { type: 'string' },
      columnMappings: ColumnMapMetadata
    }
  },
  createTopic: { type: 'boolean' },
  createSubject: { type: 'boolean' }
};

/// (JSON.stringify(PipeLineMetadata));
