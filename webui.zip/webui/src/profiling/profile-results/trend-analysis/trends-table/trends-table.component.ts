import { Component, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SharedConstants } from 'discovery-shared';

@Component({
  selector: 'discovery-trends-table',
  templateUrl: './trends-table.component.html'
})
export class TrendsTableComponent implements OnInit {
  @Input() trends: any;
  @Input() stat: string;
  @Input() type: string;
  percentageOnYaxis: boolean;
  cols: any;

  constructor(private translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.loadData();
  }

  loadData() {
    this.percentageOnYaxis = SharedConstants.trendsKeys[this.stat]?.indexOf('PERCENTAGE') > 0;
    this.cols = [
      {
        labelName: this.translocoService?.translate('discoveryProfiling.results.trends.trendsTable.runDateColumn'),
        sortable: true,
        fieldName: 'startTime',
        type: 'datetime'
      },
      {
        labelName: this.stat,
        fieldName: 'value',
        sortable: true,
        type: this.getColumnType()
      }
    ];
  }

  getColumnType() {
    if (
      (this.type === SharedConstants.trendDataType.DATE ||
        this.type === SharedConstants.trendDataType.DATETIME ||
        this.type === SharedConstants.trendDataType.TIMESTAMP) &&
      !this.percentageOnYaxis
    ) {
      switch (this.type) {
        case SharedConstants.trendDataType.DATE:
          return 'date';
        case SharedConstants.trendDataType.DATETIME:
          return 'datetime';
        case SharedConstants.trendDataType.TIMESTAMP:
          return 'timestamp';
      }
    } else if (this.type === SharedConstants.trendDataType.TIME && !this.percentageOnYaxis) {
      return 'time';
    } else {
      return this.percentageOnYaxis ? 'progressBar' : '';
    }
  }

  toFloat(val: string) {
    return Number(parseFloat(val).toFixed(2));
  }
}
