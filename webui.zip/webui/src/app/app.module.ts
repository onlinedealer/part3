import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { APP_INITIALIZER, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgbPopoverConfig, NgbTooltipConfig } from '@ng-bootstrap/ng-bootstrap';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { LoadingBarRouterModule } from '@ngx-loading-bar/router';
import { CoreModule } from 'discovery-core';
import { SharedModule } from 'discovery-shared';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { TranslocoRootModule } from './transloco-root.module';
import { AuthConfigModule } from './auth/auth-config.module';
import { HttpErrorInterceptor, ProtectedAppInitializerService } from '@precisely/prism-ng/di-suite';
import { ErrorHeaderModule } from '@precisely/prism-ng/error-header';
import { OIDC } from '../shared/oidc.model';
import { CatalogConfigModule } from 'dqcore-catalog';

@NgModule({
  declarations: [AppComponent],
  imports: [
    AuthConfigModule,
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    CoreModule,
    ErrorHeaderModule,
    LoadingBarHttpClientModule,
    LoadingBarRouterModule,
    SharedModule,
    HttpClientModule,
    TranslocoRootModule,
    CatalogConfigModule.forRoot({ app: 'gateway', namespace: 'dqcore', path: 'catalog/v1/graphql' })
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: (app: ProtectedAppInitializerService) => () => app.init('portal', OIDC.CLIENT_ID),
      deps: [ProtectedAppInitializerService],
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: HttpErrorInterceptor,
      multi: true
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
  constructor(ngbTooltipConfig: NgbTooltipConfig, popoverconfig: NgbPopoverConfig) {
    // Global configuration of ng-bootstrap tooltips.
    ngbTooltipConfig.container = 'body';
    popoverconfig.container = 'body';
  }
}
