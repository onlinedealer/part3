import { NgModule } from '@angular/core';
import { SharedModule } from 'discovery-shared';
import { AlertsListingComponent } from './alerts-listing/alerts-listing.component';
import { AlertsRoutingModule } from './alerts-routing.module';
import { PanelModule } from 'primeng/panel';
import { TableModule } from 'primeng/table';
import { AlertInfoPanelComponent } from './alerts-listing/infopanels/alert-info-panel/alert-info-panel.component';
import { CheckboxModule } from 'primeng/checkbox';
import { TooltipModule } from 'primeng/tooltip';
import { ScrollPanelModule } from 'primeng/scrollpanel';
import { NoObserverSetupComponent } from './alerts-listing/no-observer-setup/no-observer-setup.component';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { alertsLoader, sharedLoader } from '../core/i18n-loaders';
import { Router, UrlTree } from '@angular/router';
import { AlertsFeatureFlagGuard } from '../shared/alerts-feature-flag.guard';
import { ExportDialogComponent } from './alerts-listing/infopanels/export-dialog/export-dialog.component';
import { DialogService, DynamicDialogModule } from 'primeng/dynamicdialog';
import { DistributionDetailsDialogComponent } from './alerts-listing/distribution-details-dialog/distribution-details-dialog.component';
import { DatePipe } from '@angular/common';

@NgModule({
  declarations: [
    AlertsListingComponent,
    AlertInfoPanelComponent,
    NoObserverSetupComponent,
    DistributionDetailsDialogComponent,
    ExportDialogComponent
  ],
  imports: [
    SharedModule,
    AlertsRoutingModule,
    PanelModule,
    TableModule,
    CheckboxModule,
    TooltipModule,
    ScrollPanelModule,
    DynamicDialogModule
  ],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'discoveryAlerts', loader: alertsLoader },
        { scope: 'discoveryShared', loader: sharedLoader }
      ]
    },
    DatePipe,
    DialogService
  ]
})
export class AlertsModule {
  constructor(router: Router, guard: AlertsFeatureFlagGuard) {
    const result: boolean | UrlTree = guard.canActivate(undefined, router.routerState.snapshot);
    if (result instanceof UrlTree) {
      router.navigateByUrl(result);
    }
  }
}
