import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of } from 'rxjs';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { PipelineService } from '../pipeline.service';
import { Pipeline } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { FiltersSidebarComponent } from './filters-sidebar/filters-sidebar.component';
import { FiltersComponent } from './filters.component';

describe('FiltersComponent', () => {
  let component: FiltersComponent;
  let fixture: ComponentFixture<FiltersComponent>;
  const mockProgressIndicatorStateService = jasmine.createSpyObj('ProgressIndicatorStateService', ['setIsStepValid', 'setIsValid']);
  let pipelineEntityService: PipelineEntityService;
  let pipelineService: PipelineService;

  @Component({
    selector: 'p-connect-filters-sidebar',
    template: '',
    providers: [
      {
        provide: FiltersSidebarComponent,
        useClass: MockFiltersSidebarComponent
      }
    ]
  })
  class MockFiltersSidebarComponent {
    setFilter() {}
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, getTranslocoModule(), HttpClientTestingModule],
      declarations: [FiltersComponent, MockFiltersSidebarComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'filters' } },
        { provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService },
        { provide: FiltersSidebarComponent, useClass: MockFiltersSidebarComponent }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltersComponent);
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    pipelineService = TestBed.inject(PipelineService);
    component = fixture.componentInstance;
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue({
      name: '',
      description: '',
      dataFlowType: '',
      filters: [],
      source: {
        selectedTables: [
          {
            key: 'test1',
            value: {
              tableExtractType: '',
              tableAndKeys: [
                { tableName: 'table1', keys: [] },
                { tableName: 'table2', keys: [] }
              ]
            }
          },
          {
            key: 'test2',
            value: {
              tableExtractType: '',
              tableAndKeys: [
                { tableName: 'table3', keys: [] },
                { tableName: 'table4', keys: [] }
              ]
            }
          }
        ]
      },
      properties: []
    } as Pipeline);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('showFilterSidebar()', () => {
    it('should show filter sidebar when create button is clicked (no source)', () => {
      component.tableConfiguration.createButtonClicked();
      expect(component.isFilterSidebarVisible).toBe(true);
    });

    it('should show filter sidebar when create button is clicked (with source)', () => {
      component.tableConfiguration.createButtonClicked();
      expect(component.isFilterSidebarVisible).toBe(true);
    });
  });

  it('should disable the delete button when no items have been selected', () => {
    component.tableConfiguration.rowSelectionChangedEvent([]);
    expect(component.toolbarMenuItems[1].disabled).toBe(true);
  });

  it('should disable the edit button when no items have been selected', () => {
    component.tableConfiguration.rowSelectionChangedEvent([]);
    expect(component.toolbarMenuItems[0].disabled).toBe(true);
  });

  it('should enable the delete button when items have been selected', () => {
    component.tableConfiguration.rowSelectionChangedEvent([{ id: '1' }]);
    expect(component.toolbarMenuItems[1].disabled).toBe(false);
  });

  it('should enable the edit button when one item has been selected', () => {
    component.tableConfiguration.rowSelectionChangedEvent([{ id: '1' }]);
    expect(component.toolbarMenuItems[0].disabled).toBe(false);
  });

  it('should disable the edit button when more than one item has been selected', () => {
    component.tableConfiguration.rowSelectionChangedEvent([{ id: '1' }, { id: '2' }]);
    expect(component.toolbarMenuItems[0].disabled).toBe(true);
  });

  it('should delete item when option is selected', () => {
    spyOn(pipelineEntityService, 'deleteFilter' as never).and.stub();
    spyOn(pipelineService, 'savePipeline').and.returnValue(of({ id: '1' }).toPromise());
    component.tableConfiguration.rowAction.menuItems
      .find((item) => item.id === 'deleteMenuItem')
      .command({ item: { target: { id: '1' } } });
    expect(pipelineEntityService.deleteFilter).toHaveBeenCalled();
    expect(pipelineService.savePipeline).toHaveBeenCalled();
  });

  it('should delete the selected items', () => {
    spyOn(pipelineEntityService, 'deleteFilter' as never).and.stub();
    spyOn(pipelineService, 'savePipeline').and.returnValue(of({ id: '1' }).toPromise());
    component.tableConfiguration.rowSelectionChangedEvent([{ id: '1' }, { id: '2' }]);
    component.toolbarMenuItems[1].command();
    expect(pipelineEntityService.deleteFilter).toHaveBeenCalledTimes(2);
    expect(pipelineService.savePipeline).toHaveBeenCalledTimes(1);
  });

  it('should set the invalid filters', () => {
    pipelineEntityService.setPipeline({
      name: '',
      description: '',
      dataFlowType: '',
      filters: [
        { schema: 'test1', table: 'table1', expression: 'expression1' },
        { schema: 'test1', table: 'table3', expression: 'expression1' },
        { schema: 'test3', table: 'table3', expression: 'expression3' }
      ],
      source: {
        selectedTables: []
      },
      properties: []
    } as Pipeline);
    // do check the mock pipeline data being passed while spying (before each)
    // only incorrect schema will lead to set invalid filters and that is what expected
    expect(component.invalidFilters).toEqual([
      { schema: 'test1', table: 'table3', expression: 'expression1', actions: ' ' },
      { schema: 'test3', table: 'table3', expression: 'expression3', actions: ' ' }
    ]);
  });

  it('should edit the selected filter when the action menu option is clicked', () => {
    const selectedFilter = {
      id: 'abc',
      schema: 'schema1',
      table: 'table1',
      expression: 'col1 > col2'
    };
    spyOn(component.filtersSidebarComponent, 'setFilter').and.returnValue();
    component.tableConfiguration.rowAction.menuItems
      .find((item) => item.id === 'editMenuItem')
      .command({ item: { target: selectedFilter } });
    expect(component.isFilterSidebarVisible).toBe(true);
    expect(component.filtersSidebarComponent.setFilter).toHaveBeenCalledWith(selectedFilter);
  });

  it('should edit the selected filter when the toolbar menu is clicked', () => {
    const selectedFilter = [
      {
        id: 'abc',
        schema: 'schema1',
        table: 'table1',
        expression: 'col1 > col2'
      }
    ];
    spyOn(component.filtersSidebarComponent, 'setFilter').and.returnValue();
    component.tableConfiguration.rowSelectionChangedEvent(selectedFilter);
    component.toolbarMenuItems[0].command();
    expect(component.isFilterSidebarVisible).toBe(true);
    expect(component.filtersSidebarComponent.setFilter).toHaveBeenCalledWith(selectedFilter[0]);
  });
});
