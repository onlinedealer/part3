import { Component, Input, ChangeDetectionStrategy, OnChanges } from "@angular/core";
import { TranslationsService } from "../../../../../app/services/translations-service";
import { ODREventsTableSorter } from "./odr-events-table.sorter";

@Component({
    selector: "landisgyr-odr-events-table",
    templateUrl: "./odr-events-table.component.html",
    styleUrls: ["./odr-events-table.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class OdrEventsTableComponent implements OnChanges {
    @Input() meterings!: any[];
    odrEventsTableSorter = new ODREventsTableSorter();
    sortedODREventsReadingData$ = this.odrEventsTableSorter.getSortedODRReadingTable();

    constructor(public translations: TranslationsService) {}

    ngOnChanges () {
        this.odrEventsTableSorter.setODRReadingTable(this.meterings);
    }

    trackColumnFn(index: number, column: { key: string; header: string }) {
        return index;
    }
    trackRowFn(index: number, item: any) {
        return index;
    }
}
