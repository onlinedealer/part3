import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { PipelinesApiService } from './pipelines-api.service';

describe('PipelinesApiService', () => {
  let service: PipelinesApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(PipelinesApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
  it('should validate a filter', () => {
    const expectedRequestMethod = 'POST';
    const projectId = 'abc';
    const table = 'def';
    const expression = 'ghi';
    const requestBody = { table, expression };
    let returnedData;
    service.validateFilter(projectId, table, expression).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne({ method: expectedRequestMethod });
    console.log(req.request.url);
    expect(req.request.method).toBe(expectedRequestMethod);
    expect(req.request.body).toEqual(requestBody);
    req.flush(null);
    httpMock.verify();
    expect(returnedData).toBeNull();
  });
});
