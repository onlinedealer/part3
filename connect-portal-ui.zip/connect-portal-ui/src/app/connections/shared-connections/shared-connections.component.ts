import { Component, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { BreadcrumbItem } from '@shared/components/breadcrumb/breadcrumb-item';
import { GenericConnection } from 'dqcore-catalog/lib/connection-properties/connections-typings';
import { MessageService } from 'primeng/api';
import { AirbyteApiService } from 'src/app/pipelines/pipeline/shared/airbyte-api.service';

/**
 * Component for the Shared Connections page.
 */
@Component({
  selector: 'p-connect-shared-connections',
  templateUrl: './shared-connections.component.html'
})
export class SharedConnectionsComponent implements OnInit {
  /**
   * Bread crumb items for the page.
   */
  breadcrumbs: BreadcrumbItem[] = [
    { text: 'common.BREADCRUMBS.APP_ROOT', isActive: true },
    { text: 'common.BREADCRUMBS.CONNECTIONS', isActive: true }
  ];

  connectionTypes: GenericConnection[];
  connectionSpec: any;

  constructor(
    private readonly airbyteApiService: AirbyteApiService,
    private readonly translocoService: TranslocoService,
    private messageService: MessageService
  ) {}

  ngOnInit(): void {
    this.airbyteApiService.getConnectionDetails().subscribe({
      next: (data: any) => {
        this.connectionTypes = data;
      },
      error: () => {
        const errMsg: string = this.translocoService.translate('connections.API_ERROR.CONNECTION_TYPE_UNABLE_TO_LOAD');
        this.messageService.add({ severity: 'error', detail: errMsg });
      }
    });
  }

  loadSelectedConnection(event: any) {
    this.airbyteApiService.getConnectionSpec(event).subscribe({
      next: (data: any) => {
        this.connectionSpec = data;
      },
      error: () => {
        const errMsg: string = this.translocoService.translate('connections.API_ERROR.CONNECTION_SPEC_NOT_FOUND');
        this.messageService.add({ severity: 'error', detail: errMsg });
      }
    });
  }
}
