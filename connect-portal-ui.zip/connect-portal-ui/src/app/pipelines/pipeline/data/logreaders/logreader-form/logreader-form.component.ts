import { Component, Input, OnInit, Output, EventEmitter, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { BaseComponent } from 'src/app/core/base.component';
import { Connection } from 'src/app/connections/shared/connection';
import { LogReader } from '../../shared/logreader';
import { ExcludeusersSidebarComponent } from '../excludeusers-sidebar/excludeusers-sidebar.component';
@Component({
  selector: 'p-connect-logreader-form',
  templateUrl: './logreader-form.component.html',
  styleUrls: ['./logreader-form.component.scss']
})
export class LogReaderFormComponent extends BaseComponent implements OnInit {
  /**
   * Source data connection
   */
  @Input() sourceDataConnection: Connection;

  /**
   * List of journals
   */
  @Input() journals: any[] = [];

  /**
   * Event that is fired when the refresh journals button is clicked
   */
  @Output() refreshClickEvent = new EventEmitter();
  usersExcludedFromCapture: string[] = [];
  @ViewChild(ExcludeusersSidebarComponent) excludeSidebarComponent: ExcludeusersSidebarComponent;
  logReaderFormGroup: FormGroup;
  initialFormGroupValue: any;
  isEditing = false;
  filteredJournals: any[] = [];

  tableInMetabaseOptions = [
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.TABLE_IN_METABASE.NONE', value: '0' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.TABLE_IN_METABASE.ERRORS', value: '3' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.TABLE_IN_METABASE.WARNINGS', value: '4' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.TABLE_IN_METABASE.INFORMATION', value: '5' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.TABLE_IN_METABASE.SQL_PRINT', value: '6' }
  ];

  consoleOptions = [
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.CONSOLE.NONE', value: '0' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.CONSOLE.ALWAYS', value: '1' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.CONSOLE.STATUS', value: '2' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.CONSOLE.ERRORS', value: '3' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.CONSOLE.WARNINGS', value: '4' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.CONSOLE.INFORMATION', value: '5' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.CONSOLE.SQL_PRINT', value: '6' }
  ];

  logFileOptions = [
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_FILE.ERRORS', value: '3' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_FILE.WARNINGS', value: '4' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_FILE.INFORMATION', value: '5' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_FILE.SQL_PRINT', value: '6' }
  ];

  maxLogMembersCreatedOptions = [
    { name: '1', value: '1' },
    { name: '2', value: '2' },
    { name: '3', value: '3' },
    { name: '4', value: '4' },
    { name: '5', value: '5' },
    { name: '6', value: '6' },
    { name: '7', value: '7' },
    { name: '8', value: '8' },
    { name: '9', value: '9' },
    { name: '10', value: '10' }
  ];

  logIntervalOptions = [
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_INTERVAL.NO_ROTATION', value: '0' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_INTERVAL.ROTATE_TOP_HOUR', value: '1' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_INTERVAL.ROTATE_MIDNIGHT_AND_NOON', value: '2' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_INTERVAL.ROTATE_MIDNIGHT', value: '3' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_INTERVAL.ROTATE_SUNDAY_MIDNIGHT', value: '4' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_INTERVAL.ROTATE_1ST_AND_15TH', value: '5' },
    { name: 'logreaders.LOGREADER_FORM.OPTIONS.LOG_INTERVAL.ROTATE_1ST', value: '6' }
  ];

  sqlStatementParameterNames = [
    'TRACING_SQL_BASE_TBL_REF',
    'TRACING_SQL_SHADOW_TBL_REF',
    'TRACING_SQL_CONFLICT_DET_AND_RES',
    'TRACING_SQL_FROM_MESS_SYSTEM',
    'TRACING_SQL_ALL_OTHER_QUERIES',
    'TRACING_SQL_ROLLBACK_AND_COMMIT'
  ];

  miscellaneousParameterNames = ['TRACING_INC_MESS_NB', 'TRACING_MONITOR_STATS'];

  constructor(private readonly formBuilder: FormBuilder) {
    super();
  }

  ngOnInit(): void {
    this.createForm();
  }

  open(selectedLogReader?: LogReader): void {
    // add any functionality that you want to happen when the form is actually open
    this.usersExcludedFromCapture = [];
    if (selectedLogReader) {
      this.isEditing = true;
      this.logReader = selectedLogReader;
      if (this.sourceDataConnection.connectionType === 'DB2I') {
        this.logReaderFormGroup.controls.journals.disable();
      }
    } else {
      this.isEditing = false;
      if (this.sourceDataConnection.connectionType === 'DB2I') {
        this.logReaderFormGroup.controls.journals.enable();
      }
      this.resetForm();
    }
  }

  private createForm() {
    if (this.sourceDataConnection.connectionType === 'DB2I') {
      this.Db2ILogReaderForm();
    } else if (this.sourceDataConnection.connectionType === 'DB2') {
      this.Db2LogReaderForm();
    }
    this.initialFormGroupValue = this.logReaderFormGroup.value;
  }

  private Db2ILogReaderForm() {
    const defaultName = this.sourceDataConnection.connectionType === 'DB2' ? 'UDBCS1' : '';
    this.logReaderFormGroup = this.formBuilder.group(
      {
        journals: new FormControl('', [Validators.required]),
        name: new FormControl(defaultName, [Validators.required, Validators.maxLength(40)]),
        replicateClearPhysicalFile: new FormControl('false', [Validators.required]),
        dedicatedCaptureQueue: new FormControl('false', [Validators.required]),
        commitWaitTime: new FormControl('2', [Validators.required, Validators.min(1), Validators.max(100), Validators.pattern('^[0-9]*$')]),
        readerWaitTime: new FormControl('1', [Validators.required, Validators.min(0), Validators.max(600), Validators.pattern('^[0-9]*$')]),
        updateStatsFrequency: new FormControl('60', [
          Validators.required,
          Validators.min(1),
          Validators.max(60),
          Validators.pattern('^[0-9]*$')
        ]),
        messageCheckFrequency: new FormControl('20', [
          Validators.required,
          Validators.min(10),
          Validators.max(30),
          Validators.pattern('^[0-9]*$')
        ]),
        substituteForBinaryZero: new FormControl('', [Validators.maxLength(1)]),
        deleteJournalReceivers: new FormControl('true', [Validators.required]),
        keepUnsavedJournalReceiver: new FormControl('true', [Validators.required]),
        keepJournalReceivers: new FormControl('2', [
          Validators.required,
          Validators.min(0),
          Validators.max(999),
          Validators.pattern('^[0-9]*$')
        ]),
        tableInMetabase: new FormControl(this.tableInMetabaseOptions[1].value),
        console: new FormControl(this.consoleOptions[0].value),
        logFile: new FormControl(this.logFileOptions[1].value),
        maxLogMembersCreated: new FormControl(this.maxLogMembersCreatedOptions[9].value),
        logInterval: new FormControl(this.logIntervalOptions[3].value),
        logSize: new FormControl('10', [Validators.required, Validators.min(0), Validators.max(99), Validators.pattern('^[0-9]*$')]),
        sqlStatementOptions: new FormControl([]),
        miscellaneousOptions: new FormControl([this.miscellaneousParameterNames[0], this.miscellaneousParameterNames[1]])
      },
      {
        validators: [this.logReaderNameValidator()],
        updateOn: 'blur'
      }
    );
  }

  private Db2LogReaderForm() {
    const defaultName = this.sourceDataConnection.connectionType === 'DB2' ? 'UDBCS1' : '';
    this.logReaderFormGroup = this.formBuilder.group(
      {
        name: new FormControl(defaultName, [Validators.required, Validators.maxLength(40)]),
        tableInMetabase: new FormControl(this.tableInMetabaseOptions[1].value),
        console: new FormControl(this.consoleOptions[0].value),
        logFile: new FormControl(this.logFileOptions[1].value),
        sqlStatementOptions: new FormControl([]),
        miscellaneousOptions: new FormControl([this.miscellaneousParameterNames[0], this.miscellaneousParameterNames[1]])
      },
      {
        validators: [this.logReaderNameValidator()],
        updateOn: 'blur'
      }
    );
  }

  get logReader(): LogReader {
    const logReader = {} as LogReader;
    logReader.name = this.logReaderFormGroup.controls.name.value;

    if (this.sourceDataConnection.connectionType === 'DB2I') {
      logReader.journalName = this.logReaderFormGroup.controls.journals.value;
      logReader.parameters = [
        { key: 'REP_CLEAR_PF_MEMBER', value: this.logReaderFormGroup.controls.replicateClearPhysicalFile.value === 'true' ? 'Y' : 'N' },
        { key: 'DEDICATED_QUEUE', value: this.logReaderFormGroup.controls.dedicatedCaptureQueue.value === 'true' ? 'Y' : 'N' },
        { key: 'COMMIT_WAIT_TIME', value: this.logReaderFormGroup.controls.commitWaitTime.value },
        { key: 'READER_WAIT_TIME', value: this.logReaderFormGroup.controls.readerWaitTime.value },
        { key: 'UPDATE_STATS_FREQ', value: this.logReaderFormGroup.controls.updateStatsFrequency.value },
        { key: 'MESSAGE_CHECK_FREQ', value: this.logReaderFormGroup.controls.messageCheckFrequency.value },
        { key: 'SUBS_BIN_0', value: this.logReaderFormGroup.controls.substituteForBinaryZero.value },
        { key: 'DEL_JRN_RCV', value: this.logReaderFormGroup.controls.deleteJournalReceivers.value === 'true' ? 'Y' : 'N' },
        { key: 'KEEP_UNSAVED_JRN_RCV', value: this.logReaderFormGroup.controls.keepUnsavedJournalReceiver.value === 'true' ? 'Y' : 'N' },
        { key: 'KEEP_JRN_RCV', value: this.logReaderFormGroup.controls.keepJournalReceivers.value },
        { key: 'TRACING_TABLE', value: this.logReaderFormGroup.controls.tableInMetabase.value },
        { key: 'TRACING_CONSOLE', value: this.logReaderFormGroup.controls.console.value },
        { key: 'TRACING_LOG_FILE', value: this.logReaderFormGroup.controls.logFile.value },
        { key: 'TRACING_MAX_NB_LOG_CREATED', value: this.logReaderFormGroup.controls.maxLogMembersCreated.value },
        { key: 'TRACING_LOG_INTERVAL', value: this.logReaderFormGroup.controls.logInterval.value },
        { key: 'TRACING_LOG_SIZE', value: this.logReaderFormGroup.controls.logSize.value }
      ];
      if (this.usersExcludedFromCapture.length) {
        logReader.parameters.push({
          key: 'IBMI_EXCLUDED_USERS',
          value: this.usersExcludedFromCapture.join(',')
        });
      }
    } else if (this.sourceDataConnection.connectionType === 'DB2') {
      logReader.journalName = 'aba';
      logReader.parameters = [
        { key: 'TRACING_TABLE', value: this.logReaderFormGroup.controls.tableInMetabase.value },
        { key: 'TRACING_CONSOLE', value: this.logReaderFormGroup.controls.console.value },
        { key: 'TRACING_LOG_FILE', value: this.logReaderFormGroup.controls.logFile.value }
      ];
    }
    logReader.parameters = logReader.parameters.concat(this.sqlStatementParameters);
    logReader.parameters = logReader.parameters.concat(this.miscellaneousParameters);

    return logReader;
  }

  set logReader(selectedLogReader: LogReader) {
    this.logReaderFormGroup.controls.journals.setValue(selectedLogReader.journalName);
    this.logReaderFormGroup.controls.name.setValue(selectedLogReader.name);
    const parameters = selectedLogReader.parameters;
    parameters.forEach((property) => {
      switch (property.key) {
        case 'REP_CLEAR_PF_MEMBER':
          this.logReaderFormGroup.patchValue({ replicateClearPhysicalFile: property.value === 'Y' ? 'true' : 'false' });
          break;
        case 'DEDICATED_QUEUE':
          this.logReaderFormGroup.patchValue({ dedicatedCaptureQueue: property.value === 'Y' ? 'true' : 'false' });
          break;
        case 'COMMIT_WAIT_TIME':
          this.logReaderFormGroup.patchValue({ commitWaitTime: property.value });
          break;
        case 'READER_WAIT_TIME':
          this.logReaderFormGroup.patchValue({ readerWaitTime: property.value });
          break;
        case 'UPDATE_STATS_FREQ':
          this.logReaderFormGroup.patchValue({ updateStatsFrequency: property.value });
          break;
        case 'MESSAGE_CHECK_FREQ':
          this.logReaderFormGroup.patchValue({ messageCheckFrequency: property.value });
          break;
        case 'SUBS_BIN_0':
          this.logReaderFormGroup.patchValue({ substituteForBinaryZero: property.value });
          break;
        case 'DEL_JRN_RCV':
          const isDeleteJournalReceiversSet = property.value === 'Y' ? true : false;
          this.logReaderFormGroup.patchValue({ deleteJournalReceivers: isDeleteJournalReceiversSet.toString() });
          this.deleteJournalReceiversClicked(isDeleteJournalReceiversSet);
          break;
        case 'KEEP_UNSAVED_JRN_RCV':
          this.logReaderFormGroup.patchValue({ keepUnsavedJournalReceiver: property.value === 'Y' ? 'true' : 'false' });
          break;
        case 'KEEP_JRN_RCV':
          this.logReaderFormGroup.patchValue({ keepJournalReceivers: property.value });
          break;
        case 'TRACING_TABLE':
          this.logReaderFormGroup.patchValue({ tableInMetabase: property.value });
          break;
        case 'TRACING_CONSOLE':
          this.logReaderFormGroup.patchValue({ console: property.value });
          break;
        case 'TRACING_LOG_FILE':
          this.logReaderFormGroup.patchValue({ logFile: property.value });
          break;
        case 'TRACING_MAX_NB_LOG_CREATED':
          this.logReaderFormGroup.patchValue({ maxLogMembersCreated: property.value });
          break;
        case 'TRACING_LOG_INTERVAL':
          this.logReaderFormGroup.patchValue({ logInterval: property.value });
          break;
        case 'TRACING_LOG_SIZE':
          this.logReaderFormGroup.patchValue({ logSize: property.value });
          break;
        case 'IBMI_EXCLUDED_USERS':
          this.usersExcludedFromCapture = property.value.length === 0 ? [] : property.value.split(',');
          break;
      }
    });
    this.sqlStatementParameters = parameters;
    this.miscellaneousParameters = parameters;
  }

  onJournalChange(selectedJournal): void {
    if (!this.isEditing) {
      this.logReaderFormGroup.controls.name.setValue(selectedJournal);
    }
  }

  deleteJournalReceiversClicked(isDeletingJournalReceivers): void {
    if (isDeletingJournalReceivers) {
      this.logReaderFormGroup.controls.keepUnsavedJournalReceiver.enable();
      this.logReaderFormGroup.controls.keepJournalReceivers.enable();
    } else {
      this.logReaderFormGroup.controls.keepUnsavedJournalReceiver.disable();
      this.logReaderFormGroup.controls.keepJournalReceivers.disable();
    }
  }

  displayExcludeUsers(): void {
    this.excludeSidebarComponent.open();
  }

  isControlInvalid(controlName): boolean {
    const formControl = this.logReaderFormGroup.get(controlName);

    return formControl.invalid &&
      (formControl.dirty || formControl.touched) &&
      (formControl.errors.min || formControl.errors.max || formControl.errors.pattern)
      ? true
      : false;
  }

  filterJournals(event) {
    const query = event.query.toLowerCase();
    this.filteredJournals = this.journals.filter((journal) => journal.toLowerCase().indexOf(query) === 0);
  }

  resetForm(): void {
    let logReaderName;
    let journalName;

    if (this.isEditing) {
      logReaderName = this.logReaderFormGroup.controls.name.value;
      journalName = this.logReaderFormGroup.controls.journals.value;
    }
    this.logReaderFormGroup.reset(this.initialFormGroupValue);
    if (this.sourceDataConnection.connectionType === 'DB2I') {
      this.deleteJournalReceiversClicked(this.logReaderFormGroup.controls.deleteJournalReceivers.value);
    }
    if (this.isEditing) {
      this.logReaderFormGroup.controls.name.setValue(logReaderName);
      this.logReaderFormGroup.controls.journals.setValue(journalName);
    }
  }

  refreshJournalsClicked(): void {
    this.refreshClickEvent.emit();
  }

  private logReaderNameValidator() {
    return (formGroup: FormGroup) => {
      if (formGroup.controls.name.value.indexOf(' ') >= 0) {
        return { logreaderNameInvalid: true };
      }
      return null;
    };
  }

  private get sqlStatementParameters(): { key: string; value: string }[] {
    const parameters: { key: string; value: string }[] = [];
    const sqlStatementOptions = this.logReaderFormGroup.controls.sqlStatementOptions.value as any[];

    // TODO: Find out if we need to set the properties that are unchecked to "N", the API documentation
    // says that it will default to "N" if not set, but it currently defaults to "0" instead.
    // If it works as documented we can simplify this by just keekping the if with the commented line
    if (sqlStatementOptions.length) {
      this.sqlStatementParameterNames.forEach((parameterName) => {
        parameters.push({ key: parameterName, value: sqlStatementOptions.indexOf(parameterName) !== -1 ? 'Y' : 'N' });
      });
      // parameters = sqlStatementOptions.map(parameterName => ({ key: parameterName, value: "Y" }));
    } else {
      this.sqlStatementParameterNames.forEach((parameterName) => {
        parameters.push({ key: parameterName, value: 'N' });
      });
    }

    return parameters;
  }

  private set sqlStatementParameters(params) {
    const sqlStatementOptions = params.filter((d) => d.value === 'Y');
    this.logReaderFormGroup.get('sqlStatementOptions').setValue(sqlStatementOptions.map((d) => d.key));
  }

  private get miscellaneousParameters(): { key: string; value: string }[] {
    const parameters: { key: string; value: string }[] = [];
    const miscellaneousOptions = this.logReaderFormGroup.controls.miscellaneousOptions.value as any[];

    // TODO: Find out if we need to set the properties that are unchecked to "N", the API documentation
    // says that it will default to "N" if not set, but it currently defaults to "0" instead.
    // If it works as documented we can simplify this by just keekping the if with the commented line
    if (miscellaneousOptions.length) {
      this.miscellaneousParameterNames.forEach((parameterName) => {
        parameters.push({ key: parameterName, value: miscellaneousOptions.indexOf(parameterName) !== -1 ? 'Y' : 'N' });
      });
      // parameters = miscellaneousOptions.map(parameterName => ({ key: parameterName, value: "Y" }));
    } else {
      this.miscellaneousParameterNames.forEach((parameterName) => {
        parameters.push({ key: parameterName, value: 'N' });
      });
    }

    return parameters;
  }

  private set miscellaneousParameters(params) {
    const miscellaneousOptions = params.filter((d) => d.value === 'Y');
    this.logReaderFormGroup.get('miscellaneousOptions').setValue(miscellaneousOptions.map((d) => d.key));
  }
}
