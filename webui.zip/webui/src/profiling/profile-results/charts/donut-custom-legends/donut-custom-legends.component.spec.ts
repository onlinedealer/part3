import { TestBed } from '@angular/core/testing';
import { Spies } from 'discovery-test';
import { DonutCustomLegendsComponent } from './donut-custom-legends.component';

describe('DonutCustomLegendsComponent', () => {
  let component: DonutCustomLegendsComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DonutCustomLegendsComponent]
    }).compileComponents();
    component = new DonutCustomLegendsComponent(Spies.eventBusService, Spies.HttpUtilService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call ngOnInit', () => {
    component.legendDetails = ['Completeness', 'Null'];
    component.ngOnInit();
    expect(component.legendsData.length).toBeGreaterThanOrEqual(1);
  });
});
