import { AlertMetricModel } from 'alerts/alert-metric.model';
import { AlertConstants } from './alert-constants';

/**
 * This function will return values for chart based on show by percentage checkbox
 * we are returning some more info with it like criical color, alert raised on date,etc
 * @param showByPercentageData
 * @param metric
 * @param isShowPercentage
 * @returns
 */
export function showByPercentageCalculation(showByPercentageData, metric: AlertMetricModel, isShowPercentage: boolean) {
  let newValue = [];
  for (const data of showByPercentageData.values) {
    let pointsArray = [];
    data.value.forEach((point, index) => {
      pointsArray.push(Number(((point / showByPercentageData.trendTotalCountArray[index]) * 100).toFixed(2)));
    });
    newValue.push({
      label: data.label,
      value: pointsArray
    });
  }

  let values = isShowPercentage ? newValue : showByPercentageData.values;
  let criticality = metric.metricDetails[0].alertLevel;
  let criticalColor =
    AlertConstants.CRITICAL === criticality
      ? AlertConstants.HIGHLIGHT_COLOR.CRITICAL
      : AlertConstants.HIGHLIGHT_COLOR.WARNING;

  return {
    values: values,
    lables: showByPercentageData.labels,
    raisedOnDate: showByPercentageData.alertDate,
    criticalColor: criticalColor,
    isNew: showByPercentageData.isNew
  };
}
