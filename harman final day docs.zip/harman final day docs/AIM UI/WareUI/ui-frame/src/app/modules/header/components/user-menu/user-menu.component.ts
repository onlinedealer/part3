import { Component, EventEmitter, Output, Input, OnChanges, SimpleChanges, ViewChild } from "@angular/core";
import { BehaviorSubject } from "rxjs";
import { FormGroup, FormControl } from "@angular/forms";
import { HeaderData } from "../../common/header-data-provider";
import { MatMenuTrigger, MatMenu } from "@angular/material/menu";
import { TranslationsService } from "../../../../services/translations-service";

export interface UserMenuComponentChangeUiConfigurationSettingsPayload {
    systemLocale: string;
    userLocale?: string;
    dateFormat: { separator: string; format: string };
    timeFormat: string;
    hours: string;
    timeZoneInUse?: string;
}

export interface UserMenuComponentUiConfiguration {
    userLocale?: string;
    systemLocale: string;
    dateFormat: { separator: string; format: string };
    timeFormat: string;
    hours: string;
    timeZoneInUse?: string;
}

export interface UserMenuTimeZoneInformation {
    uamTimeZone: string;
    timeZoneInUse?: string;
    networkTimeZone: string;
    availableTimeZones: string[];
}
export interface LocaleDataChangeEvent {
    locale: string;
    timeZone: string;
}
/**
 * Component for user menu
 */
@Component({
    selector: "landisgyr-user-menu",
    templateUrl: "./user-menu.component.html",
    styleUrls: ["../../styles/component.styles.scss"]
})
export class UserMenuComponent implements OnChanges {
    @Input() public userInformation: any;
    @Input() public timeZoneInformation!: UserMenuTimeZoneInformation;
    @Input() headerData!: HeaderData;
    @Input() availableLanguages!: Array<{ code: string; name: string }>;

    /** Emitter for closing user menu */
    @Output() public userMenuOpenValue = new EventEmitter();
    @Output() localeChanged = new EventEmitter<string>();
    @Output() applySettingChanges = new EventEmitter<UserMenuComponentChangeUiConfigurationSettingsPayload>();
    @Output() logout = new EventEmitter();

    @ViewChild(MatMenu, { static: true }) menu!: MatMenu;
    /** Boolean for user menu settings part */
    settingsOpen = false;
    menuOpen = new BehaviorSubject(false);
    userTimeZone!: string;
    localTimeZone!: string;
    otherTimeZonesText = "";
    localTimeZoneQuessedName!: string;
    public settingsChanged = false;

    formGroup = new FormGroup({
        userLocale: new FormControl(),
        dateFormat: new FormControl(),
        timeFormat: new FormControl(),
        hours: new FormControl(),
        timeZoneInUse: new FormControl()
    });

    constructor(public translations: TranslationsService) {
        this.otherTimeZonesText = this.translations.getTranslation("timeZonesOthers");
        this.formGroup.valueChanges.subscribe((values: any) => {
            this.settingsChanged = true;
            this.userTimeZone = values.timeZoneInUse;
        });
    }

    getChangePasswordURL() {
        const changePasswordUrl = window.location.protocol + "//" + window.location.host + "/AIMUI";
        const appUrl = window.location.protocol + "//" + window.location.host + "/AIMUI";

        return changePasswordUrl + "/changePassword?successUrl=" + appUrl;
    }

    ngOnChanges(changes: SimpleChanges) {
        this.assignInitialFormValues();
    }

    assignInitialFormValues() {
        const useValue = {
            userLocale: this.headerData.currentLocale,
            dateFormat: this.headerData.uiConfiguration.dateFormat.format || ("DD/MM/YYYY" as any),
            timeFormat: this.headerData.uiConfiguration.timeFormat,
            hours: this.headerData.uiConfiguration.hours,
            timeZoneInUse: this.formGroup.value.timeZoneInUse || this.headerData.uiConfiguration.timeZoneInUse
        };
        this.userTimeZone = useValue.timeZoneInUse;
        this.localTimeZoneQuessedName = this.headerData.localTimeZoneQuessedName;
        this.formGroup.setValue(useValue, { emitEvent: false });
    }

    openUserMenu() {
        this.settingsOpen = false;
    }

    /**
     * Open or close user settings tab
     */
    public openCloseSettings() {
        if (this.settingsOpen) {
            this.assignInitialFormValues();
        }
        this.settingsOpen = !this.settingsOpen;
    }

    /*
     * Apply setting changes
     */
    public applyChanges(menuTrigger: MatMenuTrigger) {
        menuTrigger.closeMenu();
        const useValue = { ...this.formGroup.value };
        useValue.dateFormat = this.headerData.uiDateConfigurationsAvailable.get(this.formGroup.value.dateFormat);
        this.applySettingChanges.emit(useValue);
        this.settingsOpen = false;
        this.userMenuOpenValue.emit(false);
    }
}
