(function () {
    'use strict';

    angular.module('arm').controller('productCtrl',
                ['$scope', '$state', '$filter', '$ionicModal', '$ionicSideMenuDelegate', 'productService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', '$cordovaFile', '$window', '$timeout', productCtrl]);

    function productCtrl($scope, $state, $filter, $ionicModal, $ionicSideMenuDelegate, productService, utility, MASTER_TABLE, GENERAL_CONFIG, $cordovaFile, $window, $timeout) {
        $scope.title = 'Product List'
        $scope.productList = [];

        productService.getProductFamily().then(function (productFamilyRes) {
            console.log('Product Family Response is'+JSON.stringify(productFamilyRes));
            //$scope.productList = productFamilyRes;
            productService.sqlProductFamilyAdd(productFamilyRes).then(function(repDetailsResult){
                    productService.sqlProductsAdd(productFamilyRes).then(function(repDetailsResult){
                        productService.sqlProductAttachmentsAdd(productFamilyRes).then(function(repDetailsResult){
                            productService.sqlGetAllProductFamily(productFamilyRes).then(function(productFamilySqlRes){
                                     for (var i = 0; i < productFamilySqlRes.rows.length; i++) {
                                        $scope.productList[i] = productService.productFamilyMod().uiObject;
                                        $scope.productList[i] = utility.syncModelWithCollection(productFamilySqlRes.rows.item(i), $scope.productList[i]);
                                        productService.sqlGetAllProducts(productFamilySqlRes.rows.item(i),i).then(function(productSqlRes){
                                               for(var j=0;j<productSqlRes[1].rows.length;j++){
                                                    $scope.productList[productSqlRes[0]].Products[j] = productService.productMod().uiObject;
                                                    $scope.productList[productSqlRes[0]].Products[j] = utility.syncModelWithCollection(productSqlRes[1].rows.item(j), $scope.productList[productSqlRes[0]].Products[j]);
                                                    productService.sqlGetAllAttachments(productSqlRes[1].rows.item(j),productSqlRes[0], j).then(function(attachmentsSqlRes){
                                                        for(var k=0;k<attachmentsSqlRes[2].rows.length;k++){
                                                             $scope.productList[attachmentsSqlRes[0]].Products[attachmentsSqlRes[1]].Attachments[k] = productService.productAttachmentMod().uiObject;
                                                             $scope.productList[attachmentsSqlRes[0]].Products[attachmentsSqlRes[1]].Attachments[k] = utility.syncModelWithCollection(attachmentsSqlRes[2].rows.item(k), $scope.productList[attachmentsSqlRes[0]].Products[attachmentsSqlRes[1]].Attachments[k]);
                                                             if((attachmentsSqlRes[2].rows.item(k).FilePath == "" || attachmentsSqlRes[2].rows.item(k).FilePath == null) && attachmentsSqlRes[2].rows.item(k).AttachmentCategoryID == 1){
                                                                $scope.productList[attachmentsSqlRes[0]].Products[attachmentsSqlRes[1]].FilePathToDisplay = cordova.file.cacheDirectory + "productImages/"+attachmentsSqlRes[2].rows.item(k).AttachmentID+'.png' + '?' + new Date().getTime();
                                                             productService.getAttachments(attachmentsSqlRes[2].rows.item(k).AttachmentID).then(function (productAttachmentsRes) {

                                                                // If your base64 string contains "data:image/png;base64,"" at the beginning, keep reading.
                                                                var myBase64 = productAttachmentsRes.Base64String;
                                                                // To define the type of the Blob
                                                                var contentType = "image/png";
                                                                // if cordova.file is not available use instead :
                                                                // var folderpath = "file:///storage/emulated/0/";
                                                                var filename = productAttachmentsRes.AttachmentID+'.png';
                                                                var folderpath = cordova.file.cacheDirectory + "productImages";

                                                                var filePath = folderpath+"/"+filename;

                                                                utility.savebase64AsImageFile(folderpath,filename,myBase64,contentType,"productImages");

                                                                productService.sqlUpdateAttachmentPath(filePath,productAttachmentsRes.AttachmentID).then(function(updateAttachmentSqlRes){

                                                                },function (err) {
                                                                    //console.log('product family error'+err);
                                                                });

                                
                                                            },function (err) {
                                                            //console.log('product family error'+err);
                                                            });
                                                          }

                                                        }

                                                    },function(err){
                                                        alert(err);
                                                    });
                                               }
                                            },function(err){
                                                alert(err);
                                            });

                                     }
                                },function(err){
                                    alert(err);
                                });
                            },function(err){
                                alert(err);
                            });
                       },function(err){
                         alert(err);
                       });
            },function(err){
                alert(err);
            });
        },function (err) {
                //console.log('product family error'+err);
        });

        $scope.productsdetail = function (productId) {
            utility.busyCursorStart();
            for(var i=0;i<$scope.productList.length;i++){
                for(var j=0;j<$scope.productList[i].Products.length;j++){
                    if($scope.productList[i].Products[j].ProductID == productId){
                        productService.setSelectedProduct($scope.productList[i].Products[j]);
                        if($scope.productList[i].Products[j].Attachments.length == 0){
                            $state.go('tab.productDetail', {productId: productId});
                        }else{
                        for(var k=0;k<$scope.productList[i].Products[j].Attachments.length;k++){
                            if(($scope.productList[i].Products[j].Attachments[k].FilePath == "" || $scope.productList[i].Products[j].Attachments[k].FilePath == null) && $scope.productList[i].Products[j].Attachments[k].AttachmentCategoryID == 2){
                                productService.getAttachments($scope.productList[i].Products[j].Attachments[k].AttachmentID).then(function (productAttachmentsRes) {

                                    // If your base64 string contains "data:image/png;base64,"" at the beginning, keep reading.
                                    var myBase64 = productAttachmentsRes.Base64String;
                                    // To define the type of the Blob
                                    var contentType = "image/png";
                                    // if cordova.file is not available use instead :
                                    // var folderpath = "file:///storage/emulated/0/";
                                    var filename = productAttachmentsRes.AttachmentID+'.png';
                                    var folderpath = cordova.file.cacheDirectory + "productImages";

                                    var filePath = folderpath+"/"+filename;

                                    utility.savebase64AsImageFile(folderpath,filename,myBase64,contentType,"productImages");

                                    productService.sqlUpdateAttachmentPath(filePath,productAttachmentsRes.AttachmentID).then(function(updateAttachmentSqlRes){

                                    },function (err) {
                                        //console.log('product family error'+err);
                                    });

                                
                                },function (err) {
                                //console.log('product family error'+err);
                                });
                            }
                            if(k == ($scope.productList[i].Products[j].Attachments.length)-1){
                                $timeout(function () {
                                    $state.go('tab.productDetail', {productId: productId});
                                }, 3000);
                            }
                        }
                      }
                    }
                }
            }
        }

        $scope.toggleGroup = function (group) {
            group.show = !group.show;
            for(var i=0;i<$scope.productList.length;i++){
                for(var j=0;j<$scope.productList[i].Products.length;j++){
                    for(var k=0;k<$scope.productList[i].Products[j].Attachments.length;k++){
                        if($scope.productList[i].Products[j].Attachments[k].AttachmentCategoryID == 1){
                            $scope.productList[i].Products[j].FilePathToDisplay = cordova.file.cacheDirectory + "productImages/"+$scope.productList[i].Products[j].Attachments[k].AttachmentID+'.png' + '?' + new Date().getTime();
                        }
                    }
                }
            }
        };

        $scope.isGroupShown = function (group, index) {
            if(index == 0){
                return group.show;
            }else{
                return !group.show;
            }
        };


    };

})();