import { TestBed, inject } from '@angular/core/testing';

import { UrlMakerService } from './url-maker.service';

describe('UrlMakerService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [UrlMakerService]
    });
  });

  it('should be created', inject([UrlMakerService], (service: UrlMakerService) => {
    expect(service).toBeTruthy();
  }));
});
