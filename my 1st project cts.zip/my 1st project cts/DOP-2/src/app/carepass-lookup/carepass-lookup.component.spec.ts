import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CarepassLookupComponent } from './carepass-lookup.component';

describe('CarepassLookupComponent', () => {
  let component: CarepassLookupComponent;
  let fixture: ComponentFixture<CarepassLookupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CarepassLookupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CarepassLookupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
