import { Directive, HostListener, ElementRef } from '@angular/core'

@Directive({
  selector: '[appStickyScroll]'
})
export class StickyScrollDirective {

  constructor(private el: ElementRef) { 
    this.leftNav = this.el.nativeElement
  }

  leftNav;

  @HostListener('window:scroll', ['event']) scroll(event) {
    if (window.pageYOffset > 230) {
       this.leftNav = this.el.nativeElement
       this.leftNav.classList.add('sticky')
    } else {
       this.leftNav = this.el.nativeElement
       this.leftNav.classList.remove('sticky')
    }
  }

  ngOnInit() { }

}
