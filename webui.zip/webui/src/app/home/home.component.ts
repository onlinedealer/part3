import { Component } from '@angular/core';
import { ConnectionsStatesModel } from 'discovery-shared';
import { FirstTimeUserService } from 'app/first-time-user.service';
import { HttpUtilService } from '@precisely/prism-ng/cloud';

@Component({
  selector: 'discovery-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  /**
   *
   */
  returnedUser: boolean = false;

  /**
   *
   */
  ConnectionsStatesModel: typeof ConnectionsStatesModel = ConnectionsStatesModel;

  constructor(public firstTimeUserService: FirstTimeUserService, public httpUtil: HttpUtilService) {}
}
