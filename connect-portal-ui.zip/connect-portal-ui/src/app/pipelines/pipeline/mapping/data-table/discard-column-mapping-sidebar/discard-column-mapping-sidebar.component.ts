import { ChangeDetectorRef, Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';

@Component({
  selector: 'p-connect-discard-column-mapping-sidebar',
  templateUrl: './discard-column-mapping-sidebar.component.html',
  styleUrls: ['./discard-column-mapping-sidebar.component.scss']
})
export class DiscardColumnMappingSidebarComponent {
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @Output() discardClicked = new EventEmitter<any>();
  rowData: any;
  constructor() {}

  cancelButton: SidebarButton = {
    id: 'cancelButton',
    text: 'pipelines.STAGES.MAPPING.DISCARD_COLUMN_MAPPING.BUTTONS.CANCEL_BUTTON'
  };
  discardButton: SidebarButton = {
    id: 'discardButton',
    text: 'pipelines.STAGES.MAPPING.DISCARD_COLUMN_MAPPING.BUTTONS.DISCARD_BUTTON'
  };

  open(row: any) {
    this.sidebarComponent.open();
    this.rowData = row;
  }

  primaryButtonClicked() {
    this.discardClicked.emit(this.rowData);
    this.sidebarComponent.close();
  }

  cancelButtonClicked() {
    this.close();
  }
  close() {
    this.sidebarComponent.close();
  }
}
