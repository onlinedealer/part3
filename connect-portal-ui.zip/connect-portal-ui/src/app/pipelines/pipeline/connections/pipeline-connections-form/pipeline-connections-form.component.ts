import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { FeatureFlagService } from 'src/app/shared/services/feature-flag.service';
import { Observable, of } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { environment } from '../../../../../environments/environment';
import { Connection } from '../../../../connections/shared/connection';
import { ConnectionsApiService } from '../../../../connections/shared/connections-api.service';
import { BaseComponent } from '../../../../core/base.component';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { Pipeline, PIPELINE_ENTITY_TYPE, SourceConnectionInfo, TargetConnectionInfo } from '../../shared/pipeline';
import { ProgressIndicatorStateService } from '@shared/components/progress-indicator/progress-indicator-state.service';
import { PipelineService } from '../../pipeline.service';

@Component({
  selector: 'p-connect-pipeline-connections-form',
  templateUrl: './pipeline-connections-form.component.html'
})
export class PipelineConnectionsFormComponent extends BaseComponent implements OnInit, OnChanges {
  /**
   * Controls the visibility of the connection side bar component
   */
  isConnectionSidebarVisible = false;

  /**
   * List of supported connection types that is passed to the connection sidebar component;
   */
  supportedConnectionTypes: string[] = [];

  /**
   * List of existing source connections
   */
  sourceDataConnections: { label: string; value: Connection }[] = [];

  /**
   * List of existing target connections
   */
  targetDataConnections: { label: string; value: Connection }[] = [];

  connectionsFormGroup: FormGroup;

  sourceCatalogStatus: CatalogStatus = null;

  targetCatalogStatus: CatalogStatus = null;

  loader: boolean = false;

  catalogConnectionList: Connection[] = [];

  /**
   * The list of supported source connection types for the pipeline, default is all as set in the the environment property
   */
  @Input() visibleConnectionTypes: { connectionType: string; accessMethods: string[] }[] = environment.supportedSourceConnectionTypes;

  /**
   * The list of supported target connection types for the pipeline, default is only kafka in the environment property
   */
  @Input() visibleTargetConnectionTypes: { connectionType: string; accessMethods: string[] }[] = environment.supportedTargetConnectionTypes;

  /**
   * selected source connection
   */
  @Input() selectedSourceConnection: Connection;

  /**
   * selected target connection
   */
  @Input() selectedTargetConnection: Connection;

  /**
   * Event when an item is selected from the source dropdown
   */
  @Output() sourceConnectionSelectedEvent = new EventEmitter<Connection>();

  /**
   * Event when an item is selected from the target dropdown
   */
  @Output() targetConnectionSelectedEvent = new EventEmitter<Connection>();

  readonly PIPELINE_TYPE = PIPELINE_ENTITY_TYPE;

  constructor(
    private readonly connectionsService: ConnectionsApiService,
    private readonly catalogApiService: CatalogApiService,
    private readonly controlContainer: ControlContainer,
    private readonly featureFlagService: FeatureFlagService,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly progressIndicatorState: ProgressIndicatorStateService,
    private readonly pipelineService: PipelineService
  ) {
    super();
  }

  ngOnInit(): void {
    this.createForm();
    if (this.pipelineType === this.PIPELINE_TYPE.REPLICATION) {
      this.supportedConnectionTypes = this.visibleConnectionTypes.map((connection) => connection.connectionType);
      this.getConnections().subscribe({
        next: (connections: Connection[]) => {
          this.setSourceConnections(connections);
          this.setTargetConnections(connections);
          this.setDefaultSelectedConnections();
        }
      });
    } else {
      this.loader = true;
    }
  }

  setCatalogConnectionList(connectionList: Connection[]) {
    this.catalogConnectionList = connectionList;
    if (this.pipelineType === this.PIPELINE_TYPE.SCHEDULED) {
      const pipeline: Pipeline = this.pipelineEntityService.getPipeline();
      if (pipeline.source?.dataConnection || pipeline.target?.dataConnection) {
        this.connectionsFormGroup.controls.sourceConnection.setValue(pipeline.source?.dataConnection);
        this.connectionsFormGroup.controls.targetConnection.setValue(pipeline.target?.dataConnection);
        this.loader = false;
      } else if (pipeline.sourceDataConnectionId || pipeline.targetDataConnectionId) {
        const sourceConnection = this.catalogConnectionList.find((catalogConnection) => {
          return catalogConnection.id === pipeline.sourceDataConnectionId;
        });
        const targetConnection = this.catalogConnectionList.find((catalogConnection) => {
          return catalogConnection.id === pipeline.targetDataConnectionId;
        });
        this.updateSourceConnectionForScheduledPipeline(sourceConnection);
        this.updateTargetConnectionForScheduledPipeline(targetConnection);
      } else {
        this.updateSourceConnectionForScheduledPipeline(this.catalogConnectionList[0]);
        this.updateTargetConnectionForScheduledPipeline(this.catalogConnectionList[0]);
      }
    }
  }

  get pipelineType(): string {
    return this.pipelineEntityService.pipelineEntityType;
  }

  set pipelineType(val) {
    this.pipelineEntityService.pipelineEntityType = val;
  }

  ngOnChanges(changes: SimpleChanges) {
    if (this.pipelineType !== this.PIPELINE_TYPE.SCHEDULED) {
      if (this.selectedSourceConnection) {
        const connection = this.sourceDataConnections.find((d) => d.value.id === this.selectedSourceConnection.id);
        this.connectionsFormGroup.get('sourceConnection').setValue(connection.value);
        this.getSelectedConnectionCatalogStatus(
          connection.value,
          this.sourceDataConnections[0].value,
          this.addCatalogStatusToSourceConnection.bind(this)
        );
      }
      if (this.selectedTargetConnection) {
        const connection = this.targetDataConnections.find((d) => d.value.id === this.selectedTargetConnection.id);
        this.connectionsFormGroup.get('targetConnection').setValue(connection.value);
        this.getSelectedConnectionCatalogStatus(
          connection.value,
          this.targetDataConnections[0].value,
          this.addCatalogStatusToTargetConnection.bind(this)
        );
      }
    }
  }

  addSourceConnection(): void {
    this.supportedConnectionTypes = this.visibleConnectionTypes.map((connection) => connection.connectionType);
    this.isConnectionSidebarVisible = true;
  }

  addTargetConnection(): void {
    this.supportedConnectionTypes = this.visibleTargetConnectionTypes.map((connection) => connection.connectionType);
    this.isConnectionSidebarVisible = true;
  }

  /**
   * Adds the new connection to the connections list
   * @param newConnection the new connection to add to the connection list
   */
  onConnectionSavedEvent(newConnection: { id: string }) {
    this.getConnections().subscribe({
      next: (connections: Connection[]) => {
        const connection = connections.find((d) => d.id === newConnection.id);

        // is this a source connection?
        const isSourceConnection = this.visibleConnectionTypes.some(
          (visibleConnectionType) =>
            visibleConnectionType.connectionType === connection.connectionType &&
            (visibleConnectionType.accessMethods.indexOf(connection.accessMethod) !== -1 || !connection.accessMethod)
        );

        if (isSourceConnection) {
          this.sourceDataConnections.push({ label: connection.name, value: connection });
          this.connectionsFormGroup
            .get('sourceConnection')
            .setValue(this.sourceDataConnections.find((connection) => connection.value.id === newConnection.id).value);
          this.sourceConnectionSelectedEvent.emit(this.connectionsFormGroup.get('sourceConnection').value);
          // A newly created data connection (at this point) will not have any schemas/topics/subjects or tables cataloged.
          this.sourceCatalogStatus = null;
        } else {
          this.targetDataConnections.push({ label: connection.name, value: connection });
          this.connectionsFormGroup
            .get('targetConnection')
            .setValue(this.targetDataConnections.find((connection) => connection.value.id === newConnection.id).value);
          this.targetConnectionSelectedEvent.emit(this.connectionsFormGroup.get('targetConnection').value);
          // A newly created data connection (at this point) will not have any schemas/topics/subjects or tables cataloged.
          this.targetCatalogStatus = null;
        }
      }
    });
  }

  /**
   * Event handler for the newly selected source connection in dropdown for replication pipeline
   * @param event
   */
  onSourceConnectionValueChange(connectionValue) {
    this.loader = true;
    this.clearSelectedTablesIfConnectionChanged();
    if (this.sourceDataConnections.some((connection) => connection.value.id === connectionValue.id)) {
      this.sourceConnectionSelectedEvent.emit(connectionValue);
      const newSelectedSourceConnection = this.sourceDataConnections.find((connection) => connection.value.id === connectionValue.id);
      this.addCatalogStatusToSourceConnection(connectionValue);
    }
  }

  /**
   * Clear selected tables when source data connection is changed
   */
  clearSelectedTablesIfConnectionChanged() {
    const pipeline: Pipeline = this.pipelineEntityService.getPipeline();
    pipeline.source.selectedTables = [];
    this.progressIndicatorState.setIsValid(2, false);
  }

  /**
   * Event handler for the newly selected target connection in dropdown for replication pipeline
   * @param event
   */
  onTargetConnectionValueChange(connectionValue) {
    this.loader = true;
    if (this.targetDataConnections.some((connection) => connection.value.id === connectionValue.id)) {
      this.targetConnectionSelectedEvent.emit(connectionValue);
      const newSelectedTargetConnection = this.targetDataConnections.find((connection) => connection.value.id === connectionValue.id);
      this.addCatalogStatusToTargetConnection(newSelectedTargetConnection.value);
    }
  }

  /**
   * Function fetches latest catalog status of source/target connection from manage catalog
   */
  updateConnectionCatalogStatus(catalogStatus: CatalogStatus): void {
    if (this.sourceDataConnections.some((connection) => connection.value.id === catalogStatus.connectionId)) {
      this.sourceCatalogStatus = catalogStatus;
    } else if (this.targetDataConnections.some((connection) => connection.value.id === catalogStatus.connectionId)) {
      this.targetCatalogStatus = catalogStatus;
    }
  }
  /**
   * It updates the source connection details of the scheduled pipeline
   * @param details  {{Connection}}
   */
  updateSourceConnectionForScheduledPipeline(connectionInfo: Connection): void {
    if (connectionInfo) {
      this.connectionsFormGroup.get('sourceConnection').setValue(connectionInfo);
      const source: SourceConnectionInfo = {
        dataConnection: connectionInfo
      };
      this.pipelineEntityService.patchPipeline({ source: source });
      this.pipelineService.savePipeline();
      this.loader = false;
    }
  }
  /**
   * It updates the target connection details of the scheduled pipeline
   * @param details {{Connection}}
   */
  updateTargetConnectionForScheduledPipeline(connectionInfo: Connection): void {
    if (connectionInfo) {
      this.connectionsFormGroup.get('targetConnection').setValue(connectionInfo);
      const target: TargetConnectionInfo = {
        dataConnection: connectionInfo
      };
      this.pipelineEntityService.patchPipeline({ target: target });
      this.pipelineService.savePipeline();
      this.loader = false;
    }
  }

  private readonly createForm = (): void => {
    this.connectionsFormGroup = this.controlContainer.control as FormGroup;
    this.connectionsFormGroup.addControl('sourceConnection', new FormControl('', Validators.required));
    this.connectionsFormGroup.addControl('targetConnection', new FormControl('', Validators.required));
  };

  private getConnections(): Observable<Connection[]> {
    return this.connectionsService.getAll();
  }

  /**
   * Retrieves the catalog status for the source connection
   * @param connection the connection to get the catalog status for
   */
  private async addCatalogStatusToSourceConnection(connection: Connection) {
    return await this.catalogApiService
      .status(connection.id, true)
      .pipe(
        catchError(() => {
          this.loader = false;
          this.sourceDataConnections.find((d) => d.value.id === connection.id).value.catalogStatus = null;
          this.sourceCatalogStatus = null;
          return of(null);
        }),
        map((catalogStatus: CatalogStatus) => {
          this.loader = false;
          this.sourceDataConnections.find((d) => d.value.id === connection.id).value.catalogStatus = catalogStatus;
          this.sourceCatalogStatus = catalogStatus;
        })
      )
      .toPromise();
  }

  /**
   * Retrieves the catalog status for the target connection
   * @param connection the connection to get the catalog status for
   */
  private async addCatalogStatusToTargetConnection(connection: Connection) {
    return await this.catalogApiService
      .status(connection.id, true)
      .pipe(
        catchError(() => {
          this.loader = false;
          this.targetDataConnections.find((d) => d.value.id === connection.id).value.catalogStatus = null;
          this.targetCatalogStatus = null;
          return of(null);
        }),
        map((catalogStatus: CatalogStatus) => {
          this.loader = false;
          this.targetDataConnections.find((d) => d.value.id === connection.id).value.catalogStatus = catalogStatus;
          this.targetCatalogStatus = catalogStatus;
        })
      )
      .toPromise();
  }

  /**
   * Filter source connections in the same way as we filter target connection.
   */
  private setSourceConnections(connections: Connection[]): void {
    this.sourceDataConnections = connections
      .filter((connection) => {
        if (
          this.visibleConnectionTypes.find(
            (obj) =>
              obj.connectionType === connection.connectionType &&
              (obj.accessMethods.indexOf(connection.accessMethod) !== -1 || !connection.accessMethod)
          )
        ) {
          return connection;
        }
      })
      .map((connection) => ({
        label: connection.name,
        value: connection
      }));
  }

  private setTargetConnections(connections: Connection[]): void {
    this.targetDataConnections = connections
      .filter((connection) => {
        if (
          this.visibleTargetConnectionTypes.find(
            (obj) =>
              obj.connectionType === connection.connectionType &&
              (obj.accessMethods.indexOf(connection.accessMethod) !== -1 || !connection.accessMethod)
          )
        ) {
          return connection;
        }
      })
      .map((connection) => ({
        label: connection.name,
        value: connection
      }));
  }

  private readonly setDefaultSelectedConnections = (): void => {
    if (this.sourceDataConnections.length > 0) {
      this.connectionsFormGroup.get('sourceConnection').setValue(this.sourceDataConnections[0].value);
      this.sourceConnectionSelectedEvent.emit(this.connectionsFormGroup.get('sourceConnection').value);
      this.addCatalogStatusToSourceConnection(this.sourceDataConnections[0].value);
    }
    if (this.targetDataConnections.length > 0) {
      this.connectionsFormGroup.get('targetConnection').setValue(this.targetDataConnections[0].value);
      this.targetConnectionSelectedEvent.emit(this.connectionsFormGroup.get('targetConnection').value);
      this.addCatalogStatusToTargetConnection(this.targetDataConnections[0].value);
    }
  };

  /**
   * Fetches catalog status of data connection selected in dropdown
   */
  private getSelectedConnectionCatalogStatus(
    selectedDataConnection: Connection,
    currentDataConnection: Connection,
    getCatalogStatusForConnection: any
  ) {
    if (selectedDataConnection.id !== currentDataConnection.id) {
      getCatalogStatusForConnection(selectedDataConnection);
    }
  }
}
