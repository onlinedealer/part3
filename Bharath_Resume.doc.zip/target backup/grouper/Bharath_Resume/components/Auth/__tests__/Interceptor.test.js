import axios from 'axios'
import AxiosMockAdapter from 'axios-mock-adapter'
import React from 'react'
import { shallow } from 'enzyme'
import { Interceptor } from '../Interceptor'

describe('Interceptor component', () => {
  const axiosMock = new AxiosMockAdapter(axios)
  const wrapper = shallow(<Interceptor />)
  const url = 'https://praxis-dev.us-central-1.test.core.k8s.tgt/'
  axiosMock.onGet(`${url}200`).reply(200)
  axiosMock.onGet('http://www.example.com/200').reply(200)
  axiosMock.onGet(`${url}200`).reply(200)
  axiosMock.onGet(`${url}401`).reply(401)
  axiosMock.onGet(`${url}403`).reply(403)
  axiosMock.onGet(`${url}500`).reply(500)

  it('adds Authorization header with value of accessToken', done => {
    wrapper.setProps({accessToken: 'testToken'})
    axios.get(`${url}200`).then(response => {
      expect(response.config.headers.Authorization).toEqual('testToken')
      done()
    })
  })

  it('allow config to override Authorization header', done => {
    wrapper.setProps({accessToken: 'testTokenConfig'})
    axios.get(`${url}200`, {headers: {Authorization: 'testTokenOverride'}}).then(response => {
      expect(response.config.headers.Authorization).toEqual('testTokenOverride')
      done()
    })
  })

  it('allow config to disable Authorization header', done => {
    wrapper.setProps({accessToken: 'testTokenDisable'})
    axios.get(`${url}200`, {headers: {Authorization: false}}).then(response => {
      expect(response.config.headers.hasOwnProperty('Authorization')).toBe(false)
      done()
    })
  })

  it('no Authorization header if not a Target domain', done => {
    wrapper.setProps({accessToken: 'testTokenDomain'})
    axios.get('http://www.example.com/200').then(response => {
      expect(response.config.headers.hasOwnProperty('Authorization')).toBe(false)
      done()
    })
  })

  it('no Authorization header if no accessToken', done => {
    wrapper.setProps({accessToken: undefined})
    axios.get(`${url}200`).then(response => {
      expect(response.config.headers.hasOwnProperty('Authorization')).toBe(false)
      done()
    })
  })

  it('401 calls promptToSignIn', done => {
    const promptToSignIn = jest.fn()
    wrapper.setProps({
      accessToken: 'testToken401',
      promptToSignIn,
    })
    axios.get(`${url}401`).catch(() => {
      expect(promptToSignIn).toHaveBeenCalledTimes(1)
      done()
    })
  })

  it('403 calls showNotification', done => {
    const showNotification = jest.fn()
    wrapper.setProps({
      accessToken: 'testToken403',
      showNotification,
    })
    axios.get(`${url}403`).catch(() => {
      expect(showNotification).toHaveBeenCalledTimes(1)
      done()
    })
  })

  it('generic error calls showNotification', done => {
    const showNotification = jest.fn()
    wrapper.setProps({
      accessToken: 'testToken500',
      showNotification,
    })
    axios.get(`${url}500`).catch(() => {
      expect(showNotification).toHaveBeenCalledTimes(1)
      done()
    })
  })

  it('removes interceptors on unmount', done => {
    wrapper.unmount()
    axiosMock.onGet().reply(200)
    axios.get(`${url}200`).then(response => {
      expect(response.config.headers.Authorization).toEqual(undefined)
      done()
    })
  })

  describe('#isTargetDomain', () => {
    const isTargetDomain = wrapper.instance().isTargetDomain
    it('yes .target.com', () => {
      expect(isTargetDomain('https://test.target.com')).toBe(true)
    })
    it('yes .tgt', () => {
      expect(isTargetDomain('scheme:///test.tgt:80/test')).toBe(true)
    })
    it('no .target.com.ru', () => {
      expect(isTargetDomain('https://test.target.com.ru')).toBe(false)
    })
    it('no .tgtx', () => {
      expect(isTargetDomain('https://test.tgtx')).toBe(false)
    })
  })
})
