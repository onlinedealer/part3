import { Directive, ElementRef, Output, EventEmitter } from "@angular/core";

@Directive({
    selector: "[landisgyrClickOutside]",
    host: {
        "(document:click)": "onClick($event)"
    }
})
export class ClickOutsideDirective {
    @Output()
    clickedOutside = new EventEmitter<"outside" | "icon">();
    constructor(private elementRef: ElementRef) {}
    onClick(event: any) {
        if (typeof event.target.className === "string") {
            if (!this.elementRef.nativeElement.contains(event.target) && !event.target.className.includes("filter-input")) {
                this.clickedOutside.emit("outside");
            }
        }
    }
}
