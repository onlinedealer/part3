import {
    Component,
    Input,
    ChangeDetectionStrategy,
    Output,
    EventEmitter,
    OnChanges,
    ChangeDetectorRef,
    SimpleChanges
} from "@angular/core";
import { TranslationsService } from "../../../../../app/services/translations-service";
import { ValuesForTable } from "../../../../models/view-objects/summarytable-vo.model";

@Component({
    selector: "landisgyr-prepayment-chart-view",
    templateUrl: "./prepayment-chart-view.component.html",
    styleUrls: ["./prepayment-chart-view.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrepaymentChartViewComponent implements OnChanges {
    @Input() prepaymentInfoExpanded!: boolean;

    @Input() viewName!: boolean;

    @Input() chartDataGrouping: any;

    @Input() chartDataAvailableGroupingOptions: any;

    @Input() chartData: any;

    @Input() scales!: any[];

    @Input() loading!: boolean;

    @Input() tableDataForLength!: ValuesForTable[];

    @Output() chartDataGroupingSelection = new EventEmitter<string>();

    noDataMessage = this.translations.getTranslation("No data available for the selected time period");

    selectedValue!: string;
    reRendering = false;

    colorScheme: { name: string; selectable: boolean; group: string; domain: string[] } = {
        name: "coolthree",
        selectable: true,
        group: "Ordinal",
        domain: ["#42a340"]
    };
    colorSchemeTooltip: { name: string; selectable: boolean; group: string; domain: string[] } = {
        name: "coolthree",
        selectable: true,
        group: "Ordinal",
        domain: ["#42a340"]
    };

    leftYaxisColors = ["#42a340"];
    rightYaxisColors = ["#42a340"];

    onGroupingSelectionToggleChange(dataGrouping: string) {
        this.selectedValue = dataGrouping;
        this.chartDataGroupingSelection.emit(this.selectedValue);
    }

    constructor(private changeDetectionRef: ChangeDetectorRef, private translations: TranslationsService) {}

    ngOnChanges(changes: SimpleChanges) {
        if (changes.prepaymentInfoExpanded || changes.viewName) {
            this.reRendering = false;
            setTimeout(() => {
                this.reRendering = true;
                this.changeDetectionRef.markForCheck();
            }, 500);
        }
    }

    reRenderOnChange() {
        return this.reRendering;
    }
}
