import { Server, ServerMetadata } from '../../servers/shared/server';
import { CatalogStatus } from '../catalogs/shared/catalog-status';

export enum CONNECTION_TYPE {
  ORACLE = 'ORACLE',
  DB2ZOS = 'DB2ZOS',
  DB2I = 'DB2I',
  DB2 = 'DB2',
  SQLSERVER = 'SQLSERVER',
  KAFKA = 'KAFKA',
  SCHEMAREGISTRY = 'SCHEMAREGISTRY'
}

export class Connection {
  id?: string;
  parentAssetId?: string;
  connectionType?: string;
  description?: string;
  name?: string;
  owner?: string;
  dateCreated?: string;
  accessFromServer?: Server;
  accessMethod?: string;
  database?: string;
  port?: number;
  username?: string;
  password?: string;
  passwordEncrypted?: false;
  passwordRepository?: boolean;
  namenode?: string;
  private?: false;
  parameters?: { key: string; value: string }[];
  schemaOrDir?: string;
  schemaRegistryVendor?: string;
  schemaRegistryUrl?: string;
  schemaRegistryConfig?: string;
  catalogStatus?: CatalogStatus;
}

export const ConnectionMetadata = {
  id: { type: 'string' },
  type: { type: 'string', ignoreCompare: true },
  connectionType: { type: 'string' },
  description: { type: 'string' },
  name: { type: 'string' },
  owner: { type: 'string' },
  dateCreated: { type: 'string' },
  accessFromServer: ServerMetadata,
  accessMethod: { type: 'string' },
  catalogStatus: { type: 'object', ignoreCompare: true },
  database: { type: 'string' },
  port: { type: 'number' },
  username: { type: 'string' },
  password: { type: 'string' },
  passwordEncrypted: { type: 'boolean' },
  passwordRepository: { type: 'boolean' },
  namenode: { type: 'string' },
  private: { type: 'boolean' },
  parameters: {
    type: 'array',
    item: 'object',
    key: 'key',
    attributes: {
      key: { type: 'string' },
      value: { type: 'string' }
    }
  },
  schemaOrDir: { type: 'string' }
};
