import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Observable, of, throwError } from 'rxjs';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { SidebarComponent } from 'src/app/shared/components/sidebar/sidebar.component';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { ChangeColumnMappingSidebarComponent } from './change-column-mapping-sidebar.component';
import { ChangeColumnMappingDefaultsTabComponent } from './change-column-mapping-defaults-tab/change-column-mapping-defaults-tab.component';
import { ChangeColumnMappingChangesTabComponent } from './change-column-mapping-changes-tab/change-column-mapping-changes-tab.component';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Component } from '@angular/core';

@Component({
  selector: 'p-connect-change-column-mapping-changes-tab',
  template: '',
  providers: [
    {
      provide: ChangeColumnMappingChangesTabComponent,
      useClass: MockChangeColumnMappingChangesTabFormComponent
    }
  ]
})
class MockChangeColumnMappingChangesTabFormComponent {
  includeRowMetaDataDropdownData = [
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.USE_DEFAULT',
      value: 'USE_DEFAULT'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.DO_NOT_CHANGE',
      value: 'DO_NOT_CHANGE'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
      value: 'NO_ROW_METADATA'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.SELECTED_ROW_METADATA',
      value: 'SELECT_ROW_METADATA'
    }
  ];
  changesTabFormGroup = new FormGroup({
    rowMetaDataDropdown: new FormControl({
      value: this.includeRowMetaDataDropdownData[0]?.value,
      name: this.includeRowMetaDataDropdownData[0]?.name
    })
  });
}

describe('ChangeColumnMappingSidebarComponent', () => {
  let component: ChangeColumnMappingSidebarComponent;
  let fixture: ComponentFixture<ChangeColumnMappingSidebarComponent>;
  let pipelineMappingService: PipelineMappingService;

  let mapColumnsByDropdownData = [
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.MAP_COLUMNS_BY_DROPDOWN_DATA.COLUMN_NAME',
      value: 'COLUMN_NAME'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.MAP_COLUMNS_BY_DROPDOWN_DATA.COLUMN_ORDER',
      value: 'COLUMN_ORDER'
    }
  ];
  let includeRowMetaDataDropdownData = [
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.INCLUDE_ROW_METADATA_DROPDOWN_DATA.SELECT_ROW_METADATA',
      value: 'SELECT_ROW_METADATA'
    },
    {
      name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.INCLUDE_ROW_METADATA_DROPDOWN_DATA.NO_ROW_METADATA',
      value: 'NO_ROW_METADATA'
    }
  ];

  let mockPipelineService = {
    saveChangeColumnMappingDefaults: () => {},
    bulkChangeColumnMapping: () => {}
  };
  let mockchangeColumnMappingDefaultsTabComponent = {
    getDefaultsPayloadData: () => {},
    loadDefaultTab: () => {},
    defaultsTabFormGroup: () =>
      new FormGroup({
        mapColumnsByDropdown: new FormControl({
          value: mapColumnsByDropdownData[0]?.value,
          name: mapColumnsByDropdownData[0]?.name
        }),
        includeRowMetaDataDropdown: new FormControl({
          value: includeRowMetaDataDropdownData[0]?.value,
          name: includeRowMetaDataDropdownData[0]?.name
        })
      })
  };
  let mockchangeColumnMappingChangeTabComponent = {
    getChangesPayloadData: () => {},
    getBulkChangePayload: () => {},
    loadChangesTab: () => {},
    changesTabFormGroup: () =>
      new FormGroup({
        mapColumnsByDropdown: new FormControl({
          value: mapColumnsByDropdownData[0]?.value,
          name: mapColumnsByDropdownData[0]?.name
        }),
        rowMetaDataDropdown: new FormControl({
          value: component.changesTab.includeRowMetaDataDropdownData[0]?.value,
          name: component.changesTab.includeRowMetaDataDropdownData[0]?.name
        })
      })
  };

  const defaultMockData = [
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'EXCLUDE',
      isChecked: true,
      displayLabel: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ROW_METADATA_FIELDS.METADATA_USER_ID'
    },
    {
      key: 'METADATA_USER_ID',
      value: 'sv_trans_username',
      cdcRowMetadataType: 'INCLUDE',
      isChecked: true,
      displayLabel: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.ROW_METADATA_FIELDS.METADATA_USER_ID'
    }
  ];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, ReactiveFormsModule, FormsModule],
      declarations: [ChangeColumnMappingSidebarComponent, MockSidebarComponent, MockChangeColumnMappingChangesTabFormComponent],
      providers: [
        { provide: PipelineMappingService, useValue: mockPipelineService },
        { provide: ChangeColumnMappingDefaultsTabComponent, useValue: mockchangeColumnMappingDefaultsTabComponent },
        { provide: ChangeColumnMappingChangesTabComponent, useValue: mockchangeColumnMappingChangeTabComponent }
      ]
    }).compileComponents();
    fixture = TestBed.createComponent(ChangeColumnMappingSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    pipelineMappingService = TestBed.inject(PipelineMappingService);
    component.changeColumnMappingDefaultsTabComponent = TestBed.inject(ChangeColumnMappingDefaultsTabComponent);
    component.changesTab = TestBed.inject(ChangeColumnMappingChangesTabComponent);
    component.sidebarComponent = jasmine.createSpyObj<SidebarComponent>(['open', 'close']);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should enable UpdateDefaults Button', () => {
    component.enableUpdateDefaultsButton();
    expect(component.secondaryButton.isDisabled).toBe(false);
  });

  it('should disable Save button if unchecked all meta data checkboxs', () => {
    component.defaultsData = [
      {
        key: 'METADATA_USER_ID',
        value: 'sv_trans_username',
        cdcRowMetadataType: 'EXCLUDE',
        isChecked: true
      }
    ];
    let excludeCoundt = 0;
    component.defaultsData?.forEach((element) => {
      if (element.cdcRowMetadataType === 'EXCLUDE') {
        excludeCoundt++;
      }
    });
    const setMapColumnDropDownValue = spyOn(component, 'disableSaveButtonIfUncheckAll').and.returnValue();
    component.disableSaveBtn();
    expect(setMapColumnDropDownValue).toHaveBeenCalled();
  });

  it('should trigger sidebar open method without checked Items', () => {
    component.open(true, defaultMockData, 'Column name');
    component.metadataAlphabeticalSort();
    expect(component.changeColumnMappingDefaultsTabComponent.defaultsMetaData).toEqual(defaultMockData);
    expect(component.defaultsData).toEqual(defaultMockData);
    expect(component.sidebarComponent.open).toHaveBeenCalled();
    expect(component.activeTabIndex).toEqual(1);
  });

  it('should trigger sidebar open method with checked Items', () => {
    const selectedData = [
      {
        schema: 'Uxtesting1',
        table: 'Table_topic',
        topic: {
          name: '',
          mappingIcon: '',
          iconTooltip: ''
        }
      }
    ];
    component.checkedItems = selectedData;
    component.open(true, defaultMockData, 'Column name');
    expect(component.activeTabIndex).toEqual(1);
  });

  it('should trigger sidebar close method', () => {
    component.close();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should get Selected Topics Count', () => {
    const checkedItems = [
      {
        id: 1,
        schema: 'APPQOSSYS',
        table: 'WLM_CLASSIFIER_PLAN',
        topic: {
          name: 'WLM_CLASSIFIER_PLAN',
          mappingIcon: '',
          iconTooltip: '',
          class: null
        },
        isButtonEnabled: true
      }
    ];
    component.checkedItems = checkedItems;
    component.selectedTopics = checkedItems;
    component.getSelectedTopicsCount();
    expect(component.changesTabDisabled).toBe(false);
  });

  it('should get Selected Topics Count if selectd topics is zero', () => {
    const checkedItems = [
      {
        id: 1,
        schema: 'APPQOSSYS',
        table: 'WLM_CLASSIFIER_PLAN',
        topic: {
          name: 'WLM_CLASSIFIER_PLAN',
          mappingIcon: '',
          iconTooltip: '',
          class: null
        },
        isButtonEnabled: true
      }
    ];
    component.checkedItems = checkedItems;
    component.selectedTopics = [];
    component.getSelectedTopicsCount();
    expect(component.changesTabDisabled).toBe(false);
  });

  it('should disable SaveButton If Uncheck All checkbox', () => {
    component.disableSaveButtonIfUncheckAll(true);
    expect(component.primaryButton.isDisabled).toBe(false);
  });

  it('should handle tab change with changes tab', () => {
    const event = { index: 0 };
    component.handleTabChange(event);
    expect(component.activeTabIndex).toEqual(0);
  });

  it('should handle tab change with default tab', () => {
    const event = { index: 1 };
    component.handleTabChange(event);
    expect(component.activeTabIndex).toEqual(1);
  });

  it('should create Payload For Saving ChangesTab', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    const checkedItems = [
      {
        id: 1,
        schema: 'APPQOSSYS',
        table: 'WLM_CLASSIFIER_PLAN',
        topic: {
          name: 'WLM_CLASSIFIER_PLAN',
          mappingIcon: '',
          iconTooltip: '',
          class: null
        },
        isButtonEnabled: true
      }
    ];
    const setMapColumnDropDownValue = spyOn(component, 'setMapColumnDropDownValues').and.returnValue();
    const setRowMetaDataDropdownValue = spyOn(component, 'setRowMetaDataDropdownValues').and.returnValue();

    component.processPayloadForSavingChangesTab(formValues, checkedItems);
    expect(setMapColumnDropDownValue).toHaveBeenCalled();
    expect(setRowMetaDataDropdownValue).toHaveBeenCalled();
  });

  it('should set RowMeta DataDropdown Values is Do not change', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'DO_NOT_CHANGE'
      }
    };
    component.setRowMetaDataDropdownValues(formValues, payload);
    expect(payload.cdcRowMetadata).toEqual(null);
  });

  it('should set RowMeta DataDropdown Values is Select row metadata', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'SELECT_ROW_METADATA'
      }
    };
    component.setRowMetaDataDropdownValues(formValues, payload);
    expect(payload.cdcRowMetadata).toEqual(undefined);
  });

  it('should set RowMeta DataDropdown Values is No row metadata', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    component.setRowMetaDataDropdownValues(formValues, payload);
    expect(payload.cdcRowMetadata).toEqual(undefined);
  });

  it('should set RowMeta DataDropdown Values is Use default', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: { abc: 'data' },
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'USE_DEFAULT'
      }
    };
    component.setRowMetaDataDropdownValues(formValues, payload);
    expect(payload.cdcRowMetadata).toEqual(undefined);
  });

  it('should return ColumnMapping Type', () => {
    expect(component.returnColumnMappingType('COLUMN_NAME')).toEqual('NAME');
  });

  it('should return ColumnMapping Type other than Name', () => {
    expect(component.returnColumnMappingType('COLUMN_ORDER')).toEqual('ORDINAL');
  });

  it('should set MapColumn DropDown Value is do not change', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'DO_NOT_CHANGE'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    component.isTargetExists = true;
    component.setMapColumnDropDownValues(formValues, payload);
    expect(payload.columnMappingType).toEqual(null);
  });

  it('should set MapColumn DropDown Value is Column name', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_NAME'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    component.isTargetExists = true;
    component.setMapColumnDropDownValues(formValues, payload);
    expect(payload.columnMappingType).toEqual(component.returnColumnMappingType(formValues.mapColumnsByDropdown.value));
  });

  it('should set MapColumn DropDown Value is Column order', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    component.isTargetExists = true;
    component.setMapColumnDropDownValues(formValues, payload);
    expect(payload.columnMappingType).toEqual(component.returnColumnMappingType(formValues.mapColumnsByDropdown.value));
  });

  it('should set MapColumn DropDown Value is Use default', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'USE_DEFAULT'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    component.isTargetExists = true;
    component.columnMappingType = 'Column order';
    component.setMapColumnDropDownValues(formValues, payload);
    expect(payload.columnMappingType).toEqual(component.returnColumnMappingType(component.columnMappingType));
  });

  it('should set MapColumn DropDown Value and target is false', () => {
    const payload = {
      tableMappingIdList: [],
      cdcRowMetadata: {},
      columnMappingType: ''
    };
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'DO_NOT_CHANGE'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    component.isTargetExists = false;
    component.setMapColumnDropDownValues(formValues, payload);
    expect(payload.columnMappingType).toEqual(null);
  });

  it('should disable Update Defaults Button', () => {
    const event = { rowMetaDataDropdown: { name: 'Do not change', value: 'DO_NOT_CHANGE' } };
    component.isTargetExists = true;
    component.disableUpdateDefaultsButton(event);
    expect(component.secondaryButton.isDisabled).toEqual(true);
  });

  it('should disable Update Defaults Button and rowMetaData is select row metadata', () => {
    const event = { rowMetaDataDropdown: { name: 'select row metadata', value: 'SELECT_ROW_METADATA' } };
    component.isTargetExists = true;
    component.disableUpdateDefaultsButton(event);
    expect(component.secondaryButton.isDisabled).toEqual(false);
  });

  it('should disable Update Defaults Button and target is false', () => {
    const event = { rowMetaDataDropdown: { name: 'Do not change', value: 'DO_NOT_CHANGE' } };
    component.isTargetExists = false;
    component.disableUpdateDefaultsButton(event);
    expect(component.secondaryButton.isDisabled).toEqual(true);
  });

  it('should disable Update Defaults Buttonn, target is false and rowMetaData is select row metadata', () => {
    const event = { rowMetaDataDropdown: { name: 'select row metadata', value: 'SELECT_ROW_METADATA' } };
    component.isTargetExists = false;
    component.disableUpdateDefaultsButton(event);
    expect(component.secondaryButton.isDisabled).toEqual(false);
  });

  // disable as intermittantly failing
  xit('should update Defaults Button Clicked', () => {
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    component.updataDefaultsButtonClicked();
    expect(component.secondaryButton.isDisabled).toEqual(true);
    expect(saveDefaults).toHaveBeenCalled();
  });

  it('should save Button Clicked with index is 0', () => {
    const checkedItems = [
      {
        id: 1,
        schema: 'APPQOSSYS',
        table: 'WLM_CLASSIFIER_PLAN',
        topic: {
          name: 'WLM_CLASSIFIER_PLAN',
          mappingIcon: '',
          iconTooltip: '',
          class: null
        },
        isButtonEnabled: true
      }
    ];
    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    let mockPayload = {
      payload: {
        METADATA_USER_ID: 'INCLUDE'
      }
    };
    spyOn(pipelineMappingService, 'bulkChangeColumnMapping').and.returnValue(of(Observable));
    component.activeTabIndex = 0;
    component.selectedTopics = checkedItems;
    let isIncludeExists = Object.keys(mockPayload?.payload).some((key) => mockPayload?.payload[key] == 'INCLUDE');

    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      parseHttpClientResponseMessage: () => {},
      close: () => {}
    });
    component.processPayloadForSavingChangesTab(formValues, component.selectedTopics);
    component.saveButtonClicked();
    expect(isIncludeExists).toBe(true);
  });

  it('should save Button Clicked with index is 1', () => {
    let mockPayload = {
      payload: {
        METADATA_USER_ID: 'INCLUDE'
      }
    };
    component.activeTabIndex = 1;
    spyOn(component.changeColumnMappingDefaultsTabComponent, 'getDefaultsPayloadData').and.callThrough();
    spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    let isIncludeExists = Object.keys(mockPayload?.payload).some((key) => mockPayload?.payload[key] == 'INCLUDE');
    component.changeColumnMappingDefaultsTabComponent.defaultsTabFormGroup = new FormGroup({
      includeRowMetaDataDropdown: new FormControl({
        value: 'NO_ROW_METADATA',
        name: 'No RowMetadata'
      })
    });
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      parseHttpClientResponseMessage: () => {},
      close: () => {}
    });
    component.saveButtonClicked();
    component.rowMetadataValidationFails();
    expect(isIncludeExists).toBe(true);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should trigger if INCLUDE exists and active index is 1', () => {
    const isIncludeExists = true;
    component.activeTabIndex = 1;
    const getval = spyOn(component.changeColumnMappingDefaultsTabComponent, 'getDefaultsPayloadData').and.returnValue({
      payload: {
        METADATA_USER_ID: 'INCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      },
      mapColumns: ''
    });
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    component.saveChangeColumnMappingDefaults(getval);
    expect(isIncludeExists).toBe(true);
    expect(saveDefaults).toHaveBeenCalled();
  });

  it('should trigger if active index is 1, dropdown value is NO_ROW_METADATA and INCLUDE not exists', () => {
    const mockPayload = {
      payload: {
        METADATA_USER_ID: 'EXCLUDE'
      }
    };
    const isIncludeExists = Object.keys(mockPayload?.payload).some((key) => mockPayload?.payload[key] == 'INCLUDE');
    const getval = spyOn(component.changeColumnMappingDefaultsTabComponent, 'getDefaultsPayloadData').and.returnValue({
      payload: {
        METADATA_USER_ID: 'INCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      },
      mapColumns: ''
    });
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    component.activeTabIndex = 1;
    component.changeColumnMappingDefaultsTabComponent.defaultsTabFormGroup = new FormGroup({
      includeRowMetaDataDropdownData: new FormControl({
        value: 'NO_ROW_METADATA',
        name: 'No RowMetadata'
      })
    });
    component.saveButtonClicked();
    component.saveChangeColumnMappingDefaults(getval);
    expect(isIncludeExists).toBe(false);
    expect(component.changeColumnMappingDefaultsTabComponent.defaultsTabFormGroup.value.includeRowMetaDataDropdownData.value).toBe(
      'NO_ROW_METADATA'
    );
    expect(saveDefaults).toHaveBeenCalled();
  });

  it('should trigger on update default click if INCLUDE exists', () => {
    const mockPayload = {
      payload: {
        METADATA_USER_ID: 'INCLUDE'
      }
    };
    const getval = spyOn(component.changesTab, 'getChangesPayloadData').and.returnValue({
      payload: {
        METADATA_USER_ID: 'INCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      },
      mapColumns: ''
    });
    const isIncludeExists = Object.keys(mockPayload?.payload).some((key) => mockPayload?.payload[key] == 'INCLUDE');
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    component.updataDefaultsButtonClicked();
    component.saveChangeColumnMappingDefaultsOnUpdate(getval);
    expect(isIncludeExists).toBe(true);
    expect(saveDefaults).toHaveBeenCalled();
  });

  it('should trigger on update default click if INCLUDE not exists and dropdown value is NO_ROW_METADATA', () => {
    const mockPayload = {
      payload: {
        METADATA_USER_ID: 'EXCLUDE'
      }
    };
    const getval = spyOn(component.changesTab, 'getChangesPayloadData').and.returnValue({
      payload: {
        METADATA_USER_ID: 'EXCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      },
      mapColumns: ''
    });
    const isIncludeExists = Object.keys(mockPayload?.payload).some((key) => mockPayload?.payload[key] == 'INCLUDE');
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    component.changesTab.changesTabFormGroup = new FormGroup({
      rowMetaDataDropdown: new FormControl({
        value: 'NO_ROW_METADATA',
        name: 'No RowMetadata'
      })
    });

    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      parseHttpClientResponseMessage: () => {},
      close: () => {}
    });
    component.updataDefaultsButtonClicked();
    component.saveChangeColumnMappingDefaultsOnUpdate(getval);
    expect(isIncludeExists).toBe(false);
    expect(component.changesTab.changesTabFormGroup.value.rowMetaDataDropdown.value).toBe('NO_ROW_METADATA');
    expect(saveDefaults).toHaveBeenCalled();
  });

  it('should trigger if all rowMetadata unchecked and dropdown value is NO_ROW_METADATA', () => {
    const checkedItems = [
      {
        id: 1,
        schema: 'APPQOSSYS',
        table: 'WLM_CLASSIFIER_PLAN',
        topic: {
          name: 'WLM_CLASSIFIER_PLAN',
          mappingIcon: '',
          iconTooltip: '',
          class: null
        },
        isButtonEnabled: true
      }
    ];

    const formValues = {
      mapColumnsByDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.MAP_COLUMNS.PLACEHOLDERS.ORDINAL',
        value: 'COLUMN_ORDER'
      },
      rowMetaDataDropdown: {
        name: 'pipelines.STAGES.MAPPING.CHANGE_COLUMN_MAPPING_SIDEBAR.CHANGES_TAB.ROW_METADATA.PLACEHOLDERS.NO_ROW_METADATA',
        value: 'NO_ROW_METADATA'
      }
    };
    let mockPayload = [
      { key: 'METADATA_USER_ID', value: 'INCLUDE' },
      { key: 'METADATA_ROW_JOB_NAME', value: 'EXCLUDE' }
    ];
    const value = component.processPayloadForSavingChangesTab(formValues, checkedItems);
    const isIncludeExists = mockPayload?.some((element) => element.value == 'INCLUDE');
    component.activeTabIndex = 0;
    component.changesTab.changesTabFormGroup = new FormGroup({
      rowMetaDataDropdown: new FormControl({
        value: 'DO_NOT_CHANGE',
        name: 'Do not change'
      })
    });
    const saveDefaults = spyOn(pipelineMappingService, 'bulkChangeColumnMapping').and.returnValue(of(Observable));
    component.saveButtonClicked();
    component.bulkChangeColumnMapping(value);
    expect(isIncludeExists).toBe(true);
    expect(component.changesTab.changesTabFormGroup.value.rowMetaDataDropdown.value).toBe('DO_NOT_CHANGE');
    expect(saveDefaults).toHaveBeenCalled();
  });

  it('should save ChangeColumnMappingDefaults on update if api returns success', () => {
    let mockPayload = {
      payload: {
        METADATA_USER_ID: 'EXCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      }
    };
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      parseHttpClientResponseMessage: () => {},
      close: () => {}
    });
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of({ success: 'success' }));
    component.saveChangeColumnMappingDefaultsOnUpdate(mockPayload);
    component.changeColumnMappingDefaultsTabComponent.loadDefaultTab(true);
    expect(saveDefaults).toHaveBeenCalled();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
  });

  it('should show error if saveChangeColumnMappingDefaultsOnUpdate api throws error', () => {
    let mockPayload = {
      payload: {
        METADATA_USER_ID: 'EXCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      }
    };
    const error = { detailedMessage: 'something failed' };
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      open: () => {},
      parseHttpClientResponseMessage: () => {},
      close: () => {}
    });
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(throwError(error));
    component.saveChangeColumnMappingDefaultsOnUpdate(mockPayload);
    expect(saveDefaults).toHaveBeenCalled();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should save bulkChangeColumnMapping response if api returns success', () => {
    let mockPayload = [
      { key: 'METADATA_USER_ID', value: 'INCLUDE' },
      { key: 'METADATA_ROW_JOB_NAME', value: 'EXCLUDE' }
    ];
    const saveDefaults = spyOn(pipelineMappingService, 'bulkChangeColumnMapping').and.returnValue(of(Observable));
    component.bulkChangeColumnMapping(mockPayload);
    component.close();
    expect(saveDefaults).toHaveBeenCalled();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
  });

  it('should show error if bulkChangeColumnMapping api throws error', () => {
    let mockPayload = [
      { key: 'METADATA_USER_ID', value: 'INCLUDE' },
      { key: 'METADATA_ROW_JOB_NAME', value: 'EXCLUDE' }
    ];
    const error = { detailedMessage: 'something failed' };
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      open: () => {},
      parseHttpClientResponseMessage: () => {},
      close: () => {}
    });
    const saveDefaults = spyOn(pipelineMappingService, 'bulkChangeColumnMapping').and.returnValue(throwError(error));
    component.bulkChangeColumnMapping(mockPayload);
    expect(saveDefaults).toHaveBeenCalled();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should save ChangeColumnMappingDefaults response if api returns success', () => {
    let mockPayload = {
      payload: {
        METADATA_USER_ID: 'EXCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      }
    };
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    component.saveChangeColumnMappingDefaults(mockPayload);
    component.close();
    expect(saveDefaults).toHaveBeenCalled();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
  });

  it('should show error if saveChangeColumnMappingDefaults api throws error', () => {
    let mockPayload = {
      payload: {
        METADATA_USER_ID: 'EXCLUDE',
        METADATA_ROW_JOB_NAME: 'EXCLUDE'
      }
    };
    const error = { detailedMessage: 'something failed' };
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      open: () => {},
      parseHttpClientResponseMessage: () => {}
    });
    const saveDefaults = spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(throwError(error));
    component.saveChangeColumnMappingDefaults(mockPayload);
    expect(saveDefaults).toHaveBeenCalled();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should be trigger to show error if all rowMetadata unchecked', () => {
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      open: () => {},
      parseHttpClientResponseMessage: () => {}
    });
    component.rowMetadataValidationFails();
    expect(component.sidebarComponent.isProcessingRequest).toBe(false);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should trigger when update default button clicked', () => {
    let mockPayload = {
      payload: {
        METADATA_USER_ID: 'INCLUDE'
      }
    };
    let isIncludeExists = Object.keys(mockPayload?.payload).some((key) => mockPayload?.payload[key] == 'INCLUDE');
    component.sidebarComponent = jasmine.createSpyObj('SidebarComponent', {
      parseHttpClientResponseMessage: () => {}
    });
    spyOn(pipelineMappingService, 'saveChangeColumnMappingDefaults').and.returnValue(of(Observable));
    component.secondaryButton.isDisabled = true;
    component.sidebarComponent.isProcessingRequest = true;
    component.updataDefaultsButtonClicked();
    component.rowMetadataValidationFails();
    expect(isIncludeExists).toBe(true);
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should trigger to update has custom column mapping', () => {
    const selectedTable = [
      {
        id: '1',
        hasCustomColMappings: true,
        library: '#LIBRARY',
        table: 'QS36SRC ',
        topic: {
          name: 'MLO',
          mappingIcon: 'ATTENTION',
          iconTooltip: 'A new topic will be created on the target when clicked on Next button.',
          class: null
        },
        undefined: {
          mappingIcon: '',
          iconTooltip: ''
        },
        hasSchema: true,
        hasTable: true,
        isButtonEnabled: true
      }
    ];
    component.tableMapping = [
      {
        id: '1',
        key: 'string',
        value: 'string',
        hasCustomColMappings: true,
        type: 'TARGET_EXISTS_WITH_MATCH'
      }
    ];

    component.changesTab.changesTabFormGroup = new FormGroup({
      rowMetaDataDropdown: new FormControl({
        value: 'DO_NOT_CHANGE',
        name: 'Do not change'
      })
    });

    const selectedDdlValue = component.changesTab.changesTabFormGroup.value.rowMetaDataDropdown.value;
    const updatedTableMappingEmitSpy = spyOn(component.updatedTableMapping, 'emit');
    component.updateHasCustomColMapping(selectedDdlValue, selectedTable);
    expect(component.tableMapping[0].id).toEqual(selectedTable[0].id);
    expect(updatedTableMappingEmitSpy).toHaveBeenCalled();
  });
});
