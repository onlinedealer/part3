(function () {
    'use strict';
    angular.module('arm').controller('dashboardCtrl',
        ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate','dashboardService', dashboardCtrl]);

    function dashboardCtrl($scope, $state, $ionicModal, $ionicSideMenuDelegate,dashboardService) {

        $scope.groups = [
    { title: 'Internal Messages', id: 1, icon: 'ion-msg-icon', items: [{ name: 'Appetizers1' }] },
    { title: 'Activities ', id: 2, icon: 'ion-msg-icon', items: [{ name: 'Appetizers2' }] },
    { title: 'Deals', id: 3, icon: 'ion-msg-icon', items: [{ name: 'Appetizers3' }] },
    { title: 'Dashboard', id: 4, icon: 'ion-msg-icon', items: [{ name: 'Appetizers4' }] },

        ];

        $scope.openDashboardGraph = function () {
            $state.go("tab.dashboardGraph");
        };

        $scope.toggleGroup = function (group) {
            group.show = !group.show;
        };
        $scope.isGroupShown = function (group) {
            return group.show;
        };
        $scope.groupsMsg = [
          {
              title: 'Internal Messages', id: 1, icon: 'icon-msg', count: 123,
              items: [
                  {
                      msgID: 1,
                      fromMsg: 'Northern Region',
                      toMsg: 'Simon Williams',
                      msgPriority: '123',
                      msgtext: 'Town hall tomorrow 10 am at Head...',
                      msgDate: '01-08-2015 09:30 am'
                  },
                   {
                       msgID: 2,
                       fromMsg: 'Angela Robbins',
                       toMsg: '',
                       msgPriority: '2',
                       msgtext: 'Great job with the new campaign, keep it up! We can also try and sell our new products.',
                       msgDate: '11-02-2015 09:30 am'
                   },
                   {
                       msgID: 3,
                       fromMsg: 'Mr. ABC',
                       toMsg: 'All',
                       msgPriority: '2',
                       msgtext: 'Sonia has closed today a money market...',
                       msgDate: '13-02-2015'
                   },
                   {
                       msgID: 4,
                       fromMsg: 'Mr. XYZ',
                       toMsg: 'All',
                       msgPriority: '1',
                       msgtext: 'Sonia has closed today a money market...',
                       msgDate: '14-02-2015'
                   }
              ]
          },

        ];

        $scope.groupsActivities = [
          {
              title: 'Activities', id: 2, icon: 'icon-activity', count: 22,
              items: [
                  {
                      ActivityID: 1,
                      ActivityTier: '1',
                      ActivityType: 'GOLD',
                      ActivityWith: 'Alan Russo',
                      ActivityBy: 'Simons Williams',
                      ActivityAgenda: 'Follow up on proposal',
                      ActivityAt: '27-05-2016, 09:30 am',
                      ActivityDuration: '60 min',
                      ActivityLocation: 'Kingston, London',
                      ActivityCompany: 'National Automative Company',
                      ActivityPriority: '3',
                      ActivityNotes: 'Inform client of special discount approved...'
                  },
                  {
                      ActivityID: 2,
                      ActivityTier: '1',
                      ActivityType: 'GOLD',
                      ActivityWith: 'Mr. Rami Smith',
                      ActivityBy: 'Simons Williams',
                      ActivityAgenda: 'Follow up on proposal',
                      ActivityAt: '27-05-2016, 09:30 am',
                      ActivityDuration: '60 min',
                      ActivityLocation: 'Kingston, London',
                      ActivityCompany: 'National Automative Company',
                      ActivityPriority: '1',
                      ActivityNotes: 'Client is intersted in high field...'
                  }
              ]
          },
        ];

        $scope.groupsDeals = [
          {
              title: 'Deals', id: 2, icon: 'icon-deals', count: 2,
              items: [
                  {
                      DealsID: 1,
                      DealsContact: 'Maria David',
                      DealsCompany: 'Beverage Distribution LLC',
                      DealsBy: 'Simons Williams',
                      DealsTier: '1',
                      DealsType: 'GOLD',
                      DealsValue: '10,000 AED',
                      DealsProductName: 'Time Deposit',
                      DealsSizeType: 'Offered',
                      DealsRevenue: '1,000 AED',
                      DealsDate: '27-05-2016',
                      DealsPriority: '1',
                      DealsNotes: 'Client is intersted in high field...'
                  },
                  {
                      DealsID: 2,
                      DealsContact: 'Ed Rony',
                      DealsCompany: 'Beverage Distribution LLC',
                      DealsBy: 'Simons Williams',
                      DealsTier: '1',
                      DealsType: 'GOLD',
                      DealsValue: '50,000 AED',
                      DealsProductName: 'Time Deposit',
                      DealsSizeType: 'Interested',
                      DealsRevenue: '1,000 AED',
                      DealsDate: '27-05-2016',
                      DealsPriority: '2',
                      DealsNotes: 'Client will sell summer house...'
                  },
                   {
                       DealsID: 3,
                       DealsContact: 'Lorem ipsum',
                       DealsCompany: 'Beverage Distribution LLC',
                       DealsBy: 'Simons Williams',
                       DealsTier: '1',
                       DealsType: 'GOLD',
                       DealsValue: '50,000 AED',
                       DealsProductName: 'Time Deposit',
                       DealsSizeType: 'Interested',
                       DealsRevenue: '1,000 AED',
                       DealsDate: '27-05-2016',
                       DealsPriority: '1',
                       DealsNotes: 'Client will sell summer house...'
                   }
              ]
          },
        ];
        $scope.groupsCampaigns  = [
    { title: 'Campaigns', id: 2, icon:'icon-campaigns',count: 2,
      items:[
        {
          DealsID: 1,
          DealsContact: 'Maria David',
          DealsCompany: 'Beverage Distribution LLC',
          DealsBy: 'Simons Williams', 
          DealsTier: '1',
          DealsType: 'GOLD',
          DealsValue: '10K AED',
          DealsProductName: 'Time Deposit',
          DealsSizeType: 'Offered',
          DealsRevenue: '1K AED',
          DealsDate: '27-05-2016',
          DealsPriority: '1',
          DealsNotes: 'Client is intersted in high field...'
         },
        {
          DealsID: 2,
          DealsContact: 'Ed Rony',
          DealsCompany: 'Beverage Distribution LLC',
          DealsBy: 'Simons Williams', 
          DealsTier: '1',
          DealsType: 'GOLD',
          DealsValue: '50K AED',
          DealsProductName: 'Time Deposit',
          DealsSizeType: 'Interested',
          DealsRevenue: '1K AED',
          DealsDate: '27-05-2016',
          DealsPriority: '2',
          DealsNotes: 'Client will sell summer house...'
         },
        {
          DealsID: 3,
          DealsContact: 'Ed Rony',
          DealsCompany: 'Beverage Distribution LLC',
          DealsBy: 'Simons Williams', 
          DealsTier: '1',
          DealsType: 'GOLD',
          DealsValue: '50K AED',
          DealsProductName: 'Time Deposit',
          DealsSizeType: 'Interested',
          DealsRevenue: '1K AED',
          DealsDate: '27-05-2016',
          DealsPriority: '2',
          DealsNotes: 'Client will sell summer house...'
         },
        {
          DealsID: 4,
          DealsContact: 'Ed Rony',
          DealsCompany: 'Beverage Distribution LLC',
          DealsBy: 'Simons Williams', 
          DealsTier: '1',
          DealsType: 'GOLD',
          DealsValue: '50K AED',
          DealsProductName: 'Time Deposit',
          DealsSizeType: 'Interested',
          DealsRevenue: '1K AED',
          DealsDate: '27-05-2016',
          DealsPriority: '3',
          DealsNotes: 'Client will sell summer house...'
         },
        {
          DealsID: 5,
          DealsContact: 'Ed Rony',
          DealsCompany: 'Beverage Distribution LLC',
          DealsBy: 'Simons Williams', 
          DealsTier: '1',
          DealsType: 'GOLD',
          DealsValue: '50K AED',
          DealsProductName: 'Time Deposit',
          DealsSizeType: 'Interested',
          DealsRevenue: '1K AED',
          DealsDate: '27-05-2016',
          DealsPriority: '1',
          DealsNotes: 'Client will sell summer house...'
         }         
      ]
    },
    ];
    
    $scope.contactData = [
    { title: 'Contacts', id: 1, icon:'icon-contacts-title',count: 123,
      items:[
        {
          conID: 1,
          contactName: 'Maria David',
          contactCompany: 'Beverage Distribution LLC',
          contactBy: 'Simons Williams',
           contactRole: 'Manager',
          contactPriority: '1',
          contactDate: '27-05-2016',
          contactType: 'GOLD',
          contactTier: '1'
         },
         {
          conID: 2,
          contactName: 'Maria David',
          contactCompany: 'National Automative Comp.',
          contactBy: 'Simons Williams',
          contactRole: 'Manager',
          contactPriority: '2',
          contactDate: '23-05-2016',
          contactType: 'GOLD',
          contactTier: '2'          
         },
                 {
          conID: 3,
          contactName: 'Maria David',
          contactCompany: 'National Automative Comp.',
          contactBy: 'Simons Williams',
          contactRole: 'Manager',
          contactPriority: '2',
          contactDate: '23-05-2016',
          contactType: 'GOLD',
          contactTier: '3'          
         },
                 {
          conID: 4,
          contactName: 'Maria David',
          contactCompany: 'National Automative Comp.',
          contactBy: 'Simons Williams',
          contactRole: 'Manager',
          contactPriority: '3',
          contactDate: '23-05-2016',
          contactType: 'GOLD',
          contactTier: '1'          
         },
                 {
          conID: 5,
          contactName: 'Maria David',
          contactCompany: 'National Automative Comp.',
          contactBy: 'Simons Williams',
          contactRole: 'Manager',
          contactPriority: '1',
          contactDate: '23-05-2016',
          contactType: 'GOLD',
          contactTier: '2'          
         }
      ]
    }
    ];
    $scope.dashboardData = [
    { title: 'Dashboard', id: 1, icon:'icon-dashboard',count: 12,
      items:[
        /*{
          dashID: 1,
          itemgroupTitle: 'Activities MTD',
          graphImg: 'dash-graph1.jpg'
         },*/
         {
          dashID: 2,
          itemgroupTitle: 'Deals Pipeline MTD',
          graphImg: 'dash-graph2.jpg'         
         },
         {
          dashID: 3,
          itemgroupTitle: 'Contacts',
          graphImg: 'dash-graph3.jpg'
         },
         {
          dashID: 4,
          itemgroupTitle: 'Leads / Campaigns',
          graphImg: 'dash-graph4.jpg'
         }
      ]
    }
    ];
    //

        $scope.redirectToDetail = function (listId) {
            //console.log('in redirectToDetail');
            //console.log(listId);
            $state.go('app.activityDetail', {
                listId: listId
            });
        }

        $scope.redirectTomsgDetail = function (listId) {
            //console.log(listId);
            //var isIOS = ionic.Platform.isIOS();
            //$ionicHistory.clearCache();
            $state.go('app.messageDetail', {
                listId: listId
            });
        }
        $scope.redirectTodealsDetail = function (listId) {
            $state.go('app.dealDetail', {
                listId: listId
            });
        }

        $scope.toggleGroup = function (group) {
            group.show = !group.show;
        };
        $scope.isGroupShown = function (group) {
            return group.show;
        };

        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };


        // Modal filter
        $ionicModal.fromTemplateUrl('app/views/contact/contactFilter.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalcntfilter = modal;
        });
        $scope.openFilter = function () {
            $scope.modalcntfilter.show();
        };
        $scope.closeModalB = function () {
            $scope.modalcntfilter.hide();
        };

    };
    // 

})();


