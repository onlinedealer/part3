import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { AuthenticationService } from 'discovery-shared';

@Injectable({
  providedIn: 'root'
})
export class ScheduleService {
  /**
   *
   */
  baseUrl: string;

  /**
   *
   */
  constructor(
    private httpClient: HttpClient,
    private authenticationService: AuthenticationService,
    httpUtil: HttpUtilService
  ) {
    this.baseUrl = httpUtil.getAssetUrl('configapi', 'profiling', 'api/v1/');
  }

  getScheduleHistory(profileId: string) {
    return this.httpClient.get(this.baseUrl + 'runtime/schedule/run/list/' + profileId, {
      headers: this.authenticationService.getHttpHeaders()
    });
  }

  toggleSchedule(profileId: string, status: boolean) {
    return this.httpClient.put(`${this.baseUrl}schedule/status/${profileId}?enabled=${status}`, '', {
      headers: this.authenticationService.getHttpHeaders()
    });
  }
}
