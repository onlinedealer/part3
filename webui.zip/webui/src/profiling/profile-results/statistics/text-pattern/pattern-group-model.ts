export class PatternGroupModel {
  pattern: string = '';
  regex: string = '';
  count: number = 0;
  percentage: number = 0;

  constructor(pattern: string, regex: string, count: number, percent: number) {
    this.pattern = pattern;
    this.regex = regex;
    this.count = count;
    this.percentage = percent;
  }
}
