import { Spies } from 'discovery-test';

import { ConnectionButtonComponent } from './connection-button.component';

describe('ConnectionButtonComponent', () => {
  let component: ConnectionButtonComponent;

  beforeEach(() => {
    Spies.init();
    component = new ConnectionButtonComponent(Spies.TranslateService, Spies.launchDarklyService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should databrick click called', () => {
    spyOn(component, 'onButtonClick');
    component.onButtonClick('databricks');
    expect(component.onButtonClick).toHaveBeenCalled();
  });

  it('should call event on button click', () => {
    spyOn(component.connectionType, 'emit');
    component.onButtonClick('snowflake');
    expect(component.connectionType.emit).toHaveBeenCalled();
  });
});
