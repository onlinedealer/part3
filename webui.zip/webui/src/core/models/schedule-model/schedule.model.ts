import { ScheduleOccurenceTypeEnum } from './schedule-occurence-type.enum';

export class ScheduleModel {
  occurence: ScheduleOccurenceTypeEnum;
  daysOfWeek: Array<string>;
  runAtTime: {
    hour: string;
    minute: string;
    meridiemIndicator: string;
  };
  timezone: string;
  //fromDateTime: number;
}
