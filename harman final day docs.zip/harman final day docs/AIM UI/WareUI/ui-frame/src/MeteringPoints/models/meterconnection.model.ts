export interface MeterConnectionsResponse {
    parameters: Parameters;
    data: MeterConnection[];
}

export interface MeterConnection {
    meterConnectionId: number;
    meteringPointId: number;
    deviceMeter?: DeviceMeter;
    connectionType: string;
    validFrom: number;
    validUntil?: number;
    deleted?: number;
    parentDeviceMeter?: DeviceMeter;
}

export interface DeviceMeter {
    concentratorId?: number;
    deviceMeterId: number;
    deviceMeterType: string;
    manufacturerCode: string;
    meterSerialNumber: string;
    meterType: string;
    modelName: string;
    name: string;
    transformers: DeviceTransformerFactor[];
    utilitySerialNumber?: string;

    externalId?: string;
    eanCode?: string;
    moduleSerialNumber?: string;
    configuration?: string;
}

export interface DeviceTransformerFactor {
    deviceMeterId: number;
    transformerId: number;
    factor: number;
    kind: string;
    usage: string;
    validFrom: number;
    validUntil?: number | null;
}

export interface Parameters {
    meteringPointId: number;
}
