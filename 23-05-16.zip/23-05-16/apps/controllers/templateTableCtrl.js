(function() {
    'use strict';

    fileuploader.controller("templateTableCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$location', '$route', '$window', '$timeout', '$http', '$uibModal', 'ngTableParams', templateTableCtrl]);

    function templateTableCtrl($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $location, $route, $window, $timeout, $http, $uibModal, ngTableParams) {
    }

    
})();
