import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { MockSidebarComponent } from '../../../shared/components/sidebar/mock-sidebar.component.spec';
import { LogReaderDetailsSidebarComponent } from './logreader-details-sidebar.component';

describe('LogReaderDetailsSidebarComponent', () => {
  let component: LogReaderDetailsSidebarComponent;
  let fixture: ComponentFixture<LogReaderDetailsSidebarComponent>;
  const logReader = {
    journal: 'UNKNOWN',
    library: 'abc',
    name: 'GISLARDJ/TSTJRN',
    sequence: 'UNKNOWN',
    status: 'UNKNOWN',
    currentPipelineName: 'pipeline1',
    dataConnection: 'LTIAS08',
    dataConnectionType: '',
    pipelines: [
      {
        pipelineName: 'pipeline1',
        captureStatus: 'DISABLED'
      },
      {
        pipelineName: 'pipeline2',
        captureStatus: 'DISABLED'
      }
    ]
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), RouterTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [LogReaderDetailsSidebarComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogReaderDetailsSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the sidebar', () => {
    const sidebarSpy = spyOn(component.sidebarComponent, 'open');
    component.open(logReader, 'myProject');
    expect(component.logReaderDetails).toEqual(logReader);
    expect(sidebarSpy).toHaveBeenCalled();
  });

  it('should check if connection is DB2 for IBM i', () => {
    component.logReaderDetails = logReader;
    expect(component.isDb2I()).toBeFalse();
    component.logReaderDetails.dataConnectionType = 'DB2I';
    expect(component.isDb2I()).toBeTrue();
  });
});
