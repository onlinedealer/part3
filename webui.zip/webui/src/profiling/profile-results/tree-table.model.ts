import { TreeNode } from 'primeng/api';
import { ProfileResultsTableModel } from './profile-results-table.model';
export class TreeTableModel implements TreeNode {
  data: ProfileResultsTableModel;
  parent: TreeNode<ProfileResultsTableModel>;
  children?: TreeNode<ProfileResultsTableModel>[];
}
