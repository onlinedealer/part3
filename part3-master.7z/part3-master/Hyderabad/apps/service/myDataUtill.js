(function() {
    'use strict';

    myFirstApp.service('myDataUtill', ['$rootScope', '_', myDataUtill]);

    function myDataUtill($rootScope, _) {

        this.tableData = function() {
            return $rootScope.myItemData.data;
        }


    }
})();
