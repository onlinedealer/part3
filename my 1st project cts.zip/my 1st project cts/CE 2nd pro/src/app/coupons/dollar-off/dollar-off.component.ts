import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';
import { CouponHelperService } from '../../services/coupon-helper.service';

@Component({
  selector: 'app-dollar-off',
  templateUrl: './dollar-off.component.html',
  styleUrls: ['./dollar-off.component.scss']
})
export class DollarOffComponent implements OnInit {
  @Input() data: any ;

  imagesPaths:Object = ImagePaths;

  constructor(public utilityService:UtilityService, public couponHelperService: CouponHelperService) { }

  ngOnInit() { }

}
