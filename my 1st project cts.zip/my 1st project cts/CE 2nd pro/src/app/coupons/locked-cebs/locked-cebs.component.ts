import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-locked-cebs',
  templateUrl: './locked-cebs.component.html',
  styleUrls: ['./locked-cebs.component.scss']
})
export class LockedCebsComponent implements OnInit {
  @Input() data: any 

  // expandedView: boolean = false;
  // expandCpnDsc: boolean = true;
  // webDscToggle: boolean = true;
  imagesPaths: Object = ImagePaths
  

  constructor(public utilityService:UtilityService) { }

  
  styleStr;
  ngOnInit() {        
    this.getDateFormatted();    
  }

    getDateFormatted(){   
    let expDt = this.data.cmpgnEndDt;     
     let yyyy = expDt.substr(0,4);
     let mm = expDt.substr(4,2);
     let dd = expDt.substr(6,2);
     expDt = mm + '/' + dd + '/' + yyyy;     
     this.data.cmpgnEndDt = expDt;    
     }
    getRemainingThreshHold(){
    let ptsToNextQty = this.data.ptsToNextThreshldQty;
    let firstLimit = this.data.firstThrshldLimNbr;
    let diff = (((firstLimit-ptsToNextQty)*100)/firstLimit)/2;
    this.styleStr = {background:'linear-gradient(-135deg, #CC0000, #CC0000 '+diff+'px,#767676 0)'};    
    return this.styleStr;
     }
}
