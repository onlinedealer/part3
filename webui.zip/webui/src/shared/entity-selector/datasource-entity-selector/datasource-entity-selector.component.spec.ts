import { Component, Input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EntityCardHeaderModel } from '../entity-card-header.model';
import { EntityCardComponent } from '../entity-card/entity-card.component';

import { DatasourceEntitySelectorComponent } from './datasource-entity-selector.component';

@Component({
  selector: 'discovery-png-entity-card',
  template: '',
  providers: [{ provide: EntityCardComponent, useClass: MockEntityCardComponent }]
})
class MockEntityCardComponent {
  @Input() headerText: string;
  @Input() showFilter = true;
  @Input() filterText: string;
  @Input() allowSelection = true;
  @Input() headers: Array<EntityCardHeaderModel>;
  @Input() keyField?: string;
  @Input() apiData = [];
  @Input() isLoading = false;
  @Input() filterFields: string[];
  @Input() selectedData: any;
  @Input() lazy: boolean;
  @Input() virtualRowHeight: number;
  @Input() showCheckBox: boolean;
  @Input() showTriState: boolean;
  @Input() showSelectAllCheckBox: boolean;
  @Input() scrollable: boolean;
  @Input() scrollHeight: number;
  @Input() virtualScroll: boolean;
  @Input() numOfRows: number;
  @Input() rowHover: boolean;
  @Input() emptyMessage: string;
}

describe('DatasourceEntitySelectorComponent', () => {
  let component: DatasourceEntitySelectorComponent;
  let fixture: ComponentFixture<DatasourceEntitySelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DatasourceEntitySelectorComponent, MockEntityCardComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatasourceEntitySelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
