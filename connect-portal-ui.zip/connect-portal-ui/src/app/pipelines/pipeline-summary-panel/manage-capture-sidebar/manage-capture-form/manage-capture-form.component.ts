import { Component, Output, EventEmitter, ViewChild, TemplateRef } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { TableConfiguration } from '../../../../shared/components/generic-table/generic-table';
import { PipelinesMonitoringApiService } from '../../../shared/pipelines-monitoring-api.service';
import { BaseComponent } from '../../../../core/base.component';

@Component({
  selector: 'p-connect-manage-capture-form',
  templateUrl: './manage-capture-form.component.html',
  styleUrls: ['./manage-capture-form.component.scss']
})
export class ManageCaptureFormComponent extends BaseComponent {
  @ViewChild('tablesCountTemplate')
  private tablesCountTemplateTpl: TemplateRef<any>;
  @Output() pendingChanges = new EventEmitter<boolean>();

  selectedRows = [];
  tableData = [];
  renderTable = false;
  tablesCount = 0;
  tablesEnabledCount = 0;
  tablesDisabledCount = 0;
  schemas: any[] = [];
  originalState = [];
  dataConnection = '';
  dataConnectionType = '';
  allSchemaOption = { label: '', value: 'all' };
  selectedSchema = this.allSchemaOption;
  replicationStatus = '';
  overallStatus = '';
  captureStatus = '';
  pipelineName = '';
  projectName = '';
  errorMessage = '';
  errorMessageIcon = [];
  checkField = false;
  isSQLServer = false;
  manageCaptureTableConfiguration: TableConfiguration = {
    fields: [
      {
        header: 'pipelines.SHARED.MANAGE_CAPTURE.COLUMNS.SCHEMA',
        name: 'schema',
        columnStyle: { width: '13rem' },
        isSearchable: true
      },
      {
        header: 'pipelines.SHARED.MANAGE_CAPTURE.COLUMNS.TABLE',
        name: 'table',
        isSearchable: true
      },
      {
        header: 'pipelines.SHARED.MANAGE_CAPTURE.COLUMNS.CAPTURE',
        name: 'captureStatus',
        isSearchable: true
      },
      // p-tables does not support composite keys
      // in order to simulate composite keys we need to create a hidden column with the combined data
      {
        header: 'ThisColumnIsHidden',
        name: 'compositeKey',
        isKey: true,
        isHidden: true,
        columnStyle: { width: 0 }
      }
    ],
    isLoading: false,
    hideCheckboxColumn: false,
    disableCheckboxColumn: false,
    visibleRows: 25,
    rowSelectionChangedEvent: (checkedItems: any[]) => {
      this.selectedRows = checkedItems;
    },
    caption: {
      isFilterShown: true,
      dropdown: {
        options: [],
        selectedOption: this.selectedSchema,
        disabled: false,
        field: 'label',
        isHidden: false,
        onDropdownChange: (event) => {
          this.onSchemaChange(event);
        },
        completeMethod: (event) => {
          this.filterSchemas(event);
        }
      },
      template: null,
      templateContext: null
    }
  };

  constructor(
    public readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService,
    public readonly translocoService: TranslocoService
  ) {
    super();
  }

  open(selectedPipeline: any, projectName?: string): void {
    this.selectedRows = [];
    this.allSchemaOption.label = this.translocoService.translate('pipelines.SHARED.MANAGE_CAPTURE.LABELS.ALL_SCHEMAS');
    this.selectedSchema = this.allSchemaOption;
    this.dataConnection = selectedPipeline.tableMappings[0].source.name;
    this.dataConnectionType = selectedPipeline.tableMappings[0].source.connectionType;
    if (this.dataConnectionType === 'SQLSERVER' && this.checkField === false) {
      this.isSQLServer = true;
      this.checkField = true;
      this.manageCaptureTableConfiguration.fields.splice(0, 0, {
        header: 'pipelines.SHARED.MANAGE_CAPTURE.COLUMNS.DATABASE',
        name: 'database',
        columnStyle: { width: '13rem' },
        isSearchable: true
      });
    }
    this.manageCaptureTableConfiguration.caption.dropdown.selectedOption = this.selectedSchema;
    this.manageCaptureTableConfiguration.caption.template = this.tablesCountTemplateTpl;
    this.originalState = selectedPipeline.tableMappings[0].mappingDetails.map((mapping) => {
      return {
        database: mapping.source.catalog,
        schema: mapping.source.schema,
        table: mapping.source.table,
        captureStatus: mapping.captureStatus,
        newStatus: ''
      };
    });
    this.replicationStatus = selectedPipeline.replicationStatus;
    this.overallStatus = selectedPipeline.overallStatus;
    this.captureStatus = selectedPipeline.captureStatus;
    this.pipelineName = selectedPipeline.name;
    this.projectName = projectName;
    setTimeout(() => {
      // Workaround for a bug wherein the table is not rendered on the sidebar unless the
      // browser window is resized (See https://github.com/primefaces/primeng/issues/9766)
      this.populateSchemasAndTables();
      this.renderTable = true;
    });
  }

  isEnableCaptureButtonDisabled(): boolean {
    let isDisabled = true;

    if (
      this.selectedRows.length &&
      this.selectedRows.some((item) => item.captureStatus.startsWith('DISABLED')) &&
      (this.replicationStatus === 'STOPPED' || this.replicationStatus === 'OK' || this.replicationStatus === 'COMPLETED')
    ) {
      isDisabled = false;
    }

    return isDisabled;
  }

  isDisableCaptureButtonDisabled(): boolean {
    let isDisabled = true;

    if (
      this.selectedRows.length &&
      this.selectedRows.some((item) => item.captureStatus.startsWith('ENABLED')) &&
      (this.replicationStatus === 'STOPPED' || this.replicationStatus === 'OK' || this.replicationStatus === 'COMPLETED')
    ) {
      isDisabled = false;
    }

    return isDisabled;
  }

  enableCaptureButtonClicked(): void {
    this.tableData.forEach((table) => {
      const isTableSelected = this.selectedRows.find((row) => row.schema === table.schema && row.table === table.table) ? true : false;
      const originalTable = this.originalState.find((origTable) => origTable.schema === table.schema && origTable.table === table.table);
      originalTable.newStatus = isTableSelected ? 'ENABLED_PENDING' : '';
    });
    this.selectedRows = [];
    this.populateSchemasAndTables();
  }

  disableCaptureButtonClicked(): void {
    this.tableData.forEach((table) => {
      const isTableSelected = this.selectedRows.find((row) => row.schema === table.schema && row.table === table.table) ? true : false;
      const originalTable = this.originalState.find((origTable) => origTable.schema === table.schema && origTable.table === table.table);
      originalTable.newStatus = isTableSelected ? 'DISABLED_PENDING' : '';
    });
    this.selectedRows = [];
    this.populateSchemasAndTables();
  }

  getCaptureStatusIcon(captureStatus: string): string[] {
    let statusIcon = [];

    if (captureStatus) {
      switch (captureStatus) {
        case 'ENABLED_PENDING':
          statusIcon = ['png-alert-inprogress', 'text-success'];
          break;
        case 'DISABLED_PENDING':
          statusIcon = ['png-alert-inprogress', 'text-muted'];
          break;
        default:
          statusIcon = this.getStatusIconStyleClassList(captureStatus.toUpperCase());
      }
    }
    return statusIcon;
  }

  getCaptureStatusTooltip(captureStatus: string): string {
    let statusTooltip = '';

    if (captureStatus) {
      switch (captureStatus) {
        case 'ENABLED_PENDING':
        case 'DISABLED_PENDING':
        case 'ENABLED':
        case 'DISABLED':
          statusTooltip = 'pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TOOLTIP.' + captureStatus;
          break;
        default:
          statusTooltip = 'pipelines.PIPELINE_STATUS.CAPTURE_STATUS_TOOLTIP.' + captureStatus;
      }
    }
    return statusTooltip;
  }

  getCaptureStatusText(captureStatus: string): string {
    let statusText = '';

    if (captureStatus) {
      switch (captureStatus) {
        case 'ENABLED_PENDING':
        case 'DISABLED_PENDING':
          statusText = 'pipelines.SHARED.MANAGE_CAPTURE.CAPTURE_STATUS_TEXT.' + captureStatus;
          break;
        default:
          statusText = 'pipelines.PIPELINE_STATUS.' + captureStatus;
      }
    }
    return statusText;
  }

  onSchemaChange(selectedSchema): void {
    this.selectedSchema = selectedSchema;
    this.selectedRows.length = 0;
    this.populateSchemasAndTables();
  }

  filterSchemas(event) {
    const query = event.query.toLowerCase();
    this.manageCaptureTableConfiguration.caption.dropdown.options = this.schemas.filter(
      (schema) => schema.label.toLowerCase().indexOf(query) === 0
    );
  }

  get tablesEnabled(): string[] {
    return this.isSQLServer
      ? this.originalState
          .filter((table) => table.newStatus === 'ENABLED_PENDING')
          .map((table) => table.database + '.' + table.schema + '.' + table.table)
      : this.originalState.filter((table) => table.newStatus === 'ENABLED_PENDING').map((table) => table.schema + '.' + table.table);
  }

  get tablesDisabled(): string[] {
    return this.isSQLServer
      ? this.originalState
          .filter((table) => table.newStatus === 'DISABLED_PENDING')
          .map((table) => table.database + '.' + table.schema + '.' + table.table)
      : this.originalState.filter((table) => table.newStatus === 'DISABLED_PENDING').map((table) => table.schema + '.' + table.table);
  }

  private populateSchemasAndTables(): void {
    this.renderTable = false;
    const schemas = new Set();
    this.tableData = this.originalState.map((mapping) => {
      schemas.add(mapping.schema);
      return {
        database: mapping.database,
        schema: mapping.schema,
        table: mapping.table,
        captureStatus: mapping.newStatus ? mapping.newStatus : mapping.captureStatus,
        compositeKey: mapping.database + '.' + mapping.schema + '.' + mapping.table,
        originalStatus: mapping.captureStatus // only used to make table counting calculations easier
      };
    });
    this.schemas = [...schemas].map((schema) => ({ label: schema, value: schema }));
    this.schemas.unshift(this.allSchemaOption);
    if (this.selectedSchema.value !== this.allSchemaOption.value) {
      this.tableData = this.tableData.filter((mapping) => mapping.schema === this.selectedSchema.value);
    }
    this.updateStates();
    this.updateErrorMessageAndIcon();
    this.updateTableStatusCount();
    this.renderTable = true;
  }

  private updateTableStatusCount(): void {
    this.tablesCount = this.tableData.length;
    this.tablesEnabledCount = this.tableData.filter((mapping) => mapping.originalStatus === 'ENABLED').length;
    this.tablesDisabledCount = this.tableData.filter((mapping) => mapping.originalStatus === 'DISABLED').length;
    this.manageCaptureTableConfiguration.caption.templateContext = {
      totalCount: this.tablesCount,
      enabledCount: this.tablesEnabledCount,
      disabledCount: this.tablesDisabledCount
    };
  }

  private updateStates(): void {
    // TODO: need to check if project is stopped, currently the status API does not return project status
    this.manageCaptureTableConfiguration.disableCheckboxColumn =
      this.replicationStatus === 'IN_PROGRESS' || this.dataConnectionType === 'DB2ZOS';
    this.manageCaptureTableConfiguration.caption.dropdown.isHidden = this.schemas.length <= 2; // 2 because it includes the 'All Schemas' options
    this.pendingChanges.emit(this.areThereAnyPendingChanges);
  }

  private updateErrorMessageAndIcon(): void {
    // TODO: need to check if project is stopped, currently the status API does not return project status
    if (this.captureStatus === 'ACTION_REQUIRED') {
      this.errorMessage = 'pipelines.SHARED.MANAGE_CAPTURE.MESSAGES.ERROR_DURING_CAPTURE';
      this.errorMessageIcon = ['png-alert-actionrequired-solid', 'text-danger'];
    } /*else if (this.overallStatus === 'STOPPED') {
      this.errorMessage = 'pipelines.SHARED.MANAGE_CAPTURE.MESSAGES.PROJECT_IS_STOPPED';
      this.errorMessageIcon = ['png-alert-attention-solid', 'text-warning'];
    }*/ else if (this.replicationStatus === 'IN_PROGRESS') {
      this.errorMessage = 'pipelines.SHARED.MANAGE_CAPTURE.MESSAGES.REPLICATION_PROCESS_MUST_BE_STOPPED';
      this.errorMessageIcon = ['png-alert-attention-solid', 'text-warning'];
    } else {
      this.errorMessage = '';
      this.errorMessageIcon = [];
    }
  }

  private get areThereAnyPendingChanges(): boolean {
    return this.originalState.some((mapping) => mapping.newStatus);
  }
}
