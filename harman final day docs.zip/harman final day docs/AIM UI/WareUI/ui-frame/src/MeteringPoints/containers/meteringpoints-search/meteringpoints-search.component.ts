import { Component, OnDestroy, ViewChild, TemplateRef } from "@angular/core";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { Store } from "@ngrx/store";
import { Subscription, BehaviorSubject, Subject } from "rxjs";
import { XSFSearchActions } from "../../store/actions";
import { XSFSearchOverlayRef } from "../../../Shared/modules/xsf-search-overlay/xsf-search-overlay-ref";
import { XSFSearchOverlayService } from "../../../Shared/modules/xsf-search-overlay";
import { XSFSearchSelectors } from "../../store/selectors";

@Component({
    selector: "landisgyr-meteringpoints-search",
    templateUrl: "./meteringpoints-search.component.html",
    styleUrls: ["./meteringpoints-search.component.scss"]
})
export class MeteringpointsSearchContainerComponent implements OnDestroy {
    @ViewChild("originForXSFSearchOverlay")
    originForXSFSearchOverlay!: HTMLElement;

    @ViewChild("xsfSearchOverlayContent")
    xsfSearchOverlayContent!: TemplateRef<any>;

    xsfSearchOverlayRef!: XSFSearchOverlayRef;
    xsfSearchOverlayClosedSubscription!: Subscription;

    searchResultsCriteriaInformation$ = this.store.select(XSFSearchSelectors.getSearchResultsCriteriaInformation);
    mainInputPlaceholderText$ = this.store.select(XSFSearchSelectors.getMainInputPlaceholderText);
    defaultSearchField$ = this.store.select(XSFSearchSelectors.getDefaultSearchField);
    defaultSearchFieldLabel$ = this.store.select(XSFSearchSelectors.getDefaultSearchFieldLabel);
    mainInputValue$ = this.store.select(XSFSearchSelectors.getMainInputValue);

    xsfSearchFormValues$ = this.store.select(XSFSearchSelectors.getXSFSearchFormValues);
    isSearching$ = this.store.select(XSFSearchSelectors.isSearching);

    xsfSearchOverlayIsShown$: Subject<boolean> = new BehaviorSubject<boolean>(false);

    constructor(private store: Store<MeteringPointsFeatureState>, private xsfSearchOverlayService: XSFSearchOverlayService) {}

    onMainInputValue(mainInputValue: string) {
        if (mainInputValue.length > 0) {
            this.store.dispatch(XSFSearchActions.SearchByMainInputField({ value: mainInputValue }));
        } else {
            this.store.dispatch(XSFSearchActions.ClearMainInputFieldValue());
        }
    }

    onSearchFormSubmit(values: any) {
        this.store.dispatch(XSFSearchActions.SearchByXSFSearchForm({ formValues: values }));
        this.xsfSearchOverlayRef.close();
    }

    onDefaultSearchFieldChanged(key: string) {
        this.store.dispatch(XSFSearchActions.SetDefaultSearchField({ fieldName: key }));
    }

    openXSFSearchOverlay() {
        this.xsfSearchOverlayIsShown$.next(true);
        this.xsfSearchOverlayRef = this.xsfSearchOverlayService.show(
            { template: this.xsfSearchOverlayContent },
            this.originForXSFSearchOverlay
        );
        this.xsfSearchOverlayClosedSubscription = this.xsfSearchOverlayRef.closed$.subscribe(() => this.onXSFSearchOverlayClosed());
    }

    clearXSFSearch() {
        this.store.dispatch(XSFSearchActions.ClearXSFSearch());
    }

    private onXSFSearchOverlayClosed() {
        this.xsfSearchOverlayIsShown$.next(false);
        if (this.xsfSearchOverlayClosedSubscription) {
            this.xsfSearchOverlayClosedSubscription.unsubscribe();
        }
    }

    ngOnDestroy() {
        if (this.xsfSearchOverlayClosedSubscription) {
            this.xsfSearchOverlayClosedSubscription.unsubscribe();
        }
    }
}
