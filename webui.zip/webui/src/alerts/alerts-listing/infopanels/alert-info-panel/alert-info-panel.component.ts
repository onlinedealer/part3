import { DatePipe } from '@angular/common';
import { Component, Input } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { AlertMetricModel } from 'alerts/alert-metric.model';
import { AlertProfileMetricsService } from 'alerts/alert.profilemetrics.services';
import { AlertConstants } from 'alerts/alerts-listing/alert-constants';
import { showByPercentageCalculation } from 'alerts/alerts-listing/alerts-chart-config';
import { DistributionDetailsDialogComponent } from 'alerts/alerts-listing/distribution-details-dialog/distribution-details-dialog.component';
import { MetricDetailsModel } from 'alerts/metric-details.model';
import { Helper } from 'discovery-shared';
import { DialogService as PrimeNgDialogService } from 'primeng/dynamicdialog';
import { SharedConstants } from 'shared/shared.constant';
import { IConfigureMetric } from '../../../alert-dialog.type';
import { AlertModel } from '../../../alert.model';
import { ExportDialogComponent } from '../export-dialog/export-dialog.component';

@Component({
  selector: 'discovery-alert-info-panel',
  templateUrl: './alert-info-panel.component.html',
  styleUrls: ['./alert-info-panel.component.css']
})
export class AlertInfoPanelComponent {
  _alert: AlertModel;
  CRITICAL = AlertConstants.CRITICAL;
  WARNING = AlertConstants.WARNING;
  VOLUME = 'volume';
  DATA_DRIFT = 'data drift';
  uuidSeparator: string = '___';

  CARDINALITY_DETAIL = 'cardinality detail';

  CONFIDENCE_BASED = 'Confidence-based alerts';
  THRESHOLD_BASED = 'Threshold-based alerts';
  allowedMetricTypes = [AlertConstants.METRIC_TYPE.MAXIMUM_VALUE, AlertConstants.METRIC_TYPE.MINIMUM_VALUE];
  allowedMultiLineMetricType = [AlertConstants.METRIC_TYPE.CARDINALITY_DETAIL];
  trendMetric: string;
  persistConfiguredMetrics = new Map<string, IConfigureMetric>();
  chartLoading: boolean = true;
  trendCountLimit = AlertConstants.TRENDS_COUNT_LIMIT;
  showByPercentageData: any;

  get alert(): AlertModel {
    return this._alert;
  }

  @Input()
  set alert(val: AlertModel) {
    this._alert = val;
    this.loadDetailPanel();
  }

  get exportExcelFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.EXPORTTOEXCEL);
  }

  graphData: { [name: string]: any } = {};
  graphOptions: { [name: string]: any } = {};

  graphTimeframes: { [stat: string]: string } = {};
  metricsData: AlertMetricModel[] = [];
  newCardinalityChartData: { isNew: boolean; valueLength: number; metricName: string; alertReason: string }[] = [];
  externalLinkFlag: boolean;

  isShowPercentage: boolean = true;

  constructor(
    private alertMetricsService: AlertProfileMetricsService,
    private translocoService: TranslocoService,
    private dialogService: PrimeNgDialogService,
    private launchDarklyService: LaunchDarklyService,
    private datePipe: DatePipe
  ) {
    this.externalLinkFlag = this.getExternalLinks();
  }

  loadChartOptions(metricName: string, metricType: string, isNew?: boolean): void {
    let dateOnYaxis: boolean = false;

    if (this.alert.columnType) {
      if (
        this.alert.columnType === AlertConstants.COLUMN_TYPE.DATE ||
        this.alert.columnType === AlertConstants.COLUMN_TYPE.DATETIME ||
        this.alert.columnType === AlertConstants.COLUMN_TYPE.TIMESTAMP
      ) {
        dateOnYaxis = true;
      } else {
        dateOnYaxis = false;
      }
    }

    let metricNewName = isNew ? `${metricName}_new` : metricName;
    this.graphOptions[metricNewName] = {
      plugins: {
        tooltip: {
          callbacks: {
            title: (tooltipItems) => this.tooltipText(tooltipItems, metricName, metricType, isNew),
            label: () => this.label(),
            footer: this.dateFormate
          }
        },
        legend: {
          display: true,
          position: 'bottom',
          labels: {
            boxWidth: 15,
            boxHeight: 15,
            filter: (item) => this.showLegend(item)
          },
          align: 'start',
          onClick: () => {
            //empty function to disable stike out legend
          }
        }
      },
      scales: {
        x: {
          title: {
            display: true,
            align: 'end',
            text: this.translocoService?.translate('discoveryAlerts.infoPanel.stats.xAxisLabel')
          },
          ticks: {
            callback: function (val, index) {
              let formatDate = Helper.getConvertedDateOnToolTip(this.getLabelForValue(val));
              return formatDate.date + '/' + formatDate.shortMonth + '/' + formatDate.year;
            },
            source: 'auto',
            color: SharedConstants.CHARTFONTSCOLORS.TICKS,
            display: true
          },
          grid: {
            display: false,
            drawOnChartArea: false,
            drawTicks: false,
            color: SharedConstants.CHARTFONTSCOLORS.GRID
          }
        },
        y: {
          title: {
            display: true,
            align: 'end',
            text: metricName
          },
          ticks: {
            color: SharedConstants.CHARTFONTSCOLORS.TICKS,
            display: true,
            stepSize: 1,
            callback: (label) => this.yAxisLabel(label, metricType, dateOnYaxis, isNew)
          },
          grid: {
            drawTicks: false,
            color: '#f2f2f2'
          }
        }
      }
    };
  }

  loadDetailPanel(): void {
    this.chartLoading = true;
    this.graphTimeframes = {};
    this.graphData = {};
    this.graphOptions = {};
    let newValueLineChart = [];
    let historicalValueLineChart = [];
    this.newCardinalityChartData = [];
    let newValueReason: string;

    const allAvailableMetrics: AlertMetricModel[] = this.getAlertMetrics();
    allAvailableMetrics.forEach((metric) => {
      // if metric type is cardinality detail then we are creating 2 seprate array based on new and historic values
      if (this.allowedMultiLineMetricType.includes(metric.metricType)) {
        metric.metricDetails.forEach((detail: MetricDetailsModel) => {
          if (detail.isNew) {
            newValueLineChart.push(detail.sampleKey);
            newValueReason = detail.alertReason;
          } else {
            historicalValueLineChart.push(detail.sampleKey);
          }
        });
        // based on new and historic values we are creating 1 more array which will contain length of new values and metricType
        // this array will show new chart for cardinality details
        if (newValueLineChart.length > 0) {
          this.newCardinalityChartData.push({
            isNew: true,
            valueLength: newValueLineChart.length,
            metricName: metric.metricName,
            alertReason: newValueReason
          });

          this.setupStatGraph(
            metric,
            this.alert.assetUid,
            new Date(this.alert.raisedAt),
            newValueLineChart.toString(),
            true
          );
        }
        if (historicalValueLineChart.length > 0) {
          this.setupStatGraph(
            metric,
            this.alert.assetUid,
            new Date(this.alert.raisedAt),
            historicalValueLineChart.toString(),
            false
          );
        }
      } else {
        this.setupStatGraph(metric, this.alert.assetUid, new Date(this.alert.raisedAt));
      }
      newValueLineChart = [];
      historicalValueLineChart = [];
    });
  }

  getExternalLinks(): boolean {
    return this.launchDarklyService?.variation<boolean>(SharedConstants.featureFlags.HACK_DEMO);
  }

  showImpactedStatsLinks(): boolean {
    return (
      (this.alert.confidenceAlertMetrics !== undefined && this.alert.confidenceAlertMetrics.length > 1) ||
      (this.alert.thresholdAlertMetrics !== undefined && this.alert.thresholdAlertMetrics.length > 1)
    );
  }

  showImpactedStats(): boolean {
    return this.alert.alertType.toLowerCase() !== this.VOLUME; // && this.alert.impactedStatistics.length > 0;
  }

  showSampleKey(stat: string): boolean {
    return stat && stat.toLowerCase() === this.CARDINALITY_DETAIL;
  }

  getAlertReason(reasonKey: string) {
    if (reasonKey) {
      return this.translocoService?.translate('discoveryAlerts.infoPanel.stats.reasons.' + reasonKey);
    }
  }

  getAlertMetrics(): any[] {
    let metricReturnData = [];
    if (this.alert.alertConfiguration === this.CONFIDENCE_BASED) {
      metricReturnData = this.alert.confidenceAlertMetrics;
    }

    if (this.alert.alertConfiguration === this.THRESHOLD_BASED) {
      metricReturnData = this.alert.thresholdAlertMetrics;
    }
    this.metricsData = [];
    for (let iterator of metricReturnData) {
      //if metric type is cardinality detail then we will have a object with metricName, metricType and metricDetail which will contain object with highest probablity
      // this metricsData is used to show header info of charts
      if (!this.allowedMultiLineMetricType.includes(iterator.metricType)) {
        this.metricsData.push(iterator);
      } else {
        let detailData = [
          { probability: 0, currentMetric: '', alertLevel: '', comparisonMetric: '', sampleKey: '', alertReason: '' }
        ];
        let keyArray = [];
        for (const detail of iterator?.metricDetails) {
          keyArray.push({ sampleKey: detail.sampleKey, isNew: detail.isNew, alertReason: detail.alertReason });
          detailData = detail.probability > detailData[0].probability ? [{ ...detail }] : detailData;
        }

        detailData[0].sampleKey = Array.from(
          keyArray.filter((key) => !key.isNew && key.sampleKey),
          (item) => {
            detailData[0].alertReason = item.alertReason;
            return item.sampleKey;
          }
        ).toString();

        this.metricsData.push({
          metricType: iterator.metricType,
          metricName: iterator.metricName,
          metricDetails: detailData
        });
      }
    }
    return metricReturnData;
  }

  getMetricsHistoryDataSet(
    assetId: string,
    metric: AlertMetricModel,
    timeframe: string,
    alertDate?: Date,
    sampleKey?: string,
    isNew?: boolean
  ): any {
    let labels: Date[] = [];
    // value for y-axis on chart could be number or date so we are setting its type as any
    let values: any[] = [];

    const fromDate = Helper.getFromDate(timeframe, alertDate);

    this.alertMetricsService
      .getTrendsHistory(assetId, metric.metricType, fromDate, alertDate, sampleKey, this.trendCountLimit)
      .subscribe((trends) => {
        let staticKeyArray = sampleKey ? sampleKey.split(',') : [];
        let sampleKeyArray = [...staticKeyArray];
        let finalValues = new Map();
        let trendTotalCountArray: number[] = [];
        sampleKeyArray.forEach((item) => {
          finalValues.set(item, []);
        });
        trends.forEach(
          (element: {
            startTime: string;
            value?: number;
            details?: Array<{ key: string; value: string }>;
            totalCount?: number;
          }) => {
            let dataPointDate = new Date(element.startTime);
            labels.push(dataPointDate);
            // valuePoints could be number or Date or anyother datatype
            sampleKeyArray = [...staticKeyArray];
            let valuePoints = this.getTrendsValue(element, metric.metricType, sampleKeyArray, finalValues);
            values = this.populateChartValues(values, valuePoints, metric.metricType, isNew);
            if (metric.metricType === AlertConstants.METRIC_TYPE.CARDINALITY_DETAIL && !isNew) {
              trendTotalCountArray.push(element.totalCount);
            }
          }
        );
        if (metric.metricType === AlertConstants.METRIC_TYPE.CARDINALITY_DETAIL && !isNew) {
          this.showByPercentageData = {
            labels,
            values,
            alertDate,
            isNew,
            trendTotalCountArray
          };
        }
        this.setGraphData(metric, labels, values, alertDate, isNew);
      });
  }

  populateChartValues(values: any[], point: any, metricType: string, isNew?: boolean) {
    // based on valuePoint and metric type push the chart value to values array
    // in case of cardinality detail value point will be type of map
    if (this.allowedMultiLineMetricType.includes(metricType) && point && point.size > 0) {
      let data = [];
      for (const [key, value] of point) {
        let checkAllNull = value.every((element) => element === null);
        if (!checkAllNull) {
          data.push({ label: key, value: value });
        }
      }
      values = data;
    } else {
      values.push(point);
    }

    return values;
  }

  scrollToStat(statId: string) {
    document.getElementById(statId).scrollIntoView({
      behavior: 'smooth',
      block: 'start',
      inline: 'nearest'
    });
  }

  scroll(id) {
    const elmnt = document.getElementById(id);
    elmnt.scrollIntoView({ behavior: 'smooth', block: 'start', inline: 'nearest' });
  }

  updateTrendsInfo($event: Event, metric: AlertMetricModel, sampleKey?: string) {
    this.chartLoading = true;
    let timeFrame = ($event.target as HTMLInputElement).value;

    this.getMetricsHistoryDataSet(this.alert.assetUid, metric, timeFrame, new Date(this.alert.raisedAt), sampleKey);
  }

  getTrendsValue(
    element: { startTime: string; value?: number; details?: Array<{ key: string; value: string }> },
    metricType: string,
    sampleKeyArray?: string[],
    finalValues?
  ) {
    if (
      this.allowedMetricTypes.includes(metricType) &&
      (this.alert?.columnType === AlertConstants.COLUMN_TYPE.DATE ||
        this.alert?.columnType === AlertConstants.COLUMN_TYPE.DATETIME ||
        this.alert?.columnType === AlertConstants.COLUMN_TYPE.TIMESTAMP)
    ) {
      return new Date(element.value);
    } else if (this.alert?.columnType === AlertConstants.COLUMN_TYPE.TIME) {
      let timeArray = element.value.toString().split(':');
      return +timeArray[0] * 60 * 60 + +timeArray[1] * 60 + +timeArray[2];
    } else if (this.allowedMultiLineMetricType.includes(metricType) && element.details && element.details.length > 0) {
      for (const item of element.details) {
        if (sampleKeyArray.includes(item.key)) {
          let index = sampleKeyArray.indexOf(item.key);
          finalValues.set(item.key, [...finalValues.get(item.key), item.value]);
          sampleKeyArray.splice(index, 1);
        }
      }
      sampleKeyArray.forEach((ele) => {
        finalValues.set(ele, [...finalValues.get(ele), null]);
      });
      return finalValues;
    } else {
      return element.value;
    }
  }

  tooltipText(tooltipItems, metric, metricType, isNew) {
    if (
      this.allowedMetricTypes.includes(metricType) &&
      (this.alert.columnType === AlertConstants.COLUMN_TYPE.DATE ||
        this.alert.columnType === AlertConstants.COLUMN_TYPE.DATETIME ||
        this.alert.columnType === AlertConstants.COLUMN_TYPE.TIMESTAMP)
    ) {
      const convertedDate = Helper.getConvertedDateOnToolTip(tooltipItems[0].parsed.y);
      switch (this.alert?.columnType) {
        case AlertConstants.COLUMN_TYPE.DATE:
          return `${metric}: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}`;
        case AlertConstants.COLUMN_TYPE.DATETIME:
        case AlertConstants.COLUMN_TYPE.TIMESTAMP:
          return `${metric}: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}, ${convertedDate.hour}:${convertedDate.min}:${convertedDate.sec}`;
      }
    } else if (this.alert?.columnType === AlertConstants.COLUMN_TYPE.TIME) {
      let value = parseInt(tooltipItems[0].formattedValue);
      let time = new Date(value * 1000).toISOString().slice(11, 19);
      return `${metric}: ${time}`;
    } else if (this.allowedMultiLineMetricType.includes(metricType)) {
      if (
        tooltipItems[0].dataset &&
        tooltipItems[0].dataset.label &&
        tooltipItems[0].dataset.label.length &&
        this.isShowPercentage &&
        !isNew
      ) {
        return `Value: ${tooltipItems[0].dataset.label}\n${metric}: ${tooltipItems[0].formattedValue}%`;
      } else if (tooltipItems[0].dataset && tooltipItems[0].dataset.label && tooltipItems[0].dataset.label.length) {
        return `Value: ${tooltipItems[0].dataset.label}\n${metric}: ${tooltipItems[0].formattedValue}`;
      } else return `${metric}: ${tooltipItems[0].formattedValue}`;
    } else {
      return `${metric}: ${tooltipItems[0].formattedValue}`;
    }
  }

  dateFormate(tooltipItems) {
    const convertedDate = Helper.getConvertedDateOnToolTip(tooltipItems[0].label);
    return `Date: ${convertedDate.date} ${convertedDate.longMonth} ${convertedDate.year}, ${convertedDate.hour}:${convertedDate.min}:${convertedDate.sec}`;
  }

  label() {
    return '';
  }

  yAxisLabel(label, metricType: string, dateOnYaxis: boolean, isNew?: boolean) {
    // columnType is optional parameter which would usually be available in Data Drift rule config
    if (this.allowedMetricTypes.includes(metricType) && dateOnYaxis) {
      const formatDate = Helper.getConvertedDateOnToolTip(label);
      return formatDate.date + '/' + formatDate.shortMonth + '/' + formatDate.year;
    } else if (this.alert?.columnType === AlertConstants.COLUMN_TYPE.TIME) {
      return new Date(label * 1000).toISOString().slice(11, 19);
    } else if (metricType == AlertConstants.METRIC_TYPE.CARDINALITY_DETAIL && this.isShowPercentage && !isNew) {
      return label <= 100 ? label + '%' : '';
    } else {
      return label;
    }
  }

  showLegend(item) {
    if (item.text?.length > 0) {
      return true;
    }
  }

  getHighlightedIndex(xAxisLabel: Date[], raiseOnDate: Date) {
    raiseOnDate.setSeconds(0, 0);
    return xAxisLabel.findIndex((item) => {
      let tempDate = new Date(item);
      tempDate.setSeconds(0, 0);
      if (tempDate.getTime() >= raiseOnDate.getTime()) {
        return item;
      }
    });
  }

  highlightLineSegment(ctx, xAxisLabel: Date[], raiseOnDate: Date, criticalColor, isNew?: boolean) {
    let highlightIndex = this.getHighlightedIndex(xAxisLabel, raiseOnDate);
    if ((ctx.p1DataIndex === highlightIndex || ctx.p0DataIndex === highlightIndex - 1) && !isNew) {
      return criticalColor;
    } else {
      return undefined;
    }
  }

  showExportDialog() {
    this.dialogService.open(ExportDialogComponent, {
      header: this.translocoService?.translate('discoveryAlerts.infoPanel.exportToExcel'),
      data: { alertId: this.alert.id, toDate: new Date(this.alert.raisedAt), assetName: this.alert.assetName }
    });
  }

  highlightPointStyling(
    ctx,
    xAxisLabel: Date[],
    raiseOnDate: Date,
    successValue,
    failureValue,
    isNew: boolean = false
  ) {
    let highlightIndex = this.getHighlightedIndex(xAxisLabel, raiseOnDate);
    if (!isNew && (ctx.dataIndex === highlightIndex || ctx.dataIndex === highlightIndex - 1)) {
      return successValue;
    } else {
      return failureValue;
    }
  }

  openDetailedDialogBox(metric: AlertMetricModel, timeFrameValue: string, sampleKey) {
    const assetName = this.alert.assetName;
    const metricDetails: MetricDetailsModel = metric.metricDetails[0];
    const probability = metricDetails?.probability
      ? metricDetails.probability.toFixed(2)
      : metricDetails?.percentageChange?.toFixed(2) || 0;

    const selectedSampleKeys = this.graphData[metric.metricName]?.datasets?.map(({ label }) => label).join(',');
    const dialogRef = this.dialogService.open(DistributionDetailsDialogComponent, {
      width: '95%',
      height: '90%',
      showHeader: false,
      contentStyle: { padding: '0' },
      data: {
        assetName,
        probability,
        metric: metric,
        alertLevel: metricDetails.alertLevel,
        alertReason: metricDetails.alertReason,
        timeframe: timeFrameValue,
        alert: this.alert,
        allSampleKeys: sampleKey,
        selectedSampleKeys: selectedSampleKeys,
        isSampled: metricDetails.isSampled,
        isShowPercentage: this.isShowPercentage
      }
    });

    dialogRef.onClose.subscribe((data: IConfigureMetric) => {
      if (data.action !== 'close') {
        this.chartLoading = true;
        this.updateStateForSavedMetrics(this.alert.assetUid, data);
      }
    });
  }

  /**
   *
   * @param assetUid
   * @param data Passed back after changes are configured in dialog
   * Call API and Refresh the Data on small Chart
   * Set the value in Map with Unique key
   */
  updateStateForSavedMetrics(assetUid: string, data: IConfigureMetric) {
    this.persistConfiguredMetrics.set(assetUid + this.uuidSeparator + data.metric.metricName, data);
    this.graphTimeframes[data.metric.metricName] = data.timeframe;
    this.isShowPercentage = data.isShowPercentage;
    // refresh Data on the list
    this.getMetricsHistoryDataSet(
      this.alert.assetUid,
      data.metric,
      data.timeframe,
      new Date(this.alert.raisedAt),
      data.selectedSample
    );
  }

  /**
   * Check if passed data already has persisted/configured state
   * if Yes then return persisted value or else return the passed object
   */
  checkPersistedState(
    assetUid: string,
    metric: AlertMetricModel,
    sampleKey: string,
    timeframe: string
  ): { selectedSample: string; timeframe: string } {
    const uniqueKey = assetUid + this.uuidSeparator + metric.metricName;
    const record: IConfigureMetric = this.persistConfiguredMetrics.get(uniqueKey);
    if (record) {
      return {
        selectedSample: record.selectedSample,
        timeframe: record.timeframe
      };
    }
    return {
      selectedSample: sampleKey,
      timeframe: timeframe
    };
  }

  /**
   * this function is updating graphData with values based on checkbox either percentage or number
   * @param metric
   */

  populateChartValueByPercentage(metric) {
    if (this.showByPercentageData?.trendTotalCountArray?.length) {
      let chartData = showByPercentageCalculation(this.showByPercentageData, metric, this.isShowPercentage);
      let dataSets = this.plotCardinalityDetailChart(
        chartData.values,
        chartData.lables,
        chartData.raisedOnDate,
        chartData.criticalColor,
        chartData.isNew
      );
      this.graphData[metric.metricName] = {
        labels: this.showByPercentageData.labels,
        datasets: dataSets
      };
    }
  }

  private setGraphData(metric: AlertMetricModel, labels: any, data: any, raiseOnDate: Date, isNew?: boolean) {
    let currentMetric = this.metricsData?.find((item) => {
      if (item.metricName === metric.metricName) {
        return item;
      }
    });
    let criticality = currentMetric.metricDetails[0].alertLevel;
    let dataSets = [];
    let percentageValuesLoaded = false;
    let criticalColor =
      this.CRITICAL === criticality ? AlertConstants.HIGHLIGHT_COLOR.CRITICAL : AlertConstants.HIGHLIGHT_COLOR.WARNING;
    if (this.allowedMultiLineMetricType.includes(metric.metricType) && this.isShowPercentage && !isNew) {
      this.populateChartValueByPercentage(currentMetric);
      percentageValuesLoaded = true;
    } else if (this.allowedMultiLineMetricType.includes(metric.metricType)) {
      dataSets = this.plotCardinalityDetailChart(data, labels, raiseOnDate, criticalColor, isNew);
    } else {
      dataSets = [
        {
          label: '',
          data: data,
          barThickness: 20,
          maxBarThickness: 20,
          borderColor: '#AC72F9',
          backgroundColor: '#AC72F9',
          segment: {
            borderColor: (ctx) => this.highlightLineSegment(ctx, labels, raiseOnDate, criticalColor)
          },
          pointStyle: (ctx) => this.highlightPointStyling(ctx, labels, raiseOnDate, 'rect', 'circle'),
          pointRadius: (ctx) => this.highlightPointStyling(ctx, labels, raiseOnDate, 6, 3),
          pointBackgroundColor: (ctx) => this.highlightPointStyling(ctx, labels, raiseOnDate, criticalColor, '#AC72F9'),
          pointBorderColor: (ctx) => this.highlightPointStyling(ctx, labels, raiseOnDate, criticalColor, '#AC72F9'),
          lineTension: 0
        }
      ];
    }

    let metricNewName = isNew ? `${metric.metricName}_new` : metric.metricName;
    if (!percentageValuesLoaded) {
      this.graphData[metricNewName] = {
        labels: labels,
        datasets: dataSets
      };
    }
    this.chartLoading = false;
  }

  private plotCardinalityDetailChart(data, labels, raiseOnDate, criticalColor, isNew) {
    const legendColors = AlertConstants.MULTILINE_COLORS;
    let plotData = [];
    for (const [index, point] of data.entries()) {
      plotData.push({
        label: point?.label,
        data: point?.value,
        barThickness: 20,
        maxBarThickness: 20,
        borderColor: legendColors[index],
        backgroundColor: legendColors[index],
        segment: {
          borderColor: (ctx) => this.highlightLineSegment(ctx, labels, raiseOnDate, criticalColor, isNew)
        },
        pointStyle: (ctx) => this.highlightPointStyling(ctx, labels, raiseOnDate, 'rect', 'circle', isNew),
        pointRadius: (ctx) => this.highlightPointStyling(ctx, labels, raiseOnDate, 6, 3, isNew),
        pointBackgroundColor: (ctx) =>
          this.highlightPointStyling(ctx, labels, raiseOnDate, criticalColor, legendColors[index], isNew),
        pointBorderColor: (ctx) =>
          this.highlightPointStyling(ctx, labels, raiseOnDate, criticalColor, legendColors[index], isNew),
        spanGaps: true,
        lineTension: 0
      });
    }
    return plotData;
  }

  private setupStatGraph(
    metric: AlertMetricModel,
    assetUid: string,
    alertDate?: Date,
    sampleKey?: string,
    isNew?: boolean
  ) {
    let timeframe = 'week';
    const output = this.checkPersistedState(assetUid, metric, sampleKey, timeframe);
    this.graphTimeframes[metric.metricName] = timeframe = output.timeframe;
    sampleKey = output.selectedSample;

    this.getMetricsHistoryDataSet(assetUid, metric, timeframe, alertDate, sampleKey, isNew);
    this.loadChartOptions(metric.metricName, metric.metricType, isNew);
  }
}
