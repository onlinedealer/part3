import { Component, OnInit, Input } from '@angular/core';
import { ClubConstantsService } from '../../utility/club-constants.service';
import { StringifyOptions } from 'querystring';

@Component({
  selector: 'club-generic-error',
  templateUrl: './club-generic-error.component.html',
  styleUrls: ['./club-generic-error.component.scss']
})
export class ClubGenericErrorComponent implements OnInit {

  @Input() errorType: string;

  // This is the text that is displayed below the generic error service modal.
  errorMessageText: String = '';
  tryAgain: String = '';
  headerText: String = '';

  constructor(
    private _constants: ClubConstantsService
  ) { }

  ngOnInit() {
    this.tryAgain = this._constants.getCVSClubGenericMessages().tryAgainBtnText;
    if (this.errorType === 'validationLinkExpired') {
      this.errorMessageText = this._constants.getClubCompletionErrorMessages().validationLinkExpired;
      this.headerText = this._constants.getClubCompletionErrorMessages().validationLinkExpiredHeader;
    } else if (this.errorType === 'genericSerice') {
      this.errorMessageText = this._constants.getCVSClubGenericMessages().genericError;
      this.headerText = this._constants.getCVSClubGenericMessages().headerText;
    } else if (this.errorType === 'accountLocked') {
      this.headerText = this._constants.getClubCompletionErrorMessages().accountLockedHeader;
      this.errorMessageText = this._constants.getClubCompletionErrorMessages().accountLocked;
    }
  }
  refreshPage() {
    window.location.reload(true);
  }
}
