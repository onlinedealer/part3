import { Component, Input, OnInit } from '@angular/core';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { SharedConstants as ProfilingConstants } from 'discovery-shared';
import { PatternGroupModel } from './pattern-group-model';
import { TextPatternModel } from './text-pattern-model';
import { TranslocoService } from '@ngneat/transloco';
@Component({
  selector: 'discovery-text-pattern',
  templateUrl: './text-pattern.component.html',
  styleUrls: ['./text-pattern.component.css']
})
export class TextPatternComponent implements OnInit {
  @Input()
  treePath: TreePath;
  @Input()
  statistics: Map<string, any>;

  tableValues: TextPatternModel[];
  cols: any[];
  defaultSort: string;
  constructor(private translocoService: TranslocoService) {}

  ngOnInit(): void {
    this.loadData();
  }

  private loadData(): void {
    if (this.treePath.columnView) {
      if (this.statistics['type'] === ProfilingConstants.STATS.TEXTPATTERN) {
        this.cols = [
          {
            field: '',
            header: '',
            width: '5%'
          },
          {
            field: 'pattern',
            header: this.translocoService.translate('discoveryProfiling.results.patternColumn'),
            width: '30%'
          },
          {
            field: 'regex',
            header: this.translocoService.translate('discoveryProfiling.results.regexColumn'),
            width: '30%'
          },
          {
            field: 'count',
            header: this.translocoService.translate('discoveryProfiling.results.countColumn'),
            width: '15%'
          },
          {
            field: 'percentage',
            header: this.translocoService.translate('discoveryProfiling.results.percentageColumn'),
            width: '20%'
          }
        ];
        this.defaultSort = 'count';
        const statsArray: any = this.statistics['groups'];
        this.tableValues = [];
        let totalSum: number = 0;
        for (let groupIndex = 0; groupIndex < this.statistics['groups'].length; groupIndex++) {
          const childs: TextPatternModel[] = [];
          let sum: number = 0;
          for (const key in statsArray[groupIndex].patterns) {
            if (key !== '') {
              for (const subGroupkey in statsArray[groupIndex].patterns[key]) {
                if (key !== '') {
                  sum += statsArray[groupIndex].patterns[key][subGroupkey];
                  childs.push(
                    new TextPatternModel(
                      new PatternGroupModel(key, subGroupkey, statsArray[groupIndex].patterns[key][subGroupkey], 0),
                      null
                    )
                  );
                }
              }
            }
          }
          totalSum += sum;
          const group: PatternGroupModel = new PatternGroupModel(
            statsArray[groupIndex].groupPattern,
            statsArray[groupIndex].groupRegex,
            sum,
            0
          );
          this.setPercentage(childs, sum);
          const model = new TextPatternModel(group, childs);
          this.tableValues.push(model);
        }
        this.setPercentage(this.tableValues, totalSum);
      }
    }
  }

  private setPercentage(node: TextPatternModel[], sum: number): void {
    if (node != null) {
      for (const iterator of node) {
        iterator.data.percentage = (iterator.data.count / sum) * 100;
      }
    }
  }
}
