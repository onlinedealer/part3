import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { MockSidebarComponent } from '../../../shared/components/sidebar/mock-sidebar.component.spec';
import { DataFlowsEntity, PipelinesMonitoringStatus } from '../../shared/pipelines-monitoring-status';
import { ConnectionDetailsSidebarComponent } from './connection-details-sidebar.component';

describe('ConnectionDetailsSidebarComponent', () => {
  let component: ConnectionDetailsSidebarComponent;
  let fixture: ComponentFixture<ConnectionDetailsSidebarComponent>;

  const mockPipelinesMonitoringStatus: PipelinesMonitoringStatus = {
    type: 'monitoringProjectStatus',
    projectId: '61ae6e1abfb2cd1777a98edd',
    id: '61ae6e1abfb2cd1777a98edd',
    changes: 'UP_TO_DATE',
    generationTimestamp: 1638824922,
    currentEmailRuntimeServer: '',
    dataFlows: [
      {
        name: 'test',
        captureStatus: 'OK',
        dataFlowType: 'SYNCHRONIZE',
        backlogRows: {
          timestamp: 1648907331971,
          pendingTransactions: 0,
          pendingRows: 0
        },
        runtimeServers: [
          {
            dataConnections: [
              {
                connectionType: 'KAFKA',
                logReaders: [],
                name: 'HJ11(2)',
                source: false,
                target: true
              },
              {
                connectionType: 'DB2I',
                logReaders: [
                  {
                    journal: 'GISLARDJ/JRNRCV0037',
                    name: 'GISLARDJ/TSTJRN',
                    sequence: '00000000000000000045',
                    status: 'OK'
                  }
                ],
                name: 'LTIAS08',
                source: true,
                target: false
              }
            ]
          }
        ]
      } as DataFlowsEntity
    ],
    versions: [
      {
        committedVersion: 5,
        deployedVersion: 5,
        serverName: 'Docker'
      }
    ]
  };

  const mockSelectedPipeline: any = {
    projectId: '61ae6e1abfb2cd1777a98edd',
    name: 'test',
    captureStatus: 'UNKNOWN',
    dataFlowType: 'REPLICATE',
    runtimeServers: [
      {
        dataConnections: [
          {
            connectionType: 'KAFKA',
            logReaders: [],
            name: 'HJ11(2)',
            source: false,
            target: true
          },
          {
            connectionType: 'DB2I',
            logReaders: [
              {
                journal: 'GISLARDJ/JRNRCV0037',
                name: 'GISLARDJ/TSTJRN',
                sequence: '00000000000000000045',
                status: 'OK'
              }
            ],
            name: 'LTIAS08',
            source: true,
            target: false
          }
        ]
      }
    ]
  };

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      declarations: [ConnectionDetailsSidebarComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(ConnectionDetailsSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should select the connectiona and call the sidebar open function', () => {
    spyOn(component.sidebarComponent, 'open').and.returnValue();
    const expectedSelectedConnection = mockSelectedPipeline.runtimeServers[0].dataConnections[1];
    const projectName = 'connect_saas_beta_abc';
    component.open(mockSelectedPipeline, 'LTIAS08', projectName);
    expect(component.selectedConnection).toEqual(expectedSelectedConnection);
    expect(component.primaryButton.isDisabled).toBe(expectedSelectedConnection.target);
    expect(component.projectName).toBe(projectName);
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should call the sidebar close function when the cancel button is clicked', () => {
    spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.cancelButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should emit event to open the alerts modal', () => {
    spyOn(component.refreshEvent, 'emit');
    component.primaryButtonClicked();
    expect(component.refreshEvent.emit).toHaveBeenCalled();
  });
});
