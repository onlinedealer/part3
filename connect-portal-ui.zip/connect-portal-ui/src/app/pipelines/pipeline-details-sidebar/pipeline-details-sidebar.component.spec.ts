import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { MockSidebarComponent } from '../../shared/components/sidebar/mock-sidebar.component.spec';
import { PipelineDetailsFormComponent } from './pipeline-details-form/pipeline-details-form.component';
import { PipelineDetailsSidebarComponent } from './pipeline-details-sidebar.component';

describe('PipelineDetailsSidebarComponent', () => {
  let component: PipelineDetailsSidebarComponent;
  let fixture: ComponentFixture<PipelineDetailsSidebarComponent>;

  @Component({
    selector: 'p-connect-pipeline-details-form',
    template: '',
    providers: [
      {
        provide: PipelineDetailsFormComponent,
        useClass: MockPipelineDetailsFormComponent
      }
    ]
  })
  class MockPipelineDetailsFormComponent {}

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      declarations: [PipelineDetailsSidebarComponent, MockSidebarComponent, MockPipelineDetailsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipelineDetailsSidebarComponent);
    component = fixture.componentInstance;
    component.selectedPipeline = {
      id: '1',
      name: 'test',
      description: '',
      dataFlowType: 'SYNCHRONIZE',
      properties: [],
      filters: []
    };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call the sidebar open function', () => {
    spyOn(component.sidebarComponent, 'open').and.returnValue();
    component.open({});
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should call the sidebar close function when the cancel button is clicked', () => {
    spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.cancelButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should emit an event when the refresh button is clicked', () => {
    spyOn(component.primaryButtonClickedEvent, 'emit').and.returnValue();
    component.primaryButtonClicked();
    expect(component.primaryButtonClickedEvent.emit).toHaveBeenCalledWith(component.selectedPipeline);
  });

  it('should emit event to open the alerts modal', () => {
    spyOn(component.alertsButtonClickEvent, 'emit');
    component.alertsButtonClicked();
    expect(component.alertsButtonClickEvent.emit).toHaveBeenCalled();
  });
});
