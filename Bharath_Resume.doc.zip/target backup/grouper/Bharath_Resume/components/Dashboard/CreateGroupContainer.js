import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { withStyles } from '@material-ui/core/styles'
import AppBar from '@material-ui/core/AppBar'
import Tabs from '@material-ui/core/Tabs'
import Tab from '@material-ui/core/Tab'
import Typography from '@material-ui/core/Typography'
import CreateVariation from './CreateVariation'
import CreateCollection from './CreateCollection'
import CreateBundle from './CreateBundle'
import { getGrouperTypes, getItemTypes, getItemThemes, clearItemThemes, addGroup, clearActionTypes, clearErrorTcins, getCollectionItemTypes } from '../../store/Dashboard/actionCreator'

function TabContainer (props) {
  return (
    <Typography component="div" style={{ padding: '10px 0px' }}>
      {props.children}
    </Typography>
  )
}

TabContainer.propTypes = {
  children: PropTypes.node.isRequired,
}

const styles = theme => ({
  root: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.paper,
  },
  tabs: {
    background: '#fff',
    color: '#1976D2',
  },
  tabStyle: {
    minWidth: 150,
    background: '#fff',
  },
  tabStyleSelected: {
    minWidth: 150,
    backgroundColor: '#E4EFFA',
  },
  heading: {
    fontSize: 18,
    fontWeight: 500,
    marginBottom: 10,
  },
  tabsBoxShadow: {
    boxShadow: 'none',
  },
  selectGroupTypeStyle: {
    marginTop: 25,
    marginBottom: 5,
    fontSize: 13,
    fontWeight: 500,
  },
})

class CreateGroupContainer extends React.Component {
  state = {
    value: '',
    groupTypes: [],
  };

  componentWillMount () {
    this.getNewFilter(this.props.groupTypes)
  }
  componentWillReceiveProps (nextProps) {
    // this.getNewFilter(nextProps.groupTypes)
  }
  getNewFilter = (origin) => {
    if (origin.length > 0) {
      const newFilter = _.filter(origin, function (obj) {
        return obj.status
      })
      var temp = {id: 4, name: 'bundle', status: true}
      newFilter.push(temp)
      this.setState({ value: newFilter[0].name, groupTypes: newFilter })
    }
  }

  componentDidMount () {
    if (this.props.groupTypes.length === 0) {
      this.props.getGrouperTypes()
    }
  }

  handleChange = (event, value) => {
    this.setState({ value })
  };

  render () {
    const { classes } = this.props
    const { value, groupTypes } = this.state

    return (
      <div className={classes.root}>
        <div item xs={12} className={classes.heading}>
            Create Group
        </div>
        <div className={classes.selectGroupTypeStyle}>
          Select Group Type
        </div>
        <AppBar position="static" className={classes.tabsBoxShadow}>
          <Tabs value={value} onChange={this.handleChange} className={classes.tabs}>
            {groupTypes.map((option, key) => {
              return (<Tab value={option.name} key={key} label={option.name} className={(value === option.name) ? classes.tabStyleSelected : classes.tabStyle} />)
            })}
          </Tabs>
        </AppBar>
        {value === 'variation' &&
        <TabContainer>
          <CreateVariation
            closeDrawer={this.props.closeDrawer}
            loadingBtnStatus={this.props.loadingBtnStatus}
            requestType={this.props.requestType}
            recentAddedGroup={this.props.recentAddedGroup}
          />
        </TabContainer>}
        {value === 'collection' &&
        <TabContainer>
          <CreateCollection
            closeDrawer={this.props.closeDrawer}
            loadingBtnStatus={this.props.loadingBtnStatus}
            getCollectionItemTypes={this.props.getCollectionItemTypes}
            collectionItemTypes={this.props.collectionItemTypes}
            addGroup={this.props.addGroup}
            auth={this.props.auth}
            groupTypes={this.props.groupTypes}
            itemTypes={this.props.itemTypes}
            collectionMTAs={this.props.collectionMTAs}
            errorTcins={this.props.errorTcins}
            recentAddedInfo={this.props.recentAddedInfo}
            requestType={this.props.requestType}
            recentAddedGroup={this.props.recentAddedGroup}
          />
        </TabContainer>}
        {value === 'bundle' &&
        <TabContainer>
          <CreateBundle
            closeDrawer={this.props.closeDrawer}
            loadingBtnStatus={this.props.loadingBtnStatus}
            requestType={this.props.requestType}
            recentAddedGroup={this.props.recentAddedGroup}
          />
        </TabContainer>}
      </div>
    )
  }
}

CreateGroupContainer.propTypes = {
  classes: PropTypes.object.isRequired,
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getGrouperTypes,
    getItemTypes,
    getItemThemes,
    clearItemThemes,
    clearActionTypes,
    addGroup,
    clearErrorTcins,
    getCollectionItemTypes,
  }, dispatch)

const mapStateToProps = state => ({
  auth: state.get('auth').toJS(),
  groupTypes: state.getIn(['grouperDashboard', 'groupTypes']).toJS(),
  itemTypes: state.getIn(['grouperDashboard', 'itemTypes']).toJS(),
  itemThemes: state.getIn(['grouperDashboard', 'itemThemes']).toJS(),
  requestType: state.getIn(['grouperDashboard', 'requestType']),
  recentAddedGroup: state.getIn(['grouperDashboard', 'recentAddedGroup']),
  recentAddedInfo: state.getIn(['grouperDashboard', 'recentAddedInfo']).toJS(),
  errorTcins: state.getIn(['grouperDashboard', 'errorTcins']).toJS(),
  collectionItemTypes: state.getIn(['grouperDashboard', 'collectionItemTypes']).toJS(),
  collectionMTAs: state.getIn(['grouperDashboard', 'collectionMTAs']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(CreateGroupContainer))
