import { Component, Input, ViewChild } from '@angular/core';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { ValidateConfigurationSidebarComponent } from 'src/app/pipelines/shared/validate-configuration-sidebar/validate-configuration-sidebar.component';
import { PipelineFinalizeSummary } from './pipeline-finalize-summary';
import { PIPELINE_ENTITY_TYPE } from '../../shared/pipeline';
import { PipelineService } from '../../pipeline.service';

@Component({
  selector: 'p-connect-pipeline-finalize-summary',
  templateUrl: './pipeline-finalize-summary.component.html'
})
export class PipelineFinalizeSummaryComponent {
  @ViewChild(ValidateConfigurationSidebarComponent) validateConfigurationSidebarComponent: ValidateConfigurationSidebarComponent;

  @Input() summaryData: PipelineFinalizeSummary;

  readonly PIPELINE_TYPE = PIPELINE_ENTITY_TYPE;

  constructor(private readonly featureFlagService: FeatureFlagService, private readonly pipelineService: PipelineService) {}

  isAsyncCommitFeatureEnabled(): boolean {
    return this.featureFlagService.isFeatureEnabled('CDCAsyncCommitTemp20221110');
  }

  onValidationButtonClicked(): void {
    this.validateConfigurationSidebarComponent.openAsync(this.pipelineService.getProjectId());
  }
}
