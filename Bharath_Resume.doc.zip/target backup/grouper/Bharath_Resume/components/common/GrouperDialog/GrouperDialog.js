import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Button from '@material-ui/core/Button'
import Dialog from '@material-ui/core/Dialog'
import DialogActions from '@material-ui/core/DialogActions'
import DialogContent from '@material-ui/core/DialogContent'
import DialogContentText from '@material-ui/core/DialogContentText'
import DialogTitle from '@material-ui/core/DialogTitle'

const styles = theme => ({
  allowButtonStyle: {
    background: '#1976d2',
    color: '#fff',
    fontWeight: 300,
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
  },
  disAgreeButtonStyle: {
    background: '#fff',
    color: '#1976d2',
    fontWeight: 300,
    '&:hover': {
      background: '#85d2ed',
      color: '#fff',
    },
  },
  displayNote: {
    color: 'red',
    fontSize: 13,
    float: 'left',
    marginTop: 10,
  },
})
class GrouperDialog extends React.Component {
  constructor (props) {
    super(props)

    this.state = {
      open: false,
    }
  }

  componentWillReceiveProps (nextProps) {
    this.setState({ open: nextProps.openStatus })
  }

  handleClose = () => {
    this.props.deleteConfirmCallback(false)
    this.setState({ open: false })
  };

  handleAgree = () => {
    this.props.deleteConfirmCallback(true)
    this.setState({ open: false })
  };

  render () {
    const { classes, disAgreeText, agreeText } = this.props
    return (
      <Dialog
        open={this.state.open}
        keepMounted
        onClose={this.handleClose}
        aria-labelledby="alert-dialog-slide-title"
        aria-describedby="alert-dialog-slide-description"
      >
        <DialogTitle id="alert-dialog-slide-title">
          {this.props.title}
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-slide-description">
            {this.props.message}
            {(this.props.dialogNote && this.props.dialogNote !== '') &&
              <span className={classes.displayNote}>{this.props.dialogNote}</span>
            }
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={this.handleClose} color="primary" className={classes.disAgreeButtonStyle}>
            {disAgreeText}
          </Button>
          <Button onClick={this.handleAgree} color="primary" className={classes.allowButtonStyle}>
            {agreeText}
          </Button>
        </DialogActions>
      </Dialog>
    )
  }
}

export default withStyles(styles)(GrouperDialog)
