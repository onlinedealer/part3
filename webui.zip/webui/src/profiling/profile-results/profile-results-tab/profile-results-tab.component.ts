import { Component, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import {
  Helper,
  SharedConstants as ProfilingConstants,
  ValidationMessage,
  ValidationMessageTypeModel
} from 'discovery-shared';
import { StatsGroup } from '../statistics.model';
import { TreePath } from './../tree-path.model';

@Component({
  selector: 'discovery-profile-results-tab',
  templateUrl: './profile-results-tab.component.html',
  styleUrls: ['./profile-results-tab.component.css']
})
export class ProfileResultsTabComponent implements OnInit {
  @Input()
  tabContent: StatsGroup;
  chartData = {};
  donutCharts = [];
  patternCharts = [];
  stackedDonutCharts = [];
  tableChart = [];
  charAnalysisGroupChart = [];
  percentileChart = [];
  stringLengthStat = [];
  numericalAnalysisStat = [];
  histogramChart = [];
  semanticAnalysisStats: any = [];
  _treePath: TreePath;
  failureMessages: any[] = [];
  infoMessages: any[] = [];
  tablePopuarity: any[] = [];
  validationFailures: Set<string>;
  ValidationMessageType: typeof ValidationMessageTypeModel = ValidationMessageTypeModel;

  get treePath(): TreePath {
    return this._treePath;
  }

  @Input()
  set treePath(val: TreePath) {
    this._treePath = val;
    this.loadData();
  }

  constructor(private translocoService: TranslocoService, public httpUtil: HttpUtilService) {}

  ngOnInit(): void {
    this.loadData();
  }

  getTableChartWidth(): number {
    if (this.tableChart.length === 3) {
      return 4;
    } else if (this.tableChart.length === 2) {
      return 6;
    } else {
      return 12;
    }
  }

  getDonutChartWidth(): number {
    let totalCharts = 0;
    totalCharts =
      this.donutCharts.length +
      this.stackedDonutCharts.length +
      this.numericalAnalysisStat.length +
      this.stringLengthStat.length;
    if (totalCharts >= 3) {
      return 4;
    } else if (totalCharts === 2) {
      return 6;
    } else {
      return 12;
    }
  }

  private loadData(): void {
    this.clearStatistics();
    this.failureMessages = [];
    let trendIcon = this.httpUtil.getAssetUrl('portal', 'profiling', 'assets/images/maximum.svg');
    this.infoMessages = [
      new ValidationMessage(
        this.translocoService.translate('discoveryProfiling.results.trends.trendsIconInfo', { icon: trendIcon })
      )
    ];
    if (this.treePath.tableView) {
      if (this.treePath.treeData.data && this.treePath.treeData.data.statistics) {
        for (const stat of this.treePath.treeData.data.statistics) {
          this.loadChartRenderList(stat);
        }
        this.tablePopuarity = Helper.getFilteredAuthorizedPopularity(this.treePath.treeData.data);
      } else {
        if (this.treePath.treeData.data.errorMessage) {
          this.failureMessages = [new ValidationMessage(this.treePath.treeData.data.errorMessage)];
        }
      }
    } else if (this.treePath.columnView) {
      if (this.treePath.treeData.data && this.treePath.treeData.data.statistics) {
        for (const stat of this.treePath.treeData.data.statistics) {
          this.loadChartRenderList(stat);
        }
      } else {
        if (this.treePath.treeData.data.errorMessage) {
          this.failureMessages = [new ValidationMessage(this.treePath.treeData.data.errorMessage)];
        }
      }
    } else if (this.treePath.modelView) {
    }
  }

  private loadChartRenderList(stat: any): void {
    if (stat.group) {
      switch (stat.group) {
        case ProfilingConstants.STATSGROUPS.CHARACTER_ANALYSIS:
          this.charAnalysisGroupChart.push(stat);
          break;
        case ProfilingConstants.STATSGROUPS.NUMERICAL_ANALYSIS:
          this.numericalAnalysisStat.push(stat);
          break;
        case ProfilingConstants.STATSGROUPS.DATE_ANALYSIS:
          this.numericalAnalysisStat.push(stat);
          break;
        case ProfilingConstants.STATSGROUPS.TABLE_ANALYSIS:
          if (stat.type === ProfilingConstants.STATS.COMPLETENESS) {
            this.donutCharts.push(stat);
          }
          break;
        case ProfilingConstants.STATSGROUPS.SEMANTIC_ANALYSIS:
          this.semanticAnalysisStats.push(stat);
          break;
        case ProfilingConstants.STATSGROUPS.STRING_ANALYSIS:
          this.stringLengthStat.push(stat);
          break;
      }
    } else {
      switch (stat.type) {
        case ProfilingConstants.STATS.COMPLETENESS:
          this.donutCharts.push(stat);
          break;
        case ProfilingConstants.STATS.UNIQUENESS:
          this.stackedDonutCharts.push(stat);
          break;
        case ProfilingConstants.STATS.FREQUENCY:
          this.tableChart.push(stat);
          break;
        case ProfilingConstants.STATS.STRINGLENGTH:
          this.tableChart.push(stat);
          break;
        case ProfilingConstants.STATS.TEXTPATTERN:
          this.patternCharts.push(stat);
          break;
        case ProfilingConstants.STATS.SCRIPTPATTERN:
          this.tableChart.push(stat);
          break;
        case ProfilingConstants.STATS.PERCENTILE:
          this.percentileChart.push(stat);
          break;
        case ProfilingConstants.STATS.STRINGLENGTHSTAT:
          this.stringLengthStat.push(stat);
          break;
        case ProfilingConstants.STATS.HISTOGRAM:
          this.histogramChart.push(stat);
          break;
      }
    }
  }

  private clearStatistics(): void {
    this.donutCharts = [];
    this.patternCharts = [];
    this.tableChart = [];
    this.charAnalysisGroupChart = [];
    this.stackedDonutCharts = [];
    this.percentileChart = [];
    this.stringLengthStat = [];
    this.numericalAnalysisStat = [];
    this.histogramChart = [];
    this.semanticAnalysisStats = [];
  }
}
