import { CommonModule } from '@angular/common';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MockComponents } from 'ng-mocks';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { SecondaryNavComponent } from '@precisely/prism-ng/secondary-nav';
import { DatasetsComponent } from 'dqcore-catalog';
import { DataCatalogContainerComponent } from './data-catalog-container.component';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';
import { TranslocoModule } from '@ngneat/transloco';
import { SecondaryNavItemsService } from 'discovery-shared';

describe('DataCatalogContainerComponent', () => {
  let component: DataCatalogContainerComponent;
  let fixture: ComponentFixture<DataCatalogContainerComponent>;
  let mockLDService = jasmine.createSpyObj(['variation']);
  const mockSecNav = jasmine.createSpyObj('SecondaryNavItemsService', ['getNavItems', 'getActiveNav']);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DataCatalogContainerComponent, ...MockComponents(SecondaryNavComponent, DatasetsComponent)],
      imports: [CommonModule, TranslocoModule, TranslocoLocaleModule.forRoot()],
      providers: [
        { provide: LaunchDarklyService, useValue: mockLDService },
        { provide: SecondaryNavItemsService, useValue: mockSecNav }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DataCatalogContainerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  afterEach(() => {
    fixture.destroy();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
