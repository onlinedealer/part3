import React, { Component } from 'react'
import CircularProgress from '@material-ui/core/CircularProgress'
import './LoadingHOC.css'
import favicon from '../../../images/favicon.png'

export class Loader extends Component {
  render () {
    return (
      <div className="wrapper">
        <div className="loaderBlock">
          <img src={favicon} alt="loading api service" className="loaderImg" />
          <CircularProgress size={68} className="fabProgress" />
        </div>
      </div>
    )
  }
}

export default Loader
