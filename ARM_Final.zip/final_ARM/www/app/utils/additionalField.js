(function () {
    'use strict';

    angular.module('arm').directive('addField', function () {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                list: '='
            },
            templateUrl: 'app/views/common/inputPage.html',
            link: function (scope, element, attrs) {

            },
        }
    })
    .directive('mapView', function () {
        return {
            restrict: 'A',
            link: function (scope, element, attrs) {
                ////console.log(element[0].querySelector('map'))
                scope.changeText = function () {
                    scope.text = 'New directive text';
                };
                scope.$on('changeText', function (event, data) {
                    initMap();
                });
                function initMap() {
                    var options = {
                        enableHighAccuracy: true,
                        timeout: 5000,
                        maximumAge: 0
                    };
                    navigator.geolocation.getCurrentPosition(initialize, fail, options);
                }

                var map, marker;
                var lastMarker;
                function initialize(position) {
                    var lat = scope.geoLocationArr.lat;
                    var log = scope.geoLocationArr.log;
                    if (lat == '' || log == '' || typeof lat == 'undefined' || typeof log == 'undefined')
                        loadMap(position.coords.latitude, position.coords.longitude);
                    else
                        loadMap(lat, log)
                }

                function fail() {
                  /*$cordovaDialogs.alert(ALERT_MESSAGE.CONTACT_NOT_SYNC, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                               .then(function () {
                            });*/
                    alert('Please check device location settings');
                }

                // Sets the map on all markers in the array.
                function setMapOnAll(map) {
                    for (var i = 0; i < marker.length; i++) {
                        marker[i].setMap(map);
                    }
                }

                // Removes the markers from the map, but keeps them in the array.
                function clearMarkers() {
                    setMapOnAll(null);
                }
                // Deletes all markers in the array by removing references to them.
                function deleteMarkers() {
                    clearMarkers();
                    marker = [];
                }

                function GetAddress(lat, log) {
                    var latlng;
                    latlng = new google.maps.LatLng(lat, log); // New York, US

                    new google.maps.Geocoder().geocode({ 'latLng': latlng }, function (results, status) {
                        if (status == google.maps.GeocoderStatus.OK) {
                            var city, state, country, zipcode = '';
                            for (var ac = 0; ac < results[0].address_components.length; ac++) {
                                var component = results[0].address_components[ac];

                                switch (component.types[0]) {
                                    case 'locality':
                                        city = component.long_name;
                                        break;
                                    case 'administrative_area_level_1':
                                        state = component.long_name;
                                        break;
                                    case 'country':
                                        country = component.long_name;
                                        break;
                                    case 'postal_code':
                                        zipcode = component.long_name;
                                        break;
                                }
                            }
                            //alert("City: " + city + ", State: " + state + ", Country: " + country + ", Country Code: " + registered_country_iso_code);
                            scope.geoLocationArr.city = city;
                            scope.geoLocationArr.state = state;
                            scope.geoLocationArr.country = country;
                            scope.geoLocationArr.zipcode = zipcode;
                            var loc = GetText(city) + GetText(state) + GetText(country);
                            // Assign value to address feild
                            scope.geoLocationArr.address = loc.replace(/,\s*$/, "");
                        }
                    });
                }

                function GetText(val) {
                    if (val == '' || val == 'undefined' || val == null) return "";
                    return val + ', ';
                }

                //load the map
                function loadMap(lat, log) {
                    //var myLatlng = new google.maps.LatLng(24.18061975930, 79.36565089010);
                    // Assign value to lat & log
                    scope.geoLocationArr.lat = lat;
                    scope.geoLocationArr.log = log;
                    var myLatlng = new google.maps.LatLng(lat, log);
                    var myOptions = {
                        zoom: 7,
                        center: myLatlng,
                        mapTypeId: google.maps.MapTypeId.ROADMAP
                    }
                    map = new google.maps.Map(element[0], myOptions);
                    // marker refers to a global variable
                    marker = new google.maps.Marker({
                        position: myLatlng,
                        map: map
                    });
                    GetAddress(lat, log);
                    google.maps.event.addListener(map, "click", function (event) {
                        marker.setMap(null);
                        scope.geoLocationArr.lat = event.latLng.lat();
                        scope.geoLocationArr.log = event.latLng.lng();

                        marker = new google.maps.Marker({
                            position: new google.maps.LatLng(scope.geoLocationArr.lat, scope.geoLocationArr.log),
                            map: map
                        });
                        GetAddress(event.latLng.lat(), event.latLng.lng());
                    });

                }
            },
        }
    })
	 .directive('userOtherList', function () {
        return {
            restrict: 'E',
            replace: true,
            /*link: function (scope, element, attrs) {
                  scope.$watch('userKeyword', function(){
                      scope.list = JSON.parse(attrs.list);
                  });
             },
             template: '<div class="checkbox-group" ng-repeat="item in list">' +
                                     '<ion-checkbox class="item item-devider item-checkbox-left checkbox-calm" indeterminate-cue ' +
                                     'ng-model="item.IsChecked" ng-checked="true">' +
                                     '{{ item.UserName }}</ion-checkbox>'*/
            scope: {
                list: '='
            },
            /*template: '<div class="checkbox-group" ng-repeat="item in list">' +
                        '<ion-checkbox class="item item-devider item-checkbox-right checkbox-calm" indeterminate-cue ' +
                        'ng-model="item.IsChecked" ng-checked="item.IsChecked">' +
                        '{{ item.UserName }}</ion-checkbox>',*/
            template: '<div class="checkbox-group" ng-repeat="item in list"><div class="item chktogglegroup">' +
                    '<ion-checkbox class="item item-checkbox-left checkbox-calm" ' +
                    'ng-model="item.IsChecked" ng-checked="item.IsChecked">' +
                    '{{ item.UserName }}</ion-checkbox><ion-toggle ng-show="shouldShowSwitch" ng-model="item.IsSwitchOn" ng-checked="item.IsSwitchOn" toggle-class="toggle-calm"></ion-toggle></div></div>',
            link: function (scope, element, attrs) {
                //if (scope.modelSelected == 'C') {
            },
        }
    })
    .directive('userList', function () {
        return {
            restrict: 'E',
            replace: true,
            /*link: function (scope, element, attrs) {
                  scope.$watch('userKeyword', function(){
                      scope.list = JSON.parse(attrs.list);
                  });
             },
             template: '<div class="checkbox-group" ng-repeat="item in list">' +
                                     '<ion-checkbox class="item item-devider item-checkbox-left checkbox-calm" indeterminate-cue ' +
                                     'ng-model="item.IsChecked" ng-checked="true">' +
                                     '{{ item.UserName }}</ion-checkbox>'*/
            scope: {
                list: '='
            },
            /*template: '<div class="checkbox-group" ng-repeat="item in list">' +
                        '<ion-checkbox class="item item-devider item-checkbox-right checkbox-calm" indeterminate-cue ' +
                        'ng-model="item.IsChecked" ng-checked="item.IsChecked">' +
                        '{{ item.UserName }}</ion-checkbox>',*/
            template: '<div class="checkbox-list" ng-repeat="item in list">' +
                    '<ion-checkbox class="item item-devider item-checkbox-left checkbox-calm" ' +
                    'ng-model="item.IsChecked" ng-checked="item.IsChecked">' +
                    '{{ item.UserName }}</ion-checkbox></div>',
            link: function (scope, element, attrs) {
                //if (scope.modelSelected == 'C') {
            },
        }
    })
    .directive('userParContactList', function () {
        return {
            restrict: 'E',
            replace: true,
            /*link: function (scope, element, attrs) {
                  scope.$watch('userKeyword', function(){
                      scope.list = JSON.parse(attrs.list);
                  });
             },
             template: '<div class="checkbox-group" ng-repeat="item in list">' +
                                     '<ion-checkbox class="item item-devider item-checkbox-right checkbox-calm" indeterminate-cue ' +
                                     'ng-model="item.IsChecked" ng-checked="true">' +
                                     '{{ item.UserName }}</ion-checkbox>'*/
            scope: {
                list: '='
            },
            template: '<div class="checkbox-list" ng-repeat="item in list">' +
                      '<ion-checkbox class="item item-checkbox-right checkbox-calm" ' +
                      'ng-model="item.IsChecked" ng-checked="item.IsChecked">' +
                      '<div ng-if="item.ContactTypeID == 1"><span class="bold color-calm">{{ item.ContactName }}</span> ({{item.CompanyName}})</div>'+
                      '<div ng-if="item.ContactTypeID == 2">{{ item.RepresentativeName }} <span class="bold color-calm">({{item.CompanyName}})</span></div></ion-checkbox></div>',
            link: function (scope, element, attrs) {
                //if (scope.modelSelected == 'C') {
            },
        }
    })
    .directive('actCardList', function () {
        return {
            restrict: 'E',
            replace: true,
           scope: {
                list: '=',
                query: '=',
                seldate: '=',
                filteroptions: '='
            },
            templateUrl: 'app/views/common/activityCard.html',
            link: function (scope, element, attrs) {
            },
        }
    })
    .directive('dealCardList', function () {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                list: '=',
                query: '=',
                seldate: '=',
                filteroptions: '='
            },
            templateUrl: 'app/views/common/dealCard.html',
            link: function (scope, element, attrs) {
            },
        }
    })
    .directive('individualList', function () {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                list: '=',
                query: '=',
                filteroptions: '='
            },
            templateUrl: 'app/views/common/contactIndividualCard.html',
            link: function (scope, element, attrs) {
            },
        }
    })
    .directive('companyList', function () {
            return {
                restrict: 'E',
                replace: true,
                scope: {
                    list: '=',
                    query: '=',
                    filteroptions: '='
                },
                templateUrl: 'app/views/common/contactCompanyCard.html',
                link: function (scope, element, attrs) {
                },
            }
        })
    .directive('userContacts', function () {
        return {
            restrict: 'E',
            replace: true,
            link: function (scope, element, attrs) {
                scope.$watch('userKeyword', function () {
                    scope.list = JSON.parse(attrs.list);
                });
            },
            template: '<div class="radio-group radio-list" ng-repeat="item in list">' +
                      '<ion-radio ng-value="item.ContactDeviceObjID" class="item item-checkbox-right checkbox-calm indeterminate-cue" ng-model="selContacts.activeContact" ng-click="radioLink(item.RepresentativeDeviceObjID)">' +
                      '<div ng-if="item.ContactTypeID == 1"><span class="bold color-calm">{{ item.ContactName }}</span> <span>({{item.EmployerName}})</span></div>'+
                      '<div ng-if="item.ContactTypeID == 2">{{ item.RepresentativeName }} <span class="bold color-calm">({{item.CompanyName}})</span></div></ion-radio></div>',
        }
    })
    .directive('singleUser', function () {
         return {
             restrict: 'E',
             replace: true,
             link: function (scope, element, attrs) {
                 scope.$watch('userKeyword', function () {
                     scope.list = JSON.parse(attrs.list);
                 });
             },
             template: '<ion-list class="radio-group radio-list" ng-repeat="item in list">' +
                      '<ion-radio ng-value="item.UserID" ' +
                      'ng-model="selUserOwners.tempUser">' +
                      '{{ item.UserName }}</ion-radio></ion-list>'
         }
     })
     .directive('singleCompany', function () {
          return {
              restrict: 'E',
              replace: true,
              link: function (scope, element, attrs) {
                  scope.$watch('userKeyword', function () {
                      scope.list = JSON.parse(attrs.list);
                  });
              },
              template: '<ion-list class="radio-group radio-list" ng-repeat="item in list">' +
                       '<ion-radio ng-value="item.DeviceObjID" ' +
                       'ng-model="selCompanyClient.tempCompany">' +
                       '{{ item.CompanyName }}</ion-radio></ion-list>'
          }
      })
    .directive('productFamily', function () {
        return {
            restrict: 'E',
            replace: true,
            link: function (scope, element, attrs) {
                scope.$watch('userKeyword', function () {
                    scope.list = JSON.parse(attrs.list);
                });
            },
            template: '<div class="radio-group" ng-repeat="item in list">' +
                      '<div class="item item-devider">{{item.Name}}</div>' +
                      '<ion-radio ng-value="product.ProductID" ng-model="selProduct.activeProduct"' +
                      'name="D1" ng-repeat="product in item.Products">{{ product.Name }}</ion-radio>' +
                      '</div>'
        }
    })
    .directive('dealStages', function () {
        return {
            restrict: 'E',
            replace: true,
            link: function (scope, element, attrs) {
                scope.$watch('userKeyword', function () {
                    scope.list = JSON.parse(attrs.list);
                });
            },
            template: '<div class="radio-group" ng-repeat="item in list">' +
                      '<div ng-if="item.ParentDealStageID == null">'+
                      '<div class="item item-devider">{{item.Name}}</div>' +
                      '<div ng-repeat="dealsubitems in list">'+
                      '<div ng-if="item.DealStageID == dealsubitems.ParentDealStageID">'+
                      '<ion-radio ng-value="dealsubitems.DealStageID" ng-model="selDealStages.activeDealStage"' +
                      'name="D1">{{ dealsubitems.Name }}</ion-radio>' +
                      '</div>'+
                      '</div>'+
                      '</div>'+
                      '</div>'
        }
    })
    .directive('dealSource', function () {
        return {
            restrict: 'E',
            replace: true,
            link: function (scope, element, attrs) {
                scope.$watch('userKeyword', function () {
                    scope.list = JSON.parse(attrs.list);
                });
            },
            template: '<div class="radio-group radio-list" ng-repeat="item in list">' +
                    '<ion-radio ng-value="item.DealSourceID" class="item item-checkbox-right checkbox-calm" ng-model="selDealSource.activeDealSource">' +
                    '{{ item.Name }}</ion-radio></div>'
        }
    })
    .directive('timeFormat', function (utility) {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                timeval: '='
            },
            template: '<h3>{{timeDisplay}} <sup>{{timeType}}</sup></h3>',
            link: function (scope, element, attrs) {
                scope.timeDisplay = '';
                var timeformat = utility.convertTimeFormat(scope.timeval);
                var spltVal = timeformat.split(' ');
                scope.timeDisplay = spltVal[0];
                scope.timeType = spltVal[1];
            },
        }
    })
    .directive('dateTimeFormat', function (utility) {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                timeval: '=',
                dateval: '='
            },
            template: '<span>{{dateDisplay}}, {{timeDisplay}}</span>',
            link: function (scope, element, attrs) {
                scope.timeDisplay = '';
                scope.timeDisplay = utility.convertTimeFormat(scope.timeval);
                scope.dateDisplay = utility.getDateStringFormat(scope.dateval);//$filter('date')(new Date(scope.dateval), 'dd-MM-yyyy');;
            },
        }
    })
    .directive('dateTime', function (utility) {
        return {
            restrict: 'E',
            replace: true,
            scope: {
                val: '='
            },
            template: '<span>{{dateDisplay}} </span>',
            link: function (scope, element, attrs) {
                scope.dateDisplay = '';
                scope.dateDisplay = utility.getDateTimeInDisplayFormat(scope.val);
            },
        }
    })
    .directive('dateOnly', function (utility) {
            return {
                restrict: 'E',
                replace: true,
                scope: {
                    val: '='
                },
                template: '<span>{{dateDisplay}} </span>',
                link: function (scope, element, attrs) {
                    scope.dateDisplay = '';
                    scope.dateDisplay = utility.getDateOnlyDisplayFormat(scope.val);
                },
            }
        })
    .factory('focus', function ($timeout, $window) {
        return function (id) {
            // timeout makes sure that it is invoked after any other event has been triggered.
            // e.g. click events that need to run before the focus or
            // inputs elements that are in a disabled state but are enabled when those events
            // are triggered.
            $timeout(function () {
                var element = $window.document.getElementById(id);
                if (element)
                    element.focus();
            }, 200);
        };
    })
    .directive('eventFocus', function (focus) {
        return function (scope, elem, attr) {
            elem.on(attr.eventFocus, function () {
                focus(attr.eventFocusId);
            });

            // Removes bound events in the element itself
            // when the scope is destroyed
            scope.$on('$destroy', function () {
                elem.off(attr.eventFocus);
            });
        };
    })

})();
