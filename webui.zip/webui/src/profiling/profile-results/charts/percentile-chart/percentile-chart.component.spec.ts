import { TestBed } from '@angular/core/testing';
import { Spies } from 'discovery-test';
import { ChartModule } from 'primeng/chart';
import { TreePath } from 'profiling/profile-results/tree-path.model';

import { PercentileChartComponent } from './percentile-chart.component';

describe('PercentileChartComponent', () => {
  let component: PercentileChartComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PercentileChartComponent],
      imports: [ChartModule]
    }).compileComponents();
  });

  beforeEach(() => {
    Spies.init();
    component = new PercentileChartComponent();
    component.data = {
      labels: [],
      datasets: [
        {
          data: [],
          fill: false,
          borderColor: '#39006B'
        }
      ]
    };
    component.treePath = new TreePath();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with PercentileStatistics', () => {
    component.statistics = {
      type: 'PercentileStatistics',
      percentiles: {
        '1.0': 100.37908567880628,
        '5.0': 501.83858315267554,
        '25.0': 2501.478044638815,
        '50.0': 4998.396343539876
      }
    } as any;
    component.treePath.columnView = true;
    component.ngOnInit();
    expect(component.data.labels[2]).toEqual(component.statistics['percentiles']['25.0']);
    expect(component.data.datasets[0].data[1]).toEqual(5);
  });
});
