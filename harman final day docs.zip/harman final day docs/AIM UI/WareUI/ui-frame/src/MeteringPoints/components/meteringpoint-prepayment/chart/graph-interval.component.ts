import { Component, Input, EventEmitter, Output, OnChanges, ChangeDetectionStrategy } from "@angular/core";
import { TranslationsService } from "../../../../app/services/translations-service";
import { MatButtonToggleChange } from "@angular/material/button-toggle";

@Component({
    selector: "landisgyr-graph-interval",
    templateUrl: "./graph-interval.component.html",
    styleUrls: ["./graph-interval.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class GraphIntervalComponent implements OnChanges {
    @Input() chartDataAvailableGroupingOptions!: string[];

    @Input() chartDataGrouping!: string;

    @Output() chartDataGroupingSelection = new EventEmitter<string>();

    selectedValue!: string;

    constructor(public translations: TranslationsService) {}

    ngOnChanges(): void {
        this.selectedValue = this.chartDataGrouping;
    }

    isOptionDisabled(optionValue: string) {
        return this.chartDataAvailableGroupingOptions.includes(optionValue) === false;
    }

    onGroupingSelectionToggleChange(selection: MatButtonToggleChange) {
        this.selectedValue = selection.value;
        this.chartDataGroupingSelection.emit(selection.value);
    }
}
