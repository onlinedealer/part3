import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { AirbyteApiService } from './airbyte-api.service';

describe('AirbyteApiService', () => {
  let service: AirbyteApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(AirbyteApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return the connection details', () => {
    const expectedRequestMethod = 'GET';

    service.getConnectionDetails().subscribe((response) => {
      expect(response).toEqual(null);
    });
    const req = httpMock.expectOne({
      method: 'GET',
      url: `${service.serviceURL}connections/details`
    });
    req.flush(null);
  });

  it("should return the connection's source spec", () => {
    const connection = {
      isSource: true,
      isTarget: true,
      logoURL: '',
      type: 'S3'
    };
    service.getConnectionSpec(connection).subscribe((response) => {
      expect(response).toEqual(null);
    });
    const req = httpMock.expectOne({
      method: 'GET',
      url: `${service.serviceURL}connections/S3/spec`
    });
    req.flush(null);
  });

  it("should return the connection's target spec", () => {
    const connection = {
      isSource: false,
      isTarget: true,
      logoURL: '',
      type: 'S3'
    };
    service.getConnectionSpec(connection).subscribe((response) => {
      expect(response).toEqual(null);
    });
    const req = httpMock.expectOne({
      method: 'GET',
      url: `${service.serviceURL}connections/S3/spec?connection_origin=destination`
    });
    req.flush(null);
  });

  it('should get the job log when pipeline and run id is defined', () => {
    const expectedRequestMethod = 'GET';
    const pipeline_id = 'pipeline_id';
    const run_id = 'run_id';

    service.getLogs(pipeline_id, run_id).subscribe((response) => {
      expect(response).toEqual(null);
    });
    const req = httpMock.expectOne({
      method: 'GET',
      url: `${service.serviceURL}logs?pipeline_id=pipeline_id&run_id=run_id`
    });
    req.flush(null);
  });

  it('should get the job log when only pipeline defined', () => {
    const expectedRequestMethod = 'GET';
    const pipeline_id = 'pipeline_id';
    const run_id = 'run_id';

    service.getLogs(pipeline_id).subscribe((response) => {
      expect(response).toEqual(null);
    });
    const req = httpMock.expectOne({
      method: 'GET',
      url: `${service.serviceURL}logs?pipeline_id=pipeline_id`
    });
    req.flush(null);
  });
});
