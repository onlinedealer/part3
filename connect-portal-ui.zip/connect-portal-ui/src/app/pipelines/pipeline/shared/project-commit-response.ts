export class ProjectCommitResponse {
  isCommited?: boolean;
  status?: string;
  validationResponse?: {
    error?: number;
    fatal?: number;
    incomplete: number;
    message?: string;
    severityLevel?: string;
    total?: number;
    warning?: number;
  };
}
