import React from 'react'
import { Link } from 'react-router-dom'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormHelperText from '@material-ui/core/FormHelperText'
import FormControl from '@material-ui/core/FormControl'
import Tooltip from '@material-ui/core/Tooltip'
import Help from '@material-ui/icons/Help'
import GrouperChipInput from '../common/GrouperChipInput/GrouperChipInput'
import { getItemTypesOptions } from '../common/Utils/CommonUtils'
import * as Constants from '../common/Utils/Constants'
import IntegrationReactSelect from '../common/GrouperAutoComplete/IntegrationReactSelect'

const styles = theme => ({
  container: {
    width: '100%',
  },
  formControl: {
    width: '100%',
  },
  field: {
    marginTop: 40,
  },
  help: {
    color: '#1976D2',
    fontSize: 10,
    marginTop: 8,
  },
  helpIcon: {
    fontSize: 15,
    paddingRight: 5,
    float: 'left',
    color: '#1976D2',
  },
  helperText: {
    marginTop: 8,
  },
  helpText: {
    float: 'left',
    marginTop: 2,
  },
  helpLink: {
    color: '#1976D2',
    textDecoration: 'none',
  },
  itemCount: {
    float: 'right',
  },
  textHead: {
    fontSize: 13,
    fontWeight: 500,
    marginBottom: 16,
  },
  textHead1: {
    fontSize: 13,
    fontWeight: 500,
  },
  textNormal: {
    fontSize: 13,
    fontWeight: 300,
  },
  textSmall: {
    fontSize: 11,
    fontWeight: 300,
    fontStyle: 'italic',
  },
  displayFlex: {
    display: 'flex',
  },
  chipContainer: {
    maxHeight: '200px',
    overflowY: 'auto',
    marginBottom: 0,
    backgroundColor: '#fff',
  },
})

export class CreateCommonFields extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      tcins: [],
      formData: {
        group_type: 'variation',
        group_name: '',
        item_type: '',
        tcins: [],
      },
      errors: {
        group_type: '',
        item_type: '',
        group_name: '',
        tcins: '',
      },
    }
  }

  componentWillMount () {
    if (this.props.step1FormData) {
      this.setState({ formData: this.props.step1FormData })
    }
  }

  componentWillReceiveProps (nextProps) {
    // if (nextProps.itemTypeOfFirstTcin) {
    //   const formData = { ...this.state.formData }
    //   formData.item_type = nextProps.itemTypeOfFirstTcin
    //   this.setState({ formData })
    // }
  }

  handleAddTcin = (tcin) => {
    if (tcin) {
      let tcins = [tcin]
      if (tcin.indexOf(',') !== -1) { // paste with comma
        tcins = tcin.replace(/ /g, '').split(',')
      } else if (tcin.indexOf(' ') !== -1) { // paste columns or columns and rows together
        tcins = tcin.split(' ')
        let newTcins = []
        tcins.map((tc, i) => {
          if (tc) {
            let locTcin = tc.trim()
            if (locTcin.indexOf(String.fromCharCode(9)) !== -1) {
              locTcin = locTcin.split(String.fromCharCode(9))
              newTcins = [ ...newTcins, ...locTcin ]
            } else {
              newTcins.push(locTcin)
            }
          }
        })
        tcins = newTcins
      } else if (tcin.indexOf(String.fromCharCode(9)) !== -1) { // paste rows
        tcins = tcin.split(String.fromCharCode(9))
      }

      const formData = { ...this.state.formData }
      const errors = { ...this.state.errors }
      let isError = false
      tcins.map((tc, i) => {
        if (tc) {
          if (tc.match(Constants.REGEX_NUMBER)) {
            if (formData.tcins.indexOf(tc) === -1) {
              formData.tcins.push(tc)
            }
          } else {
            isError = true
          }
        }
      })
      this.props.VariationItemTypeOfFirstTcin(formData.tcins)
      errors.tcins = (isError) ? Constants.INVALID_TCIN_TEXT : ''
      this.props.onHandleChange('tcins', formData.tcins)
      if (this.props.itemTypeOfFirstTcin) {
        formData.item_type = this.props.itemTypeOfFirstTcin
      }
      this.setState({ formData, errors })
    }
  }

  handleDeleteTcin = (tcin) => {
    const formData = { ...this.state.formData }
    formData.tcins = formData.tcins.filter((c) => c !== tcin)
    if (formData.tcins.length <= 0) {
      this.props.clearErrorTcins()
      this.props.toggleSnackBar({})
    }
    this.setState({ formData })
    this.props.onHandleChange('tcins', formData.tcins)
  }

  handlekeyDown = (name, value) => {
    if (name === 'item_type' && this.props.groupType === 'variation') {
      if (value.length >= 1) {
        // this.props.getItemTypes(value)
      }
    }
  }

    handleChange = name => event => {
      const formData = { ...this.state.formData }
      const errors = { ...this.state.errors }
      if (name === 'group_name') {
        if (!event.target.value) {
          formData.group_name = event.target.value
          errors.group_name = Constants.ERROR_GROUP_NAME_REQ
        } else if (event.target.value.length <= 150) {
          formData.group_name = event.target.value
          errors.group_name = ''
        } else {
          errors.group_name = Constants.GROUP_NAME_EXCEED_TEXT
        }
      }
      this.setState({ formData, errors })
      this.props.onHandleChange(name, event.target.value)
    }

    handleSelectChange = (name, value) => {
      const formData = { ...this.state.formData }
      const errors = { ...this.state.errors }
      if (name === 'group_type') {
        formData.group_type = value
        errors.group_type = ''
      } else if (name === 'item_type') {
        formData.item_type = value
        errors.item_type = ''
        formData.themes = {
          theme1: '',
        }
        if (value && this.props.groupType === 'variation') {
          this.props.getItemThemes(value)
        } else if (value && this.props.groupType === 'collection') {
          this.props.getCollectionMtas(value)
        } else {
          this.props.clearItemThemes()
        }
        this.setState({ themesFieldsCount: 1 })
      } else if (name && name.indexOf('theme') !== -1) {
        let isError = false
        for (let i = 1; i <= Constants.THEME_MAX_COUNT; i++) {
          if (value && (`theme${i}` !== name) && (formData.themes[`theme${i}`] === value)) {
            if (name === 'theme1') {
              errors.theme1 = Constants.ERROR_THEME_EXIST
            } else {
              errors.themes = Constants.ERROR_THEME_EXIST
            }
            isError = true
          }
        }
        if (!isError || !value) {
          formData.themes[name] = value
          errors.themes = ''
          if (value && name === 'theme1') {
            errors.theme1 = ''
          }
        }
      }
      this.setState({ formData, errors })
      this.props.onHandleChange(name, value)
    }

    render () {
      const { classes } = this.props
      const { formData, errors } = this.state
      const isMultiple = false
      return (
        <div className={classes.container}>
          <Grid item xs={12}>
            <FormControl className={classes.formControl} aria-describedby="name-helper-text">
              <InputLabel htmlFor="name-helper" required>Product Title/Group Name</InputLabel>
              <Input multiline id="name-helper" value={formData.group_name} onChange={this.handleChange('group_name')} required />
              {(errors.group_name) ? <FormHelperText error className={classes.helperText}>{errors.group_name}</FormHelperText>
                : <FormHelperText id="name-helper-text">150 character max</FormHelperText>}
            </FormControl>
          </Grid>
          <Grid item xs={12}>
            <div className={classes.help}>
              <Help className={classes.helpIcon} />
              <Tooltip title={Constants.GROUP_NAME_HELP_TEXT}>
                <div className={classes.helpText}>
                  <Link to="https://wiki.target.com/tgtwiki/index.php/Portal:Product_Title/General_Guidelines" target="_blank" className={classes.helpLink}>Group Name Help</Link>
                </div>
              </Tooltip>
            </div>
          </Grid>
          <Grid item xs={12} className={classes.field}>
            <IntegrationReactSelect
              currentValue={formData.item_type}
              column_id="item_type"
              options={getItemTypesOptions(this.props.itemTypes)}
              isMultiOption={isMultiple}
              handleSelectChange={this.handleSelectChange}
              handlekeyDown={this.handlekeyDown}
              labeledMsg="Item Type*"
              columnId="itemType"
            />
            {(errors.item_type) && <FormHelperText error className={classes.helperText}>{errors.item_type}</FormHelperText>}
          </Grid>
          <Grid item xs={12} className={classes.field}>
            <Grid container>
              <Grid item xs={12}>
                <Grid container className={classes.textHead}>
                  <Grid item xs={6}>
                    Add Items to Group
                  </Grid>
                  <Grid item xs={6}>
                    {formData.tcins.length > 0 &&
                      <div className={classes.itemCount}>
                        {formData.tcins.length} item(s)
                      </div>
                    }
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={12} className={classes.displayFlex}>
                <GrouperChipInput
                  chipContainerCls={classes.chipContainer}
                  placeholder="Paste or Type in TCINs *"
                  handleAddTcin={this.handleAddTcin}
                  handleDeleteTcin={this.handleDeleteTcin}
                  value={formData.tcins}
                  errors={this.props.errorTcins}
                  mode="WhileCreate"
                />
                {(errors.tcins) && <FormHelperText error className={classes.helperText}>{errors.tcins}</FormHelperText>}
              </Grid>
            </Grid>
          </Grid>
        </div>
      )
    }
}

CreateCommonFields.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(CreateCommonFields)
