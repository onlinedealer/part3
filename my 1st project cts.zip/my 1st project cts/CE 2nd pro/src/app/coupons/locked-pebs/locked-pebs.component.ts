import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';

@Component({
  selector: 'app-locked-pebs',
  templateUrl: './locked-pebs.component.html',
  styleUrls: ['./locked-pebs.component.scss']
})
export class LockedPebsComponent implements OnInit {
  @Input() data: any 

  // expandedView: boolean = false;
  // expandCpnDsc: boolean = true;
  // webDscToggle: boolean = true;
  imagesPaths: Object = ImagePaths
  

  constructor(public utilityService:UtilityService) { }

  
  styleStr;
  ngOnInit() {        
    this.getDateFormatted();    
  }
    getDateFormatted(){   
    let expDt = this.data.cmpgnEndDt;     
     let yyyy = expDt.substr(0,4);
     let mm = expDt.substr(4,2);
     let dd = expDt.substr(6,2);
     expDt = mm + '/' + dd + '/' + yyyy;     
     this.data.cmpgnEndDt = expDt;    
     }   
}
