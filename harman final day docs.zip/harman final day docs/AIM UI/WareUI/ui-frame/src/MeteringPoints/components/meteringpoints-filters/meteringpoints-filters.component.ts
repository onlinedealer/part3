import { Component, ChangeDetectionStrategy } from "@angular/core";
import { ComponentPortal } from "@angular/cdk/portal";
import { FiltersMenuComponent } from "./filters-menu.component";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { MeteringPointsUISelectors } from "../../store/selectors";
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";

@Component({
    selector: "landisgyr-meteringpoints-filters",
    templateUrl: "./meteringpoints-filters.component.html",
    styleUrls: ["./meteringpoints-filters.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringpointsFiltersComponent {
    filtersMenuVisible = false;

    filtersMenuPortal: ComponentPortal<FiltersMenuComponent> = new ComponentPortal(FiltersMenuComponent);

    selectedFilters$: Observable<string[]> = this.store.select(MeteringPointsUISelectors.getFilters);

    constructor(private store: Store<MeteringPointsFeatureState>) {}

    toggleFiltersMenuVisible() {
        this.filtersMenuVisible = !this.filtersMenuVisible;
    }
}
