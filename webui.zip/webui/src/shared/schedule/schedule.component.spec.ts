import { NgForm } from '@angular/forms';
import { Mocks, Spies } from 'discovery-test';
import { of } from 'rxjs';
import { ScheduleOccurenceTypeEnum } from 'discovery-core';
import { ScheduleComponent } from './schedule.component';

describe('ScheduleComponent', () => {
  let component: ScheduleComponent;

  beforeEach(() => {
    Spies.init();
    component = new ScheduleComponent(Spies.TranslateService);
    component.scheduleForm = new NgForm([], []);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should run ngOnInit', () => {
    component.ngOnInit();
    expect(component.patterns.length).toBe(2);
    expect(component.dayList.length).toBe(7);
    expect(component.scheduleOccurenceType).toBe('daily');
    expect(component.scheduleWeeklyModel.daysOfWeek[0]).toBe('MON');
  });
  //from date related test future scope
  // it('check invalid date format', () => {
  //   const e = jasmine.createSpyObj('e', ['preventDefault']);
  //   e['target'] = { value: '02-d2-2022' };
  //   component.onDateChanged(e);
  //   component.isFormatValid(e.target.value, 'date');
  //   spyOnProperty(component.scheduleForm.form, 'invalid', 'get').and.returnValue(true);
  //   expect(e.preventDefault).toHaveBeenCalled();
  //   expect(component.scheduleForm.form.invalid).toBe(true);
  // });

  // it('check valid date format', () => {
  //   const e = jasmine.createSpyObj('e', ['preventDefault']);
  //   component.scheduleOccurenceType = ScheduleOccurenceTypeEnum.DAILY;
  //   e['target'] = { value: '02-Feb-2038' };
  //   component.onDateChanged(e);
  //   component.isFormatValid(e.target.value, 'date');
  //   spyOnProperty(component.scheduleForm.form, 'invalid', 'get').and.returnValue(false);
  //   expect(e.preventDefault).toHaveBeenCalled();
  //   expect(component.scheduleForm.form.invalid).toBe(false);
  // });
  it('check valid time format', () => {
    const e = jasmine.createSpyObj('e', ['preventDefault']);
    component.scheduleOccurenceType = ScheduleOccurenceTypeEnum.DAILY;
    e['target'] = { value: '12:12 PM' };
    component.onTimeChanged(e);
    component.isFormatValid(e.target.value, 'time');
    spyOnProperty(component.scheduleForm.form, 'invalid', 'get').and.returnValue(false);
    expect(e.preventDefault).toHaveBeenCalled();
    expect(component.scheduleForm.form.invalid).toBe(false);
  });
  it('check invalid time format', () => {
    const e = jasmine.createSpyObj('e', ['preventDefault']);
    component.scheduleOccurenceType = ScheduleOccurenceTypeEnum.DAILY;
    e['target'] = { value: '12:65 PM' };
    component.onTimeChanged(e);
    component.isFormatValid(e.target.value, 'time');
    spyOnProperty(component.scheduleForm.form, 'invalid', 'get').and.returnValue(true);
    expect(e.preventDefault).toHaveBeenCalled();
    expect(component.scheduleForm.form.invalid).toBe(true);
  });
  it('check form invalid onSubmit', () => {
    spyOnProperty(component.scheduleForm.form, 'valid', 'get').and.returnValue(false);
    const result = component.onSubmit();
    expect(result).toBe(false);
    expect(component.isSubmitted).toBe(true);
  });
  it('should onSubmit call when occurence is daily', () => {
    component.switchScheduler = true;
    component.watchedCount = 1;
    component.scheduleDailyModel.runAtTime = new Date();
    component.scheduleOccurenceType = ScheduleOccurenceTypeEnum.DAILY;
    spyOn(component.schedulerChange, 'emit');
    component.onSubmit();
    spyOnProperty(component.scheduleForm.form, 'valid', 'get').and.returnValue(true);
    expect(component.scheduleForm.form.valid).toBe(true);
    expect(component.isSubmitted).toBe(false);
    expect(component.schedulerChange.emit).toHaveBeenCalled();
  });
  it('should onSubmit call when occurence is weekly', () => {
    component.switchScheduler = true;
    component.watchedCount = 1;
    component.scheduleOccurenceType = ScheduleOccurenceTypeEnum.WEEKLY;
    spyOn(component.schedulerChange, 'emit');
    component.onSubmit();
    spyOnProperty(component.scheduleForm.form, 'valid', 'get').and.returnValue(true);
    expect(component.scheduleForm.form.valid).toBe(true);
    expect(component.isSubmitted).toBe(false);
    expect(component.schedulerChange.emit).toHaveBeenCalled();
  });
  it('check if user never enabled schedule', () => {
    component.watchedCount = 0;
    component.isEdit = false;
    component.scheduleOccurenceType = ScheduleOccurenceTypeEnum.DAILY;
    spyOn(component.schedulerChange, 'emit');
    component.onSubmit();
    expect(component.scheduleDailyModel.runAtTime).toBeTruthy();
    expect(component.switchScheduler).toBe(false);
    expect(component.schedulerChange.emit).toHaveBeenCalled();
  });

  it('check if else case for different occurences', () => {
    component.watchedCount = 1;
    component.scheduleOccurenceType = ScheduleOccurenceTypeEnum.DAILY;
    component.occurences = { DAILY: 'weekly', WEEKLY: 'weekly' };
    spyOn(component.schedulerChange, 'emit');
    component.onSubmit();
    expect(component.schedulerChange.emit).toHaveBeenCalled();
  });
  it('check toggleSchedule event', () => {
    component.isEdit = false;
    component.watchedCount = 0;
    component.toggleSchedule();
    expect(component.watchedCount).toBe(1);
  });
  it('check toggleSchedule event with invalid data in Edit', () => {
    component.profileConfig = Mocks.MockProfiles[0];
    component.isEdit = true;
    component.switchScheduler = false;
    spyOnProperty(component.scheduleForm.form, 'valid', 'get').and.returnValue(false);
    component.toggleSchedule();
    expect(component.failureMessage.length).toBeGreaterThanOrEqual(1);
  });
  it('check timeformat for setTimeFormat fn', () => {
    const date = new Date();
    const time = [(date.getHours() % 12 || 12).toString(), date.getMinutes().toString(), 'AM'];
    const result = component.setTimeFormat(date);
    expect(result.length).toEqual(time.length);
  });
  it('load from settings in Edit for daily frequency', () => {
    const data = Mocks.MockProfiles[0];
    data.scheduleConfig.schedule.occurence = ScheduleOccurenceTypeEnum.DAILY;
    component.loadScheduleSettings(data, true);
    // Spies.ProfileService.isEmpty.and.returnValue(false);
    expect(component.scheduleOccurenceType).toBe('daily');
    expect(component.switchScheduler).toBe(true);
  });
  it('load from settings in Edit weekly frequency', () => {
    const data = Mocks.MockProfiles[0];
    data.scheduleConfig.schedule.occurence = ScheduleOccurenceTypeEnum.WEEKLY;
    data.scheduleConfig.schedule.runAtTime = { hour: null, minute: null, meridiemIndicator: null };
    component.loadScheduleSettings(data, true);
    // Spies.ProfileService.isEmpty.and.returnValue(true);
    expect(component.scheduleOccurenceType).toBe('weekly');
    expect(component.switchScheduler).toBe(true);
  });
});
