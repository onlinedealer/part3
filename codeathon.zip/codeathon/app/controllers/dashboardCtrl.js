(function() {
    'use strict';

    codeathonApp.controller("dashboardCtrl", ['$scope', '$ajaxFactory', 'uiRouters','$location',dashboardCtrl]);

    function dashboardCtrl($scope, $ajaxFactory, uiRouters,$location) {
        Codeathon.utils.showHeaderFooterMenu();
        
        var userId="";
		if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        }
        		
        $scope.dashboardDataSource = [];

        var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/dashboard/data.json', 'GET', {});
       //var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + '/view/dashboard/'+userId+'/','GET', {});

		
        promise.then(function(d) {
			$scope.batchData = d[0];
            $scope.dashboardDataSource = d;
        });
        promise.catch(function(d) {
            console.log('catch block executed', d);
            return d;
        });
        promise.finally(function(d) {
            console.log('finally block executed', d);
            indicatorStop();
        });
    }

})();
