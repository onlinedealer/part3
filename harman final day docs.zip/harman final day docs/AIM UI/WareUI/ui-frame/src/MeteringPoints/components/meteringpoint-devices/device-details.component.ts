import { Component, Input, Output, EventEmitter } from "@angular/core";
import { TranslationsService } from "../../../app/services/translations-service";
import { MeterConnection } from "../../models/meterconnection.model";
import { MeterTypeNames } from "./meter-type-names";

@Component({
    selector: "landisgyr-meteringpoint-device-details",
    templateUrl: "./device-details.component.html",
    styleUrls: ["./device-details.component.scss"]
})
export class DeviceDetailsComponent {
    constructor(public translations: TranslationsService) {}

    @Input()
    meterConnection!: MeterConnection;

    @Output()
    showRelays = new EventEmitter();

    @Output()
    showConfigurationsAndRegisters = new EventEmitter();

    @Output()
    showTransformerFactors = new EventEmitter();

    @Output()
    showCustomProperties = new EventEmitter();

    public meterTypeNames = new MeterTypeNames();
}
