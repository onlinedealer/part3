(function () {
    'use strict';

    angular.module('arm').controller('conversationListCtrl',
                ['$scope', '$state', '$ionicModal', '$ionicSideMenuDelegate','messageService', conversationListCtrl]);

    function conversationListCtrl($scope, $state, $ionicModal, $ionicSideMenuDelegate, messageService) {
		
		$scope.conversationList = messageService.getConversationList();
		
		$scope.createNewConversation = function ()
		{
			messageService.setConversationList($scope.conversationList);
			$state.go('tab.conversationParticipantList', {
              
            });
		}
        $scope.selectedMessage = function (array)
        {
        	var message = array[0];
        	return message;
        }
		$scope.messageDetail = function() 
		{
            $state.go('tab.conversationDetail', {
               //
            });
        }
		   
	};
})();



