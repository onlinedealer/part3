import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of, throwError } from 'rxjs';
import { Connection } from '../../../../../connections/shared/connection';
import { getTranslocoModule } from '../../../../../core/transloco-testing.module';
import { MockSidebarComponent } from '../../../../../shared/components/sidebar/mock-sidebar.component.spec';
import { MetadataApiService } from '../../schema-table-selector/metadata-api.service';
import { LogReader } from '../../shared/logreader';
import { LogReadersApiService } from '../../shared/logreaders-api.service';
import { LogReaderFormComponent } from '../logreader-form/logreader-form.component';
import { LogReaderSidebarComponent } from './logreader-sidebar.component';

@Component({
  selector: 'p-connect-logreader-form',
  template: '',
  providers: [
    {
      provide: LogReaderFormComponent,
      useClass: MockLogReaderFormComponent
    }
  ]
})
class MockLogReaderFormComponent {
  logReaderFormGroup = new FormGroup({ name: new FormControl(''), journals: new FormControl('') });
  open(isEditing = false): void {}
  resetForm(): void {}
}

describe('LogReaderSidebarComponent', () => {
  let component: LogReaderSidebarComponent;
  let fixture: ComponentFixture<LogReaderSidebarComponent>;
  let logReadersApiService: LogReadersApiService;
  let metadataApiService: MetadataApiService;

  const mockedSourceConnection = {
    id: '1',
    connectionType: 'DB2I',
    journalName: 'Journal1',
    name: 'DB2IConnection'
  } as Connection;

  const mockDefaultLogReader = {
    name: 'LGNAME1',
    journalName: 'SCHEMA/JOURNAL',
    parameters: [
      {
        key: 'REP_CLEAR_PF_MEMBER',
        value: 'Y'
      },
      {
        key: 'DEDICATED_QUEUE',
        value: 'Y'
      },
      {
        key: 'COMMIT_WAIT_TIME',
        value: '2'
      },
      {
        key: 'READER_WAIT_TIME',
        value: '1'
      },
      {
        key: 'UPDATE_STATS_FREQ',
        value: '60'
      },
      {
        key: 'MESSAGE_CHECK_FREQ',
        value: '20'
      },
      {
        key: 'SUBS_BIN_0',
        value: ''
      },
      {
        key: 'DEL_JRN_RCV',
        value: 'Y'
      },
      {
        key: 'KEEP_UNSAVED_JRN_RCV',
        value: 'Y'
      },
      {
        key: 'KEEP_JRN_RCV',
        value: '2'
      },
      {
        key: 'TRACING_TABLE',
        value: '3'
      },
      {
        key: 'TRACING_CONSOLE',
        value: '0'
      },
      {
        key: 'TRACING_LOG_FILE',
        value: '4'
      },
      {
        key: 'TRACING_MAX_NB_LOG_CREATED',
        value: '10'
      },
      {
        key: 'TRACING_LOG_INTERVAL',
        value: '3'
      },
      {
        key: 'TRACING_LOG_SIZE',
        value: '10'
      },
      {
        key: 'TRACING_SQL_BASE_TBL_REF',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_SHADOW_TBL_REF',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_CONFLICT_DET_AND_RES',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_FROM_MESS_SYSTEM',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_ALL_OTHER_QUERIES',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_ROLLBACK_AND_COMMIT',
        value: 'N'
      },
      {
        key: 'TRACING_INC_MESS_NB',
        value: 'Y'
      },
      {
        key: 'TRACING_MONITOR_STATS',
        value: 'Y'
      }
    ]
  } as LogReader;

  const mockJournals: string[] = ['journal1', 'journal2'];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'logreaders' } }],
      declarations: [LogReaderSidebarComponent, MockLogReaderFormComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogReaderSidebarComponent);
    metadataApiService = TestBed.inject(MetadataApiService);
    component = fixture.componentInstance;
    component.sourceDataConnection = mockedSourceConnection;
    logReadersApiService = TestBed.inject(LogReadersApiService);
    jasmine.getEnv().allowRespy(true);
    spyOn(logReadersApiService, 'createLogReader').and.returnValue(of(mockDefaultLogReader));
    spyOn(logReadersApiService, 'updateLogReader').and.returnValue(of(mockDefaultLogReader));
    spyOn(metadataApiService, 'getJournals').and.returnValue(of(mockJournals));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('add log reader', () => {
    it('should open in add mode', fakeAsync(() => {
      component.open();
      expect(component.isEditing).toBe(false);
    }));

    it('should update button states when form value changes', () => {
      component.logReaderFormComponent.logReaderFormGroup.patchValue({ name: 'LGNAME1' });
      expect(component.primaryButton.isDisabled).toBe(false);
    });

    it('should hide side bar', fakeAsync(() => {
      spyOn(component, 'cancelButtonClicked').and.callThrough();
      component.open();
      component.addLogReader();
      tick();
      expect(component.cancelButtonClicked).toHaveBeenCalled();
      expect(component.sidebarComponent.isVisible).toBe(false);
    }));

    it('should emit logReaderSavedEvent event', fakeAsync(() => {
      spyOn(component.logReaderSavedEvent, 'emit');
      component.open();
      component.addLogReader();
      tick();
      expect(logReadersApiService.createLogReader).toHaveBeenCalled();
      expect(component.logReaderSavedEvent.emit).toHaveBeenCalledWith(mockDefaultLogReader);
    }));

    it('should emit isVisibleChanged event', fakeAsync(() => {
      spyOn(component.isVisibleChanged, 'emit');
      component.open();
      component.addLogReader();
      tick();
      expect(component.isVisibleChanged.emit).toHaveBeenCalledWith(false);
    }));

    it('should be able to handle errors when adding a log reader', () => {
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      spyOn(logReadersApiService, 'createLogReader').and.returnValue(throwError({ error: { detailedMessage: 'createLogReader failed' } }));
      component.open();
      component.addLogReader();
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
    });

    it('should be able to handle errors when getJournals API fails', () => {
      const errorResponse = { error: { detailedMessage: 'getJournals failed' } };
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      spyOn(metadataApiService, 'getJournals').and.returnValue(throwError(errorResponse));
      component.open();
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
    });

    it('should retrieve the journals when refresh button is clicked', () => {
      component.refreshClickEvent();
      expect(metadataApiService.getJournals).toHaveBeenCalled();
    });
  });

  describe('edit log reader', () => {
    it('should open in edit mode', fakeAsync(() => {
      component.open(mockDefaultLogReader);
      expect(component.isEditing).toBe(true);
    }));

    it('should update the log reader', fakeAsync(() => {
      spyOn(component.logReaderSavedEvent, 'emit');
      component.open(mockDefaultLogReader);
      component.addLogReader();
      tick();
      expect(logReadersApiService.updateLogReader).toHaveBeenCalled();
    }));
  });
});
