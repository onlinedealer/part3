import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import SaveIcon from '@material-ui/icons/Save'
import RemoveCircle from '@material-ui/icons/RemoveCircle'
import Camera from '@material-ui/icons/Camera'
import AddCircle from '@material-ui/icons/AddCircle'
import SyncProblem from '@material-ui/icons/SyncProblem'
import CircularProgress from '@material-ui/core/CircularProgress'

const styles = theme => ({
  footer: {
    borderTop: '1px solid #E4E4E4',
    position: 'absolute',
    bottom: 0,
    width: '100%',
    background: '#fff',
    display: 'flex',
  },
  container: {
    width: '100%',
    textAlign: 'right',
    padding: '10px 0px',
  },
  addItemsButtonStyle: {
    border: '1px solid #1976d2',
    color: '#1976d2',
    fontWeight: 300,
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
  },
  saveButtonStyle: {
    position: 'relative',
    background: '#1976d2',
    margin: '0 20px',
    color: '#fff',
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
    '&disbaled': {
      background: 'rgb(182, 182, 182)',
      color: '#fff',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
    fontSize: 23,
  },
  addIcon: {
    width: '0.7em',
    height: '0.7em',
    marginRight: 10,
    borderRadius: 2,
  },
  saveIcon: {
    color: '#fff',
    background: 'transparent',
    width: '0.7em',
    height: '0.7em',
    marginRight: 7,
    borderRadius: 2,
  },
  syncStyle: {
    color: 'blue',
    fontSize: 10,
    '&:hover': {
      background: 'none',
      textDecoration: 'none',
      cursor: 'inherit',
    },
  },
})
class GroupFooter extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      drawerOpenStatus: false,
      saveBtnDisableStatus: true,
      removeBtnDisableStatus: true,
      createBtnDisableStatus: true,
    }
  }
  componentWillReceiveProps (nextProps) {
    this.setState({saveBtnDisableStatus: nextProps.isSaveDisabled, removeBtnDisableStatus: nextProps.isRemoveDisabled})
    if (nextProps.loadingBtnStatus.status && nextProps.loadingBtnStatus.btnName === 'Save Order') {
      this.setState({saveBtnDisableStatus: true})
    }
    if (nextProps.loadingBtnStatus.status && nextProps.loadingBtnStatus.btnName === 'Remove') {
      this.setState({removeBtnDisableStatus: true})
    }
    /* if (nextProps.themeUpdatedFlag) {
      this.setState({ createBtnDisableStatus: false })
    } else { */
    let createBtnDisableStatus = !((nextProps.themeTcinStateValue.length > 0))
    nextProps.themeTcinStateValue.map((tcinObj) => {
      if (tcinObj) {
        tcinObj.var_theme_value_list.map((themeObj) => {
          if (themeObj.value === '') {
            createBtnDisableStatus = true
          }
        })
      }
    })
    this.setState({ createBtnDisableStatus })
    // }
  }

  render () {
    const { classes, isSaveDisabled, validateUpdate, removeMultipleConfirmCB, loadingBtnStatus, createVariationGroupCB, groupDetails, editThemeValueStatus, sendThemeValueCB, contentPipelineCB } = this.props
    const { saveBtnDisableStatus, removeBtnDisableStatus, createBtnDisableStatus } = this.state
    let haveNewelyAddedItem = false
    if (groupDetails.items) {
      groupDetails.items.map((itemObj) => {
        if (itemObj.newelyAdded) {
          haveNewelyAddedItem = true
        }
      })
    }
    return (
      <div className={classes.footer}>
        <div className={classes.container}>
          <Grid container>
            <Grid item xs={12} >
              {!isSaveDisabled &&
              <Button className={classes.syncStyle}>
                <SyncProblem className={classes.addIcon} /> Pending Changes
              </Button>
              }
              {editThemeValueStatus &&
                <Button variant="contained" className={classes.saveButtonStyle} disabled={createBtnDisableStatus} onClick={sendThemeValueCB}>
                  <AddCircle className={classes.addIcon} />
                  {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Update Theme Value') &&
                  <CircularProgress
                    className={classes.progress}
                    size={25}
                  />
                  }
                      UPDATE THEME VALUES
                </Button>
              }
              {!groupDetails.group_id &&
                <Button variant="contained" className={classes.saveButtonStyle} disabled={createBtnDisableStatus} onClick={createVariationGroupCB}>
                  <AddCircle className={classes.addIcon} />
                  {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Create Group') &&
                  <CircularProgress
                    className={classes.progress}
                    size={25}
                  />
                  }
                      CREATE VARIATION GROUP
                </Button>
              }
              {!haveNewelyAddedItem &&
                <Button variant="contained" className={classes.saveButtonStyle} onClick={contentPipelineCB}>
                  <Camera className={classes.addIcon} />
                      Content Pipeline
                </Button>
              }
              {!haveNewelyAddedItem &&
                <Button variant="contained" className={classes.saveButtonStyle} disabled={removeBtnDisableStatus} onClick={removeMultipleConfirmCB}>
                  <RemoveCircle className={classes.addIcon} />
                  {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Remove') &&
                  <CircularProgress
                    className={classes.progress}
                    size={25}
                  />
                  }
                      REMOVE
                </Button>
              }
              {!haveNewelyAddedItem &&
                <Button variant="contained" className={classes.saveButtonStyle} disabled={saveBtnDisableStatus} onClick={validateUpdate}>
                  <SaveIcon className={classes.saveIcon} />
                  {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Save Order') &&
                  <CircularProgress
                    className={classes.progress}
                    size={25}
                  />
                  }
                      Save Order
                </Button>
              }
            </Grid>
          </Grid>
        </div>
      </div>
    )
  }
}

export default withStyles(styles)(GroupFooter)
