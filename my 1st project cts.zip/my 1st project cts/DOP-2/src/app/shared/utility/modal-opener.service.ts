import { Injectable } from '@angular/core';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';


@Injectable()
export class ModalOpenerService {
  constructor(private _modalService: NgbModal) { }
   /**
    * Opens Component/ content in a modal.
    * @param {Component} component Reference of the component/ Content which should be shown in the modal
    * @param {NgbModalOptions} options options for NgbModal
    * @returns NgbModalRef with the component
    */
    openModal(component , options, content?) {
        const modalRef = this._modalService.open(component , options);
       if (modalRef.componentInstance) {
        modalRef.componentInstance.content = content;
       }
        return modalRef;
    }
}
