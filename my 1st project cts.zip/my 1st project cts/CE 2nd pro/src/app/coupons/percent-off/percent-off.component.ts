import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';
import { CouponHelperService } from '../../services/coupon-helper.service';

@Component({
  selector: 'app-percent-off',
  templateUrl: './percent-off.component.html',
  styleUrls: ['./percent-off.component.scss']
})
export class PercentOffComponent implements OnInit {
  @Input() data: any

  imagesPaths: Object = ImagePaths
  serviceUrls: Object;

  constructor(public utilityService:UtilityService, public couponHelperService: CouponHelperService) { }

  ngOnInit() {
  }

}
