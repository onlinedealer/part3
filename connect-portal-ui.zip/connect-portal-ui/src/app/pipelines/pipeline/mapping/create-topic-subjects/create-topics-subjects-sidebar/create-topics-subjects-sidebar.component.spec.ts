import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { ProgressIndicatorStateService } from '@shared/components/progress-indicator/progress-indicator-state.service';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { of, Observable, throwError } from 'rxjs';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { EventApiService } from '../../shared/event-api.service';

import { CreateTopicsSubjectsSidebarComponent } from './create-topics-subjects-sidebar.component';

describe('CreateTopicsSubjectsSidebarComponent', () => {
  let component: CreateTopicsSubjectsSidebarComponent;
  let fixture: ComponentFixture<CreateTopicsSubjectsSidebarComponent>;
  let eventApiService: EventApiService;
  let pipelineMappingService: PipelineMappingService;
  @Component({
    selector: 'p-connect-sidebar',
    template: '',
    providers: [
      { provide: PipelineMappingService },
      {
        provide: SidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    open() {}
    close() {}
    parseHttpClientResponseMessage() {}
  }
  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['setIsComplete', 'setActiveStepIndex']
  );

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule(), RouterTestingModule],
      declarations: [CreateTopicsSubjectsSidebarComponent],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: '' } },
        { provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateTopicsSubjectsSidebarComponent);
    component = fixture.componentInstance;
    eventApiService = TestBed.inject(EventApiService);
    pipelineMappingService = TestBed.inject(PipelineMappingService);
    fixture.detectChanges();
    component.sidebarComponent = jasmine.createSpyObj<SidebarComponent>(['open', 'close']);
    component.pipeline = {
      createSubject: true,
      createTopic: true,
      name: 'test',
      description: 'test',
      dataFlowType: 'test',
      filters: [],
      properties: []
    };
  });

  it('should create', () => {
    component.ngOnInit();
    expect(component).toBeTruthy();
  });

  it('should trigger sidebar open method', () => {
    component.open();
    component.ngOnInit();

    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should trigger sidebar close method', () => {
    component.pipeline.id = 'abc';
    spyOn(component, 'navigateTo');
    component.closeButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should trigger sidebar close method when topics are created', () => {
    component.pipeline.createTopic = true;
    component.pipeline.createSubject = false;
    component.totalTopicsValue = 1;
    component.totalTopicsSuccessCount = 100;
    component.pipeline.id = 'abc';
    spyOn(component, 'navigateTo');
    component.closeButtonClicked();
    expect(component.navigateTo).toHaveBeenCalledWith(`/pipelines/${component.pipeline.id}/edit/finalize`);
    expect(mockProgressIndicatorStateService.setActiveStepIndex).toHaveBeenCalledWith(4);
  });

  it('should trigger sidebar close method when subjects are created', () => {
    component.pipeline.createTopic = false;
    component.pipeline.createSubject = true;
    component.totalSubjectsValue = 1;
    component.totalSubjectsSuccessCount = 100;
    component.pipeline.id = 'abc';
    spyOn(component, 'navigateTo');
    component.closeButtonClicked();
    expect(component.navigateTo).toHaveBeenCalledWith(`/pipelines/${component.pipeline.id}/edit/finalize`);
    expect(mockProgressIndicatorStateService.setActiveStepIndex).toHaveBeenCalledWith(4);
  });

  it('should handle seeErrors event when subjects errors clicked', () => {
    spyOn(component, 'getStatusOfSubjectCreation').and.returnValue();
    component.onSeeErrorsClicked('subjects');
    expect(component.getStatusOfSubjectCreation).toHaveBeenCalled();
  });

  it('should handle seeErrors event when topics errors clicked', () => {
    spyOn(component, 'getStatusOfTopicCreation').and.returnValue();
    component.onSeeErrorsClicked('topics');
    expect(component.getStatusOfTopicCreation).toBeDefined();
  });

  it('should get status of topics and subjects', () => {
    component.pipeline.createSubject = true;
    component.pipeline.createTopic = true;
    spyOn(component, 'getStatusOfSubjectCreation').and.returnValue();
    component.getStatusTopicAndSubjectsCreation();
    expect(component.getStatusOfSubjectCreation).toBeDefined();
  });

  it('should get status of subjects creation with success', () => {
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'complete', successCount: 1, totalCount: 1 } as any)
    );
    component.getStatusOfSubjectCreation();
    expect(component.totalSubjectsValue).toBe(1);
  });

  it('should get status of topics creation with success', () => {
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'complete', successCount: 1, totalCount: 1 } as any)
    );
    component.getStatusOfTopicCreation();
    expect(component.totalTopicsValue).toBe(1);
  });

  it('should get status of subjects creation with failure', () => {
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(
      of({ errResponse: [{ message: 'failed' }], failureCount: 1, status: 'complete', successCount: 0, totalCount: 1 } as any)
    );
    component.getStatusOfSubjectCreation();
    expect(component.subjectFailureErrors).toBe(true);
  });

  it('should get status of topics creation with failure', () => {
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(
      of({ errResponse: [{ message: 'failed' }], failureCount: 1, status: 'complete', successCount: 0, totalCount: 1 } as any)
    );
    component.getStatusOfTopicCreation();
    expect(component.topicFailureErrors).toBe(true);
  });

  it('should enable collapse sidebar button when topics creation status is complete and subject checkbox not selected', () => {
    component.topicsStatusComplete = true;
    component.pipeline.createSubject = false;
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'complete', successCount: 1, totalCount: 1 } as any)
    );
    component.getStatusOfTopicCreation();
    expect(component.secondaryButton.isDisabled).toBeFalsy();
  });
  it('should enable collapse sidebar button when topics creation status is complete and subject checkbox is selected', () => {
    component.pipeline.createSubject = true;
    component.topicsStatusComplete = true;
    component.subjectsStatusComplete = true;
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'complete', successCount: 1, totalCount: 1 } as any)
    );
    component.getStatusOfTopicCreation();
    expect(component.secondaryButton.isDisabled).toBeFalsy();
  });

  it('should enable collapse sidebar button when subjects creation status is complete and topic checkbox is selected', () => {
    component.pipeline.createTopic = true;
    component.topicsStatusComplete = true;
    component.subjectsStatusComplete = true;
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'complete', successCount: 1, totalCount: 1 } as any)
    );
    component.getStatusOfSubjectCreation();
    expect(component.secondaryButton.isDisabled).toBeFalsy();
  });

  it('should enable collapse sidebar button when subjects creation status is complete and topic checkbox not selected', () => {
    component.topicsStatusComplete = true;
    component.pipeline.createTopic = false;
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'complete', successCount: 1, totalCount: 1 } as any)
    );
    component.getStatusOfSubjectCreation();
    expect(component.secondaryButton.isDisabled).toBeFalsy();
  });

  it('should handle error for getStatusOfSubjectCreation', () => {
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(throwError({ status: 422 }));
    component.getStatusOfSubjectCreation();
    expect(component.secondaryButton.isDisabled).toBeTruthy();
  });

  it('should handle error for getStatusOfTopicCreation', () => {
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(throwError({ status: 422 }));
    component.getStatusOfTopicCreation();
    expect(component.secondaryButton.isDisabled).toBeTruthy();
  });

  it('should handle which progressBar to show', () => {
    component.handleTopicsSubjectsProgress(0, 0);
    expect(component.pipeline.createTopic).toBeFalsy();
  });
});
