export enum DataBrickConnectionOptionsModel {
  password = 'password',
  url = 'url'
}
