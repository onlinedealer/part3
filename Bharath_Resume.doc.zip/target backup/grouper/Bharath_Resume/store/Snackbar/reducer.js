import { fromJS } from 'immutable'
import {
  TOGGLE_SNACKBAR,
  LOADING_DATA_STATUS,
  LOADING_BTN_STATUS,
} from './actionType'

export const initialState = fromJS({
  snackbarMessage: {},
  loadingDataStatus: false,
  loadingBtnStatus: {
    status: false,
    btnName: '',
  },
})

export default function grouperReducer (state = initialState, action) {
  switch (action.type) {
    case TOGGLE_SNACKBAR:
      return state
        .set('snackbarMessage', fromJS(action.snackMessage))

    case LOADING_DATA_STATUS:
      return state
        .set('loadingDataStatus', fromJS(action.status))

    case LOADING_BTN_STATUS:
      return state
        .set('loadingBtnStatus', fromJS(action.btnPayload))

    default:
      return state
  }
}
