export class ProfileModel {
  id: string;
  dataProfile: string;
  dataSource: string;
  dataType: string;
  completeness: number;
  tableCount: number;
  recordCount: number;
  lastRun: number;
  duration: number;
  createdBy: string;
}
