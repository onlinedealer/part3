/**
 * @internal
 */
export const LOG_LEVELS = {
  TRACE: 0,
  DEBUG: 1,
  INFO: 2,
  WARN: 3,
  ERROR: 4,
  OFF: 5
};

/**
 * Default application log level.  This should be 'WARN' for release builds and 'DEBUG' for snapshot builds.
 * @internal
 */
export const DEFAULT_LOG_LEVEL = 'DEBUG';
