import { createSelector } from "@ngrx/store";
import * as fromRoot from "../reducers";
import * as fromEnvironmentIndicator from "../reducers/environment-indicator.reducer";

export const getTestProductionEnvironmentIndicator = createSelector(
    fromRoot.getEnvironmentIndicatorState,
    (state: fromEnvironmentIndicator.EnvironmentIndicatorState) => state?.entities
);

export const getTestProductionEnvironmentIndicatorText = createSelector(getTestProductionEnvironmentIndicator, (environmentIndicator) =>
    environmentIndicator?.text ? environmentIndicator.text : ""
);

export const getTestProductionEnvironmentIndicatorTextColor = createSelector(
    getTestProductionEnvironmentIndicator,
    (environmentIndicator) => (environmentIndicator?.textColor ? environmentIndicator.textColor : "")
);

export const getTestProductionEnvironmentIndicatorTextBoxColor = createSelector(
    getTestProductionEnvironmentIndicator,
    (environmentIndicator) => (environmentIndicator?.textBoxColor ? environmentIndicator.textBoxColor : "")
);
