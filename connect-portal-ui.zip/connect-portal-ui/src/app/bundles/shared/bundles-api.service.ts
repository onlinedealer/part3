import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Project } from 'src/app/pipelines/pipeline/shared/project';
import { environment } from '../../../environments/environment';
import { LogFileMetadata } from './bundles';

@Injectable({
  providedIn: 'root'
})
export class BundlesApiService {
  constructor(private httpClient: HttpClient) {}

  getBundles(): Observable<any> {
    const apiEndpoint = `${environment.connectApiBaseURL}/cdc/monitoring/bundles`;
    return this.httpClient.get(apiEndpoint);
  }

  getLogsFileMetadata(project: Project): Observable<any> {
    const apiEndpoint = `${environment.connectApiBaseURL}/cdc/monitoring/${project.id}/logs`;
    return this.httpClient.post(apiEndpoint, []);
  }

  createBundle(projectId: string, bundleName: string, bundleDescription: string, filesToBeBundled: LogFileMetadata): Observable<any> {
    const apiEndpoint = `${environment.connectApiBaseURL}/cdc/monitoring/bundles/full/start?projectId=${projectId}&bundleName=${bundleName}&description=${bundleDescription}`;
    return this.httpClient.post(apiEndpoint, filesToBeBundled);
  }

  stopBundle(ids: string[], headers?: HttpHeaders) {
    const apiEndpoint = `${environment.connectApiBaseURL}/cdc/monitoring/bundles/stop`;
    return this.httpClient.post(apiEndpoint, ids, { headers });
  }

  deleteBundle(ids: string[], headers?: HttpHeaders) {
    const apiEndpoint = `${environment.connectApiBaseURL}/cdc/monitoring/bundles/delete`;
    const options = {
      body: ids,
      headers
    };
    return this.httpClient.delete(apiEndpoint, options);
  }
}
