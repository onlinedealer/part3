import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { HttpUtilService } from '@precisely/prism-ng/cloud';
import { EventBusService } from 'core/eventBusService';
import { SharedConstants } from 'discovery-shared';
import { ToastrService } from 'ngx-toastr';
import { Subscription } from 'rxjs';
import { ValidationMessageTypeModel } from 'shared/form-validation-message/validation-message-type.model';
import { ValidationMessage } from 'shared/form-validation-message/validation-message.model';
import { ProfileMetadataModel } from '../profile-metadata.model';
import { ProfileResultsColumnModel } from '../profile-results-column.model';
import { ProfileResultsTableModel } from '../profile-results-table.model';
import { ProfileResultsService } from '../profile-results.service';
import { TreePath, Types } from './../tree-path.model';

@Component({
  selector: 'discovery-results',
  templateUrl: './results.component.html',
  styleUrls: ['./results.component.css']
})
export class ResultsComponent implements OnInit, OnDestroy {
  header: Types = new Types('', '', '');
  dataContext: any;
  _treePath: TreePath;
  _profileMetadata: ProfileMetadataModel;
  emptyTable: boolean;
  showResults: boolean;
  warningMessages: any[] = [];
  failureMessages: any[] = [];
  visitedTables = [];
  visitedColumns = [];
  ValidationMessageType: typeof ValidationMessageTypeModel = ValidationMessageTypeModel;
  historyResultSubscription: Subscription = {} as any;
  isLoadingResults: boolean;
  trendsSourceConstants = SharedConstants.TRENDS_SOURCE;
  popularityAuthText: boolean = false;

  constructor(
    private translocoService: TranslocoService,
    private profileResultsService: ProfileResultsService,
    private toastrService: ToastrService,
    private eventBusService: EventBusService,
    public httpUtil: HttpUtilService
  ) {}
  get treePath(): TreePath {
    return this._treePath;
  }

  @Input()
  set treePath(val: TreePath) {
    this._treePath = val;
    this.loadData();
  }

  get profileMetadata(): ProfileMetadataModel {
    return this._profileMetadata;
  }

  @Input()
  set profileMetadata(val: ProfileMetadataModel) {
    this._profileMetadata = val;
    this.loadData();
  }

  ngOnInit(): void {
    this._treePath = this.treePath;
    this.historyResultSubscription = this.eventBusService?.on<any>('HistoryResultsNavigation')?.subscribe((data) => {
      this.treePath.runId = data.runId;
      this.visitedTables = [];
      this.visitedColumns = [];
      this.warningMessages = [];
      this.failureMessages = [];
    });
  }

  ngOnDestroy(): void {
    this.historyResultSubscription.unsubscribe();
  }

  launchTrendsSidebar(stat: string) {
    this.eventBusService.emit('TrendsSidebarToggle', { flag: true, stat: stat });
  }

  loadData(): void {
    this.emptyTable = false;
    this.showResults = false;
    this.warningMessages = [];
    this.failureMessages = [];
    if (this._treePath) {
      if (this._treePath.tableView) {
        this.header = new Types(
          this._treePath.tableName.name,
          this.translocoService.translate('discoveryProfiling.results.result-level-header.table'),
          ''
        );
        if (this._treePath.treeData.data?.totalRows === 0) {
          this.toggleEmptyTable();
        } else if (this._treePath.treeData.data?.totalRows > 0) {
          const table = this.visitedTables.find((elem) => this.treePath.tableName.name === elem.name);
          if (table) {
            this.showResults = true;
            this.treePath.treeData.data = table;
          } else {
            // for table level error
            if (this.treePath.treeData.data.errorMessage) {
              this.showResults = true;
            } else {
              this.loadTableView();
            }
          }
        }
      } else if (this._treePath.columnView) {
        this.header = new Types(
          this._treePath.columnName.name + ' (' + this._treePath.columnName.type + ')',
          this.translocoService.translate('discoveryProfiling.results.result-level-header.column'),
          ''
        );
        if (this._treePath.treeData.parent.data?.totalRows === 0) {
          this.toggleEmptyTable();
        } else if (this._treePath.treeData.parent.data?.totalRows > 0) {
          const column = this.visitedColumns.find(
            (elem) => this.treePath.tableName.name === elem.tableName && this.treePath.columnName.name === elem.name
          );
          if (column) {
            this.showResults = true;
            this.treePath.treeData.data = column;
          } else {
            // for column level error
            if (this.treePath.treeData.data.errorMessage) {
              this.showResults = true;
            } else {
              this.loadColumnView();
            }
          }
        }

        if (this._treePath.columnName.type === 'virtual') {
        }
      } else if (this._treePath.modelView) {
        this.header.name = this._treePath.modelName;
        this.header.type = this.translocoService.translate('discoveryProfiling.results.result-level-header.model');
        this.loadModalView();
      }
    }
  }

  private loadModalView(): void {}

  private loadTableView(): void {
    this.isLoadingResults = true;
    this.profileResultsService
      .getTableStats(this.treePath.runId, this.profileMetadata, this.treePath.tableName.name)
      .subscribe(
        (profileResultsTableModel: ProfileResultsTableModel) => {
          this.isLoadingResults = false;
          this.showResults = true;
          this.treePath.treeData.data.statistics = profileResultsTableModel.statistics;
          this.getPropularityAuthStatus(this.treePath);
          for (const col of profileResultsTableModel.columns) {
            for (const [index, value] of this.treePath.treeData.data.columns.entries()) {
              if (this.treePath.treeData.data.columns[index].name === col.name) {
                this.treePath.treeData.data.columns[index].statistics = col.statistics;
              }
            }
          }
          this.visitedTables.push(this.treePath.treeData.data);
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.isLoadingResults = false;
          if (httpErrorResponse.status === 404 || httpErrorResponse.status === 400) {
            this.failureMessages = [
              new ValidationMessage(this.translocoService.translate('discoveryProfiling.results.noStatsAvailable'))
            ];
          } else {
            if (httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message) {
              this.failureMessages = [new ValidationMessage(httpErrorResponse.error.message)];
            }
          }
        }
      );
  }

  private loadColumnView(): void {
    this.isLoadingResults = true;
    this.profileResultsService
      .getColumnStats(
        this.treePath.runId,
        this.profileMetadata,
        this.treePath.tableName.name,
        this.treePath.columnName.name
      )
      .subscribe(
        (profileResultsColumnsModel: ProfileResultsColumnModel) => {
          this.isLoadingResults = false;
          this.treePath.treeData.data.statistics = profileResultsColumnsModel.statistics;
          this.getPropularityAuthStatus(this.treePath);
          const obj = { ...this.treePath.treeData.data, tableName: this.treePath.tableName.name };
          this.visitedColumns.push(obj);
          this.showResults = true;
        },
        (httpErrorResponse: HttpErrorResponse) => {
          this.isLoadingResults = false;
          if (httpErrorResponse.status === 404 || httpErrorResponse.status === 400) {
            this.failureMessages = [
              new ValidationMessage(this.translocoService.translate('discoveryProfiling.results.noStatsAvailable'))
            ];
          } else {
            if (httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message) {
              this.failureMessages = [new ValidationMessage(httpErrorResponse.error.message)];
            }
          }
        }
      );
  }

  private getPropularityAuthStatus(treePathData: TreePath) {
    if (treePathData?.treeData?.data?.statistics?.length > 0) {
      const tablePopularity = treePathData.treeData.data.statistics.filter(
        (stats) => stats.type === SharedConstants.STATS.POPULARITY
      );
      if (tablePopularity.length && !tablePopularity[0].isAuthorizedForPopularity) {
        this.popularityAuthText = true;
      }
    }
  }

  private toggleEmptyTable() {
    this.emptyTable = true;
    this.warningMessages = [
      new ValidationMessage(this.translocoService.translate('discoveryProfiling.results.noData'))
    ];
  }
}
