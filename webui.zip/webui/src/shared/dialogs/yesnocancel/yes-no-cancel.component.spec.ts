import { YesNoCancelComponent } from './yes-no-cancel.component';

describe('YesNoCancelComponent', () => {
  let component: YesNoCancelComponent;

  beforeEach(() => {
    component = new YesNoCancelComponent({} as any);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
