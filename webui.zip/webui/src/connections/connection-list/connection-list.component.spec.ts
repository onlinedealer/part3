import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Mocks, Spies } from 'discovery-test';
import { of, throwError } from 'rxjs';
import { ConnectionListComponent } from './connection-list.component';
import { ConfirmDialog, ConfirmDialogModule } from 'primeng/confirmdialog';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ConnectionService, SecondaryNavItemsService } from 'discovery-shared';
import { ConfirmationService } from 'primeng/api';
import { ToastrModule, ToastrService } from 'ngx-toastr';
import { TranslocoModule, TranslocoService } from '@ngneat/transloco';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { By } from '@angular/platform-browser';
import { TableModule } from 'primeng/table';
import { ContextMenuModule } from 'primeng/contextmenu';
import { SecondaryNavModule } from '@precisely/prism-ng/secondary-nav';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';

describe('ConnectionListComponent', () => {
  let component: ConnectionListComponent;
  let fixture: ComponentFixture<ConnectionListComponent>;
  let toasterService;
  let translocoService;

  beforeEach(() => {
    Spies.init();
    const mockSecNav = jasmine.createSpyObj('SecondaryNavItemsService', ['getNavItems']);
    TestBed.configureTestingModule({
      declarations: [ConnectionListComponent],
      imports: [
        CommonModule,
        HttpClientTestingModule,
        ConfirmDialogModule,
        FormsModule,
        RouterTestingModule,
        BrowserAnimationsModule,
        ToastrModule.forRoot(),
        TranslocoModule,
        TableModule,
        ContextMenuModule,
        SecondaryNavModule,
        TranslocoLocaleModule.forRoot()
      ],
      providers: [
        ConfirmationService,
        { provide: ConnectionService, useValue: Spies.ConnectionService },
        { ToastrService, useValue: Spies.ToastrService },
        { TranslocoService, useValue: Spies.TranslateService },
        { provide: LaunchDarklyService, useValue: Spies.launchDarklyService },
        { SecondaryNavItemsService, useValue: mockSecNav }
      ]
    });

    fixture = TestBed.createComponent(ConnectionListComponent);
    component = fixture.componentInstance;
    toasterService = TestBed.get(ToastrService);
    spyOn(toasterService, 'success');
    spyOn(toasterService, 'error');
    translocoService = TestBed.get(TranslocoService);
    spyOn(translocoService, 'translate');
    mockSecNav.getNavItems.and.returnValue(of([]));
    fixture.autoDetectChanges(true);
  });

  it('should check connection context menu', () => {
    const rowData = Mocks.MockConnections[0];
    component.connectionContextMenu(rowData);
    expect(component.items.length).toBe(5);
    // // eslint-disable-next-line max-len
    expect(component.items[0]['label']).toBe(
      translocoService.translate('discoveryConnections.connectionList.testConnection')
    );
  });

  it('should check get connection list', () => {
    component.ngOnInit();
    expect(component.connectionList.length).toBeDefined();
  });

  it('should check test connection success', () => {
    const connection = Mocks.MockConnections[0];
    Spies.ConnectionService.testConnectionByID.and.returnValue(of('success'));
    component.testConnection(connection);
    expect(toasterService.success).toHaveBeenCalled();
  });

  it('should check test connection error response 404', () => {
    const connection = Mocks.MockConnections[0];
    Spies.ConnectionService.testConnectionByID.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.testConnection(connection);
    expect(toasterService.error).toHaveBeenCalled();
  });

  it('should check test connection error other than 404', () => {
    const connection = Mocks.MockConnections[0];
    Spies.ConnectionService.testConnectionByID.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[1]));
    component.testConnection(connection);
    expect(toasterService.error).toHaveBeenCalled();
  });

  it('should check delete connection', () => {
    const connection = Mocks.MockConnections[0];
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const accept = spyOn(confirmdialog, 'accept').and.callThrough();
    Spies.ConnectionService.deleteConnection.and.returnValue(of('success'));
    component.deleteConnection(connection);
    fixture.detectChanges();
    const acceptBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-accept');
    acceptBtn.click();
    expect(accept).toHaveBeenCalled();
    expect(Spies.ConnectionService.getConnectionList).toHaveBeenCalled();
  });

  it('should call onDelete with error response', () => {
    const connection = Mocks.MockConnections[0];
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const accept = spyOn(confirmdialog, 'accept').and.callThrough();
    Spies.ConnectionService.deleteConnection.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.deleteConnection(connection);
    fixture.detectChanges();
    const acceptBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-accept');
    acceptBtn.click();
    expect(accept).toHaveBeenCalled();
  });

  it('should call onDelete with No button click', () => {
    const connection = Mocks.MockConnections[0];
    const confirmdialog: ConfirmDialog = fixture.debugElement.query(By.css('p-confirmdialog')).componentInstance;
    const reject = spyOn(confirmdialog, 'reject').and.callThrough();
    component.deleteConnection(connection);
    fixture.detectChanges();
    const noBtn = fixture.debugElement.nativeElement.querySelector('.p-confirm-dialog-reject');
    noBtn.click();
    expect(reject).toHaveBeenCalled();
  });
});
