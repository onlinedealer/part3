export class ProfileRunStatusModel {
  status: string;
  tables: TableStatusModel[];
  completenessPercentage: string;
  recordsCount: number;
  lastRun: string;
  duration: string;
  message: string;
}

export class TableStatusModel {
  name: string;
  status: string;
}
