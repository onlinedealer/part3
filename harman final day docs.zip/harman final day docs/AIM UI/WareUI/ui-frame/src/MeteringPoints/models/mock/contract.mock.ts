import { Contract } from "../contract.model";

export const contract: Contract = {
    id: 121,
    customer: {
        id: 101,
        name: "Seppo Ilmarinen",
        address: {
            streetName: "Seppo Ilmarinen Street",
            streetNumber: 1,
            streetNumberExtension: null,
            apartment: null,
            areaCode: null,
            areaName: null,
            postalCode: "99991",
            city: "JYSKAWICE",
            territory: null,
            countryCode: null,
            postOfficeBox: null
        },
        email: null,
        telephoneNumber: null
    },
    contractNo: "80040887624606837337",
    contractType: "CONNECTION_CONTRACT",
    contractTypeInUi: "Connection contract",
    contractorNo: null,
    customerNo: "CUST101",
    periodicity: {
        id: 1,
        interval: 1,
        name: "Calendar month",
        periodicity: "M",
        startDate: 1009836000000
    },
    validFrom: 1514757600000,
    validTo: 12,
    productId: 12,
    meteringPointId: 242
};

export const contracts: Contract[] = [contract];
