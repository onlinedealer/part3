import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';

//import { dataService } from '../services/data.service';
 
@Component({
  selector: 'app-reg',
  templateUrl: './reg.component.html',
  styleUrls: ['./reg.component.css'],

})
export class RegComponent {
  model: any = {};
  empData;
  signOut;
  editEmpRowData: any = {
    first_name: '',
    last_name: '',
    id: ''
  };
  constructor(private http: HttpClient,private router: Router){ 
      this.http.get('https://reqres.in/api/users?page=2').subscribe(data => {
         this.empData = data.data;
        if(data.data.length > 0){
          localStorage.setItem("employees", JSON.stringify(data.data));
        }
      }); 
  }
  ngOnInit(): void {
      //this._postsArray = this.myDataService.getFetchingData();
      
  }
  signingOut(){
    this.router.navigate(['/login']);
  }
  submitData(modelData, event){
    if (modelData.firstName === undefined && modelData.lastName === undefined && modelData.id === undefined ) {
      alert("Registration Failed, All Details are required")
    }
    else{
      this.router.navigate(['/reg']);
      var localData = JSON.parse(localStorage.getItem("employees"));
      localData.push(modelData);
      this.empData = localData;
      localStorage.setItem("employees", JSON.stringify(localData));
    }
    console.log(modelData)
  }
  popModel(){
    this.model = {};
  }

  edit(rowData){
    this.editEmpRowData = rowData;
  }
  save(updatedRowData){
      var localData = JSON.parse(localStorage.getItem("employees"));
      localData.push(updatedRowData);
      this.empData = updatedRowData;
      localStorage.setItem("employees", JSON.stringify(this.empData));
  }
 }
