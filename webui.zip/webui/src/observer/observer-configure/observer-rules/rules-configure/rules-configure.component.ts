import { Component, EventEmitter, Input, Output } from '@angular/core';
import { ObserverConstants } from 'observer/observer-constants';
@Component({
  selector: 'discovery-rules-configure',
  templateUrl: './rules-configure.component.html',
  styleUrls: ['./rules-configure.component.scss']
})
export class RulesConfigureComponent {
  @Input() rulesConfig: { ruleType: string; data: Record<string, unknown> };
  @Input() ruleSidebarVisible: boolean;
  @Output() ruleSidebarVisibleChange: EventEmitter<boolean> = new EventEmitter<boolean>();

  ruleTypeConstants = ObserverConstants.RULE_METRIC_TYPES;

  showRulesSidebar(event) {
    this.ruleSidebarVisible = event;
    this.ruleSidebarVisibleChange.emit(this.ruleSidebarVisible);
  }
  onHide() {
    this.showRulesSidebar(false);
  }
}
