import { Component, ComponentRef, Input, OnInit, TemplateRef } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from 'src/app/connections/shared/connection';
import { AddDatabase } from '../shared/addDatabase';

@Component({
  selector: 'p-connect-add-database-form',
  templateUrl: './add-database-form.component.html'
})
export class AddDatabaseFormComponent implements OnInit {
  addDatabaseForm: FormGroup;
  constructor(private readonly formBuilder: FormBuilder) {}
  /**
   * Source data connection
   */
  @Input() sourceDataConnection: Connection;

  /**
   * Selected Databases
   */
  @Input() selectedDatabase: any[];

  /**
   *Error Template
   */
  @Input() errorTemplate: TemplateRef<any>;

  /**
   * Toggle displaying error message
   */
  displayErrorMessage: boolean = false;

  /**
   * Reference to the child connection form
   */
  childComponentReference: ComponentRef<any>;

  ngOnInit(): void {
    this.createForm();
  }

  private createForm(): void {
    this.addDatabaseForm = this.formBuilder.group({
      adminUserId: new FormControl('sa', [Validators.required]),
      password: new FormControl('', [Validators.required])
    });
  }

  getDatabaseObject(): AddDatabase {
    const addDatabase = {} as AddDatabase;
    addDatabase.dataConnectionId = this.sourceDataConnection.id;
    addDatabase.userDataBaseNames = this.selectedDatabase;
    addDatabase.adminUserId = this.addDatabaseForm.get('adminUserId').value;
    addDatabase.adminUserPassword = this.addDatabaseForm.get('password').value;
    return addDatabase;
  }
}
