export enum ScheduleOccurenceTypeEnum {
  DAILY = 'daily',
  WEEKLY = 'weekly'
  //Future scope
  // HOURLY = 'hourly',
  // MONTHLY ='MONTHLY'
}
