import { Injectable } from '@angular/core';

@Injectable()
export class StateUtilityService {

  constructor() { }
  states: any = [
    {
        'name': 'Armed Forces Americas',
        'abv': 'AA'
    },
    {
        'name': 'Armed Forces MiddleEast',
        'abv': 'AE'
    },
    {
        'name': 'Alaska',
        'abv': 'AK'
    },
    {
        'name': 'Alabama',
        'abv': 'AL'
    },
    {
        'name': 'Armed Forces Pacific',
        'abv': 'AP'
    },
    {
        'name': 'Arkansas',
        'abv': 'AR'
    },
    {
        'name': 'American Samoa',
        'abv': 'AS'
    },
    {
        'name': 'Arizona',
        'abv': 'AZ'
    },
    {
        'name': 'California',
        'abv': 'CA'
    },
    {
        'name': 'Colorado',
        'abv': 'CO'
    },
    {
        'name': 'Connecticut',
        'abv': 'CT'
    },
    {
        'name': 'District of Columbia',
        'abv': 'DC'
    },
    {
        'name': 'Delaware',
        'abv': 'DE'
    },
    {
        'name': 'Florida',
        'abv': 'FL'
    },
    {
        'name': 'Georgia',
        'abv': 'GA'
    },
    {
        'name': 'Guam',
        'abv': 'GU'
    },
    {
        'name': 'Hawaii',
        'abv': 'HI'
    },
    {
        'name': 'Iowa',
        'abv': 'IA'
    },
    {
        'name': 'Idaho',
        'abv': 'ID'
    },
    {
        'name': 'Illinois',
        'abv': 'IL'
    },
    {
        'name': 'Indiana',
        'abv': 'IN'
    },
    {
        'name': 'Kansas',
        'abv': 'KS'
    },
    {
        'name': 'Kentucky',
        'abv': 'KY'
    },
    {
        'name': 'Louisiana',
        'abv': 'LA'
    },
    {
        'name': 'Massachusetts',
        'abv': 'MA'
    },
    {
        'name': 'Maryland',
        'abv': 'MD'
    },
    {
        'name': 'Maine',
        'abv': 'ME'
    },
    {
        'name': 'Michigan',
        'abv': 'MI'
    },
    {
        'name': 'Minnesota',
        'abv': 'MN'
    },
    {
        'name': 'Mississippi',
        'abv': 'MS'
    },
    {
        'name': 'Missouri',
        'abv': 'MO'
    },
    {
        'name': 'Montana',
        'abv': 'MT'
    },
    {
        'name': 'Nebraska',
        'abv': 'NE'
    },
    {
        'name': 'Nevada',
        'abv': 'NV'
    },
    {
        'name': 'Northern Mariana Islands',
        'abv': 'MP'
    },
    {
        'name': 'New Hampshire',
        'abv': 'NH'
    },
    {
        'name': 'New Jersey',
        'abv': 'NJ'
    },
    {
        'name': 'New Mexico',
        'abv': 'NM'
    },
    {
        'name': 'New York',
        'abv': 'NY'
    },
    {
        'name': 'North Carolina',
        'abv': 'NC'
    },
    {
        'name': 'North Dakota',
        'abv': 'ND'
    },
    {
        'name': 'Ohio',
        'abv': 'OH'
    },
    {
        'name': 'Oklahoma',
        'abv': 'OK'
    },
    {
        'name': 'Oregon',
        'abv': 'OR'
    },
    {
        'name': 'Pennsylvania',
        'abv': 'PA'
    },
    {
        'name': 'Puerto Rico',
        'abv': 'PR'
    },
    {
        'name': 'Rhode Island',
        'abv': 'RI'
    },
    {
        'name': 'South Carolina',
        'abv': 'SC'
    },
    {
        'name': 'South Dakota',
        'abv': 'SD'
    },
    {
        'name': 'Tennessee',
        'abv': 'TN'
    },
    {
        'name': 'Texas',
        'abv': 'TX'
    },
    {
        'name': 'Utah',
        'abv': 'UT'
    },
    {
        'name': 'Vermont',
        'abv': 'VT'
    },
    {
        'name': 'Virginia',
        'abv': 'VA'
    },
    {
        'name': 'Washington',
        'abv': 'WA'
    },
    {
        'name': 'West Virginia',
        'abv': 'WV'
    },
    {
        'name': 'Wisconsin',
        'abv': 'WI'
    },
    {
        'name': 'Virgin Islands',
        'abv': 'VI'
    },
    {
        'name': 'Wyoming',
        'abv': 'WY'
    }
];
}
