import { HistoryTableComponent } from './history-table.component';

describe('HistoryTableComponent', () => {
  let component: HistoryTableComponent;

  beforeEach(() => {
    component = new HistoryTableComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
  it('should run ngOnInit', () => {
    component.historyDetails.tableData = [
      {
        duration: '00:00:21',
        id: '402880877f93feb0017f9693f8090007',
        run: 1647498754033,
        status: 'SUCCESS'
      }
    ];
    component.ngOnInit();
    expect(component.historyData.length).toBeGreaterThanOrEqual(1);
  });
  it('should run ngOnInit with empty list', () => {
    component.historyDetails.tableData = [];
    component.ngOnInit();
    expect(component.scrollCount).toBe(0);
    expect(component.historyData.length).toBe(0);
  });
  it('should run navigateHistoryWithParam output event', () => {
    spyOn(component.historyRunId, 'emit');
    component.navigateHistoryWithParam('ea45sdf');
    expect(component.historyRunId.emit).toHaveBeenCalled();
  });
});
