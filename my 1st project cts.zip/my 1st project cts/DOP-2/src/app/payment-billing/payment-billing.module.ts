import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaymentSubscriptionComponent } from './payment-subscription/payment-subscription.component';
import { PaymentBillingComponent } from './payment-billing/payment-billing.component';
import { CardDetailsComponent } from './card-details/card-details.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddressDetailsModule } from 'address-details-module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule, FormsModule, ReactiveFormsModule, AddressDetailsModule, SharedModule
  ],
  declarations: [PaymentSubscriptionComponent, PaymentBillingComponent, CardDetailsComponent],
  exports: [ PaymentSubscriptionComponent, PaymentBillingComponent, CardDetailsComponent ]
})
export class PaymentBillingModule { }
