(function () {
    'use strict';

    angular.module('arm').controller('signinCtrl',
        ['$scope', '$state', 'authService', 'localStorageService', 'utility', '$filter','GENERAL_CONFIG', 'ALERT_MESSAGE', '$rootScope', 'MASTER_TABLE','$cordovaDialogs',signinController]);
    function signinController($scope, $state, authService, localStorageService, utility, $filter, GENERAL_CONFIG, ALERT_MESSAGE, $rootScope,MASTER_TABLE,$cordovaDialogs) {
        // toggle footer logo input focus, blur
		$scope.footerToggle = function () {
			$scope.footer = true;
		}	
		$scope.footerblurred = function () {
			$scope.footer = false;
		}
		$scope.user = {
            email: '',
            password: ''
        };
		// Toggle end 
		$scope.isChecked = false;
        function init() {
             loadLogo();
        }

        init();

        $scope.rememberMeTapped = function(){
            $scope.isRememberMeSelected =! $scope.isRememberMeSelected;
            if($scope.isRememberMeSelected)
              utility.setMasterData(GENERAL_CONFIG.RememberMeFlag, true);
            else
              utility.setMasterData(GENERAL_CONFIG.RememberMeFlag, false);
        };

        function rememberMe(){
            //console.log($scope.getLocalValues)
            var flag = utility.getMasterDataByKey(GENERAL_CONFIG.RememberMeFlag);
            if(flag){
                var storedInUserAndPass = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
                $scope.user.email = storedInUserAndPass.UserName;
                $scope.isRememberMeSelected = true;
            }
            else{
                $scope.user.email = "";
                $scope.user.password = "";
                $scope.isRememberMeSelected = false;
            }
        };
        rememberMe();

        $scope.submitLogin = function () {

            utility.clearIonicHistory(); //Clearing ionic history on every new log in.
            $rootScope.isAccessingOtherUserProfile = false;

            $rootScope.loadNewMasterDataForLoggedInAsUser = false;
            if (utility.removeWhitespace($scope.user.email) == '') {
               $cordovaDialogs.alert(ALERT_MESSAGE.EMAIL, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                .then(function () {
                                });
                return false;
            }
            if (utility.removeWhitespace($scope.user.password) == '') {
               $cordovaDialogs.alert(ALERT_MESSAGE.PASSWORD, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                .then(function () {
                                });
                return false;
            }
            authService.loginAction($scope.user).then(function (response) {

            if (response.UserID == null) {
                return;
            }

            $scope.loggedInResponse =  response;
            $rootScope.token = $scope.loggedInResponse.Token;
            $rootScope.loggedInUserID = $scope.loggedInResponse.UserID;
            $rootScope.languageID = 1;

            var hasRootUserChanged = false;
            var storedLoggedInUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
            if (storedLoggedInUser != null && typeof storedLoggedInUser != 'undefined' && storedLoggedInUser.UserID != $scope.loggedInResponse.UserID) {
                hasRootUserChanged = true;
            }

            var isOldUser = utility.getMasterDataByKey(GENERAL_CONFIG.OldUser);
                if(!isOldUser)
                {
                  isOldUser = true;
                  utility.setMasterData(GENERAL_CONFIG.OldUser, true);

                  $scope.loggedInResponse.Token = '';
                  utility.setMasterData(MASTER_TABLE.LoggedInUserInfo, $scope.loggedInResponse);

                  utility.setMasterData(GENERAL_CONFIG.ServerDateTimes, utility.prepareServerDateTimes());
                  var credentials = { "data": [{ "userName": $scope.user.email, "password": $scope.user.password }] };
                  authService.sqlUserInsert(credentials.data[0],$scope.loggedInResponse);
                }

            utility.wipeUserData(hasRootUserChanged).then(function (result) {

                 var isOldUser = utility.getMasterDataByKey(GENERAL_CONFIG.OldUser);
                if(!isOldUser)
                {
                  isOldUser = true;
                  utility.setMasterData(GENERAL_CONFIG.OldUser, true);

                  $scope.loggedInResponse.Token = '';
                  utility.setMasterData(MASTER_TABLE.LoggedInUserInfo, $scope.loggedInResponse);

                  utility.setMasterData(GENERAL_CONFIG.ServerDateTimes, utility.prepareServerDateTimes());
                  var credentials = { "data": [{ "userName": $scope.user.email, "password": $scope.user.password }] };
                  authService.sqlUserInsert(credentials.data[0],$scope.loggedInResponse);
                }
                utility.activeUserName();
                authService.loadMasterData().then(function (res) {
                    utility.storeMasterData(res);
                    //TODO Call HomeList Service and on success response $state.go('tab.home');
                    authService.sqlUserDelete().then(function (res) {
                         authService.loadUserListData().then(function (res) {
                             $state.go('tab.home');
                         }, function (err) {
                             $scope.errorMessage = err;
                         });
                    },function (err) {
                         $scope.errorMessage = err;
                    });
                },
                function (err) {
                    $scope.errorMessage = err;
                });
                                }, function (error) {
                                        
                                        });
            },
             function (err) {
                 $scope.errorMessage = err;
                 $cordovaDialogs.alert(err, ALERT_MESSAGE.ALERT_TITLE, 'OK')
                                   .then(function () {
                                    });

             });
        };

        $scope.$watch(function () { return $filter('translate')('lang.login.emailPlaceHolder'); },
                function (newval) { $scope.emailPlaceHolder = newval; }
        );

        $scope.$watch(function () { return $filter('translate')('lang.login.passwordPlaceHolder'); },
              function (newval) { $scope.passwordPlaceHolder = newval; }
        );

        //showed the logo
        function loadLogo() {
            document.addEventListener('deviceready', function () {
                //////////////////////////////////////strat comment////////////////////worked///////
                window.requestFileSystem(LocalFileSystem.PERSISTENT, 2 * 1024 * 1024, function (fs) {
                    //console.log('file system open: ' + fs.name);
                    // Make sure you add the domain name to the Content-Security-Policy <meta> element.
                    var url = 'http://cdn.theatlantic.com/assets/media/img/photo/2015/11/images-from-the-2016-sony-world-pho/s01_130921474920553591/main_900.jpg?1448476701';
                    // Parameters passed to getFile create a new file or return the file if it already exists.
                    fs.root.getFile('en.translation.json', { create: true, exclusive: false }, function (fileEntry) {
                        download(fileEntry, url, true);

                    }, onErrorCreateFile);

                }, onErrorLoadFs);


            })
        }

        function onErrorLoadFs() {

        }

        function onErrorCreateFile() {

        }

        function onErrorReadFile() {
        }

        function displayImage(blob) {

            // Note: Use window.URL.revokeObjectURL when finished with image.
            var objURL = window.URL.createObjectURL(blob);

            // Displays image if result is a valid DOM string for an image.
            var elem = document.getElementById('imageFile');
            elem.src = objURL;
        }

        function readBinaryFile(fileEntry) {
            fileEntry.file(function (file) {
                var reader = new FileReader();

                reader.onloadend = function () {

                    //console.log("Successful file read: " + this.result);
                    // displayFileData(fileEntry.fullPath + ": " + this.result);

                    var blob = new Blob([new Uint8Array(this.result)], { type: "image/png" });
                    displayImage(blob);
                };

                reader.readAsArrayBuffer(file);

            }, onErrorReadFile);
        }

        function displayImageByFileURL(fileEntry) {
            var elem = document.getElementById('imageFile');
            elem.src = fileEntry.toURL();
        }

        function download(fileEntry, uri, readBinaryData) {

            var fileTransfer = new FileTransfer();
            var fileURL = fileEntry.toURL();

            fileTransfer.download(
                uri,
                fileURL,
                function (entry) {
                    //console.log("Successful download...");
                    //console.log("download complete: " + entry.toURL());
                    if (readBinaryData) {
                        // Read the file...
                        readBinaryFile(entry);
                    }
                    else {
                        // Or just display it.
                        displayImageByFileURL(entry);
                    }


                },
                function (error) {
                    //console.log("download error source " + error.source);
                    //console.log("download error target " + error.target);
                    //console.log("upload error code" + error.code);
                },
                null, // or, pass false
                {
                    //headers: {
                    //    "Authorization": "Basic dGVzdHVzZXJuYW1lOnRlc3RwYXNzd29yZA=="
                    //}
                }
            );
        }
        //end show the logo
    };
})();
