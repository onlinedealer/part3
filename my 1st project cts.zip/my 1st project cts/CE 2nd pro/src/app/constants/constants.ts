/**
 * This file is use to define static text used in the application
 * 
 */
export const GlobalConfig = {
    BCC_FOOTER_ID: "25203",
    BCC_ANONYMOUS_SLOT1_ID: "46000",
    BCC_ANONYMOUS_SLOT2_ID: "46001"
}