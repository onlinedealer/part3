(function() {
    'use strict';

    fileuploader.controller("templateTableCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$location', '$route', '$window', '$timeout', '$http', '$uibModal', 'ngTableParams', templateTableCtrl]);

    function templateTableCtrl($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $location, $route, $window, $timeout, $http, $uibModal, ngTableParams) {

        $rootScope.globalTemplateD = "";
        $rootScope.globalListTempData = "";

        $scope.fileuploadPopUp = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: uiRouters.directivesHtmlPath + '/filePopUpTemplatePage.html',
                controller: 'ModalInstanceTemplateController',
            });
        };
        $scope.openViewHtml = function(data) {
            $location.url(uiRouters.viewTemplate);
            $rootScope.globalTemplateD = data;
            //console.log(data)
        };

        $scope.fetchDataTable = function() {
            //var url = "/ocr/rest/v1/service/get/all/template";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/listOfTemplate.json', 'GET', {});
            //var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
            promise.then(function(d) {
                $scope.data = d;
                $rootScope.globalListTempData = d;
                
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
        };
        $scope.fetchDataTable();

    }

    // model Instance controller for popup upload function
    fileuploader.controller('ModalInstanceTemplateController', ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$uibModalInstance', '$route', '$location', '$timeout', '$http', ModalInstanceTemplateController]);

    function ModalInstanceTemplateController($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $uibModalInstance, $route, $location, $timeout, $http) {

        $scope.errorShow = false;
        $scope.createButtonHide = true;
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.uploadFile = function() {
            if ($scope.myFile) {
                var file = $scope.myFile;
                var filename = file.name;
                var valid = /(\.jpg|\.jpeg|\.png|\.pdf|\.PDF|\.PNG|\.TIFF|\.tiff|\.JPEG|\.JPG)$/i;
                if (!valid.exec(filename)) {
                    alert("upload valid file, like .pdf, .png, .tiff, .jpg")
                } else {
                    indicatorStart("upload File....Please wait");
                    var uploadUrl = '/ocr/rest/v1/service/upload/template/file/';
                    var fd = new FormData();
                    $rootScope.globalFileName = file.name;
                    console.log($rootScope.globalFileName)
                    fd.append('file', file);
                    $http.post(uploadUrl, fd, {
                            transformRequest: angular.identity,
                            headers: {
                                'Content-Type': undefined
                            }
                        })
                        .success(function(d) {
                            indicatorStop();
                            $scope.uploadResponse = d;
                            $rootScope.globalTemplateUpResp = $scope.uploadResponse;
                            console.log($scope.uploadResponse)
                            $scope.cancel();
                            $location.url(uiRouters.createTemplate);
                        })
                        .error(function(data, status, headers, config) {

                        });         
                }

            } else {
                alert("First Select the file and click upload")
            }
        };
    }
})();
