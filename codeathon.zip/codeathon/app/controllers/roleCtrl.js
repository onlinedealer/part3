(function() {
    'use strict';

    codeathonApp.controller("roleCtrl", ['$scope', '$ajaxFactory', 'uiRouters','$location', roleCtrl]);

    function roleCtrl($scope, $ajaxFactory, uiRouters,$location) {
        $scope.roleDataSource = [];        
        $scope.itemData = {};
        $scope.isEditOrAddPage = false;
        $scope.isAddPage = false;
        $scope.userName = "";
        $scope.email = "";
        $scope.location = "";
        $scope.roleName = "";
        $scope.buttonText = "";
        $scope.headerText = "";
        $scope.searchText = "";
        $scope.rolesData = [];
        $scope.selectedRoleName = "";
        $scope.imageUrl = "images/balnkuser.png";
        var userId = "";
        var roleId = "";
        var url = "";

                // redirecting to /login page
        if (Codeathon.utils.isSessionItemAvailble('userId')) {
            $location.url(uiRouters.login);
            return false;
        } else {
            indicatorStart("Loading....");
            userId = Codeathon.utils.getSessionItem('userId');
        }


        $scope.searchByemail = function(obj) {
            console.log(obj.searchText)
            indicatorStart("Searching ..." + obj.searchText);
            url = "/get/profile/"+obj.searchText+"/"
            var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
				$scope.assignUserId=d.id;
                $scope.userName = d.name;
                $scope.email = d.email;
                $scope.location = d.location;
                $scope.roleName = d.roleList;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });

        };

        $scope.addItem = function() {
            $scope.isEditOrAddPage = true;
            $scope.isAddPage = true;
			$scope.assignUserId=d.userId;
            $scope.userName = "";
            $scope.email = "";
            $scope.location = "";
            $scope.roleName = "";
            $scope.buttonText = "Add";
            $scope.headerText = "Create";
        };

        $scope.removeItem = function(roleId) {
            indicatorStart("Deleting Role..");
            url = "/delete/role/" + roleId + "/user/" + userId + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'POST', {});

            promise.then(function(d) {
                $scope.roleDataSource = d;
                console.log('Delete Success');
				   $scope.fetchDataSource();
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        };

        $scope.saveData = function(e) {
            if (Codeathon.utils.isNullOrEmpty($scope.selectedRoleName)) {
                alert("All Fields Required");
                return;
            } else {
                var obj = {}
                obj.userId = $scope.assignUserId;
                obj.roleId = $scope.selectedRoleName;


                // if isAddPage true : Adding New Role
                // if isAddPage False : Editing Role
                if ($scope.isAddPage) {
                    indicatorStart("Adding Role..");
                    url = uiRouters.urlpath + "/add/role/"+ obj.roleId +"/user/"+  obj.userId + "/";
                } 
                var promise = $ajaxFactory.getDataFromServer(url, 'POST', obj);

                promise.then(function(d) {
                    $scope.roleDataSource = d;
                    $scope.isEditOrAddPage = false;
                    $scope.isAddPage = false;
                    console.log('Success');

                    var obj = {};
                    obj.message = "Role";
                    obj.content = "Success";
                    obj.eventObj = e;
                    $scope.$emit('openPopupEvent', obj);
					   $scope.fetchDataSource();
                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
                promise.finally(function(d) {
                    console.log('finally block executed', d);
                    indicatorStop();
                });

            }
        }

        $scope.cancel = function() {
            $scope.isEditOrAddPage = false;
            $scope.isAddPage = false;
        }

        $scope.fetchDataSource = function() {
            var url = "/get/list/of/role/user/" + userId + "/";
			//var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/roles/data.json', 'GET', {});

            promise.then(function(d) {
                $scope.roleDataSource = d;
				var obj=[];
				var obj1 = {}
                obj1.roleId = 2;
                obj1.roleName = "ROLE_ADMIN";
				var obj2 = {}
                obj2.roleId = 1;
                obj2.roleName = "ROLE_USER";
				obj.push(obj1);
				obj.push(obj2);
                $scope.rolesData = Codeathon.utils.getListByProperty(obj, 'roleId', 'roleName');
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
                indicatorStop();
            });
        }
        $scope.fetchDataSource();
    }

})();
