export interface Alert {
  host: string;
  id: string;
  level: string;
  levelInt: number;
  localTime: number;
  message: string;
  projectId: string;
  remoteTime: string;
  tenantId: string;
}
