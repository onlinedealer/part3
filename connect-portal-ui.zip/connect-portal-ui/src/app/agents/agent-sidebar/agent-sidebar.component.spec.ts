import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { MockSidebarComponent } from '../../shared/components/sidebar/mock-sidebar.component.spec';
import { AgentsApiService } from '../shared/agents-api.service';
import { AgentFormComponent } from './agent-form/agent-form.component';
import { AgentSidebarComponent } from './agent-sidebar.component';

@Component({
  selector: 'p-connect-agent-form',
  template: '',
  providers: [
    {
      provide: AgentFormComponent,
      useClass: MockAgentFormComponent
    }
  ]
})
class MockAgentFormComponent {
  agentFormGroup = new FormGroup({ agentName: new FormControl(''), agentId: new FormControl(''), agentDescription: new FormControl('') });
}

describe('AgentSidebarComponent', () => {
  let component: AgentSidebarComponent;
  let fixture: ComponentFixture<AgentSidebarComponent>;
  let agentsApiService: AgentsApiService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'agents' } }],
      declarations: [AgentSidebarComponent, MockSidebarComponent, MockAgentFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentSidebarComponent);
    component = fixture.componentInstance;
    agentsApiService = TestBed.inject(AgentsApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
    component.isVisible = true;
  });

  it('should update button states when form value changes', () => {
    component.agentFormComponent.agentFormGroup.patchValue({ agentName: '' });
    expect(component.primaryButton.isDisabled).toBe(false);
  });

  it('should be able to successfully save an existing a agent', () => {
    spyOn(component.agentFormComponent.agentFormGroup, 'reset').and.returnValue(null);
    component.agentFormComponent.agentFormGroup.patchValue({ agentId: 1, agentName: 'test' });
    spyOn(component.agentFormComponent.agentFormGroup, 'getRawValue').and.returnValue({});
    spyOn(agentsApiService, 'update').and.returnValue(of({ success: true }));
    component.saveAgentButtonClicked();
    expect(component.isVisible).toBe(false);
    expect(component.agentFormComponent.agentFormGroup.reset).toHaveBeenCalled();
  });

  it('should be able to handle errors when saving the agent', () => {
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(component.agentFormComponent.agentFormGroup, 'getRawValue').and.returnValue({});
    spyOn(agentsApiService, 'update').and.returnValue(throwError({ error: { detailedMessage: 'save failed' } }));
    component.saveAgentButtonClicked();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  });

  it('should update the form', () => {
    component.setAgent({ agentName: 'test', agentDescription: 'test description', agentId: 'abcd' });
    expect(component.agentFormComponent.agentFormGroup.get('agentName').value).toBe('test');
    expect(component.agentFormComponent.agentFormGroup.get('agentDescription').value).toBe('test description');
  });

  it('should update sidebar when esc key press', () => {
    spyOn(component.isVisibleChanged, 'emit');
    component.sideBarHidden(false);
    expect(component.isVisible).toBe(false);
    expect(component.isVisibleChanged.emit).toHaveBeenCalled();
  });
});
