(function() {
    'use strict';

    widget.controller("addCtrl", ['$scope', 'uiRouters', '$state', '$rootScope', 'ajaxFactory', addCtrl]);

    function addCtrl($scope, uiRouters, $state, $rootScope, ajaxFactory) {

 
    }
})();