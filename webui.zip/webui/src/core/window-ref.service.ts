import { Injectable } from '@angular/core';

/**
 * Provides access to the global window object in a way that is compatible with Angular's dependency
 * injection framework.  This is especially useful for unit testing.
 */
@Injectable({
  providedIn: 'root'
})
export class WindowRefService {
  /**
   * Returns the global `window` object.
   */
  get nativeWindow(): Window {
    return this.window;
  }

  private window: Window;

  /**
   * @internal
   */
  constructor() {
    this.window = window;
  }
}
