import { MeasuredUnit } from "./measuredunit.model";
import { MeasuredAttribute } from "./measuredattribute.model";
import { MeasurementType } from "./measurementtype.model";
import { ProductComponentDetail } from "./product-component-detail.model";
import { TimeZone } from "./timezone.model";

export interface Metering {
    loadedFrom: number | null;
    loadedUntil: number | null;
    measuredAttribute?: MeasuredAttribute;
    measuredUnit: MeasuredUnit;
    measurementType?: MeasurementType;
    productComponent?: ProductComponentDetail;
    meteringId: number;
    meteringPointId: number;
    meteringMode?: string;
    meteringType?: string;
    name: string;
    obis: string;
    obisA?: number;
    obisB?: number;
    obisC?: number;
    obisD?: number;
    obisE?: number;
    powerDimension: string;
    timeZone?: TimeZone;
    type: string;
    validFrom: number;
    validUntil: number;
    periodLength?: number;
    hasGaps?: boolean;
}

export interface MeteringIcon {
    name: string;
    tooltip: string;
    disabled: boolean;
}

export interface ProductComponent {
    meteringId: number;
    meteringPointId: number;
    meteringType: string;
}
