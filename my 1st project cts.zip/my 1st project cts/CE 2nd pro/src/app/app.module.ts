import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {  HttpClientModule } from '@angular/common/http';
import { JsonpModule } from '@angular/http';
import { RouterModule, Routes } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { LeftNavComponent } from './common/left-nav/left-nav.component';
import { SearchbarComponent } from './authenticated-view/searchbar/searchbar.component';
import { StickyScrollDirective } from './directives/sticky-scroll.directive';
import { BackToTopComponent } from './common/back-to-top/back-to-top.component';
import { YourFeedComponent } from './authenticated-view/your-feed/your-feed.component';
import { AllDealsComponent } from './authenticated-view/all-deals/all-deals.component';
import { OnCardComponent } from './authenticated-view/on-card/on-card.component';
import { ExpiringComponent } from './authenticated-view/expiring/expiring.component';
import { NewComponent } from './authenticated-view/new/new.component';
import { FinalPriceComponent } from './coupons/final-price/final-price.component';
import { DollarOffComponent } from './coupons/dollar-off/dollar-off.component';
import { PercentOffComponent } from './coupons/percent-off/percent-off.component';
import { SeqNumPipe } from './pipes/seq-num.pipe';
import { BoldPipe } from './pipes/sequence-num.pipe';
import { CustomDatePipe } from './pipes/custom-date.pipe';
import { EarnedXtrabucksComponent } from './coupons/earned-xtrabucks/earned-xtrabucks.component';
import { VariableXtracareComponent } from './coupons/variable-xtracare/variable-xtracare.component';
import { HomePageComponent } from './home-page/home-page.component';
import { AnonymousViewComponent } from './anonymous-view/anonymous-view.component';
import { AuthenticatedViewComponent } from './authenticated-view/authenticated-view.component';
import { UtilityService } from './services/utility.service';
import { AccountInfoComponent } from './authenticated-view/account-info/account-info.component';
import { DefaultComponent } from './coupons/default/default.component';
import { MultiOfferPageComponent } from './multi-offer-page/multi-offer-page.component';
import { CarepassPercentOffComponent } from './coupons/carepass-percent-off/carepass-percent-off.component';
import { CarepassDollarRewardComponent } from './coupons/carepass-dollar-reward/carepass-dollar-reward.component';
import { DigitalManufacturerComponent } from './coupons/digital-manufacturer/digital-manufacturer.component';
import { PhrLockedComponent } from './coupons/phr-locked/phr-locked.component';
import { LockedCebsComponent } from './coupons/locked-cebs/locked-cebs.component';
import { LockedPebsComponent } from './coupons/locked-pebs/locked-pebs.component';
import { CouponHelperService } from './services/coupon-helper.service';
import { BeautyClubComponent } from './coupons/beauty-club/beauty-club.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    LeftNavComponent,
    SearchbarComponent,
    StickyScrollDirective,
    BackToTopComponent,
    YourFeedComponent,
    AllDealsComponent,
    OnCardComponent,
    ExpiringComponent,
    NewComponent,
    FinalPriceComponent,
    DollarOffComponent,
    PercentOffComponent,
    SeqNumPipe,
    BoldPipe,
    CustomDatePipe,
    EarnedXtrabucksComponent,
    VariableXtracareComponent,
    HomePageComponent,
    AnonymousViewComponent,
    AuthenticatedViewComponent,
    AccountInfoComponent,
    DefaultComponent,
    MultiOfferPageComponent,
    CarepassPercentOffComponent,
    CarepassDollarRewardComponent,
    DigitalManufacturerComponent,
    PhrLockedComponent,
    LockedCebsComponent,
     LockedPebsComponent,
     BeautyClubComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    RouterModule,
    HttpClientModule,
    JsonpModule
  ],
  providers: [UtilityService,CouponHelperService],
  bootstrap: [AppComponent]
})
export class AppModule { }
