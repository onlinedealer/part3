import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { of } from 'rxjs';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { ProgressIndicatorStateService } from '../../shared/components/progress-indicator/progress-indicator-state.service';
import { ServersHomeComponent } from './servers-home.component';

describe('ServersHomeComponent', () => {
  let component: ServersHomeComponent;
  let fixture: ComponentFixture<ServersHomeComponent>;

  const mockLaunchDarklyService = jasmine.createSpyObj({
    dispose: () => of(),
    identify: () => of(),
    variation: () => {}
  });

  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['initiateProgressSteps', 'setActiveStepByRouterLink', 'setIsValid']
  );

  beforeEach(async () => {
    TestBed.overrideComponent(ServersHomeComponent, {
      set: {
        providers: [{ provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService }]
      }
    });

    await TestBed.configureTestingModule({
      imports: [getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [ServersHomeComponent],
      providers: [{ provide: LaunchDarklyService, useValue: mockLaunchDarklyService }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServersHomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('shouild set step to valid when server has been added', () => {
    component.serverSavedEvent();
    expect(mockProgressIndicatorStateService.setIsValid).toHaveBeenCalled();
  });
});
