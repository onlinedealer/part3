import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from "@angular/core";
import { BehaviorSubject } from "rxjs";

import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { TranslationsService } from "../../../../app/services/translations-service";

import { MultiplyMeteringValuesVO } from "../../../models/view-objects/meteringdata-vo.model";

@Component({
    selector: "landisgyr-multiply-metering-values-table",
    templateUrl: "./multiply-metering-values-table.component.html",
    styleUrls: ["./multiply-metering-values-table.component.scss"]
})
export class MultiplyMeteringValuesTableComponent implements OnChanges {
    @Input()
    timeSeries!: MultiplyMeteringValuesVO[];
    @Input()
    dialogValueDigitLength!: any;
    @Input()
    dataEdited!: boolean;
    @Output() sortChangeEventToDialog: EventEmitter<SortOrder> = new EventEmitter();
    infoMessage = $localize`:|@@meteringsList.noMeteringsFound:No metering data found`;
    sortingSubject: BehaviorSubject<{ active: string; direction: "asc" | "desc" }> = new BehaviorSubject({
        active: "",
        direction: "asc"
    } as any);
    scrollVisible = false;

    constructor(public translations: TranslationsService) {}

    ngOnChanges(changes: SimpleChanges): void {
        this.checkTableScroll();
    }

    onSortEvent(event: SortOrder) {
        this.sortChangeEventToDialog.emit(event);
    }

    checkTableScroll() {
        const tableContentHeight = this.timeSeries.length * 40;
        if (tableContentHeight / 362 >= 1) {
            this.scrollVisible = true;
        } else {
            this.scrollVisible = false;
        }
    }
}
