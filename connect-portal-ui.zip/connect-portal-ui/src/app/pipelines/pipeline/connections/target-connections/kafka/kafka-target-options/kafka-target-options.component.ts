import { Component, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { TranslocoService } from '@ngneat/transloco';
import { combineLatest, Observable } from 'rxjs';
import { map, startWith, tap } from 'rxjs/operators';
import { Connection } from '../../../../../../connections/shared/connection';
import { ConnectionsApiService } from '../../../../../../connections/shared/connections-api.service';
import { BaseComponent } from '../../../../../../core/base.component';
import { FeatureFlagService } from '../../../../../../shared/services/feature-flag.service';

@Component({
  selector: 'p-connect-kafka-target-options',
  templateUrl: './kafka-target-options.component.html',
  styleUrls: ['./kafka-target-options.component.scss']
})
export class KafkaTargetOptionsComponent extends BaseComponent implements OnInit {
  lang = 'pipelines';
  translationPrefix = 'STAGES.CONNECTIONS.SECTIONS.TARGET_OPTIONS';

  targetForm: FormGroup;
  isFeatureEnabled;
  acknowledgementOptions$: Observable<{ label: string; value: string }[]>;
  messageFormats$: Observable<{ label: string; value: string }[]>;
  imagesOptions$: Observable<{ label: string; value: string }[]>;
  schemaRegistries$: Observable<{ label: string; value: string }[]>;

  schemaConnectionTypes = ['SCHEMAREGISTRY'];
  isConnectionSidebarVisible = false;

  get isFeatureFlagEnabled() {
    return this.featureFlagService.isFeatureEnabled('CDCKafkaSchemaRegistryTemp20220628');
  }

  get messageFormatValue(): string {
    return this.targetForm.controls.messageFormat.value;
  }

  constructor(
    private readonly translocoService: TranslocoService,
    private readonly controlContainer: ControlContainer,
    private readonly featureFlagService: FeatureFlagService,
    private readonly connectionsService: ConnectionsApiService
  ) {
    super();
  }

  ngOnInit(): void {
    this.createForm();
    this.initiateAcknowledgementOptions();
    this.initiateMessageFormats();
    this.initiateImageOptions();
    if (this.isFeatureFlagEnabled) {
      this.getSchemaRegistryDataConnections();
    }
  }

  onMessageFormatChange($event) {
    if ($event.value === 'JSON') {
      if (!this.targetForm.get('omitNulls').value) {
        this.targetForm.get('omitNulls').setValue('1');
      }
      if (!this.targetForm.get('removeTrailingBlanks').value) {
        this.targetForm.get('removeTrailingBlanks').setValue('0');
      }
    }
  }

  private readonly createForm = () => {
    this.targetForm = this.controlContainer.control as FormGroup;
    this.targetForm.addControl('acknowledgement', new FormControl('WAIT_SINGLE_BROKER', Validators.required));
    this.targetForm.addControl('clientId', new FormControl(''));
    this.targetForm.addControl('messageFormat', new FormControl('CSV'));
    this.targetForm.addControl('recordDelimiter', new FormControl('\\n', [Validators.required, Validators.maxLength(10)]));
    this.targetForm.addControl('fieldDelimiter', new FormControl(',', [Validators.required, Validators.maxLength(10)]));
    this.targetForm.addControl('enclosingCharacter', new FormControl('"', Validators.maxLength(1)));
    this.targetForm.addControl('nullString', new FormControl('~', Validators.maxLength(10)));
    this.targetForm.addControl('schemaRegistries', new FormControl());
    this.targetForm.addControl('imagesToInclude', new FormControl('AFTER_ONLY'));
    this.targetForm.addControl('omitNulls', new FormControl('1'));
    this.targetForm.addControl('removeTrailingBlanks', new FormControl('0'));
    this.targetForm.addControl('messagePartitionBy', new FormControl('TABLE_NAME'));
    this.targetForm.addControl('prefixMessagesWithTableName', new FormControl('TRUE'));
  };

  private readonly initiateAcknowledgementOptions = () => {
    this.acknowledgementOptions$ = this.translocoService
      .selectTranslateObject(`${this.translationPrefix}.LABELS.ACKNOWLEDGEMENT_OPTIONS`, null, this.lang)
      .pipe(map((acknowledgementOptions) => this.transformToDropdownOptions(acknowledgementOptions)));
  };

  private readonly initiateMessageFormats = () => {
    this.messageFormats$ = this.translocoService.selectTranslate(`${this.translationPrefix}.LABELS.DELIMITED`, null, this.lang).pipe(
      map((value) => {
        let formats = [
          { label: 'Avro', value: 'AVRO' },
          {
            label: `CSV (${value})`,
            value: 'CSV'
          },
          { label: 'JSON', value: 'JSON' }
        ];

        if (!this.isFeatureFlagEnabled) {
          // Avro is not included if flag is not present
          formats = formats.filter((format) => format.label !== 'Avro');
        }

        return formats;
      })
    );
  };

  private readonly initiateImageOptions = () => {
    this.imagesOptions$ = combineLatest([
      // the options change based on the selected message format
      this.targetForm.controls.messageFormat.valueChanges.pipe(
        startWith('CSV') // default option
      ),
      this.translocoService.selectTranslateObject(`${this.translationPrefix}.LABELS.IMAGES_TO_INCLUDE_OPTIONS`, null, this.lang)
    ]).pipe(
      map(([msgFormat, imageOptions]) => {
        if (msgFormat === 'JSON' || msgFormat === 'AVRO') {
          this.targetForm.patchValue({
            imagesToInclude: 'BOTH'
          });
          return this.transformToDropdownOptions(imageOptions);
        } else {
          this.targetForm.patchValue({
            imagesToInclude: 'AFTER_ONLY'
          });
          return this.transformToDropdownOptions(imageOptions, 'BOTH');
        }
      })
    );
  };

  /**
   * Gets connection types that are Schema Registries and sets the dropdown.
   * Occurs when we load the pipeline and when a schema connection is added.
   * @param selectedConnection Optional connection to select from the dropdown after getting schema registries
   */
  getSchemaRegistryDataConnections(connectionToSelect?: { id: string }) {
    this.schemaRegistries$ = this.connectionsService.getAll().pipe(
      map((connections: Connection[]) => {
        return connections
          .filter((connection) => connection.connectionType === 'SCHEMAREGISTRY')
          .map((connection) => ({
            label: connection.name,
            value: connection.id
          }));
      }),
      tap((connections) => {
        if (connectionToSelect) {
          const selectedConnection = connections.find((connection) => connection.value === connectionToSelect.id);
          this.targetForm.get('schemaRegistries').setValue(selectedConnection.value);
        }
      })
    );
  }

  addSchemaRegistryConnection(): void {
    this.isConnectionSidebarVisible = true;
  }

  private transformToDropdownOptions(translationObject, filteredKey?): { label: string; value: string }[] {
    return Object.keys(translationObject)
      .filter((option) => option !== filteredKey)
      .map((key) => ({
        label: translationObject[key],
        value: key
      }));
  }
}
