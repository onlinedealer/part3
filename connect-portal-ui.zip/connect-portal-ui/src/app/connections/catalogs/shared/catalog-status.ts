import { CatalogSchema } from './catalog-schema';
import { CatalogSubject } from './catalog-subject';
import { CatalogTopic } from './catalog-topic';

export interface CatalogStatus {
  connectionId?: string;
  schemas?: CatalogSchema[];
  topics?: CatalogTopic[];
  subjects?: CatalogSubject[];
  status?: string;
  workspaceId?: string;
  // Error message in json format
  errorMessage?: string;
}

export enum CATALOG_STATUS {
  INPROGRESS = 'inprogress',
  COMPLETE = 'complete',
  NOT_CATALOGED = 'not_cataloged'
}
