export interface StatusSummaryDetail {
  completed: number;
  error: number;
  inprogress: number;
  stopped: number;
  total: number;
}

export interface SchemaStatusSummaryDetail extends StatusSummaryDetail {
  tables: StatusSummaryDetail;
}

export interface SubjectsStatusSummaryDetail extends StatusSummaryDetail {
  schemas: StatusSummaryDetail;
}

export interface CatalogStatusSummary {
  connectionId: string;
  schemas: SchemaStatusSummaryDetail;
  status: string;
  subjects: SubjectsStatusSummaryDetail;
  topics: StatusSummaryDetail;
  workspaceId: string;
}
