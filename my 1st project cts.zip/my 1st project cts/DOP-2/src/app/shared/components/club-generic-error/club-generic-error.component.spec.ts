import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClubGenericErrorComponent } from './club-generic-error.component';

describe('ClubGenericErrorComponent', () => {
  let component: ClubGenericErrorComponent;
  let fixture: ComponentFixture<ClubGenericErrorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClubGenericErrorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClubGenericErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
