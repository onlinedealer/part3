import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from "rxjs";
import { UtilityService } from '../services/utility.service';

@Injectable({
  providedIn: 'root'
})
export class CouponHelperService {
  serviceUrls: Object;
  allCoupons;

  constructor(private utilityService: UtilityService) {
    this.getServiceUrls();
  }

  getServiceUrls() {
    this.utilityService.serviceUrlsObservable$.subscribe((data) => {
      if (!this.utilityService.isEmpty(data) && !data.hasOwnProperty('error')) {
        this.serviceUrls = data['config']['serviceUrls'];
      } else if (data.hasOwnProperty('error')) {
      }
    });
  }

  /**
   * Check to see if coupon should be displayed or not
   */
  isCouponViewable(couponObj) {
    let viewable = false;
    if (couponObj.viewableInd == 'Y' && (couponObj.appOnlyInd == 'N' || (couponObj.appOnlyInd == 'Y' && couponObj.loadActlDt != ''))) {
      viewable = true;
    }
    return viewable;
  }

  /**
   * Check to see if coupon id on card or not
   */
  isCouponOnCard(eachCoupon) {
    if (eachCoupon.prntActlDt || eachCoupon.loadActlDt) {
      eachCoupon.showOnCardView = true;
    } else {
      eachCoupon.showOnCardView = false;
    }
  }

  showDetails(type, coupon) {
    let payload = {};
    let header = {};
    this.utilityService.showExpandedView(type, coupon.couponIndex);
    if (!coupon.hasOwnProperty("cpnTermsTxt")) {
      this.utilityService.sendRequest(this.serviceUrls['couponDefinition'], payload, header).subscribe((response) => {
        switch (true) {
          // if 'cpnTermsTxt' property missing
          case !(response['respCpnDefs'][0].hasOwnProperty("cpnTermsTxt")):{
            coupon['cpnTermsTxt'] = "Limit 1 coupon per customer per purchase";            
            break;
          }
          // if 'cpnTermsTxt' available, but it has empty/blank string
          case response['respCpnDefs'][0].cpnTermsTxt.length == 0:{
            coupon['cpnTermsTxt'] = "Limit 1 coupon per customer per purchase";            
            break;
          }
          // if 'cpnTermsTxt' available and it has value
          case response['respCpnDefs'][0].cpnTermsTxt && response['respCpnDefs'][0].cpnTermsTxt.length > 0:{
            coupon['cpnTermsTxt'] = response['respCpnDefs'][0].cpnTermsTxt;            
            break;
          }
          default:
            console.log('error');
            break;
        }
      },
        error => {
          console.log(error);
        });
    }
  }

}
