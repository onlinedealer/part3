import {
  getGrouperList,
  grouperListAPI,
  getGrouperTypes,
  getItemTypes,
  clearItemThemes,
  getItemThemes,
  addGroup,
  deleteGroup,
  closeSnackBar,
  clearActionTypes,
} from '../actionCreator'

import {
  TOGGLE_SNACKBAR,
} from '../../Snackbar/actionType'

import {
  GET_GROUPER_LIST,
  GET_GROUP_TYPES,
  GET_ITEM_TYPES,
  CLEAR_ITEM_THEMES,
  GET_ITEM_THEMES,
  ADD_GROUP,
  DELETE_GROUP,
  CLEAR_GROUP_ACTION_TYPES,
} from '../actionType'

import axios from 'axios'
import configureMockStore from 'redux-mock-store'

describe('Dashboard actionCreator', () => {
  const mockStore = configureMockStore()
  let store = mockStore()

  const groupListMock = [{'group_id': 5, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534306000, 'department': {'department_id': 244, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962800000, 'status': 'InActive'}]

  const mockResponse = (resp, shouldReject) => {
    axios.get = jest.fn(() => {
      return Promise[shouldReject ? 'reject' : 'resolve'](resp)
    })
  }

  afterEach(() => {
    store = mockStore()
  })

  it('dispatches GET_GROUPER_LIST', () => {
    const expectedAction = {
      type: GET_GROUPER_LIST,
      payload: {memberOf: 'x', userId: 'abc'},
    }
    expect(getGrouperList('x', 'abc')).toEqual(expectedAction)
  })

  it('dispatches grouperListAPI', () => {
    mockResponse({status: 200, data: groupListMock})
    // expect(grouperListAPI({memberOf: 'x', userId: 'abc'})).toEqual(groupListMock)
    const payload = {memberOf: 'x', userId: 'abc'}
    store.dispatch(grouperListAPI(), payload).then(() => {
      expect(groupListMock).toEqual(groupListMock)
    })
  })

  it('dispatches GET_GROUPER_LIST on request - Jira service', () => {
    mockResponse({status: 200, data: groupListMock})
    store.dispatch(grouperListAPI({memberOf: 'x', userId: 'abc'})).then(() => {
      expect(store.getActions()[0].type).toEqual(GET_GROUPER_LIST)
    })
  })

  it('dispatches GET_GROUP_TYPES', () => {
    const expectedAction = {
      type: GET_GROUP_TYPES,
      payload: {memberOf: 'x', userId: 'abc'},
    }
    expect(getGrouperTypes('x', 'abc')).toEqual(expectedAction)
  })

  it('dispatches GET_ITEM_TYPES', () => {
    const expectedAction = {
      type: GET_ITEM_TYPES,
      payload: {searchText: 'nec'},
    }
    expect(getItemTypes('nec')).toEqual(expectedAction)
  })

  it('dispatches CLEAR_ITEM_THEMES', () => {
    const expectedAction = {
      type: CLEAR_ITEM_THEMES,
    }
    expect(clearItemThemes()).toEqual(expectedAction)
  })

  it('dispatches GET_ITEM_THEMES', () => {
    const expectedAction = {
      type: GET_ITEM_THEMES,
      payload: { id: 123 },
    }
    expect(getItemThemes(123)).toEqual(expectedAction)
  })

  it('dispatches ADD_GROUP', () => {
    const mockData = {'group_type_id': 1, 'group_type': 'variation', 'group_name': 'Test123', 'tcin_data': [{'tcin': '21212', 'action': 'CREATED', 'sort_order': 1}], 'themes': [{'id': 93, 'attribute': 'Product Length', 'attribute_type': 'mta'}]}
    const expectedAction = {
      type: ADD_GROUP,
      payload: { data: mockData, memberOf: 'x', userId: 'abc' },
    }
    expect(addGroup(mockData, 'x', 'abc')).toEqual(expectedAction)
  })

  it('dispatches DELETE_GROUP', () => {
    const mockData = {'group_id': 123, 'group_type': 'variation'}
    const expectedAction = {
      type: DELETE_GROUP,
      payload: { data: mockData, memberOf: 'x', userId: 'abc' },
    }
    expect(deleteGroup(mockData, 'x', 'abc')).toEqual(expectedAction)
  })

  it('dispatches TOGGLE_SNACKBAR', () => {
    const expectedAction = {
      type: TOGGLE_SNACKBAR,
      snackMessage: {status: false, variant: 'info', message: ''},
    }
    expect(closeSnackBar()).toEqual(expectedAction)
  })

  it('dispatches CLEAR_GROUP_ACTION_TYPES', () => {
    const expectedAction = {
      type: CLEAR_GROUP_ACTION_TYPES,
    }
    expect(clearActionTypes()).toEqual(expectedAction)
  })
})
