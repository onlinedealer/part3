export const environment = {
  production: true,
  name: 'Prod'
};
