import { AppComponent } from "./app/app.component";
export const containers: any[] = [AppComponent];

export * from "./app/app.component";
