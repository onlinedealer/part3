import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SimpleChange, SimpleChanges } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { of } from 'rxjs';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { Connection } from '../../../../connections/shared/connection';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { Pipeline, PIPELINE_ENTITY_TYPE } from '../../shared/pipeline';
import { PipelineEntityService } from '../../shared/pipeline-entity.service';
import { LogReader } from '../shared/logreader';
import { LogReadersApiService } from '../shared/logreaders-api.service';
import { SourceGeneralComponent } from './source-general.component';

describe('SourceGeneralComponent', () => {
  let component: SourceGeneralComponent;
  let fixture: ComponentFixture<SourceGeneralComponent>;
  let logReadersApiService: LogReadersApiService;
  let pipelineEntityService: PipelineEntityService;
  let catalogApiService: CatalogApiService;

  const mockedSourceConnection = {
    id: '1',
    connectionType: 'ORACLE',
    journalName: 'JDBC',
    name: 'OracleConnection'
  } as Connection;

  const mockedSourceConnection1 = {
    id: '1',
    connectionType: 'DB2',
    journalName: 'JDBC',
    name: 'DB2Connection'
  } as Connection;
  const mockLogReaders = [
    {
      type: 'logReader',
      dataConnectionId: '1',
      journalName: 'SCHEMA/JOURNAL',
      logReaderId: '1',
      name: 'LGNAME1'
    } as LogReader
  ];
  const mockPipeline = {
    projectId: 'abcd',
    dataFlowType: 'SYNCHRONIZE',
    source: {
      dataConnection: { id: 'abcd', connectionType: 'DB2I' }
    },
    properties: [{ key: 'IBMI_LOG_READER_NAME', value: 'LGNAME1' }]
  } as Pipeline;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      declarations: [SourceGeneralComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SourceGeneralComponent);
    component = fixture.componentInstance;
    logReadersApiService = TestBed.inject(LogReadersApiService);
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    catalogApiService = TestBed.inject(CatalogApiService);
    component.sourceDataConnection = mockedSourceConnection;
    fixture.detectChanges();
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue(mockPipeline);
  });

  const mockLogReaderConfigurationDb2Data = {
    id: 1,
    projectId: 2,
    metabaseId: 3,
    dataConnection: {
      id: 4,
      connectionType: 'DB2'
    }
  } as LogReader;

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the source data connection for replication pipeline', () => {
    const newSourceDataConnection = {
      id: '2',
      name: 'NewDB2iConnection',
      connectionType: 'DB2I',
      accessMethod: 'JDBC'
    } as Connection;
    component.sourceDataConnection = newSourceDataConnection;
    component.ngOnInit();
    expect(component.sourceDataConnection.name).toBe(newSourceDataConnection.name);
    expect(component.connectionTypeFriendlyName).toBe('connections.CONNECTION_TYPES.DB2I');
  });

  it('should set the source data connection for scheduled pipeline', () => {
    const newSourceDataConnection = {
      id: '5',
      name: 'AsanValid',
      connectionType: 'ASAN'
    } as Connection;
    component.sourceDataConnection = newSourceDataConnection;
    pipelineEntityService.pipelineEntityType = PIPELINE_ENTITY_TYPE.SCHEDULED;
    component.ngOnInit();
    expect(component.sourceDataConnection.name).toBe(newSourceDataConnection.name);
    expect(component.connectionTypeFriendlyName).toBe(newSourceDataConnection.connectionType);
  });

  it('should populate the log readers dropdown', () => {
    spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of(mockLogReaders));
    const newSourceDataConnection = {
      id: '2',
      name: 'NewDB2Connection',
      connectionType: 'DB2',
      accessMethod: 'JDBC'
    } as Connection;
    component.sourceDataConnection = newSourceDataConnection;
    component.ngOnInit();
    expect(component.logReadersList.length).toBeGreaterThan(0);
  });

  it('should open the sidebar when configuration button is clicked', () => {
    spyOn(component.configurationClickEvent, 'emit');
    component.configurationButtonClicked();
    expect(component.configurationClickEvent.emit).toHaveBeenCalled();
  });

  it('should emit event when selected log reader changes', () => {
    spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of(mockLogReaders));
    spyOn(component.selectedLogReaderChanged, 'emit').and.returnValue(null);
    const newSourceDataConnection = {
      id: '2',
      name: 'NewDB2iConnection',
      connectionType: 'DB2I',
      accessMethod: 'JDBC'
    } as Connection;
    component.sourceDataConnection = newSourceDataConnection;
    component.ngOnInit();
    component.onLogReaderChange({ value: 'logReader' });
    expect(component.selectedLogReaderChanged.emit).toHaveBeenCalled();
  });

  it('should select the log reader that was saved', () => {
    spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of(mockLogReaders));
    spyOn(component.selectedLogReaderChanged, 'emit').and.returnValue(null);
    const newSourceDataConnection = {
      id: '2',
      name: 'NewDB2iConnection',
      connectionType: 'DB2I',
      accessMethod: 'JDBC'
    } as Connection;
    component.sourceDataConnection = newSourceDataConnection;
    component.ngOnInit();
    expect(component.selectedLogReaderChanged.emit).toHaveBeenCalled();
    expect(component.selectedLogReader.name).toBe(mockLogReaders[0].name);
  });

  describe('isDb2I', () => {
    it('should return true for db2i connection type', () => {
      const mockSourceDataConnection = {
        id: '2',
        name: 'NewDB2iConnection',
        connectionType: 'DB2I',
        accessMethod: 'JDBC'
      } as Connection;
      component.sourceDataConnection = mockSourceDataConnection;
      expect(component.isDB2I()).toBeTruthy();
    });

    it('should be false for db2 connection type', () => {
      expect(component.isDB2I()).toBeFalsy();
    });
  });

  describe('isLogreaderConfigured', () => {
    it('check if logreaders are configured', () => {
      spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of(mockLogReaders));

      expect(component.isLogreaderConfigured()).toBe('Not Configured');
    });
    it('check if not configured', () => {
      spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of(mockLogReaders));
      const newSourceDataConnection = {
        id: '2',
        name: 'NewDB2Connection',
        connectionType: 'DB2',
        accessMethod: 'JDBC'
      } as Connection;
      component.sourceDataConnection = newSourceDataConnection;
      component.ngOnInit();
      expect(component.isLogreaderConfigured()).toBe('UDBCS1');
    });
  });

  describe('catalog status', () => {
    beforeEach(() => {
      jasmine.getEnv().allowRespy(true);
    });
    it('should fetch catalog status of source connection, if scalable commit ff is enabled', () => {
      spyOn(catalogApiService, 'status').and.returnValue(of({}));
      const changesObj: SimpleChanges = { sourceDataConnection: new SimpleChange(true, true, false) };
      component.ngOnChanges(changesObj);
      expect(catalogApiService.status).toHaveBeenCalled();
    });

    it('handles catalog button click', () => {
      component.isManageCatalogSidebarVisible = false;
      component.catalogButtonClicked();
      expect(component.isManageCatalogSidebarVisible).toBeTrue();
    });
  });
});
