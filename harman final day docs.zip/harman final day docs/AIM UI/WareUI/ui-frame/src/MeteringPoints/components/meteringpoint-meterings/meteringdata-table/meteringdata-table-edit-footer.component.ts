import { Component, EventEmitter, Input, OnChanges, Output, SimpleChanges } from "@angular/core";
import { Store } from "@ngrx/store";
import { State } from "../../../../app/store/reducers";
import { MatDialog } from "@angular/material/dialog";
import { dissapearAnimation } from "../../../../Shared/Animations/dissapear-animation";

import { ProfileDataActions } from "../../../store/actions";
// tslint:disable-next-line: max-line-length
import { MultiplyMeteringValuesComponent } from "../../../containers/meteringpoint-meterings/multiply-metering-values/multiply-metering-values.component";

@Component({
    selector: "landisgyr-metering-data-table-edit-footer",
    templateUrl: "./meteringdata-table-edit-footer.component.html",
    styleUrls: ["./meteringdata-table-edit-footer.component.scss"],
    animations: dissapearAnimation()
})
export class MeteringDataTableEditFooterComponent implements OnChanges {
    @Input() undoRedoDisabled!: { undoDisabled: boolean; redoDisabled: boolean };
    @Input() multiplyDisabled!: boolean;
    @Input() interpolationDisabled!: boolean;
    @Input() submitDisabled!: boolean;
    @Input() editSuccess!: boolean;
    @Input() editError!: string;
    @Output() closeEdit: EventEmitter<any> = new EventEmitter();
    undoText = $localize`:|@@commonTranslations.undo:Undo`;
    redoText = $localize`:|@@commonTranslations.redo:Redo`;
    basicOperationsText = $localize`:|@@meteringdataTable.basicOparations:Apply basic operations`;
    interpolateText = $localize`:|@@meteringdataTable.interpolate:Interpolate`;

    notification = false;

    constructor(private store: Store<State>, public dialog: MatDialog) {}

    ngOnChanges(changes: SimpleChanges): void {
        if (changes.editSuccess || changes.editError) {
            if (this.editSuccess) {
                this.notification = true;
                setTimeout(() => (this.notification = false), 5000);
            }
            if (this.editError) {
                this.notification = true;
            }
        }
    }

    closeEditMode() {
        this.closeEdit.emit(null);
    }

    undo() {
        this.store.dispatch(ProfileDataActions.UndoOrRedoEdit({ operationType: "undo" }));
    }

    redo() {
        this.store.dispatch(ProfileDataActions.UndoOrRedoEdit({ operationType: "redo" }));
    }

    onClickMultiplyButton() {
        this.store.dispatch(ProfileDataActions.InitializeMultiplyDialog());
        this.dialog.open(MultiplyMeteringValuesComponent, {
            width: "1024px",
            maxWidth: "1024px",
            height: "640px",
            maxHeight: "640px",
            disableClose: true
        });
    }

    submit() {
        this.store.dispatch(ProfileDataActions.SubmitEdit());
    }

    clearNotification(event: any) {
        if (event.fromState !== "void") {
            setTimeout(() => this.store.dispatch(ProfileDataActions.ClearSubmitNotification()), 5000);
        }
    }
}
