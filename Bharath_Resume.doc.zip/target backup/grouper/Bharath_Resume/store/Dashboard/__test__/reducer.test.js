import reducer, { initialState } from '../reducer'
import { fromJS } from 'immutable'
import {
  GET_GROUPER_LIST,
  GET_GROUPER_LIST_SUCCESS,
  GET_GROUP_TYPES,
  GET_GROUP_TYPES_SUCCESS,
  GET_ITEM_TYPES,
  GET_ITEM_TYPES_SUCCESS,
  GET_ITEM_THEMES,
  GET_ITEM_THEMES_SUCCESS,
  CLEAR_ITEM_THEMES,
  ADD_GROUP,
  ADD_GROUP_SUCCESS,
  CLEAR_GROUP_ACTION_TYPE,
  SET_ERROR_TCINS,
} from '../actionType'

describe('Dashboard reducer', () => {
  it('returns the initial state', () => {
    expect(
      reducer(undefined, {})
    ).toEqual(initialState)
  })

  it('should handle GET_GROUPER_LIST', () => {
    const action = {
      type: GET_GROUPER_LIST,
    }
    expect(reducer(initialState, action)).toEqual({
      ...initialState,
    })
  })

  it('should handle GET_GROUPER_LIST_SUCCESS', () => {
    const grouperList = [{'group_id': 5, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534306000, 'department': {'department_id': 244, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962800000, 'status': 'InActive'}]
    const initial = initialState.toJS()
    initial['grouperList'] = grouperList
    expect(reducer(fromJS(initialState), {
      type: GET_GROUPER_LIST_SUCCESS,
      data: grouperList,
    })).toEqual(fromJS(initial))
  })

  it('should handle GET_GROUP_TYPES', () => {
    const action = {
      type: GET_GROUP_TYPES,
    }
    expect(reducer(initialState, action)).toEqual({
      ...initialState,
    })
  })

  it('should handle GET_GROUP_TYPES_SUCCESS', () => {
    const groupTypes = [{'id': 1, 'name': 'variation', 'status': true}, {'id': 2, 'name': 'collection', 'status': false}]
    const initial = initialState.toJS()
    initial['groupTypes'] = groupTypes
    expect(reducer(fromJS(initialState), {
      type: GET_GROUP_TYPES_SUCCESS,
      payload: groupTypes,
    })).toEqual(fromJS(initial))
  })

  it('should handle GET_ITEM_TYPES', () => {
    const action = {
      type: GET_ITEM_TYPES,
    }
    expect(reducer(initialState, action)).toEqual({
      ...initialState,
    })
  })

  it('should handle GET_ITEM_TYPES_SUCCESS', () => {
    const itemTypes = [{'item_type_id': 380505, 'item_type_name': 'Neckties', 'item_type_short_name': 'Neckties', 'item_type_status_code': 'ACTV', 'merchandise_type_id': 118302, 'merchandise_type_name': 'Ties'}]

    const initial = initialState.toJS()
    initial['itemTypes'] = itemTypes
    expect(reducer(fromJS(initialState), {
      type: GET_ITEM_TYPES_SUCCESS,
      payload: itemTypes,
    })).toEqual(fromJS(initial))
  })

  it('should handle GET_ITEM_THEMES', () => {
    const action = {
      type: GET_ITEM_THEMES,
    }
    expect(reducer(initialState, action)).toEqual({
      ...initialState,
    })
  })

  it('should handle GET_ITEM_THEMES_SUCCESS', () => {
    const itemThemes = fromJS([{'id': 93, 'attribute_type': 'mta', 'name': 'Product Length', 'path': 'dummy', 'is_active': true, 'mta_attribute_id': 102627}, {'id': 97, 'attribute_type': 'mta', 'name': 'Product Color', 'path': 'dummy', 'is_active': true, 'mta_attribute_id': 107707}])
    const initial = initialState.toJS()
    initial['itemThemes'] = itemThemes
    expect(reducer(fromJS(initialState), {
      type: GET_ITEM_THEMES_SUCCESS,
      payload: itemThemes,
    })).toEqual(fromJS(initial))
  })

  it('should handle CLEAR_ITEM_THEMES', () => {
    const action = {
      type: CLEAR_ITEM_THEMES,
    }
    expect(reducer(initialState, action)).toEqual({
      ...initialState,
    })
  })

  it('should handle ADD_GROUP', () => {
    const action = {
      type: ADD_GROUP,
    }
    expect(reducer(initialState, action)).toEqual({
      ...initialState,
    })
  })

  it('should handle ADD_GROUP_SUCCESS', () => {
    const initial = initialState.toJS()
    initial['requestType'] = 'ADD'
    expect(reducer(fromJS(initialState), {
      type: ADD_GROUP_SUCCESS,
    })).toEqual(fromJS(initial))
  })

  it('should handle CLEAR_GROUP_ACTION_TYPE', () => {
    const action = {
      type: CLEAR_GROUP_ACTION_TYPE,
    }
    expect(reducer(initialState, action)).toEqual({
      ...initialState,
    })
  })

  it('should handle SET_ERROR_TCINS', () => {
    const errorTcins = [111, 222]
    const initial = initialState.toJS()
    initial['errorTcins'] = errorTcins
    expect(reducer(fromJS(initialState), {
      type: SET_ERROR_TCINS,
      errorTcins: errorTcins,
    })).toEqual(fromJS(initial))
  })
})
