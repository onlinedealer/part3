import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  ComponentFactoryResolver,
  ComponentRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';

import { Subscription } from 'rxjs';
import { Connection } from '../../../connections/shared/connection';
import { ConnectionsApiService } from '../../../connections/shared/connections-api.service';
import { DynamicHostDirective } from '../../../shared/directives/dynamic-host.directive';
import { Metabase } from '../../shared/metabase.model';
import { DB2IMetabaseFormComponent } from './db2i-metabase-form/db2i-metabase-form.component';
import { OracleMetabaseFormComponent } from './oracle-metabase-form/oracle-metabase-form.component';
import { DB2MetabaseFormComponent } from './db2-metabase-form/db2-metabase-form.component';
import { SqlServerMetabaseFormComponent } from './sqlserver-metabase-form/sqlserver-metabase-form.component';
/**
 * Component that is used to create a new metabase
 */
@Component({
  selector: 'p-connect-metabase-form',
  templateUrl: './metabase-form.component.html'
})
export class MetabaseFormComponent implements OnInit, AfterViewInit, OnDestroy {
  /**
   * Auto selects a data connection from the data connection list
   */
  @Input() selectedDataConnection: Connection;

  /**
   * The project where this metabase will be created
   */
  @Input() projectId: string;

  /**
   * Event that can be used to handle component error messages
   */
  @Output() setErrorMessageEvent = new EventEmitter<any>();

  /**
   * event that handles in progress component events, for example when a API request is being made
   */
  @Output() setInProgressEvent = new EventEmitter<boolean>();

  metabaseFormGroup: FormGroup;
  dataConnections = [];
  subscriptions: Subscription[] = [];

  @ViewChild(DynamicHostDirective, { static: true })
  dynamicHostDirective: DynamicHostDirective;

  childComponentReference: ComponentRef<any>;

  // list of the data connections and access methods that are supported by this component
  supportedDataConnectionTypes = [
    { connectionType: 'ORACLE', accessMethod: 'JDBC' },
    { connectionType: 'DB2I', accessMethod: 'JDBC' },
    { connectionType: 'DB2', accessMethod: 'JDBC' },
    { connectionType: 'SQLSERVER', accessMethod: 'JDBC' }
  ];

  // list of components by connection type
  metabaseChildFormComponentList: { connectionType: string; component: any }[] = [
    { connectionType: 'ORACLE', component: OracleMetabaseFormComponent },
    { connectionType: 'DB2I', component: DB2IMetabaseFormComponent },
    { connectionType: 'DB2', component: DB2MetabaseFormComponent },
    { connectionType: 'SQLSERVER', component: SqlServerMetabaseFormComponent }
  ];

  selectedConnection: { label: string; value: Connection };
  initialFormGroupValues: any;

  constructor(
    private readonly componentFactoryResolver: ComponentFactoryResolver,
    private readonly formBuilder: FormBuilder,
    private readonly connectionService: ConnectionsApiService,
    private readonly cdr: ChangeDetectorRef
  ) {}

  ngOnDestroy(): void {
    this.subscriptions.forEach((s) => s.unsubscribe());
  }

  ngOnInit(): void {
    this.createFormGroup();
    this.setDataConnectionList();
  }

  ngAfterViewInit(): void {
    // Trigger change detection in order to avoid ExpressionChangedAfterItHasBeenCheckedError
    this.cdr.detectChanges();
  }

  get metabase(): Metabase {
    return this.childComponentReference.instance.metabase;
  }

  private setDataConnectionList(): void {
    this.subscriptions.push(
      this.connectionService.getAll().subscribe({
        next: (connections) => {
          connections = connections
            .filter((connection) => {
              if (
                this.supportedDataConnectionTypes.some((supportedDataConnectionType) => {
                  return (
                    supportedDataConnectionType.connectionType === connection.connectionType &&
                    (supportedDataConnectionType.accessMethod === connection.accessMethod || !connection.accessMethod)
                  );
                })
              ) {
                return connection;
              }
            })
            .sort((a, b) => a.name.localeCompare(b.name));

          this.dataConnections = connections.map((connection) => ({
            label: connection.name,
            value: connection
          }));

          // if we don't have a selected data connection then just pre select the first item
          if (!this.selectedDataConnection && this.dataConnections.length > 0) {
            this.metabaseFormGroup.get('dataConnection').setValue(this.dataConnections[0].value);
          } else {
            const selectedConnection = this.dataConnections.find((connection) => {
              return connection.value.id === this.selectedDataConnection.id;
            });
            this.metabaseFormGroup.get('dataConnection').setValue(selectedConnection?.value);
            this.metabaseFormGroup.get('dataConnection').disable();
          }

          this.initialFormGroupValues = this.metabaseFormGroup.value;
        }
      })
    );
  }

  private createFormGroup(): void {
    this.metabaseFormGroup = this.formBuilder.group({
      id: null,
      dataConnection: new FormControl({
        value: ''
      })
    });

    this.subscriptions.push(
      this.metabaseFormGroup.get('dataConnection').valueChanges.subscribe({
        next: () => {
          if (this.metabaseFormGroup.get('dataConnection').value) {
            this.selectedConnection = this.dataConnections.find((connection) => {
              return connection.value.id === this.metabaseFormGroup.get('dataConnection').value.id;
            });
            this.loadConnectionSpecificChildComponent(this.selectedConnection.value);
          }
        }
      })
    );
  }

  private loadConnectionSpecificChildComponent(connection: Connection): void {
    const viewContainerRef = this.dynamicHostDirective.viewContainerRef;
    viewContainerRef.clear();

    const metabaseChildFormComponent = this.metabaseChildFormComponentList.find((obj) => obj.connectionType === connection.connectionType);
    const componentFactory = this.componentFactoryResolver.resolveComponentFactory(metabaseChildFormComponent.component);

    this.childComponentReference = viewContainerRef.createComponent<typeof metabaseChildFormComponent.component>(componentFactory);
    this.childComponentReference.instance.dataConnection = connection;
  }
}
