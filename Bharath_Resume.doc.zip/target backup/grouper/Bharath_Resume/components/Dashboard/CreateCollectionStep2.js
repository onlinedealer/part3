import React from 'react'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import CreateCollectionLoadMTAs from './CreateCollectionLoadMTAs'

const styles = theme => ({
  container: {
    padding: 10,
  },
  formControl: {
    marginTop: 10,
    width: '100%',
  },
  field: {
    marginTop: 10,
  },
  fieldWidth: {
    width: '100%',
  },
})

export class CreateCollectionStep1 extends React.Component {
    handleSelectChange = (selectedMTAs) => {
      this.props.onMTAs(selectedMTAs)
    }

    render () {
      const { classes, collectionMTAs, RequiredMTAs } = this.props
      return (
        <div>
          <Grid container>
            {collectionMTAs.required_collection_mta_info.length > 0 &&
              <div className={classes.fieldWidth}>
                <Grid item xs={12} className={classes.field}>
                  Required MTAs
                </Grid>
                <CreateCollectionLoadMTAs
                  mtaList={collectionMTAs.required_collection_mta_info}
                  handleSelectChange={this.handleSelectChange}
                  step2FormData={this.props.step2FormData}
                  RequiredMTAs={RequiredMTAs}
                />
              </div>
            }
            {collectionMTAs.optional_collection_mta_info.length > 0 &&
              <div className={classes.fieldWidth}>
                <Grid item xs={12} className={classes.field}>
                  Optional MTAs
                </Grid>
                <CreateCollectionLoadMTAs
                  mtaList={collectionMTAs.optional_collection_mta_info}
                  handleSelectChange={this.handleSelectChange}
                  step2FormData={this.props.step2FormData}
                  RequiredMTAs={RequiredMTAs}
                />
              </div>
            }
          </Grid>
        </div>
      )
    }
}

CreateCollectionStep1.propTypes = {
  classes: PropTypes.object.isRequired,
}

export default withStyles(styles)(CreateCollectionStep1)
