import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { SidebarButton } from 'src/app/shared/components/sidebar/sidebar-button';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { MAPPING_CONST } from '../../shared/mapping_constants';

@Component({
  selector: 'p-connect-change-table-mapping',
  templateUrl: './change-table-mapping.component.html',
  styleUrls: ['./change-table-mapping.component.scss']
})
export class ChangeTableMappingComponent implements OnInit {
  @Output() cancelClicked = new EventEmitter();
  @Output() applyClicked = new EventEmitter();
  @Input() checkedItems: any[];
  @Input() topics: string[];
  @Input() tableData: string[];
  @Input() setTargetDetails: (row, topic) => void;
  @Input() patchPipeline: () => void;
  @Input() setMappingIcon: (row, topic, topicFound) => void;
  @Input() fields: string[];
  @Input() getSubjectDetails: (row) => void;
  @Input() setTopicSubject: (row, subject) => void;

  selectedRows: number;
  caseDropdownItems$: Observable<{ label: string; value: string }[]>;
  patternDropdown = true;
  filteredTopics: any[];
  filteredPatterns: any[];
  selectedTopic = '';
  selectedPattern: any[] = [];
  selectedCase = 'MATCH_SOURCE';
  patternTextInputError: boolean = false;
  primaryObject: SidebarButton = {};

  @ViewChild('clearTypedPattern', { read: ElementRef }) clearTypedPattern: ElementRef;

  constructor(private readonly translocoService: TranslocoService, private readonly mappingService: PipelineMappingService) {}

  lang = 'pipelines';
  caseTranslationPrefix = 'STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.CASE_DROPDOWN.PLACEHOLDERS';

  applyButton: SidebarButton = {
    id: 'applyMappingClearButton',
    text: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.APPLY_BUTTON'
  };
  cancelButton: SidebarButton = {
    id: 'clearMappingCancelButton',
    text: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.CANCEL_BUTTON'
  };

  topicDropdownItems = [
    {
      id: 1,
      name: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.TOPIC_DROPDOWN.OPTIONS.OPTION_1',
      code: 'USE_A_PATTERN'
    },
    {
      id: 2,
      name: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.TOPIC_DROPDOWN.OPTIONS.OPTION_2',
      code: 'SELECT_ENTER_TOPIC'
    }
  ];

  patternDropdownItems = [
    {
      code: 'schema',
      name: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.CASE_DROPDOWN.OPTIONS.OPTION_1'
    },
    {
      code: 'table',
      name: 'pipelines.STAGES.MAPPING.CHANGE_MAPPING_SIDEBAR.CASE_DROPDOWN.OPTIONS.OPTION_2'
    }
  ];

  ngOnInit(): void {
    this.initiateCaseDropdownOptions();
  }

  onCancel() {
    this.cancelClicked.emit('close');
    this.clearPatternTextBox();
  }

  onApply() {
    // SPECIFY OR USE EXISTING TOPIC
    if (this.selectedPattern.length) {
      this.applyPatternChanges();
    }
    // CREATE A PATTERN
    else {
      this.applyTopicChanges();
    }

    // resetting all variables
    this.selectedTopic = '';
    this.selectedPattern = [];
    this.patternTextInputError = false;
    this.checkIfApplyDisabled();
    this.selectedCase = 'MATCH_SOURCE';
    this.cancelClicked.emit('close');
  }

  applyTopicChanges() {
    this.checkedItems?.forEach((row) => {
      row.topic.class = null;
      const casedTopicName = this.convertTopicAsCaseSpecified(this.selectedCase, this.selectedTopic.trim());
      this.setTargetDetails(row, casedTopicName);
      row.isButtonEnabled = true;
    });
    this.patchPipeline();
  }

  applyPatternChanges() {
    const topicPattern = [];
    this.selectedPattern.forEach((x) => {
      topicPattern.push(x.code);
    });
    const indexOfAll = (arr, val) => arr.reduce((acc, el, i) => (el === val ? [...acc, i] : acc), []);
    const schemasIndex = indexOfAll(topicPattern, 'schema');
    const tableIndex = indexOfAll(topicPattern, 'table');
    const schema = topicPattern.findIndex((ele) => ele === 'schema');
    const table = topicPattern.findIndex((ele) => ele === 'table');
    const restPart = topicPattern.findIndex((ele) => ele !== schema && ele !== table);
    this.checkedItems?.forEach((row) => {
      row.topic.class = null;
      schemasIndex.forEach((e) => {
        topicPattern[e] = row.schema || row.library;
      });
      tableIndex.forEach((e) => {
        topicPattern[e] = row.table.trim();
      });
      topicPattern[restPart] = topicPattern.find((ele) => ele !== schema && ele !== table);
      const topicName = topicPattern.join('');
      const casedTopicName = this.convertTopicAsCaseSpecified(this.selectedCase, topicName);
      this.setTargetDetails(row, casedTopicName);
      row.isButtonEnabled = true;
    });
    this.clearPatternTextBox();
    this.patchPipeline();
  }

  clearPatternTextBox() {
    // checking native element ref with querySelector and its value to make it empty
    if (
      this.clearTypedPattern.nativeElement.querySelectorAll('.p-autocomplete-input-token > input')[0] &&
      this.clearTypedPattern.nativeElement.querySelectorAll('.p-autocomplete-input-token > input')[0].value
    ) {
      this.clearTypedPattern.nativeElement.querySelectorAll('.p-autocomplete-input-token > input')[0].value = '';
    }
  }
  onChangeTopicDropdown(event) {
    if (event.value === 'USE_A_PATTERN') {
      this.patternDropdown = true;
      this.selectedTopic = '';
    } else if (event.value === 'SELECT_ENTER_TOPIC') {
      this.patternDropdown = false;
      this.selectedPattern = [];
    }
  }

  filterTopic(event: { query: any }) {
    const query = event.query.trim();
    this.filteredTopics = this.topics.filter((c: string) => c.toLowerCase().includes(query.toLowerCase()));
  }

  filterPattern(event: { code?: string; name?: string; query?: any }) {
    const query = event.query.trim();
    this.filteredPatterns = this.patternDropdownItems.filter((c) => c.code.toLowerCase().startsWith(query.toLowerCase()));
  }

  onSelectTopic(event) {
    this.selectedTopic = event;
    this.checkIfApplyDisabled();
  }

  keyChangeTopic(event) {
    this.selectedTopic = event.target.value.trim();
    this.checkIfApplyDisabled();
  }

  handleFocus(event) {
    if (event.target.value.match(MAPPING_CONST.REGEX_TARGET_NAME)) {
      this.patternTextInputError = true;
    } else {
      this.patternTextInputError = false;
      this.handleInput(event);
    }
  }

  handleInput(evt) {
    if (!this.selectedPattern) {
      this.selectedPattern = [
        {
          code: evt.target.value.trim(),
          name: evt.target.value.trim()
        }
      ];
      evt.target.value = '';
      this.checkIfApplyDisabled();
      return;
    }
    if (evt.target.value.trim() !== '') {
      this.selectedPattern.push({
        code: evt.target.value.trim(),
        name: evt.target.value.trim()
      });
      evt.target.value = '';
      this.checkIfApplyDisabled();
    }
  }

  keyChangePattern(evt) {
    if (evt.target.value.match(MAPPING_CONST.REGEX_TARGET_NAME)) {
      this.patternTextInputError = true;
    } else {
      this.patternTextInputError = false;
      if (evt.which === 13) {
        this.handleInput(evt);
      }
    }
  }

  convertTopicAsCaseSpecified(caseSelected, topicName) {
    const match = /[-_.]/.exec(topicName);
    switch (caseSelected) {
      case 'MATCH_SOURCE':
        return topicName;

      case 'SENTENCE_CASE':
        return topicName.replace(/\w\S*/g, (txt) => {
          return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
        });
      case 'LOWER_CASE':
        return topicName.toLowerCase();

      case 'UPPER_CASE':
        return topicName.toUpperCase();

      case 'CAP_EACH_WORD':
        return topicName
          .toLowerCase()
          .split(topicName[match?.index])
          .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
          .join(topicName[match?.index]);

      case 'TOGGLE_CASE':
        return topicName
          .toUpperCase()
          .split(topicName[match?.index])
          .map((word) => {
            return word.charAt(0).toLowerCase() + word.slice(1);
          })
          .join(topicName[match?.index]);
    }
  }

  private initiateCaseDropdownOptions = () => {
    this.caseDropdownItems$ = this.translocoService
      .selectTranslateObject(`${this.caseTranslationPrefix}`, null, this.lang)
      .pipe(map((dropdownOptions) => this.transformToDropdownOptions(dropdownOptions)));
  };
  private transformToDropdownOptions(translationObject, filteredKey?): { label: string; value: string }[] {
    return Object.keys(translationObject)
      .filter((option) => option !== filteredKey)
      .map((key) => ({
        label: translationObject[key],
        value: key
      }));
  }

  getPrimaryObject(applyButtonInfo) {
    this.primaryObject = applyButtonInfo;
  }

  checkIfApplyDisabled() {
    if (this.selectedTopic.trim() || this.selectedPattern.length) {
      this.primaryObject.isDisabled = false;
    } else {
      this.primaryObject.isDisabled = true;
    }
  }
}
