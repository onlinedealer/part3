#!/bin/bash

set -eu

if [[ $# -ne 1 ]]; then
    echo >&2 "[ERROR] Expected 1 argument (env: dev, qa, stg, prd) but received $#."
    exit 1
fi

env=$1

case "$env" in
    dev|qa|stg|prd)
        echo "[INFO] Environment: $env"
        ;;
    *)
        echo >&2 "[ERROR] Invalid environment specified: $env"
        exit 1
        ;;
esac

browser_list=(chrome edge firefox)
final_status=0

run_pipeline_history_report()
{
    env=$1
    browser=$2

    report_path="$CI_PROJECT_DIR/cypress/reports/FinalReport-${browser}.xml"
    report_type="UI"

    java -jar pipeline_history_report.jar ${env} ${browser} ${report_path} ${report_type}
}

for browser in ${browser_list[@]}; do
    echo "Running against ${browser}..."
    if ! run_pipeline_history_report ${env} ${browser}; then
        status=$?
        final_status=$((final_status+status))
        echo "Running against ${browser}... FAILED (code: ${status})"
    else
        echo "Running against ${browser}... SUCCESS"
    fi
done

[[ ${final_status} -eq 0 ]] || exit 1
