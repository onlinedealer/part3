import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { EncryptionService } from '@shared/services/encryption.service';
import { first } from 'rxjs/operators';
import { Connection } from 'src/app/connections/shared/connection';
import { AddDatabaseFormComponent } from './add-database-form/add-database-form.component';
import { AddDatabaseApiService } from './shared/addDatabase-api.service';
import { Clipboard } from '@angular/cdk/clipboard';
import { HttpErrorResponse } from '@angular/common/http';
import { TranslocoService } from '@ngneat/transloco';

@Component({
  selector: 'p-connect-adduser-database',
  templateUrl: './adduser-database.component.html',
  styleUrls: ['./adduser-database.component.scss']
})
export class AdduserDatabaseComponent {
  addDatabaseForm: FormGroup;
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  @Input() selectedDatabase: any[];

  /**
   * Source data connection
   */
  @Input() sourceDataConnection: Connection;

  /**
   * Reference to the addDatabaseComponent child component
   */
  @ViewChild(AddDatabaseFormComponent) addDatabaseFormComponent: AddDatabaseFormComponent;

  /**
   * Set to true to display the sidebar component
   */
  @Input() isVisible: boolean;

  /**
   * Event when the cancel button is clicked
   */
  @Output() cancelButtonClicked = new EventEmitter<boolean>();

  /**
   * String which is actually displayed to the error window
   */
  errorMessage: string = '';

  /**
   * String used for formatting
   */
  errorString: string = '';

  constructor(
    private readonly encryptionApiService: EncryptionService,
    private readonly addDatabaseApiService: AddDatabaseApiService,
    public clipboard: Clipboard,
    public readonly translocoService: TranslocoService
  ) {}

  primaryButton: SidebarButton = {
    id: 'addDatabaseButton',
    text: 'connections.ADD_USERDATABASE.BUTTONS.ADD'
  };

  secondaryButton: SidebarButton = {
    id: 'addDatabaseCancel',
    text: 'common.BUTTONS.CANCEL'
  };

  cancelButton: SidebarButton = {
    isHidden: true
  };

  open(): void {
    this.sidebarComponent.open();
  }

  /* Add Databse Button Clicked */
  async addDatabaseButtonClicked() {
    this.sidebarComponent.isProcessingRequest = true;
    const addDatabaseDetails = this.addDatabaseFormComponent.getDatabaseObject();
    let encryptedPassword: any = await this.encryptionApiService.encrypt(
      this.sourceDataConnection.accessFromServer.name,
      addDatabaseDetails.adminUserPassword
    );
    addDatabaseDetails.adminUserPassword = encryptedPassword;
    this.addDatabaseApiService
      .add(addDatabaseDetails)
      .pipe(first())
      .subscribe({
        next: () => {
          const success = {
            message: 'connections.ADD_USERDATABASE.MESSAGES.SUCCESS_MESSAGE'
          };
          this.sidebarComponent.parseHttpClientResponseMessage('success', success);
          this.cancelButton.isHidden = true;
          this.sidebarComponent.close();
        },
        error: (errorResponse: HttpErrorResponse) => {
          this.addDatabaseFormComponent.displayErrorMessage = true;
          this.errorMessage = this.parseErrorMsg(errorResponse.error.detailedMessage);
          this.primaryButton.isHidden = true;
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  /**
   *
   * @param errorResponse
   * @returns Failure cases for prepare user db along with err msg in enhanced way
   */
  parseErrorMsg(errorResponse: string): string {
    let jsonObj = JSON.parse(errorResponse);
    let map = new Map<string, string>();
    for (let value in jsonObj) {
      map.set(value, jsonObj[value]);
    }
    for (let entry of map.entries()) {
      this.errorString = this.errorString.concat(
        `\n` +
          this.translocoService.translate('connections.ADD_USERDATABASE.MESSAGES.PARSE_ERROR_STRING_1') +
          `${entry[0]}, \n\n` +
          this.translocoService.translate('connections.ADD_USERDATABASE.MESSAGES.PARSE_ERROR_STRING_2') +
          `${entry[1]} \n` +
          this.translocoService.translate('connections.ADD_USERDATABASE.MESSAGES.PARSE_ERROR_STRING_3')
      );
    }

    this.errorString = this.errorString.concat(
      `\n` +
        this.translocoService.translate('connections.ADD_USERDATABASE.MESSAGES.ACTION_REQUIRED') +
        ` ${map.size} ` +
        this.translocoService.translate('connections.ADD_USERDATABASE.MESSAGES.ACTION_REQUIRED_MESSAGE')
    );
    return this.errorString;
  }

  /**
   * Click event for the cancel button
   */
  onCancelButtonClicked(): void {
    this.isVisible = false;
    this.cancelButtonClicked.emit(true);
    this.sidebarComponent.close();
  }

  /**
   * Close sidebar without cancel logic
   */
  onCloseButtonClicked(): void {
    this.sidebarComponent.close();
  }

  copyClipboard(): void {
    this.errorMessage ? this.clipboard.copy(this.errorMessage) : this.clipboard.copy('');
  }
}
