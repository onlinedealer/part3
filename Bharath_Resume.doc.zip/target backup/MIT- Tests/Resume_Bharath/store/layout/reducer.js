import { fromJS } from 'immutable'
import {
  CLOSE_SIDE_NAV,
  OPEN_SIDE_NAV,
  SHOW_AUTH_POPUP,
  SET_HEADER_TITLE,
} from './actionType'

export const initialState = fromJS({
  sideNavIsOpen: true,
  openPopup: 0,
  popupType: '',
  headerTitle: '',
})

export default function layoutReducer (state = initialState, action = {}) {
  switch (action.type) {
    case OPEN_SIDE_NAV: {
      return state
        .set('sideNavIsOpen', true)
    }
    case CLOSE_SIDE_NAV: {
      return state
        .set('sideNavIsOpen', false)
    }
    case SHOW_AUTH_POPUP: {
      return state
        .set('openPopup', state.get('openPopup') + 1)
        .set('popupType', action.payload)
    }
    case SET_HEADER_TITLE: {
      return state
        .set('headerTitle', action.payload)
    }
    default:
      return state
  }
}
