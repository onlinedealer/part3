export interface DropdownOptionsModel {
  options: any[];
  selectedOption: any;
  ignoredOption?: any;
  disabled?: boolean;
  filter?: {};
  customFilter?: { name: string; filter: (value, filter) => boolean };
}
