import { TestBed } from '@angular/core/testing';
import { compareObject } from './pipeline-compare';
import { PipeLineMetadata } from './pipeline';

describe('Compare pipeline objects', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({});
  });

  it('should compare pipeline objects', () => {
    const left = {
      type: 'cdcDataFlow',
      id: '61e949f39758073893ad728d',
      dataFlowType: 'SYNCHRONIZE',
      description: 'TestPipeLine11',
      filters: [],
      name: 'TestPipeLine',
      owner: 'neo',
      projectId: '61c47ae26b99145a5083e59c',
      properties: [
        { key: 'REPLICATION_TRANSACTION_ERROR_MODE', value: 'IGNORE_DELETE_CONTINUE' },
        { key: 'COPY_SOURCE_LOCKING', value: 'INDIVIDUAL_TABLE' },
        { key: 'COPY_ERROR_MODE', value: 'TERMINATE_RUN' },
        { key: 'COPY_SOURCE_ISOLATION_LEVEL', value: 'READ_COMMITTED' },
        { key: 'COPY_SOURCE_TABLE_RETRIEVE_ORDER', value: 'ANY_ORDER' }
      ],
      source: {
        dataConnection: {
          id: '61c47b086b99145a5083e59e',
          accessFromServer: {
            id: '61c47ad46b99145a5083e59b',
            agentId: 'f7c01e9d-5b91-44e1-8fea-7e9c7c1adcd8',
            altIpAddress: '',
            dataPort: '',
            description: '',
            hostname: 'host.docker.internal',
            name: 'PK-Agent',
            port: 51701,
            pvtKey: '',
            serverType: 'REPLICATION',
            useSslTls: false
          },
          accessMethod: 'JDBC',
          connectionType: 'ORACLE',
          database: '10.2.66.225',
          dateCreated: '2021-12-23T13:35:04.983Z',
          description: '',
          name: 'SD1',
          namenode: '',
          owner: 'neo',
          parameters: [
            { key: 'ORACLE_JDBC_ROOT_CONTAINER_USER_ID' },
            { key: 'ORACLE_JDBC_DRIVER_VERSION', value: 'ORACLE12' },
            { key: 'ORACLE_JDBC_SUPPORT_PLUGGABLE', value: 'false' },
            { key: 'ORACLE_JDBC_INSTANCE_NAME', value: 'orcl' },
            { key: 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD' },
            { key: 'JDBC_ENCRYPTION', value: 'false' }
          ],
          password: '',
          passwordEncrypted: false,
          passwordRepository: false,
          port: 1521,
          username: ''
        },
        selectedTables: [
          {
            key: 'HR',
            value: {
              tableAndKeys: [
                { keys: [], tableName: 'EMPLOYEES' },
                { keys: [], tableName: 'DEPARTMENTS' },
                { keys: [], tableName: 'DEPARTMENTS' },
                { keys: [], tableName: 'JOBS' },
                { keys: [], tableName: 'EMPLOYEES' },
                { keys: [], tableName: 'JOBS' }
              ],
              tableExtractType: 'INCLUDE',
              tableNames: ['EMPLOYEES', 'JOBS', 'DEPARTMENTS']
            }
          }
        ],
        parameters: []
      },
      target: {
        cdcRowMetadatas: [
          { key: 'METADATA_USER_ID', value: 'INCLUDE' },
          { key: 'METADATA_ROW_JOB_NAME', value: 'EXCLUDE' },
          { key: 'METADATA_ROW_JOB_USER', value: 'EXCLUDE' },
          { key: 'METADATA_ROW_PROGRAM_NAME', value: 'EXCLUDE' },
          { key: 'METADATA_TRANSACTION_ROW_SEQ', value: 'INCLUDE' },
          { key: 'METADATA_TRANSACTION_TIMESTAMP', value: 'INCLUDE' },
          { key: 'METADATA_ROW_RECEIVER_NAME', value: 'EXCLUDE' },
          { key: 'METADATA_SEND_TABLE_NAME', value: 'INCLUDE' },
          { key: 'METADATA_TRANSACTION_ID', value: 'INCLUDE' },
          { key: 'METADATA_ROW_FILE_MEMBER', value: 'EXCLUDE' },
          { key: 'METADATA_ROW_RECEIVER_LIBRARY', value: 'EXCLUDE' },
          { key: 'METADATA_ROW_JOB_NUMBER', value: 'EXCLUDE' },
          { key: 'METADATA_ROW_TIMESTAMP', value: 'INCLUDE' },
          { key: 'METADATA_SEND_DBMS_TYPE', value: 'INCLUDE' },
          { key: 'METADATA_SEND_SERVER_NAME', value: 'INCLUDE' },
          { key: 'METADATA_ROW_MANIPULATION_TYPE', value: 'INCLUDE' },
          { key: 'METADATA_ROW_JOURNAL_SEQ_NO', value: 'EXCLUDE' },
          { key: 'METADATA_TRANSACTION_COMMIT_SEQ_NB', value: 'INCLUDE' }
        ],
        dataConnection: {
          id: '61c47b296b99145a5083e59f',
          accessFromServer: {
            id: '61c47ad46b99145a5083e59b',
            agentId: 'f7c01e9d-5b91-44e1-8fea-7e9c7c1adcd8',
            altIpAddress: '',
            dataPort: '',
            description: '',
            hostname: 'host.docker.internal',
            name: 'PK-Agent',
            port: 51701,
            pvtKey: '',
            serverType: 'REPLICATION',
            useSslTls: false
          },
          connectionType: 'KAFKA',
          database: 'host.docker.internal:29092',
          dateCreated: '2021-12-23T13:35:37.994Z',
          description: '',
          name: 'TF1',
          namenode: '',
          owner: 'neo',
          parameters: [
            { key: 'KAFKA_ENABLE_BATCH', value: 'true' },
            { key: 'KAFKA_KERBEROS_KEYTAB_LOCATION' },
            { key: 'KAFKA_BATCH_SIZE', value: '100' },
            { key: 'KAFKA_USE_KERBEROS', value: 'false' },
            { key: 'KAFKA_KERBEROS_PRINCIPAL' },
            { key: 'KAFKA_PRODUCER_CONFIG_FILE_PATH' }
          ],
          password: '',
          passwordEncrypted: false,
          passwordRepository: false,
          port: 0,
          username: ''
        },
        parameters: [
          { key: 'PARTITION_MESSAGES_BY', value: 'TABLE_NAME' },
          { key: 'MESSAGE_FORMAT_QUOTE_CHARACTER', value: '"' },
          { key: 'MAP_TABLES', value: 'ALL_TABLES_ONE_TOPIC' },
          { key: 'USE_EXISTING_TOPIC', value: 'true' },
          { key: 'INCLUDE_IMAGE_OPTION', value: 'AFTER_ONLY' },
          { key: 'MESSAGE_FORMAT_RECORD_DELIMITER', value: '\\n' },
          { key: 'TOPIC_NAME', value: 'Test' },
          { key: 'PREFIX_MESSAGES_WITH_TABLENAME', value: 'false' },
          { key: 'LOB_NO_CHANGES_MESSAGE', value: '1000' },
          { key: 'CLIENT_ID' },
          { key: 'MESSAGE_FORMAT', value: 'CSV' },
          { key: 'MESSAGE_FORMAT_FIELD_DELIMITER', value: ',' },
          { key: 'LOB_SEND_BEFORE', value: 'true' },
          { key: 'ACKNOWLEDGMENT', value: 'WAIT_SINGLE_BROKER' },
          { key: 'TRANSACTION_BUNDLING_LIMIT', value: '1000' },
          { key: 'LOB_MAX_SIZE', value: '50000' },
          { key: 'LOB_MAX_SIZE_FORMAT', value: 'bytes' },
          { key: 'MESSAGE_FORMAT_NULL_STRING', value: '~' },
          { key: 'ENABLE_TRANSACTION_BUNDLING', value: 'false' }
        ]
      }
    };
    const right = {
      type: 'cdcDataFlow',
      id: '61e949f39758073893ad728d',
      dataFlowType: 'SYNCHRONIZE',
      description: 'TestPipeLine111',
      filters: [],
      name: 'TestPipeLine',
      owner: 'neo',
      projectId: '61c47ae26b99145a5083e59c',
      properties: [
        { key: 'REPLICATION_TRANSACTION_ERROR_MODE', value: 'IGNORE_DELETE_CONTINUE' },
        { key: 'COPY_ERROR_MODE', value: 'TERMINATE_RUN' },
        { key: 'COPY_SOURCE_ISOLATION_LEVEL', value: 'READ_COMMITTED' },
        { key: 'COPY_SOURCE_LOCKING', value: 'INDIVIDUAL_TABLE' },
        { key: 'COPY_SOURCE_TABLE_RETRIEVE_ORDER', value: 'ANY_ORDER' }
      ],
      source: {
        dataConnection: {
          type: 'dataConnection',
          id: '61c47b086b99145a5083e59e',
          accessFromServer: {
            id: '61c47ad46b99145a5083e59b',
            agentId: 'f7c01e9d-5b91-44e1-8fea-7e9c7c1adcd8',
            altIpAddress: '',
            dataPort: '',
            description: '',
            hostname: 'host.docker.internal',
            name: 'PK-Agent',
            port: 51701,
            pvtKey: '',
            serverType: 'REPLICATION',
            useSslTls: false
          },
          accessMethod: 'JDBC',
          connectionType: 'ORACLE',
          database: '10.2.66.225',
          dateCreated: '2021-12-23T13:35:04.983Z',
          description: '',
          name: 'SD1',
          namenode: '',
          owner: 'neo',
          parameters: [
            { key: 'ORACLE_JDBC_ROOT_CONTAINER_USER_ID' },
            { key: 'ORACLE_JDBC_DRIVER_VERSION', value: 'ORACLE12' },
            { key: 'ORACLE_JDBC_SUPPORT_PLUGGABLE', value: 'false' },
            { key: 'ORACLE_JDBC_INSTANCE_NAME', value: 'orcl' },
            { key: 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD' },
            { key: 'JDBC_ENCRYPTION', value: 'false' }
          ],
          password: '',
          passwordEncrypted: false,
          passwordRepository: false,
          port: 1521,
          username: ''
        },
        selectedTables: [
          {
            key: 'HR',
            value: {
              tableAndKeys: [
                { keys: [], tableName: 'EMPLOYEES' },
                { keys: [], tableName: 'DEPARTMENTS' },
                { keys: [], tableName: 'DEPARTMENTS' },
                { keys: [], tableName: 'JOBS' },
                { keys: [], tableName: 'EMPLOYEES' },
                { keys: [], tableName: 'JOBS' }
              ],
              tableExtractType: 'INCLUDE',
              tableNames: ['EMPLOYEES', 'JOBS', 'DEPARTMENTS']
            }
          }
        ]
      },
      target: {
        dataConnection: {
          type: 'dataConnection',
          id: '61c47b296b99145a5083e59f',
          accessFromServer: {
            id: '61c47ad46b99145a5083e59b',
            agentId: 'f7c01e9d-5b91-44e1-8fea-7e9c7c1adcd8',
            altIpAddress: '',
            dataPort: '',
            description: '',
            hostname: 'host.docker.internal',
            name: 'PK-Agent',
            port: 51701,
            pvtKey: '',
            serverType: 'REPLICATION',
            useSslTls: false
          },
          connectionType: 'KAFKA',
          database: 'host.docker.internal:29092',
          dateCreated: '2021-12-23T13:35:37.994Z',
          description: '',
          name: 'TF1',
          namenode: '',
          owner: 'neo',
          parameters: [
            { key: 'KAFKA_ENABLE_BATCH', value: 'true' },
            { key: 'KAFKA_KERBEROS_KEYTAB_LOCATION' },
            { key: 'KAFKA_BATCH_SIZE', value: '100' },
            { key: 'KAFKA_USE_KERBEROS', value: 'false' },
            { key: 'KAFKA_KERBEROS_PRINCIPAL' },
            { key: 'KAFKA_PRODUCER_CONFIG_FILE_PATH' }
          ],
          password: '',
          passwordEncrypted: false,
          passwordRepository: false,
          port: 0,
          username: ''
        },
        cdcRowMetadatas: [
          { key: 'METADATA_USER_ID', value: 'INCLUDE' },
          { key: 'METADATA_TRANSACTION_ROW_SEQ', value: 'INCLUDE' },
          { key: 'METADATA_TRANSACTION_TIMESTAMP', value: 'INCLUDE' },
          { key: 'METADATA_SEND_TABLE_NAME', value: 'INCLUDE' },
          { key: 'METADATA_TRANSACTION_ID', value: 'INCLUDE' },
          { key: 'METADATA_ROW_TIMESTAMP', value: 'INCLUDE' },
          { key: 'METADATA_SEND_DBMS_TYPE', value: 'INCLUDE' },
          { key: 'METADATA_SEND_SERVER_NAME', value: 'INCLUDE' },
          { key: 'METADATA_ROW_MANIPULATION_TYPE', value: 'INCLUDE' },
          { key: 'METADATA_TRANSACTION_COMMIT_SEQ_NB', value: 'INCLUDE' }
        ],
        parameters: [
          { key: 'ACKNOWLEDGMENT', value: 'WAIT_SINGLE_BROKER' },
          { key: 'CLIENT_ID' },
          { key: 'MESSAGE_FORMAT', value: 'CSV' },
          { key: 'MESSAGE_FORMAT_QUOTE_CHARACTER', value: '"' },
          { key: 'MESSAGE_FORMAT_NULL_STRING', value: '~' },
          { key: 'MESSAGE_FORMAT_FIELD_DELIMITER', value: ',' },
          { key: 'MESSAGE_FORMAT_RECORD_DELIMITER', value: '\\n' },
          { key: 'INCLUDE_IMAGE_OPTION', value: 'AFTER_ONLY' },
          { key: 'MAP_TABLES', value: 'ALL_TABLES_ONE_TOPIC' },
          { key: 'USE_EXISTING_TOPIC', value: 'true' },
          { key: 'TOPIC_NAME', value: 'Test' },
          { key: 'PARTITION_MESSAGES_BY', value: 'TABLE_NAME' },
          { key: 'PREFIX_MESSAGES_WITH_TABLENAME', value: 'false' },
          { key: 'ENABLE_TRANSACTION_BUNDLING', value: 'false' },
          { key: 'TRANSACTION_BUNDLING_LIMIT', value: '1000' },
          { key: 'LOB_SEND_BEFORE', value: 'true' },
          { key: 'LOB_NO_CHANGES_MESSAGE', value: '1000' },
          { key: 'LOB_MAX_SIZE', value: '50000' },
          { key: 'LOB_MAX_SIZE_FORMAT', value: 'bytes' }
        ]
      }
    };

    const compareObj = compareObject(left, right, PipeLineMetadata);

    expect(compareObj.hasChanges).toBeTrue();
  });

  it('should compare test data', () => {
    const left = {
      id: 123456,
      name: 'test1',
      flag: false,
      leftonly: true,
      missmeta: true,
      obj: {
        key: '1234',
        value: 'Name',
        leftAttr: true
      },
      uObj: {
        a: ['1', '2'],
        b: [],
        d: []
      },
      arr: [
        {
          key: '1234',
          value: 'Name1'
        },
        {
          key: '12341',
          value: 'Name1'
        }
      ],
      carr: [
        {
          key: '1',
          value: 'a'
        },
        {
          key: '1',
          value: 'b'
        }
      ],
      sarr: ['a', 'b', 'c', 'd', 'c', 'c', 'c']
    };

    const right = {
      id: 123456,
      name: 'test',
      flag: true,
      rightonly: true,
      obj: {
        key: '1234',
        value: 'Name1'
      },
      uObj: {
        a: [],
        b: [],
        c: []
      },
      arr: [
        {
          key: '1234',
          value: 'Name'
        },
        {
          key: '12346',
          value: 'Name'
        }
      ],
      carr: [
        {
          key: '2',
          value: 'b'
        }
      ],
      sarr: ['a', 'b', 'c', 'c', 'e']
    };

    const metadata = {
      id: { type: 'number' },
      name: { type: 'string' },
      missboth: { type: 'boolean' },
      leftonly: { type: 'boolean' },
      rightonly: { type: 'boolean' },
      flag: { type: 'boolean', ignoreCompare: true },
      obj: {
        type: 'object',
        attributes: {
          key: { type: 'string' },
          value: { type: 'string' }
        }
      },
      uObj: {
        type: 'objectArray',
        item: 'object',
        key: 'tableName',
        metakey: 'tableName',
        metavalue: 'keys',
        attributes: {
          tableName: { type: 'string' },
          keys: {
            type: 'array',
            item: 'string'
          }
        }
      },
      arr: {
        type: 'array',
        item: 'object',
        key: 'key',
        ignoreMissing: {
          left: true,
          right: false
        },
        attributes: {
          key: { type: 'string' },
          value: { type: 'string' }
        }
      },
      carr: {
        type: 'array',
        item: 'object',
        combinedkey: 'key|value',
        ignoreMissing: {
          left: false,
          right: true
        },
        attributes: {
          key: { type: 'string' },
          value: { type: 'string' }
        }
      },
      sarr: {
        type: 'array',
        item: 'string'
      }
    };

    const compareObj = compareObject(left, right, metadata);
    expect(compareObj.hasChanges).toBeTrue();
  });
});
