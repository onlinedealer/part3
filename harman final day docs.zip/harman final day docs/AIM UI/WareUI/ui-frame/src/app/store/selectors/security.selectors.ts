import { createSelector } from "@ngrx/store";

import * as fromRoot from "../reducers";
import * as fromsecurity from "../reducers/security.reducer";
import { isNil, isObject, isString } from "lodash";

export interface UserInformationAttributes {
    email: string;
    fullName: string;
}

export interface UserInformation {
    attributes: UserInformationAttributes;
}

export const getUser = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    if (securityState) {
        return securityState.user;
    } else {
        return undefined;
    }
});

export const getUserTimeZone = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    if (securityState) {
        return securityState.user && securityState.user.timeZone ? securityState.user.timeZone : "";
    }
});

export const getUserInformation = createSelector(getUser, (user) => {
    if (!user) {
        return { attributes: {} } as UserInformation;
    }
    return {
        attributes: {
            email: user.email,
            fullName: user.fullName
        }
    } as UserInformation;
});

export const getUAMPermissions = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    if (securityState) {
        return securityState.permissions;
    } else {
        return [];
    }
});

export const getUAMPermissionsLoaded = createSelector(getUAMPermissions, (uamPermissions) => uamPermissions.length > 0);

export const getSession = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    if (securityState) {
        return securityState.session;
    } else {
        return undefined;
    }
});

export const getToken = createSelector(getSession, (session: any) => {
    if (session) {
        return session.token;
    } else {
        return "";
    }
});

export const getTokenAndUserLanguageCode = createSelector(getToken, getUser, (token, user) => {
    if (isNil(token) || isNil(user)) {
        return undefined;
    }
    return {
        token,
        languageCode: isObject(user) && isString(user.languageCode) ? user.languageCode : "en"
    };
});

export const isShowingTimeoutDialog = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    return securityState.showingTimeoutDialog;
});

export const getSecurityResponseFailuresCount = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    return securityState.securityResponseFailures;
});

export const isUserAndSessionLoaded = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    return isObject(securityState.user) && isObject(securityState.session);
});

export const isLoadingUserInfo = createSelector(
    fromRoot.getSecurityState,
    (securityState: fromsecurity.SecurityState) => securityState.loadingUserInfo
);

export const getSecurityFailed = createSelector(fromRoot.getSecurityState, (securityState: fromsecurity.SecurityState) => {
    if (securityState.getUserFailed && securityState.getUserFailed.errorCode) {
        return securityState.getUserFailed.errorCode.toString();
    } else if (securityState.getSessionFailed && securityState.getSessionFailed.errorCode) {
        return securityState.getSessionFailed.errorCode.toString();
    } else if (securityState.securityFailed) {
        return "SESSION_EXPIRED";
    } else {
        return "";
    }
});
