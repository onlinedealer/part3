(function() {
    'use strict';

    angular.module('arm').factory('dashboardService', ['serviceApi', '$filter', 'SERVICE_TYPE', 'sqliteService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', '$rootScope', dashboardService]);

    function dashboardService(serviceApi, $filter, SERVICE_TYPE, sqliteService, utility, MASTER_TABLE, GENERAL_CONFIG, $rootScope) {

        var serArr = {};
        var serviceArr = {};
        serArr.dashAdd = function() {
            //console.log("calling dashboardCTRL");

            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };
            var date = $filter('date')(new Date(), 'yyyy-MM-dd');
            //console.log(date);
            var dashboardGraphURL = SERVICE_TYPE.DASHBOARDGRAPH + '/' + $rootScope.loggedInUserID + '/' + "1" + "/" + "null" + "/" + date;
            //console.log("dashboardGraphURL" + dashboardGraphURL)
            return serviceApi.doGetWithoutData("dashboardAddService",
                dashboardGraphURL, headerconfig).then(function(response) {
                return response;
            }, function(err) {
                alert('web service error' + err);
            });
        }

        serArr.dashGraphFilterAdd = function(link) {
            var headerconfig = {
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded;charset=utf-8;'
                }
            };

            var dashboardGraphURL = SERVICE_TYPE.DASHBOARDGRAPH + link;
            console.log("dashboardGraphURL" + dashboardGraphURL)
            return serviceApi.doGetWithoutData("dashboardGraphFilterService",
                dashboardGraphURL, headerconfig).then(function(response) {
                return response;
            }, function(err) {
                alert('web service error' + err);
            });
        }
        return serArr;
    }

})();