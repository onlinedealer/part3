import { Component, Input, Output, EventEmitter, ContentChild, HostBinding } from "@angular/core";
import { InputRefDirective } from "../../../../Shared/directives/input-ref.directive";

@Component({
    selector: "landisgyr-input-with-icon",
    templateUrl: "./input-with-icon.component.html",
    styleUrls: ["./input-with-icon.component.scss"]
})
export class InputWithIconComponent {
    @Input() icon!: string;
    @Output() focusFilterInput: EventEmitter<boolean> = new EventEmitter();
    @Output() iconClick: EventEmitter<null> = new EventEmitter();
    @ContentChild(InputRefDirective)
    input!: InputRefDirective;
    constructor() {}

    @HostBinding("class.focus")
    get focus() {
        return this.input ? this.input.focus : false;
    }
    onIconClick() {
        this.iconClick.emit();
    }
}
