import {
  ADD_TCINS_SUCCESS,
  REMOVE_TCINS_SUCCESS,
  UPDATE_GROUP_NAME_SUCCESS,
  CLEAR_GROUP_DETAILS_REQUEST_TYPE,
  UPDATE_ITEMS_ORDER_SUCCESS,
  CLEAR_ADD_ITEM_TCIN_ERROR,
  GET_GROUP_DETAILS_SUCCESS,
  SET_DETAILS_ERROR_TCINS,
  CLEAR_GROUP_DETAILS,
  SET_ADDITEM_ERROR_TCINS,
  UPDATE_ITEMS_ORDER_ERROR,
  UPDATE_VARIATION_GROUP_NAME_DETAILS,
  SET_GROUP_DETAILS,
  ADD_ITEMS_TO_GROUP_DETAILS,
} from './actionType'
import { TOGGLE_SNACKBAR, LOADING_BTN_STATUS } from '../Snackbar/actionType'
import { UPDATE_VARIATION_GROUP_NAME_REQUEST, SET_ERROR_TCINS, SET_VARIATION_PAGE1_DATA } from '../Dashboard/actionType'
import config from '../../config/apiConfig'
import { getGrouperList, setVariationPage1Data } from '../Dashboard/actionCreator'

import {
  getService,
  putService,
  postService,
} from './../../services/grouper'

const sendGroupListPayload = {
  group_id: 0,
  pagination_filter: {
    page: 0,
    order: 'id',
    limit: 20,
    direction: 'ASC',
    is_count_needed: true,
  },
}

export function getGroupDetails (groupId, memberOf, userId, mode) {
  // return { payload: {group_id: groupId, memberOf, userId, mode}, type: GET_GROUP_DETAILS }
  return dispatch => {
    return getService(config.grouper.group + '/' + groupId, memberOf, userId)
      .then(resp => {
        dispatch({ type: GET_GROUP_DETAILS_SUCCESS, data: resp })

        if (resp.validation_error && mode === 'load') {
          let validationErr = ''
          let errorTcins = []
          resp.validation_error.map((option) => {
            errorTcins.push(option.tcin)
            validationErr += option.tcin + ' - ' + option.message + '<br />'
          })
          const errorData = { status: true, variant: 'error', message: validationErr, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
          dispatch({ type: SET_DETAILS_ERROR_TCINS, errorTcins })
        }
      })
      .catch((error) => {
        const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
        dispatch({ snackMessage: errorData, type: TOGGLE_SNACKBAR })
      })
  }
}

export function addTcins (data, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName: 'Add Tcin' }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return putService(data, config.grouper.group, memberOf, userId)
      .then(resp => {
        dispatch({ type: ADD_TCINS_SUCCESS, payload: resp })
        if (data.group_type === 'variation') {
          dispatch({ type: ADD_ITEMS_TO_GROUP_DETAILS, payload: resp.items })
        } else {
          dispatch(getGroupDetails(data.group_id, memberOf, userId, 'update'))
        }
        const snackMessage = { status: true, variant: 'success', message: `${data.tcin_data.length} Items added to this Group.`, autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: snackMessage })
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          let dispErrorMsg = ''
          if (error.response.data.message) {
            dispErrorMsg = error.response.data.message
          } else if (error.response.data.validation_error) {
            let validationErr = ''
            let errorTcins = []
            error.response.data.validation_error.map((option) => {
              errorTcins.push(option.tcin)
              validationErr += option.tcin + ' - ' + option.message + '<br />'
            })
            dispatch({ type: SET_ADDITEM_ERROR_TCINS, errorTcins })
            dispErrorMsg = validationErr
          } else {
            dispErrorMsg = 'Issue while adding items to the group, please try again.'
          }

          if (dispErrorMsg) {
            const errorData = { status: true, variant: 'error', message: dispErrorMsg, autoHide: false }
            dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
          }
        }

        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
  }
}

export function removeTcins (data, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName: 'Remove' }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return putService(data, config.grouper.group, memberOf, userId)
      .then(resp => {
        dispatch({ type: REMOVE_TCINS_SUCCESS, payload: resp })
        dispatch(getGroupDetails(data.group_id, memberOf, userId, 'update'))
        const snackMessage = { status: true, variant: 'success', message: `Item removed from this Group.`, autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: snackMessage })
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
  }
}

export function updateGroupName (data, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName: 'Save' }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return putService(data, config.grouper.group, memberOf, userId)
      .then(resp => {
        dispatch({ type: UPDATE_GROUP_NAME_SUCCESS, payload: resp })
        dispatch(getGroupDetails(data.group_id, memberOf, userId, 'update'))
        const snackMessage = { status: true, variant: 'success', message: `Group Updated Successfully.`, autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: snackMessage })
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
        dispatch(getGrouperList(sendGroupListPayload))
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
  }
}

export function updateItemsOrder (data, groupData, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName: 'Save Order' }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return putService(data, config.grouper.group, memberOf, userId)
      .then(resp => {
        dispatch({ type: UPDATE_ITEMS_ORDER_SUCCESS, payload: resp })
        dispatch({ type: SET_GROUP_DETAILS, payload: groupData })
        const snackMessage = { status: true, variant: 'success', message: `Group Items Order Updated Successfully.`, autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: snackMessage })
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
      .catch((error) => {
        dispatch({ type: SET_GROUP_DETAILS, payload: groupData })
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
          dispatch({ type: UPDATE_ITEMS_ORDER_ERROR, error })
        }
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
  }
}

export function clearActionTypes () {
  return {
    type: CLEAR_GROUP_DETAILS_REQUEST_TYPE,
  }
}

export function clearAddItemTcinError () {
  return {
    type: CLEAR_ADD_ITEM_TCIN_ERROR,
  }
}

export function clearGroupDetails () {
  return {
    type: CLEAR_GROUP_DETAILS,
  }
}

export function updateVariationGroupName (groupName) {
  return dispatch => {
    dispatch({ type: UPDATE_VARIATION_GROUP_NAME_REQUEST, groupName })
    dispatch({ type: UPDATE_VARIATION_GROUP_NAME_DETAILS, groupName })
  }
}

export function updateVariationDetails (data, btnName) {
  return dispatch => {
    let btnPayload = { status: true, btnName }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return postService(data, config.grouper.group)
      .then(resp => {
        // (btnName === 'Add Tcin') ? dispatch({ type: ADD_TCINS_SUCCESS }) : dispatch({ type: UPDATE_GROUP_NAME_SUCCESS })
        dispatch(setVariationPage1Data(data))
        dispatch({ type: SET_GROUP_DETAILS, payload: resp })
        dispatch({ type: ADD_TCINS_SUCCESS })
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          let dispErrorMsg = ''
          if (error.response.data.message) {
            dispErrorMsg = error.response.data.message
          } else if (error.response.data.validation_error) {
            let validationErr = ''
            let errorTcins = []
            error.response.data.validation_error.map((option) => {
              errorTcins.push(option.tcin)
              validationErr += option.tcin + ' - ' + option.message + '<br />'
            })
            dispatch({ type: SET_ERROR_TCINS, errorTcins: errorTcins })
            dispErrorMsg = validationErr
          } else {
            dispErrorMsg = 'Issue while create the group, please try again.'
          }
          if (dispErrorMsg) {
            const errorData = { status: true, variant: 'error', message: dispErrorMsg, autoHide: false }
            dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
          }
          btnPayload = { status: false, btnName: '' }
          dispatch({ type: LOADING_BTN_STATUS, btnPayload })
        }
      })
  }
}

export function setVariationDetails (page1Data, updatedDetailsInfo) {
  return dispatch => {
    // dispatch(setVariationPage1Data(page1Data))
    dispatch({ type: SET_VARIATION_PAGE1_DATA, payload: page1Data })
    dispatch({ type: SET_GROUP_DETAILS, payload: updatedDetailsInfo })
  }
}

export function sendUpdateGroupVariationDetails (data, btnName, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return putService(data, config.grouper.group, memberOf, userId)
      .then(resp => {
        // dispatch({ type: UPDATE_GROUP_NAME_SUCCESS, payload: resp })
        dispatch(getGroupDetails(data.group_id, memberOf, userId, 'update'))
        const snackMessage = { status: true, variant: 'success', message: `Group Updated Successfully.`, autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: snackMessage })
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
        dispatch(getGrouperList(sendGroupListPayload))
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
  }
}

export function setGroupDetails (updatedDetailsInfo) {
  return dispatch => {
    dispatch({ type: SET_GROUP_DETAILS, payload: updatedDetailsInfo })
    dispatch({ type: ADD_TCINS_SUCCESS })
  }
}

export function changeCollectionPublishStatus (groupData, eventType) {
  return dispatch => {
    return postService(groupData, config.grouper.publishGroup + '?event_type=' + eventType)
      .then(resp => {
        dispatch(getGroupDetails(groupData.group_ids[0].group_id, '', '', 'update'))
        const snackMessage = { status: true, variant: 'success', message: `Group status Successfully changed to ${eventType}`, autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: snackMessage })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
      })
  }
}
