import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription, firstValueFrom } from 'rxjs';
import { BaseComponent } from '../../core/base.component';
import { BreadcrumbItem } from '../../shared/components/breadcrumb/breadcrumb-item';
import { ProgressIndicatorStateService } from '../../shared/components/progress-indicator/progress-indicator-state.service';
import { ProgressStep } from '../../shared/components/progress-indicator/progress-step';
import { ValidateConfigurationSidebarComponent } from '../shared/validate-configuration-sidebar/validate-configuration-sidebar.component';
import { PipelineService } from './pipeline.service';
import { LoadedPipelineValidationService } from './shared/loaded-pipeline-validation.service';
import { PipelineEntityService } from './shared/pipeline-entity.service';
import { AlertsSidebarComponent } from '../alerts-sidebar/alerts-sidebar.component';
import { ResourcePermissionService } from '../../shared/services/resource-permission.service';
import { PipelinesApiService } from './shared/pipelines-api.service';
import { PipelineMappingService } from './mapping/pipeline-mapping.service';
import { Pipeline, PIPELINE_ENTITY_TYPE } from './shared/pipeline';
import { MAPPING_CONST } from './mapping/shared/mapping_constants';
import { ErrorMessagesService } from '@precisely/prism-ng/cloud';
import { ProjectsApiService } from './shared/projects-api.service';
import { Project } from './shared/project';
import { FeatureFlagService } from '@shared/services/feature-flag.service';

@Component({
  selector: 'p-connect-pipeline',
  templateUrl: './pipeline.component.html',
  styleUrls: ['./pipeline.component.scss'],
  // Define `ProgressIndicatorStateService` as a provider. This results in
  // a new instance of `ProgressIndicatorStateService` being created which is dedicated
  // to this component and it's child components, and will not clash with other
  // instances of `ProgressIndicatorStateService` across the app.
  providers: [ProgressIndicatorStateService]
})
export class PipelineComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild(ValidateConfigurationSidebarComponent) validateConfigurationSidebarComponent: ValidateConfigurationSidebarComponent;
  @ViewChild(AlertsSidebarComponent) alertsSidebarComponent: AlertsSidebarComponent;

  breadcrumbs: BreadcrumbItem[] = [];

  progressSteps: ProgressStep[] = [];

  subscriptions: Subscription[] = [];

  isProcessingRequest: boolean;

  latestPipeline: Pipeline;

  updatedPipeline: Pipeline;

  pipelineType = PIPELINE_ENTITY_TYPE.REPLICATION;

  homeRoute = '/pipelines';

  private isCreate = false;
  private pipelineId: string;
  private project: Project;
  private isMultipleProjectsEnabled = false;

  constructor(
    private readonly pipelineProgressIndicatorStateService: ProgressIndicatorStateService,
    private readonly pipelineService: PipelineService,
    private readonly pipelinesApiService: PipelinesApiService,
    private readonly pipelineEntityService: PipelineEntityService,
    private readonly route: ActivatedRoute,
    private readonly loadedPipelineValidationService: LoadedPipelineValidationService,
    private readonly pipelineMappingService: PipelineMappingService,
    private readonly resourcePermissionService: ResourcePermissionService,
    public router: Router,
    public readonly errorMessagesService: ErrorMessagesService,
    private readonly projectsApiService: ProjectsApiService,
    private readonly featureFlagService: FeatureFlagService
  ) {
    super(router);
  }

  ngOnInit(): void {
    this.isMultipleProjectsEnabled = this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421');
    this.pipelineService?.deployProjectFunction?.subscribe(() => {
      this.deployProject();
    });
    this.pipelineEntityService.pipelineEntityType = this.route.snapshot.data['pipelineEntityType'] || PIPELINE_ENTITY_TYPE.REPLICATION;
    this.getLatestPipeline();
    this.pipelineId = this.route.snapshot.params.id;
    this.isCreate = typeof this.pipelineId === 'undefined';
    this.setProgressSteps();
    this.getProjectInformation();
    if (!this.isCreate) {
      const updatedPipeline = this.pipelineEntityService.getUpdatePipelineData(this.route.snapshot.data.pipeline);
      this.pipelineEntityService.setPipeline(updatedPipeline);
      this.loadedPipelineValidationService.setPipeline(this.route.snapshot.data.pipeline);
      this.setProgressStepsValidityStatus();
      this.setProgressStepsCompletionStatus();
      if (this.featureFlagService.isFeatureEnabled('CDCKafkaSRCreateTopicsAndSubjectsTemp20220705')) {
        this.getStatusOfTopicAndSubjectsCreation();
      }
    }
    this.setInitialStep();
  }

  savePipelineButtonClicked(): void {
    this.pipelineService.savePipeline().then(() => {
      this.pipelineEntityService.notifyChange();
    });
  }

  /**
   * Progress indicator cancel button event handler
   */
  cancelPipelineButtonClicked(): void {
    this.navigateTo(this.homeRoute);
    this.pipelineEntityService.patchPipeline({ isEditing: false } as Partial<Pipeline>);
  }

  /**
   * Gets latest pipeline, including latest pipeline editing status;
   */
  getLatestPipeline(): void {
    this.subscriptions.push(this.pipelineEntityService.getLatestPipeline().subscribe((pipeline) => (this.latestPipeline = pipeline)));
  }

  getStatusOfTopicAndSubjectsCreation() {
    this.updatedPipeline = this.pipelineEntityService.getPipeline();
    this.pipelineMappingService.getStatusOfTopicAndSubjectsCreation();
  }

  ngOnDestroy(): void {
    this.pipelineEntityService.resetPipeline();
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  async mappingStepAction() {
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      return Promise.resolve();
    }

    return new Promise((resolve, reject) => {
      let allTargetNameHaveValidInput = true;
      const pipeline = this.pipelineEntityService.getPipeline();
      pipeline.tableMapping.forEach((ele) => {
        const targetName = ele.value.split('||').length == 2 ? ele.value.split('||')[0] : ele.value;
        if (
          ele.value === '' ||
          ele.value === null ||
          targetName.match(MAPPING_CONST.REGEX_TARGET_NAME) ||
          ele.value.split('||')[0] == '' ||
          ele.value.split('||')[1] == ''
        ) {
          allTargetNameHaveValidInput = false;
        }
      });
      if (!allTargetNameHaveValidInput) {
        reject({ error: { error: 'Target Names Blank' } });
        this.pipelineService.mappingNextAction.next(Promise.resolve());
      } else {
        this.handleSaveAndCreateTopicOrSubject(resolve, reject, pipeline);
      }
    });
  }

  private handleSaveAndCreateTopicOrSubject(resolve, reject, pipeline: Pipeline) {
    if (pipeline.createTopic || pipeline.createSubject) {
      this.pipelinesApiService
        .update(pipeline, true)
        .toPromise()
        .then(() => {
          if (this.pipelineMappingService.createNonExistingTopicsandSubjects(pipeline)) {
            resolve(this.pipelinesApiService.update(pipeline, true).toPromise());
          } else {
            reject({});
          }
        });
    } else {
      resolve(this.pipelinesApiService.update(pipeline, true)?.toPromise());
    }
  }

  private async getProjectInformation() {
    if (this.isMultipleProjectsEnabled) {
      if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.REPLICATION) {
        this.project = await firstValueFrom(this.projectsApiService.get(this.pipelineService.getProjectId()));
        this.homeRoute = '/projects/' + this.project.name;
      } else {
        this.homeRoute = '/scheduled-pipelines';
      }
    } else {
      this.project = await firstValueFrom(this.projectsApiService.getDefaultProject());
      this.homeRoute =
        this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.REPLICATION ? '/pipelines' : '/scheduled-pipelines';
    }
    this.setBreadcrumbs();
  }

  private setProgressSteps(): void {
    const pipelineId = this.route.snapshot.params.id;
    const isCreate = typeof pipelineId === 'undefined';
    const rootUrl =
      this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.REPLICATION ? '/pipelines' : '/scheduled-pipelines';

    this.progressSteps = [
      {
        text: 'pipelines.STAGES.GENERAL.HEADING',
        id: 'general',
        routerLink: isCreate ? [`${rootUrl}/create/general`] : [`${rootUrl}/${pipelineId}/edit/general`],
        isValid: false,
        isComplete: false,
        isOptional: false,
        stepChangeAction: () => {
          return this.pipelineService.savePipeline().then(() => {
            if (isCreate) {
              const pipeline = this.pipelineEntityService.getPipeline();
              this.pipelineProgressIndicatorStateService.updateRouterLink(
                `/${rootUrl}/create/general`,
                `/${rootUrl}/${pipelineId}/edit/general`
              );
              this.pipelineProgressIndicatorStateService.updateRouterLink(`${rootUrl}`, rootUrl);
              this.pipelineProgressIndicatorStateService.updateRouterLink(`${pipelineId}`, pipeline.id);
            }
          });
        }
      },
      {
        text: 'pipelines.STAGES.CONNECTIONS.HEADING',
        id: 'connections',
        routerLink: [`${rootUrl}/${pipelineId}/edit/connections`],
        isValid: false,
        isComplete: false,
        isOptional: false,
        stepChangeAction: () => {
          return this.pipelineService.savePipeline();
        }
      },
      {
        text: 'pipelines.STAGES.DATA.HEADING',
        id: 'data',
        routerLink: [`${rootUrl}/${pipelineId}/edit/data`],
        isValid: false,
        isComplete: false,
        isOptional: false,
        stepChangeAction: () => {
          return this.pipelineService.savePipeline();
        }
      },
      ...this.addMappingStep(rootUrl, pipelineId),
      // { TODO: Uncomment when the filter functionality is supported in the backend after the beta release
      //   text: 'pipelines.STAGES.FILTERS',
      //   id: 'filters',
      //   routerLink: [`${rootUrl}/${pipelineId}/edit/filters`],
      //   isValid: false,
      //   isComplete: false,
      //   isOptional: true
      // },
      {
        text: 'pipelines.STAGES.FINALIZE.HEADING',
        id: 'finalize',
        routerLink: [`${rootUrl}/${pipelineId}/edit/finalize`],
        isValid: false,
        isComplete: false,
        isOptional: false,
        stepChangeAction: this.finalizeStepAction.bind(this),
        onlyPerformStepChangeActionOnNext: true
      }
    ];
    this.pipelineProgressIndicatorStateService.initiateProgressSteps(this.progressSteps);
  }

  private addMappingStep(rootUrl: string, pipelineId: string) {
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      return [];
    }

    return [
      {
        text: 'pipelines.STAGES.MAPPING.HEADING',
        id: 'mapping',
        routerLink: [`${rootUrl}/${pipelineId}/edit/mapping`],
        isValid: false,
        isComplete: false,
        isOptional: false,
        onlyPerformStepChangeActionOnNext: true,
        stepChangeAction: this.mappingStepAction.bind(this)
      }
    ];
  }

  private getCommitStatus() {
    this.validateConfigurationSidebarComponent.openCommitValidationAsync(this.project?.id, 'finalCommitButton');
  }

  private async finalizeStepAction() {
    if (this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      this.navigateTo('scheduled-pipelines');
      if (this.pipelineEntityService.isStartPipelineRequested) {
        await firstValueFrom(this.pipelineService.runScheduledPipeline(this.pipelineEntityService.getPipeline().id));
      }
      return;
    }

    if (this.pipelineEntityService.isStageChangesEnabled) {
      const commitResponse = await this.pipelineService.commitPipeline();

      if (this.featureFlagService.isFeatureEnabled('CDCAsyncCommitTemp20221110')) {
        this.getCommitStatus();
      } else {
        if (!commitResponse.isCommited) {
          this.validateConfigurationSidebarComponent.open(commitResponse, this.project?.name, this.project?.description, this.project?.id);
        } else {
          this.deployProject();
        }
      }
    } else {
      this.navigateTo(this.homeRoute);
    }
  }

  private async startPipeline() {
    if (this.pipelineEntityService.isStartPipelineRequested) {
      const name = this.pipelineEntityService.getPipeline().name;
      const projectId = this.pipelineEntityService.getPipeline().projectId;
      await firstValueFrom(this.pipelineService.start(projectId, [name], false));
    }
  }

  private setProgressStepsValidityStatus(): void {
    this.progressSteps.find((p) => p.id === 'general').isValid = this.loadedPipelineValidationService.isGeneralStepValid();
    this.progressSteps.find((p) => p.id === 'connections').isValid = this.loadedPipelineValidationService.isConnectionsStepValid();
    this.progressSteps.find((p) => p.id === 'data').isValid = this.loadedPipelineValidationService.isDataStepValid();

    if (this.progressSteps.find((p) => p.id === 'mapping')) {
      this.progressSteps.find((p) => p.id === 'mapping').isValid = this.loadedPipelineValidationService.isMappingStepValid();
    }
  }

  private setProgressStepsCompletionStatus(): void {
    this.progressSteps.forEach((step, index) => {
      step.isComplete = this.getStepCompletionStatus(step, index);
    });
  }

  private getStepCompletionStatus(step: ProgressStep, index: number): boolean {
    const precedingSteps = this.progressSteps.slice(0, index);
    return (
      precedingSteps.every((precedingStep) => precedingStep.isComplete || precedingStep.isOptional) && (step.isValid || step.isOptional)
    );
  }

  private setBreadcrumbs(): void {
    const currentPageText = this.isCreate ? 'common.BREADCRUMBS.CREATE_PIPELINE' : 'common.BREADCRUMBS.EDIT_PIPELINE';
    const isScheduledPipeline = this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.SCHEDULED;

    if (this.isMultipleProjectsEnabled && !isScheduledPipeline) {
      const projectsRoot = '/data-integration/projects';
      const selectedProjectRoute = `${projectsRoot}/${this.project.name}`;

      this.breadcrumbs = [
        { text: 'common.BREADCRUMBS.APP_ROOT', isActive: true },
        { text: 'common.BREADCRUMBS.PROJECTS', isActive: false, routerLink: [projectsRoot] },
        { text: this.project.name, isActive: false, routerLink: [selectedProjectRoute] }
      ];

      if (!this.isCreate) {
        this.breadcrumbs.push({
          text: this.latestPipeline.name,
          isActive: false,
          routerLink: [`${selectedProjectRoute}/${this.latestPipeline.name}`]
        });
        this.breadcrumbs.push({ text: currentPageText, isActive: true });
      } else {
        this.breadcrumbs.push({ text: 'common.BREADCRUMBS.PIPELINES', isActive: true });
        this.breadcrumbs.push({ text: currentPageText, isActive: true });
      }
    } else {
      const pipelineText = isScheduledPipeline ? 'common.BREADCRUMBS.SCHEDULED_PIPELINES' : 'common.BREADCRUMBS.PIPELINES';

      this.breadcrumbs = [
        { text: 'common.BREADCRUMBS.APP_ROOT', isActive: true },
        { text: pipelineText, isActive: true },
        { text: currentPageText, isActive: true }
      ];
    }
  }

  private setInitialStep = () => {
    const url = this.router.url;
    // The following is somewhat hacky and would benefit from more work. At the time of writing it
    // I couldn't figure out a clean way to match the current route with an entry
    // in `ProgressIndicatorStateService.ProgressSteps`. GG.
    const searchString =
      this.pipelineEntityService.pipelineEntityType === PIPELINE_ENTITY_TYPE.REPLICATION ? '/pipelines' : '/scheduled-pipelines';
    let urlForProgressIndicator = url.substring(url.indexOf(searchString));
    this.pipelineProgressIndicatorStateService.setActiveStepByRouterLink(urlForProgressIndicator);
  };

  private displayAlertsSidebar(): void {
    this.alertsSidebarComponent.open();
    this.alertsSidebarComponent.renderTable = false;
    setTimeout(() => {
      // Workaround for a bug wherein the table is not rendered on the sidebar unless the
      // browser window is resized (See https://github.com/primefaces/primeng/issues/9766)
      this.alertsSidebarComponent.renderTable = true;
    });
  }

  async onContinueStageEvent() {
    await this.deployProject();
  }

  async deployProject() {
    if (this.resourcePermissionService.hasResourcePermission('PIPELINE.DEPLOY')) {
      if (this.pipelineEntityService.isDeployChangesEnabled) {
        if (this.pipelineEntityService.isDisplayAlertsEnabled) {
          this.displayAlertsSidebar();
        }
        await this.pipelineService.deployPipeline();
      } else {
        this.startPipeline();
      }
      if (!this.pipelineEntityService.isDisplayAlertsEnabled) {
        this.navigateTo(this.homeRoute);
      }
    } else {
      this.navigateTo(this.homeRoute);
    }
  }
}
