import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AlertsListingComponent } from 'alerts/alerts-listing/alerts-listing.component';
import { ProfileResultsComponent } from 'profiling/profile-results/profile-results.component';
import { ObserverConfigureComponent } from './observer-configure/observer-configure.component';
import { ObserverDetailViewComponent } from './observer-detail-view/observer-detail-view.component';
import { ObserverListingComponent } from './observer-listing/observer-listing.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: ObserverListingComponent
  },
  {
    path: 'new',
    component: ObserverConfigureComponent
  },
  {
    path: 'edit/:observerId',
    component: ObserverConfigureComponent
  },
  {
    path: 'observer-detail/:observerName/:observerId',
    component: ObserverDetailViewComponent,
    children: [
      {
        path: 'alerts',
        component: AlertsListingComponent,
        data: { tabIndex: 0 }
      },
      {
        path: 'profile/:profileId',
        component: ProfileResultsComponent,
        data: { tabIndex: 1 }
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ObserverRoutingModule {}
