import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA, SimpleChange, SimpleChanges } from '@angular/core';
import { ComponentFixture, fakeAsync, flush, TestBed, tick } from '@angular/core/testing';
import { FormControl, FormGroup } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { MetadataApiService } from '../../pipelines/pipeline/data/schema-table-selector/metadata-api.service';
import { Project } from '../../pipelines/pipeline/shared/project';
import { ProjectsApiService } from '../../pipelines/pipeline/shared/projects-api.service';
import { MockSidebarComponent } from '../../shared/components/sidebar/mock-sidebar.component.spec';
import { Metabase } from '../shared/metabase.model';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { MetabaseFormComponent } from './metabase-form/metabase-form.component';
import { MetabaseSidebarComponent } from './metabase-sidebar.component';

describe('MetabaseSidebarComponent', () => {
  let component: MetabaseSidebarComponent;
  let fixture: ComponentFixture<MetabaseSidebarComponent>;
  let projectsApiService: ProjectsApiService;
  let metabasesApiService: MetabasesApiService;
  let metadataApiService: MetadataApiService;

  @Component({
    selector: 'p-connect-metabase-form',
    template: '',
    providers: [
      {
        provide: MetabaseFormComponent,
        useClass: MockMetabaseFormComponent
      }
    ]
  })
  class MockMetabaseFormComponent {
    supportedConnectionTypes = [
      { connectionType: 'ORACLE', accessMethod: 'JDBC' },
      { connectionType: 'DB2I', accessMethod: 'JDBC' }
    ];
    childComponentReference = {
      instance: {
        dataConnection: {}
      },
      destroy: () => {}
    };
    metabaseFormGroup = new FormGroup({
      id: new FormControl('1'),
      dataConnection: new FormControl('')
    });

    get metabase(): Metabase {
      return {
        parameters: [{ key: 'REPLICATION_USER_PASSWORD', value: 'myPassword' }],
        dataConnection: { id: 'abcd', connectionType: 'ORACLE', accessFromServer: { name: 'myServer' } }
      };
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'metabases' } }],
      declarations: [MetabaseSidebarComponent, MockSidebarComponent, MockMetabaseFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MetabaseSidebarComponent);
    component = fixture.componentInstance;
    projectsApiService = TestBed.inject(ProjectsApiService);
    metabasesApiService = TestBed.inject(MetabasesApiService);
    metadataApiService = TestBed.inject(MetadataApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should cancel and hide the form', () => {
    spyOn(component.metabaseFormComponent.childComponentReference, 'destroy').and.returnValue(null);
    component.cancelMetabaseButtonClicked();
    expect(component.isVisible).toBe(false);
  });

  it('should enable save button if form is valid', fakeAsync(() => {
    component.isVisible = true;
    const changesObj: SimpleChanges = { isVisible: new SimpleChange(false, true, false) };
    component.ngOnChanges(changesObj);
    component.metabaseFormComponent.metabaseFormGroup.patchValue({ id: '2' });
    tick();
    fixture.whenStable().then(() => {
      expect(component.primaryButton.isDisabled).toBe(false);
      flush();
    });
  }));

  it('should not update form buttons when other changes are made', () => {
    component.isVisible = false;
    const changesObj: SimpleChanges = { prop: new SimpleChange(1, 2, false) };
    component.ngOnChanges(changesObj);
    expect(component.primaryButton.isDisabled).toBe(true);
  });

  it('setMetabase', () => {
    // placeholder
    component.setMetabase('1');
    expect(true).toBeTruthy();
  });

  it('should save metabase', fakeAsync(() => {
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(metabasesApiService, 'create').and.returnValue(of({ id: 1 }));
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(of('mypublickey'));
    component.saveMetabaseButtonClicked();
    tick();
    expect(metabasesApiService.create).toHaveBeenCalled();
  }));

  it('should handle error saving a metabase', fakeAsync(() => {
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(metabasesApiService, 'create').and.returnValue(throwError({}));
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(metadataApiService, 'getPublicKey').and.returnValue(throwError({ error: '{"detailedMessage": "test failed" }' }));
    spyOnProperty(component.metabaseFormComponent, 'metabase', 'get').and.returnValue({
      adminUserPassword: 'pwd',
      parameters: [{ key: 'REPLICATION_USER_PASSWORD', value: 'myPassword' }],
      dataConnection: { id: 'abcd', connectionType: 'ORACLE', accessFromServer: { name: 'myServer' } }
    });
    component.saveMetabaseButtonClicked();
    tick();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
  }));
});
