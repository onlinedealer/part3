import { ScheduleConfigModel } from 'discovery-core';
import { ScheduleRunsModel } from './schedule-runs.model';

export class ScheduleHistoryModel {
  profileId: string;
  profileName: string;
  profileRunInformationList: ScheduleRunsModel[];
  scheduleConfig: ScheduleConfigModel;
  scheduleId: string;
}
