import { Component, Input } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';

/**
 * Form used to stop bundling.
 */
@Component({
  selector: 'p-connect-stop-bundle-form',
  templateUrl: './stop-bundle-form.component.html'
})
export class StopBundleFormComponent {
  /**
   * The number of bundles selected
   */
  @Input() bundlesCount: number;

  /**
   * The number of bundles to be stopped
   */
  @Input() stoppableBundlesCount: number;

  constructor(private readonly translocoService: TranslocoService) {}

  /**
   * Get the plural or singular verb
   */
  get pluralOrSingularVerb(): string {
    let verb = this.bundlesCount !== 1 ? 'bundles.STOP_BUNDLE.BUNDLES' : 'bundles.STOP_BUNDLE.BUNDLE';
    return this.translocoService.translate(verb);
  }
}
