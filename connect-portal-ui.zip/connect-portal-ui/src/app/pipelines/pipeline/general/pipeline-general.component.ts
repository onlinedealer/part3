import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Subscription } from 'rxjs';
import { BaseComponent } from '../../../core/base.component';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { Pipeline, PIPELINE_ENTITY_TYPE } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';

const progressIndicatorStepIndex = 0;

@Component({
  selector: 'p-connect-pipeline-general',
  templateUrl: './pipeline-general.component.html'
})
export class PipelineGeneralComponent extends BaseComponent implements OnInit, OnDestroy {
  generalForm: FormGroup;

  pipelineTypes = [
    { label: `Synchronize`, value: 'SYNCHRONIZE' },
    { label: `Replicate`, value: 'REPLICATE' },
    { label: `Copy`, value: 'COPY' }
  ];

  private statusChangesSubscription: Subscription;

  private valueChangesSubscription: Subscription;

  readonly PIPELINE_TYPE = PIPELINE_ENTITY_TYPE;

  possibleKeys: { key: string; value?: string }[] = [
    'REPLICATION_TRANSACTION_ERROR_MODE',
    'COPY_ERROR_MODE',
    'COPY_SOURCE_ISOLATION_LEVEL',
    'COPY_SOURCE_LOCKING',
    'COPY_SOURCE_TABLE_RETRIEVE_ORDER'
  ].map((value) => {
    return { key: value };
  });

  private get pipeline(): Partial<Pipeline> {
    if (this.pipelineType === PIPELINE_ENTITY_TYPE.SCHEDULED) {
      return {
        name: this.generalForm.get('name').value,
        description: this.generalForm.get('description').value
      };
    }

    const properties = [...this.possibleKeys];

    const type = this.generalForm.get('dataFlowType').value;
    // Add properties for synchronize/replicate
    if (type === 'SYNCHRONIZE' || type === 'REPLICATE') {
      properties.push({ key: 'REPLICATION_TRANSACTION_ERROR_MODE', value: this.generalForm.get('transactionErrorMode').value });
    }
    // Add properties for synchronize/copy
    if (type === 'SYNCHRONIZE' || type === 'COPY') {
      properties.push({ key: 'COPY_ERROR_MODE', value: this.generalForm.get('errorMode').value });
      properties.push({ key: 'COPY_SOURCE_ISOLATION_LEVEL', value: this.generalForm.get('sourceIsolationLevel').value });
      properties.push({ key: 'COPY_SOURCE_LOCKING', value: this.generalForm.get('sourceLocking').value });
      properties.push({ key: 'COPY_SOURCE_TABLE_RETRIEVE_ORDER', value: this.generalForm.get('sourceTableRetrievalOrder').value });
    }
    return {
      name: this.generalForm.get('name').value,
      description: this.generalForm.get('description').value,
      dataFlowType: this.generalForm.get('dataFlowType').value,
      properties
    };
  }

  constructor(
    private readonly formBuilder: FormBuilder,
    private readonly progressIndicatorState: ProgressIndicatorStateService,
    private readonly pipelineEntityService: PipelineEntityService
  ) {
    super();
  }

  ngOnInit(): void {
    this.createForm();
    this.initValidateFormOnStatusChange();
    this.loadPipeline();
    this.initUpdatePipelineEntityOnValuesChange();
  }

  ngOnDestroy(): void {
    this.statusChangesSubscription.unsubscribe();
    this.valueChangesSubscription.unsubscribe();
  }

  displayReplicationOptions(): boolean {
    return this.generalForm.get('dataFlowType').value === 'SYNCHRONIZE' || this.generalForm.get('dataFlowType').value === 'REPLICATE';
  }

  displayCopyOptions(): boolean {
    return this.generalForm.get('dataFlowType').value === 'SYNCHRONIZE' || this.generalForm.get('dataFlowType').value === 'COPY';
  }

  get pipelineType(): string {
    return this.pipelineEntityService.pipelineEntityType;
  }

  private createForm(): void {
    this.generalForm = this.formBuilder.group({
      name: new FormControl('', Validators.required),
      description: new FormControl('', Validators.maxLength(500)),
      dataFlowType: new FormControl('SYNCHRONIZE'),
      transactionErrorMode: new FormControl('SHUT_DOWN_APPLY'),
      errorMode: new FormControl('TERMINATE_RUN'),
      sourceIsolationLevel: new FormControl('READ_COMMITTED'),
      sourceLocking: new FormControl('INDIVIDUAL_TABLE'),
      sourceTableRetrievalOrder: new FormControl('ANY_ORDER')
    });
  }

  private initValidateFormOnStatusChange(): void {
    this.statusChangesSubscription = this.generalForm.statusChanges.subscribe((status: string) => {
      const isValid = status.toUpperCase() === 'VALID';
      this.progressIndicatorState.setIsValid(progressIndicatorStepIndex, isValid);
    });
  }

  private readonly loadPipeline = (): void => {
    const originalPipeline = this.pipelineEntityService.getPipeline();
    this.generalForm.patchValue(originalPipeline);
    if (originalPipeline.properties) {
      this.patchProperties(originalPipeline);
    }
  };

  private readonly patchProperties = (originalPipeline: Pipeline) => {
    originalPipeline.properties.forEach((property) => {
      if (property.key === 'REPLICATION_TRANSACTION_ERROR_MODE') {
        this.generalForm.patchValue({ transactionErrorMode: property.value });
      } else if (property.key === 'COPY_ERROR_MODE') {
        this.generalForm.patchValue({ errorMode: property.value });
      } else if (property.key === 'COPY_SOURCE_ISOLATION_LEVEL') {
        this.generalForm.patchValue({ sourceIsolationLevel: property.value });
      } else if (property.key === 'COPY_SOURCE_LOCKING') {
        this.generalForm.patchValue({ sourceLocking: property.value });
      } else if (property.key === 'COPY_SOURCE_TABLE_RETRIEVE_ORDER') {
        this.generalForm.patchValue({ sourceTableRetrievalOrder: property.value });
      }
    });
    return originalPipeline;
  };

  private readonly initUpdatePipelineEntityOnValuesChange = (): void => {
    this.valueChangesSubscription = this.generalForm.valueChanges.subscribe(this.updatePipelineEntity);
  };

  private readonly updatePipelineEntity = (): void => {
    const updatedPipeline = this.pipeline;
    this.pipelineEntityService.patchPipeline(updatedPipeline);
  };
}
