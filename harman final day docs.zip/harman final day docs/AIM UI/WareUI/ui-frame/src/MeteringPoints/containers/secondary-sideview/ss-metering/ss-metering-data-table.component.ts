import { Component, ChangeDetectionStrategy, Input, OnInit, OnDestroy } from "@angular/core";
import { DateFormatService } from "../../../../Shared/services/date-format.service";
import { map } from "rxjs/operators";
import { Metering } from "../../../models/metering.model";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { MeteringsActions, ProfileDataActions } from "../../../store/actions";
import {
    MeteringPointsUISelectors,
    MeteringsSelectors,
    MeteringPointsSelectors,
    RegistersSelectors,
    MeteringDataUISelectors,
    ProfileDataSelectors,
    PeriodicDataSelectors,
    MeterConnectionsWithConfigurationsSelectors
} from "../../../store/selectors";
import { Observable, BehaviorSubject } from "rxjs";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../../app/services/translations-service";
import { ValuesForTable, convertValuesForTableEpochsToDisplay } from "../../../models/view-objects/summarytable-vo.model";
import { MeterConnectionVO } from "../../../models/view-objects/meterconnection-vo.model";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { LocalStorageKeys, LocalStorageService } from "../../../../app/services/local-storage.service";

@Component({
    selector: "landisgyr-ss-metering-data-table",
    templateUrl: "./ss-metering-data-table.component.html",
    styleUrls: ["./ss-metering-data-table.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSMeteringDataTableComponent implements OnInit, OnDestroy {
    @Input()
    metering!: Metering;

    sideviewExpanded$: Observable<boolean> = this.store.select(MeteringPointsUISelectors.getMeteringPointsSideviewExpanded);
    profileDataLoading$: Observable<boolean> = this.store.select(ProfileDataSelectors.getProfileDataLoading);
    periodicDataLoading$: Observable<boolean> = this.store.select(PeriodicDataSelectors.getPeriodicDataLoading);
    devices$: Observable<MeterConnectionVO[]> = this.store.select(
        MeterConnectionsWithConfigurationsSelectors.getSelectedMeteringPointMeterConnectionsEntitiesForTable
    );
    deviceMeterRegisters$: Observable<{ [id: number]: number[] }> = this.store.select(RegistersSelectors.getDeviceMeterRegisterIds);
    meteringDataForExport$: Observable<any> = this.store.select(MeteringsSelectors.getSelectedMeteringDetailsForExport);
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);

    profileDataForExport$: Observable<ValuesForTable[] | undefined> = this.store.select(
        ProfileDataSelectors.getSelectedProfileDataForHours
    );
    periodicDataForExport$: Observable<ValuesForTable[] | undefined> = this.store.select(
        PeriodicDataSelectors.getSelectedPeriodicDataForHours
    );
    eventsTimeRange$ = this.store.select(MeteringDataUISelectors.getMeteringDataTimesSelection);

    profileData$: Observable<ValuesForTable[] | undefined> = this.store
        .select(ProfileDataSelectors.getProfileDataForHoursWithMissingDataObjects)
        .pipe(map((values) => this.convertValueTimestampsForDisplay(values)));

    periodicData$: Observable<ValuesForTable[] | undefined> = this.store
        .select(PeriodicDataSelectors.getSelectedPeriodicDataForHours)
        .pipe(map((values) => this.convertValueTimestampsForDisplay(values)));

    meteringDetailsExpanded = new BehaviorSubject(false);
    meteringDetailsExpanded$ = this.meteringDetailsExpanded.asObservable();
    editMode$: Observable<boolean> = this.store.select(ProfileDataSelectors.getEditMode);
    undoRedoDisabled$: Observable<{ undoDisabled: boolean; redoDisabled: boolean }> = this.store.select(
        ProfileDataSelectors.getUndoRedoDisabled
    );
    editDisabled$: Observable<{ valuesDisabled: boolean; cumulativeValuesDisabled: boolean }> = this.store.select(
        ProfileDataSelectors.getEditDisabled
    );
    operationsDisabled$: Observable<{ multiplyDisabled: boolean; interpolationDisabled: boolean }> = this.store.select(
        ProfileDataSelectors.getOperationsDisabled
    );
    allSelected$: Observable<{ allValuesSelected: boolean; allCumulativeValuesSelected: boolean }> = this.store.select(
        ProfileDataSelectors.getAreAllEditProfileSelected
    );
    isProfileDataEdited$: Observable<boolean> = this.store.select(ProfileDataSelectors.getIsProfileDataEdited);

    editSuccess$: Observable<boolean> = this.store.select(ProfileDataSelectors.getProfileEditSuccess);
    editError$: Observable<string> = this.store.select(ProfileDataSelectors.getProfileEditError);

    public profilePeriodicColumnsData: any;
    changed = false;
    viewName!: string;

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private dateFormatService: DateFormatService,
        public translations: TranslationsService,
        private localStorage: LocalStorageService
    ) {}
    ngOnDestroy(): void {
        this.store.dispatch(ProfileDataActions.SwitchEditMode({ editMode: false, selectedMeteringId: undefined }));
    }

    ngOnInit() {
        this.localStorage.changedColumnInfo.subscribe((data) => {
            if (data.key === LocalStorageKeys.meteringDataTable || data.key === LocalStorageKeys.meteringDataTableCollapsed) {
                this.changed = true;
                this.profilePeriodicColumnsData = data.value;
            }
        });
        if (!this.changed) {
            this.sideviewExpanded$.subscribe((ele) => {
                if (ele && this.localStorage.getColumnConfiguration(LocalStorageKeys.meteringDataTable)) {
                    this.viewName = LocalStorageKeys.meteringDataTable;
                    this.profilePeriodicColumnsData = this.localStorage.getColumnConfiguration(LocalStorageKeys.meteringDataTable);
                } else if (ele && !this.localStorage.getColumnConfiguration(LocalStorageKeys.meteringDataTable)) {
                    this.viewName = LocalStorageKeys.meteringDataTable;
                    this.store.select(MeteringPointsUISelectors.getProfilePeriodicColumnConfigInitial).subscribe((data) => {
                        this.profilePeriodicColumnsData = data;
                    });
                } else if (!ele && this.localStorage.getColumnConfiguration(LocalStorageKeys.meteringDataTableCollapsed)) {
                    this.viewName = LocalStorageKeys.meteringDataTableCollapsed;
                    this.profilePeriodicColumnsData = this.localStorage.getColumnConfiguration(LocalStorageKeys.meteringDataTableCollapsed);
                } else if (!ele && !this.localStorage.getColumnConfiguration(LocalStorageKeys.meteringDataTableCollapsed)) {
                    this.viewName = LocalStorageKeys.meteringDataTableCollapsed;
                    this.store.select(MeteringPointsUISelectors.getProfilePeriodicCollapsedColumnConfigInitial).subscribe((data) => {
                        this.profilePeriodicColumnsData = data;
                    });
                }
            });
        }
    }

    decimalCount(): number | undefined {
        if (this.metering.measuredUnit) {
            const unitsWithNoDecimals = ["W", "Wh"];
            const unitsWithThreeDecimals = ["kW", "kWh"];
            if (unitsWithNoDecimals.indexOf(this.metering.measuredUnit.name) >= 0) {
                console.log("Desimaali-indeksi: ", unitsWithThreeDecimals.indexOf(this.metering.measuredUnit.name));
                return 0;
            }
            if (unitsWithThreeDecimals.indexOf(this.metering.measuredUnit.name) >= 0) {
                console.log("Desimaali-indeksi: ", unitsWithThreeDecimals.indexOf(this.metering.measuredUnit.name));
                return 3;
            }
        }
        return undefined;
    }

    onSortChange(sortChange: SortOrder): void {
        this.store.dispatch(MeteringsActions.SetMeteringsDataTableSorting({ sortChange }));
    }

    onMeteringDetailsExpandToggled(expanded: boolean) {
        this.meteringDetailsExpanded.next(expanded);
    }

    private convertValueTimestampsForDisplay = (values: ValuesForTable[]) => {
        return values.map((value) => convertValuesForTableEpochsToDisplay(value, this.dateFormatService));
    };
}
