import { HttpErrorResponse } from '@angular/common/http';
import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { ToastrService } from 'ngx-toastr';
import { HistoryTableSettingModel } from 'shared/history-table/history-table-setting.model';
import { ScheduleService } from '../schedule.service';
import { ScheduleHistoryModel } from 'discovery-core';
import {
  ValidationMessageTypeModel,
  ValidationMessage,
  SharedConstants as ProfilingConstants,
  Helper,
  SharedConstants
} from 'discovery-shared';
import { Router } from '@angular/router';
import { HistoryHeaderModel } from 'shared/history-table/history-header.model';
import { HistoryDataModel } from 'shared/history-table/history-data-model';
import { ScheduleSidebarConfigModel } from './schedule-sidebar-config.model';
@Component({
  selector: 'discovery-schedule-detail',
  templateUrl: './schedule-detail.component.html',
  styleUrls: ['./schedule-detail.component.css']
})
export class ScheduleDetailComponent implements OnInit {
  @Output() showScheduleSidebarChange: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() refresh: EventEmitter<string> = new EventEmitter<string>();
  /**
   * toggle for sidebar visibility
   */
  _showScheduleSidebar: boolean;
  _scheduleType: ScheduleSidebarConfigModel;
  switchScheduler = false;
  isTableVisible = false;
  isEditScreenVisible = false;
  editEnabled = false;
  scheduleHistoryDetails = new ScheduleHistoryModel();
  ValidationMessageType: ValidationMessageTypeModel;
  failureMessages: any[] = [];
  failureActionMessages: any[] = [];
  actionMessageType: ValidationMessageTypeModel;
  daysOfWeekView: string;
  tableSetting: HistoryTableSettingModel;
  isLoading = false;
  get showScheduleSidebar(): boolean {
    return this._showScheduleSidebar;
  }

  @Input()
  set showScheduleSidebar(val: boolean) {
    this._showScheduleSidebar = val;
  }

  get scheduleType(): ScheduleSidebarConfigModel {
    return this._scheduleType;
  }

  @Input()
  set scheduleType(val: ScheduleSidebarConfigModel) {
    this._scheduleType = val;
  }

  schedularSourceConstants = SharedConstants.SCHEDULER_SOURCE;

  constructor(
    private scheduleService: ScheduleService,
    private translocoService: TranslocoService,
    private toastrService: ToastrService,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (
      this.scheduleType.viewType === SharedConstants.SCHEDULE_STATUS.SUSPENDED &&
      this.scheduleType.source === SharedConstants.SCHEDULER_SOURCE.OBSERVER
    ) {
      this.actionMessageType = ValidationMessageTypeModel.Error;
      this.failureActionMessages.push(
        new ValidationMessage(
          this.translocoService.translate('discoveryShared.scheduleHistoryDetails.suspendedObserver'),
          {
            heading: this.translocoService.translate('discoveryShared.scheduleHistoryDetails.suspendedScheduler'),
            actionMessage: this.translocoService.translate('discoveryShared.scheduleHistoryDetails.enableSchedule')
          }
        )
      );
    } else if (
      this.scheduleType.viewType === SharedConstants.SCHEDULE_STATUS.SUSPENDED &&
      this.scheduleType.source === SharedConstants.SCHEDULER_SOURCE.PROFILING
    ) {
      this.ValidationMessageType = ValidationMessageTypeModel.Error;
      this.failureMessages.push(
        new ValidationMessage(
          this.translocoService.translate('discoveryShared.scheduleHistoryDetails.suspendedProfile'),
          {
            heading: this.translocoService.translate('discoveryShared.scheduleHistoryDetails.suspendedScheduler')
          }
        )
      );
    }
    this.getScheduleHistory(this.scheduleType.id);
  }

  cancelCreate(): void {
    this.showScheduleSidebarChange.emit(false);
  }

  getScheduleHistory(profileId): void {
    this.isLoading = true;
    this.scheduleService.getScheduleHistory(profileId).subscribe(
      (response: ScheduleHistoryModel) => {
        this.isLoading = false;
        this.isTableVisible = true;
        this.scheduleHistoryDetails = response;
        if (this.scheduleHistoryDetails.scheduleConfig?.schedule) {
          const date = Helper.convertUTCtoLocalTimezone(this.scheduleHistoryDetails.scheduleConfig.schedule.runAtTime);
          const timeFormat = Helper.getTimeFormat(date.getHours());
          const { hours, minutes } = Helper.getFormattedHrsAndMins(date);
          this.scheduleHistoryDetails.scheduleConfig.schedule.runAtTime.hour = hours;
          this.scheduleHistoryDetails.scheduleConfig.schedule.runAtTime.minute = minutes;
          this.scheduleHistoryDetails.scheduleConfig.schedule.runAtTime.meridiemIndicator = timeFormat;
        }
        const daysOfWeek = this.scheduleHistoryDetails.scheduleConfig?.schedule?.daysOfWeek;
        if (daysOfWeek?.length) {
          this.daysOfWeekView = [daysOfWeek.slice(0, -1).join(', '), daysOfWeek.slice(-1)[0]].join(
            daysOfWeek.length < 2 ? '' : ' & '
          );
        }
        this.onScheduleStatusChanged();
        const historyArray = [];
        if (this.scheduleHistoryDetails?.profileRunInformationList) {
          for (const history of this.scheduleHistoryDetails?.profileRunInformationList) {
            let status: string;
            if (
              history.status === ProfilingConstants.STATUS.SUCCESS ||
              history.status === ProfilingConstants.STATUS.INPROGRESS
            ) {
              status = history.status;
            } else if (history.status === ProfilingConstants.STATUS.CANCELLED) {
              status = this.translocoService.translate('discoveryShared.scheduleHistoryDetails.stoppedProfile');
            } else {
              status = history.errorMessage;
            }

            historyArray.push(
              new HistoryDataModel({
                run: history.runDateTime,
                duration: history.duration,
                status: status,
                id: history.id
              })
            );
          }
        }
        this.tableSetting = new HistoryTableSettingModel();
        this.tableSetting.defaultSort = ProfilingConstants.HISTORY_TABLE_DEFAULT_SORT.HISTORY_SCHEDULER;
        this.tableSetting.sortable = true;
        this.tableSetting.isTablePagination = false;
        this.tableSetting.noHistoryFound = this.translocoService.translate(
          'discoveryShared.scheduleHistoryDetails.noRunsFound'
        );
        this.tableSetting.tableHeader = this.getTableHeader();
        this.tableSetting.tableData = historyArray;
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.isLoading = false;
        this.isTableVisible = false;
        if (httpErrorResponse.status === 404) {
          this.toastrService.error(httpErrorResponse.message);
        }
      }
    );
  }

  toggleSchedule(): void {
    this.scheduleService.toggleSchedule(this.scheduleType.id, this.switchScheduler).subscribe(
      (response) => {
        this.refresh.emit();
        this.failureMessages.length = 0;
        this.failureActionMessages.length = 0;
        this.scheduleType.viewType = this.switchScheduler
          ? ProfilingConstants.SCHEDULE_STATUS.ENABLED
          : ProfilingConstants.SCHEDULE_STATUS.DISABLED;
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.switchScheduler = !this.switchScheduler;
        this.toastrService.error(httpErrorResponse?.error.message);
      }
    );
  }

  editSchedule() {
    this.router.navigateByUrl(`/data-observability/data-profiling/edit/${this.scheduleType.id}?index=finalize`);
  }

  private onScheduleStatusChanged(): void {
    switch (this.scheduleType.viewType) {
      case ProfilingConstants.SCHEDULE_STATUS.ENABLED:
        this.switchScheduler = true;
        break;
      case ProfilingConstants.SCHEDULE_STATUS.DISABLED:
        const disabledDate = this.scheduleHistoryDetails?.scheduleConfig?.lastStatusUpdatedDateTime
          ? this.getFormattedDate(this.scheduleHistoryDetails?.scheduleConfig?.lastStatusUpdatedDateTime)
          : '';
        this.ValidationMessageType = ValidationMessageTypeModel.Warning;
        this.failureMessages.push(
          new ValidationMessage(
            this.translocoService.translate(
              'discoveryShared.scheduleHistoryDetails.scheduleStatusMessage.disabled.message',
              {
                date: disabledDate
              }
            )
          )
        );
        break;
      case ProfilingConstants.SCHEDULE_STATUS.NOT_CONFIGURED:
        this.isEditScreenVisible = true;
        this.editEnabled = this.scheduleType.editEnabled;
        break;
      default:
        this.switchScheduler = this.scheduleType.source === SharedConstants.SCHEDULER_SOURCE.OBSERVER ? true : false;
    }
  }
  private getTableHeader(): HistoryHeaderModel[] {
    const header = [
      {
        labelName: this.translocoService.translate('discoveryShared.scheduleHistoryDetails.historyTableHeaders.run'),
        fieldName: 'run',
        isSort: false,
        type: 'date'
      },
      {
        labelName: this.translocoService.translate(
          'discoveryShared.scheduleHistoryDetails.historyTableHeaders.duration'
        ),
        fieldName: 'duration',
        isSort: false
      },
      {
        labelName: this.translocoService.translate('discoveryShared.scheduleHistoryDetails.historyTableHeaders.status'),
        fieldName: 'status',
        type: 'status',
        isSort: false
      }
    ];
    const tableHeader = [];
    for (const element of header) {
      tableHeader.push(new HistoryHeaderModel(element));
    }
    return tableHeader;
  }
  private getFormattedDate(date: number): string {
    const dateParam = new Date(date);
    const monthValue = dateParam.toLocaleString('default', { month: 'short' });
    const dayValue = dateParam.getDate();
    const yearValue = dateParam.getFullYear();
    const time = dateParam.toLocaleString(ProfilingConstants.DATE_DEFAULT_LOCALE, {
      hour: 'numeric',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
    return `${monthValue} ${dayValue}, ${yearValue}, ${time}`;
  }
}
