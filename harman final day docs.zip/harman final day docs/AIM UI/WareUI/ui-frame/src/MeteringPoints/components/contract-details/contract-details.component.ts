import { Component, Input, ChangeDetectionStrategy } from "@angular/core";
import { Contract } from "../../models/contract.model";
import { TranslationsService } from "../../../app/services/translations-service";

@Component({
    selector: "landisgyr-contract-details",
    templateUrl: "./contract-details.component.html",
    styleUrls: ["./contract-details.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class ContractDetailsComponent {
    @Input()
    contract!: Contract;

    constructor(public translations: TranslationsService) {}
}
