import { TestBed } from '@angular/core/testing';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { SelectSourceComponent } from 'discovery-shared';
import { Mocks, Spies } from 'discovery-test';
import { ProfileListingComponent } from 'profiling/profile-listing/profile-listing.component';
import { of, throwError } from 'rxjs';
import { ProfileConfigureComponent } from './profile-configure.component';
import { ProfileDetailsComponent } from './profile-details/profile-details.component';

describe('ProfileConfigureComponent', () => {
  let component: ProfileConfigureComponent;
  let router: Router;
  let activateRoute: ActivatedRoute;

  beforeEach(() => {
    Spies.init();

    TestBed.configureTestingModule({
      imports: [
        RouterTestingModule.withRoutes([
          { path: '', component: ProfileListingComponent },
          { path: 'data-profiling/new/select-source', component: SelectSourceComponent },
          { path: 'data-profiling/new/configure-profile', component: ProfileConfigureComponent }
        ])
      ]
    });

    router = TestBed.inject(Router);

    component = new ProfileConfigureComponent(
      router,
      Spies.ProfileService,
      Spies.TranslateService,
      Spies.ToastrService,
      Spies.ActivatedRoute,
      Spies.launchDarklyService
    );

    component.selectSourceComponent = new SelectSourceComponent(
      {} as any,
      Spies.ConnectionService,
      {} as any,
      {} as any,
      {} as any
    );
    component.profileDetailsComponent = new ProfileDetailsComponent();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('validation select source', () => {
    expect(component.validate()).toBe(false);
  });

  it('test ngOnInit with editMode success', () => {
    const mockUrlTree = router.parseUrl('/data-observability/data-profiling/edit/2c9380837dbe23a9017dc7908e080001');
    // @ts-ignore: force this private property value for testing.
    router.currentUrlTree = mockUrlTree;
    component.profileId = Spies.ActivatedRoute.paramMap;
    spyOn(component, 'loadProfileById');
    Spies.ProfileService.getProfile.and.returnValue(of('dummy'));
    component.ngOnInit();
    expect(component.editMode).toBe(true);
    expect(component.copyMode).toBe(false);
  });
  it('test ngOnInit with copyMode success', () => {
    const mockUrlTree = router.parseUrl('/data-observability/data-profiling/copy/2c9380837dbe23a9017dc7908e080001');
    // @ts-ignore: force this private property value for testing.
    router.currentUrlTree = mockUrlTree;
    component.profileId = Spies.ActivatedRoute.paramMap;
    spyOn(component, 'loadProfileById');
    Spies.ProfileService.getProfile.and.returnValue(of('dummy'));
    console.log(component.editMode);
    component.ngOnInit();
    expect(component.editMode).toBe(false);
    expect(component.copyMode).toBe(true);
  });
  it('test ngOnInit failure', () => {
    component.profileId = Spies.ActivatedRoute.paramMap;
    Spies.ProfileService.getProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[2]));
    component.ngOnInit();
    expect(component.editMode).toBe(false);
  });
  it('test ngOnInit failure with 404 code', () => {
    component.profileId = Spies.ActivatedRoute.paramMap;
    Spies.ProfileService.getProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.ngOnInit();
    expect(component.editMode).toBe(false);
    expect(Spies.ToastrService['error']).toHaveBeenCalled();
  });
  it('validation profile details', () => {
    component.activeIndex = 2;
    component.profileDetailsComponent.profileDetailForm = new NgForm([], []);
    expect(component.validate()).toBe(false);
  });
  it('test moveNext fn call', () => {
    component.validationFailures = new Set<string>();
    component.activeIndex = 0;
    spyOn(component, 'validate').and.returnValue(true);
    component.moveNext();
    expect(component.activeIndex).toBe(1);
  });
  it('test movePrev fn call', () => {
    component.activeIndex = 1;
    component.movePrevious();
    expect(component.activeIndex).toBe(0);
  });
  it('test cancel', () => {
    const spy = spyOn(router, 'navigateByUrl');
    component.cancelCreate();
    expect(spy.calls.first().args[0]).toBe('/data-observability/data-profiling');
  });

  it('test save profile success', () => {
    spyOn(component, 'validate').and.returnValue(true);
    const spy = spyOn(router, 'navigateByUrl');
    Spies.launchDarklyService.variation.and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(of('dummy'));
    component.saveProfile();
    expect(component.saveInProgress).toBe(false);
    expect(spy.calls.first().args[0]).toBe('/data-observability/data-profiling');
  });
  it('test save profile success with schedule feature false', () => {
    spyOn(component, 'validate').and.returnValue(true);
    const spy = spyOn(router, 'navigateByUrl');
    Spies.launchDarklyService.variation.and.returnValue(false);
    Spies.ProfileService.saveProfile.and.returnValue(of('dummy'));
    component.saveProfile();
    expect(component.saveInProgress).toBe(false);
    expect(spy.calls.first().args[0]).toBe('/data-observability/data-profiling');
  });
  it('test save profile failed at server side', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.saveProfile();
    expect(component.saveInProgress).toBe(false);
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test save profile failed with response 409', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[2]));
    component.saveProfile();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });

  it('test save profile failed with response 423', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[3]));
    component.saveProfile();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test save profile failed with response 404', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.saveProfile();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test run profile success', () => {
    const spy = spyOn(router, 'navigateByUrl');
    Spies.ProfileService.runProfile.and.returnValue(of('dummy'));
    component.runProfile('id', 'name');
    expect(Spies.ToastrService.success).toHaveBeenCalled();
    expect(spy.calls.first().args[0]).toBe('/data-observability/data-profiling');
  });

  it('test run profile failed at server side', () => {
    Spies.ProfileService.runProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.runProfile('id', 'name');
    expect(Spies.ToastrService.error).toHaveBeenCalled();
  });

  it('test save and run profile success', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.launchDarklyService.variation.and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(of('dummy'));
    Spies.ProfileService.runProfile.and.returnValue(of('dummy'));
    const spy = spyOn(router, 'navigateByUrl');
    component.saveRunProfile();
    expect(Spies.ToastrService.success).toHaveBeenCalled();
    expect(spy.calls.first().args[0]).toBe('/data-observability/data-profiling');
  });
  it('test save and run profile success with schedule feature false', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.launchDarklyService.variation.and.returnValue(false);
    Spies.ProfileService.saveProfile.and.returnValue(of('dummy'));
    Spies.ProfileService.runProfile.and.returnValue(of('dummy'));
    const spy = spyOn(router, 'navigateByUrl');
    component.saveRunProfile();
    expect(Spies.ToastrService.success).toHaveBeenCalled();
    expect(spy.calls.first().args[0]).toBe('/data-observability/data-profiling');
  });
  it('test save failed in save and run profile', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.saveRunProfile();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test save and run profile failed with response 409', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[2]));
    component.saveRunProfile();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });

  it('test save and run profile failed with response 423', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[3]));
    component.saveRunProfile();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test save and run profile failed with response 404', () => {
    spyOn(component, 'validate').and.returnValue(true);
    Spies.ProfileService.saveProfile.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.saveRunProfile();
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });
  it('test rules list change', () => {
    const rulesListMap = new Map<string, Map<string, any>>();

    const mockRuleListJson = Mocks.MockAllRulesList;

    for (const ruleId in mockRuleListJson) {
      if (mockRuleListJson.hasOwnProperty(ruleId)) {
        const rulesOptionsMap = new Map<string, any>();

        for (const optionId in mockRuleListJson[ruleId]) {
          if (mockRuleListJson[ruleId].hasOwnProperty(optionId)) {
            rulesOptionsMap.set(optionId, mockRuleListJson[ruleId][optionId]);
          }
        }

        rulesListMap.set(ruleId, rulesOptionsMap);
      }
    }
    component.rulesListChanged(rulesListMap);
    expect(component.profileConfigureModel.rules).toEqual(mockRuleListJson);
  });

  it('load from settings', () => {
    component.profileConfigureModel.loadFromSettings(Mocks.MockProfiles[0]);
    expect(component.profileConfigureModel.name).toBe('Profile1');
    expect(component.profileConfigureModel.tables.length).toBe(1);
  });
  it('test disableActions event', () => {
    const result = false;
    component.disableActions(result);
    expect(component.isActionDisabled).toBe(result);
  });
});
