﻿(function(){
'use strict';
angular.module('arm').factory('userService', ['utility', '$rootScope', 'MASTER_TABLE','$filter','sqliteService','GENERAL_CONFIG','serviceApi', 'SERVICE_TYPE',factoryModel]);
    function factoryModel(utility,$rootScope,MASTER_TABLE,$filter,sqliteService,GENERAL_CONFIG,serviceApi, SERVICE_TYPE){

	   var factoryFunctionArr = [];

     factoryFunctionArr.models = function()
      {
      return{
       //Contact model
         userModel :
           {
             UserID: 0,
             OrganisationID: 0,
             UserName: '',
             ManagerID: 0,
             SalutationID: null,
             SalutationName: '',
             FirstName: '',
             LastName: '',
             MiddleName: '',
             FullName: '',
             DOB: '',
             DesignationID: null,
             UnitID: 0,
             AllowedContactType: 0,
             PreferredLanguageID: 0,
             PasswordHash: '',
             IsActive: false,
             Islocked: false,
             UserType: 0,
             AccessCategoryID: 0
           },
         }
     }

  factoryFunctionArr.fetchUserListFromServer = function (requestType) {

            var serviceURL = SERVICE_TYPE.USERLIST+$rootScope.loggedInUserID+'/'+$rootScope.languageID+'/NULL/'+requestType;
            serviceApi.headerConfg['WebServiceType'] = GENERAL_CONFIG.WebServiceType.UserList;
           
            return serviceApi.doGetWithoutData("LoadUserListData",
                    serviceURL, headerconfig).then(function (response) 
                  {
                        var queryBindingsArr = [];
                        for (var userCategory in response) {
                            var UserType = "";
                            switch(userCategory) {
                                case "ActivityOwnershipUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.ActivityOwnershipUsers;
                                    break;
                               case "ContactOwnershipUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.ContactOwnershipUsers;
                                    break;
                                case "ContactSharingUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.ContactSharingUsers;
                                    break;
                                case "DealOwnershipUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.DealOwnershipUsers;
                                    break;
                                case "InternalMessagingUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.InternalMessagingUsers;
                                    break;
                                case "LoggedInAsUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.LoggedInAsUsers;
                                    break;
                                case "OtherAttendeeUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.OtherAttendeeUsers;
                                    break;
                                case "ParallelAccessUsers":
                                    UserType = GENERAL_CONFIG.UsersCategory.ParallelAccessUsers;
                                    break;
                            }
                      angular.forEach(response[userCategory], function (obj, key) {
                        queryBindingsArr.push(factoryFunctionArr.prepareUserInsertQuery(obj,UserType));
                      });
                  }

                 return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
                              return ['ABCD'];
                                }, function (error) {
                                alert(error);
                            });                  
              },
             function (err) {
              });
         }  
      
  factoryFunctionArr.prepareUserInsertQuery = function(user,UserTypeNow) {
         var userInsertQuery = "INSERT INTO Users (AccessCategoryID,FirstName,FullName,LastName,OrganisationID,UserID,UserName,UserType) VALUES ('" + user.AccessCategoryID + "','" + user.FirstName + "','" + user.FullName + "','" + user.LastName + "','" + user.OrganisationID + "','" + user.UserID + "','" + user.UserName + "','" + UserTypeNow + "')";
           return  {'Query':userInsertQuery,'Bindings':''};
           }
   		return factoryFunctionArr;
   	}
})();


/*(function () {
    'use strict';

    angular.module('arm').factory('userService',['$scope',userServiceInit]);
    
    function userServiceInit($scope){
	
	var factoryFunctionArr = [];

   //  factoryFunctionArr.models = function()
   //  	{
			// return{
			// 	//Contact model
			// 		userModel :
			// 			{
			// 				UserID: 0,
			// 				OrganisationID: 0,
			// 				UserName: '',
			// 				ManagerID: 0,
			// 				SalutationID: null,
			// 				SalutationName: '',
			// 				FirstName: '',
			// 				LastName: '',
			// 				MiddleName: '',
			// 				FullName: '',
			// 				DOB: '',
			// 				DesignationID: null,
			// 				UnitID: 0,
			// 				AllowedContactType: 0,
			// 				PreferredLanguageID: 0,
			// 				PasswordHash: '',
			// 				IsActive: false,
			// 				Islocked: false,
			// 				UserType: 0,
			// 				AccessCategoryID: 0
 		// 				},
 		// 			}
 		// }

 	// factoryFunctionArr.fetchUserListFromServer = function (requestType) {

  //           var serviceURL = SERVICE_TYPE.USERLIST+$rootScope.loggedInUserID+'/'+$rootScope.languageID+'/NULL/'+requestType;
  //           serviceApi.headerConfg['WebServiceType'] = GENERAL_CONFIG.WebServiceType.UserList;
           
  //           return serviceApi.doGetWithoutData("LoadUserListData",
  //                   serviceURL, headerconfig).then(function (response) {
  //                       //debugger
  //                       var queryBindingsArr = [];
  //                       for (var userCategory in response) {
  //                           ////console.log(prop);
  //                           ////console.log(response[prop].length);
  //                           var UserType = "";
  //                           switch(userCategory) {
  //                               case "ActivityOwnershipUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.ActivityOwnershipUsers;
  //                                   break;
  //                              case "ContactOwnershipUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.ContactOwnershipUsers;
  //                                   break;
  //                               case "ContactSharingUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.ContactSharingUsers;
  //                                   break;
  //                               case "DealOwnershipUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.DealOwnershipUsers;
  //                                   break;
  //                               case "InternalMessagingUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.InternalMessagingUsers;
  //                                   break;
  //                               case "LoggedInAsUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.LoggedInAsUsers;
  //                                   break;
  //                               case "OtherAttendeeUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.OtherAttendeeUsers;
  //                                   break;
  //                               case "ParallelAccessUsers":
  //                                   UserType = GENERAL_CONFIG.UsersCategory.ParallelAccessUsers;
  //                                   break;
  //                           }
        
  //                            angular.forEach(response[userCategory], function (obj, key) {
		// 		                queryBindingsArr.push(factoryFunctionArr.prepareUserInsertQuery(obj,UserType));
		// 		            });
  //                       }

		// 	 // return sqliteService.multipleQueries(queryBindingsArr).then(function (result) {
		// 	 // 					//return ['ABCD'];
		// 	 //                }, function (error) {
		// 	 //                alert(error);
		// 	 //            });

  //                   },
  //            function (err) {
  //            });
  //       }	
	// factoryFunctionArr.prepareUserInsertQuery = function(user,UserTypeNow) {
	// 		var userInsertQuery = "INSERT INTO Users (AccessCategoryID,FirstName,FullName,LastName,OrganisationID,UserID,UserName,UserType) VALUES ('" + user.AccessCategoryID + "','" + user.FirstName + "','" + user.FullName + "','" + user.LastName + "','" + user.OrganisationID + "','" + user.UserID + "','" + user.UserName + "','" + UserTypeNow + "')";
	//  		return  {'Query':userInsertQuery,'Bindings':''};
	//      }

	   return factoryFunctionArr;
}})();*/