export const environment = {
  production: false,
  apiKey: "2e77f5eb-016f-44a6-8d73-d5f2e6a01a54",
  apiSecret: "bf2a3c64-16df-4bfe-8fa9-53c24b079ea7",
  retailurl: "https://services-sit2.cvs.com/minuteClinic/retailWebContent?appName=CVS_WEB&channelName=WEB&contentType=BCC&deviceID=device12345&deviceToken=BLNK&deviceType=DESKTOP&lineOfBusiness=RETAIL&operationName=retailWebContent&serviceCORS=False&serviceName=webContent&version=1.0&apiKey=2e77f5eb-016f-44a6-8d73-d5f2e6a01a54&apiSecret=bf2a3c64-16df-4bfe-8fa9-53c24b079ea7&contentId=",
  env: 'sit',
  headerconfigurlMobile: "/assets/mock-services/headerService.json",
  headerconfigurlDesktop: "/assets/mock-services/headerService.json",
  headerconfigurlMobileMultiOffer: "/assets/mock-services/headerService.json", 
  headerconfigurlDesktopMultiOffer: "/assets/mock-services/headerService.json", 
  imagePath : '/webcontent/ng-extracare/extracare_leanNg6/assets/images/',
  cvsHealthHost: 'https://test-services.cvshealth.com'
};
