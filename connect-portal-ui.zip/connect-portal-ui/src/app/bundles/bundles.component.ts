import { Component, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbItem } from '@shared/components/breadcrumb/breadcrumb-item';
import { TableConfiguration, TableField, TableMessage, TableMessageType } from '@shared/components/generic-table/generic-table';
import { MenuItem } from 'primeng/api';
import { BaseComponent } from '../core/base.component';
import { ProjectsApiService } from '../pipelines/pipeline/shared/projects-api.service';
import { ResourcePermissionService } from '../shared/services/resource-permission.service';
import { Bundle } from './shared/bundles';
import { CreateBundleSidebarComponent } from './create-bundle-sidebar/create-bundle-sidebar.component';
import { BundlesApiService } from './shared/bundles-api.service';
import { forkJoin } from 'rxjs';
import { mergeMap, tap } from 'rxjs/operators';
import { Project } from '../pipelines/pipeline/shared/project';
import { PipelinesApiService } from '../pipelines/pipeline/shared/pipelines-api.service';
import { Connection } from '../connections/shared/connection';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { StopBundleDialogComponent } from './stop-bundle-dialog/stop-bundle-dialog.component';
import { DeleteBundleDialogComponent } from './delete-bundle-dialog/delete-bundle-dialog.component';
import { DatePipe } from '@angular/common';
import { BundleDetailsSidebarComponent } from './bundle-details-sidebar/bundle-details-sidebar.component';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'p-connect-bundles',
  templateUrl: './bundles.component.html'
})
export class BundlesComponent extends BaseComponent implements OnInit {
  @ViewChild(CreateBundleSidebarComponent) createBundleSidebarComponent: CreateBundleSidebarComponent;
  @ViewChild(StopBundleDialogComponent) stopBundleDialogComponent: StopBundleDialogComponent;
  @ViewChild(DeleteBundleDialogComponent) deleteBundleDialogComponent: DeleteBundleDialogComponent;
  @ViewChild(BundleDetailsSidebarComponent) bundleDetailsSidebarComponent: BundleDetailsSidebarComponent;

  breadcrumbs: BreadcrumbItem[] = [
    { text: 'common.BREADCRUMBS.PIPELINES', routerLink: ['/data-integration/pipeline'], isActive: false },
    { text: 'common.BREADCRUMBS.BUNDLES', isActive: true }
  ];

  /**
   * List of fields that are displayed in the table.
   */

  fields: TableField[] = [
    { header: 'bundles.BUNDLES_TABLE.COLUMNS.STATUS', name: 'status', columnStyle: { width: '6rem', minWidth: '6rem' } },
    {
      header: 'bundles.BUNDLES_TABLE.COLUMNS.NAME',
      name: 'bundleName',
      columnStyle: { width: '23rem', minWidth: '6rem' },
      isSearchable: true,
      isClickable: () => true,
      clickEvent: (event: Bundle) => this.bundleDetailsSidebarComponent.open(event, this.listOfSourceConnectionsInProject, this.project)
    },
    {
      header: 'bundles.BUNDLES_TABLE.COLUMNS.CREATED',
      name: 'createdDate',
      isSearchable: true
    },
    {
      isHidden: this.featureFlagService.isFeatureDisabled('CDCMultipleProjectsTemp20220421'),
      header: 'bundles.BUNDLES_TABLE.COLUMNS.PROJECT',
      name: 'projectName',
      isSearchable: true
    },
    {
      header: 'bundles.BUNDLES_TABLE.COLUMNS.AGENT',
      name: 'agentName',
      isSearchable: true
    },
    {
      header: 'bundles.BUNDLES_TABLE.COLUMNS.SIZE',
      isSearchable: true,
      name: 'sizeFormatted'
    },
    {
      header: 'bundles.BUNDLES_TABLE.COLUMNS.DESCRIPTION',
      isSearchable: true,
      name: 'description'
    }
  ];

  emptyTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'bundles.BUNDLES_TABLE.MESSAGES.NO_BUNDLES_CONFIGURED.HEAD',
    messageCaption: 'bundles.BUNDLES_TABLE.MESSAGES.NO_BUNDLES_CONFIGURED.CAPTION'
  };

  filterTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'bundles.BUNDLES_TABLE.MESSAGES.NO_FILTER_RESULTS.HEAD'
  };

  errorTableMessage: TableMessage = {
    messageType: TableMessageType.ALERT,
    messageHead: 'bundles.BUNDLES_TABLE.MESSAGES.ERROR.HEAD',
    messageCaption: 'bundles.BUNDLES_TABLE.MESSAGES.ERROR.CAPTION'
  };

  toolbarMenuItems: MenuItem[] = [];

  tableConfiguration: TableConfiguration = {
    hideCheckboxColumn: false,
    isLoading: false,
    visibleRows: 25,
    isFilterShown: true,
    fields: this.fields,
    tableToolbar: {
      style: { width: '23rem', height: '60px' },
      menuItems: this.toolbarMenuItems
    },
    tableMessages: {
      emptyTableMessage: this.emptyTableMessage,
      filterTableMessage: this.filterTableMessage,
      errorTableMessage: this.errorTableMessage
    },
    primaryButtonText: this.resourcePermissionService.hasResourcePermission('BUNDLE.ADD') ? 'bundles.BUTTON.CREATE_BUNDLE' : undefined,
    createButtonClicked: () => {
      this.createBundleSidebarComponent.open(this.project, this.listOfSourceConnectionsInProject);
    },
    rowSelectionChangedEvent: (checkedItems: any[]) => {
      this.selectedBundles = checkedItems;
    },
    getCheckboxTestIds: (row) => {
      return !row ? 'bundles-globalcheckbox' : 'bundle-checkbox-' + row.bundleName;
    }
  };

  private project: Project;
  listOfSourceConnectionsInProject: Connection[];
  /**
   * There are 3 page level messages that can be displayed at the top of bundles portlet
   * Numbers 1 - 3 will toggle which page level message will be shown
   */
  pageLevelMessage: number = 0;
  createdBundleName: string = '';
  bundles: Bundle[] = [];
  selectedBundles: any[] = [];
  showStopBundleDialog = false;
  showDeleteBundleDialog = false;
  manageDiagnosticBundlesURL = environment.manageDiagnosticBundlesURL;

  constructor(
    private readonly resourcePermissionService: ResourcePermissionService,
    private readonly projectsApiService: ProjectsApiService,
    private readonly pipelinesApiService: PipelinesApiService,
    private readonly bundlesApiService: BundlesApiService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly datePipe: DatePipe
  ) {
    super();
  }

  ngOnInit(): void {
    this.getListOfBundles();
    this.pageLevelMessage = 1;
  }

  getListOfBundles(createdBundleName?: string): void {
    this.tableConfiguration.isLoading = true;
    const projects$ = this.projectsApiService.getDefaultProject();
    const pipelines$ = this.pipelinesApiService.getAll();
    forkJoin([projects$, pipelines$])
      .pipe(
        tap((response) => {
          this.project = response[0] as Project;
          this.listOfSourceConnectionsInProject = response[1]
            .filter((pipeline) => pipeline.projectId === this.project.id && pipeline.source?.dataConnection)
            .map((pipeline) => pipeline.source.dataConnection);
        }),
        mergeMap(() => this.bundlesApiService.getBundles())
      )
      .subscribe({
        next: (bundles: Bundle[]) => {
          this.defaultSort(bundles);
          this.bundles = bundles.map((bundle) => {
            return {
              ...bundle,
              createdDate:
                this.datePipe.transform(new Date(bundle.createdDate), 'dd MMM YYYY hh:mm') +
                this.datePipe.transform(new Date(bundle.createdDate), 'a').toLowerCase(),
              sizeFormatted: this.formatBytes(bundle.size)
            };
          });
          if (createdBundleName) {
            this.createdBundleName = createdBundleName;
            this.updatePageLevelMessage();
          }
        }
      })
      .add(() => {
        this.tableConfiguration.isLoading = false;
      });
  }

  isStopBundleDisabled(): boolean {
    return this.selectedBundles.some((bundle: Bundle) => bundle.status === 'IN_PROGRESS') !== true;
  }

  isDeleteBundleDisabled(): boolean {
    return this.selectedBundles.some((bundle: Bundle) => bundle.status !== 'IN_PROGRESS') !== true;
  }

  openStopBundleDialog(): void {
    this.showStopBundleDialog = true;
    let stoppableBundles = this.selectedBundles.filter((bundle: Bundle) => bundle.status === 'IN_PROGRESS');
    this.stopBundleDialogComponent.open(stoppableBundles, this.selectedBundles.length);
  }

  openDeleteBundleDialog(): void {
    this.showDeleteBundleDialog = true;
    let deletableBundles = this.selectedBundles.filter((bundle: Bundle) => bundle.status !== 'IN_PROGRESS');
    this.deleteBundleDialogComponent.open(deletableBundles, this.selectedBundles.length);
  }

  refreshData(): void {
    // clear the selection
    this.selectedBundles = [];
    // reload the list of bundles so that the statuses get updated
    this.getListOfBundles();
  }

  formatBytes(bytes, decimals = 2): string {
    const sizeInMB = (bytes / (1024 * 1024)).toFixed(decimals);
    return sizeInMB + ' MB';
  }

  defaultSort(bundles: Bundle[]) {
    // the default sort is the most recent created date first
    bundles.sort((a, b) => {
      return <any>new Date(b.createdDate) - <any>new Date(a.createdDate);
    });
  }

  getBundleNameTestId(row) {
    return row.field.name !== 'bundleName' ? null : 'bundle-' + row.defaultValue;
  }

  private updatePageLevelMessage(): void {
    this.pageLevelMessage = 2;
    const bundlesInQueue = this.bundles.filter((bundle) => bundle.status === 'QUEUED');
    if (bundlesInQueue.length >= 1) {
      this.pageLevelMessage = 3;
    }
  }
}
