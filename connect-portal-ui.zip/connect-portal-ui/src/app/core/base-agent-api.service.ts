import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { BaseApiService } from './base-api.service';

/**
 * Abstract class that provides basic CRUD endpoints
 * Any service that interacts with the Agent API should extend this base service
 */
export abstract class BaseAgentApiService<T> extends BaseApiService<T> {
  constructor(protected httpClient: HttpClient, protected url?: string) {
    super(httpClient, environment.agentApiBaseUrl, url);
  }

  update(item: { agentId: string; agentName: string; agentDescription: string }): Observable<any> {
    const url = `${environment.agentApiBaseUrl}/${item.agentId}`;
    const body = {
      agentName: item.agentName,
      agentDescription: item.agentDescription
    };
    return this.httpClient.patch(url, body);
  }

  deleteAgent(item: { tenantId: string; productName: string; agentIds: string[] }): Observable<any> {
    return this.httpClient.delete(`${environment.agentApiBaseUrl}`, { body: item });
  }
}
