import { HttpClient } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { AuthModule, StsConfigHttpLoader, StsConfigLoader } from 'angular-auth-oidc-client';
import { map } from 'rxjs/operators';

export const httpLoaderFactory = (http: HttpClient) => {
  const config = http.get<{ clientId: string; stsServer: string }>('assets/data/oidc.json').pipe(
    map((oidc) => ({
      clientId: oidc.clientId,
      authority: oidc.stsServer,
      redirectUrl: window.location.origin + '/login/callback',
      postLogoutRedirectUri: window.location.origin,
      scope: 'openid profile email',
      responseType: 'code',
      silentRenew: true,
      useRefreshToken: true,
      renewTimeBeforeTokenExpiresInSeconds: 30,
      triggerAuthorizationResultEvent: true
    }))
  );
  return new StsConfigHttpLoader(config);
};

@NgModule({
  imports: [
    AuthModule.forRoot({
      loader: {
        provide: StsConfigLoader,
        useFactory: httpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ]
})
export class AuthConfigModule {}
