import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { NameValidatorService, SharedConstants as ProfilingConstants, ScheduleComponent } from 'discovery-shared';
import { NgForm } from '@angular/forms';
import { ProfilingRulesComponent } from '../profiling-rules/profiling-rules.component';
import { ProfileConfigureModel } from '../profile-configure.model';
import { ScheduleConfigModel } from 'discovery-core';

@Component({
  selector: 'discovery-profile-details',
  templateUrl: './profile-details.component.html',
  styleUrls: ['./profile-details.component.css']
})
export class ProfileDetailsComponent {
  @ViewChild('profileDetailForm')
  profileDetailForm: NgForm;
  //remove the ProfileRules view child if scheduleFeatureFlag feature removed
  @ViewChild('profileRules')
  profilingRulesComponent: ProfilingRulesComponent;

  @ViewChild('profileScheduler')
  scheduleComponent: ScheduleComponent;

  @Input() profileName: string;
  //feature flag
  @Input() scheduleFeatureFlag: boolean;
  @Input() profileDescription: string;
  @Output() profileNameChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() profileDescriptionChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() selectedRulesListChange: EventEmitter<Map<string, Map<string, any>>> = new EventEmitter<
    Map<string, Map<string, any>>
  >();
  @Output() schedulerChange: EventEmitter<ScheduleConfigModel> = new EventEmitter<ScheduleConfigModel>();
  NameValidatorService: typeof NameValidatorService = NameValidatorService;
  profileSampleSize: number;
  profileNotification: string;
  scheduleEnabled: boolean = false;
  readonly minimumSampleSize: number = 1;
  readonly maximumSampleSize: number;
  profileNameError: any = {
    invalidName: false
  };

  validateProfileName() {
    this.profileName = this.profileName?.trim();
    this.profileNameError.invalidName = false;
    if (this.profileName) {
      const test = NameValidatorService.validateName(this.profileName);
      if (!test || this.profileName.length > ProfilingConstants.NAMEMAXLENGTH) {
        this.profileNameError.invalidName = true;
      }
    }
  }
  getSchedulerChange(event) {
    this.schedulerChange.emit(event);
  }
  profileNameChanged() {
    this.profileNameChange.emit(this.profileName);
  }

  profileDescriptionChanged() {
    this.profileDescriptionChange.emit(this.profileDescription);
  }

  rulesListChanged(selectedRulesList) {
    this.selectedRulesListChange.emit(selectedRulesList);
  }

  validate(): Set<string> {
    this.validateProfileName();
    const errors: Set<string> = new Set<string>();
    this.profileDetailForm.onSubmit(null);
    if (!this.profileName || this.profileName.trim().length === 0) {
      errors.add('discoveryProfiling.profilingDetails.missingName');
    } else if (
      !this.NameValidatorService.validateName(this.profileName) ||
      this.profileName.length > ProfilingConstants.NAMEMAXLENGTH
    ) {
      errors.add('discoveryProfiling.profilingDetails.invalidName');
    }
    //remove the first condtion i.e flag if feature flag removed
    if (this.scheduleFeatureFlag && !this.scheduleComponent?.onSubmit()) {
      errors.add('discoveryProfiling.scheduleProfile.errorMessages.invalidSchedule');
    }
    return errors;
  }

  loadProfileSettings(profileConfigureModel: ProfileConfigureModel, isEdit: boolean) {
    this.profileName = profileConfigureModel.name ? profileConfigureModel.name : '';
    this.profileDescription = profileConfigureModel.description ? profileConfigureModel.description : '';
    //remove the complete if block code if scheduleFeatureFlag feature removed
    if (!this.scheduleFeatureFlag) {
      this.profilingRulesComponent?.loadProfileSettings(profileConfigureModel);
    }
    if (profileConfigureModel.scheduleConfig) {
      this.scheduleComponent?.loadScheduleSettings(profileConfigureModel, isEdit);
    }
  }
}
