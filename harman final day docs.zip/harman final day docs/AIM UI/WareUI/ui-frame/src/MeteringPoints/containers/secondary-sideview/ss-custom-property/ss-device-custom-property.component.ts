import { Component, ChangeDetectionStrategy } from "@angular/core";
import { TranslationsService } from "../../../../app/services/translations-service";
import { CustomPropertyVO } from "../../../models/view-objects/custom-property-vo.model";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import * as MeterConnectionSelectors from "../../../store/selectors/meterconnections.selectors";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import { MeteringsSelectors } from "../../../store/selectors";

@Component({
    selector: "landisgyr-ss-device-custom-property",
    templateUrl: "./ss-device-custom-property.component.html",
    styleUrls: ["./ss-device-custom-property.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSDeviceCustomPropertyComponent {
    loading$: Observable<boolean> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);
    refreshDataLoading$: Observable<boolean> = this.store.select(MeterConnectionSelectors.getLoadingData);
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    customproperties$: Observable<CustomPropertyVO[]> = this.store.select(MeterConnectionSelectors.getDeviceMetersCustomPropertyForTable);
    firstColumnHeader: string;

    constructor(public translations: TranslationsService, private store: Store<MeteringPointsFeatureState>) {
        this.firstColumnHeader = $localize`:|@@ssDeviceCustomProp.parameter:Parameter` + "/" + this.translations.getTranslation("Status");
    }
}
