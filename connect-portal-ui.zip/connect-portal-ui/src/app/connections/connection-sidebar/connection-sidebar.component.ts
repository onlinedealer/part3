import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  EventEmitter,
  Input,
  OnChanges,
  OnDestroy,
  OnInit,
  Output,
  SimpleChanges,
  ViewChild
} from '@angular/core';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { BaseComponent } from '../../core/base.component';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { ConnectionFormComponent } from './connection-form/connection-form.component';
import { Connection } from '../shared/connection';
import { ConnectionsApiService } from '../shared/connections-api.service';
import { EncryptionService } from '@shared/services/encryption.service';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { MenuItem } from 'primeng/api';
import { CatalogStatus } from '../catalogs/shared/catalog-status';

/**
 * Connection sidebar component
 *
 * This is a wrapper component for the p-sidebar component used for creating and editing data connections
 */
@Component({
  selector: 'p-connect-connection-sidebar',
  styleUrls: ['./connection-sidebar.component.scss'],
  templateUrl: './connection-sidebar.component.html'
})
export class ConnectionSidebarComponent extends BaseComponent implements OnInit, OnChanges, OnDestroy, AfterViewInit {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * Reference to the ConnectionFormComponent child component
   */
  @ViewChild(ConnectionFormComponent) connectionFormComponent: ConnectionFormComponent;

  /**
   * Set to true to display the sidebar component
   */
  @Input() isVisible: boolean;

  /**
   * Event that is triggered when the sidebar visible state changes internally
   */
  @Output() isVisibleChanged = new EventEmitter<boolean>();

  /**
   * Event that is fired when a connection has been saved, returns the id of the new connection
   */
  @Output() connectionSavedEvent = new EventEmitter<{ id: string }>();

  /**
   * Event that is emitted when data connection has schemas/topics/subjects cataloged
   */
  @Output() connectionCataloged = new EventEmitter<CatalogStatus>();

  /**
   * List of supported connection types, this can be used to limit the supported connection types
   */
  @Input() connectionTypes = [];

  /**
   * Primary button definition for the sidebar
   */
  primaryButton: SidebarButton = {
    id: 'connectionSaveButton',
    text: 'connections.CONNECTION_FORM.BUTTONS.SAVE',
    isDisabled: true
  };

  /**
   * Secondary button definition for the sidebar
   */
  secondaryButton: SidebarButton = {
    id: 'connectionTestButton',
    text: 'connections.CONNECTION_FORM.BUTTONS.TEST',
    isDisabled: true
  };

  /**
   * Cancel button definition for the sidebar
   */
  cancelButton: SidebarButton = {
    id: 'connectionCancelButton',
    text: 'connections.CONNECTION_FORM.BUTTONS.CANCEL'
  };

  subscriptions: Subscription[] = [];

  /**
   * Toggles the sidebar and associated components to be in edit mode
   */
  isEditingConnection: boolean = false;

  /**
   * List of menuitems for the sidebar progress bar
   */
  connectionSteps: MenuItem[] = [
    {
      label: '<h4>Connection</h4',
      escape: false,
      styleClass: ''
    },
    {
      label: '<h4>Catalog</h4>',
      escape: false,
      styleClass: ''
    }
  ];

  /**
   * The default active step index (0 = connection, 1 = catalog)
   */
  activeStepIndex = 0;

  /**
   * The connection id being edited
   */
  connectionId = '';

  /**
   * The connection object - required for manage capture component
   */
  connection: Connection;

  /**
   * Checks if start cataloging button is clicked in catalog section of creating a connection. Start cataloging button is only clickable
   * when schemas, topics or subjects are selected
   */
  isStartCatalogButtonClicked = false;

  /**
   * Count of finish button when clicked, in catalog stage of connection sidebar
   */
  finishButtonClickCount: number = 0;

  /**
   * Toggles displaying catalog warning
   */
  get showCatalogWarning(): boolean {
    return !this.isStartCatalogButtonClicked && this.activeStepIndex === 1 && this.finishButtonClickCount === 1;
  }

  /** @internal */
  constructor(
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly connectionsService: ConnectionsApiService,
    private readonly encryptionService: EncryptionService,
    private readonly featureFlagService: FeatureFlagService
  ) {
    super();
  }

  /** @internal */
  ngOnInit(): void {
    this.primaryButton.text = 'connections.CONNECTION_FORM.BUTTONS.SAVE_AND_CONTINUE';
  }

  /** @internal */
  ngOnChanges(changes: SimpleChanges): void {
    if (changes.isVisible) {
      if (this.isVisible) {
        this.activeStepIndex = 0;
        this.secondaryButton.isHidden = false;
        if (this.connectionFormComponent) {
          this.configureForm();
        }
      } else {
        this.isEditingConnection = false;
        this.primaryButton.text = 'connections.CONNECTION_FORM.BUTTONS.SAVE_AND_CONTINUE';
        this.ngOnDestroy();
      }
    }
  }

  /** @internal */
  ngOnDestroy(): void {
    this.subscriptions.forEach((subscription) => subscription.unsubscribe());
  }

  /** @internal */
  ngAfterViewInit() {
    this.changeDetectorRef.detectChanges();
  }

  /**
   * Opens the connection based on the passed in ID
   * @param id the id of the connection to be opened
   */
  openConnection(id: string) {
    if (id) {
      this.isEditingConnection = true;
      this.primaryButton.text = 'connections.CONNECTION_FORM.BUTTONS.SAVE';
      this.connectionId = id;
      this.setConnection(id);
    } else {
      this.isEditingConnection = false;
      this.primaryButton.text = 'connections.CONNECTION_FORM.BUTTONS.SAVE_AND_CONTINUE';
      this.connectionId = '';
    }
  }

  /**
   * Returns an encrypted password
   * @param runtimeServerName the runtime server name
   * @param password the password
   * @returns an encrypted password
   */
  async getEncryptedPassword(runtimeServerName: string, password: string) {
    const encryptedPassword = (await this.encryptionService.encrypt(runtimeServerName, password).catch((errorResponse) => {
      this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
    })) as string;
    return encryptedPassword;
  }

  /**
   * Saves the connection or moves back to the previous step on the wizard
   */
  async primaryButtonClicked() {
    if (this.activeStepIndex === 1) {
      this.activeStepIndex = 0;
      this.secondaryButton.isHidden = false;
      this.primaryButton.text = 'connections.CONNECTION_FORM.BUTTONS.SAVE_AND_CONTINUE';
      this.primaryButton.buttonClassName = '';
      this.cancelButton.text = 'connections.CONNECTION_FORM.BUTTONS.CANCEL';
      this.cancelButton.buttonClassName = '';
      this.finishButtonClickCount = 0;
      this.isStartCatalogButtonClicked = false;
      setTimeout(() => {
        if (this.connectionFormComponent) {
          this.configureForm();
          this.setConnection(this.connectionId);
        }
      });
      return;
    }

    this.sidebarComponent.isProcessingRequest = true;

    const connection = this.connectionFormComponent.getConnection(false);
    const runtimeServerName = connection.accessFromServer;

    if (connection.password) {
      connection.password = await this.getEncryptedPassword(runtimeServerName.name, connection.password);
    }

    // Oracle must also encrypt the root container password
    if (connection.connectionType === 'ORACLE') {
      const containerPasswordParamater = connection.parameters.find(
        (parameter) => parameter.key === 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD'
      );
      if (containerPasswordParamater && containerPasswordParamater.value) {
        containerPasswordParamater.value = await this.getEncryptedPassword(runtimeServerName.name, containerPasswordParamater.value);
      }
    }

    const saveConnectionRequest = !this.connectionId
      ? this.connectionsService.create(connection)
      : this.connectionsService.update(connection);

    saveConnectionRequest
      .pipe(first())
      .subscribe({
        next: (response: { id: string }) => {
          this.connectionSavedEvent.emit(response);
          this.responsefromSaveConnection(response);
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  private responsefromSaveConnection(response: { id: string }) {
    if (response) {
      this.connectionId = response.id;
      this.connectionFormComponent.connectionFormGroup.patchValue({ id: this.connectionId });
    } else {
      this.connectionId = this.connectionFormComponent.connectionFormGroup.get('id').value;
    }

    if (this.isEditingConnection) {
      this.cancelConnectionButtonClicked();
    } else {
      this.connection = this.connectionFormComponent.getConnection();
      this.activeStepIndex = 1;
      this.primaryButton.text = 'connections.CONNECTION_FORM.BUTTONS.BACK';
      this.primaryButton.buttonClassName = 'btn-page-secondary';
      this.cancelButton.text = 'connections.CONNECTION_FORM.BUTTONS.FINISH';
      this.cancelButton.buttonClassName = 'btn-page-primary';
      this.secondaryButton.isHidden = true;
      this.sidebarComponent.message = '';
    }
  }

  /**
   * Tests the connection
   */
  async secondaryButtonClicked() {
    this.sidebarComponent.isProcessingRequest = true;
    const connection = this.connectionFormComponent.getConnection(true);
    const runtimeServerName = connection.accessFromServer;

    if (connection.password) {
      connection.password = await this.getEncryptedPassword(runtimeServerName.name, connection.password);
    }

    const containerPasswordParamater = connection.parameters.find(
      (parameter) => parameter.key === 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD'
    );
    if (containerPasswordParamater && containerPasswordParamater.value) {
      containerPasswordParamater.value = await this.getEncryptedPassword(runtimeServerName.name, containerPasswordParamater.value);
    }

    this.connectionsService
      .verify(connection)
      .pipe(first())
      .subscribe({
        next: (response) => {
          const success = {
            message: 'connections.CONNECTION_FORM.MESSAGES.TEST_SUCCESSFUL'
          };
          this.sidebarComponent.parseHttpClientResponseMessage('success', success);
          this.connectionFormComponent.updateTestValues(response);
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  /**
   * Cancels the form and closes the sidebar component
   */
  cancelConnectionButtonClicked(): void {
    if (this.activeStepIndex === 1) {
      if (!this.isStartCatalogButtonClicked) {
        this.finishButtonClickCount++;
        if (this.finishButtonClickCount === 2) {
          this.finishButtonClickCount = 0;
          this.closeSidebarAndResetForm();
        }
      } else {
        this.closeSidebarAndResetForm();
      }
    } else {
      this.closeSidebarAndResetForm();
    }
  }

  closeSidebarAndResetForm(): void {
    this.isVisible = false;
    this.connectionId = '';
    this.isVisibleChanged.emit(false);
    this.connectionId = null;
    this.isStartCatalogButtonClicked = false;

    this.primaryButton.buttonClassName = '';
    this.cancelButton.text = 'connections.CONNECTION_FORM.BUTTONS.CANCEL';
    this.cancelButton.buttonClassName = '';

    if (this.connectionFormComponent) {
      this.connectionFormComponent.connectionFormGroup.get('connectionType').enable();
      this.connectionFormComponent.childComponentReference.destroy();
      this.connectionFormComponent.connectionFormGroup.reset();
    }

    this.changeDetectorRef.markForCheck();
  }

  /**
   * Event handler for the sidebar close event
   * @param $event updates the state of the sidebar component, whether it is
   */
  updateVisibility($event: boolean): void {
    this.isVisibleChanged.emit($event);
  }

  /**
   * Configures the connection form and setup listener for changes
   */
  private configureForm() {
    this.connectionFormComponent.setupFormAndChildComponent();
    this.subscriptions.push(
      this.connectionFormComponent.connectionFormGroup.valueChanges.subscribe(() => {
        this.updateButtonDisabledState();
        if (this.featureFlagService.isFeatureEnabled('CDCKafkaSchemaRegistryTemp20220628')) {
          this.updateSchemaRegistryTestButtonState();
        }
      })
    );
  }

  /**
   * Sets the connection form values based on the connection id
   */
  private setConnection(id: string): void {
    this.sidebarComponent.isProcessingRequest = true;
    this.connectionsService
      .get(id)
      .pipe(first())
      .subscribe({
        next: (response: Connection) => {
          this.connectionFormComponent.connection = response;
        },
        error: (errorResponse) => {
          this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }

  /**
   * Checks if the test username and password has been entered into a form
   * @returns true if test user and test password have been entered, false if not
   */
  private hasTestUserCredentials(): boolean {
    const testUserIDControl = this.connectionFormComponent.connectionFormGroup.get('connectionDetails.testUser');
    const testUserPasswordControl = this.connectionFormComponent.connectionFormGroup.get('connectionDetails.testPassword');

    if (testUserIDControl && testUserPasswordControl) {
      const connection = this.connectionFormComponent.getConnection(true);
      const isEditting = this.connectionFormComponent.connectionFormGroup.get('id').value;

      if (!isEditting || connection.connectionType !== 'DB2ZOS') {
        return testUserIDControl.value !== '' || testUserPasswordControl.value !== '';
      } else {
        return testUserIDControl.value !== '';
      }
    }

    return true;
  }

  /**
   * Updates the disabled state of the primary and secondary buttons
   * The connection form group also validates the child component values
   * Has reference to child form via the nested connection-detail form group
   */
  private updateButtonDisabledState(): void {
    /** Need to add a timeout here to avoid Expression ___ has changed after it was checked error  */
    setTimeout(() => {
      if (this.connectionFormComponent) {
        this.primaryButton.isDisabled = !this.connectionFormComponent.connectionFormGroup.valid;
        this.secondaryButton.isDisabled = !this.connectionFormComponent.connectionFormGroup.valid || !this.hasTestUserCredentials();
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  /**
   * Set test button state only if chosen connection type is schema registry
   * Schema registry form's test button enabled only if connection form's name & connectionType controls are valid,
   * and 'schema regsitry url' field is valid
   * Ensures save button stays disabled until entire connection form is valid.
   */
  private updateSchemaRegistryTestButtonState() {
    setTimeout(() => {
      if (this.connectionFormComponent) {
        if (this.connectionFormComponent.connectionFormGroup.value.connectionType === 'SCHEMAREGISTRY') {
          const { name, connectionType, connectionDetails } = this.connectionFormComponent.connectionFormGroup.controls;
          this.secondaryButton.isDisabled =
            name.valid && connectionType.valid && connectionDetails.get('schemaRegistryUrl').valid ? false : true;
        }
      }
      this.changeDetectorRef.markForCheck();
    });
  }

  handleManageCatalogError(errorResponse): void {
    this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse);
  }
}
