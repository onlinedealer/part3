(function() {
    'use strict';

    fileuploader.controller("templateTableCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$location', '$route', '$window', '$timeout', '$http', '$uibModal', 'ngTableParams', templateTableCtrl]);

    function templateTableCtrl($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $location, $route, $window, $timeout, $http, $uibModal, ngTableParams) {

        $scope.fileuploadPopUp = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: uiRouters.directivesHtmlPath + '/filePopUp.html',
                controller: 'ModalInstanceController',
            });
        };
        $scope.openViewHtml = function(data){
            $location.url(uiRouters.viewTemplate);
            $rootScope.globalTemplateD = data;
        };

        $scope.fetchDataTable = function() {
            //var url = "/ocr/rest/v1/service/get/all/documentqueuedetails";
           var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/template.json', 'GET', {});
           //var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
            promise.then(function(d) {
                $scope.data = d;
                var temp1 = $scope.data;
                console.log(temp1.templateName)
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
        };
        $scope.fetchDataTable();


        // model Instance controller for popup upload function
    fileuploader.controller('ModalInstanceController', ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$uibModalInstance', '$route', '$location', '$window', '$timeout', '$http', ModalInstanceController]);

    function ModalInstanceController($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $uibModalInstance, $route, $location, $window, $timeout, $http) {

        $scope.errorShow = false;
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.uploadFile = function() {
            if ($scope.myFile) {
                var file = $scope.myFile;
                var filename = file.name;
                var valid = /(\.jpg|\.jpeg|\.png|\.pdf|\.PDF|\.PNG|\.TIFF|\.tiff|\.JPEG|\.JPG)$/i;
                if (!valid.exec(filename)) {
                    alert("upload valid file, like .pdf, .png, .tiff, .jpg")
                } else {
                    indicatorStart("Loading....");
                    console.log(file)
                    console.log(filename)
                    var uploadUrl = '/ocr/rest/v1/service/upload/pdf/file/';
                    var fd = new FormData();
                    fd.append('file', file);
                    $http.post(uploadUrl, fd, {
                            transformRequest: angular.identity,
                            headers: {
                                'Content-Type': undefined
                            }
                        })
                        .success(function(d) {
                            $scope.uploadResponse = d;
                            indicatorStop();
                            
                            $location.url(uiRouters.createTemplate);
                        })
                        .error(function(data, status, headers, config) {

                        });                   
                }

            } else {
                alert("First Select the file and click upload")
            }
        };
    }

    }

})();
