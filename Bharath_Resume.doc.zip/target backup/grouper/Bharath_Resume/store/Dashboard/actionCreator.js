import {
  CLEAR_ITEM_THEMES,
  ADD_GROUP_SUCCESS,
  CLEAR_GROUP_ACTION_TYPES,
  DELETE_GROUP_SUCCESS,
  CLEAR_ERROR_TCINS,
  DELETE_GROUP_MULTIPLE_SUCCESS,
  GET_COLLECTION_ITEM_TYPES_SUCCESS,
  GET_COLLECTION_MTAS_SUCCESS,
  GET_VARIATION_ITEM_TYPES_SUCCESS,
  GET_GROUPER_LIST_SUCCESS,
  GET_GROUP_TYPES_SUCCESS,
  GET_FIXED_THEMES_SUCCESS,
  SET_ERROR_TCINS,
  SET_VARIATION_PAGE1_DATA,
  CLEAR_VARIATION_PAGE1_DATA,
  GET_ITEM_TYPES_SUCCESS,
  GET_ITEM_THEMES_SUCCESS,
  UPDATE_GROUP_LIST_REQUEST_PARAMS,
  GET_STATUS_LIST_SUCCESS,
  ITEM_TYPE_OF_FIRST_TCIN,
} from './actionType'
import { GET_GROUP_DETAILS_SUCCESS } from '../GroupDetails/actionType'
import { LOADING_BTN_STATUS, TOGGLE_SNACKBAR } from '../Snackbar/actionType'

import config from '../../config/apiConfig'
import {
  postService,
  getService,
  deleteService,
} from './../../services/grouper'

const sendGroupListPayload = {
  group_id: 0,
  pagination_filter: {
    page: 0,
    order: 'id',
    limit: 20,
    direction: 'ASC',
    is_count_needed: true,
  },
}

// get Maintenance Types while loading the page
export function getGrouperList (sendData) {
  // return { payload: {memberOf, userId}, type: GET_GROUPER_LIST }
  return dispatch => {
    return postService(sendData, config.grouper.getGrouperListPagination)
      .then(resp => {
        dispatch({ type: GET_GROUPER_LIST_SUCCESS, data: resp })
      })
      .catch((error) => {
        const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
        dispatch({ snackMessage: errorData, type: TOGGLE_SNACKBAR })
      })
  }
}

export function grouperListAPI (payload) {
  const sendData = {
    'end_time': null,
    'group_id': 0,
    'group_name': null,
    'group_type': 'variation',
    'start_time': null,
  }
  return postService(sendData, config.grouper.getGrouperList, payload.memberOf, payload.userId)
    .then(resp => {
      return resp
    })
    .catch((error) => {
      throw error
    })
}

export function getGrouperTypes (memberOf, userId) {
  return dispatch => {
    return getService(config.grouper.getGrouperTypes, memberOf, userId)
      .then(resp => {
        dispatch({ type: GET_GROUP_TYPES_SUCCESS, payload: resp })
      })
      .catch((error) => {
        const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
        dispatch({ snackMessage: errorData, type: TOGGLE_SNACKBAR })
      })
  }
}

export function getGrouperTypesAPI (payload) {
  return getService(config.grouper.getGrouperTypes, payload.memberOf, payload.userId)
    .then(resp => {
      return resp
    })
    .catch((error) => {
      throw error
    })
  // return { data: {}, type: GET_GROUP_TYPES }
}

export function getItemTypes (searchText) {
  return dispatch => {
    return getService(`${config.grouper.getItemTypes}?item_type_name=${searchText}`)
      .then(resp => {
        dispatch({ type: GET_ITEM_TYPES_SUCCESS, payload: resp })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
      })
  }
}

/* export function getItemTypesAPI (payload) {
  return getService(`${config.grouper.getItemTypes}?item_type_name=${payload.searchText}`)
    .then(resp => {
      return resp
    })
    .catch((error) => {
      throw error
    })
  // return { data: {}, type: GET_GROUP_TYPES }
} */

export function clearItemThemes () {
  return {
    type: CLEAR_ITEM_THEMES,
  }
}

export function getItemThemes (id) {
  return dispatch => {
    return getService(`${config.grouper.getThemes}?item_type_id=${id}`)
      .then(resp => {
        dispatch({ type: GET_ITEM_THEMES_SUCCESS, payload: resp })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
      })
  }
}

/* export function getItemThemesAPI (payload) {
  return getService(`${config.grouper.getThemes}?item_type_id=${payload.id}`)
    .then(resp => {
      return resp
    })
    .catch((error) => {
      throw error
    })
  // return { data: {}, type: GET_GROUP_TYPES }
} */

export function addGroup (data, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName: 'Create Group' }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    if (data.group_type === 'variation' && data.first_page_variation_request) {
      return postService(data, config.grouper.group, memberOf, userId)
        .then(resp => {
          dispatch({ type: GET_GROUP_DETAILS_SUCCESS, data: resp })
          dispatch({ type: SET_VARIATION_PAGE1_DATA, payload: data })
          btnPayload = { status: false, btnName: '' }
          dispatch({ type: LOADING_BTN_STATUS, btnPayload })
        })
        .catch((error) => {
          if (error && error.response && error.response.data) {
            let dispErrorMsg = ''
            if (error.response.data.message) {
              dispErrorMsg = error.response.data.message
            } else if (error.response.data.validation_error) {
              let validationErr = ''
              let errorTcins = []
              error.response.data.validation_error.map((option) => {
                errorTcins.push(option.tcin)
                validationErr += option.tcin + ' - ' + option.message + '<br />'
              })
              dispatch({ type: SET_ERROR_TCINS, errorTcins: errorTcins })
              dispErrorMsg = validationErr
            } else {
              dispErrorMsg = 'Issue while create the group, please try again.'
            }
            if (dispErrorMsg) {
              const errorData = { status: true, variant: 'error', message: dispErrorMsg, autoHide: false }
              dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
            }
            btnPayload = { status: false, btnName: '' }
            dispatch({ type: LOADING_BTN_STATUS, btnPayload })
          }
        })
    } else {
      return postService(data, config.grouper.group, memberOf, userId)
        .then(resp => {
          let sendPayload = {
            memberOf: resp.memberOf,
            userId: resp.userId,
            recentAddedGroupID: resp.group_id,
            recentAddedInfo: resp,
          }
          if (data.group_type === 'variation' || (data.group_type === 'collection' && !data.first_page_collection_request)) {
            dispatch({ type: ADD_GROUP_SUCCESS, payload: sendPayload })
            dispatch({ type: CLEAR_VARIATION_PAGE1_DATA })
            const addMessage = { status: true, variant: 'success', message: 'Group Created Successfully.', autoHide: true }
            dispatch({ type: TOGGLE_SNACKBAR, snackMessage: addMessage })
            dispatch(getGrouperList(sendGroupListPayload))
          } else {
            dispatch({ type: ADD_GROUP_SUCCESS, payload: sendPayload })
          }
          btnPayload = { status: false, btnName: '' }
          dispatch({ type: LOADING_BTN_STATUS, btnPayload })
        })
        .catch((error) => {
          if (error && error.response && error.response.data) {
            let dispErrorMsg = ''
            if (error.response.data.message) {
              dispErrorMsg = error.response.data.message
            } else if (error.response.data.validation_error) {
              let validationErr = ''
              let errorTcins = []
              error.response.data.validation_error.map((option) => {
                errorTcins.push(option.tcin)
                validationErr += option.tcin + ' - ' + option.message + '<br />'
              })
              dispatch({ type: SET_ERROR_TCINS, errorTcins: errorTcins })
              dispErrorMsg = validationErr
            } else {
              dispErrorMsg = 'Issue while create the group, please try again.'
            }
            if (dispErrorMsg) {
              const errorData = { status: true, variant: 'error', message: dispErrorMsg, autoHide: false }
              dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
            }
            btnPayload = { status: false, btnName: '' }
            dispatch({ type: LOADING_BTN_STATUS, btnPayload })
          }
        })
    }
  }
}

export function addGroupAPI (payload) {
  return postService(payload.data, config.grouper.group, payload.memberOf, payload.userId)
    .then(resp => {
      return resp
    })
    .catch((error) => {
      throw error
    })
}

export function deleteGroup (data, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName: 'Delete Group' }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return deleteService(data, config.grouper.group, memberOf, userId)
      .then(resp => {
        dispatch({ type: DELETE_GROUP_SUCCESS, payload: resp })
        const successData = { status: true, variant: 'success', message: 'Group deleted successfully', autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: successData })
        dispatch(getGrouperList(sendGroupListPayload))
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
          btnPayload = { status: false, btnName: '' }
          dispatch({ type: LOADING_BTN_STATUS, btnPayload })
        }
      })
  }
}

export function deleteGroupMultiple (data, memberOf, userId) {
  return dispatch => {
    let btnPayload = { status: true, btnName: 'Delete Group' }
    dispatch({ type: LOADING_BTN_STATUS, btnPayload })
    return postService(data, config.grouper.deleteMultiple, memberOf, userId)
      .then(resp => {
        dispatch({ type: DELETE_GROUP_MULTIPLE_SUCCESS, payload: resp })
        const successData = { status: true, variant: 'success', message: 'Groups deleted successfully', autoHide: true }
        dispatch({ type: TOGGLE_SNACKBAR, snackMessage: successData })
        dispatch(getGrouperList(sendGroupListPayload))
        btnPayload = { status: false, btnName: '' }
        dispatch({ type: LOADING_BTN_STATUS, btnPayload })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
          btnPayload = { status: false, btnName: '' }
          dispatch({ type: LOADING_BTN_STATUS, btnPayload })
        }
      })
  }
}

export function deleteGroupMultipleAPI (payload) {
  return postService(payload.data, config.grouper.deleteMultiple, payload.memberOf, payload.userId)
    .then(resp => {
      return resp
    })
    .catch((error) => {
      throw error
    })
}

export function closeSnackBar () {
  return {
    type: TOGGLE_SNACKBAR,
    snackMessage: {status: false, variant: 'info', message: ''},
  }
}

export function clearActionTypes () {
  return {
    type: CLEAR_GROUP_ACTION_TYPES,
  }
}

export function clearErrorTcins () {
  return {
    type: CLEAR_ERROR_TCINS,
  }
}

export function getCollectionItemTypes () {
  return dispatch => {
    return getService(`${config.grouper.getCollectionItemTypes}`)
      .then(resp => {
        dispatch({ type: GET_COLLECTION_ITEM_TYPES_SUCCESS, payload: resp })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
      })
  }
}

export function getCollectionMtas (id) {
  return dispatch => {
    return getService(`${config.grouper.getCollectionMtas}?item_type_id=${id}`)
      .then(resp => {
        dispatch({ type: GET_COLLECTION_MTAS_SUCCESS, payload: resp })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
      })
  }
}

export function getVariationItemTypes () {
  return dispatch => {
    return getService(`${config.grouper.getVariationItemTypes}`)
      .then(resp => {
        dispatch({ type: GET_VARIATION_ITEM_TYPES_SUCCESS, payload: resp })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
      })
  }
}

export function getFixedThemes () {
  return dispatch => {
    return getService(`${config.grouper.getFixedThemes}`)
      .then(resp => {
        dispatch({ type: GET_FIXED_THEMES_SUCCESS, payload: resp })
      })
      .catch((error) => {
        if (error && error.response && error.response.data) {
          const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
          dispatch({ type: TOGGLE_SNACKBAR, snackMessage: errorData })
        }
      })
  }
}

export function setVariationPage1Data (payload) {
  return {
    type: SET_VARIATION_PAGE1_DATA,
    payload,
  }
}

export function updateGroupListRequestParams (payload) {
  return {
    type: UPDATE_GROUP_LIST_REQUEST_PARAMS,
    payload,
  }
}

export function getStatusList () {
  const statusMockData = ['INITIATED', 'READY_FOR_ORDER', 'READY_FOR_LAUNCH', 'DELETED']
  return {
    type: GET_STATUS_LIST_SUCCESS,
    payload: statusMockData,
  }

  /* return dispatch => {
    return getService(config.grouper.getStatusList)
      .then(resp => {
        dispatch({ type: GET_STATUS_LIST_SUCCESS, payload: resp })
      })
      .catch((error) => {
        const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
        dispatch({ snackMessage: errorData, type: TOGGLE_SNACKBAR })
      })
  } */
}

// get item type if TCIN type/add while creating variation
export function VariationItemTypeOfFirstTcin (sendData) {
  return dispatch => {
    return postService(sendData, config.grouper.itemTypeOfFirstTcin)
      .then(resp => {
        dispatch({ type: ITEM_TYPE_OF_FIRST_TCIN, resp })
      })
      .catch((error) => {
        const errorData = { status: true, variant: 'error', message: error.response.data.message, autoHide: false }
        dispatch({ snackMessage: errorData, type: TOGGLE_SNACKBAR })
      })
  }
}
