// import { StickyScrollDirective } from './sticky-scroll.directive';

// describe('StickyScrollDirective', () => {
//   it('should create an instance', () => {
//     const directive = new StickyScrollDirective();
//     expect(directive).toBeTruthy();
//   });
// });
