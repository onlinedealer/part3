import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../../connections/shared/connection';
import { Metabase } from '../../../shared/metabase.model';

export enum ORACLE_METABASE_PARAMETERS {
  REPLICATION_USER_ID = 'REPLICATION_USER_ID',
  REPLICATION_USER_PASSWORD = 'REPLICATION_USER_PASSWORD',
  TABLESPACE_NAME = 'TABLESPACE_NAME',
  TABLESPACE_FILE = 'TABLESPACE_FILE',
  TABLESPACE_SIZE = 'TABLESPACE_SIZE',
  TEMP_TABLESPACE_NAME = 'TEMP_TABLESPACE_NAME',
  TEMP_TABLESPACE_FILE = 'TEMP_TABLESPACE_FILE',
  TEMP_TABLESPACE_SIZE = 'TEMP_TABLESPACE_SIZE'
}

/**
 * Partial form for creating metabases for Oracle data connections
 */
@Component({
  selector: 'p-connect-oracle-metabase-form',
  templateUrl: './oracle-metabase-form.component.html'
})
export class OracleMetabaseFormComponent implements OnInit, OnDestroy {
  oracleMetabaseForm: FormGroup;

  /**
   * Data connection that applies to this form
   */
  @Input() dataConnection: Connection;

  constructor(private readonly controlContainer: ControlContainer) {}

  ngOnInit() {
    this.configureForm();
    if (this.dataConnection) {
      this.oracleMetabaseForm.get('databaseServer').setValue(`${this.dataConnection.database}:${this.dataConnection.port}`);
    }
  }

  ngOnDestroy() {
    this.removeForm();
  }

  /**
   * Removes form and any form specific translations or validation
   */
  private removeForm(): void {
    if (this.oracleMetabaseForm) {
      this.oracleMetabaseForm.clearValidators();
      this.oracleMetabaseForm.updateValueAndValidity();

      Object.keys(this.oracleMetabaseForm.controls).forEach((key) => {
        if (key !== 'dataConnection') {
          this.oracleMetabaseForm.removeControl(key);
        }
      });
    }
  }

  get metabase(): Metabase {
    return {
      name: this.oracleMetabaseForm.get('metabaseName').value.toUpperCase(),
      adminUserId: this.oracleMetabaseForm.get('userID').value,
      adminUserPassword: this.oracleMetabaseForm.get('password').value,
      dataConnection: {
        id: (this.oracleMetabaseForm.get('dataConnection').value as Connection).id,
        accessFromServer: (this.oracleMetabaseForm.get('dataConnection').value as Connection).accessFromServer
      },
      parameters: [
        {
          key: ORACLE_METABASE_PARAMETERS.REPLICATION_USER_ID,
          value: this.oracleMetabaseForm.get('replicationUserID').value
        },
        {
          key: ORACLE_METABASE_PARAMETERS.REPLICATION_USER_PASSWORD,
          value: this.oracleMetabaseForm.get('replicationPassword').value
        },
        {
          key: ORACLE_METABASE_PARAMETERS.TABLESPACE_NAME,
          value: this.oracleMetabaseForm.get('tablespaceName').value
        },
        {
          key: ORACLE_METABASE_PARAMETERS.TABLESPACE_FILE,
          value: this.oracleMetabaseForm.get('dataFile').value
        },
        {
          key: ORACLE_METABASE_PARAMETERS.TABLESPACE_SIZE,
          value: this.oracleMetabaseForm.get('dataFileSize').value
        },
        {
          key: ORACLE_METABASE_PARAMETERS.TEMP_TABLESPACE_NAME,
          value: this.oracleMetabaseForm.get('temporaryTablespaceName').value
        },
        {
          key: ORACLE_METABASE_PARAMETERS.TEMP_TABLESPACE_FILE,
          value: this.oracleMetabaseForm.get('temporaryDataFile').value
        },
        {
          key: ORACLE_METABASE_PARAMETERS.TEMP_TABLESPACE_SIZE,
          value: this.oracleMetabaseForm.get('temporaryDataFileSize').value
        }
      ]
    } as Metabase;
  }

  /**
   * setup the form for the Oracle metabase
   */
  private configureForm(): void {
    this.oracleMetabaseForm = this.controlContainer.control as FormGroup;
    this.oracleMetabaseForm.addControl('databaseServer', new FormControl({ value: '', disabled: true }));
    this.oracleMetabaseForm.addControl('userID', new FormControl('SYS', Validators.required));
    this.oracleMetabaseForm.addControl('password', new FormControl('', Validators.required));
    this.oracleMetabaseForm.addControl('replicationUserID', new FormControl('', Validators.required));
    this.oracleMetabaseForm.addControl('replicationPassword', new FormControl('', Validators.required));
    this.oracleMetabaseForm.addControl('metabaseName', new FormControl({ value: '', disabled: true }));
    this.oracleMetabaseForm.addControl('tablespaceName', new FormControl('', Validators.required));
    this.oracleMetabaseForm.addControl('dataFile', new FormControl('', Validators.required));
    this.oracleMetabaseForm.addControl('dataFileSize', new FormControl(200, Validators.required));
    this.oracleMetabaseForm.addControl('temporaryTablespaceName', new FormControl('', Validators.required));
    this.oracleMetabaseForm.addControl('temporaryDataFile', new FormControl('', Validators.required));
    this.oracleMetabaseForm.addControl('temporaryDataFileSize', new FormControl(200, Validators.required));
  }

  /**
   * keyup event handler for the replication user id
   * @param event keyboard event data
   */
  replicationUserIDKeyupEvent(event: KeyboardEvent) {
    const replicationUserId = (event.target as HTMLInputElement).value;

    this.oracleMetabaseForm.patchValue({
      metabaseName: replicationUserId,
      tablespaceName: `REP1_${replicationUserId}`,
      dataFile: `REP1_${replicationUserId}.dat`,
      temporaryTablespaceName: `TEMPREP1_${replicationUserId}`,
      temporaryDataFile: `TEMPREP1_${replicationUserId}.dat`
    });
  }

  tablespaceNameKeyupEvent(event: KeyboardEvent) {
    const tablespaceName = (event.target as HTMLInputElement).value;
    this.oracleMetabaseForm.patchValue({ dataFile: `${tablespaceName}.dat` });
  }

  temporaryTablespaceNameKeyupEvent(event: KeyboardEvent) {
    const temporaryTablespaceName = (event.target as HTMLInputElement).value;
    this.oracleMetabaseForm.patchValue({ temporaryDataFile: `${temporaryTablespaceName}.dat` });
  }
}
