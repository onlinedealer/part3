import { Component, Input } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { Connection } from 'src/app/connections/shared/connection';
import { CATALOG_STATUS } from '../../../shared/catalog-status';

/**
 * Form used to delete a catalog.
 */
@Component({
  selector: 'p-connect-delete-catalog-form',
  templateUrl: './delete-catalog-form.component.html'
})
export class DeleteCatalogFormComponent {
  /**
   * Is the catalog in progress?
   */
  @Input() isInProgress: boolean = false;

  /**
   * List of schemas to be deleted
   */
  @Input() schemas = [];

  /**
   * The connection type for the selected schemas
   */
  @Input() connection: Connection;

  /**
   * catalog status of connection
   */
  @Input() catalogStatus: { params: { partialNumber: number; totalNumber: number; structureType: string } };

  constructor(private readonly translocoService: TranslocoService) {}

  get itemTypeSelected(): string {
    const transationRoot = 'connections.DELETE_CATALOG.SELECTED_OBJECTS';
    let itemTypeSelected = `${transationRoot}.SCHEMAS`;
    if (this.connection && this.connection.connectionType === 'DB2I') {
      itemTypeSelected = `${transationRoot}.LIBRARIES`;
    }
    if (this.connection && this.connection.connectionType === 'KAFKA') {
      itemTypeSelected = this.catalogStatus?.params.totalNumber !== 1 ? `${transationRoot}.TOPICS` : `${transationRoot}.TOPIC`;
    }
    return this.translocoService.translate(itemTypeSelected);
  }

  get schemasOrLibrariesToBeRemoved(): number {
    return this.schemas.filter((selectedSchema) => selectedSchema.status === CATALOG_STATUS.COMPLETE.toUpperCase()).length || 0;
  }
}
