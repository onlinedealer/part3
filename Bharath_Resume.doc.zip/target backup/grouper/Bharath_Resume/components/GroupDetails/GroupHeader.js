import React from 'react'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import EditIcon from '@material-ui/icons/Edit'
import GroupNameDialog from './GroupNameDialog'
import GroupThemesDialog from './GroupThemesDialog'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { getFormatedDate, getStatusStyle, getStatusFormat } from '../common/Utils/CommonUtils'
// import LoadingHOC from '../common/HOC/LoadingHOC'
import GrouperDrawer from '../common/GrouperDrawer/GrouperDrawer'
import UpdateCollectionGroup from './UpdateCollectionGroup'
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft'
import GrouperExpand from '../common/GrouperExpand/GrouperExpand'
import MTAsList from './MTAsList'
import AddToPhotos from '@material-ui/icons/AddToPhotos'
import AddItem from './AddItem'
import NoImage from '../../images/no-image.png'
import GroupLaunchDateDialog from './GroupLaunchDateDialog'
import Switch from '@material-ui/core/Switch'
import GrouperDialog from '../common/GrouperDialog/GrouperDialog'
import GroupEndDateDialog from './GroupEndDateDialog'
import { getGrouperTypes, getItemTypes, getCollectionItemTypes, getCollectionMtas, getItemThemes, clearItemThemes } from '../../store/Dashboard/actionCreator'

const styles = theme => ({
  header: {
    padding: '24px',
  },
  detailsBox: {
    borderRight: '1px solid #ccc',
    paddingLeft: 10,
  },
  lastRow: {
    paddingLeft: 10,
  },
  boxContainer: {
    fontSize: 10,
    paddingLeft: 5,
  },
  gridPadding: {
    padding: 5,
  },
  createGroupButtonStyle: {
    background: '#1976d2',
    color: '#fff',
    fontWeight: 300,
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
  },
  groupAddIcon: {
    color: '#1976d2',
    background: '#fff',
    width: '0.7em',
    height: '0.7em',
    marginRight: 7,
    borderRadius: 2,
  },
  headerTitle: {
    fontWeight: 500,
    fontSize: 24,
    margin: '0px 0px 10px 16px',
    display: 'inline-block',
    verticalAlign: 'middle',
  },
  editGroupButton: {
    border: '1px solid #1976d2',
    color: '#1976d2',
    fontWeight: 400,
    marginTop: '10px',
    float: 'right',
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
  },
  editIcon: {
    width: '12px',
    height: '12px',
    color: '#1976d2',
    marginRight: 2,
  },
  headerInfoBlock: {
    fontSize: 12,
    margin: '8px 16px 8px',
  },
  headerInfoRow: {
    padding: 2,
  },
  headerInfoAttr: {
    fontWeight: 500,
  },
  headerInfoPadding: {
    paddingLeft: 10,
  },
  groupStateRFL: {
    maxWidth: 150,
    backgroundColor: '#85D2ED',
    padding: 6,
    fontSize: 13,
    textAlign: 'center',
    color: '#333',
    marginTop: 2,
  },
  groupStateRFO: {
    maxWidth: 150,
    backgroundColor: '#FFF7C0',
    padding: 6,
    fontSize: 13,
    textAlign: 'center',
    color: '#333',
    marginTop: 2,
  },
  groupStateIn: {
    maxWidth: 150,
    backgroundColor: '#FCBE86',
    padding: 6,
    fontSize: 13,
    textAlign: 'center',
    color: '#333',
    marginTop: 2,
  },
  groupStateHis: {
    maxWidth: 150,
    backgroundColor: '#C0BEC1',
    padding: 6,
    fontSize: 13,
    textAlign: 'center',
    color: '#333',
    marginTop: 2,
  },
  gridContainer: {
    padding: '5px 0px',
    backgroundColor: '#f4f4f4',
  },
  mtaLink: {
    cursor: 'pointer',
    color: '#1976d2',
  },
  expandBox: {
    marginTop: 35,
    paddingLeft: 18,
  },
  expContentWidth: {
    width: '100%',
  },
  addItemsButtonStyle: {
    border: '1px solid #1976d2',
    color: '#1976d2',
    fontWeight: 300,
    padding: '0px 10px',
    fontSize: 12,
    '&:hover': {
      background: '#125ca5',
      color: '#fff',
    },
  },
  addIcon: {
    fontSize: 16,
    paddingRight: 5,
  },
  variationText: {
    fontSize: 11,
    color: '#999',
    fontStyle: 'italic',
  },
  varEditIcon: {
    width: 12,
    color: '#1976d2',
    height: 12,
    marginRight: 2,
  },
  varEditThemeTitle: {
    color: '#1976d2',
    fontSize: 12,
    cursor: 'pointer',
  },
  titleEdit: {
    display: 'inline',
    fontSize: 13,
    color: '#1976d2',
    cursor: 'pointer',
  },
  titleEditIcon: {
    width: 12,
    color: '#1976d2',
    height: 12,
    marginLeft: 16,
    marginRight: 2,
  },
  boxPosition: {
    position: 'relative',
    // paddingLeft: 8,
  },
  primaryImgStyle: {
    /* width: '100%',
    height: '150px',
    */
  },
  arrowStyle: {
    marginTop: 2,
    color: '#1976d2',
  },
  mtaEditLink: {
    display: 'inline',
    fontSize: 12,
    color: '#1976d2',
    cursor: 'pointer',
    marginLeft: 16,
  },
  primaryImgBlock: {
    position: 'relative',
    maxWidth: 150,
    height: 150,
    textAlign: 'center',
  },
  primaryImgText: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    height: 22,
    zIndex: 999,
    opacity: 0.6,
    width: '100%',
    backgroundColor: '#9B9B9B',
    textAlign: 'center',
    color: '#000',
    fontSize: 16,
    fontStyle: 'Roboto Bold',
  },
  dbLink: {
    cursor: 'pointer',
    textAlign: 'center',
  },
  editThemeValue: {
    marginTop: 20,
  },
  launchDateEditLink: {
    fontSize: 10,
    marginLeft: -20,
    cursor: 'pointer',
    display: 'inline',
    color: '#1976d2',
  },
  launchDateEditIcon: {
    width: 9,
    color: '#1976d2',
    height: 9,
    marginRight: 2,
  },
  publishText: {
    fontSize: 12,
    display: 'inline-block',
  },
  publishBlock: {
    width: 112,
    marginLeft: -20,
    textAlign: 'center',
  },
  itemTypeEditLink: {
    fontSize: 10,
    marginLeft: -20,
    cursor: 'pointer',
    display: 'inline',
    color: '#1976d2',
    float: 'right',
  },
  itemTypeEditIcon: {
    width: 9,
    color: '#1976d2',
    height: 9,
    marginRight: 2,
  },
})
class GroupHeader extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      drawerOpenStatus: false,
      drawerContent: '',
      isOpen: false,
      isOpenCollectionDrawer: false,
      isOpenThemesDialog: false,
      isOpenLaunchDateDialog: false,
      isOpenEndDateDialog: false,
      isOpenCollectionDrawerWithItemType: false,
      isItemType: false,
      collectionPublishStatus: props.groupDetails.is_merchant_approved_for_publishing,
      collectionPublishDialogOpenStatus: false,
      collectionPublishTitle: '',
      collectionPublishMessage: '',
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.requestType) {
      this.props.clearActionTypes()
      this.closeDrawer()
      this.setState({ isOpenCollectionDrawer: false, isOpen: false, isOpenThemesDialog: false, isOpenCollectionDrawerWithItemType: false })
    }
    this.setState({ collectionPublishStatus: nextProps.groupDetails.is_merchant_approved_for_publishing })
  }

  openGroupTitleDialog = () => {
    this.setState({ isOpen: true })
  }

  openCollectionDialog = () => {
    this.setState({ isOpenCollectionDrawer: true })
    this.state.isItemType = false
  }

  openCollectionDialogItemType = () => {
    this.setState({ isOpenCollectionDrawerWithItemType: true })
    this.state.isItemType = true
  }

  openThemesDialog = () => {
    this.props.getItemThemes(this.props.groupDetails.item_type_id)
    this.setState({ isOpenThemesDialog: true })
  }

  closeGroupTitleDialog = () => {
    this.setState({ isOpen: false })
  }

  closeDrawer = () => {
    this.setState({ isOpenCollectionDrawer: false, isOpenCollectionDrawerWithItemType: false })
    this.setState({ isOpen: false, isOpenThemesDialog: false })
    this.setState({ drawerOpenStatus: false, drawerContent: '', isOpenLaunchDateDialog: false, isOpenEndDateDialog: false })
  }

  openDrawer = (event) => {
    this.setState({ drawerOpenStatus: true })
  }

  navToDashboard = () => {
    // this.props.history.push("/")
    window.location.href = '/'
  }

  editThemeValues = () => {
    this.props.editThemeValuesCB()
  }

  openLaunchDateDialog = () => {
    this.setState({ isOpenLaunchDateDialog: true })
  }

  openEndDateDialog = () => {
    this.setState({ isOpenEndDateDialog: true })
  }

  changeCollectionPublishStatus = () => {
    const dispMessage = this.state.collectionPublishStatus ? 'unpublish' : 'publish'
    this.setState({
      collectionPublishDialogOpenStatus: true,
      collectionPublishTitle: 'Change Group Publish Status',
      collectionPublishMessage: 'Are you sure to change status to ' + dispMessage,
    })
  }
  confirmPublishChange = (status) => {
    if (status) {
      const sendMessage = this.state.collectionPublishStatus ? 'unpublish' : 'publish'
      this.props.changeCollectionPublishStatusCB(sendMessage)
    }
    this.setState({
      collectionPublishDialogOpenStatus: false,
      collectionPublishTitle: '',
      collectionPublishMessage: '',
    })
  }

  render () {
    const { classes, groupDetails, itemThemes, updateGroupName, auth, loadingBtnStatus, collectionMTAs, editThemeValueStatus } = this.props
    const HeaderInfo = (props) => {
      return (
        <Grid item xs={12} className={classes.headerInfoRow}>
          <Grid container>
            <Grid item xs={5} className={classes.headerInfoAttr}>
              {props.attr}
            </Grid>
            <Grid item xs={7}>
              {props.value}
            </Grid>
          </Grid>
        </Grid>
      )
    }

    const itemsLength = groupDetails.items ? groupDetails.items.length : 0
    // const PrimaryImage = 'https://target.scene7.com/is/image/Target/GUEST_1607ded2-6070-4224-ba75-1572eae3d53e?wid=150&hei=150&qlt=60&fmt=pjpeg'
    let PrimaryImage = NoImage
    if ((groupDetails.image_base_url && groupDetails.image_base_url !== null) && (groupDetails.primary_image && groupDetails.primary_image !== null)) {
      PrimaryImage = 'https:' + groupDetails.image_base_url + groupDetails.primary_image + '?wid=150&hei=150&qlt=60&fmt=pjpeg'
    }
    const editValueBtnText = editThemeValueStatus ? 'RESET THEME VALUES' : 'EDIT THEME VALUES'
    const collectonPublishText = this.state.collectionPublishStatus ? 'Unpublish' : 'Publish'

    let editLinkLoader = <Grid className={classes.mtaEditLink} >Loading MTAs...</Grid>
    if (Object.keys(collectionMTAs).length > 0) {
      editLinkLoader = <Grid className={classes.mtaEditLink} onClick={this.openCollectionDialog}><EditIcon className={classes.editIcon} />EDIT</Grid>
    }
    return (
      <div className={classes.header}>
        <Grid container>
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={2}>
                <Grid container>
                  <Grid item xs={3} className={classes.dbLink} onClick={this.navToDashboard}><KeyboardArrowLeft className={classes.arrowStyle} /></Grid>
                  <Grid item xs={9} className={classes[getStatusStyle(groupDetails.group_state)]}>
                    {getStatusFormat(groupDetails.group_state)}
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={9}>
                <h2 className={classes.headerTitle}><span dangerouslySetInnerHTML={{ __html: groupDetails.group_name }} /></h2>
                <Grid className={classes.titleEdit} onClick={this.openGroupTitleDialog}><EditIcon className={classes.titleEditIcon} />EDIT</Grid>
              </Grid>
              <Grid item xs={1}>
                <Button color="primary" variant="outlined" className={classes.addItemsButtonStyle} onClick={this.openDrawer}>
                  <AddToPhotos className={classes.addIcon} /> ADD ITEMS
                </Button>
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={2}>
                <Grid container>
                  <Grid item xs={3} />
                  <Grid item xs={9} className={classes.primaryImgBlock}>
                    <span className={classes.primaryImgText}>Primary Image</span>
                    <img src={PrimaryImage} alt="primary" className={classes.primaryImgStyle} />
                  </Grid>
                </Grid>
              </Grid>
              <Grid item xs={10} className={classes.boxPosition}>
                <Grid container>
                  <Grid item xs={12}>
                    <Grid container className={classes.boxContainer}>
                      <Grid item xs={2} className={classes.detailsBox}>
                        <HeaderInfo attr="GroupId" value={groupDetails.group_id} />
                        <HeaderInfo attr="Parent TCIN" value={groupDetails.parent_tcin} />
                      </Grid>
                      <Grid item xs={2} className={classes.detailsBox}>
                        <HeaderInfo attr="Group Type" value={groupDetails.group_type} />
                        <HeaderInfo attr="# of Items" value={itemsLength} />
                      </Grid>
                      <Grid item xs={2} className={classes.detailsBox}>
                        <HeaderInfo attr="Dept" value={groupDetails.department_id} />
                        <HeaderInfo attr="Item Type" value={groupDetails.item_type} />
                        {(groupDetails.group_type === 'collection') && Object.keys(collectionMTAs).length > 0 &&
                          <Grid item xs={12} className={classes.itemTypeEditLink} onClick={this.openCollectionDialogItemType} >
                            <EditIcon className={classes.itemTypeEditIcon} />EDIT
                          </Grid>
                        }
                      </Grid>
                      <Grid item xs={2} className={classes.detailsBox}>
                        <HeaderInfo attr="Last Modified" value={getFormatedDate(groupDetails.last_updated_dt)} />
                        <HeaderInfo attr="Created Date" value={getFormatedDate(groupDetails.created_dt)} />
                      </Grid>
                      <Grid item xs={3} className={classes.lastRow}>
                        <Grid container>
                          <Grid item xs={7}>
                            <HeaderInfo attr="Launch Date" value={getFormatedDate(groupDetails.launch_date)} />
                          </Grid>
                          {(groupDetails.group_type === 'collection') &&
                            <Grid item xs={2} className={classes.launchDateEditLink} onClick={this.openLaunchDateDialog} >
                              <EditIcon className={classes.launchDateEditIcon} />EDIT
                            </Grid>
                          }
                          {(groupDetails.group_type === 'collection') &&
                            <Grid item xs={7}>
                              <HeaderInfo attr="End Date" value={getFormatedDate(groupDetails.collection_end_date)} />
                            </Grid>
                          }
                          {(groupDetails.group_type === 'collection') && (groupDetails.launch_date !== '') &&
                            <Grid item xs={2} className={classes.launchDateEditLink} onClick={this.openEndDateDialog} >
                              <EditIcon className={classes.launchDateEditIcon} />EDIT
                            </Grid>
                          }
                        </Grid>
                      </Grid>
                      <Grid item xs={1} />
                    </Grid>
                  </Grid>
                  <Grid container>
                    <Grid item xs={11} className={classes.expandBox}>
                      {groupDetails.group_type === 'collection' &&
                        <GrouperExpand
                          expandTitle="MTAs"
                          expandLinkIcon={editLinkLoader}
                          expandContent={<MTAsList groupDetails={groupDetails} collectionMTAs={collectionMTAs} className={classes.expContentWidth} />}
                        />
                      }
                      {groupDetails.group_type === 'variation' &&
                        <Grid container>
                          <Grid item xs={12}>
                            <Grid container>
                              <Grid item xs={12} className={classes.varEditThemeTitle} onClick={this.openThemesDialog}><EditIcon className={classes.varEditIcon} />EDIT THEMES</Grid>
                              <Grid item xs={12} className={classes.variationText}>Changing the theme order and sort order displays to the guest.</Grid>
                            </Grid>
                          </Grid>
                          {groupDetails.group_id &&
                            <Grid item xs={12} className={classes.editThemeValue}>
                              <Grid container>
                                <Grid item xs={12} className={classes.varEditThemeTitle} onClick={this.editThemeValues}><EditIcon className={classes.varEditIcon} />{editValueBtnText}</Grid>
                                <Grid item xs={12} className={classes.variationText}>Edit theme values.</Grid>
                              </Grid>
                            </Grid>
                          }
                        </Grid>
                      }
                    </Grid>
                    <Grid item xs={1}>
                      {groupDetails.group_type === 'collection' &&
                        <div className={classes.publishBlock}>
                          <Switch color="primary" checked={this.state.collectionPublishStatus} onChange={this.changeCollectionPublishStatus} />
                          <span className={classes.publishText}>Change to {collectonPublishText}</span>
                        </div>
                      }
                    </Grid>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        {/* isOpen && <GroupNameDialog
              auth={auth}
              isOpen={isOpen}
              updateGroupName={updateGroupName}
              groupDetails={groupDetails}
              itemThemes={itemThemes}
              handleClose={this.closeGroupTitleDialog}
            /> */}
        <GrouperDrawer
          drawerPosition="right"
          drawerContent={<GroupNameDialog closeDrawer={this.closeDrawer} groupDetails={groupDetails} updateGroupName={updateGroupName} auth={auth} itemThemes={itemThemes} loadingBtnStatus={loadingBtnStatus} updateVariationGroupName={this.props.updateVariationGroupName} />
          }
          openStatus={this.state.isOpen}
          closeCallback={this.closeDrawer}
        />
        <GrouperDrawer
          drawerPosition="right"
          drawerContent={<GroupThemesDialog closeDrawer={this.closeDrawer} groupDetails={groupDetails} updateGroupName={updateGroupName} auth={auth} itemThemes={itemThemes} loadingBtnStatus={loadingBtnStatus} fixedThemes={this.props.fixedThemes} variationPage1Data={this.props.variationPage1Data} updateVariationDetails={this.props.updateVariationDetails} setGroupDetails={this.props.setGroupDetails} editThemeValues={this.props.editThemeValuesCB} themeUpdatedFlagCB={this.props.themeUpdatedFlagCB} />
          }
          openStatus={this.state.isOpenThemesDialog}
          closeCallback={this.closeDrawer}
        />
        <GrouperDrawer
          drawerPosition="right"
          drawerContent={<UpdateCollectionGroup isItemType={this.isItemType} closeDrawer={this.closeDrawer} groupDetails={groupDetails} collectionMTAs={this.props.collectionMTAs} auth={auth} updateGroupName={updateGroupName} loadingBtnStatus={loadingBtnStatus} />
          }
          openStatus={this.state.isOpenCollectionDrawer}
          closeCallback={this.closeDrawer}
        />

        <GrouperDrawer
          drawerPosition="right"
          drawerContent={<AddItem closeDrawer={this.closeDrawer} groupDetails={groupDetails} loadingBtnStatus={loadingBtnStatus} variationPage1Data={this.props.variationPage1Data} updateVariationDetails={this.props.updateVariationDetails} />}
          openStatus={this.state.drawerOpenStatus}
          closeCallback={this.closeDrawer}
        />
        <GrouperDrawer
          drawerPosition="right"
          drawerContent={<GroupLaunchDateDialog closeDrawer={this.closeDrawer} groupDetails={groupDetails} updateGroupName={updateGroupName} auth={auth} itemThemes={itemThemes} loadingBtnStatus={loadingBtnStatus} updateVariationGroupName={this.props.updateVariationGroupName} />
          }
          openStatus={this.state.isOpenLaunchDateDialog}
          closeCallback={this.closeDrawer}
        />
        <GrouperDrawer
          drawerPosition="right"
          drawerContent={<GroupEndDateDialog closeDrawer={this.closeDrawer} groupDetails={groupDetails} updateGroupName={updateGroupName} auth={auth} itemThemes={itemThemes} loadingBtnStatus={loadingBtnStatus} updateVariationGroupName={this.props.updateVariationGroupName} />
          }
          openStatus={this.state.isOpenEndDateDialog}
          closeCallback={this.closeDrawer}
        />
        <GrouperDialog
          openStatus={this.state.collectionPublishDialogOpenStatus}
          deleteConfirmCallback={this.confirmPublishChange}
          title={this.state.collectionPublishTitle}
          message={this.state.collectionPublishMessage}
          disAgreeText="No"
          agreeText="Yes"
        />

        <GrouperDrawer
          drawerPosition="right"
          drawerContent={<UpdateCollectionGroup
            isItemType={this.state.isItemType}
            collectionItemTypes={this.props.collectionItemTypes} closeDrawer={this.closeDrawer} groupDetails={groupDetails} collectionMTAs={this.props.collectionMTAs} auth={auth} updateGroupName={updateGroupName} loadingBtnStatus={loadingBtnStatus} />
          }
          openStatus={this.state.isOpenCollectionDrawerWithItemType}
          closeCallback={this.closeDrawer}
        />
      </div>
    )
  }
} const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getGrouperTypes,
    getItemTypes,
    getCollectionItemTypes,
    getCollectionMtas,
    getItemThemes,
    clearItemThemes,
  }, dispatch)

const mapStateToProps = state => ({
  itemTypes: state.getIn(['grouperDashboard', 'itemTypes']).toJS(),
  itemThemes: state.getIn(['grouperDashboard', 'itemThemes']).toJS(),
  requestType: state.getIn(['grouperDashboard', 'requestType']),
  collectionItemTypes: state.getIn(['grouperDashboard', 'collectionItemTypes']).toJS(),
  recentAddedGroup: state.getIn(['grouperDashboard', 'recentAddedGroup']),
  errorTcins: state.getIn(['grouperDashboard', 'errorTcins']).toJS(),
  variationItemTypes: state.getIn(['grouperDashboard', 'variationItemTypes']).toJS(),
  fixedThemes: state.getIn(['grouperDashboard', 'fixedThemes']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(GroupHeader))

//  export default withStyles(styles)(GroupHeader)
