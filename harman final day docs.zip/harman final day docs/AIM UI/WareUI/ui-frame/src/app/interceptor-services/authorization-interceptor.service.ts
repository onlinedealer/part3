import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent } from "@angular/common/http";
import { Observable, interval, from } from "rxjs";
import { Store } from "@ngrx/store";
import { take, mergeMap } from "rxjs/operators";
import { SecurityState } from "../store/reducers/security.reducer";
import { getTokenAndUserLanguageCode } from "../store/selectors/security.selectors";
import { InterceptorFilterService } from "./interceptor-filter.service";

@Injectable()
export class AuthorizationInterceptorService implements HttpInterceptor {
    constructor(private store: Store<SecurityState>, private filterService: InterceptorFilterService) {}

    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        if (this.filterService.isRequestFiltered(req)) {
            return next.handle(req);
        }
        return from(this.getTokenAndDelayWhileNoToken(5, req)).pipe(
            mergeMap(token => {
                if (token.error) {
                    console.error(token.error);
                    throw token.error;
                }
                const newHeaders = req.headers.set("Authorization", `Bearer ${token.token}`);
                const newRequest = req.clone({ headers: newHeaders });
                return next.handle(newRequest);
            })
        );
    }

    private getTokenAndDelayWhileNoToken(maxSecondsToWait: number, req: HttpRequest<any>): Promise<{ error?: string; token?: string }> {
        return new Promise<{ error?: string; token?: string }>(async (resolve, reject) => {
            const retryInterval = 100;
            const maxRetryCount = (maxSecondsToWait * 1000) / retryInterval;
            let retryCount = 0;
            let token: any;
            const delayOperation = interval(retryInterval).pipe(take(1));
            // console.log("Starting promise ", req.url);
            while (retryCount < maxRetryCount) {
                token = await this.store
                    .select(getTokenAndUserLanguageCode)
                    .pipe(take(1))
                    .toPromise();
                if (token && token.token) {
                    break;
                }
                await delayOperation.toPromise();
                // onsole.log("Waiting url " + req.url);
                retryCount++;
            }
            if (!token || !token.token) {
                console.error("No token retrieved in seconds " + maxSecondsToWait + ". Retry count was " + retryCount);
                reject({ error: "No token retrieved in seconds " + maxSecondsToWait, token: "" });
                return;
            }
            // console.log("RES", retryCount, req.url);
            resolve({ token: token.token });
        });
    }
}
