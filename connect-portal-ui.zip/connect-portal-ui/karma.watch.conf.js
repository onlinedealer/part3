// import settings from default config file
var properties = null;
var originalConfigFn = require('./karma.conf.js');
originalConfigFn({
  set: function (arg) {
    properties = arg;
  }
});

// override settings from karma.conf.js:
properties.singleRun = false;
properties.autoWatch = true;
properties.usePolling = true;
properties.customLaunchers = {
  ChromeDebugging: {
    base: 'Chrome',
    flags: ['--remote-debugging-port=9222']
  }
};
properties.browsers = ['ChromeDebugging'];
properties.restartOnFileChange = true;

// export settings
module.exports = function (config) {
  config.set(properties);
};
