import { Component, Input, ChangeDetectionStrategy, Output, EventEmitter } from "@angular/core";

@Component({
    selector: "landisgyr-prepayment-date-selector",
    templateUrl: "./prepayment-date-selector.component.html",
    styleUrls: ["./prepayment-date-selector.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrepaymentDateSelectorComponent {
    @Input() prepaymentInfoExpanded = false;

    @Input() selectedView!: string;

    @Output() setActiveView = new EventEmitter<string>();

    onActiveViewSelection(view: string) {
        this.setActiveView.emit(view);
    }
}
