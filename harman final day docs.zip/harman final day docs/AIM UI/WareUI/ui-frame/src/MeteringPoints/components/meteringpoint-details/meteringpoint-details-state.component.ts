import { Component, Input, Output, EventEmitter } from "@angular/core";
import { MeterConnection } from "../../models/meterconnection.model";
import { TranslationsService } from "../../../app/services/translations-service";

@Component({
    selector: "landisgyr-meteringpoint-details-state",
    templateUrl: "./meteringpoint-details-state.component.html",
    styleUrls: ["./meteringpoint-details-state.component.scss"]
})
export class MeteringPointDetailsStateComponent {
    constructor(public translations: TranslationsService) {}

    @Input()
    activeStateName!: string | undefined;
    @Input()
    currentStatesCount!: number;

    @Input()
    lastReadingDate = 0;

    @Input()
    meterConnection!: MeterConnection;

    @Input()
    missingDataStatus!: boolean;

    @Output()
    statesDetailsClick: EventEmitter<any> = new EventEmitter();

    @Input()
    loading!: boolean;

    weekdayNames = [
        $localize`:|@@meteringpointDetails.sunday:Sun`,
        $localize`:|@@meteringpointDetails.monday:Mon`,
        $localize`:|@@meteringpointDetails.tuesday:Tue`,
        $localize`:|@@meteringpointDetails.wednesday:Wed`,
        $localize`:|@@meteringpointDetails.thursday:Thu`,
        $localize`:|@@meteringpointDetails.friday:Fri`,
        $localize`:|@@meteringpointDetails.saturday:Sat`
    ];
    missingDataIcon = false;
    noMeteringConnectionIcon = false;
    goodIcon = false;
    stateDetails = $localize`:|@@meteringpointDetailsState.stateDetails:State details`;

    onStateDetailsClick() {
        this.statesDetailsClick.emit();
    }
}
