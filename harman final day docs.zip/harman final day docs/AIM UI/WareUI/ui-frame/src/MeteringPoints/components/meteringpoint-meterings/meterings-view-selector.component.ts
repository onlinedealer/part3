import { Component, Output, EventEmitter, Input } from "@angular/core";

@Component({
    selector: "landisgyr-meterings-view-selector",
    templateUrl: "./meterings-view-selector.component.html",
    styleUrls: ["./meterings-view-selector.component.scss"]
})
export class MeteringsViewSelectorComponent {
    @Input()
    selectedView!: string;

    @Input()
    meteringType!: string;

    @Input()
    forAllViews!: boolean;

    @Input()
    isProfileDataEdited!: boolean;

    @Output()
    viewSelection = new EventEmitter<string>();

    tooltipTableView = $localize`:|Tooltip text for table view -tooltip@@dateSelector.tableview-tooltip:Table view`;

    tooltipChartView = $localize`:|Tooltip text for chart view -tooltip@@dateSelector.chartView-tooltip:Chart view`;

    tooltipSummaryView = $localize`:|Tooltip text for summary view -tooltip@@dateSelector.summaryView-tooltip:Summary view`;
    // For hiding the summary icon as it is not the part of GSS114 release.
    hideSummaryIcon = false;

    constructor() {}
}
