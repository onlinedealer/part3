import { ComponentFixture, fakeAsync, TestBed, tick, waitForAsync } from '@angular/core/testing';
import { Component } from '@angular/core';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { LogReaderConfigurationFormComponent } from './logreader-configuration-form.component';
import { TranslocoService, TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of } from 'rxjs';
import { HttpClientModule } from '@angular/common/http';
import { LogReader } from '../../shared/logreader';
import { LogReadersApiService } from '../../shared/logreaders-api.service';
import { Connection } from 'src/app/connections/shared/connection';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { LogReaderSidebarComponent } from '../logreader-sidebar/logreader-sidebar.component';

@Component({
  selector: 'p-connect-logreader-sidebar',
  template: '',
  providers: [
    {
      provide: LogReaderSidebarComponent,
      useClass: MockLogReaderSidebarComponent
    }
  ]
})
class MockLogReaderSidebarComponent {
  open(selectedLogReader?: LogReader): void {}
}

describe('LogReaderConfigurationFormComponent', () => {
  let component: LogReaderConfigurationFormComponent;
  let fixture: ComponentFixture<LogReaderConfigurationFormComponent>;
  let translocoService: TranslocoService;

  const mockLogReaders = [
    {
      type: 'logReader',
      dataConnectionId: '1',
      journalName: 'SCHEMA/JOURNAL',
      logReaderId: '1',
      name: 'logReader1',
      parameters: {}
    },
    {
      type: 'logReader',
      dataConnectionId: '1',
      journalName: 'SCHEMA/JOURNAL',
      logReaderId: '2',
      name: 'logReader2',
      parameters: {}
    }
  ] as LogReader[];

  const mockPipelines: string[] = ['pipeline1', 'pipeline2'];

  const logReadersApiService = jasmine.createSpyObj<Partial<LogReadersApiService>>('mockLogReadersApiService', [
    'getLogReaders',
    'deleteLogReader',
    'getDataFlows'
  ]);

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [LogReaderConfigurationFormComponent, MockLogReaderSidebarComponent],
      imports: [getTranslocoModule(), HttpClientTestingModule],
      providers: [
        HttpClientModule,
        { provide: TRANSLOCO_SCOPE, useValue: { scope: '' } },
        { provide: LogReadersApiService, useValue: logReadersApiService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(LogReaderConfigurationFormComponent);
    component = fixture.componentInstance;
    translocoService = TestBed.inject(TranslocoService);
    component.sourceDataConnection = {};
    fixture.detectChanges();
    spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of(mockLogReaders));
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should transform translation keys to dropdown options', () => {
    spyOn(translocoService, 'selectTranslateObject').and.returnValue(of([{ key: 'value' }]));
    component.ngOnInit();
    component.dropdownItems$.subscribe((b: any) => {
      expect(b[0].label.key).toBe('value');
    });
  });

  // skipping this for now, it's causing other tests to fail
  xit('should populate logReadersList when getAllLogReaders is called', waitForAsync(() => {
    spyOn(logReadersApiService, 'getLogReaders').and.returnValue(of(mockLogReaders));
    component.getAllLogReaders().then(() => {
      expect(component.logReadersList.length).toBeGreaterThan(0);
    });
  }));

  it('should call getAllLogReaders if All Log Readers is selected', fakeAsync(() => {
    spyOn(component, 'getAllLogReaders');
    const selectedLogReaderAuto = { id: 'All Log Readers', value: 'LOG_READERS' };
    component.dropdownItemChanged(selectedLogReaderAuto);
    tick();
    expect(component.getAllLogReaders).toHaveBeenCalled();
  }));

  it('should set logReadersList length to 0 when closing', () => {
    component.close();
    expect(component.logReadersList.length).toBe(0);
  });

  it('should set only two fields if connection type is DB2UDB', () => {
    const newSourceDataConnection = {
      id: '2',
      name: 'NewDB2iConnection',
      connectionType: 'DB2UDB',
      accessMethod: 'JDBC'
    } as Connection;
    component.sourceDataConnection = newSourceDataConnection;
    component.ngOnInit();
    expect(component.fields.length).toBe(3);
  });

  // it('should enable button if connection type is DB2UDB', () => {
  //   const newSourceDataConnection = {
  //     id: '2',
  //     name: 'NewDB2iConnection',
  //     connectionType: 'DB2UDB',
  //     accessMethod: 'JDBC'
  //   } as Connection;
  //   const logReadersList = [{ name: 'someName', journalName: 'someJournalName', actions: 'someAction' }];
  //   component.logReadersList = logReadersList;
  //   component.sourceDataConnection = newSourceDataConnection;
  //   const result = component.checkButtonDisabled();
  //   expect(result).toBe(true);
  // });

  it('should disable dropdown if opened with Autogenerate option', fakeAsync(() => {
    spyOn(component, 'getAllLogReaders').and.returnValue(Promise.resolve());
    component.open(null);
    tick();
    expect(component.dropdownDisabled).toBe(true);
  }));

  it('should set default value of dropdown to All Log Readers if opened with Autogenerate option', fakeAsync(() => {
    spyOn(component, 'dropdownItemChanged');
    const Auto = 'LOG_READERS';
    component.open(null);
    tick();
    expect(component.dropdownItemChanged).toHaveBeenCalledWith({ value: Auto });
  }));

  it('should open edit log reader form when edit is selected', () => {
    spyOn(component, 'logReaderFormOpen').and.callThrough();
    const logReader = mockLogReaders[0];
    component.actionDropdownMenuItems[0].command({ item: { target: logReader } });
    expect(component.logReaderFormOpen).toHaveBeenCalledOnceWith(logReader);
  });

  it('should open delete dialog when delete is selected', () => {
    const logReader = mockLogReaders[0];
    component.actionDropdownMenuItems[1].command({ item: { target: logReader } });
    expect(component.deleteSidebarConfiguration.isSidebarVisible).toBe(true);
  });

  // it('should open delete dialog when delete is selected', waitForAsync(() => {
  //   spyOn(logReadersApiService, 'deleteLogReader').and.returnValue(of([]));
  //   spyOn(component.deleteCompleted, 'next').and.returnValue();
  //   spyOn(component, 'getAllLogReaders').and.returnValue(Promise.resolve());
  //   component.deleteDialogConfiguration.deleteButtonClicked(mockLogReaders);
  //   expect(logReadersApiService.deleteLogReader).toHaveBeenCalled();
  //   expect(component.deleteCompleted.next).toHaveBeenCalled();
  // }));

  // it('should handle a delete log reader error', () => {
  //   const errorResponse = { error: { detailedMessage: 'deleteLogReader failed' } };
  //   spyOn(logReadersApiService, 'deleteLogReader').and.returnValue(throwError(errorResponse));
  //   spyOn(component.deleteCompleted, 'next').and.returnValue();
  //   component.deleteDialogConfiguration.deleteButtonClicked(mockLogReaders);
  //   expect(logReadersApiService.deleteLogReader).toHaveBeenCalled();
  //   expect(component.deleteCompleted.next).toHaveBeenCalledWith(errorResponse);
  // });

  it('should only display log readers for current pipeline', fakeAsync(() => {
    component.logReadersList = [{ name: 'logReaderName' }, { name: 'otherLogreaderName' }];
    component.currentPipelineProperties = [{ key: 'IBMI_LOG_READER_NAME', value: 'logReaderName' }];
    component.dropdownItemChanged({ value: 'CURRENT_PIPELINE' });
    expect(component.logReadersList.length).toBe(1);
  }));
});
