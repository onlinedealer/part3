import { ChangeDetectorRef, Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges, ViewChild } from '@angular/core';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogStatus } from 'src/app/connections/catalogs/shared/catalog-status';
import { Connection } from 'src/app/connections/shared/connection';
import { Pipeline } from '../../shared/pipeline';
import { ChangeTableMappingSidebarComponent } from '../change-mapping/change-table-mapping/change-table-mapping-sidebar/change-table-mapping-sidebar.component';
import { CreateTopicsSubjectsErrorsSidebarComponent } from '../create-topic-subjects/create-topics-subjects-errors-sidebar/create-topics-subjects-errors-sidebar.component';
import { PipelineMappingService } from '../pipeline-mapping.service';
import { ResetToDefaultSidebarComponent } from '../reset-to-default/sidebar/reset-to-default-sidebar.component';
import { EventApiService } from '../shared/event-api.service';

@Component({
  selector: 'p-connect-mapping-overview',
  templateUrl: './mapping-overview.component.html'
})
export class MappingOverviewComponent implements OnInit, OnChanges {
  @Output() resetSideViewClicked = new EventEmitter<any>();

  @Output() getAllSelectedSourceData = new EventEmitter<any>();
  @Output() getErrors = new EventEmitter<any>();

  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(ChangeTableMappingSidebarComponent) changeMappingSidebar: ChangeTableMappingSidebarComponent;

  /**
   * Reference to the Reset to Default Sidebar Component
   */
  @ViewChild(ResetToDefaultSidebarComponent) resetToDefaultSidebar: ResetToDefaultSidebarComponent;

  /**
   * Reference to the Create topic subjects error Sidebar Component
   */
  @ViewChild(CreateTopicsSubjectsErrorsSidebarComponent) createTopicSubjectsErrorsSidebar: CreateTopicsSubjectsErrorsSidebarComponent;

  /**
   * Source data connection
   */
  @Input() sourceDataConnection: Connection;

  @Input() enableOverviewButtons;
  /**
   * Target data connection
   */
  @Input() targetDataConnection: Connection;

  /**
   * Schema Registry Connection
   */
  @Input() schemaRegistryConnection: Connection;

  // rows selected from table
  @Input() checkedItems: any[];
  @Input() topics: string[];
  @Input() tableData: string[];
  @Input() pipeline: Pipeline;
  @Input() setTargetDetails: (row, topic) => void;
  @Input() patchPipeline: () => void;
  @Input() setMappingIcon: (row, topic, topicFound) => void;
  @Input() fields: any[];
  @Input() getSubjectDetails: (row) => void;
  @Input() setTopicSubject: (row, subject) => void;
  @Input() isSchemaRegistryThere: boolean;

  // source data connection type friendly name
  connectionTypeFriendlyName: string;

  // target data connection type friendly name
  targetConnectionTypeFriendlyName: string;

  // target connection's catalog status
  targetCatalogStatus$: Observable<CatalogStatus> = null;
  schemaRegistryCatalogStatus$: Observable<CatalogStatus> = null;
  errorMessage = [];
  showErrorbtn: boolean;

  @Output() topicCheckBox = new EventEmitter<boolean>();
  @Output() subjectCheckbox = new EventEmitter<boolean>();
  @Output() refreshButtonTrigger = new EventEmitter();

  constructor(
    private readonly catalogApiService: CatalogApiService,
    private readonly changeDetectorRef: ChangeDetectorRef,
    private readonly eventApiService: EventApiService
  ) {}

  ngOnInit(): void {
    this.connectionTypeFriendlyName = `connections.CONNECTION_TYPES.${this.sourceDataConnection.connectionType}`;
    this.targetConnectionTypeFriendlyName = `connections.CONNECTION_TYPES.${this.targetDataConnection.connectionType}`;
    this.getTopicAndSubjectErrors();
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.targetDataConnection || changes.schemaRegistryConnection) {
      this.targetCatalogStatus$ = this.getTargetCatalogStatus(this.targetDataConnection.id);
      this.schemaRegistryCatalogStatus$ = this.getTargetCatalogStatus(this.schemaRegistryConnection?.id);
    }
  }

  private getTargetCatalogStatus(id: string): Observable<CatalogStatus> | null {
    return this.catalogApiService.status(id, true).pipe(catchError(() => of(null)));
  }

  changeMappingClicked() {
    this.changeMappingSidebar.open();
  }

  resetToDefaultClicked() {
    this.getAllSelectedSourceData.emit();
    setTimeout(() => {
      this.resetToDefaultSidebar.open([this.checkedItems, this.tableData?.length]);
      this.changeDetectorRef.markForCheck();
    });
  }

  resetClicked(event) {
    this.resetSideViewClicked.emit(event);
  }

  // refreshMappingClicked() {
  //   this.refreshButtonTrigger.emit();
  // }

  onChangeTopicCheckBox(event) {
    this.topicCheckBox.emit(event.checked);
  }
  onChangeSubjectCheckBox(event) {
    this.subjectCheckbox.emit(event.checked);
  }

  openErrorMsgSidebar() {
    this.createTopicSubjectsErrorsSidebar?.open();
  }

  getTopicAndSubjectErrors() {
    this.eventApiService.subjectFailureErrors$.subscribe((data) => {
      this.showErrorbtn = true;
      this.errorMessage = data;
    });
  }
}
