import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';
import { CouponHelperService } from '../../services/coupon-helper.service';

@Component({
  selector: 'app-carepass-dollar-reward',
  templateUrl: './carepass-dollar-reward.component.html',
  styleUrls: ['./carepass-dollar-reward.component.scss']
})
export class CarepassDollarRewardComponent implements OnInit {
  @Input() data: any;

  imagesPaths:Object = ImagePaths;

  constructor(public utilityService:UtilityService, public couponHelperService: CouponHelperService) { }

  ngOnInit() {
  }

}
