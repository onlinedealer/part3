import { Component, Input, OnChanges, OnDestroy, SimpleChanges } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { CatalogApiService } from 'src/app/connections/catalogs/shared/catalog-api.service';
import { CatalogStatus, CATALOG_STATUS } from 'src/app/connections/catalogs/shared/catalog-status';
import { Connection, CONNECTION_TYPE } from 'src/app/connections/shared/connection';

@Component({
  selector: 'p-connect-connection-catalog-status',
  templateUrl: './connection-catalog-status.component.html'
})
export class ConnectionCatalogStatusComponent implements OnChanges, OnDestroy {
  isManageCatalogSidebarVisible = false;
  refreshCatalogDataTimeout: NodeJS.Timeout;

  @Input() catalogStatus: CatalogStatus;
  @Input() connectionValue: Connection;

  /**
   * Recieves true or false value. If true, shared component will show total number of datasets.
   * If false, then shared component will show latest cataloged schema date & time.
   */
  @Input() showTotalDatasets: boolean;

  lastCompletedTime: string = '';

  constructor(private readonly catalogApiService: CatalogApiService, public readonly translocoService: TranslocoService) {}

  get totalDatasets() {
    const numOfDatasets: number = this.catalogStatus?.schemas?.reduce((total, tables) => total + tables.tablesCount, 0) || 0;
    return `${numOfDatasets} Datasets`;
  }

  get isConnectionTypeKafkaOrSchmeaRegistry(): boolean {
    return (
      (this.connectionValue && this.connectionValue.connectionType === CONNECTION_TYPE.KAFKA) ||
      this.connectionValue.connectionType === CONNECTION_TYPE.SCHEMAREGISTRY
    );
  }

  get isCatalogComplete(): boolean {
    return this.catalogStatus && this.catalogStatus.status === CATALOG_STATUS.COMPLETE;
  }

  get configureTooltipText(): any {
    const schemaOrTopics: any = this.catalogStatus?.schemas || this.catalogStatus?.topics || this.catalogStatus?.subjects || [];
    const partialNumber = schemaOrTopics.filter((schemaOrTopic) => schemaOrTopic.status === CATALOG_STATUS.COMPLETE).length;
    const totalNumber = schemaOrTopics.length;
    const structureType = this.translocoService.translate(this.getConnectionTypeText()).toLowerCase();
    return { partialNumber, totalNumber, structureType };
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.catalogStatus) {
      this.updateAutoRefreshTimeout();
      if (!this.showTotalDatasets) {
        this.getlatestCatalogDateTime(this.catalogStatus);
      }
    }
  }

  ngOnDestroy(): void {
    clearInterval(this.refreshCatalogDataTimeout);
  }

  public getlatestCatalogDateTime(catalogStatus: CatalogStatus) {
    if (catalogStatus) {
      if (catalogStatus.schemas?.length || catalogStatus.subjects?.length || catalogStatus.topics?.length) {
        const recentCatalogDateTime = (catalogStatus.schemas || catalogStatus.subjects || catalogStatus.topics)
          ?.map((element) => new Date(element.lastCompleted || element.lastUpdated))
          .reduce((acc, currentDate) => (acc > currentDate ? acc : currentDate));
        const [day, month, year] = recentCatalogDateTime.toLocaleDateString().split('/');
        this.lastCompletedTime = `${year}/${month}/${day}`;
      } else {
        this.lastCompletedTime = 'connections.CATALOG_STATUS.NOT_CATALOGED.TEXT';
      }
    }
  }

  /**
   * Updates catalog status of existing source or target connection.
   */
  private getCatalogStatus() {
    this.catalogApiService
      .status(this.connectionValue?.id, false)
      .pipe(catchError(() => of(null)))
      .subscribe((catalogStatus: CatalogStatus) => {
        this.catalogStatus = catalogStatus;
        if (!this.showTotalDatasets) {
          this.getlatestCatalogDateTime(catalogStatus);
        }
      });
  }

  getCatalogStatusIcon(status: string): string[] {
    if (status) {
      switch (status.toUpperCase()) {
        case 'FAILED':
          return ['png-alert-actionrequired-solid', 'text-danger'];
        case 'STOPPED':
          return ['png-alert-partial', 'text-danger'];
        case 'INPROGRESS':
          return ['png-alert-inprogress', 'text-success'];
        case 'COMPLETE':
          return ['png-alert-open', 'text-success'];
        case 'NOT_CATALOGED':
          return ['png-disabled', 'text-muted'];
        default:
          return [];
      }
    }
  }

  public getOverallStatusTooltip(status: string) {
    let isStopped = status.toUpperCase() === 'STOPPED';

    if (isStopped && !this.isConnectionTypeKafkaOrSchmeaRegistry) {
      return `connections.CATALOG_STATUS.STOPPED.STRUCTURE_TOOLTIP`;
    } else if (isStopped && this.isConnectionTypeKafkaOrSchmeaRegistry) {
      return `connections.CATALOG_STATUS.STOPPED.NO_STRUCTURE_TOOLTIP`;
    } else {
      return `connections.CATALOG_STATUS.${status.toUpperCase()}.TOOLTIP`;
    }
  }

  getConnectionTypeText(): string {
    let itemType: string;
    const connectionType = this.connectionValue?.connectionType;
    const schemaOrTopics: any = this.catalogStatus?.schemas || this.catalogStatus?.topics || this.catalogStatus?.subjects || [];

    switch (connectionType) {
      case 'DB2':
      case 'DB2I':
        itemType =
          schemaOrTopics.length !== 1 ? 'connections.CATALOG_STATUS.ITEM_TYPES.LIBRARIES' : 'connections.CATALOG_STATUS.ITEM_TYPES.LIBRARY';
        break;
      case 'SQLSERVER':
        itemType =
          schemaOrTopics.length !== 1
            ? 'connections.CATALOG_STATUS.ITEM_TYPES.DATABASES'
            : 'connections.CATALOG_STATUS.ITEM_TYPES.DATABASE';
        break;
      case 'KAFKA':
        itemType = schemaOrTopics.length !== 1 ? 'connections.CATALOGED.PLURAL.TOPIC' : 'connections.CATALOGED.SINGLE.TOPIC';
        break;
      case 'SCHEMAREGISTRY':
        itemType =
          schemaOrTopics.length !== 1 ? 'connections.CATALOG_STATUS.ITEM_TYPES.SUBJECTS' : 'connections.CATALOG_STATUS.ITEM_TYPES.SUBJECT';
        break;
      case 'ORACLE':
      default:
        itemType =
          schemaOrTopics.length !== 1 ? 'connections.CATALOG_STATUS.ITEM_TYPES.SCHEMAS' : 'connections.CATALOG_STATUS.ITEM_TYPES.SCHEMA';
        break;
    }

    return itemType;
  }

  updateAutoRefreshTimeout(): void {
    if (this.catalogStatus) {
      clearInterval(this.refreshCatalogDataTimeout);

      this.refreshCatalogDataTimeout = setInterval(() => {
        this.getCatalogStatus();
      }, 30000);
    }
  }
}
