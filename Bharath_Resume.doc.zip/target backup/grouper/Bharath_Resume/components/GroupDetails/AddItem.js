import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import GrouperChipInput from '../common/GrouperChipInput/GrouperChipInput'
import * as Constants from '../common/Utils/Constants'
import { addTcins, clearActionTypes, clearAddItemTcinError } from '../../store/GroupDetails/actionCreator'
import { toggleSnackBar } from '../../store/Snackbar/actionCreator'
// import FormHelperText from '@material-ui/core/FormHelperText'
import CircularProgress from '@material-ui/core/CircularProgress'

const styles = theme => ({
  formControl: {
    margin: theme.spacing.unit,
    width: 250,
  },
  container: {
    padding: 10,
  },
  field: {
    marginTop: '24px',
  },
  helperText: {
    marginTop: 8,
  },
  heading: {
    fontSize: 18,
    fontWeight: 500,
  },
  textHead: {
    marginBottom: 16,
  },
  itemCount: {
    float: 'right',
    marginTop: 4,
    fontSize: 14,
  },
  createButtonStyle: {
    position: 'relative',
    color: '#fff',
    float: 'right',
    marginLeft: '8px',
    background: '#1976d2',
    fontWeight: 300,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  displayFlex: {
    display: 'flex',
  },
  chipContainer: {
    maxHeight: '500px',
    overflowY: 'auto',
    marginBottom: 0,
    backgroundColor: '#fff',
  },
})

class AddItem extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      formData: {
        addedTcins: [],
      },
      errors: {
        tcins: '',
      },
      addItemErrorTcins: [],
      tcinExistsStatus: false,
    }
  }

  componentWillMount () {
    this.setState({ addItemErrorTcins: this.props.addItemErrorTcins })
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.requestType) {
      if (nextProps.requestType === 'ADDED_TCINS') {
        this.props.closeDrawer()
        this.props.clearActionTypes()
      }
    }
  }

  handleAddTcin = (tcin) => {
    if (tcin) {
      let tcins = [tcin]
      if (tcin.indexOf(',') !== -1) { // paste with comma
        tcins = tcin.replace(/ /g, '').split(',')
      } else if (tcin.indexOf(' ') !== -1) { // paste columns or columns and rows together
        tcins = tcin.split(' ')
        let newTcins = []
        tcins.map((tc, i) => {
          if (tc) {
            let locTcin = tc.trim()
            if (locTcin.indexOf(String.fromCharCode(9)) !== -1) {
              locTcin = locTcin.split(String.fromCharCode(9))
              newTcins = [ ...newTcins, ...locTcin ]
            } else {
              newTcins.push(locTcin)
            }
          }
        })
        tcins = newTcins
      } else if (tcin.indexOf(String.fromCharCode(9)) !== -1) { // paste rows
        tcins = tcin.split(String.fromCharCode(9))
      }
      const formData = { ...this.state.formData }
      const errors = { ...this.state.errors }
      errors.tcins = ''
      this.setState({ errors })
      let isError = false
      tcins.map((tc, i) => {
        if (tc) {
          if (tc.match(Constants.REGEX_NUMBER)) {
            if (formData.addedTcins.indexOf(tc) === -1) {
              formData.addedTcins.push(tc)
            }
          } else {
            isError = true
          }
        }
      })
      errors.tcins = (isError) ? Constants.INVALID_TCIN_TEXT : ''
      this.setState({ formData, errors })
    }
  }

  handleDeleteTcin = (tcin) => {
    const formData = { ...this.state.formData }
    formData.addedTcins = formData.addedTcins.filter((c) => c !== tcin)
    if (formData.addedTcins.length <= 0) {
      this.props.clearAddItemTcinError()
      this.props.toggleSnackBar({})
    }
    this.setState({ formData })
  }

  addTcinsStatus = () => {
    const formData = { ...this.state.formData }
    const { groupDetails } = this.props
    const errors = { ...this.state.errors }
    let payload = { }
    let isValid = true
    let existingTcins = []
    if (formData.addedTcins.length === 0) {
      errors.tcins = Constants.ERROR_TCIN_REQ
      isValid = false
    } else {
      let tcinData = []
      let groupItemsCount = (groupDetails.items !== undefined) ? groupDetails.items.length : 0
      formData.addedTcins.map((tcin) => {
        const tcinPos = _.findIndex(groupDetails.items, (n) => { return n.tcin.toString() === tcin })
        if (tcinPos !== -1) { // check tcin already part of this group
          existingTcins.push(parseInt(tcin))
          isValid = false
        } else {
          groupItemsCount++
          const actionText = (groupDetails.group_id) ? 'ADDED' : 'CREATED'
          tcinData.push({ tcin, action: actionText, sort_order: groupItemsCount })
        }
      })
      if (existingTcins.length === 0) {
        payload.tcin_data = tcinData
        errors.tcins = ''
      } else {
        errors.tcins = Constants.TCIN_EXISTS
        this.setState({ addItemErrorTcins: existingTcins, tcinExistsStatus: true })
      }
    }
    return {
      isValid,
      payload,
    }
  }

  validateSubmit = () => {
    const { groupDetails, auth } = this.props
    let tcinObj = this.addTcinsStatus()
    let payload = tcinObj.payload
    if (tcinObj.isValid && groupDetails && groupDetails.group_id) {
      payload.description = groupDetails.description
      payload.group_name = groupDetails.group_name
      payload.group_type = groupDetails.group_type
      payload.group_id = groupDetails.group_id
      payload.group_type_id = groupDetails.group_type_id
      payload.status = groupDetails.status
      payload.item_type_id = groupDetails.item_type_id
      payload.item_type = groupDetails.item_type
      payload.themes = groupDetails.themes
      // payload['is_migration_request'] = true
      this.props.addTcins(payload, auth.memberOf, auth.lanId)
    } else {
      // this.setState({ errors })
    }
  }

  addNewItemVariation = () => {
    const { variationPage1Data } = this.props
    let tcinObj = this.addTcinsStatus()
    if (tcinObj.isValid) {
      tcinObj.payload.tcin_data.map((opt) => {
        variationPage1Data.tcin_data.push(opt)
      })
      this.props.updateVariationDetails(variationPage1Data, 'Add Tcin')
    }
  }

  render () {
    const { classes, closeDrawer, loadingBtnStatus, groupDetails } = this.props
    const { formData, tcinExistsStatus } = this.state
    const addBtnDisableStatus = !!((formData.addedTcins.length === 0 || (loadingBtnStatus.status && loadingBtnStatus.btnName === 'Add Tcin')))
    let btnText = groupDetails.group_id ? 'ADD' : 'ADD More'
    let btnClickEvent = groupDetails.group_id ? this.validateSubmit : this.addNewItemVariation
    return (
      <div className={classes.container}>
        <Grid container>
          <Grid item xs={12}>
            <Grid container>
              <Grid item xs={6} className={classes.heading}>
                                  Add items
              </Grid>
              <Grid item xs={6}>
                {formData.addedTcins.length > 0 &&
                  <div className={classes.itemCount}>
                    {formData.addedTcins.length} item(s)
                  </div>
                }
              </Grid>
            </Grid>
          </Grid>
          <Grid item xs={12} className={classes.field + ' ' + classes.displayFlex}>
            <GrouperChipInput
              chipContainerCls={classes.chipContainer}
              placeholder="Paste or Type in TCINs *"
              handleAddTcin={this.handleAddTcin}
              handleDeleteTcin={this.handleDeleteTcin}
              value={formData.addedTcins}
              errors={this.state.addItemErrorTcins}
              tcinExistsStatus={tcinExistsStatus}
              mode="WhileAddNew"
            />

          </Grid>
          <Grid item xs={12} className={classes.field}>
            <Button color="primary" className={classes.createButtonStyle} onClick={btnClickEvent} disabled={addBtnDisableStatus}>
              {(loadingBtnStatus.status && loadingBtnStatus.btnName === 'Add Tcin') &&
              <CircularProgress
                className={classes.progress}
                size={25}
              />
              }
              {btnText}
            </Button>
            <Button color="primary" className={classes.cancelButtonStyle} onClick={closeDrawer} >
                        Cancel
            </Button>

          </Grid>
        </Grid>
      </div>
    )
  }
}

AddItem.propTypes = {
  classes: PropTypes.object.isRequired,
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    addTcins,
    clearActionTypes,
    clearAddItemTcinError,
    toggleSnackBar,
  }, dispatch)

const mapStateToProps = state => ({
  auth: state.get('auth').toJS(),
  requestType: state.getIn(['GroupDetails', 'requestType']),
  addItemErrorTcins: state.getIn(['GroupDetails', 'addItemErrorTcins']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(AddItem))
