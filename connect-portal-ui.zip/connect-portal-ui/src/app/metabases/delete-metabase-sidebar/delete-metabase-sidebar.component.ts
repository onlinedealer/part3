import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { mergeMap } from 'rxjs/operators';
import { ProjectsApiService } from '../../pipelines/pipeline/shared/projects-api.service';
import { Metabase } from '../shared/metabase.model';
import { MetabasesApiService } from '../shared/metabases-api.service';
import { EncryptionService } from '../../shared/services/encryption.service';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { DeleteMetabaseFormComponent } from './delete-metabase-form/delete-metabase-form.component';

@Component({
  selector: 'p-connect-delete-metabase-sidebar',
  templateUrl: './delete-metabase-sidebar.component.html'
})
export class DeleteMetabaseSidebarComponent {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  /**
   * Reference to the DeleteMetabaseFormComponent child component
   */
  @ViewChild(DeleteMetabaseFormComponent) deleteMetabaseFormComponent: DeleteMetabaseFormComponent;

  @Input() metabase: Metabase;

  @Output() metabaseDeletedEvent = new EventEmitter();

  primaryButton: SidebarButton = {
    id: 'metabaseDeleteButton',
    text: 'metabases.DELETE_DIALOG.BUTTONS.DELETE',
    testId: 'deleteMetabaseButton',
    isDisabled: true
  };
  cancelButton: SidebarButton = {
    id: 'metabaseCancelButton',
    text: 'common.BUTTONS.CANCEL',
    testId: 'cancelMetabaseButton'
  };

  get isIBMi(): boolean {
    return this.metabase?.dataConnection.connectionType === 'DB2I';
  }

  constructor(
    private readonly projectsApiService: ProjectsApiService,
    private readonly metabasesApiService: MetabasesApiService,
    private readonly encryptionService: EncryptionService
  ) {}

  cancelButtonClicked(): void {
    this.sidebarComponent.close();
  }

  open(metabase: Metabase): void {
    this.deleteMetabaseFormComponent.open(metabase);
    this.sidebarComponent.open();
  }

  togglePrimaryButtonDisableState(event: boolean): void {
    this.primaryButton.isDisabled = event;
  }

  async deleteButtonClicked() {
    this.sidebarComponent.isProcessingRequest = true;
    const currentMetabase = this.metabase;
    let credentials;

    if (!this.isIBMi) {
      const { adminUserId, password, removeConfigOnly } = this.deleteMetabaseFormComponent?.metabaseCredentialsForm?.controls;
      try {
        const adminPassword = password;
        const encryptedPassword: any = await this.encryptionService.encrypt(
          currentMetabase.dataConnection.accessFromServer.name,
          adminPassword.value
        );
        credentials = {
          userId: adminUserId.value,
          password: encryptedPassword,
          removeConfigOnly: removeConfigOnly.value
        };
      } catch ({ error }: any) {
        this.sidebarComponent.isProcessingRequest = false;
        if (error?.detailedMessage.includes('AgentDownException') || error?.detailedMessage.includes('AgentTimeoutException')) {
          this.sidebarComponent.close();
        }
      }
    }

    this.projectsApiService
      .getDefaultProject()
      .pipe(
        mergeMap((project) => {
          this.metabasesApiService.serviceURL = `projects/${project.id}/metabases`;
          return this.metabasesApiService.deleteMetabase(this.metabase.dataConnection.id, credentials);
        })
      )
      .subscribe({
        next: () => {
          this.sidebarComponent.close();
          this.metabaseDeletedEvent.emit();
        }
      })
      .add(() => {
        this.sidebarComponent.isProcessingRequest = false;
      });
  }
}
