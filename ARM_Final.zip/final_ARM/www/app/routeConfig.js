﻿(function () {
    'use strict';
    angular.module('arm').config(['$stateProvider',
                  '$urlRouterProvider',
             function ($stateProvider, $urlRouterProvider) {

                 $stateProvider.state('home', {
                     url: '/home',
                     templateUrl: 'app/views/home.html',
                     controller: "homeController",
                     data: { pageTitle: 'DashBoard', requireLogin: true }
                 })
                 .state("login", {
                     url: '/login',
                     templateUrl: 'app/views/login.html',
                     controller: "loginController",
                     data: { pageTitle: 'Login', requireLogin: false }
                 })
                 .state("signup", {
                     url: '/signup',
                     templateUrl: 'app/views/registration/signup.html',
                     controller: "signupController",
                     data: { pageTitle: 'Sign Up', requireLogin: false }
                 })
                 .state("reSetPwd", {
                     url: '/reSetPwd',
                     templateUrl: 'app/views/registration/resetPassword.html',
                     controller: "resetPwdController",
                     data: { pageTitle: 'Reset Password', requireLogin: false }
                 })
                 .state("reSetPwdStep2", {
                     url: '/reSetPwdStep2',
                     templateUrl: 'app/views/registration/resetPasswordStep2.html',
                     controller: "resetPwdStep2Controller",
                     data: { pageTitle: 'Reset Password', requireLogin: false }
                 })
                 .state("reSetPwdStep3", {
                     url: '/reSetPwdStep3',
                     templateUrl: 'app/views/registration/resetPasswordStep3.html',
                     controller: "resetPwdStep3Controller",
                     data: { pageTitle: 'Reset Password', requireLogin: false }
                 })
                 .state("favCourses", {
                     url: '/favCourses',
                     templateUrl: 'app/views/find/favouriteCourses.html',
                     controller: "favCoursesController",
                     data: { pageTitle: 'My Favourites', requireLogin: true }
                 })
                 .state("settings", {
                     url: '/setting',
                     templateUrl: 'app/views/settings.html',
                     controller: "settingsController",
                     data: { pageTitle: 'Settings', requireLogin: true }
                 })
                 .state("findCourses", {
                     url: '/findCourses',
                     templateUrl: 'app/views/find/course/filter.html',
                     controller: "coursesController",
                     data: { pageTitle: 'Find Courses', requireLogin: true }
                 })
                 .state("findAgents", {
                     url: '/findAgents',
                     templateUrl: 'app/views/find/agent/filter.html',
                     controller: "agentsController",
                     data: { pageTitle: 'Find Agent', requireLogin: true }
                 })
                 .state("findEvents", {
                     url: '/findEvents',
                     templateUrl: 'app/views/find/event/filter.html',
                     controller: "eventsController",
                     data: { pageTitle: 'Find Event', requireLogin: true }
                 })
                 .state("findInst", {
                     url: '/findInst',
                     templateUrl: 'app/views/find/institute/filter.html',
                     controller: "institutesController",
                     data: { pageTitle: 'Find Institute', requireLogin: true }
                 })
                 .state("findSch", {
                     url: '/findSch',
                     templateUrl: 'app/views/find/scholarship/filter.html',
                     controller: "scholarshipController",
                     data: { pageTitle: 'Find Scholarship', requireLogin: true }
                 })
                 .state("findFrd", {
                     url: '/findFrd',
                     templateUrl: 'app/views/find/friend/filter.html',
                     controller: "friendController",
                     data: { pageTitle: 'Find Friend', requireLogin: true }
                 })
                 .state("search", {
                     url: '/search/:searchType/:preSate',
                     templateUrl: 'app/views/find/search.html',
                     controller: "searchController",
                     data: { pageTitle: 'Search', requireLogin: true }
                 })
                 .state("search.course", {
                     url: '/course',
                     templateUrl: 'app/views/find/course/searchList.html',
                     controller: "courseListController",
                     data: { pageTitle: 'Course Search', requireLogin: true }
                 })
                 .state("search.coursedetail", {
                     url: '/coursedetail/:courseId',
                     templateUrl: 'app/views/find/course/detail.html',
                     controller: "courseDetailController",
                     data: { pageTitle: 'Course Detail', requireLogin: true }
                 })
                 .state("search.agent", {
                     url: '/agent',
                     templateUrl: 'app/views/find/agent/searchList.html',
                     controller: "agentListController",
                     data: { pageTitle: 'Agent Search', requireLogin: true }
                 })
                 .state("search.agentmap", {
                     url: '/agentmap/:mapType?bar',
                     templateUrl: 'app/views/find/map.html',
                     controller: "mapController",
                     data: { pageTitle: 'Map Detail', requireLogin: true }
                 })
                 .state("search.agentdetail", {
                     url: '/agentdetail/:legalId',
                     templateUrl: 'app/views/find/agent/detail.html',
                     controller: "agentDetailController",
                     data: { pageTitle: 'Agent Detail', requireLogin: true }
                 })

                 .state("search.event", {
                     url: '/event',
                     templateUrl: 'app/views/find/event/searchList.html',
                     controller: "eventListController",
                     data: { pageTitle: 'Event Search', requireLogin: true }
                 })
                 .state("search.eventdetail", {
                     url: '/eventdetail/:legalId/:locationId/:eventId',
                     templateUrl: 'app/views/find/event/detail.html',
                     controller: "eventDetailController",
                     data: { pageTitle: 'Event Detail', requireLogin: true }
                 })

                 .state("search.inst", {
                     url: '/inst',
                     templateUrl: 'app/views/find/institute/searchList.html',
                     controller: "institutesListController",
                     data: { pageTitle: 'Institute Search', requireLogin: true }
                 })
                 .state("search.instdetail", {
                     url: '/instdetail/:legalId',
                     templateUrl: 'app/views/find/institute/detail.html',
                     controller: "institutesDetailController",
                     data: { pageTitle: 'Institute Detail', requireLogin: true }
                 })
                 .state("search.scholar", {
                     url: '/scholar',
                     templateUrl: 'app/views/find/scholarship/searchList.html',
                     controller: "scholarshipListController",
                     data: { pageTitle: 'Scholarship Search', requireLogin: true }
                 })
                 .state("search.scholardetail", {
                     url: '/scholardetail/:scholFk',
                     templateUrl: 'app/views/find/scholarship/detail.html',
                     controller: "scholarshipDetailController",
                     data: { pageTitle: 'Scholarship Detail', requireLogin: true }
                 })
                 .state("search.friend", {
                     url: '/friend',
                     templateUrl: 'app/views/find/friend/searchList.html',
                     controller: "friendListController",
                     data: { pageTitle: 'Friend Search', requireLogin: true }
                 })
                 .state("search.frienddetail", {
                     url: '/frienddetail/:friendId',
                     templateUrl: 'app/views/find/friend/detail.html',
                     controller: "friendDetailController",
                     data: { pageTitle: 'Friend Detail', requireLogin: true }
                 })
                .state("search.requestsent", {
                    url: '/requestsent/:clientFk',
                    templateUrl: 'app/views/find/friend/requestSent.html',
                    controller: "requestController",
                    data: { pageTitle: 'Friend Detail', requireLogin: true }
                })
                .state("search.connect", {
                    url: '/connect/:returnFk',
                    templateUrl: 'app/views/find/connect.html',
                    controller: "connectController",
                    data: { pageTitle: 'Connect', requireLogin: true }
                })
                 .state("customers", {
                     url: '/customers',
                     templateUrl: 'app/views/customers.html',
                     controller: "customersController",
                     data: { pageTitle: 'Customer', requireLogin: true }
                 });

                 $urlRouterProvider.otherwise('/login');

             }]);

}());