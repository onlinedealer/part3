import { Component, Input, Output, EventEmitter } from "@angular/core";

@Component({
    selector: "landisgyr-icon-buttons",
    templateUrl: "./icon-buttons.component.html",
    styleUrls: ["./icon-buttons.component.scss"]
})
export class IconButtonsComponent {
    @Input() icons!: { name: string; tooltip: string; disabled?: boolean }[];

    @Input() selected!: string;

    @Input()
    showMeteringDetails!: boolean;

    @Output() buttonClicked: EventEmitter<string> = new EventEmitter();

    onButtonClicked(event: string): void {
        this.buttonClicked.emit(event);
    }
}
