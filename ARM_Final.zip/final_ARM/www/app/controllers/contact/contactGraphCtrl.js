(function() {
    'use strict';
    angular.module('arm').controller('contactGraphCtrl', ['$scope', 'contactNoteService', '$filter', '$state', '$ionicModal', '$ionicSideMenuDelegate', 'utility', 'MASTER_TABLE', 'ALERT_MESSAGE', '$cordovaDialogs', '$rootScope','homeService', contactGraphCtrl]);

    function contactGraphCtrl($scope, contactNoteService, $filter, $state, $ionicModal, $ionicSideMenuDelegate, utility, MASTER_TABLE, ALERT_MESSAGE, $cordovaDialogs, $rootScope,homeService) {

        // Contact Back
        $scope.dropDownShow = false;
        $scope.contactBack = function() {
            $state.go('tab.contact');
        }

        function fetchDashboardData() {
            contactNoteService.contactAdd().then(function(res) {
                console.log(JSON.stringify(res));
                $scope.getData = res;
                //console.log("CHECK THE DATA --->", $scope.getData);
                $scope.bindingValues();
                //console.log($scope.ContactTier3Contacted + "---- " + $scope.ContactTier3Target + "--" + $scope.ContactTier3TargetToDate);
            }, function(err) {
                //console.log('product family error' + err);
            });
        };

        fetchDashboardData();

        $scope.submitFilter = function() {
            var date = $filter('date')(new Date(), 'yyyy-MM-dd');
            console.log($scope.groupGroupID)
            if ($scope.getRowDetails.ID == 3) {
                if ($scope.groupGroupID == undefined) {
                    $cordovaDialogs.alert(ALERT_MESSAGE.GROUP, ALERT_MESSAGE.ALERT_TITLE, 'OK').then(function () { });
                } else {
                    var forOpe;
                    var url = "/" + $rootScope.loggedInUserID + "/" + $scope.groupGroupID + "/" + "3" + "/" + date;
                    contactNoteService.contactGraphFilterAdd(url).then(function(res) {
                        ////console.log("Dashboard Response" + JSON.stringify(res));
                        $scope.getData = res;
                        console.log(JSON.stringify($scope.getData));
                        $scope.closeFilter();
                        $scope.bindingValues();
                    }, function(err) {
                        //console.log('product family error' + err);
                    });
                }
            } else {
                var url = "/" + $rootScope.loggedInUserID + "/" + $scope.getRowDetails.ID + "/" + "null" + "/" + date;
                contactNoteService.contactGraphFilterAdd(url).then(function(res) {
                    ////console.log("Dashboard Response" + JSON.stringify(res));
                    $scope.getData = res;
                    console.log(JSON.stringify($scope.getData));
                    $scope.closeFilter();
                    $scope.bindingValues();
                }, function(err) {
                    //console.log('product family error' + err);
                });
            }
        }

        $scope.bindingValues = function() {

            $scope.ContactAllTotal = $scope.getData.Total;

            $scope.ContactAllDayContacted = formatNumber($scope.getData.Contacted);
            $scope.ContactAllDayTarget = formatNumber($scope.getData.Target);
            $scope.ContactAllDayTargetToDate = formatNumber($scope.getData.TargetToDate);

            $scope.ContactAllDayContactedPercentage = $scope.getData.ContactedPercentage;
            $scope.ContactAllDayTargetPercentage = $scope.getData.TargetPercentage;
            $scope.ContactAllDayTargetToDatePercentage = $scope.getData.TargetToDatePercentage;

            $scope.ContactTier1Total = $scope.getData.Tiers[0].TierTotal;

            $scope.ContactTier1Contacted = formatNumber($scope.getData.Tiers[0].TierContacted);
            $scope.ContactTier1Target = formatNumber($scope.getData.Tiers[0].TierTarget);
            $scope.ContactTier1TargetToDate = formatNumber($scope.getData.Tiers[0].TierTargetToDate);

            $scope.ContactTier1ContactedPercentage = $scope.getData.Tiers[0].TierContactedPercentage;
            $scope.ContactTier1TargetPercentage = $scope.getData.Tiers[0].TierTargetPercentage;
            $scope.ContactTier1TargetToDatePercentage = $scope.getData.Tiers[0].TierTargetToDatePercentage;

            $scope.ContactTier2Total = $scope.getData.Tiers[1].TierTotal;

            $scope.ContactTier2Contacted = formatNumber($scope.getData.Tiers[1].TierContacted);
            $scope.ContactTier2Target = formatNumber($scope.getData.Tiers[1].TierTarget);
            $scope.ContactTier2TargetToDate = formatNumber($scope.getData.Tiers[1].TierTargetToDate);

            $scope.ContactTier2ContactedPercentage = $scope.getData.Tiers[1].TierContactedPercentage;
            $scope.ContactTier2TargetPercentage = $scope.getData.Tiers[1].TierTargetPercentage;
            $scope.ContactTier2TargetToDatePercentage = $scope.getData.Tiers[1].TierTargetToDatePercentage;

            $scope.ContactTier3Total = $scope.getData.Tiers[2].TierTotal;

            $scope.ContactTier3Contacted = formatNumber($scope.getData.Tiers[2].TierContacted);
            $scope.ContactTier3Target = formatNumber($scope.getData.Tiers[2].TierTarget);
            $scope.ContactTier3TargetToDate = formatNumber($scope.getData.Tiers[2].TierTargetToDate);

            $scope.ContactTier3ContactedPercentage = $scope.getData.Tiers[2].TierContactedPercentage;
            $scope.ContactTier3TargetPercentage = $scope.getData.Tiers[2].TierTargetPercentage;
            $scope.ContactTier3TargetToDatePercentage = $scope.getData.Tiers[2].TierTargetToDatePercentage;

            $scope.ContactTier4Total = $scope.getData.Tiers[3].TierTotal;

            $scope.ContactTier4Contacted = formatNumber($scope.getData.Tiers[3].TierContacted);
            $scope.ContactTier4Target = formatNumber($scope.getData.Tiers[3].TierTarget);
            $scope.ContactTier4TargetToDate = formatNumber($scope.getData.Tiers[3].TierTargetToDate);

            $scope.ContactTier4ContactedPercentage = $scope.getData.Tiers[3].TierContactedPercentage;
            $scope.ContactTier4TargetPercentage = $scope.getData.Tiers[3].TierTargetPercentage;
            $scope.ContactTier4TargetToDatePercentage = $scope.getData.Tiers[3].TierTargetToDatePercentage;
        }

        //############### LoggedInAs User  functionality START ##############
        $ionicModal.fromTemplateUrl('app/views/common/loggedInAsUserList.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function(modal) {
            $scope.modalLoginAsUsers = modal;
        });

        $scope.loggedInUsers = [];
        var loggedInUserInfo = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.selfLoggedInID = loggedInUserInfo.UserID;

        $scope.selectedUser = function(index, isSelfUser) {
            utility.selectedLogginAsUser(index, isSelfUser, $scope.modalLoginAsUsers, $scope.loggedInUsers).then(function(res) {
                fetchDashboardData();
                if ($rootScope.isAccessingOtherUserProfile) {
                    homeService.syncServerRecords();
                }
            });
        };

        $scope.openLogInUserMenu = function() {
            $scope.loggedInUsers = [];
            utility.loadLoggodInAsUsers($scope.loggedInUsers);
            $scope.modalLoginAsUsers.show();

        };

        $scope.closeLogInMenu = function() {
            $scope.modalLoginAsUsers.hide();
            $scope.loggedInUsers = [];
        };

        $ionicModal.fromTemplateUrl('app/views/contact/contactGraphFilter.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function(modal) {
            $scope.modalcntfilterGraph = modal;
        });
        $scope.openFilter = function() {
            $scope.modalcntfilterGraph.show();
            //console.log($scope.objFilter.search)
        };
        $scope.closeFilter = function() {
            $scope.modalcntfilterGraph.hide();
        };

        function formatNumber(n) {
            for (var i = 0; i < ranges.length; i++) {
                if (n >= ranges[i].divider) {
                    n = (n / ranges[i].divider);
                    if (parseInt(n) == n) {} else if (parseFloat(n) == n) {
                        n = n.toFixed(1);
                    }
                    n = n.toString() + ranges[i].suffix;
                }
            }
            return n.toString();
        };

        $scope.userGroup = utility.getMultLangMasData(MASTER_TABLE.UserGroup);

        $scope.handleRadioClick = function(getID) {
            $scope.getRowDetails = getID;
            if (getID.ID == 3) {
                $scope.dropDownShow = true;
            } else {
                $scope.dropDownShow = false;
            }
        };

        $scope.groupHandleRadioClick = function(GroupRadio) {

        };

        $scope.groupRadio = function(getUserGroupID) {
            //console.log(getUserGroupID.UserGroupID)
            $scope.groupGroupID = getUserGroupID.UserGroupID;

        };

        $scope.list = [{
            name: 'Self',
            ID: 1
        }, {
            name: 'Team',
            ID: 2
        }, {
            name: 'Group',
            ID: 3
        }];

        var ranges = [{
            divider: 1e6,
            suffix: 'M'
        }, {
            divider: 1e3,
            suffix: 'K'
        }];

        $scope.openDashGraphFilter = function() {
            $scope.modalcntfilterGraph.show();
        };
        //############### LoggedInAs User  functionality END ##############
    };

})();