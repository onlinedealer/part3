import { ValidationMessageTypeModel } from './validation-message-type.model';

export class ValidationMessage {
  heading?: string;
  /**
   *
   */
  message: string;

  /**
   *
   */
  params: Record<string, string>;

  /**
   *
   * @param message
   * @param params
   */
  constructor(message: string, params?: Record<string, string>) {
    this.message = message;
    if (params) {
      this.params = params;
      this.heading = params.heading ? params.heading : '';
    }
  }
}
