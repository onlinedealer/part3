import { Component, Inject } from "@angular/core";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material/dialog";
import { TranslationsService } from "../../../../services/translations-service";

@Component({
    selector: "landisgyr-about-application",
    templateUrl: "./about-application.component.html",
    styleUrls: ["../../styles/component.styles.scss", "../../styles/dialog.styles.scss"]
})
export class AboutApplicationComponent {
    applicationTitle!: string;
    versionNumber!: string;

    constructor(
        public translations: TranslationsService,
        public dialogRef: MatDialogRef<AboutApplicationComponent>,
        @Inject(MAT_DIALOG_DATA) public data: { applicationTitle: string; versionNumber: string }
    ) {}
}
