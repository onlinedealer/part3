import React from 'react'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import TableHead from '@material-ui/core/TableHead'
import TableCell from '@material-ui/core/TableCell'
import TableRow from '@material-ui/core/TableRow'
import Tooltip from '@material-ui/core/Tooltip'
import TableSortLabel from '@material-ui/core/TableSortLabel'
import Checkbox from '@material-ui/core/Checkbox'

const styles = theme => ({
  regRoot: {
    padding: 0,
    textAlign: 'center',
  },
  regRootLeft: {
    padding: 0,
    paddingLeft: 5,
    textAlign: 'left',
  },
  regRootLink: {
    padding: '0px 0px 0px 16px',
    textAlign: 'center',
  },
  regRootdDefault: {
    padding: 0,
    textAlign: 'center',
    '&:last-child': {
      paddingRight: 0,
    },
  },
  lastRoot: {
    paddingRight: 0,
  },
  rootTd: {
    padding: 0,
    textAlign: 'center',
    backgroundColor: '#1976d2',
    color: '#fff',
    '&:hover': {
      color: '#fff',
    },
  },
  rootTdLeft: {
    padding: 0,
    paddingLeft: 5,
    textAlign: 'left',
    backgroundColor: '#1976d2',
    color: '#fff',
    '&:hover': {
      color: '#fff',
    },
  },
  activeTd: {
    color: '#fff !important',
    '&:hover': {
      color: '#fff !important',
    },
  },
  rootLink: {
    color: '#2d81d4b5',
  },
  tableHeadHeight: {
    height: 40,
  },
})

export class ItemsHead extends React.Component {
    createSortHandler = property => event => {
      this.props.onRequestSort(event, property)
    };

    render () {
      const { classes, order, orderBy, numSelected, rowCount, onSelectAllClick } = this.props
      return (
        <TableHead>
          <TableRow className={classes.tableHeadHeight}>
            {this.props.columnData.map(column => {
              const defaultRootStyle = (column.id === 'item_state' || column.id === 'move' || column.id === 'remove' || column.id === 'image') ? classes.regRootdDefault : (column.id === 'product_title') ? classes.regRootLeft : classes.regRootLink
              const defaultRootTDStyle = (column.id === 'product_title') ? classes.rootTdLeft : classes.rootTd
              return (
                <TableCell
                  key={column.id}
                  numeric={column.numeric}
                  // padding={column.disablePadding ? 'none' : 'dense'}
                  sortDirection={orderBy === column.id ? order : false}
                  classes={{ root: orderBy === column.id ? defaultRootTDStyle : defaultRootStyle }}
                >
                  {(column.id === 'created_date' || column.id === 'tcin' || column.id === 'product_title' || column.id === 'launch_date' || column.id === 'relationship_type_code' || column.id === 'item_type') ? (
                    <Tooltip
                      title="Sort"
                      placement={column.numeric ? 'bottom-end' : 'bottom-start'}
                      enterDelay={300}
                    >
                      <TableSortLabel
                        active={orderBy === column.id}
                        direction={order}
                        onClick={this.createSortHandler(column.id)}
                        classes={{ active: classes.activeTd, root: orderBy !== column.id ? classes.rootLink : '' }}
                      >
                        {column.label}
                      </TableSortLabel>
                    </Tooltip>
                  ) : (
                    <span>
                      {column.id === 'remove' &&
                        <Checkbox
                          indeterminate={numSelected > 0 && numSelected < rowCount}
                          checked={numSelected === rowCount}
                          onChange={onSelectAllClick}
                        />
                      }
                      {column.label}
                    </span>
                  )}
                </TableCell>
              )
            }, this)}
          </TableRow>
        </TableHead>
      )
    }
}

ItemsHead.propTypes = {
  onRequestSort: PropTypes.func.isRequired,
  order: PropTypes.string.isRequired,
  orderBy: PropTypes.string.isRequired,
}

export default withStyles(styles)(ItemsHead)
