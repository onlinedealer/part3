import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { EventBusService } from 'core/eventBusService';
import { Helper } from 'discovery-shared';
import { ObserverConstants } from 'observer/observer-constants';
import { ObserverService } from 'observer/observer.service';
import { SliderComponent } from '../slider/slider.component';
import { SliderModel } from '../slider/slider.model';
import { WarningAlertModel } from '../warning-alert.model';
import { DatadriftConfigureModel } from './data-drift-configure.model';
import { DataDriftType } from './data-drift-type.enum';

@Component({
  selector: 'discovery-data-drift-configure',
  templateUrl: './data-drift-configure.component.html',
  styleUrls: ['./data-drift-configure.component.scss']
})
export class DataDriftConfigureComponent implements OnInit {
  @Output() dataDriftSidebarVisible: EventEmitter<boolean> = new EventEmitter<boolean>();
  @ViewChild('slider')
  sliderComponent: SliderComponent;
  @Input() savedConfig;
  alertType = 'confidence';
  confidenceSliderSettings: SliderModel;
  dataThresholds: WarningAlertModel;
  dataDriftModel = new DatadriftConfigureModel();
  customDataDriftModel = new DatadriftConfigureModel();
  validationCheck: ReturnType<typeof setTimeout>;
  numericData = [
    {
      label: 'discoveryObserver.alerts.dataDriftAlert.numericDataOptions.minimum',
      value: DataDriftType.VALUE_MIN
    },
    {
      label: 'discoveryObserver.alerts.dataDriftAlert.numericDataOptions.maximum',
      value: DataDriftType.VALUE_MAX
    },
    {
      label: 'discoveryObserver.alerts.dataDriftAlert.numericDataOptions.mean',
      value: DataDriftType.VALUE_MEAN
    },
    {
      label: 'discoveryObserver.alerts.dataDriftAlert.numericDataOptions.standardDeviation',
      value: DataDriftType.VALUE_STDEV
    }
  ];
  textualData = [
    {
      label: 'discoveryObserver.alerts.dataDriftAlert.textualDataOptions.minimumLength',
      value: DataDriftType.TEXT_LENGTH_MIN
    },
    {
      label: 'discoveryObserver.alerts.dataDriftAlert.textualDataOptions.maximumLength',
      value: DataDriftType.TEXT_LENGTH_MAX
    }
  ];
  detailDrift = [
    {
      label: 'discoveryObserver.alerts.dataDriftAlert.detailDrift.valueCount',
      value: DataDriftType.CARDINALITY_DETAIL
    }
  ];

  constructor(private observerService: ObserverService, private eventBusService: EventBusService) {}

  ngOnInit(): void {
    this.initialize();
  }
  cancelCreate(): void {
    this.dataDriftSidebarVisible.emit(false);
  }
  getThresholdUpdate(threshold): void {
    if (this.validationCheck) {
      clearTimeout(this.validationCheck);
    }
    this.dataThresholds = threshold;
    this.validationCheck = setTimeout(() => {
      if (threshold.minimum === 100 && threshold.maximum === 100) {
        this.confidenceSliderSettings.rangeValues = this.observerService.getDefaultRanges().confidence;
        this.sliderComponent?.initialize();
      }
    }, 500);
  }
  initialize(): void {
    const dataConfig = this.observerService.getDefaultsConfigForObserverRules().dataConfig;
    if (this.savedConfig) {
      this.confidenceSliderSettings = new SliderModel();
      this.confidenceSliderSettings.sliderVisible = true;
      this.confidenceSliderSettings.rangeValues = [
        this.savedConfig.confidence.warningAlerts.minimum,
        this.savedConfig.confidence.warningAlerts.maximum
      ];
      this.dataDriftModel = JSON.parse(JSON.stringify(this.savedConfig));
      if (Helper.isEmpty(this.savedConfig.confidence.warningAlerts)) {
        this.setDefaultsForDatadrift(dataConfig);
      }
    }
  }

  saveChanges() {
    if (this.dataThresholds) {
      this.dataDriftModel.confidence.warningAlerts = this.dataThresholds;
    }
    this.eventBusService.emit('OBSRuleConfig', {
      data: this.dataDriftModel,
      ruleType: Helper.getCamcelCaseString(ObserverConstants.RULE_METRIC_TYPES.DATA_DRIFT)
    });
    this.cancelCreate();
  }

  private setDefaultsForDatadrift(config) {
    this.confidenceSliderSettings = new SliderModel();
    this.confidenceSliderSettings.sliderVisible = true;
    this.confidenceSliderSettings.rangeValues = this.observerService.getDefaultRanges().confidence;
    this.dataDriftModel.confidence = config.confidence;
  }
}
