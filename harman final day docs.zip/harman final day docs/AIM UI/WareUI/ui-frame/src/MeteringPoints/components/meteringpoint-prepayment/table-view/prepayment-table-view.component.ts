import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from "@angular/core";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { TranslationsService } from "../../../../app/services/translations-service";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { MeterConnectionVO } from "../../../models/view-objects/meterconnection-vo.model";

@Component({
    selector: "landisgyr-prepayment-table-view",
    templateUrl: "./prepayment-table-view.component.html",
    styleUrls: ["./prepayment-table-view.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PrepaymentTableViewComponent {
    @Input() prepaymentInfoExpanded = false;

    @Input() loading!: boolean;

    @Input() tableData!: any;

    @Input() meteringPoint!: MeteringPoint;

    @Input() timeRange: any;

    @Input() meteringDataForExport: any;

    @Input() prepaymentDataToExport: any;

    @Input() devices!: MeterConnectionVO[];

    @Input() deviceMeterRegisters!: any;

    @Input() sideViewExpanded!: boolean;

    @Input() columnsData: any;

    @Input() tableViewName!: string;

    @Output() tableSortOrder = new EventEmitter<SortOrder>();

    public prepaymentColumnsData: any;

    infoMessage = this.translations.getTranslation("No data available for the selected time period");

    constructor(public translations: TranslationsService) {}

    onSortChange(sortChange: SortOrder): void {
        this.tableSortOrder.emit(sortChange);
    }
}
