import { Component, Input } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { EntityCardComponent } from './entity-card/entity-card.component';
import { EntityDataModel } from './entity-card/entity-data-model';
import { DatasourceEntitySelectorComponent } from './datasource-entity-selector.component';

@Component({
  selector: 'p-connect-entity-card',
  template: '',
  providers: [{ provide: EntityCardComponent, useClass: MockEntityCardComponent }]
})
class MockEntityCardComponent {
  @Input() headerText: string;
  @Input() showFilter = true;
  @Input() filterPlaceHolder: string;
  @Input() allowSelection = true;
  @Input() cardDataModel: EntityDataModel;
  @Input() apiData = [];
  @Input() isLoading = false;
  @Input() filterFields: string[];
  @Input() selectedData: any;
}

describe('DatasourceEntitySelectorComponent', () => {
  let component: DatasourceEntitySelectorComponent;
  let fixture: ComponentFixture<DatasourceEntitySelectorComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [DatasourceEntitySelectorComponent, MockEntityCardComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatasourceEntitySelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
