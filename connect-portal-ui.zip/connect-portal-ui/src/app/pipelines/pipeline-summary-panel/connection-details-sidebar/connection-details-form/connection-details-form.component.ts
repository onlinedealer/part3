import { Component, Input } from '@angular/core';
import { BaseComponent } from '../../../../core/base.component';

@Component({
  selector: 'p-connect-connection-details-form',
  templateUrl: './connection-details-form.component.html',
  styleUrls: ['./connection-details-form.component.scss']
})
export class ConnectionDetailsFormComponent extends BaseComponent {
  @Input() selectedPipeline: any;
  @Input() selectedConnection: any;
  @Input() projectName: string;

  constructor() {
    super();
  }

  hasMonitoringStatusValues(): boolean {
    return this.selectedPipeline && this.selectedPipeline.hasOwnProperty('replicationStatus') ? true : false;
  }

  isSourceConnecton(): boolean {
    return this.selectedConnection?.source;
  }

  getRole(): string {
    let role = 'pipelines.PIPELINES_SUMMARY.CONNECTION_DETAILS.LABELS.SOURCE';
    if (this.selectedConnection?.target) {
      role = 'pipelines.PIPELINES_SUMMARY.CONNECTION_DETAILS.LABELS.TARGET';
    }
    return role;
  }
}
