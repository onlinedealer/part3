import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { Location, LocationStrategy, PathLocationStrategy, APP_BASE_HREF } from '@angular/common';
import { AppRoutingModule } from './app-routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppComponent } from './app.component';
import { ClubBenefitComponent } from './club-benefit/club-benefit.component';
import { RegistrationModule } from './registration/registration.module';
import { SharedModule } from './shared/shared.module';
import { BccComponent } from './shared/bcc/bcc.component';
import { UtilityService } from './shared/utility/utility.service';
import { AjaxUtilityService } from './shared/utility/ajax-utility.service';
import { UrlMakerService } from './shared/utility/url-maker.service';
import { HttpClientModule, HttpClient, HTTP_INTERCEPTORS } from '@angular/common/http';
import { serviceConfigs } from './shared/utility/service-config.service';
import { HttpModule } from '@angular/http';
import { Env } from './shared/utility/envConfig.service';
import { WindowRef } from './shared/utility/window.object';
import { ClubDashboardComponent } from './club-dashboard/club-dashboard.component';
import { ClubBenefitDashboardComponent } from './club-benefit-dashboard/club-benefit-dashboard.component';
import { PaymentBillingModule } from './payment-billing/payment-billing.module';
import { PaymentBillingComponent } from './payment-billing/payment-billing/payment-billing.component';
import { ProfileCompletionComponent } from './profile-completion/profile-completion.component';
import { PaymentSubscriptionComponent } from './payment-billing/payment-subscription/payment-subscription.component';
import { CardDetailsComponent } from './payment-billing/card-details/card-details.component';
import { StateUtilityService } from './shared/utility/state-utility.service';
import { ScrollToStartService } from './shared/utility/scroll-to-start.service';
import { ActiveModelService } from './shared/models/active-model.service';
import { VantivModelService } from './shared/models/vantiv-model.service';
import { GetDigitalProfileResolver } from './shared/resolvers/get-digital-profile-resolver.service'
import { RegistrationNavResolverService } from './shared/resolvers/registration-nav-resolver.service';
import { ValidateProfileEmailResolver } from './shared/resolvers/validate-profile-email-resolver.service';
import { GetEligibleClubSubscription } from './shared/resolvers/get-eligible-club-subscription-resolver';
import { CreditCardService } from './shared/utility/credit-card.service';
import { ClubOrderConfirmationComponent } from './club-order-confirmation/club-order-confirmation.component';
import { CookieUtilityService } from './shared/utility/cookie-utility.service';
import { HttpInterceptorService } from './shared/interceptor/http-interceptor.service';
import { InterceptorEmitter } from './shared/interceptor/interceptor-emitter.service';
import { ModalOpenerService } from './shared/utility/modal-opener.service';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ScriptLoaderService } from './shared/utility/script-loader.service';
import { SEOService } from './shared/utility/seo.service';
import { CarepassLookupComponent } from './carepass-lookup/carepass-lookup.component';
import { GetCancellationInfoResolver } from './shared/resolvers/get-cancellation-info.resolver.service';


/* Reusable angular components */
import { GlobalHeaderModule } from 'global-header-module';
import { UtagModule, UtagService } from 'utag-module';
import { GlobalFooterModule } from 'global-footer-module';
import { LoaderComponent } from './loader/loader.component';
import { TermsAndConditionsModalComponent } from './terms-and-conditions-modal/terms-and-conditions-modal.component';
import { ClubConstantsService } from './shared/utility/club-constants.service';
import { CarepassSelfUnenrollComponent } from './carepass-self-unenroll/carepass-self-unenroll.component';

@NgModule({
  declarations: [
    AppComponent,
    ClubBenefitComponent,
    ClubDashboardComponent,
    ClubBenefitDashboardComponent,
    ProfileCompletionComponent,
    ClubOrderConfirmationComponent,
    LoaderComponent,
    TermsAndConditionsModalComponent,
    CarepassLookupComponent,
    CarepassSelfUnenrollComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpModule,
    HttpClientModule,
    PaymentBillingModule,
    SharedModule,
    RegistrationModule,
    GlobalHeaderModule,
    FormsModule,
    UtagModule,
    ReactiveFormsModule,
    GlobalFooterModule,
    NgbModule.forRoot()
  ],
  providers: [
    UtilityService,
    AjaxUtilityService,
    UrlMakerService,
    Env,
    WindowRef,
    StateUtilityService,
    UtagService,
    ScrollToStartService,
    ActiveModelService,
    VantivModelService,
    GetDigitalProfileResolver,
    ValidateProfileEmailResolver,
    GetEligibleClubSubscription,
    RegistrationNavResolverService,
    CreditCardService,
    CookieUtilityService,
    { provide: HTTP_INTERCEPTORS, useClass: HttpInterceptorService, multi: true },
    HttpInterceptorService,
    InterceptorEmitter,
    ModalOpenerService,
    ClubConstantsService,
    ScriptLoaderService,
    SEOService,
    {provide: APP_BASE_HREF, useValue: '/carepass'},
    GetCancellationInfoResolver
    ],
  bootstrap: [ AppComponent ],
  entryComponents: [TermsAndConditionsModalComponent]
})
export class AppModule { }
