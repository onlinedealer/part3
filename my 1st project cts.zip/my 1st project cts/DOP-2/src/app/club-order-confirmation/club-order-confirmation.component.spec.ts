import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ClubOrderConfirmationComponent } from './club-order-confirmation.component';

describe('ClubOrderConfirmationComponent', () => {
  let component: ClubOrderConfirmationComponent;
  let fixture: ComponentFixture<ClubOrderConfirmationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ClubOrderConfirmationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ClubOrderConfirmationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
