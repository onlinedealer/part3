import { HttpClientTestingModule } from '@angular/common/http/testing';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { RadioButtonModule } from 'primeng/radiobutton';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { Connection } from '../../../../connections/shared/connection';
import { SharedModule } from '../../../../shared/shared.module';

import { SqlServerMetabaseFormComponent } from './sqlserver-metabase-form.component';
import { Metabase } from '../../../shared/metabase.model';
import { By } from '@angular/platform-browser';
import { of, throwError } from 'rxjs';
import { MetabasesApiService } from '../../../shared/metabases-api.service';
import { AuthModule } from 'angular-auth-oidc-client';
import { RouterModule } from '@angular/router';
import { EncryptionService } from '@shared/services/encryption.service';

describe('SQLServerMetabaseFormComponent', () => {
  let component: SqlServerMetabaseFormComponent;
  let fixture: ComponentFixture<SqlServerMetabaseFormComponent>;
  let mockMetabaseService;
  let encryptionApiService: EncryptionService;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const mockedSourceConnection = {
    id: '1',
    connectionType: 'SQLSERVER',
    accessFromServer: { name: 'myServer' }
  } as Connection;

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  beforeEach(waitForAsync(() => {
    TestBed.configureTestingModule({
      declarations: [SqlServerMetabaseFormComponent],
      imports: [
        getTranslocoModule(),
        FormsModule,
        SharedModule,
        ReactiveFormsModule,
        RadioButtonModule,
        HttpClientTestingModule,
        AuthModule.forRoot({}),
        RouterModule.forRoot([])
      ],
      providers: [
        {
          provide: TRANSLOCO_SCOPE,
          useValue: 'metabase'
        },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SqlServerMetabaseFormComponent);
    component = fixture.componentInstance;
    encryptionApiService = TestBed.inject(EncryptionService);
    mockMetabaseService = TestBed.inject(MetabasesApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set the database server control value if a data connection is passed', () => {
    component.dataConnection = { database: 'test', port: 30000, accessFromServer: { name: 'myServer' } } as Connection;
    component.ngOnInit();
    expect(component.sqlserverMetabaseForm.get('databaseServer').value).toBe('test:30000');
  });

  it('should NOT set the database server control value if a data connection is NOT passed', () => {
    component.ngOnInit();
    expect(component.sqlserverMetabaseForm.get('databaseServer').value).toBe('');
  });

  it('should return a metabase object from the form', () => {
    component.ngOnInit();
    component.sqlserverMetabaseForm.patchValue({
      userID: 'sa',
      password: '',
      replicationUserID: '',
      replicationPassword: '',
      metabaseName: '',
      maximumTransactionRow: '',
      dataLogicalName: '',
      dataSize: '',
      dataPhysicalName: '',
      logLogicalName: '',
      logSize: '',
      logPhysicalName: ''
    });
    component.sqlserverMetabaseForm.addControl('dataConnection', new FormControl('1'));
    const metabase = component.metabase as Metabase;
    expect(metabase.adminUserId).toBe('sa');
  });

  it('should enable controls when retrieve button is clicked', () => {
    component.ngOnInit();
    component.dataConnection = { database: 'test', port: 30000, accessFromServer: { name: 'myServer' } } as Connection;
    component.sqlserverMetabaseForm.addControl('dataConnection', new FormControl('1'));
    component.sqlserverMetabaseForm.patchValue({ metabaseName: 'test' });
    spyOn(mockMetabaseService, 'getPhysicalSQLServerPaths').and.returnValue(of({ directoryPath: 'c:\\path' }));
    // component.dataConnection.accessFromServer.name='myserver';
    encryptionApiService.encrypt('myServer', 'pwd');
    component.retrieveSQLServerPaths();
    expect(component.sqlserverMetabaseForm.get('dataPhysicalName').value).toBe('...\\omnirep_data.mdf');
  });

  it('should not set controls as enabled iof retrieve paths API request fails', () => {
    component.ngOnInit();
    component.dataConnection = { database: 'test', port: 30000, accessFromServer: { name: 'myServer' } } as Connection;
    component.sqlserverMetabaseForm.addControl('dataConnection', new FormControl('1'));
    component.sqlserverMetabaseForm.patchValue({ metabaseName: 'test' });
    spyOn(mockMetabaseService, 'getPhysicalSQLServerPaths').and.returnValue(throwError({ error: 'An error has occured' }));
    //component.dataConnection.accessFromServer.name = 'myserver';
    encryptionApiService.encrypt('myServer', 'pwd');
    component.retrieveSQLServerPaths();
    expect(component.sqlserverMetabaseForm.get('dataPhysicalName').value).toBe('...\\omnirep_data.mdf');
  });

  it('should update fields when metabase name changes before retrieve paths button clicked', () => {
    component.ngOnInit();
    component.sqlserverMetabaseForm.addControl('dataConnection', new FormControl('1'));
    component.sqlserverMetabaseForm.patchValue({ metabaseName: 't' });
    const event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });

    const controlName = 'sqlServerMetabaseName';
    const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
    input.dispatchEvent(event);
    input.value = 't';
    fixture.detectChanges();

    expect(component.sqlserverMetabaseForm.get('dataLogicalName').value).toBe('t_data');
    expect(component.sqlserverMetabaseForm.get('dataPhysicalName').value).toBe(
      'C:\\Program Files\\Microsoft SQL Server\\MSSQL13.MSSQLSERVER\\MSSQL\\DATA\\t_data.mdf'
    );
  });

  it('should update fields when metabase name changes after retrieve paths button clicked', () => {
    component.ngOnInit();
    component.sqlserverMetabaseForm.addControl('dataConnection', new FormControl('1'));
    component.sqlserverMetabaseForm.patchValue({ metabaseName: 't' });
    component.sqlServerPathsReturned = true;
    component.sqlServerDirectoryPath = 'c:\\path';

    const event = new KeyboardEvent('keyup', {
      bubbles: true,
      cancelable: true,
      shiftKey: false
    });

    const controlName = 'sqlServerMetabaseName';
    const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
    input.dispatchEvent(event);
    input.value = 't';
    fixture.detectChanges();

    expect(component.sqlserverMetabaseForm.get('dataLogicalName').value).toBe('t_data');
    expect(component.sqlserverMetabaseForm.get('dataPhysicalName').value).toBe('c:\\path\\t_data.mdf');
  });
});
