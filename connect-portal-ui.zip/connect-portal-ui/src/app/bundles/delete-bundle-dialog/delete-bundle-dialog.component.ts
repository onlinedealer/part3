import { Component, ChangeDetectorRef, EventEmitter, Input, Output } from '@angular/core';
import { HttpHeaders } from '@angular/common/http';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';
import { first } from 'rxjs/operators';
import { BundlesApiService } from '../shared/bundles-api.service';
import { Bundle } from '../shared/bundles';

@Component({
  selector: 'p-connect-delete-bundle-dialog',
  templateUrl: './delete-bundle-dialog.component.html'
})
export class DeleteBundleDialogComponent {
  /**
   * Visibility flag
   */
  @Input() isVisible: boolean;

  /**
   * Event that is fired when visibility changes
   */
  @Output() isVisibleChanged = new EventEmitter<boolean>();

  /**
   * Event that is fired when bundle has been deleted
   */
  @Output() bundleDeletedEvent = new EventEmitter<{ id: number }>();

  /**
   * The number of bundles selected
   */
  bundlesCount = 0;

  /**
   * List of bundles that can be deleted
   */
  deletableBundles: Bundle[] = [];

  isDeletingBundle: boolean;

  constructor(private readonly bundlesApiService: BundlesApiService, private readonly changeDetectorRef: ChangeDetectorRef) {}

  /**
   * Open the sidebar
   */
  open(deletableBundles: Bundle[], bundlesCount): void {
    this.deletableBundles = deletableBundles;
    this.bundlesCount = bundlesCount;
    this.isDeletingBundle = false;
  }

  /**
   * Click event for the primary button
   */
  deleteButtonClicked(): void {
    this.isDeletingBundle = true;
    const ids = this.deletableBundles.map((bundle) => bundle.id);
    this.bundlesApiService
      .deleteBundle(ids, new HttpHeaders().set(InterceptorSkipHeader, ''))
      .pipe(first())
      .subscribe({
        next: (response: any) => {
          this.bundleDeletedEvent.emit(response);
        }
      })
      .add(() => {
        this.isDeletingBundle = false;
        this.changeDetectorRef.markForCheck();
        this.cancelButtonClicked();
      });
  }

  /**
   * Click event for the cancel button
   */
  cancelButtonClicked(): void {
    this.isVisible = false;
    this.isVisibleChanged.emit(false);
  }
}
