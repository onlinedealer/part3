import { Component, Input, ViewChild, TemplateRef, OnInit, OnDestroy } from "@angular/core";
import { DateFormatService, DateFormats } from "../../../../Shared/services/date-format.service";
import { cloneDeep } from "lodash";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { Observable, of, Subscription } from "rxjs";
import { PQIDataSelectors, MeteringPointsUISelectors, EventsSelectors, EventDefinitionsSelectors } from "../../../store/selectors";
import { PQIDataVO } from "../../../models/view-objects/pqidata-vo.model";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { Store } from "@ngrx/store";
import { ToastMessageComponent } from "../../../../Shared/modules/toast/toast-message.component";
import { ToastRef } from "../../../../Shared/modules/toast/toast-ref";
import { ToastService } from "../../../../Shared/modules/toast";
import { TranslationsService } from "../../../../app/services/translations-service";
import * as PQIDataActions from "../../../store/actions/pqidata.action";
import { concatMap, delay, map } from "rxjs/operators";
import { ExportDataActions, PqiDataActions } from "../../../store/actions";
import { ExportDataColHeaderService } from "../../../services/export-data-col-header.service";
import { getSelectedPqiDefinitionPlaceholderText } from "./selected-pqidefinition-placeholdertext.selector";
import { FormGroup, FormControl } from "@angular/forms";
import { getMeteringPointsSideviewExpanded } from "../../../store/selectors/ui.selectors";
import { LocalStorageKeys, LocalStorageService } from "../../../../app/services/local-storage.service";
import { EditColumnDialogComponent } from "../../../components/edit-column-dialog/edit-column-dialog.component";
import { MatDialog } from "@angular/material/dialog";

interface ColumnTitles {
    [key: string]: string;
}

@Component({
    selector: "landisgyr-meteringpoint-events-power-quality-container",
    templateUrl: "./meteringpoint-power-quality.component.html",
    styleUrls: ["./meteringpoint-power-quality.component.scss"]
})
export class MeteringPointEventsPowerQualityComponent implements OnInit, OnDestroy {
    @ViewChild("toastMessageOrigin") toastMessageOrigin!: HTMLElement;

    @ViewChild("toastmessage", { static: true }) toastMessage!: TemplateRef<any>;

    @ViewChild("pqiTypeContextMenu") pqiTypeContextMenu!: TemplateRef<any>;

    @Input() meteringPoint!: MeteringPoint;

    @Input() selectedTimeRangeRadio!: string;

    @Input() selectedTimeRange!: any;

    currentToast!: ToastRef;
    typeFilter!: string;
    eventType!: PQIDataVO;
    selectedPQIEvent!: PQIDataVO;
    selectedPQIDataId: number | null = null;

    filterForm: FormGroup = new FormGroup({
        filter: new FormControl("")
    });

    pqiColumnConfig: any;
    changed = false;
    localStorageSubscription!: Subscription;
    columnConfigInitialSubs!: Subscription;
    selectedEventId!: number | undefined;

    // tslint:disable-next-line: max-line-length
    toastMessageSubCategoryChanged = $localize`:|Toast message that is shown when user filters events based on a specific pqi type shown on the table.@@pqiView.toastmessage.filterchanged:Selected filter was changed`;

    selectedView$: Observable<any> = this.store.select(PQIDataSelectors.getPqiView);
    pqiGraphData$: Observable<any> = this.store.select(PQIDataSelectors.getPQIChartData);
    pqiDataCount$: Observable<number> = this.store.select(PQIDataSelectors.getSelectedMeteringPointPQIDataCount);
    pqiDataTablePageCount$: Observable<number> = this.store.select(PQIDataSelectors.getPQIDataTablePagesCount);
    pqiDataTablePage$: Observable<number> = this.store.select(PQIDataSelectors.getPQIDataPage);
    selectedEventFiltersPlaceholderText$: Observable<string> = this.store.select(getSelectedPqiDefinitionPlaceholderText);
    pqiDataLoading$: Observable<boolean> = this.store.select(PQIDataSelectors.selectDataLoadStatus);
    pqiSelectedTimeRange$: Observable<{ from: number | undefined; until: number | undefined }> = this.store.select(
        PQIDataSelectors.getPqiSelectedTimeRange
    );
    pqiChartXAxisFormat$: Observable<{ dateFormat: string; timeFormat: string }> = this.store.select(
        PQIDataSelectors.getDateFormatFormattedForPqiChartXaxisLabels
    );
    pqiFilterData$: Observable<any[]> = this.store.select(EventsSelectors.getPqiFilter);

    pqiRadioButtonData$: Observable<string> = this.store.select(EventsSelectors.getEventsTimeRangeRadio);

    pqiTableData$: Observable<any> = this.store.select(PQIDataSelectors.getPQIDataSortedAndPaginatedForTable).pipe(
        map((pqiData) => {
            return pqiData.map((data) => {
                return {
                    ...data,
                    startTime: this.dateFormatService.toLocaleString(data.startTime, DateFormats.DATETIME),
                    endTime:
                        data.duration < 0
                            ? $localize`:|@@powerQualityData.ongoing:Ongoing`
                            : this.dateFormatService.toLocaleString(Number(data.startTime) + data.duration, DateFormats.DATETIME),
                    duration: data.duration < 0 ? "" : this.dateFormatService.toLocaleString(data.duration, DateFormats.DURATION),
                    readingTime: this.dateFormatService.toLocaleString(data.readingTime, DateFormats.DATETIME)
                };
            });
        })
    );

    pqiForExport$: Observable<any> = this.store.select(PQIDataSelectors.getPQIExportData).pipe(
        map((pqiDatas) => {
            return pqiDatas.map((pqiData: any) => {
                return {
                    ...pqiData,
                    startTime: this.dateFormatService.toLocaleString(pqiData.startTime, DateFormats.DATETIME),
                    endTime: this.dateFormatService.toLocaleString(pqiData.endTime, DateFormats.DATETIME),
                    readingTime: this.dateFormatService.toLocaleString(pqiData.readingTime, DateFormats.DATETIME)
                };
            });
        })
    );
    sideViewExpanded$: Observable<boolean> = this.store
        .select(getMeteringPointsSideviewExpanded)

        .pipe(concatMap((expanded) => of(expanded).pipe(delay(100))));
    // this delay above is added so that the chart can resize itself after expand animation
    showUndo$: Observable<number> = this.store.select(EventDefinitionsSelectors.getUndoPqiCount);
    showRedo$: Observable<number> = this.store.select(EventDefinitionsSelectors.getRedoPqiCount);
    infoMessage = this.translations.getTranslation("No data available for the selected time period");

    TABLE_COLUMN_TITLES_PQI: ColumnTitles = {
        startTime: this.translations.getTranslation("Start time"),
        endTime: this.translations.getTranslation("End time"),
        duration: $localize`:|@@meteringpointEvents.duration:Duration`,
        type: this.translations.getTranslation("Type"),
        phase: this.translations.getTranslation("Phase"),
        level: $localize`:|@@meteringpointEvents.level:Level`,
        readingTime: this.translations.getTranslation("Reading time")
    };
    exportData: any;

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private translations: TranslationsService,
        private toastService: ToastService,
        private dateFormatService: DateFormatService,
        private exportDataColHeaderService: ExportDataColHeaderService,
        private localStorage: LocalStorageService,
        private dialog: MatDialog
    ) {}

    ngOnInit() {
        this.localStorageSubscription = this.localStorage.changedColumnInfo.subscribe((data) => {
            if (data.key === LocalStorageKeys.pqiTable) {
                this.changed = true;
                this.pqiColumnConfig = data.value;
            }
        });
        if (!this.changed) {
            if (this.localStorage.getColumnConfiguration(LocalStorageKeys.pqiTable)) {
                this.pqiColumnConfig = this.localStorage.getColumnConfiguration(LocalStorageKeys.pqiTable);
            } else {
                this.columnConfigInitialSubs = this.store.select(MeteringPointsUISelectors.getPqiColumnConfigInitial).subscribe((data) => {
                    this.pqiColumnConfig = data;
                });
            }
        }
        this.pqiForExport$.subscribe((data) => (this.exportData = data));
    }
    onPageChange(page: number): void {
        this.store.dispatch(new PQIDataActions.SetPQIDataTablePage(page));
    }

    onSortChange(sortChange: SortOrder): void {
        this.store.dispatch(new PQIDataActions.SetPqisTableSorting(sortChange));
    }

    onSelect(event: PQIDataVO) {
        this.selectedPQIEvent = event;
        this.selectedPQIDataId = event.id;
    }

    onSelectPqi(event: PQIDataVO) {
        this.selectedEventId = event.id;
    }

    onFilterListSelection(filterList: any) {
        this.store.dispatch(new PQIDataActions.SetPQIFilterList(filterList));
    }

    showOnlyThisType(event: PQIDataVO) {
        this.store.dispatch(PqiDataActions.AddToUndoPQI());
        this.store.dispatch(PqiDataActions.ShowPqiOfSelectedType({ event }));
        this.showSubCategoryChangeToastMessage();
    }

    hideThisType(event: PQIDataVO) {
        this.store.dispatch(PqiDataActions.AddToUndoPQI());
        this.store.dispatch(PqiDataActions.HidePqiOfSelectedType({ event }));
        this.showSubCategoryChangeToastMessage();
    }

    onUndoClick() {
        this.store.dispatch(PqiDataActions.UndoPqiFilter());
        this.showSubCategoryChangeToastMessage();
    }
    onRedoClick() {
        this.store.dispatch(PqiDataActions.RedoPqiFilter());
        this.showSubCategoryChangeToastMessage();
    }
    showSubCategoryChangeToastMessage() {
        this.currentToast = this.toastService.replaceToast(
            this.currentToast,
            {
                component: ToastMessageComponent,
                componentData: {
                    message: this.toastMessageSubCategoryChanged,
                    icon: "info"
                }
            },
            {
                origin: this.toastMessageOrigin,
                positions: [
                    {
                        originX: "start",
                        originY: "top",
                        overlayX: "start",
                        overlayY: "top"
                    }
                ]
            }
        );
    }

    onPowerQualityExportDataClick(pqiData: any) {
        const exportData: any[] = cloneDeep(this.exportData);
        exportData.forEach((element: { duration: string | number }) => {
            if (element.duration < 0) {
                element.duration = "";
            } else {
                element.duration = Number(element.duration) / 1000;
            }
        });

        const data = {
            fileName: this.meteringPoint.name + "_pqi_data",
            results: exportData,
            header: this.exportDataColHeaderService.pqiHeaderObj,
            includePageRange: true,
            includeTimeRange: false
        };
        this.store.dispatch(ExportDataActions.OpenExportTableDialog({ data: data }));
    }

    openEditColumnDialog() {
        this.dialog.open(EditColumnDialogComponent, {
            width: "550px",
            maxWidth: "550px",
            height: "620px",
            maxHeight: "620px",
            data: {
                results: [],
                header: this.pqiColumnConfig,
                tabSelectionFlag: "pqiTable"
            }
        });
    }

    ngOnDestroy() {
        if (this.columnConfigInitialSubs) {
            this.columnConfigInitialSubs.unsubscribe();
        }
        if (this.localStorageSubscription) {
            this.localStorageSubscription.unsubscribe();
        }
    }
}
