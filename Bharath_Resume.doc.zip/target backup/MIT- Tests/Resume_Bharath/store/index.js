import auth from './auth'
import { combineReducers } from 'redux-immutable'
import layout from '../store/layout/reducer'
import notification from './notification/reducer'
import items from './massItemMaintain/reducer'

const rootReducer = combineReducers({
  auth,
  layout,
  notification,
  items,
})

export default rootReducer
