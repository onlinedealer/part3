import { Spies } from 'discovery-test';
import { HomeComponent } from './home.component';

describe('HomeComponent', () => {
  let component: HomeComponent;

  beforeEach(() => {
    component = new HomeComponent({} as any, Spies.HttpUtilService);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });
});
