import { createSelector } from "@ngrx/store";

import * as fromRoot from "../reducers";
import * as fromConfigurations from "../reducers/configurations.reducer";
import * as fromSecuritySelectors from "./security.selectors";

export interface TimeZoneConfiguration {
    userUamTimeZone: string;
    timeZoneSelected?: string;
}

export const getUIConfiguration = createSelector(fromRoot.getConfigurationsState, (configState) => configState.uiConfiguration);

export const getUiLocale = createSelector(fromSecuritySelectors.getUser, getUIConfiguration, (user, uiConfiguration) => {
    return uiConfiguration.userLocale || (user ? user.languageCode : undefined) || uiConfiguration.systemLocale;
});

export const getUserCountry = createSelector(getUIConfiguration, (uiConfiguration) => uiConfiguration.systemLocale);

export const getUserSettingsUrl = createSelector(fromRoot.getConfigurationsState, (configuration) => configuration.userSettingsUrl);


export const getUAMDefinedTimeZone = createSelector(getUIConfiguration, fromSecuritySelectors.getUser, (uiConfiguration, user) => {
    return user ? user.timeZone || "" : "";
});

export const getTimeZoneInUse = createSelector(getUIConfiguration, (uiConfiguration) => uiConfiguration.timeZoneInUse);

export const getTimeZoneInUseInformation = createSelector(
    getTimeZoneInUse,
    fromSecuritySelectors.getUser,
    (timeZoneInUse, securityUser) => {
        const information: TimeZoneConfiguration = {
            userUamTimeZone: securityUser ? securityUser.timeZone : "",
            timeZoneSelected: timeZoneInUse
        };
        return information;
    }
);
export const getUiConfigurations = createSelector(
    fromRoot.getConfigurationsState,
    getTimeZoneInUse,
    getUiLocale,
    (configState: fromConfigurations.ConfigurationsState, timeZoneInUse: string | undefined, uiLocale) => {
        return {
            ...configState.uiConfiguration,
            userTimezone: timeZoneInUse,
            userLocale: uiLocale
        };
    }
);
export const getDateFormat = createSelector(
    getUiConfigurations,
    (uiConfiguration: fromConfigurations.UiConfiguration): fromConfigurations.DateFormatConfiguration => {
        return updateDateFormatObject(uiConfiguration.dateFormat, uiConfiguration.hours, uiConfiguration.timeFormat);
    }
);
export const getDateFormatStates = createSelector(getUiConfigurations, (uiConfiguration) => {
    return { dateFormat: uiConfiguration.dateFormat, hours: uiConfiguration.hours, timeFormat: uiConfiguration.timeFormat };
});

function updateDateFormatObject(
    dateFormatObject: { separator: string; format: string },
    hours: string,
    useTimeFormat: string
): fromConfigurations.DateFormatConfiguration {
    let timeFormat = useTimeFormat.includes("HH")
        ? useTimeFormat.replace("HH", hours === "12" ? "hh" : "HH")
        : useTimeFormat.replace("H", hours === "12" ? "h" : "H");
    if (hours === "12") {
        timeFormat += " a";
    }
    const dateFormat = dateFormatObject.format;
    const separator = dateFormatObject.separator;
    const initialDateFormatConfiguration: fromConfigurations.DateFormatConfiguration = {
        dateFormatWithTime: `${dateFormat} ${timeFormat}`,
        dateFormatWithTimeWithoutYear: `${dateFormat.replace(`${separator}YYYY`, "")} ${timeFormat.replace(":ss", "")}`,
        dateFormatWithOnlyYear: `YYYY`,
        dateFormatWithoutSeconds: `${dateFormat} ${timeFormat.replace(":ss", "")}`,
        dateFormatWithoutTime: `${dateFormat}`,
        dateFormatWithoutYearTime: `${dateFormat.replace(`${separator}YYYY`, "")}`,
        timeFormat: `${timeFormat}`,
        timeFormatNoSeconds: `${timeFormat.replace(":ss", "")}`,
        dateFormatWithoutDate: `MMM, YYYY`,
        dateWithOnlyMonth: `MMMM`,
        default: `${dateFormat} ${timeFormat}`
    };
    return initialDateFormatConfiguration;
}
