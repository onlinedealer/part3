(function() {
    'use strict';

    fileuploader.controller("dashboardCtrl", ['$scope', '$ajaxFactory', '$rootScope', dashboardCtrl]);

    function dashboardCtrl($scope, $ajaxFactory, $rootScope) {

 
    }


})();
