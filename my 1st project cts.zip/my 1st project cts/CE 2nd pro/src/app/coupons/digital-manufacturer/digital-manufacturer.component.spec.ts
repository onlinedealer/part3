import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DigitalManufacturerComponent } from './digital-manufacturer.component';

describe('DigitalManufacturerComponent', () => {
  let component: DigitalManufacturerComponent;
  let fixture: ComponentFixture<DigitalManufacturerComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DigitalManufacturerComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DigitalManufacturerComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
