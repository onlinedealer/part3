(function() {
    'use strict';

    codeathonApp.service('appService', ['$rootScope', '_', appService]);

    function appService($rootScope, _) {

    }
})();
