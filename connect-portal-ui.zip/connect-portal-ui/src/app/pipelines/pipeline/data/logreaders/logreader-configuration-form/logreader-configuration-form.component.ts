import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { Connection } from 'src/app/connections/shared/connection';
import { TableConfiguration, TableField, TableMessage, TableMessageType } from '@shared/components/generic-table/generic-table';
import { TranslocoService } from '@ngneat/transloco';
import { LogReader } from '../../shared/logreader';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { LogReadersApiService } from '../../shared/logreaders-api.service';
import { PipelineEntityService } from '../../../shared/pipeline-entity.service';
import { MenuItem } from 'primeng/api';
import { LogReaderSidebarComponent } from '../logreader-sidebar/logreader-sidebar.component';
import { DeleteSidebarConfiguration } from '@shared/components/delete-sidebar/delete-sidebar-configuration';

enum LOG_READERS_DROPDOWN_VALUE_TYPE {
  'CURRENT' = 'CURRENT_PIPELINE',
  'ALL' = 'LOG_READERS'
}

@Component({
  selector: 'p-connect-logreader-configuration-form',
  templateUrl: './logreader-configuration-form.component.html',
  styleUrls: ['./logreader-configuration-form.scss']
})
export class LogReaderConfigurationFormComponent implements OnInit {
  @Input() baseZIndex;
  @Input() sourceDataConnection: Connection;
  @ViewChild(LogReaderSidebarComponent) logReaderSidebar: LogReaderSidebarComponent;
  isAuto: {} = { value: LOG_READERS_DROPDOWN_VALUE_TYPE.ALL };
  lang = 'logreaders';
  translationPrefix = 'CONFIGURATION_FORM.DROPDOWN_ITEMS';
  dropdownItems$: Observable<{ label: string; value: string }[]>;
  logReadersList: LogReader[] = [];
  dropdownDisabled = false;
  logReader = {
    header: 'logreaders.CONFIGURATION_FORM.TABLE_HEADERS.LOG_READER',
    name: 'name',
    columnStyle: { width: '20rem', minWidth: '20rem' },
    isKey: true,
    isInDeleteModal: true
  };
  journal = {
    header: 'logreaders.CONFIGURATION_FORM.TABLE_HEADERS.JOURNAL',
    name: 'journalName'
  };
  actions = {
    header: 'logreaders.CONFIGURATION_FORM.TABLE_HEADERS.ACTIONS',
    name: 'actions',
    columnStyle: { width: '6rem', minWidth: '6rem' }
  };
  fields: TableField[] = [this.logReader, this.journal, this.actions];
  emptyTableMessage: TableMessage = {
    messageHead: 'logreaders.CONFIGURATION_FORM.TABLE_MESSAGES.HEAD',
    messageCaption: 'logreaders.CONFIGURATION_FORM.TABLE_MESSAGES.CAPTION.NEW',
    messageType: TableMessageType.INFO
  };
  renderTable = false;
  errorTableMessage: TableMessage = {
    messageHead: 'logreaders.CONFIGURATION_FORM.TABLE_MESSAGES.HEAD',
    messageCaption: 'logreaders.CONFIGURATION_FORM.TABLE_MESSAGES.CAPTION.NEW',
    messageType: TableMessageType.INFO
  };
  currentPipelineName: string;
  actionDropdownMenuItems: MenuItem[] = [
    {
      id: 'logReaderEdit',
      label: 'common.BUTTONS.EDIT',
      command: (event) => {
        this.logReaderFormOpen(event.item.target);
      }
    },
    {
      id: 'logReaderDelete',
      label: 'common.BUTTONS.DELETE',
      command: (event) => {
        this.deleteSidebarConfiguration.targetItemsTableData = [event.item.target];
        this.deleteSidebarConfiguration.isSidebarVisible = true;
      }
    }
  ];
  tableConfiguration: TableConfiguration = {
    isLoading: false,
    isFilterShown: false,
    hideCheckboxColumn: true,
    visibleRows: 25,
    fields: this.fields,
    tableMessages: {
      emptyTableMessage: this.emptyTableMessage,
      filterTableMessage: this.emptyTableMessage,
      errorTableMessage: this.errorTableMessage
    },
    rowAction: {
      fieldIndex: 2,
      menuItems: this.actionDropdownMenuItems
    }
  };

  deleteCompleted: Subject<any> = new Subject<any>();
  deleteSidebarConfiguration: DeleteSidebarConfiguration = {
    isSidebarVisible: false,
    targetItemsTableData: [],
    targetItemsFieldList: this.fields,
    sidebarTitle: 'logreaders.DELETE_LOGREADER_DIALOG.HEADING',
    bodyText: 'logreaders.DELETE_LOGREADER_DIALOG.MESSAGE',
    deleteButtonText: 'logreaders.DELETE_LOGREADER_DIALOG.BUTTONS.DELETE',
    deleteFailedText: 'logreaders.DELETE_LOGREADER_DIALOG.ERRORS.DELETE_FAILED_MESSAGE',
    deleteCompletedEvent: this.deleteCompleted.asObservable(),
    deleteButtonClicked: ($event) => {
      this.deleteLogReader($event as LogReader[]);
    }
  };
  currentPipelineProperties: { key?: string; value?: string }[];
  projectId: string;

  constructor(
    private translocoService: TranslocoService,
    private readonly logReaderApiService: LogReadersApiService,
    private readonly pipelineEntityService: PipelineEntityService
  ) {}

  ngOnInit(): void {
    const currentPipeline = this.pipelineEntityService.getPipeline();
    this.currentPipelineName = currentPipeline.name;
    this.projectId = currentPipeline.projectId;
    this.currentPipelineProperties = currentPipeline.properties;

    this.initiateDropdownOptions();
  }

  isDB2I(): boolean {
    return this.sourceDataConnection.connectionType === 'DB2I';
  }

  logReaderFormOpen(logReader?: LogReader) {
    this.logReaderSidebar.open(logReader);
  }

  async getAllLogReaders() {
    this.logReadersList.length = 0;
    this.logReadersList = await this.logReaderApiService.getLogReaders(this.sourceDataConnection.id, this.projectId).toPromise();
  }

  dropdownItemChanged(selectedDropdownItem): void {
    if (selectedDropdownItem.value === 'LOG_READERS') {
      this.getAllLogReaders();
    } else if (selectedDropdownItem.value === 'CURRENT_PIPELINE') {
      this.renderTable = false;
      const currentLogReaderProperty = this.currentPipelineProperties.find((parameter) => parameter.key === 'IBMI_LOG_READER_NAME');
      const currentLogReaderName = currentLogReaderProperty ? currentLogReaderProperty.value : '';
      const currentLogreader = this.logReadersList.filter((logreader) => logreader.name === currentLogReaderName);
      this.logReadersList = currentLogreader;
      this.renderTable = true;
    }
  }

  open(selectedLogReader: LogReader) {
    setTimeout(() => {
      if (selectedLogReader) {
        this.isAuto = LOG_READERS_DROPDOWN_VALUE_TYPE.CURRENT;
        this.emptyTableMessage.messageCaption = 'logreaders.CONFIGURATION_FORM.TABLE_MESSAGES.CAPTION.NEW';
        this.getAllLogReaders().then(() => this.dropdownItemChanged({ value: this.isAuto }));
      } else {
        this.isAuto = LOG_READERS_DROPDOWN_VALUE_TYPE.ALL;
        this.emptyTableMessage.messageCaption = 'logreaders.CONFIGURATION_FORM.TABLE_MESSAGES.CAPTION.AUTO_GENERATED';
        this.dropdownItemChanged({ value: this.isAuto });
      }
      this.dropdownDisabled = !selectedLogReader;
      this.renderTable = true;
    });
  }

  close() {
    this.logReadersList.length = 0;
  }

  checkButtonDisabled(): boolean {
    if (this.sourceDataConnection.connectionType === 'DB2' && this.logReadersList.length !== 0) {
      return true;
    }
  }

  private initiateDropdownOptions = () => {
    this.dropdownItems$ = this.translocoService
      .selectTranslateObject(`${this.translationPrefix}`, null, this.lang)
      .pipe(map((dropdownOptions) => this.transformToDropdownOptions(dropdownOptions)));
  };

  private transformToDropdownOptions(translationObject, filteredKey?): { label: string; value: string }[] {
    return Object.keys(translationObject)
      .filter((option) => option !== filteredKey)
      .map((key) => ({
        label: translationObject[key],
        value: key
      }));
  }

  private deleteLogReader(logReaders: LogReader[]) {
    this.logReaderApiService.deleteLogReader(this.sourceDataConnection.id, this.projectId, logReaders[0].name).subscribe({
      next: (response) => {
        this.getAllLogReaders();
        this.deleteCompleted.next(response);
      },
      error: (error) => {
        this.deleteCompleted.next(error);
      }
    });
  }
}
