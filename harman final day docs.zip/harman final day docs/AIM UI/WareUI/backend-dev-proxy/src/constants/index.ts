import { isBoolean } from "lodash";

const UAM_HOST = process.env.UAM_HOST
  ? process.env.UAM_HOST
  : "fijyvvraimbl11.eu.bm.net";
const UAM_PORT = process.env.UAM_PORT ? process.env.UAM_PORT : "7503";
const UAM_DEV_USER = process.env.UAM_DEV_USER
  ? process.env.UAM_DEV_USER
  : "wareui";
const UAM_DEV_PASSWORD = process.env.UAM_DEV_PASSWORD
  ? process.env.UAM_DEV_PASSWORD
  : "wareuiui";

const REQUEST_DEBUG = process.env.REQUEST_DEBUG
  ? process.env.REQUEST_DEBUG.toLowerCase() === "true"
  : false;

const BACKEND_URL_SCHEME = process.env.BACKEND_URL_SCHEME
  ? process.env.BACKEND_URL_SCHEME
  : "http";

const BACKEND_HOST = process.env.BACKEND_HOST
  ? process.env.BACKEND_HOST
  : "fijyvvrapp07.eu.bm.net";

const BACKEND_ROOT = process.env.BACKEND_ROOT
  ? process.env.BACKEND_ROOT
  : "/AIMUI/";

const BACKEND_SAML_URL = process.env.BACKEND_SAML_URL
  ? process.env.BACKEND_SAML_URL
  : "http://fijyvvrapp07.eu.bm.net/AIMUI/security/saml2/sso/post";

export {
  UAM_HOST,
  UAM_PORT,
  UAM_DEV_USER,
  UAM_DEV_PASSWORD,
  BACKEND_URL_SCHEME,
  BACKEND_HOST,
  BACKEND_ROOT,
  BACKEND_SAML_URL,
  REQUEST_DEBUG
};
