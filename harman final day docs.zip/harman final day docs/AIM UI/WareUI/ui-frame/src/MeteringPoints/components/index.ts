import { ChartOptionsComponent } from "./meteringpoint-meterings/charts/chart-options/chart-options.component";
import { ChartScalingDialogComponent } from "./meteringpoint-meterings/charts/chart-scaling-dialog/chart-scaling-dialog.component";
import { ClickOutsideDirective } from "./meteringpoint-events/filter-tree/click-outside.directive";
import { ConfigurationsTableComponent } from "./meteringpoint-registers/configurations-table.component";
import { ContractDetailsComponent } from "./contract-details/contract-details.component";
import { CustomPropertiesTableComponent } from "./custom-property-table/custom-property-table.component";
import { DeviceDetailsComponent } from "./meteringpoint-devices/device-details.component";
// tslint:disable-next-line: max-line-length
import { SetRelayUsageDialogsComponent } from "./meteringpoint-devices/set-relay-usage-dialogs/set-relay-usage-dialogs.component";
import { DoubleAxisChartComponent } from "./meteringpoint-meterings/charts/double-axis-chart/double-axis-chart.component";
import { EventFilterComponent } from "./meteringpoint-events/filter-tree/event-filter.component";
import { EventFilterTreeComponent } from "./meteringpoint-events/filter-tree/event-filter-tree.component";
import { ExportDialogComponent } from "./export-dialog/export-dialog.component";
import { FiltersItemListComponent } from "./meteringpoints-filters/filters-itemlist.component";
import { FiltersMenuComponent } from "./meteringpoints-filters/filters-menu.component";
import { IconButtonsComponent } from "./meteringpoint-meterings/icon-buttons/icon-buttons.component";
import { InputWithIconComponent } from "./meteringpoint-events/input-with-icon/input-with-icon.component";
import { MeterConnectionsTableComponent } from "./meteringpoint-devices/meter-connections-table.component";
import { MeteringChartsComponent } from "./meteringpoint-meterings/charts/metering-charts.component";
import { MeteringDatatableComponent } from "./meteringpoint-meterings/meteringdata-table/meteringdata-table.component";
// tslint:disable-next-line: max-line-length
import { MeteringDataTableEditFooterComponent } from "./meteringpoint-meterings/meteringdata-table/meteringdata-table-edit-footer.component";
import { MeteringDataTableEditInputComponent } from "./meteringpoint-meterings/meteringdata-table/meteringdata-table-edit-input.component";
import { MeteringPointDetailsInfotableComponent } from "./meteringpoint-details/meteringpoint-details-infotable.component";
import { MeteringPointDetailsLatestReadingComponent } from "./meteringpoint-details/meteringpoint-details-latest-reading.component";
import { MeteringPointDetailsSLAStatusComponent } from "./meteringpoint-details/meteringpoint-details-sla-status.component";
import { MeteringPointDetailsStateComponent } from "./meteringpoint-details/meteringpoint-details-state.component";
import { MeteringpointEventsControlbarComponent } from "./meteringpoint-events/meteringpoint-events-controlbar.component";
import { MeteringPointEventsResultTableComponent } from "./meteringpoint-events/results/meteringpoint-events-result.component-table";
import { MeteringPointEventsSideViewComponent } from "./meteringpoint-events/side-view/meteringpoint-events-sideview.component";
import { MeteringpointEventsSubcategorybarComponent } from "./meteringpoint-events/meteringpoint-events-subcategorybar.component";
import { MeteringpointPowerQualityFilterComponent } from "./meteringpoint-power-quality/meteringpoint-power-quality-filter.component";
import { MeteringPointsBottomToolsComponent } from "./meteringpoints-bottomtools/meteringpoints-bottomtools.component";
import { MeteringpointsFiltersComponent } from "./meteringpoints-filters/meteringpoints-filters.component";
import { MeteringPointSideviewTopBarComponent } from "./meteringpoint-sideview-topbar/meteringpoint-sideview-topbar.component";
import { MeteringpointsResultsHeaderComponent } from "./meteringpoints-results/meteringpoints-resultsheader.component";
import { MeteringpointsSearchfieldMenuComponent } from "./meteringpoints-search/xsf-search-form/searchfield-menu/menu.component";
import { MeteringpointsSearchMainInputComponent } from "./meteringpoints-search/main-input/mp-search-main-input.component";
import { MeteringPointsSearchResultsComponent } from "./meteringpoints-results/meteringpoints-search-result/meteringpoints-search-results";
import { MeteringpointsSearchXSFFormComponent } from "./meteringpoints-search/xsf-search-form/mp-search-xsf-form.component";
import { MeteringPointStatesIconComponent } from "./meteringpoints-results/meteringpoints-search-result/meteringpoints-states-icon";
import { MeteringPointStatesListComponent } from "./meteringpoint-states/meteringpoint-states-list.component";
import { MeteringsDetailsTablesComponent } from "./meteringpoint-meterings/meterings-details-tables.component";
import { MeteringsListComponent } from "./meteringpoint-meterings/meterings-list/meterings-list.component";
import { MeteringsSummaryComponent } from "./meteringpoint-meterings/meterings-summary.component";
import { MeteringsSummarySummaryComponent } from "./meteringpoint-meterings/meterings-summary-summary/meterings-summary-summary.component";
import { MeteringsViewSelectorComponent } from "./meteringpoint-meterings/meterings-view-selector.component";
import { OdrEventsTableComponent } from "./ondemandreading/reading-entry/event-data-table/odr-events.table.component";
import { ODROperationFormPeriodicComponent } from "./ondemandreading/operation-form/periodic-form/periodic-form.component";
import { ODROperationFormProfileComponent } from "./ondemandreading/operation-form/profile-form/profile-form.component";
import { OdrReadingSimpleTableComponent } from "./ondemandreading/reading-entry/odr-reading-simple-table.component";
import { OnDemandReadingOperationFormComponent } from "./ondemandreading/operation-form/odr-operation-form.component";
import { OnDemandReadingReadingEntryComponent } from "./ondemandreading/reading-entry/odr-reading-entry.component";
import { OnDemandReadingReadingEntryResultsComponent } from "./ondemandreading/reading-entry/odr-reading-entry-results.component";
import { OnDemandReadingReadingsListComponent } from "./ondemandreading/readings-list/odr-readings-list.component";
import { OnDemandReadingServicesSelectionComponent } from "./ondemandreading/services-selection/odr-services-selection.component";
import { PeriodSelectionComponent } from "./meteringpoint-meterings/period-selection/period-selection.component";
import { PeriodSelectionDayComponent } from "./meteringpoint-meterings/period-selection/period-selection-day.component";
import { PeriodSelectionMonthComponent } from "./meteringpoint-meterings/period-selection/period-selection-month.component";
import { PeriodSelectionWeekComponent } from "./meteringpoint-meterings/period-selection/period-selection-week.component";
import { PeriodSelectionYearComponent } from "./meteringpoint-meterings/period-selection/period-selection-year.component";
import { GraphIntervalComponent } from "./meteringpoint-prepayment/chart/graph-interval.component";
// tslint:disable-next-line: max-line-length
import { PrepaymentCustomerInfoComponent } from "./meteringpoint-prepayment/customer-info/customer-info.component";
import { PrepaymentDateSelectorComponent } from "./meteringpoint-prepayment/date-selector/prepayment-date-selector.component";
import { PrepaymentTableViewComponent } from "./meteringpoint-prepayment/table-view/prepayment-table-view.component";
import { PrepaymentChartViewComponent } from "./meteringpoint-prepayment/chart/double-axis-chart/prepayment-chart-view.component";
import { ProductComponentComponent } from "./product-component/product-component.component";
import { ProfileDataTableComponent } from "./ondemandreading/reading-entry/profile-data-table/profile-data-table.component";
import { RegistersTableComponent } from "./meteringpoint-registers/registers-table.component";
import { StatusIndicatorComponent } from "./meteringpoints-results/meteringpoints-search-result/status-indicator.component";
import { TimeRangeSelectionComponent } from "./meteringpoint-meterings/timerange-selection/timerange-selection.component";
import { ValidStatusIndicatorComponent } from "./meteringpoint-meterings/meteringdata-table/valid-status-indicator.component";
import * as SSR from "./ondemandreading/odr-reading-entry-result-scheduled-reading/odr-reading-entry-result-scheduled-reading.component";
import { MeteringpointPowerQualityChartComponent } from "./meteringpoint-power-quality/meteringpoint-power-quality-chart.component";
// tslint:disable-next-line: max-line-length
import { MeteringpointPowerQualityViewSelectorComponent } from "./meteringpoint-power-quality/meteringpoint-power-quality-view-selector.component";
// tslint:disable-next-line: max-line-length
import { MultiplyMeteringValuesDialogComponent } from "./meteringpoint-meterings/multiply-metering-values/multiply-metering-values-dialog.component";
// tslint:disable-next-line: max-line-length
import { MultiplyMeteringValuesTableComponent } from "./meteringpoint-meterings/multiply-metering-values/multiply-metering-values-table.component";

export const components: any[] = [
    ChartOptionsComponent,
    ChartScalingDialogComponent,
    ClickOutsideDirective,
    ConfigurationsTableComponent,
    ContractDetailsComponent,
    CustomPropertiesTableComponent,
    DeviceDetailsComponent,
    DoubleAxisChartComponent,
    EventFilterComponent,
    EventFilterTreeComponent,
    ExportDialogComponent,
    FiltersItemListComponent,
    FiltersMenuComponent,
    IconButtonsComponent,
    InputWithIconComponent,
    MeterConnectionsTableComponent,
    MeteringChartsComponent,
    MeteringDatatableComponent,
    MeteringDataTableEditFooterComponent,
    MeteringDataTableEditInputComponent,
    MeteringPointDetailsInfotableComponent,
    MeteringPointDetailsLatestReadingComponent,
    MeteringPointDetailsSLAStatusComponent,
    MeteringPointDetailsStateComponent,
    MeteringpointEventsControlbarComponent,
    MeteringPointEventsResultTableComponent,
    MeteringPointEventsSideViewComponent,
    MeteringpointEventsSubcategorybarComponent,
    MeteringpointPowerQualityFilterComponent,
    MeteringPointsBottomToolsComponent,
    MeteringpointsFiltersComponent,
    MeteringPointSideviewTopBarComponent,
    MeteringpointsResultsHeaderComponent,
    MeteringpointsSearchfieldMenuComponent,
    MeteringpointsSearchMainInputComponent,
    MeteringPointsSearchResultsComponent,
    MeteringpointsSearchXSFFormComponent,
    MeteringPointStatesIconComponent,
    MeteringPointStatesListComponent,
    MeteringsDetailsTablesComponent,
    MeteringsListComponent,
    MeteringsSummaryComponent,
    MeteringsSummarySummaryComponent,
    MeteringsViewSelectorComponent,
    OdrEventsTableComponent,
    ODROperationFormPeriodicComponent,
    ODROperationFormProfileComponent,
    OdrReadingSimpleTableComponent,
    OnDemandReadingOperationFormComponent,
    OnDemandReadingReadingEntryComponent,
    OnDemandReadingReadingEntryResultsComponent,
    OnDemandReadingReadingsListComponent,
    OnDemandReadingServicesSelectionComponent,
    PeriodSelectionComponent,
    PeriodSelectionDayComponent,
    PeriodSelectionMonthComponent,
    PeriodSelectionWeekComponent,
    PeriodSelectionYearComponent,
    GraphIntervalComponent,
    PrepaymentCustomerInfoComponent,
    PrepaymentDateSelectorComponent,
    PrepaymentTableViewComponent,
    PrepaymentChartViewComponent,
    ProductComponentComponent,
    ProfileDataTableComponent,
    RegistersTableComponent,
    SSR.OdrReadingEntryResultScheduledReadingComponent,
    StatusIndicatorComponent,
    TimeRangeSelectionComponent,
    ValidStatusIndicatorComponent,
    MeteringpointPowerQualityChartComponent,
    MeteringpointPowerQualityViewSelectorComponent,
    SetRelayUsageDialogsComponent,
    MultiplyMeteringValuesDialogComponent,
    MultiplyMeteringValuesTableComponent
];
