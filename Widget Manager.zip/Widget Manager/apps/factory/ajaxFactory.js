(function() {
    'use strict';
    widget.factory('ajaxFactory', ['$http', '$q', ajaxFactory]);

    function ajaxFactory($http, $q) {
        var data = [];
        var editData;
        var methods = {
            getData: getData,
            setData: setData,
            deleteData: deleteData,
            setEditDataToSave: setEditDataToSave,
            getEditDataToSave: getEditDataToSave,
            deleteEditDataToSave: deleteEditDataToSave
        }
        return methods;
        /* Implimentations*/
        function getData() {
            return data;
            console.log(data)
        }

        function setData(item) {
            data.push(item);
        }

        function deleteData(index) {
            data.splice(index, 1);
            return data;
        }

        function setEditDataToSave(item) {
            editData = item;
        }
        function getEditDataToSave() {
            return editData;
        }
        function deleteEditDataToSave() {
            editData =  undefined;
            return editData;
        }
    }
})();