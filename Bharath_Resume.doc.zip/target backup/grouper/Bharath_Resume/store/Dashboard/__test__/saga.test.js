
import { getGroupListSaga } from '../saga'
import { grouperListAPI } from '../actionCreator'
import { put, call } from 'redux-saga/effects'

describe('Dashboard saga', () => {
  const response = {
    data: [{'group_id': 5, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534306000, 'department': {'department_id': 244, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962800000, 'status': 'InActive'}],
  }
  // const action = {
  //   axios: {
  //     get () {},
  //   },
  //   GET_GROUPER_LIST: 'dummy url',
  //   getGrouperListSuccess: jest.fn().mockReturnValue({ type: 'GET_GROUPER_LIST_SUCCESS' }),
  //   setAppInProcessing: jest.fn().mockReturnValue({ type: 'setAppInProcessing' }),
  //   todosInitialized: jest.fn().mockReturnValue({ type: 'todosInitialized' }),
  // }

  const error = {
    response: {
      data: {
        message: 'Error fetching grouper list.',
      },
    },
  }

  const action = {
    type: 'GET_GROUPER_LIST',
    payload: { memberOf: 'x', userId: 'abc' },
  }
  let result

  const initGroupListSagaGen = getGroupListSaga(action)

  result = initGroupListSagaGen.next()
  expect(result.value).toEqual(call(grouperListAPI, action.payload))
  result = initGroupListSagaGen.next(response)
  expect(result.value).toEqual(put({
    type: 'GET_GROUPER_LIST_SUCCESS',
    data: response.data,
  }))
  initGroupListSagaGen.throw(new Error(error))
  // initGroupListSagaGen.throw({message: 'error!'})
  // result = initGroupListSagaGen.next(error)
  // expect(result.value).toEqual(put({
  //   type: 'TOGGLE_SNACKBAR',
  //   snackMessage: { status: true, variant: 'error', message: error.response.data.message },
  // }))
})
