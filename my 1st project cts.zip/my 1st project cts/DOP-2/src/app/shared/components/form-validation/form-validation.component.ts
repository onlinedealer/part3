import { Component, OnInit, Input, ElementRef, Renderer } from '@angular/core';
import { FormGroup, Validators } from '@angular/forms';
import { UtilityService } from '../../utility/utility.service';

@Component({
  selector: 'app-form-validation',
  templateUrl: './form-validation.component.html',
  styleUrls: ['./form-validation.component.scss']
})
export class FormValidationComponent implements OnInit {

  // Form for which validation should be done.
  formToValidate: FormGroup;

  // Object with list of field names from the formToValidate FormGroup.
  formFields: any = {};

  //flag to enable or diable form validation.
  enableValidation: boolean = false;

  //flag to enable or diable form validation.
  errorMessages: Object;

  constructor(private renderer : Renderer, private _utility: UtilityService) { }
  ngOnInit() {

  }

  // @TODO - Check if we can remove the setTimeOut
  /*placeFocus() {
    setTimeout(function(){ $('#genericErrorBlock').focus(); }, 0);
  }*/

  @Input('formToValidate')
  set updateFormToValidate(formToValidate) {
    if (formToValidate) {
      this.formToValidate = formToValidate;
      this.formFields = formToValidate.controls;
    }
  }

  @Input('enableValidation')
  set updateFlag(enableValidation) {
    this.enableValidation = enableValidation;
  }

  @Input('errorMessageObject')
  set updateFormErrorObj(errorMessageObject) {
    this.errorMessages = errorMessageObject;
  }
  /**
   * Method to return form field names as keys from form
   */
   formFieldNames() : Array<string> {
    return Object.keys(this.formFields);
  }

  /**
   * Method to get focus on a particular element based on Id.
   */
  focusOnElem(formField){
    let isIOS = this._utility.getUserAgent() === 'IOS_MOBILE' || this._utility.getUserAgent() === 'IOS_TABLET';
    if(formField === 'agreement' && isIOS){
      window.scrollTo(0,document.getElementById(formField).offsetTop);
    }else{
    const element = this.renderer.selectRootElement('#'+formField);
    element.focus();
    }
  }
}
