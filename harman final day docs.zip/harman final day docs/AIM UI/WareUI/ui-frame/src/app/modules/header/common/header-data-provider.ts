import { Observable } from "rxjs";
import { UserMenuComponentUiConfiguration, UserMenuTimeZoneInformation } from "../components/user-menu/user-menu.component";

export interface HeaderData {
    applicationTitle: string;
    headerTitle: string;
    versionNumber: string;
    currentLocale: string;
    network: string;
    networkTimeZoneName: string;
    manualAddress: string;
    uiConfiguration: UserMenuComponentUiConfiguration;
    uiDateConfigurationsAvailable: Map<string, { format: string; separator: string }>;
    userInformation: any;
    userSettingsUrl: string;
    localTimeZoneQuessedName: string;
}

export abstract class HeaderDataProvider {
    abstract getHeaderData(): Observable<HeaderData>;
    abstract getAvailableUILanguages(): Observable<Array<{ code: string; name: string }>>;
    abstract getUITimeZoneInformation(): Observable<UserMenuTimeZoneInformation>;
}
