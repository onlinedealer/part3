import { CommonModule } from "@angular/common";
import { EditColumnDialogComponent } from "./components/edit-column-dialog/edit-column-dialog.component";
import { effects } from "./store/effects";
import { EffectsModule } from "@ngrx/effects";
import { FlexLayoutModule } from "@angular/flex-layout";
import { FormsModule } from "@angular/forms";
import { LandisgyrChartsModule } from "./modules/lg-charts/lg-charts.module";
import { LandisGyrDateAdapterService } from "../Shared/services/landis-gyr-date-adapter.service";
import { LandisgyrTableModule } from "./modules/lg-table/lg-table.module";
import { MaterialModule } from "../material.module";
import { MeteringPointsRoutingModule } from "./meteringpoints-routing.module";
import { NgModule } from "@angular/core";
import { NgxChartsModule } from "@swimlane/ngx-charts";
import { NgxTrimDirectiveModule } from "ngx-trim-directive";
import { NgApexchartsModule } from "ng-apexcharts";
import { pipes } from "./pipes";
import { PortalModule } from "@angular/cdk/portal";
import { ReactiveFormsModule } from "@angular/forms";
import { reducers } from "./store/reducers";
import { RelayControlModule } from "./RelayControl/relaycontrol.module";
import { SharedModule } from "../Shared/shared.module";
import { SSContractsComponent } from "./containers/secondary-sideview/ss-contracts/ss-contracts.component";
import { SSMeteringComponent } from "./containers/secondary-sideview/ss-metering/ss-metering.component";
import { SSMeteringPointStatesComponent } from "./containers/secondary-sideview/ss-mpstates/ss-meteringpointstates.component";
import { SSRegistersComponent } from "./containers/secondary-sideview/ss-registers/ss-registers.component";
import { SSRelaysComponent } from "./containers/secondary-sideview/ss-relays/ss-relays.component";
import { SSTransformerFactorsComponent } from "./containers/secondary-sideview/ss-transformer-factors/ss-transformer-factors.component";
import { SSPrepaymentTokenLogsComponent } from "./containers/secondary-sideview/ss-token-log/ss-prepayment-token-logs.component";
import { StoreModule } from "@ngrx/store";
import * as fromComponents from "./components";
import * as fromContainers from "./containers";
@NgModule({
    imports: [
        NgxChartsModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        FlexLayoutModule,
        MeteringPointsRoutingModule,
        StoreModule.forFeature("meteringPointsFeature", reducers),
        EffectsModule.forFeature(effects),
        LandisgyrTableModule,
        SharedModule,
        LandisgyrChartsModule,
        PortalModule,
        RelayControlModule,
        NgxTrimDirectiveModule,
        NgApexchartsModule
    ],
    declarations: [
        ...fromContainers.containers,
        ...fromComponents.components,
        ...pipes,
        SSRegistersComponent,
        SSMeteringComponent,
        SSContractsComponent,
        SSMeteringPointStatesComponent,
        SSRelaysComponent,
        SSTransformerFactorsComponent,
        SSPrepaymentTokenLogsComponent,
        EditColumnDialogComponent
    ],
    exports: [...fromContainers.containers, ...fromComponents.components, ...pipes]
})
export class MeteringPointsModule {}
