import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ControlContainer, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { ServersApiService } from '../../../../servers/shared/servers-api.service';
import { Connection } from '../../../shared/connection';
import { OrderbyascPipe } from '../../../../shared/pipes/dynamic-dropdown-sort.pipe';
import { OracleFormComponent, ORACLE_CONNECTION_PARAMETERS } from './oracle-form.component';
import { Server } from 'src/app/servers/shared/server';
import { ServiceInjector } from '../../../../shared/services/service.injector';
import { MockConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component.spec';

describe('OracleFormComponent', () => {
  let component: OracleFormComponent;
  let fixture: ComponentFixture<OracleFormComponent>;
  let serversService: ServersApiService;
  const runtimeServer = {
    id: '1',
    hostname: 'test'
  } as Server;
  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  class mockInjector {
    get() {
      return {};
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule, DropdownModule, CheckboxModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ],
      declarations: [OracleFormComponent, OrderbyascPipe, MockConnectionCredentialsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    ServiceInjector.injector = new mockInjector();
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(OracleFormComponent);
    component = fixture.componentInstance;
    serversService = TestBed.inject(ServersApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should toggle container visibility', () => {
    component.pluggableDatabaseChanged(true);
    expect(component.isContainerSectionVisible).toBe(true);
  });

  it('should return connection', () => {
    component.oracleFormGroup.patchValue({
      database: 'test',
      testUser: 'user',
      testPassword: 'pwd',
      instanceName: 'test',
      jdbcDriverVersion: 'ORACLE11',
      jdbcEncryption: false
    });
    const connection: Connection = component.getConnection(true);
    expect(connection.database).toBe('test');
  });

  it('should set connection form for Oracle 12', () => {
    const dataConnection = {
      accessFromServer: { id: '1' },
      database: 'test',
      parameters: [
        { key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_INSTANCE_NAME, value: 'orcl' },
        { key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_DRIVER_VERSION, value: 'ORACLE12' },
        { key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_SUPPORT_PLUGGABLE, value: 'true' },
        { key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_ROOT_CONTAINER_USER_ID, value: 'user' },
        { key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD, value: 'test' },
        { key: ORACLE_CONNECTION_PARAMETERS.JDBC_ENCRYPTION, value: 'false' }
      ]
    } as Connection;
    component.selectedRuntimeServer = runtimeServer;
    component.connection = dataConnection;
    expect(component.oracleFormGroup.get('database').value).toBe('test');
  });

  it('should set connection form for Oracle 11', () => {
    const dataConnection = {
      accessFromServer: { id: '1' },
      database: 'test',
      parameters: [
        { key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_INSTANCE_NAME, value: 'orcl' },
        { key: ORACLE_CONNECTION_PARAMETERS.ORACLE_JDBC_DRIVER_VERSION, value: 'ORACLE11' },
        { key: ORACLE_CONNECTION_PARAMETERS.JDBC_ENCRYPTION, value: 'false' }
      ]
    } as Connection;
    component.selectedRuntimeServer = runtimeServer;
    component.connection = dataConnection;
    expect(component.oracleFormGroup.get('database').value).toBe('test');
  });

  it('should return connection with pluggable options', () => {
    component.oracleFormGroup.patchValue({
      database: 'test',
      testUser: 'user',
      testPassword: 'pwd',
      instanceName: 'test',
      jdbcDriverVersion: 'ORACLE12',
      jdbcEncryption: false,
      containerPassword: 'pwd',
      pluggableDatabase: true
    });
    let pluggableConnection = component.getConnection(true);
    expect(pluggableConnection.database).toBe('test');
    expect(pluggableConnection.parameters.some((parameter) => parameter.key === 'ORACLE_JDBC_SUPPORT_PLUGGABLE')).toBe(true);
    expect(pluggableConnection.parameters.find((parameter) => parameter.key === 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD').value).toBe('');
    component.hasContainerPasswordChanged = true;
    pluggableConnection = component.getConnection(true);
    expect(pluggableConnection.parameters.find((parameter) => parameter.key === 'ORACLE_JDBC_ROOT_CONTAINER_USER_PASSWORD').value).toBe(
      'pwd'
    );
  });

  it('should handle container password change event', () => {
    component.oracleFormGroup.patchValue({ containerPassword: 'pwd' });
    expect(component.oracleFormGroup.get('containerPassword').value).toBe('pwd');
    component.containerPasswordChanged();
    expect(component.hasContainerPasswordChanged).toBe(true);
    expect(component.oracleFormGroup.get('containerPassword').value).toBe('');
    component.containerPasswordChanged();
    expect(component.hasContainerPasswordChanged).toBe(true);
  });

  it('should toggle container visibility when jdbc driver version changes', () => {
    component.jdbcDriverVersionChanged('ORACLE11');
    expect(component.isContainerSectionVisible).toBe(false);
    component.oracleFormGroup.patchValue({
      pluggableDatabase: false
    });
    component.jdbcDriverVersionChanged('ORACLE12');
    expect(component.isContainerSectionVisible).toBe(false);
    component.oracleFormGroup.patchValue({
      pluggableDatabase: true
    });
    component.jdbcDriverVersionChanged('ORACLE12');
    expect(component.isContainerSectionVisible).toBe(true);
  });

  it('should require the credentials', () => {
    component.oracleFormGroup.patchValue({
      database: 'test',
      testUser: 'user',
      testPassword: 'pwd',
      instanceName: 'test',
      jdbcDriverVersion: 'ORACLE12',
      jdbcEncryption: false,
      containerUser: 'cUser',
      containerPassword: 'cPwd',
      pluggableDatabase: false
    });
    spyOn(component.credentialsComponent, 'requireCredentials');
    component.requireCredentials();
    expect(component.credentialsComponent.requireCredentials).toHaveBeenCalled();
    component.oracleFormGroup.patchValue({ pluggableDatabase: true });
    expect(component.oracleFormGroup.get('containerUser').value).toBe('cUser');
    expect(component.oracleFormGroup.get('containerPassword').value).toBe('cPwd');
    component.requireCredentials();
    expect(component.oracleFormGroup.get('containerUser').value).toBe('');
    expect(component.oracleFormGroup.get('containerPassword').value).toBe('');
  });
});
