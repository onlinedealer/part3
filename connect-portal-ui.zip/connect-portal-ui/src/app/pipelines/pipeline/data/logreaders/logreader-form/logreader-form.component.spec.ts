import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DropdownModule } from 'primeng/dropdown';
import { AutoCompleteModule } from 'primeng/autocomplete';
import { getTranslocoModule } from '../../../../../core/transloco-testing.module';
import { LogReaderFormComponent } from './logreader-form.component';
import { Connection } from '../../../../../connections/shared/connection';
import { LogReader } from '../../shared/logreader';
import { ExcludeusersSidebarComponent } from '../excludeusers-sidebar/excludeusers-sidebar.component';

describe('LogReaderFormComponent', () => {
  let component: LogReaderFormComponent;
  let fixture: ComponentFixture<LogReaderFormComponent>;

  const mockedSourceConnection = {
    id: '1',
    connectionType: 'DB2I',
    journalName: 'Journal1',
    name: 'DB2IConnection'
  } as Connection;

  @Component({
    selector: 'p-connect-excludeusers-sidebar',
    template: '',
    providers: [
      {
        provide: ExcludeusersSidebarComponent,
        useClass: MockExcludeUsersSidebarComponent
      }
    ]
  })
  class MockExcludeUsersSidebarComponent {
    open() {}
  }

  const mockDefaultLogReader = {
    name: '',
    journalName: '',
    parameters: [
      {
        key: 'REP_CLEAR_PF_MEMBER',
        value: 'N'
      },
      {
        key: 'DEDICATED_QUEUE',
        value: 'N'
      },
      {
        key: 'COMMIT_WAIT_TIME',
        value: '2'
      },
      {
        key: 'READER_WAIT_TIME',
        value: '1'
      },
      {
        key: 'UPDATE_STATS_FREQ',
        value: '60'
      },
      {
        key: 'MESSAGE_CHECK_FREQ',
        value: '20'
      },
      {
        key: 'SUBS_BIN_0',
        value: ''
      },
      {
        key: 'DEL_JRN_RCV',
        value: 'Y'
      },
      {
        key: 'KEEP_UNSAVED_JRN_RCV',
        value: 'Y'
      },
      {
        key: 'KEEP_JRN_RCV',
        value: '2'
      },
      {
        key: 'TRACING_TABLE',
        value: '3'
      },
      {
        key: 'TRACING_CONSOLE',
        value: '0'
      },
      {
        key: 'TRACING_LOG_FILE',
        value: '4'
      },
      {
        key: 'TRACING_MAX_NB_LOG_CREATED',
        value: '10'
      },
      {
        key: 'TRACING_LOG_INTERVAL',
        value: '3'
      },
      {
        key: 'TRACING_LOG_SIZE',
        value: '10'
      },
      {
        key: 'TRACING_SQL_BASE_TBL_REF',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_SHADOW_TBL_REF',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_CONFLICT_DET_AND_RES',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_FROM_MESS_SYSTEM',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_ALL_OTHER_QUERIES',
        value: 'N'
      },
      {
        key: 'TRACING_SQL_ROLLBACK_AND_COMMIT',
        value: 'N'
      },
      {
        key: 'TRACING_INC_MESS_NB',
        value: 'Y'
      },
      {
        key: 'TRACING_MONITOR_STATS',
        value: 'Y'
      }
    ]
  } as LogReader;

  const mockedSourceConnection1 = {
    id: '1',
    connectionType: 'DB2',
    journalName: '',
    name: 'DB2Connection'
  } as Connection;

  it('should create for DB2', () => {
    component.sourceDataConnection = mockedSourceConnection1;
    component.ngOnInit();
    expect(component.logReaderFormGroup.controls.name.value).toBe('UDBCS1');
  });

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        HttpClientTestingModule,
        CheckboxModule,
        RadioButtonModule,
        FormsModule,
        ReactiveFormsModule,
        DropdownModule,
        AutoCompleteModule,
        getTranslocoModule()
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: 'logreaders' } }],
      declarations: [LogReaderFormComponent, MockExcludeUsersSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogReaderFormComponent);
    component = fixture.componentInstance;
    component.sourceDataConnection = mockedSourceConnection;
    jasmine.getEnv().allowRespy(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open exclude users sidebar when button is clicked', () => {
    const sidebarOpen = spyOn(component.excludeSidebarComponent, 'open');
    component.displayExcludeUsers();
    expect(sidebarOpen).toHaveBeenCalled();
  });

  describe('add log reader', () => {
    it('should open in add mode', fakeAsync(() => {
      spyOn(component, 'resetForm').and.callThrough();
      component.open();
      expect(component.resetForm).toHaveBeenCalled();
      expect(component.logReaderFormGroup.controls.name.value).toBe('');
      expect(component.logReaderFormGroup.controls.journals.value).toBe('');
      expect(component.logReaderFormGroup.controls.journals.enabled).toBe(true);
      expect(component.journals.length).toBe(0);
    }));

    it('should retrieve the default state of the form as a log reader', fakeAsync(() => {
      component.open();
      const logReader = component.logReader;
      expect(logReader).toEqual(mockDefaultLogReader);
    }));

    it('should retrieve the default state of the form as a log reader for DB2', fakeAsync(() => {
      const mockDB2LogReader = {
        name: '',
        journalName: 'aba',
        parameters: [
          { key: 'TRACING_TABLE', value: '1' },
          { key: 'TRACING_CONSOLE', value: '2' },
          { key: 'TRACING_LOG_FILE', value: '3' }
        ]
      };
      component.sourceDataConnection = mockedSourceConnection1;
      component.open();
      const logReader = component.logReader;
      expect(component.logReader.journalName).toEqual('aba');
    }));

    it('should retrieve the changed state of the form as a log reader', fakeAsync(() => {
      component.open();
      component.logReaderFormGroup.controls.sqlStatementOptions.setValue(['TRACING_SQL_ALL_OTHER_QUERIES']);
      component.logReaderFormGroup.controls.miscellaneousOptions.setValue([]);
      const expectedLogReader = JSON.parse(JSON.stringify(mockDefaultLogReader));
      expectedLogReader.parameters[20].value = 'Y';
      expectedLogReader.parameters[21].value = 'N';
      expectedLogReader.parameters[22].value = 'N';
      expectedLogReader.parameters[23].value = 'N';
      const logReader = component.logReader;
      expect(logReader).toEqual(expectedLogReader);
    }));

    it('should add excluded users if there are any', () => {
      component.usersExcludedFromCapture.push('user1');
      const expectedLogReader = JSON.parse(JSON.stringify(mockDefaultLogReader));
      expectedLogReader.parameters.splice(16, 0, { key: 'IBMI_EXCLUDED_USERS', value: 'user1' });
      expect(component.logReader).toEqual(expectedLogReader);
    });

    it('should report an error for incorrect log reader name', fakeAsync(() => {
      const input: HTMLInputElement = fixture.debugElement.query(By.css('input[data-cy="logreaderName"]')).nativeElement;
      input.value = 'invalid log reader name';
      input.dispatchEvent(new Event('input'));
      input.dispatchEvent(new Event('blur'));
      tick();
      fixture.whenStable().then(() => {
        expect(component.logReaderFormGroup.errors.logreaderNameInvalid).toBe(true);
      });
    }));

    it('should report an error for invalid commit wait time', fakeAsync(() => {
      const controlName = 'commitWaitTime';
      const minValue = '0';
      const maxValue = '101';
      const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
      input.value = minValue;
      input.dispatchEvent(new Event('input'));
      input.dispatchEvent(new Event('blur'));
      tick();
      fixture.whenStable().then(() => {
        expect(component.isControlInvalid(controlName)).toBe(true);
        input.value = maxValue;
        input.dispatchEvent(new Event('input'));
        input.dispatchEvent(new Event('blur'));
        tick();
        fixture.whenStable().then(() => {
          expect(component.isControlInvalid(controlName)).toBe(true);
        });
      });
    }));

    it('should report an error for invalid reader wait time', fakeAsync(() => {
      const controlName = 'readerWaitTime';
      const minValue = '-1';
      const maxValue = '601';
      const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
      input.value = minValue;
      input.dispatchEvent(new Event('input'));
      input.dispatchEvent(new Event('blur'));
      tick();
      fixture.whenStable().then(() => {
        expect(component.isControlInvalid(controlName)).toBe(true);
        input.value = maxValue;
        input.dispatchEvent(new Event('input'));
        input.dispatchEvent(new Event('blur'));
        tick();
        fixture.whenStable().then(() => {
          expect(component.isControlInvalid(controlName)).toBe(true);
        });
      });
    }));

    it('should report an error for invalid update stats frequency', fakeAsync(() => {
      const controlName = 'updateStatsFrequency';
      const minValue = '0';
      const maxValue = '61';
      const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
      input.value = minValue;
      input.dispatchEvent(new Event('input'));
      input.dispatchEvent(new Event('blur'));
      tick();
      fixture.whenStable().then(() => {
        expect(component.isControlInvalid(controlName)).toBe(true);
        input.value = maxValue;
        input.dispatchEvent(new Event('input'));
        input.dispatchEvent(new Event('blur'));
        tick();
        fixture.whenStable().then(() => {
          expect(component.isControlInvalid(controlName)).toBe(true);
        });
      });
    }));

    it('should report an error for invalid message check frequency', fakeAsync(() => {
      const controlName = 'messageCheckFrequency';
      const minValue = '9';
      const maxValue = '31';
      const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
      input.value = minValue;
      input.dispatchEvent(new Event('input'));
      input.dispatchEvent(new Event('blur'));
      tick();
      fixture.whenStable().then(() => {
        expect(component.isControlInvalid(controlName)).toBe(true);
        input.value = maxValue;
        input.dispatchEvent(new Event('input'));
        input.dispatchEvent(new Event('blur'));
        tick();
        fixture.whenStable().then(() => {
          expect(component.isControlInvalid(controlName)).toBe(true);
        });
      });
    }));

    it('should report an error for invalid keep journal receivers', fakeAsync(() => {
      const controlName = 'keepJournalReceivers';
      const minValue = '-1';
      const maxValue = '1000';
      const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
      input.value = minValue;
      input.dispatchEvent(new Event('input'));
      input.dispatchEvent(new Event('blur'));
      tick();
      fixture.whenStable().then(() => {
        expect(component.isControlInvalid(controlName)).toBe(true);
        input.value = maxValue;
        input.dispatchEvent(new Event('input'));
        input.dispatchEvent(new Event('blur'));
        tick();
        fixture.whenStable().then(() => {
          expect(component.isControlInvalid(controlName)).toBe(true);
        });
      });
    }));

    it('should report an error for invalid log size', fakeAsync(() => {
      const controlName = 'logSize';
      const minValue = '-1';
      const maxValue = '100';
      const input: HTMLInputElement = fixture.debugElement.query(By.css(`input[data-cy="${controlName}"]`)).nativeElement;
      input.value = minValue;
      input.dispatchEvent(new Event('input'));
      input.dispatchEvent(new Event('blur'));
      tick();
      fixture.whenStable().then(() => {
        expect(component.isControlInvalid(controlName)).toBe(true);
        input.value = maxValue;
        input.dispatchEvent(new Event('input'));
        input.dispatchEvent(new Event('blur'));
        tick();
        fixture.whenStable().then(() => {
          expect(component.isControlInvalid(controlName)).toBe(true);
        });
      });
    }));

    it('should disable appropriate controls when delete journals is set to false', fakeAsync(() => {
      component.deleteJournalReceiversClicked(false);
      expect(component.logReaderFormGroup.controls.keepUnsavedJournalReceiver.disabled).toBe(true);
      expect(component.logReaderFormGroup.controls.keepJournalReceivers.disabled).toBe(true);
    }));

    it('should emit when refresh button is clicked', fakeAsync(() => {
      spyOn(component.refreshClickEvent, 'emit').and.callThrough();
      component.refreshJournalsClicked();
      expect(component.refreshClickEvent.emit).toHaveBeenCalled();
    }));

    it('should set the log reader name to the selected journal name', fakeAsync(() => {
      const journalName = 'New Journal';
      component.onJournalChange(journalName);
      expect(component.logReaderFormGroup.controls.name.value).toBe(journalName);
    }));

    it('should filter the journals', fakeAsync(() => {
      component.journals = ['1journal', '2journal'];
      component.filterJournals({ query: '2j' });
      expect(component.filteredJournals).toEqual([component.journals[1]]);
    }));
  });

  describe('edit log reader', () => {
    it('should open in edit mode', fakeAsync(() => {
      const logReader = { ...mockDefaultLogReader };
      logReader.name = 'New Log Reader';
      logReader.journalName = 'New Journal';
      component.open(logReader);
      expect(component.logReaderFormGroup.controls.name.value).toBe(logReader.name);
      expect(component.logReaderFormGroup.controls.journals.value).toBe(logReader.journalName);
      expect(component.logReaderFormGroup.controls.journals.disabled).toBe(true);
      expect(component.journals.length).toBe(0);
    }));

    it('should keep log reader name and journal when we reset the form', fakeAsync(() => {
      const logReader = { ...mockDefaultLogReader };
      logReader.name = 'New Log Reader';
      logReader.journalName = 'New Journal';
      component.open(logReader);
      component.resetForm();
      expect(component.logReaderFormGroup.controls.name.value).toBe(logReader.name);
      expect(component.logReaderFormGroup.controls.journals.value).toBe(logReader.journalName);
    }));
  });
});
