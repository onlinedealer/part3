import { Injectable } from '@angular/core';
import { Router, Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { AjaxUtilityService } from '../utility/ajax-utility.service';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/of';
import 'rxjs/add/operator/map';
import { CookieUtilityService } from '../utility/cookie-utility.service';
import { RouteConfigurations } from '../utility/club-constants.service';

@Injectable()
export class GetDigitalProfileResolver implements Resolve<any> {

  constructor(
    private _router: Router,
    private _ajax: AjaxUtilityService,
    private _cookieService: CookieUtilityService
  ) { }

  resolve(route: ActivatedRouteSnapshot): Observable<any> | boolean {
    return this._ajax.sendRequest('getDigitalProfile')
    .map((data) => {
      this.statusChecker(data);
      return data;
    })
    .catch((err) => {
      // if service does not respond use the catch block
      this.statusChecker(err);
      return Observable.of({'status': 'Fail', 'statusCode': '404'});
    });
  }

  statusChecker(data) {
    if (this._cookieService.exists('SCC_COOKIE')) {
      if (data.hasOwnProperty('getDigitalProfileResponse') &&
      data['getDigitalProfileResponse'].hasOwnProperty('header') &&
      '0000' === data['getDigitalProfileResponse']['header']['statusCode']) {
        if (!data['getDigitalProfileResponse']['additionalDetails']['ecTied']) {
          this._router.navigate(['/' + RouteConfigurations.clubRegistration]);
        }
        if ('ENROLLED' === data['getDigitalProfileResponse']['additionalDetails']['carePassEnrollmentStatus']) {
          this._router.navigate(['/' + RouteConfigurations.clubDashboard]);
        }
      }
    }else {
      this._router.navigate(['/' + RouteConfigurations.clubRegistration]);
    }
  }
}
