import { Injectable } from '@angular/core';
import { ErrorMessage } from '@precisely/prism-ng/cloud';

@Injectable({
  providedIn: 'root'
})
export class CatalogingErrorSidebarService {
  errorMessages: ErrorMessage[] = [];

  add(errorMessages: ErrorMessage[]): void {
    this.errorMessages.unshift(...errorMessages);
  }

  resetErrorMessages(): void {
    this.errorMessages = [];
  }
}
