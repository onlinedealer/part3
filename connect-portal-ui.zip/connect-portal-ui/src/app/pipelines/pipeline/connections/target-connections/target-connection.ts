import { Observable } from 'rxjs';
import { KafkaTargetComponent } from './kafka/kafka-target.component';

export interface TargetConnection {
  get(): Observable<any>;
}

export const targetConnectionMap = new Map([['KAFKA', KafkaTargetComponent]]);
