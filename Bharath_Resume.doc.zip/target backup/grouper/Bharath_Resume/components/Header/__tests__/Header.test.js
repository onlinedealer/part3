import React from 'react'
import { shallow } from 'enzyme'
import { Header } from '../Header'
import IconButton from '@material-ui/core/IconButton'

describe('Header component', () => {
  it('renders', () => {
    const header = shallow(
      <Header title="Home" />
    )
    expect(header).toHaveLength(1)
  })

  it('renders without an icon button if `props.menuAction` is falsey', () => {
    const header = shallow(
      <Header
        title="Home"
        menuAction={null}
      />
    )
    expect(header.find(IconButton)).toHaveLength(0)
  })

  it('renders an icon button if `props.menuAction` is truthy', () => {
    const header = shallow(
      <Header
        title="Home"
        menuAction={() => {}}
      />
    )
    expect(header.find(IconButton)).toHaveLength(1)
  })
})
