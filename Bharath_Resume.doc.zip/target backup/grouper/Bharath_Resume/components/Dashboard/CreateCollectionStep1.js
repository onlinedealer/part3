import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import * as Constants from '../common/Utils/Constants'
import { getGrouperTypes, getItemTypes, getItemThemes, clearItemThemes, addGroup, clearActionTypes, clearErrorTcins, getCollectionMtas } from '../../store/Dashboard/actionCreator'
import { toggleSnackBar } from '../../store/Snackbar/actionCreator'
import CreateCommonFields from './CreateCommonFields'
import TextField from '@material-ui/core/TextField'
import { changeLaunchDateEditFormat, changeDateToTimestamp } from '../common/Utils/CommonUtils'

const styles = theme => ({
  container: {
    padding: 10,
  },
  formControl: {
    marginTop: 24,
    width: '100%',
  },
  field: {
    marginTop: 24,
  },
  itemCount: {
    float: 'right',
  },
  textHead: {
    fontSize: 13,
    fontWeight: 500,
    marginBottom: 16,
  },
  textHead1: {
    fontSize: 13,
    fontWeight: 500,
  },
  textNormal: {
    fontSize: 13,
    fontWeight: 300,
  },
  textSmall: {
    fontSize: 11,
    fontWeight: 300,
    fontStyle: 'italic',
  },
  createButtonStyle: {
    position: 'relative',
    color: '#fff',
    float: 'right',
    background: '#1976d2',
    fontWeight: 300,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  IconButton: {
    width: '100%',
    height: '100%',
    '&:hover': {
      background: 'transparent',
    },
  },
  displayFlex: {
    display: 'flex',
  },
  chipContainer: {
    maxHeight: '200px',
    overflowY: 'auto',
    marginBottom: 0,
    backgroundColor: '#fff',
  },
})

export class CreateCollectionStep1 extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      group_name: '',
      tcins: [],
      themesFieldsCount: 1,
      formData: {
        group_type: 'collection',
        group_name: '',
        item_type: '',
        tcins: [],
        collection_end_date: '',
      },
      errors: {
        group_type: '',
        item_type: '',
        group_name: '',
        tcins: '',
      },
    }
  }

  componentWillMount () {
    this.setState({ formData: this.props.step1FormData })
  }

  componentWillReceiveProps (nextProps) {
    this.setState({ formData: nextProps.step1FormData })
  }

    validateSubmit = () => {
      const formData = { ...this.state.formData }
      const selItem = _.find(this.props.itemTypes, { 'item_type_id': formData.item_type })
      const errors = { ...this.state.errors }
      let payload = {}
      let isValid = true
      if (!formData.group_type) {
        errors.group_type = Constants.ERROR_GROUP_TYPE_REQ
        isValid = false
      } else {
        this.props.groupTypes.map((grpType) => {
          if (grpType.id === formData.group_type) {
            payload.group_type_id = grpType.id
            payload.group_type = grpType.name
          }
        })
        errors.group_type = ''
      }
      if (!formData.item_type) {
        errors.item_type = Constants.ERROR_ITEM_TYPE_REQ
        isValid = false
      } else {
        payload.item_type_id = formData.item_type
        payload.item_type = selItem.item_type_name
        errors.item_type = ''
      }

      if (!formData.group_name) {
        errors.group_name = Constants.ERROR_GROUP_NAME_REQ
        isValid = false
      } else {
        payload.group_name = formData.group_name
        errors.item_type = ''
      }

      if (formData.tcins.length < 2) {
        errors.tcins = Constants.ERROR_TCIN_REQ
        isValid = false
      } else {
        let tcinData = []
        let count = 0
        formData.tcins.map((tcin) => {
          count++
          tcinData.push({ tcin, action: 'CREATED', sort_order: count })
        })
        payload.tcin_data = tcinData
        errors.tcins = ''
      }

      if (!formData.themes['theme1']) {
        errors.theme1 = Constants.ERROR_THEME1_REQ
        isValid = false
      } else {
        let themesData = []
        this.props.itemThemes.map((theme) => {
          for (let i = 1; i <= Constants.THEME_MAX_COUNT; i++) {
            if (formData.themes[`theme${i}`] === theme.id) {
              themesData.push({ id: theme.id, attribute: theme.name, attribute_type: theme.attribute_type })
            }
          }
        })
        payload.themes = themesData
        errors.themes = ''
      }

      if (isValid) {
        this.props.addGroup(payload, this.props.auth.memberOf, this.props.auth.lanId)
      } else {
        this.setState({ errors })
      }
    }

    handleChange = (name, value) => {
      const formData = { ...this.state.formData }
      formData[name] = value
      this.setState({ formData })
      this.props.onGroupDetails(formData)
    }

    render () {
      const { classes } = this.props
      const { formData } = this.state
      return (
        <div>
          <Grid container className={classes.container}>
            <CreateCommonFields
              groupType="collection"
              onHandleChange={this.handleChange}
              itemTypes={this.props.collectionItemTypes}
              getItemTypes={this.props.getItemTypes}
              getCollectionMtas={this.props.getCollectionMtas}
              clearItemThemes={this.props.clearItemThemes}
              clearErrorTcins={this.props.clearErrorTcins}
              toggleSnackBar={this.props.toggleSnackBar}
              errorTcins={this.props.errorTcins}
              step1FormData={this.state.formData}
            />
            <TextField
              id="date"
              label="End Date"
              type="date"
              defaultValue=""
              className={classes.formControl}
              InputLabelProps={{
                shrink: true,
              }}
              onChange={(e) => this.handleChange('collection_end_date', changeDateToTimestamp(e.target.value))}
              value={changeLaunchDateEditFormat(formData.collection_end_date)}
            />
          </Grid>
        </div>
      )
    }
}

CreateCollectionStep1.propTypes = {
  classes: PropTypes.object.isRequired,
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getGrouperTypes,
    getItemTypes,
    getItemThemes,
    clearItemThemes,
    clearActionTypes,
    addGroup,
    toggleSnackBar,
    clearErrorTcins,
    getCollectionMtas,
  }, dispatch)

const mapStateToProps = state => ({
  auth: state.get('auth').toJS(),
  groupTypes: state.getIn(['grouperDashboard', 'groupTypes']).toJS(),
  itemTypes: state.getIn(['grouperDashboard', 'itemTypes']).toJS(),
  itemThemes: state.getIn(['grouperDashboard', 'itemThemes']).toJS(),
  requestType: state.getIn(['grouperDashboard', 'requestType']),
  recentAddedGroup: state.getIn(['grouperDashboard', 'recentAddedGroup']),
  errorTcins: state.getIn(['grouperDashboard', 'errorTcins']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(CreateCollectionStep1))
