import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Observable, of, throwError } from 'rxjs';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { PipelineMappingService } from '../../../pipeline-mapping.service';
import { ResetDefaultSidebarComponent } from './reset-default-sidebar.component';

describe('ResetDefaultSidebarComponent', () => {
  let component: ResetDefaultSidebarComponent;
  let fixture: ComponentFixture<ResetDefaultSidebarComponent>;
  let mappingService: PipelineMappingService;
  @Component({
    selector: 'p-connect-sidebar',
    template: '',
    providers: [
      {
        provide: SidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    open() {}
    close() {}
    parseHttpClientResponseMessage() {}
  }
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      declarations: [ResetDefaultSidebarComponent, MockSidebarComponent],
      providers: [{ provide: TRANSLOCO_SCOPE, useValue: { scope: '' } }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetDefaultSidebarComponent);
    component = fixture.componentInstance;
    mappingService = TestBed.inject(PipelineMappingService);
    component.checkedItems = [];
    component.pipeline = { id: '1' } as any;
    component.rowData = { table: '1', topic: { name: 'topicName' } };
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open sidebar', () => {
    const openSidebar = spyOn(component.sidebar, 'open');
    component.resetSidebarOpen();
    expect(openSidebar).toHaveBeenCalled();
  });

  it('should close sidebar', () => {
    const closeSidebar = spyOn(component.sidebar, 'close');
    component.close();
    expect(closeSidebar).toHaveBeenCalled();
  });

  it('should call resetToDefault API', () => {
    const resetDefaultSpy = spyOn(mappingService, 'resetToDefault').and.returnValue(of(Observable));
    const closeSidebar = spyOn(component.sidebar, 'close');
    component.primaryButtonClicked();
    expect(resetDefaultSpy).toHaveBeenCalled();
    expect(closeSidebar).toHaveBeenCalled();
  });

  it('should handle error while calling resetToDefault API', () => {
    const errorResponse = { error: { detailedMessage: 'resetDefault failed' } };
    spyOn(component.sidebar, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(mappingService, 'resetToDefault').and.returnValue(throwError(errorResponse));
    component.primaryButtonClicked();
    expect(component.sidebar.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
  });
});
