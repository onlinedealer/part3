import { Injectable } from '@angular/core';

@Injectable()
export class CreditCardService {

    constructor() { }

    private defaultFormat = /(\d{1,4})/g;
    private defaultInputFormat = /(?:^|\s)(\d{4})$/;

    private cards : Array<Object> = [
        {
            type: 'maestro',
            pattern: /^(5018|5020|5038|6304|6759|676[1-3])/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [12, 13, 14, 15, 16, 17, 18, 19],
            cvcLength: [3],
            luhn: true
        }, {
            type: 'dinersclub',
            pattern: /^(36|38|30[0-5])/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [14],
            cvcLength: [3],
            luhn: true
        }, {
            type: 'laser',
            pattern: /^(6706|6771|6709)/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [16, 17, 18, 19],
            cvcLength: [3],
            luhn: true
        }, {
            type: 'jcb',
            pattern: /^35/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [16],
            cvcLength: [3],
            luhn: true
        }, {
            type: 'unionpay',
            pattern: /^62/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [16, 17, 18, 19],
            cvcLength: [3],
            luhn: false
        }, {
            type: 'discover',
            pattern: /^(6011|65|64[4-9]|622)/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [16],
            cvcLength: [3],
            luhn: true
        }, {
            type: 'masterCard',
            pattern: /^(5[0-5]|222[1-9]|22[3-9]|2[3-6]|27[0-1]|272[0])/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [16],
            cvcLength: [3],
            luhn: true
        }, {
            type: 'americanExpress',
            pattern: /^3[47]/,
            format: /(\d{1,4})(\d{1,6})?(\d{1,5})?/,
            inputFormat: /^(\d{4}|\d{4}\s\d{6})$/,
            length: [15],
            cvcLength: [3, 4],
            luhn: true
        }, {
            type: 'visa',
            pattern: /^4/,
            format: this.defaultFormat,
            inputFormat: this.defaultInputFormat,
            length: [13, 14, 15, 16],
            cvcLength: [3],
            luhn: true
        }
    ];

    _fromNumber(num) {
        var card, i, len;
        num = (num + '').replace(/\D/g, '');
        for (i = 0, len = this.cards.length; i < len; i++) {
            card = this.cards[i];
            if (card.pattern.test(num)) {
                return card;
            }
        }
    }

}
