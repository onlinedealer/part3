import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ResetToDefaultSidebarComponent } from './reset-to-default-sidebar.component';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { SidebarComponent } from '../../../../../shared/components/sidebar/sidebar.component';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { Pipeline, TableMapping } from '../../../shared/pipeline';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { PipelineMappingService } from '../../pipeline-mapping.service';
import { Observable, of, throwError } from 'rxjs';
import { FeatureFlagService } from '@shared/services/feature-flag.service';

describe('ResetToDefaultSidebarComponent', () => {
  let component: ResetToDefaultSidebarComponent;
  let fixture: ComponentFixture<ResetToDefaultSidebarComponent>;
  let mappingService: PipelineMappingService;
  let mockFeatureFlagService: any;

  @Component({
    selector: 'p-connect-sidebar',
    template: '',
    providers: [
      {
        provide: SidebarComponent,
        useClass: MockSidebarComponent
      }
    ]
  })
  class MockSidebarComponent {
    open() {}
    close() {}
    parseHttpClientResponseMessage() {}
  }

  beforeEach(async () => {
    mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: '' } },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ],
      declarations: [ResetToDefaultSidebarComponent, MockSidebarComponent],
      schemas: [CUSTOM_ELEMENTS_SCHEMA]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ResetToDefaultSidebarComponent);
    component = fixture.componentInstance;
    component.pipeline = { target: { parameters: [{ key: 'SCHEMA_REGISTRY_ID', value: 'SCHEMAREGISTRY' }] } } as Pipeline;
    component.checkedItems = [];
    mappingService = TestBed.inject(PipelineMappingService);
    jasmine.getEnv().allowRespy(true);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should trigger sidebar open method', () => {
    const openSidebar = spyOn(component.sidebarComponent, 'open');
    component.open([]);
    expect(component.sidebarComponent.open).toHaveBeenCalled();
  });

  it('should trigger sidebar close method', () => {
    const closeSidebar = spyOn(component.sidebarComponent, 'close');
    component.cancelSidebarButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  it('should check disable checkbox if schemaRegistry is available', () => {
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
    component.pipeline = { target: { parameters: [{ key: 'SCHEMA_REGISTRY_ID', value: 'SCHEMAREGISTRY' }] } } as Pipeline;
    component.open([]);
    expect(component.checkboxDisable).toEqual(true);
  });

  it('should have reset button disabled if none of the checkboxes have been filled', () => {
    component.resetTarget = false;
    component.resetFields = false;
    component.onCheck();
    expect(component.resetToDefaultButton.isDisabled).toEqual(true);
  });

  it('should have reset button enabled if any of the checkboxes have been filled', () => {
    component.resetTarget = true;
    component.resetFields = false;
    component.onCheck();
    const resetDisabled = component.resetToDefaultButton.isDisabled;
    expect(resetDisabled).toEqual(false);
  });

  it('should successfully call saveTableMapping API', () => {
    const data = {};
    const saveTableSpy = spyOn(mappingService, 'saveTableMapping').and.returnValue(of(Observable));
    component.open(data);
    expect(saveTableSpy).toHaveBeenCalled();
  });

  it('should handle error for saveTableMapping API', () => {
    const errorResponse = { error: { detailedMessage: 'saveTableMapping failed' } };
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    spyOn(mappingService, 'saveTableMapping').and.returnValue(throwError(errorResponse));
    component.saveTableMapping();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
  });

  it('should successfully call resetDefault API', () => {
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
    component.resetFields = true;
    component.resetButtonClicked();
    const resetDefaultSpy = spyOn(mappingService, 'bulkResetToDefault').and.returnValue(of(Observable));
    const closeSidebarSpy = spyOn(component.sidebarComponent, 'close');
    const emitSpy = spyOn(component.resetBtnClicked, 'emit');
    component.resetButtonClicked();
    expect(resetDefaultSpy).toHaveBeenCalled();
    expect(closeSidebarSpy).toHaveBeenCalled();
    expect(emitSpy).toHaveBeenCalled();
  });

  it('should handle error for resetDefault API', () => {
    spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
    component.resetFields = true;
    const errorResponse = { error: { detailedMessage: 'resetDefault failed' } };
    spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
    const resetSpy = spyOn(mappingService, 'bulkResetToDefault').and.returnValue(throwError(errorResponse));
    component.resetButtonClicked();
    expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalledOnceWith('error', errorResponse);
    expect(resetSpy).toHaveBeenCalled();
  });

  it('should filter the tables by the IDs in checked items', () => {
    const checkeditems = [{ id: 'abc' }, { id: 'efg' }];
    const tableMapping: TableMapping[] = [
      { id: 'abc', key: '', value: '', hasCustomColMappings: false, type: '' },
      { id: 'efg', key: '', value: '', hasCustomColMappings: false, type: '' },
      { id: '123', key: '', value: '', hasCustomColMappings: false, type: '' },
      { id: '456', key: '', value: '', hasCustomColMappings: false, type: '' }
    ];
    const filteredTableMapping = component.filterTableMapping(checkeditems, tableMapping);
    expect(filteredTableMapping).toEqual([
      { id: 'abc', key: '', value: '', hasCustomColMappings: false, type: '' },
      { id: 'efg', key: '', value: '', hasCustomColMappings: false, type: '' }
    ]);
  });
});
