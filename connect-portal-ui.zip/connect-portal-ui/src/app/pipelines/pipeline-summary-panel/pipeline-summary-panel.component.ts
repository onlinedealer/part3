import { Component, EventEmitter, OnDestroy, Output, ViewChild, Input, OnInit } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { ActivatedRoute, Router } from '@angular/router';
import { MenuItem } from 'primeng/api';
import { Subscription } from 'rxjs';
import { first } from 'rxjs/operators';
import { Server } from 'src/app/servers/shared/server';
import { ServersApiService } from 'src/app/servers/shared/servers-api.service';
import { Agent } from '../../agents/shared/agent';
import { AgentsApiService } from '../../agents/shared/agents-api.service';
import { BaseComponent } from '../../core/base.component';
import { DeleteSidebarConfiguration } from '../../shared/components/delete-sidebar/delete-sidebar-configuration';
import { ResourcePermissionService } from '../../shared/services/resource-permission.service';
import { AlertsSidebarComponent } from '../alerts-sidebar/alerts-sidebar.component';
import { PipelineDetailsSidebarComponent } from '../pipeline-details-sidebar/pipeline-details-sidebar.component';
import { LogReadersApiService } from '../pipeline/data/shared/logreaders-api.service';
import { DebugSidebarComponent } from '../shared/debug-sidebar/debug-sidebar.component';
import { LogReaderDetails } from '../shared/pipelines-monitoring-status';
import { StartPipelinesSidebarComponent } from '../start-pipelines-sidebar/start-pipelines-sidebar.component';
import { StopPipelinesSidebarComponent } from '../stop-pipelines-sidebar/stop-pipelines-sidebar.component';
import { ConnectionDetailsSidebarComponent } from './connection-details-sidebar/connection-details-sidebar.component';
import { LogReaderMessagesSidebarComponent } from './log-reader-messages-sidebar/log-reader-messages-sidebar.component';
import { LogReaderDetailsSidebarComponent } from './logreader-details-sidebar/logreader-details-sidebar.component';
import { ManageCaptureSidebarComponent } from './manage-capture-sidebar/manage-capture-sidebar.component';
import { ServerDetailsSidebarComponent } from './server-details-sidebar/server-details-sidebar.component';
import { ClearBacklogSidebarComponent } from './shared/backlog-summary-details/clear-backlog-sidebar/clear-backlog-sidebar.component';
import { StartLogreaderSidebarComponent } from './start-logreader-sidebar/start-logreader-sidebar.component';
import { StartServerSidebarComponent } from './start-server-sidebar/start-server-sidebar.component';
import { StopLogreaderSidebarComponent } from './stop-logreader-sidebar/stop-logreader-sidebar.component';
import { StopServerSidebarComponent } from './stop-server-sidebar/stop-server-sidebar.component';
import { FeatureFlagService } from '@shared/services/feature-flag.service';

@Component({
  selector: 'p-connect-pipeline-summary-panel',
  templateUrl: './pipeline-summary-panel.component.html',
  styleUrls: ['./pipeline-summary-panel.component.scss']
})
export class PipelineSummaryPanelComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild(PipelineDetailsSidebarComponent) pipelineDetailsSidebarComponent: PipelineDetailsSidebarComponent;
  @ViewChild(StartPipelinesSidebarComponent) startPipelinesSidebarComponent: StartPipelinesSidebarComponent;
  @ViewChild(StopPipelinesSidebarComponent) stopPipelinesSidebarComponent: StopPipelinesSidebarComponent;
  @ViewChild(ClearBacklogSidebarComponent) clearBacklogSidebarComponent: ClearBacklogSidebarComponent;

  @ViewChild(LogReaderDetailsSidebarComponent) logReaderDetailsSidebarComponent: LogReaderDetailsSidebarComponent;
  @ViewChild(StartLogreaderSidebarComponent) startLogreaderSidebarComponent: StartLogreaderSidebarComponent;
  @ViewChild(StopLogreaderSidebarComponent) stopLogreaderSidebarComponent: StopLogreaderSidebarComponent;
  @ViewChild(StartServerSidebarComponent) startRuntimeEngineProcessSidebarComponent: StartServerSidebarComponent;
  @ViewChild(StopServerSidebarComponent) stopRuntimeEngineProcessSidebarComponent: StopServerSidebarComponent;
  @ViewChild(ConnectionDetailsSidebarComponent) connectionDetailsSidebarComponent: ConnectionDetailsSidebarComponent;
  @ViewChild(ServerDetailsSidebarComponent) serverDetailsSidebarComponent: ServerDetailsSidebarComponent;
  @ViewChild(ManageCaptureSidebarComponent) manageCaptureSidebarComponent: ManageCaptureSidebarComponent;
  @ViewChild(AlertsSidebarComponent) alertsSidebarComponent: AlertsSidebarComponent;
  @ViewChild(DebugSidebarComponent) debugSidebarComponent: DebugSidebarComponent;

  @Output() alertsButtonClickEvent = new EventEmitter();
  @Output() selectedPipelineRowItemEvent = new EventEmitter();
  @Output() refreshEvent = new EventEmitter();
  @ViewChild(LogReaderMessagesSidebarComponent) logReaderMessagesSidebarComponent: LogReaderMessagesSidebarComponent;
  @Input() deleteSidebarConfiguration: DeleteSidebarConfiguration;

  pipelinesMonitoringStatus: any;
  showSummary: boolean;
  showLogReaders: boolean;
  logReaderSubscription: Subscription;
  currentLogReaders: LogReaderDetails[] = [];
  pipelineTableMenuItems: MenuItem[] = [
    {
      id: 'detailsMenuItem',
      label: 'common.BUTTONS.DETAILS',
      command: () => {
        this.pipelineDetailsSidebarComponent.open(this.pipelinesMonitoringStatus, this.projectName);
      },
      visible: this.resourcePermissionService.hasResourcePermission('PIPELINE.DETAILS')
    },
    {
      id: 'startPipelineMenuItem',
      label: 'common.BUTTONS.START',
      command: () => {
        this.startPipelinesSidebarComponent.open([this.pipelinesMonitoringStatus], this.projectId, this.projectName);
      },
      visible: this.resourcePermissionService.hasResourcePermission('PIPELINE.START')
    },
    {
      id: 'stopPipelineMenuItem',
      label: 'common.BUTTONS.STOP',
      command: () => {
        this.stopPipelinesSidebarComponent.open([this.pipelinesMonitoringStatus], this.projectId, this.projectName);
      },
      visible: this.resourcePermissionService.hasResourcePermission('PIPELINE.STOP')
    },
    {
      separator: true
    },
    {
      id: 'clearBacklogItem',
      label: 'pipelines.PIPELINE_DETAILS.CLEAR_BACKLOG.TITLE',
      command: () => {
        this.displayClearBacklog();
      },
      visible: this.resourcePermissionService.hasResourcePermission('PIPELINE.CLEAR_BACKLOG')
    },
    {
      separator: true
    },
    {
      id: 'editMenuItem',
      label: 'common.BUTTONS.EDIT',
      command: () => {
        this.navigateTo(`pipelines/${this.pipelinesMonitoringStatus.id}/edit/general`);
      },
      visible: this.resourcePermissionService.hasResourcePermission('PIPELINE.EDIT')
    },
    {
      id: 'deleteMenuItem',
      label: 'pipelines.PIPELINES_TABLE.BUTTONS.DELETE',
      command: () => {
        const projectName = this.projectName;
        this.deleteSidebarConfiguration.targetItemsTableData = [{ ...this.pipelinesMonitoringStatus, projectName }];
        this.selectedPipelineRowItemEvent.emit(this.pipelinesMonitoringStatus);
        this.deleteSidebarConfiguration.isSidebarVisible = true;
        this.deleteDisable(this.pipelinesMonitoringStatus);
      },
      visible: this.resourcePermissionService.hasResourcePermission('PIPELINE.DELETE')
    }
  ];

  deleteDisable(data): void {
    if (data.dataFlowType !== 'COPY' && this.isPipelineDeletionNotEnabled(data)) {
      this.deleteSidebarConfiguration.isDeleteButtonDisabled = true;
      this.deleteSidebarConfiguration.bodyText = '';
      this.deleteSidebarConfiguration.subText = '';
      this.deleteSidebarConfiguration.hasCustomBody = true;
    }
  }

  /**
   * Toggles content of delete pipeline sidebar based on if the pipeline hasn't been stopped
   * or has capture status enabled for one or more tables or has backlog rows
   * @param data selected pipeline row item
   */
  isPipelineDeletionNotEnabled(data: any): boolean {
    return (
      (data.captureStatus !== undefined && data.captureStatus !== '' && data.captureStatus !== 'DISABLED') ||
      (data.replicationStatus !== undefined &&
        data.replicationStatus !== 'STOPPED' &&
        data.replicationStatus !== 'COMPLETED' &&
        data.replicationStatus !== 'ACTION_REQUIRED') ||
      (data.pendingRows !== undefined && data.pendingRows !== '-' && data.pendingRows > 0)
    );
  }

  currentAgentName: string;
  server: Server;

  MENU_ITEM = 'pipelines.PIPELINES_SUMMARY.TABLE.MENU_ITEMS';
  connectionTableMenuItems: MenuItem[] = [
    {
      id: 'connectionDetails',
      label: `${this.MENU_ITEM}.DETAILS`,
      command: () => {
        this.connectionDetailsSidebarComponent.open(this.pipelinesMonitoringStatus, this.rowActionSelectedItem.name, this.projectName);
      }
    },
    {
      id: 'manageCapture',
      label: `${this.MENU_ITEM}.MANAGE_CAPTURE`,
      command: () => {
        this.manageCaptureSidebarComponent.open(this.pipelinesMonitoringStatus, this.projectName);
      }
    }
  ];
  logReaderMenuItems: MenuItem[] = [
    {
      id: 'details',
      label: `${this.MENU_ITEM}.DETAILS`,
      command: () => {
        this.logReaderDetailsSidebarComponent.open(this.rowActionSelectedItem, this.projectName);
      }
    },
    {
      id: 'start',
      label: `${this.MENU_ITEM}.START`,
      command: () => {
        this.startLogreaderSidebarComponent.open(this.pipelinesMonitoringStatus.projectId, this.rowActionSelectedItem, this.projectName);
      }
    },
    {
      id: 'stop',
      label: `${this.MENU_ITEM}.STOP`,
      command: () => {
        this.stopLogreaderSidebarComponent.open(this.pipelinesMonitoringStatus.projectId, this.rowActionSelectedItem, this.projectName);
      }
    },
    {
      separator: true
    },
    {
      id: 'log',
      label: `${this.MENU_ITEM}.LOG`,
      command: () => {
        this.logReaderMessagesSidebarComponent.open(this.pipelinesMonitoringStatus, this.rowActionSelectedItem, this.projectName);
      }
    }
  ];
  runtimeEngineMenuItems: MenuItem[] = [
    {
      id: 'runtime-engine-process-details',
      label: `${this.MENU_ITEM}.DETAILS`,
      command: () => {
        this.serverDetailsSidebarComponent.open(
          this.pipelinesMonitoringStatus,
          this.rowActionSelectedItem.name,
          this.projectName,
          this.currentAgentName
        );
      }
    },
    {
      id: 'runtime-engine-process-start',
      label: `${this.MENU_ITEM}.START`,
      command: () => {
        const runtimeServerName = this.pipelinesMonitoringStatus.runtimeServers[0].name;
        const projectId = this.pipelinesMonitoringStatus.projectId;
        this.startRuntimeEngineProcessSidebarComponent.open(projectId, runtimeServerName, this.currentAgentName, this.projectName);
      }
    },
    {
      id: 'runtime-engine-process-stop',
      label: `${this.MENU_ITEM}.STOP`,
      command: () => {
        const projectId = this.pipelinesMonitoringStatus.projectId;
        const runtimeServerName = this.rowActionSelectedItem.name;
        this.stopRuntimeEngineProcessSidebarComponent.open(projectId, runtimeServerName, this.currentAgentName, this.projectName);
      }
    },
    {
      separator: true
    },
    {
      id: 'showAlerts',
      label: `${this.MENU_ITEM}.ALERTS`,
      command: () => {
        this.displayAlertsSidebar(true);
      }
    }
    // Support for debugging runtime server not available: https://jira.syncsort.com/browse/DMX-34327
    // {
    //   separator: true
    // },
    // {
    //   id: 'debugProject',
    //   label: `${this.MENU_ITEM}.DEBUG',
    //   command: () => {
    //     this.debugSidebarComponent.open(this.server);
    //   }
    // }
  ];

  rowActionSelectedItem: any;
  rowActionMenuItems: MenuItem[] = [];
  dataConnectionList = [];
  projectName = '';
  projectId = '';
  isMultipleProjectsEnabled = false;
  selectedPipeline = '';
  schemaCount = 0;
  datasetCount = 0;

  onRefresh() {
    this.refreshEvent.emit();
  }

  getMenuItems(menuItems) {
    menuItems.forEach((menuItem) => {
      menuItem.label = this.translocoService.translate(menuItem.label);
      menuItem.disabled = this.isMenuItemDisabled(menuItem);
      menuItem.visible = this.isMenuVisible(menuItem);
    });
    return menuItems;
  }

  getAllAgents(agentID: string): void {
    this.agentsService
      .getAll()
      .pipe(first())
      .subscribe({
        next: (agents) => {
          const selectedAgent = agents.filter((agent: Agent) => agent.agentId === agentID);
          if (selectedAgent.length) {
            this.currentAgentName = selectedAgent[0].agentName;
          } else {
            this.currentAgentName = '';
          }
        }
      });
  }

  getServerByName(serverName: string): void {
    this.serversService.getByName(serverName).subscribe({
      next: (server: Server) => {
        this.server = server;
      }
    });
  }

  get dataConnections() {
    const connections = [];
    this.pipelinesMonitoringStatus.runtimeServers.forEach((runtimeServer) => {
      runtimeServer.dataConnections.forEach((dataConnection) =>
        connections.push({ ...dataConnection, runtimeServerName: runtimeServer.name })
      );
    });
    return connections;
  }

  getVersionInfo(serverName: string) {
    return this.pipelinesMonitoringStatus.versions.find((versionInfo) => versionInfo.serverName === serverName);
  }

  constructor(
    private readonly agentsService: AgentsApiService,
    private readonly serversService: ServersApiService,
    private readonly logReaderApiService: LogReadersApiService,
    private readonly resourcePermissionService: ResourcePermissionService,
    public readonly translocoService: TranslocoService,
    public router: Router,
    private readonly featureFlagService: FeatureFlagService,
    public readonly activatedRoute: ActivatedRoute
  ) {
    super();
  }

  ngOnInit(): void {
    this.isMultipleProjectsEnabled = this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421');
  }

  open(pipelines, currentPipelineName: string, pipelineStatuses?: any[], projectName?: string) {
    this.selectedPipeline = currentPipelineName;
    this.pipelinesMonitoringStatus = pipelines.find((pipeline) => pipeline.name === currentPipelineName);
    this.getServerByName(this.pipelinesMonitoringStatus.runtimeServers[0].name);
    this.projectName = projectName;
    this.projectId = this.pipelinesMonitoringStatus.projectId;

    this.showLogReaders = this.shouldShowLogReaders();

    this.showSummary = true;
    this.currentLogReaders.length = 0;

    // get schema and table counts
    this.schemaCount = this.pipelinesMonitoringStatus.source ? this.pipelinesMonitoringStatus.source.selectedTables.length : 0;
    const allDatasets = this.pipelinesMonitoringStatus.source
      ? this.pipelinesMonitoringStatus.source.selectedTables.reduce((previousValue, currentValue) => {
          return [...previousValue, ...currentValue.value.tableAndKeys];
        }, [])
      : [];
    this.datasetCount = allDatasets.length;

    if (this.showLogReaders) {
      const logReaders = this.pipelinesMonitoringStatus.runtimeServers
        ?.map((runtimeServer) =>
          runtimeServer.dataConnections
            .filter((connection) => connection.logReaders?.length > 0)
            .map((connection) =>
              connection.logReaders.map((logReader) => ({
                ...logReader,
                dataConnection: connection.name,
                dataConnectionId: this.pipelinesMonitoringStatus.source?.dataConnection.id,
                dataConnectionType: connection.connectionType
              }))
            )
        )
        .flat(2);

      // Get all the log readers for the current pipeline
      logReaders.forEach((logReader) => {
        this.logReaderSubscription = this.logReaderApiService
          .getDataFlows(logReader.dataConnectionId, this.pipelinesMonitoringStatus.projectId, logReader.name)
          .subscribe({
            next: (pipelinesUsed) => {
              if (pipelinesUsed.indexOf(this.pipelinesMonitoringStatus.name) !== -1) {
                // pipelines is used by log reader details
                logReader.pipelines = pipelinesUsed.map((pipelineName) => ({
                  pipelineName,
                  captureStatus: pipelineStatuses?.find((pipeline) => pipeline.name === pipelineName).captureStatus || ''
                }));
                this.currentLogReaders.push(logReader);
              }
            }
          });
      });
    }
    const agentID = this.pipelinesMonitoringStatus.source?.dataConnection.accessFromServer.agentId;
    this.getAllAgents(agentID);
    this.dataConnectionList = this.dataConnections;
  }

  shouldShowLogReaders() {
    const hasLogReader =
      this.pipelinesMonitoringStatus.logReaderStatus !== 'NONE' && this.pipelinesMonitoringStatus.dataFlowType !== 'COPY';

    const hasValidConnection =
      this.dataConnections &&
      this.dataConnections.some((dataConnection) => dataConnection.connectionType === 'DB2' || dataConnection.connectionType === 'DB2I');

    return hasLogReader && hasValidConnection;
  }

  ngOnDestroy() {
    this.logReaderSubscription?.unsubscribe();
  }

  alertsButtonClicked() {
    this.alertsButtonClickEvent.emit();
  }

  private isMenuItemDisabled(menuItem: MenuItem) {
    let overallStatus = this.pipelinesMonitoringStatus?.overallStatus;

    switch (menuItem.id) {
      // Pipeline actions
      case 'startPipelineMenuItem':
        return (
          overallStatus === undefined ||
          this.projectId === undefined ||
          (overallStatus !== 'STOPPED' && overallStatus !== 'COMPLETED' && overallStatus !== 'ACTION_REQUIRED')
        );
      case 'stopPipelineMenuItem':
        return (
          overallStatus === undefined ||
          this.projectId === undefined ||
          overallStatus === 'STOPPED' ||
          overallStatus === 'COMPLETED' ||
          overallStatus === 'ACTION_REQUIRED'
        );
      case 'deleteMenuItem':
      case 'editMenuItem':
      case 'clearBacklogItem':
        return this.projectId ? false : true;

      case 'runtime-engine-process-start':
        return this.rowActionSelectedItem?.status === 'OK';
      case 'runtime-engine-process-stop':
        return this.rowActionSelectedItem?.status === 'STOPPED';
      case 'manageCapture':
        return (
          this.pipelinesMonitoringStatus.dataFlowType === 'COPY' ||
          overallStatus === undefined ||
          (overallStatus !== 'STOPPED' &&
            overallStatus !== 'COMPLETED' &&
            overallStatus !== 'OK' &&
            overallStatus !== 'ACTION_REQUIRED' &&
            overallStatus !== 'ATTENTION')
        );
      default:
        return false;
    }
  }

  private isMenuVisible(menuItem: MenuItem) {
    switch (menuItem.id) {
      case 'runtime-engine-process-start':
        return this.resourcePermissionService.hasResourcePermission('PIPELINE.START_RUNTIME');
      case 'runtime-engine-process-stop':
        return this.resourcePermissionService.hasResourcePermission('PIPELINE.STOP_RUNTIME');
      case 'log':
        return this.resourcePermissionService.hasResourcePermission('PIPELINE.LOGREADER_LOG');
      case 'start':
        return this.resourcePermissionService.hasResourcePermission('PIPELINE.START_LOGREADER');
      case 'stop':
        return this.resourcePermissionService.hasResourcePermission('PIPELINE.STOP_LOGREADER');
      case 'manageCapture':
        return this.rowActionSelectedItem?.source && this.resourcePermissionService.hasResourcePermission('PIPELINE.MANAGE_CAPTURE');
      default:
        return true;
    }
  }

  displayAlertsSidebar(isVisible: boolean): void {
    this.alertsSidebarComponent.open(this.rowActionSelectedItem?.name);
    this.alertsSidebarComponent.renderTable = false;
    setTimeout(() => {
      // Workaround for a bug wherein the table is not rendered on the sidebar unless the
      // browser window is resized (See https://github.com/primefaces/primeng/issues/9766)
      this.alertsSidebarComponent.renderTable = isVisible;
    });
  }

  closePipelineSummaryPanel(): void {
    const projectName = this.activatedRoute.snapshot.paramMap.get('projectName');
    this.navigateTo(`projects/${projectName}`);
  }

  displayClearBacklog(): void {
    this.clearBacklogSidebarComponent.open(this.pipelinesMonitoringStatus);
  }

  hasMonitoringStatusValues(): boolean {
    return this.pipelinesMonitoringStatus && this.pipelinesMonitoringStatus.hasOwnProperty('replicationStatus');
  }

  getStatusIcon(status: string) {
    const commonStyles = 'align-bottom png-icon-sm';

    if (status === 'OK') {
      return commonStyles + ' png-alert-open text-success';
    } else {
      const statusIcon = this.getStatusIconStyleClassList(status);
      if (statusIcon) {
        return commonStyles + ' ' + statusIcon.join(' ');
      } else {
        return '';
      }
    }
  }
}
