import { createSelector } from "@ngrx/store";

import * as fromRoot from "../reducers";
import { RouterReducerState } from "@ngrx/router-store";

export const getRouterState = createSelector(fromRoot.getRouterState, (routerState: RouterReducerState<fromRoot.RouterStateUrl>) =>
    routerState ? routerState.state : undefined
);

export const getParams = createSelector(getRouterState, state => (state ? state.params : undefined));

export const getQueryParams = createSelector(getRouterState, state => (state ? state.queryParams : undefined));

export const getURL = createSelector(getRouterState, state => (state ? state.url : undefined));

export const getSegments = createSelector(getRouterState, state => (state ? state.segments : []));

export const getLastSegment = createSelector(getRouterState, state => (state ? state.lastSegment : undefined));

export const getSegmentsWithParams = createSelector(getSegments, getParams, (segments, params) => ({
    segments,
    params
}));
