export interface XSFSearch {
    condition?: XSFCondition;
    target: string;
    description?: string;
    name?: string;
    orderBy?: XSFOrderBy[];
}

export interface XSFCondition {
    content: XSFCondition[] | string[] | number[];
    operator: string;
    type: string;
    disabled?: boolean;
    matchCase?: boolean;
    property?: string;
}

export interface XSFOrderBy {
    direction: string;
    property: string;
}

export interface XSFQueryResponse {
    groupId: number;
    elementType: string;
    groupName: string;
    elementCount: number;
}

export interface XSFSearchQuery {
    groupId: number;
    rangeStart?: number;
    rangeSize?: number;
    fromTime?: number;
    untilTime?: number;
    orderBy: XSFOrderBy[];
    includeColumns?: string[];
    ranges?: string;
}
