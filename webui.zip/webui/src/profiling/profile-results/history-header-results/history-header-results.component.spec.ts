import { Mocks, Spies } from 'discovery-test';
import { of, throwError } from 'rxjs';

import { HistoryHeaderResultsComponent } from './history-header-results.component';

describe('HistoryHeaderResultsComponent', () => {
  let component: HistoryHeaderResultsComponent;

  beforeEach(() => {
    Spies.init();
    component = new HistoryHeaderResultsComponent(
      Spies.eventBusService,
      Spies.ProfileResultsService,
      Spies.ActivatedRoute,
      Spies.ToastrService
    );
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch history on init', () => {
    Spies.ProfileResultsService.getProfileHistory.and.returnValue(of(Mocks.MockProfileHistory));
    component.ngOnInit();
    expect(component.isLoading).toBe(false);
    expect(component.history.length).toBeGreaterThan(0);
  });

  it('should handle fetch history failed on init', () => {
    Spies.ProfileResultsService.getProfileHistory.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.ngOnInit();
    expect(component.isLoading).toBe(false);
    expect(component.history.length).toBe(0);
    expect(Spies.ToastrService['error']).toHaveBeenCalled();
  });

  it('should navigate previous Stats', () => {
    component.history = Mocks.MockProfileHistory;
    component.activeIndex = 1;
    component.navigateStats('Previous');
    expect(component.activeIndex).toBe(0);
  });

  it('should navigate next Stats', () => {
    component.history = Mocks.MockProfileHistory;
    component.activeIndex = 0;
    component.navigateStats('Next');
    expect(component.activeIndex).toBe(1);
  });

  it('should navigate latest Stats', () => {
    component.history = Mocks.MockProfileHistory;
    component.activeIndex = 1;
    component.navigateStats('Latest');
    expect(component.activeIndex).toBe(0);
  });
});
