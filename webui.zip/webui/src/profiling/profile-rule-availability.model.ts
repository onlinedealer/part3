export class ProfileRuleAvailabilityModel {
  message: string;
  configured: string;
}
