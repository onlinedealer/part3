export class DebugResponse {
  engine?: {
    sqlDebug?: string;
    level?: string;
  };
}
