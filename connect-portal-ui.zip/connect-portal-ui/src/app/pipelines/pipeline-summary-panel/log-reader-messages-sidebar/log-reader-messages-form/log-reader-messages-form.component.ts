import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { TableConfiguration, TableMessage, TableMessageType } from '../../../../shared/components/generic-table/generic-table';
import { catchError, map, tap } from 'rxjs/operators';
import { Observable, of } from 'rxjs';
import { LogReaderDetails, LogReaderLog } from '../../../shared/pipelines-monitoring-status';
import { PipelinesMonitoringApiService } from '../../../shared/pipelines-monitoring-api.service';
import { HttpErrorResponse } from '@angular/common/http';

@Component({
  selector: 'p-connect-log-reader-messages-form',
  templateUrl: './log-reader-messages-form.component.html',
  styleUrls: ['./log-reader-messages-form.component.scss']
})
export class LogReaderMessagesFormComponent {
  @Output() serviceError = new EventEmitter<HttpErrorResponse>();

  logReader: LogReaderDetails;
  projectId: string;
  projectName = '';
  logReaderStatus: string;
  replicationStatus: string;

  logReadersNotStartedMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.TABLE_MESSAGES.LOG_READER_NOT_STARTED.HEAD',
    messageCaption: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.TABLE_MESSAGES.LOG_READER_NOT_STARTED.CAPTION'
  };

  pipelineNotStartedMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.TABLE_MESSAGES.PIPELINE_NOT_STARTED.HEAD',
    messageCaption: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.TABLE_MESSAGES.PIPELINE_NOT_STARTED.CAPTION'
  };

  errorTableMessage: TableMessage = {
    messageType: TableMessageType.ALERT,
    messageHead: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.TABLE_MESSAGES.ERROR.HEAD',
    messageCaption: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.TABLE_MESSAGES.ERROR.CAPTION'
  };

  logMessagesTableConfiguration: TableConfiguration = {
    hideCheckboxColumn: true,
    isLoading: false,
    visibleRows: 25,
    fields: [
      { header: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.MESSAGE', name: 'description', columnStyle: { width: '38rem' } },
      { header: 'pipelines.LOG_READER_MESSAGES_SIDEBAR.LOGGED', name: 'timestamp', isKey: true }
    ],
    tableMessages: {
      emptyTableMessage: this.logReadersNotStartedMessage
    }
  };
  logs$: Observable<LogReaderLog[]>;
  selectedRecentLogEntries = 50;
  renderTable = false;
  lastRefreshedTime: string;

  constructor(private readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService) {}

  /**
   * Makes a service call to fetch the logs
   */
  getLogs() {
    this.updateLastRefreshedTime();
    this.logMessagesTableConfiguration.isLoading = true;
    this.logs$ = this.pipelinesMonitoringApiService
      .getLogs(this.projectId, this.logReader.dataConnection, this.logReader.name, this.selectedRecentLogEntries)
      .pipe(
        tap((logs) => {
          this.logMessagesTableConfiguration.isLoading = false;
          if (logs.length === 0) {
            if (this.replicationStatus !== 'OK') {
              this.logMessagesTableConfiguration.tableMessages.emptyTableMessage = this.pipelineNotStartedMessage;
            } else if (this.logReaderStatus !== 'OK') {
              this.logMessagesTableConfiguration.tableMessages.emptyTableMessage = this.logReadersNotStartedMessage;
            }
          }
        }),
        map((logs) => logs.map((log) => ({ ...log, timestamp: new Date(log.timestamp).toLocaleString() }))),
        catchError((error) => {
          this.logMessagesTableConfiguration.isLoading = false;
          this.serviceError.emit(error);
          return of(error);
        })
      );
  }
  /**
   * Gets the correct icons depending on the log severity
   * @param severity the severity of the log
   * @returns an array of icons
   */
  getAlertStatusIconClass(severity): string[] {
    if (severity === 'ERROR') {
      return ['png-alert-actionrequired-solid', 'text-danger'];
    } else if (severity === 'WARNING') {
      return ['png-alert-attention-solid', 'text-warning'];
    } else if (severity === 'INFORMATION') {
      return ['png-alert-info-solid', 'text-info'];
    }
    return [];
  }

  private updateLastRefreshedTime() {
    this.lastRefreshedTime = new Date().toLocaleString();
  }
}
