import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormGroup, FormControl, FormGroupDirective, FormsModule, ReactiveFormsModule, ControlContainer } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { Server } from 'src/app/servers/shared/server';
import { of, throwError } from 'rxjs';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { OrderbyascPipe } from '../../../../shared/pipes/dynamic-dropdown-sort.pipe';
import { Connection } from '../../../shared/connection';
import { Db2zFormComponent, DB2ZOS_CONNECTION_PARAMETERS } from './db2z-form.component';
import { MockConnectionCredentialsFormComponent } from '../shared/connection-credentials-form/connection-credentials-form.component.spec';
import { SidebarManagerService } from '@precisely/prism-ng/sidebar-manager';

describe('Db2zFormComponent', () => {
  let component: Db2zFormComponent;
  let fixture: ComponentFixture<Db2zFormComponent>;
  let httpClient: HttpClient;
  let sidebarManagerService: SidebarManagerService;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  const runtimeServer = {
    id: '1',
    hostname: 'test'
  } as Server;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule, DropdownModule, CheckboxModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ],
      declarations: [Db2zFormComponent, OrderbyascPipe, MockConnectionCredentialsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(Db2zFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    httpClient = TestBed.inject(HttpClient);
    component.db2Agents = [];
    component.db2AgentTextValue = '';
    component.selectedRuntimeServer = runtimeServer;
    sidebarManagerService = TestBed.inject(SidebarManagerService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open error message sidebar', () => {
    spyOn(sidebarManagerService, 'setActiveSidebar').and.returnValue();
    component.agentHttpErrorResponse = new HttpErrorResponse({ error: 'test' });
    component.openErrorMessageSidebar();
    expect(sidebarManagerService.setActiveSidebar).toHaveBeenCalled();
  });

  it('should set connection form', () => {
    spyOn(component, 'updateAgentsDropdownList').and.returnValue();
    const dataConnection = {
      accessFromServer: { id: '1' },
      database: 'test',
      parameters: [
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_DATABASE_NAME, value: 'database' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_PORT_NUMBER, value: '9999' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_SERVER, value: 'captureServer' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_PORT, value: '9990' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_PRIVATE_KEY, value: 'id_nacl' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_CAPTURE_AGENT, value: 'share5' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_JOB_CARD, value: '' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_JOB_LIB, value: '' },
        { key: DB2ZOS_CONNECTION_PARAMETERS.DB2Z_JCL_INFO_ISPF_LIB, value: '' }
      ]
    } as Connection;
    component.selectedRuntimeServer = runtimeServer;
    component.connection = dataConnection;
    expect(component.db2zConnectionForm.get('database').value).toBe('test');
  });

  it('should return connection', () => {
    component.db2zConnectionForm.patchValue({
      database: 'test'
    });
    const connection: Connection = component.getConnection(false);
    expect(connection.database).toBe('test');
  });

  it('update db2 agent from dropdown', () => {
    component.selectDB2AgentFromDropdown('test');
    expect(component.db2zConnectionForm.get('db2Agent').value).toBe('test');
  });

  it('should disable selectedDb2Agent control if db2CaptureServer is blank', () => {
    component.db2zConnectionForm.patchValue({ db2CaptureServer: '' });
    fixture.detectChanges();
    expect(component.db2zConnectionForm.get('selectedDb2Agent').enabled).toBe(false);
  });

  it('should get list of agents from API', fakeAsync(() => {
    component.ngOnInit();
    spyOn(httpClient, 'get').and.returnValue(of(['test1', 'test2', 'test3']));
    setDb2AgentFormValues();
    component.updateAgentsDropdownList();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2Agents.length).toBe(3);
  }));

  it('should not update db2 agents list of items already exist or if there are duplicates in response', fakeAsync(() => {
    component.ngOnInit();
    component.db2Agents = [{ label: 'test1', value: 'test1' }];
    spyOn(httpClient, 'get').and.returnValue(of(['test1', 'test1']));
    setDb2AgentFormValues();
    component.updateAgentsDropdownList();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2Agents.length).toBe(1);
  }));

  it('should handle no results when calling agents API', fakeAsync(() => {
    component.ngOnInit();
    spyOn(httpClient, 'get').and.returnValue(of([]));
    setDb2AgentFormValues();
    component.updateAgentsDropdownList();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2Agents.length).toBe(0);
  }));

  it('should ensure db2z capture progress message is not displayed when commit is successful', fakeAsync(() => {
    component.ngOnInit();
    spyOn(httpClient, 'get').and.returnValue(of(['test1', 'test2', 'test3']));
    setDb2AgentFormValues();
    component.updateAgentsDropdownList();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2GetAgentStatusMessageInfo).toBeFalsy();
  }));

  it('should update selectedDb2Agent', fakeAsync(() => {
    component.ngOnInit();
    spyOn(httpClient, 'get').and.returnValue(of(['test1', 'test2', 'test3']));
    component.db2zConnectionForm.get('db2Agent').setValue('test');
    setDb2AgentFormValues();
    component.updateAgentsDropdownList();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2zConnectionForm.get('selectedDb2Agent').value).toBe('test');
  }));

  it('should update db2AgentTextValue when no dropdown values return', fakeAsync(() => {
    component.ngOnInit();
    spyOn(httpClient, 'get').and.returnValue(of([]));
    component.db2zConnectionForm.get('db2Agent').setValue('test');
    setDb2AgentFormValues();
    component.updateAgentsDropdownList();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2AgentTextValue).toBe('test');
  }));

  it('should handle errors from get agents API and set db2AgentTextValue', fakeAsync(() => {
    component.ngOnInit();
    spyOn(httpClient, 'get').and.returnValue(throwError({}));
    component.db2zConnectionForm.get('db2Agent').setValue('test');
    setDb2AgentFormValues();
    component.updateAgentsDropdownList();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2AgentTextValue).toBe('test');
  }));

  it('should handle errors from get agents API', fakeAsync(() => {
    component.ngOnInit();
    spyOn(httpClient, 'get').and.returnValue(throwError({}));
    setDb2AgentFormValues();
    tick(1000);
    expect(httpClient.get).toHaveBeenCalled();
    expect(component.db2AgentTextValue).toBe('');
  }));

  const setDb2AgentFormValues = () => {
    component.db2zConnectionForm.get('db2CaptureServer').setValue('10.0.0.1');
    component.db2zConnectionForm.get('db2CaptureServerPort').setValue('9999');
    component.db2zConnectionForm.get('db2CapturePrivateKeyPath').setValue('c://id_nacl');
    component.updateAgentsDropdownList();
  };
});
