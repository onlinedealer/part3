export class HistoryHeaderModel {
  fieldName: string;
  labelName: string;
  isSort: boolean;
  type?: string;
  constructor(header?) {
    if (header) {
      this.fieldName = header.fieldName;
      this.labelName = header.labelName;
      this.isSort = header.isSort;
    }
    this.type = header && header.type ? header.type : 'default';
  }
}
