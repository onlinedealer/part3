import { AlertMetricModel } from './alert-metric.model';

export type DialogAction = 'close' | 'save';
export interface IConfigureMetric {
  action: DialogAction;
  alertId?: string;
  selectedSample: string;
  timeframe: string;
  metric: AlertMetricModel;
  isShowPercentage: boolean;
}
