import { dataService } from './services/data.service';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpModule } from '@angular/http'
import { AppRoutingModule } from './route.module';
import { provideRoutes} from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CanDeactivateGuard } from './can-deactivate.guard';
import { CanActivateGuard } from './can-activate.guard';

import { AppComponent } from './app.component';
import { UserComponent } from './components/user/user.component';
import { RegComponent } from './components/registration/reg.component';
 
@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    RegComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  providers: [dataService, CanDeactivateGuard, CanActivateGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
