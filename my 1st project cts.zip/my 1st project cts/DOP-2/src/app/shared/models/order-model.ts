export class OrderModel {
    public shippingAddress: any;
    public orderBillingInfo: any;
    public externalId: string;
    public orderId: string;
    public orderSubmittedDate: string;
    public extracareCardNumber: string;
    public orderSummary: any;


    constructor(details: any) {
        const order = details;
        this.shippingAddress = order.shippingAddress;
        this.orderBillingInfo = order.orderBillingInfo;
        this.externalId = order.externalId;
        this.orderId = order.orderId;
        this.orderSubmittedDate = order.orderSubmittedDate;
        this.extracareCardNumber = order.extracareCardNumber;
        this.orderSummary = order.orderSummary;
    }
}
