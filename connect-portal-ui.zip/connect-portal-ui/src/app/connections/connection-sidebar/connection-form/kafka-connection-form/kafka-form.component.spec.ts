import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, fakeAsync, tick } from '@angular/core/testing';
import { ControlContainer, FormArray, FormControl, FormGroup, FormGroupDirective, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { Connection } from '../../../shared/connection';
import { OrderbyascPipe } from '../../../../shared/pipes/dynamic-dropdown-sort.pipe';
import { KafkaFormComponent, KAFKA_CONNECTION_PARAMETERS } from './kafka-form.component';
import { Server } from 'src/app/servers/shared/server';
import { ServiceInjector } from '../../../../shared/services/service.injector';

describe('KafkaFormComponent', () => {
  let component: KafkaFormComponent;
  let fixture: ComponentFixture<KafkaFormComponent>;

  const fg: FormGroup = new FormGroup({
    control: new FormControl('')
  });

  const fgd: FormGroupDirective = new FormGroupDirective([], []);
  fgd.form = fg;

  const runtimeServer = {
    id: '1',
    hostname: 'test'
  } as Server;

  class mockInjector {
    get() {
      return {};
    }
  }

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule, DropdownModule, CheckboxModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        {
          provide: ControlContainer,
          useValue: fgd
        }
      ],
      declarations: [KafkaFormComponent, OrderbyascPipe]
    }).compileComponents();
  });

  beforeEach(() => {
    ServiceInjector.injector = new mockInjector();
    fixture = TestBed.createComponent(KafkaFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should add a new broker', () => {
    const brokers = component.kafkaFormGroup.get('brokers') as FormArray;
    component.addBrokerItem();
    expect(brokers.length).toBe(2);
  });

  it('should be able to remove a broker', () => {
    const brokers = component.kafkaFormGroup.get('brokers') as FormArray;
    component.addBrokerItem();
    component.addBrokerItem();
    expect(brokers.length).toBe(3);
    component.removeBrokerItem(1);
    expect(brokers.length).toBe(2);
  });

  it('should return an error if use batch is enabled and batch size is not supplied', fakeAsync(() => {
    component.ngOnInit();
    fixture.detectChanges();
    component.kafkaFormGroup.get('enableBatch').setValue(true);
    component.kafkaFormGroup.get('batchSize').setValue(null);
    tick();
    fixture.whenStable().then(() => {
      expect(component.kafkaFormGroup.get('batchSize').errors).toBeTruthy();
    });
  }));

  it('should return and error if kerberos is enabled and required kerberos fields are missing', () => {
    component.createForm();
    fixture.detectChanges();
    component.kafkaFormGroup.get('useKerberos').setValue(true);
    component.kafkaFormGroup.get('keytabLocation').setValue('keytab');
    component.kafkaFormGroup.get('principal').setValue('');
    expect(component.kafkaFormGroup.errors?.useKerberosError).toEqual({ missingRequiredFields: true });

    component.kafkaFormGroup.get('keytabLocation').setValue('');
    component.kafkaFormGroup.get('principal').setValue('test');
    expect(component.kafkaFormGroup.errors?.useKerberosError).toEqual({ missingRequiredFields: true });

    component.kafkaFormGroup.get('keytabLocation').setValue('keytab');
    component.kafkaFormGroup.get('principal').setValue('test');
    expect(component.kafkaFormGroup.errors?.useKerberosError).toBeUndefined();
  });

  it('should set connection form', () => {
    component.createForm();
    fixture.detectChanges();

    const dataConnection = {
      accessFromServer: { id: '1' },
      database: 'localhost:1024',
      parameters: [
        { key: KAFKA_CONNECTION_PARAMETERS.KAFKA_PRODUCER_CONFIG_FILE_PATH, value: 'c://test' },
        { key: KAFKA_CONNECTION_PARAMETERS.KAFKA_USE_KERBEROS, value: true },
        { key: KAFKA_CONNECTION_PARAMETERS.KAFKA_KERBEROS_PRINCIPAL, value: 'principal' },
        { key: KAFKA_CONNECTION_PARAMETERS.KAFKA_KERBEROS_KEYTAB_LOCATION, value: 'keytab' },
        { key: KAFKA_CONNECTION_PARAMETERS.KAFKA_ENABLE_BATCH, value: true },
        { key: KAFKA_CONNECTION_PARAMETERS.KAFKA_BATCH_SIZE, value: 1000 }
      ]
    } as Connection;
    component.selectedRuntimeServer = runtimeServer;
    component.connection = dataConnection;
    expect(component.kafkaFormGroup.get('configurationFile').value).toBe('c://test');
  });

  it('should return connection', () => {
    component.kafkaFormGroup.patchValue({
      configurationFile: 'test',
      useKerberos: false,
      principal: '',
      keytabLocation: '',
      brokers: [
        { name: 'test', port: 111 },
        { name: 'test2', port: 222 }
      ],
      enableBatch: false,
      batchSize: ''
    });
    const connection: Connection = component.getConnection(false);
    expect(connection.database).toBe('test:111');
  });

  it('should return connection with Kerberos enabled', () => {
    component.kafkaFormGroup.patchValue({
      configurationFile: 'test',
      useKerberos: true,
      principal: 'myPrincipal',
      keytabLocation: 'myKeyTabLocation',
      brokers: [
        { name: 'test', port: 111 },
        { name: 'test2', port: 222 }
      ],
      enableBatch: false,
      batchSize: ''
    });
    const connection: Connection = component.getConnection(false);
    expect(connection.parameters.find((parameter) => parameter.key === 'KAFKA_KERBEROS_PRINCIPAL').value).toBe('myPrincipal');
    expect(connection.parameters.find((parameter) => parameter.key === 'KAFKA_KERBEROS_KEYTAB_LOCATION').value).toBe('myKeyTabLocation');
  });

  it('should return connection with batch enabled', () => {
    component.kafkaFormGroup.patchValue({
      configurationFile: 'test',
      useKerberos: false,
      principal: '',
      keytabLocation: '',
      brokers: [
        { name: 'test', port: 111 },
        { name: 'test2', port: 222 }
      ],
      enableBatch: true,
      batchSize: '2000'
    });
    const connection: Connection = component.getConnection(false);
    expect(connection.parameters.find((parameter) => parameter.key === 'KAFKA_BATCH_SIZE').value).toBe('2000');
  });

  it('should disable batch controls', () => {
    component.enableBatchChanged(false);
    expect(component.kafkaFormGroup.get('batchSize').disabled).toBeTrue();
  });
});
