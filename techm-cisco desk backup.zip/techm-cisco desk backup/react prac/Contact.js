import React from 'react';


class Contact extends React.Component {
		
   render() {
      return (
         <div>
			<h2>Contact Page</h2>
		</div>
      );
   }
}

export default Contact;