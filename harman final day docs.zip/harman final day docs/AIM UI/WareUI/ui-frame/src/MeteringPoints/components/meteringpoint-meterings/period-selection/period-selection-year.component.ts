import {
    Component,
    ChangeDetectionStrategy,
    Input,
    ViewChild,
    ElementRef,
    EventEmitter,
    Output,
    OnDestroy,
    SimpleChanges,
    OnChanges
} from "@angular/core";
import { debounceTime, filter, map } from "rxjs/operators";
import { FormControl } from "@angular/forms";
import { Subscription, Observable } from "rxjs";
import { isEqual } from "lodash";
import * as moment from "moment";
import { MatAutocomplete, AUTOCOMPLETE_OPTION_HEIGHT, AUTOCOMPLETE_PANEL_HEIGHT } from "@angular/material/autocomplete";
import { _countGroupLabelsBeforeOption, _getOptionScrollPosition } from "@angular/material/core";

const NUMBER_OF_YEARS_FOR_SELECTION = 6;
const CURRENT_YEAR = moment().year();

const getYearOptions = () => {
    const year = CURRENT_YEAR;
    const years: number[] = [];
    for (let i = 0; i < NUMBER_OF_YEARS_FOR_SELECTION; i++) {
        years.push(year - i);
    }
    return years.map((val) => val.toString());
};

@Component({
    selector: "landisgyr-period-selection-year",
    templateUrl: "./period-selection-year.component.html",
    styleUrls: ["./period-selection.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PeriodSelectionYearComponent implements OnChanges, OnDestroy {
    static scrollToItem: number;
    static scrollToItemMetering: number;
    static scrollToItemPrepayment: number;
    static scrollToItemTokenlog: number;
    @ViewChild("yearInput", { static: true }) input!: ElementRef<HTMLInputElement>;
    @ViewChild("yearInputDropdown", { static: true }) inputDropdown!: MatAutocomplete;

    @Input()
    disabled = false;

    @Input()
    tab!: string;

    @Input()
    from!: number;

    @Input()
    until!: number;

    @Output()
    timePeriodChange = new EventEmitter<{ from: number; until: number }>();
    selectedYear!: string;
    yearOptions: string[] = getYearOptions();
    yearOptionsTemp: string[] = this.yearOptions;
    yearInputControl = new FormControl({ value: "", disabled: this.disabled });
    index = 0;
    optionHeight = AUTOCOMPLETE_OPTION_HEIGHT;
    panelHeight = AUTOCOMPLETE_PANEL_HEIGHT;

    private yearInputValueChanges$: Observable<any> = this.yearInputControl.valueChanges.pipe(
        debounceTime(200),
        filter((value) => value > 1900 && value < 2100)
    );

    private yearInputChangeSubscription: Subscription = this.yearInputValueChanges$.subscribe((value) => {
        this.timePeriodChange.emit({
            from: this.getPeriodStartAsEpoch(value),
            until: this.getPeriodEndAsEpoch(value)
        });
    });

    constructor() {}

    ngOnChanges(changes: SimpleChanges) {
        if (this.inputDropdown) {
            if (this.tab === "metering") {
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemMetering);
            }
            if (this.tab === "prepayment") {
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemPrepayment);
            }
            if (this.tab === "tokenlog") {
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemTokenlog);
            }
        }
        if (this.until) {
            const newYearValue = moment(this.until).format("YYYY");
            this.selectedYear = newYearValue;
            if (isEqual(newYearValue, this.yearInputControl.value) === false) {
                this.yearInputControl.setValue(newYearValue);
            }
        }

        if (this.disabled) {
            this.yearInputControl.disable();
        } else {
            this.yearInputControl.enable();
        }
    }
    selected(event: any, selectedItem: any) {
        PeriodSelectionYearComponent.scrollToItem = this.inputDropdown._getScrollTop();
        const last = this.inputDropdown.options.last;
        if (event.source.selected) {
            if (selectedItem === last.value) {
                PeriodSelectionYearComponent.scrollToItem = 32;
            }
            if (this.tab === "metering") {
                PeriodSelectionYearComponent.scrollToItemMetering = PeriodSelectionYearComponent.scrollToItem;
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemMetering);
            }
            if (this.tab === "prepayment") {
                PeriodSelectionYearComponent.scrollToItemPrepayment = PeriodSelectionYearComponent.scrollToItem;
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemPrepayment);
            }
            if (this.tab === "tokenlog") {
                PeriodSelectionYearComponent.scrollToItemTokenlog = PeriodSelectionYearComponent.scrollToItem;
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemTokenlog);
            }
        }
    }
    filterData() {
        const searchText = this.input.nativeElement.value;
        setTimeout(() => {
            this.input.nativeElement.focus();
        });
        if (searchText) {
            this.yearOptions = this.yearOptionsTemp.filter((yearList) => {
                return yearList.startsWith(searchText);
            });
        } else {
            this.yearOptions = getYearOptions();
        }
    }
    resetInput() {
        this.input.nativeElement.blur();
        this.onInputArrowDownClick();
        this.yearInputControl.setValue("");
    }
    onOutFocus() {
        if (!this.yearInputControl.value.view) {
            this.yearInputControl.setValue(this.selectedYear);
        }
    }
    getPeriodStartAsEpoch(year: number) {
        const yearMoment = moment(`${year}`, "YYYY");
        return yearMoment.startOf("year").valueOf();
    }

    getPeriodEndAsEpoch(year: number) {
        const yearMoment = moment(`${year}`, "YYYY");
        return yearMoment.endOf("year").valueOf();
    }

    onArrowClickBackward(): void {
        this.selectedYear = (Number(this.yearInputControl.value) - 1).toString();
        this.yearInputControl.setValue((Number(this.yearInputControl.value) - 1).toString());
    }

    onArrowClickForward(): void {
        this.selectedYear = (Number(this.yearInputControl.value) + 1).toString();
        this.yearInputControl.setValue((Number(this.yearInputControl.value) + 1).toString());
    }

    onInputEnterKey() {
        this.input.nativeElement.blur();
    }

    onInputArrowDownClick() {
        setTimeout(() => {
            if (this.tab === "metering") {
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemMetering);
            }
            if (this.tab === "prepayment") {
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemPrepayment);
            }
            if (this.tab === "tokenlog") {
                this.inputDropdown._setScrollTop(PeriodSelectionYearComponent.scrollToItemTokenlog);
            }
        }, 20);
        setTimeout(() => this.input.nativeElement.focus());
    }

    ngOnDestroy() {
        this.yearInputChangeSubscription.unsubscribe();
    }
}
