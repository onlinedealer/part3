import React from 'react'
import { Helmet } from 'react-helmet'
import { withStyles } from '@material-ui/core/styles'
import Notifications from '../Notifications/Notifications'

import MiniDrawer from './DrawerComponent'

const styles = theme => ({
  header: {
    height: 56,
    [`${theme.breakpoints.up('xs')} and (orientation: landscape)`]: {
      height: 48,
    },
    [theme.breakpoints.up('sm')]: {
      height: 64,
    },
  },
  contentContainer: {
    padding: theme.spacing.unit, // Default <Grid container> spacing is 16. Use 8px padding for bug in material-ui Grid. See https://github.com/callemall/material-ui/issues/7466#issuecomment-316356427
  },
  sideNavFooterList: {
    color: theme.typography.body1.color,
    display: 'flex',
    flexWrap: 'wrap',
    fontSize: theme.typography.caption.fontSize,
    listStyle: 'none',
    margin: 0,
    padding: theme.spacing.unit * 1.5,
    '& li': {
      padding: theme.spacing.unit / 2,
    },
    '& a': {
      color: theme.typography.caption.color,
      textDecoration: 'none',
      transition: theme.transitions.create('color', {duration: theme.transitions.duration.shorter}),
      '&:hover': {
        color: theme.palette.primary[500],
      },
    },
  },
})

export class Layout extends React.Component {
  static defaultProps = {
    layoutActions: {},
    notificationActions: {},
  }

  render () {
    return (
      <div>
        <Helmet
          defaultTitle="mit"
          titleTemplate="%s - mit"
        />
        <Notifications />
        <MiniDrawer />

      </div>
    )
  }
}

export default withStyles(styles)(Layout)
/*
import React from 'react'
import { shape, string, func, bool, object } from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Route, Switch } from 'react-router-dom'
import { Helmet } from 'react-helmet'
import { withStyles } from 'material-ui/styles'
import HomeIcon from 'material-ui-icons/Home'
import Search from 'material-ui-icons/Search'
import Help from 'material-ui-icons/Help'
import AccountBox from 'material-ui-icons/AccountBox'
import SideNav, { Header, Icon, Link, Text } from 'react-praxis-components/SideNav'
import Grid from 'material-ui/Grid'
import Notifications from '../Notifications/Notifications'
import { closeSideNav, openSideNav } from '../../store/layout/actionCreator'
import AppHeader from '../Header/Header'
// import HomePage from '../HomePage/HomePage'
import MassItemMaintain from '../MassItemMaintain/MassItemMaintain'
import NotFound from '../NotFoundPage/NotFoundPage'
import launchpadLogo from '../../images/launchpad-logo.png'
import Logout from '../Logout/Logout'
import apiConfig from '../../config/apiConfig'

const styles = theme => ({
  header: {
    height: 56,
    [`${theme.breakpoints.up('xs')} and (orientation: landscape)`]: {
      height: 48,
    },
    [theme.breakpoints.up('sm')]: {
      height: 64,
    },
  },
  contentContainer: {
    backgroundColor: '#e6e6e6',
    padding: theme.spacing.unit, // Default <Grid container> spacing is 16. Use 8px padding for bug in material-ui Grid. See https://github.com/callemall/material-ui/issues/7466#issuecomment-316356427
  },
  sideNavFooterList: {
    color: theme.typography.body1.color,
    display: 'flex',
    flexWrap: 'wrap',
    fontSize: theme.typography.caption.fontSize,
    listStyle: 'none',
    margin: 0,
    padding: theme.spacing.unit * 1.5,
    '& li': {
      padding: theme.spacing.unit / 2,
    },
    '& a': {
      color: theme.typography.caption.color,
      textDecoration: 'none',
      transition: theme.transitions.create('color', {duration: theme.transitions.duration.shorter}),
      '&:hover': {
        color: theme.palette.primary[500],
      },
    },
  },
  sideNaveStyle: {
    display: 'flex',
    flexFlow: 'column',
    position: 'absolute',
    top: 0,
  },
  logoDimension: {
    width: '90%',
    padding: '20px 0 20px 10px',
  },
  sideNavRootStyle: {
    width: '11.2%',
    position: 'fixed',
    boxShadow: '0 1px 5px 0 rgba(0,0,0,.2), 0 2px 2px 0 rgba(0,0,0,.14), 0 3px 1px -2px rgba(0,0,0,.12)',
  },
  sideNavBg: {
    backgroundColor: '#f2f2f2',
  },
  sideNavLink: {
    padding: '8px 5px 8px 10px',
  },
  sideNavIcon: {
    marginRight: 8,
  },
})

export class Layout extends React.Component {
  static propTypes = {
    classes: object,
    headerTitle: string,
    openSideNav: func,
    closeSideNav: func,
    user: shape({
      email: string,
      isAuthorized: bool,
    }),
  }

  static defaultProps = {
    classes: {},
    headerTitle: undefined,
    layoutActions: {},
    notificationActions: {},
    user: {
      email: undefined,
      isAuthorized: undefined,
    },
  }

  handleMenuButtonClick = (event) => {
    event.preventDefault()
    if (this.props.sideNavIsOpen) {
      this.props.closeSideNav()
    } else {
      this.props.openSideNav()
    }
  }

  handleCloseSideNav = (event) => {
    if (this.props.sideNavIsOpen && event !== undefined) {
      this.props.closeSideNav()
    }
  }

  render () {
    const {
      classes,
      headerTitle,
      sideNavIsOpen,
    } = this.props

    return (
      <div>
        <Helmet
          defaultTitle="MIT"
          titleTemplate="%s - MIT"
        />
        <Notifications />
        <div className={sideNavIsOpen ? 'header-style-app-open' : 'header-style-app-close'}><AppHeader
          title={headerTitle}
          menuAction={(event) => this.handleMenuButtonClick(event)}

        /></div>
        {sideNavIsOpen &&
        <div className={classes.sideNaveStyle}>
          <SideNav
            isOpen={sideNavIsOpen}
            onClose={this.handleCloseSideNav}
            variant={'permanent'}
            classes={{paper: classes.sideNavRootStyle, list: classes.sideNavBg}}
          >
            <Header>
              <img alt="launchpad" className={classes.logoDimension} src={launchpadLogo} />
            </Header>
            <Link
              to={apiConfig.lpLinks.home}
              target="_self"
              exact
              className={classes.sideNavLink}
            >
              <Icon><HomeIcon className={classes.sideNavIcon} /></Icon>
              <Text className="sideNavLinkText">HOME</Text>
            </Link>
            <Link
              to={apiConfig.lpLinks.search}
              target="_self"
              exact
              className={classes.sideNavLink}
            >
              <Icon><Search className={classes.sideNavIcon} /></Icon>
              <Text className="sideNavLinkText">SEARCH</Text>
            </Link>
            <Link
              to={apiConfig.lpLinks.help}
              target="_self"
              exact
              className={classes.sideNavLink}
            >
              <Icon><Help className={classes.sideNavIcon} /></Icon>
              <Text className="sideNavLinkText">HELP CENTER</Text>
            </Link>
            <Link
              to="/logout"
              exact
              className={classes.sideNavLink}
              target="_self"
            >
              <Icon><AccountBox className={classes.sideNavIcon} /></Icon>
              <Text className="sideNavLinkText">LOG OUT</Text>
            </Link>
          </SideNav>
        </div>
        }
        <div className={classes.contentContainer}>
          <Grid container>
            <Grid item xs={12}>
              <Switch>
                <Route exact path="/" component={MassItemMaintain} />
                <Route path="/mass-item-maintain" component={MassItemMaintain} />
                <Route path="/logout" component={Logout} />
                <Route component={NotFound} />
              </Switch>
            </Grid>
          </Grid>
        </div>
      </div>
    )
  }
}

const mapStateToProps = state => {
  return {
    error: state.getIn(['error', 'message']),
    openPopup: state.getIn(['layout', 'openPopup']),
    popupType: state.getIn(['layout', 'popupType']),
    sideNavIsOpen: state.getIn(['layout', 'sideNavIsOpen']),
    // userInfo: state.get('user').toJS(),
    headerTitle: state.getIn(['layout', 'headerTitle']),
  }
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    openSideNav,
    closeSideNav,
  }, dispatch)

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(Layout))
*/
