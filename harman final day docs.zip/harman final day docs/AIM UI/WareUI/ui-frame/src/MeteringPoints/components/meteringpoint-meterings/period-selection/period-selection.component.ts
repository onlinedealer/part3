import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, OnChanges, SimpleChanges } from "@angular/core";
import { FormControl } from "@angular/forms";

@Component({
    selector: "landisgyr-period-selection",
    templateUrl: "./period-selection.component.html",
    styleUrls: ["./period-selection.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PeriodSelectionComponent implements OnChanges {
    @Input()
    disabled = false;

    @Input()
    period = "week";

    @Input() tab!: string;
    @Input()
    from!: number;

    @Input()
    until!: number;

    @Output()
    periodSelectionChanged = new EventEmitter<string>();

    @Output()
    timePeriodChanged = new EventEmitter<{ from: number; until: number }>();

    periodSelectionControl = new FormControl({ value: this.period, disabled: this.disabled });

    periodDropDown: { id: string; name: string }[] = [
        { id: "day", name: $localize`:|@@periodSelection.day:Day` },
        /* was Disabled as instructed in https://jira.landisgyr.net/browse/GAIM-23721,
        now is enabled as stated in https://jira.landisgyr.net/browse/GAIM-23720  */
        { id: "week", name: $localize`:|@@periodSelection.week:Week` },
        { id: "month", name: $localize`:|@@periodSelection.month:Month` },
        { id: "year", name: $localize`:|@@periodSelection.year:Year` }
    ];

    periodOptionComparator = (option: { id: string; name: string }, selected: string) => {
        return option.id === selected;
    };

    constructor() {}

    onPeriodSelectionChange() {
        this.periodSelectionChanged.emit(this.periodSelectionControl.value);
    }

    onTimePeriodChange(timePeriod: { from: number; until: number }) {
        if (this.disabled) {
            return;
        }

        if (timePeriod.from !== this.from || timePeriod.until !== this.until) {
            this.timePeriodChanged.emit(timePeriod);
        }
    }

    ngOnChanges(changes: SimpleChanges) {
        if (this.period) {
            this.periodSelectionControl.setValue(this.period);
        }

        if (this.disabled) {
            this.periodSelectionControl.disable();
        } else {
            this.periodSelectionControl.enable();
        }
    }
}
