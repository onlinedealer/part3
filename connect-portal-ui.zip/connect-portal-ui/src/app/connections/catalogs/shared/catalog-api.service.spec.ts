import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Connection, CONNECTION_TYPE } from '../../shared/connection';
import { CatalogApiService, UPDATE_CATALOG_ACTION } from './catalog-api.service';

describe('ConnectionsService', () => {
  let service: CatalogApiService;
  let httpMock: HttpTestingController;
  let httpClient: HttpClient;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(CatalogApiService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create the first catalog', () => {
    let actualResponse;
    service.createCatalog(['test'], {} as Connection, 'projectid').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/catalog/schemas');
    expect(req.request.method).toBe('POST');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should create the first catalog for schema regsitry connection', () => {
    let actualResponse;
    service.createCatalog(['test'], { connectionType: CONNECTION_TYPE.SCHEMAREGISTRY } as Connection, 'projectid').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/catalog/subjects');
    expect(req.request.method).toBe('POST');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should create the first catalog for kafka connections', () => {
    let actualResponse;
    service.createCatalog(['test'], { connectionType: CONNECTION_TYPE.KAFKA } as Connection, 'projectid').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/catalog/topics');
    expect(req.request.method).toBe('POST');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should update an existing catalog', () => {
    let actualResponse;
    service.updateCatalog(['test'], {} as Connection, 'projectid').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/catalog/schemas');
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should stop an existing catalog', () => {
    let actualResponse;
    service.updateCatalog(['test'], {} as Connection, 'projectid', UPDATE_CATALOG_ACTION.STOP).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/catalog/schemas?action=stop');
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should delete an existing catalog', () => {
    let actualResponse;
    service.deleteCatalog(['test'], {} as Connection, 'projectid').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/catalog/schemas');
    expect(req.request.method).toBe('DELETE');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should delete an existing catalog information for multiple connections', () => {
    let actualResponse;
    service.deleteCatalogs(['test']).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/catalog/schemass');
    expect(req.request.method).toBe('DELETE');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should return catalog status', () => {
    let actualResponse;
    service.status('test', false).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/status?connection_id=test&details=false');
    expect(req.request.method).toBe('GET');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should return catalog status for collection of connection ids with no details', () => {
    let actualResponse;
    let connectionIds = ['test1', 'test2'];
    service.statusSummary(connectionIds, false).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/status/summary?details=false');
    expect(req.request.method).toBe('POST');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should return catalog status for collection of connection ids with details', () => {
    let actualResponse;
    let connectionIds = ['test1', 'test2'];
    service.statusSummary(connectionIds).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne(service.serviceURL + '/status/summary?details=true');
    expect(req.request.method).toBe('POST');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });
});
