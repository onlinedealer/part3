import { Component, OnInit, Input, ViewChild, ElementRef } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { AjaxUtilityService } from '../shared/utility/ajax-utility.service';
import { UtilityService } from '../shared/utility/utility.service';
import { HttpParams, HttpResponse } from '@angular/common/http';


@Component({
  selector: 'app-terms-and-conditions-modal',
  templateUrl: './terms-and-conditions-modal.component.html',
  styleUrls: ['./terms-and-conditions-modal.component.scss']
})
export class TermsAndConditionsModalComponent implements OnInit {

  @Input() content: any;
  @ViewChild('tcModalId') tcModalId: ElementRef;
  @ViewChild('dismissBtn') dismissBtn: ElementRef;
  businessContent: any;

  constructor(
    private _ngActiveModal: NgbActiveModal,
    private _ajaxUtilityService: AjaxUtilityService,
    private _utility: UtilityService
  ) { }

  ngOnInit() {
    this.tcModalId.nativeElement.focus();
  }

   /**
   * used to close a modal, passing an optional result.
   */
  close(data?) {
    this._ngActiveModal.close(data);
  }
  /**
   * used to dismiss a modal, passing an optional result.
   */
  dismiss(data?) {
    this._ngActiveModal.dismiss(data);
  }


  onFocusOfLastElem() {
    this.dismissBtn.nativeElement.focus();
  }
}
