import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { TranslocoService } from '@ngneat/transloco';
import { EMPTY, Observable, of, Subject } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { WindowRefService } from './window-ref.service';

@Injectable({
  providedIn: 'root'
})
export class I18nService {
  private static DEFAULT_LOCALE = 'en-US';
  private static DEFAULT_LANG = 'en';

  private currentLocale: string;
  private loadedPaths = {};
  private localeChangedSource = new Subject<string>();
  // private localeChangedObservable: Observable<string> = this.localeChangedSource.pipe(distinctUntilChanged());
  private window: Window;

  /**
   * By default, the current language and backup language are set to `'en'`.
   * @internal
   */
  constructor(
    private http: HttpClient,
    private translocoService: TranslocoService,
    // private localeStore: LocaleStoreService,
    windowUtil: WindowRefService
  ) {
    this.window = windowUtil.nativeWindow;
    this.setLocale(this.getBrowserLocale());
  }

  /**
   * Loads the translations from the specified url if they have not been previously downloaded.
   * @param path The path the the translation file's directory.  The actual file to download
   * (e.g. en.json) will be determined automatically.
   * @returns Observable that will be immediately completed upon successful load.
   */

  public addTranslations(path: string): Observable<void> {
    const locale: string = this.translocoService.getActiveLang() || I18nService.DEFAULT_LOCALE;
    const lang: string = locale.substr(0, 2);
    let url: string = `${path}/${lang}.json`;

    // If we've already downloaded these translations, just succeed.
    if (this.loadedPaths[path] && this.loadedPaths[path][url]) {
      return EMPTY;
      // eslint-disable-next-line brace-style
    }
    // Download json translation file and load.
    else {
      if (!this.loadedPaths[path]) {
        this.loadedPaths[path] = {};
      }
      this.loadedPaths[path][url] = true;
      return this.http.get(url).pipe(
        map((data) => {
          this.setTranslations(locale, data);
        }),
        catchError((error: HttpErrorResponse) => {
          // fallback to default en.json if some localized file is not find
          url = `${path}/en.json`;
          return this.http.get(url).pipe(map((data) => this.setTranslations(I18nService.DEFAULT_LANG, data)));
        })
      );
    }
  }

  /**
   * Retrieve the locale based on the following priorities:
   *
   * * the "locale" query parameter from the current url
   * * the last locale set using `setLocale()`
   * * the browser locale (if available)
   * * `en-us` if all else fails
   * @returns lowercase locale
   */

  public getBrowserLocale(): string {
    const navigator = this.window.navigator as any;
    const browserLocale =
      this.parseLocaleFromQueryParam() ||
      //  this.localeStore.get() ||
      navigator.language ||
      navigator.browserLanguage ||
      navigator.systemLanguage ||
      navigator.userLanguage ||
      I18nService.DEFAULT_LOCALE;
    return browserLocale.toLowerCase();
  }

  /**
   * Get the language currently being utilized by this web app.
   * @returns current 2-digit language code
   */

  public getLanguage(): string {
    return this.currentLocale.substr(0, 2);
  }

  /**
   * Get the locale currently being utilized by this web app.
   * @returns current application locale
   */

  public getLocale(): string {
    return this.currentLocale;
  }

  /**
   * Set the locale to be utilized by this web app.
   * @param locale The locale code in standard `xx-yy` format where `xx` is the language code and
   * `yy` is the optional country code.  Non-lowercase locales will be converted to lowercase automatically.
   */

  public setLocale(locale: string): void {
    locale = locale.toLowerCase();
    const lang = locale.substr(0, 2);

    this.currentLocale = locale;
    this.translocoService.setActiveLang(lang);
    this.reloadTranslations();
    this.localeChangedSource.next(locale);
  }

  private parseLocaleFromQueryParam(): string {
    let locale: string;
    const matches: Array<string> = this.window.location.search.match(/locale=([^&]*)/);
    if (matches) {
      locale = matches[1];
    }
    return locale;
  }

  /**
   * Reload any previously loaded translation paths.  Useful when the locale has changed
   * since the original load.
   */
  private reloadTranslations(): void {
    for (const path of Object.keys(this.loadedPaths)) {
      this.addTranslations(path).subscribe();
    }
  }

  private setTranslations(lang: string, translations: any): void {
    this.translocoService.setTranslation(translations, lang);
  }
}
