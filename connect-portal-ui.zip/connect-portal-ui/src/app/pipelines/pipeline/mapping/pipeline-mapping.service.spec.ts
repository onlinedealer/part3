import { HttpClient } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { Pipeline, TableMapping } from '../shared/pipeline';
import { PipelineMappingService } from './pipeline-mapping.service';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { of, pipe, throwError } from 'rxjs';
import { EventApiService } from './shared/event-api.service';
import { PipelineEntityService } from '../shared/pipeline-entity.service';

describe('PipelineMappingService', () => {
  let service: PipelineMappingService;
  let httpClient: HttpClient;
  let httpMock: HttpTestingController;
  let eventApiService: EventApiService;
  let pipelineEntityService: PipelineEntityService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()]
    });
    service = TestBed.inject(PipelineMappingService);
    httpMock = TestBed.inject(HttpTestingController);
    httpClient = TestBed.inject(HttpClient);
    eventApiService = TestBed.inject(EventApiService);
    pipelineEntityService = TestBed.inject(PipelineEntityService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should return the table columns when called by a source or target', () => {
    // Object.defineProperty(environment, 'features', { get: getSpy });
    expect(service.getColumnHeaders('KAFKA')).toEqual([
      { header: 'pipelines.STAGES.MAPPING.TABLE.DATABASE_LABELS.KAFKA.TOPIC', name: 'topic' }
    ]);
  });

  it('should return the selected tables for source', () => {
    // Object.defineProperty(environment, 'features', { get: getSpy });
    const expectedRequestMethod = 'GET';
    const expectedEndpointUrl = '/api/v1/cdc/dataflows/aaa/selected-tables';
    let returnedData;
    const mockApiResponse = [{ schemaName: 'A', tableName: 'A1' }];
    const source = 'ORACLE';
    const target = 'KAFKA';
    service.getSelectedTables('aaa', source, target, []).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData[0].schema).toEqual('A');
  });

  it('should process the source data as per the columns when previousDataArray length is 0', () => {
    const mockApiResponse = [{ schemaName: 'A', tableName: 'A1' }];
    const source = 'ORACLE';
    const target = 'KAFKA';
    const mappingData = [{ key: 'UXTESTING.TABLE2', value: 'TABLE1' }];
    expect(service.processData(mockApiResponse, mappingData, source, target)[0].topic.name).toEqual('');
  });

  it('for SQLSERVER should process the source data as per the columns when previousDataArray length is 0', () => {
    const mockApiResponse = [{ schemaName: 'A', tableName: 'dbo.A1' }];
    const source = 'SQLSERVER';
    const target = 'KAFKA';
    const mappingData = [{ key: 'UXTESTING.TABLE2', value: 'TABLE1' }];
    expect(service.processData(mockApiResponse, mappingData, source, target)[0].topic.name).toEqual('');
  });

  it('should process the source data as per the columns when previousDataArray length is greater than 0', () => {
    const mockApiResponse = [{ schemaName: 'UXTESTING', tableName: 'TABLE2' }];
    const source = 'ORACLE';
    const target = 'KAFKA';
    const mappingData = [
      { key: 'UXTESTING||TABLE2', value: 'TABLE1' },
      { key: 'UXTESTING||TABLE2', value: 'TABLE2' }
    ];
    expect(service.processData(mockApiResponse, mappingData, source, target)[0].topic.name).toEqual('TABLE1');
  });

  it('should save Change Column Mapping Defaults if map is undefined', () => {
    const payload = { mapColumns: undefined };
    let actualResponse;
    service.saveChangeColumnMappingDefaults('627cc0ffc6940361ee0fe99f', payload).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne('/api/v1/cdc/dataflows/627cc0ffc6940361ee0fe99f/column-mappings/defaults');
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should save Change Column Mapping Defaults value is ColumnOrder', () => {
    const payload = { mapColumns: 'Column order' };
    let actualResponse;
    service.saveChangeColumnMappingDefaults('627cc0ffc6940361ee0fe99f', payload).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne('/api/v1/cdc/dataflows/627cc0ffc6940361ee0fe99f/column-mappings/defaults/?columnMappingType=ORDINAL');
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should save Change Column Mapping Defaults value is ColumnName', () => {
    const payload = { mapColumns: 'Column name' };
    let actualResponse;
    service.saveChangeColumnMappingDefaults('627cc0ffc6940361ee0fe99f', payload).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne('/api/v1/cdc/dataflows/627cc0ffc6940361ee0fe99f/column-mappings/defaults/?columnMappingType=NAME');
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should get Change Column Mapping Defaults', () => {
    let actualResponse;
    service.bulkChangeColumnMapping('627cc0ffc6940361ee0fe99f', {}).subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne('/api/v1/cdc/dataflows/627cc0ffc6940361ee0fe99f/column-mappings/change');
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should get Change Column Mapping Defaults', () => {
    let actualResponse;
    service.getChangeColumnMappingDefaults('627cc0ffc6940361ee0fe99f').subscribe((response) => {
      actualResponse = response;
    });
    const req = httpMock.expectOne('/api/v1/cdc/dataflows/627cc0ffc6940361ee0fe99f/column-mappings/defaults');
    expect(req.request.method).toBe('GET');
    req.flush(null);
    httpMock.verify();
    expect(actualResponse).toBeNull();
  });

  it('should call resetToDefault API', () => {
    const pipelineID = 'abc';
    const tableName = 'table';
    const schemaName = 'schema';
    const targetTopic = 'targetTopic';
    const checkedItems = [
      {
        sourceColumnName: 'sourceColumn1',
        sourceColType: 'type1',
        isKey: false,
        action: '',
        targetColumnName: 'targetColumn1',
        targetColType: 'targetType1',
        isExpression: false,
        state: 'SOURCE_COLUMN_SUPPORTED'
      }
    ];
    const expectedEndpointUrl = '/api/v1/cdc/dataflows/abc/column-mappings/reset?tableMappingId=1';
    const tableMapping: TableMapping = {
      id: '1',
      key: 'string',
      value: 'string',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    let returnedData;
    service.resetToDefault(pipelineID, checkedItems, tableMapping).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    expect(returnedData).toBeNull();
  });

  it('should call saveColumnMapping API', () => {
    const pipelineID = 'abc';
    const tableMapping: TableMapping = {
      id: '1',
      key: 'string',
      value: 'string',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    const expectedEndpointUrl = `/api/v1/cdc/dataflows/${pipelineID}/column-mappings/save`;
    let returnedData;
    service.saveColumnMapping(pipelineID, tableMapping).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe('PUT');
    req.flush(null);
    expect(returnedData).toBeNull();
  });

  it('should call getColumnMappings API', () => {
    const pipelineID = 'abc';
    const tableMapping: TableMapping = {
      id: '1',
      key: 'string',
      value: 'string',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    const expectedEndpointUrl = `/api/v1/cdc/dataflows/${pipelineID}/column-mappings?tableMappingId=${tableMapping.id}`;
    let returnedData;
    service.getColumnMappings(pipelineID, tableMapping.id).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe('GET');
    req.flush(null);
    expect(returnedData).toBeNull();
  });

  it('should call getSourceColumns API', () => {
    const pipelineID = 'abc';
    const tableMapping: TableMapping = {
      id: '1',
      key: 'string',
      value: 'string',
      hasCustomColMappings: true,
      type: 'TARGET_EXISTS_WITH_MATCH'
    };
    const expectedEndpointUrl = `/api/v1/cdc/dataflows/abc/column-mappings/source-columns?tableMappingId=${tableMapping.id}`;
    let returnedData;
    service.getColumns(pipelineID, tableMapping.id).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe('GET');
    req.flush(null);
    expect(returnedData).toBeNull();
  });

  it('should call getSubjectsFromCatalog API if feature flag enabled', () => {
    const connectionID = 'abc';
    const expectedEndpointUrl = `/catalog/api/v1/subjects?connection_id=abc`;
    let returnedData;
    service.getSubjectsFromCatalog(connectionID).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe('GET');
    req.flush(null);
    expect(returnedData).toBeNull();
  });

  it('should call getSubjects if feature flag not enabled', () => {
    const connectionID = 'abc';
    const expectedEndpointUrl = `/api/v1/metadata/subjects?connection_id=abc`;
    let returnedData;
    service.getSubjects(connectionID).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe('GET');
    req.flush(null);
    expect(returnedData).toBeNull();
  });

  it('should handle createNonExistingTopicsandSubjects when both topic and subject checkboxes are checked', () => {
    const pipeline = {
      id: 'abc',
      createTopic: true,
      createSubject: true
    };
    service.mappingTableGrid = [
      {
        topic: {
          name: 'topic',
          mappingIcon: 'ATTENTION'
        },
        subject: {
          name: 'subject',
          mappingIcon: 'ATTENTION'
        }
      }
    ];
    const spy = service.createNonExistingTopicsandSubjects(pipeline);
    expect(spy).toBe(false);
  });

  it('should handle createNonExistingTopicsandSubjects when both topic and subject checkboxes are checked and only topics need to be created', () => {
    const pipeline = {
      id: 'abc',
      createTopic: true,
      createSubject: true
    };
    service.mappingTableGrid = [
      {
        topic: {
          name: 'topic',
          mappingIcon: 'ATTENTION'
        },
        subject: {}
      }
    ];
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.createNonExistingTopicsandSubjects(pipeline);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should handle createNonExistingTopicsandSubjects when both topic and subject checkboxes are checked but no topics or subjects to be created', () => {
    const pipeline = {
      id: 'abc',
      createTopic: true,
      createSubject: true
    };
    service.mappingTableGrid = [
      {
        topic: {
          mappingIcon: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];

    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.createNonExistingTopicsandSubjects(pipeline);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(0);
  });

  it('should handle createNonExistingTopicsandSubjects when only topic is checked', () => {
    const pipeline = {
      id: 'abc',
      createTopic: true,
      createSubject: false
    };
    service.mappingTableGrid = [
      {
        topic: {
          name: 'topic',
          mappingIcon: 'ATTENTION'
        },
        subject: {
          mappingIcon: 'ATTENTION'
        }
      }
    ];
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.createNonExistingTopicsandSubjects(pipeline);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should handle createNonExistingTopicsandSubjects when only topic is checked but no topics to be created', () => {
    const pipeline = {
      id: 'abc',
      createTopic: true,
      createSubject: false
    };
    service.mappingTableGrid = [
      {
        topic: {
          mappingIcon: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.createNonExistingTopicsandSubjects(pipeline);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(0);
  });

  it('should handle createNonExistingTopicsandSubjects when only subject is checked', () => {
    const pipeline = {
      id: 'abc',
      createTopic: false,
      createSubject: true
    };
    service.mappingTableGrid = [
      {
        topic: {
          mappingIcon: 'ATTENTION'
        },
        subject: {
          mappingIcon: 'ATTENTION'
        }
      }
    ];
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.createNonExistingTopicsandSubjects(pipeline);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should handle createNonExistingTopicsandSubjects when only subject is checked but no subject to be created', () => {
    const pipeline = {
      id: 'abc',
      createTopic: false,
      createSubject: true
    };
    service.mappingTableGrid = [
      {
        topic: {
          mappingIcon: ''
        },
        subject: {
          mappingIcon: ''
        }
      }
    ];
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.createNonExistingTopicsandSubjects(pipeline);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(0);
  });
  it('should get statusOfSubjects with complete status', () => {
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(
      of({ errResponse: [{ message: 'failed' }], failureCount: 1, status: 'complete', successCount: 0, totalCount: 1 } as any)
    );
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.getStatusOfSubjects('abc', '/', 1, 1);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should get statusOfSubjects with other status', () => {
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'pending', successCount: 0, totalCount: 1 } as any)
    );
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.getStatusOfSubjects('abc', '/', 1, 1);
    expect(eventApiService.getStatusOfSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should get statusOfTopics with other status', () => {
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'pending', successCount: 0, totalCount: 1 } as any)
    );
    spyOn(eventApiService, 'initiateSubjectAndTopicCreation').and.returnValue(of({} as any));
    service.getStatusOfTopics('abc', '/', 1, 1);
    expect(eventApiService.getStatusOfTopicsCreation).toHaveBeenCalledTimes(1);
  });

  it('should get statusOfTopics with complete status', () => {
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'complete', successCount: 1, totalCount: 1 } as any)
    );
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.getStatusOfTopics('abc', '/', 1, 1);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should throw error for getStatusOfTopics when no status present', () => {
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(throwError('error'));
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.getStatusOfTopics('abc', '/', 1, 1);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should throw error for getStatusOfSubjects when no status present', () => {
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(throwError('error'));
    spyOn(service, 'initiateTopicsAndSubjectsCreation').and.returnValue();
    service.getStatusOfSubjects('abc', '/', 1, 1);
    expect(service.initiateTopicsAndSubjectsCreation).toHaveBeenCalledTimes(1);
  });

  it('should get status of topic and subject creation', () => {
    spyOn(pipelineEntityService, 'getPipeline').and.returnValue({
      projectId: 'abcd',
      source: {
        dataConnection: { id: 'abcd', connectionType: 'ORACLE' }
      },
      target: {
        dataConnection: { id: 'abcd', connectionType: 'KAFKA' }
      },
      createTopic: true
    } as Pipeline);
    spyOn(eventApiService, 'getStatusOfTopicsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'pending', successCount: 0, totalCount: 1 } as any)
    );
    spyOn(eventApiService, 'getStatusOfSubjectsCreation').and.returnValue(
      of({ errResponse: [], failureCount: 0, status: 'pending', successCount: 0, totalCount: 1 } as any)
    );
    service.getStatusOfTopicAndSubjectsCreation();
    expect(eventApiService.getStatusOfTopicsCreation).toHaveBeenCalled();
    expect(eventApiService.getStatusOfSubjectsCreation).toHaveBeenCalled();
  });
});
