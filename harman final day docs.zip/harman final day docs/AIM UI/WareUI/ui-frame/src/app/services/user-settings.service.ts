import { environment } from "../../environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";
import { catchError } from "rxjs/operators";

@Injectable({
    providedIn: "root"
})
export class UserSettingsService {
    constructor(private http: HttpClient) {}

    getUserSetting(): Observable<any> {
        return this.http
            .get<any>(`${environment.backend_api_prefix}/user/settings?identifier=userProfileSettings`, {
                withCredentials: true
            })
            .pipe(catchError((error: any) => throwError(error)));
    }

    getDefaultMeteringPointSearchSetting(): Observable<any> {
        return this.http
            .get<any>(`${environment.backend_api_prefix}/user/settings?identifier=searchSettings`, {
                withCredentials: true
            })
            .pipe(catchError((error: any) => throwError(error)));
    }

    updateUserSetting(userSetting: any): Observable<any> {
        const headers = new HttpHeaders().set("Content-Type", "text/plain");
        return this.http.put(`${environment.backend_api_prefix}/user/settings?identifier=userProfileSettings`, userSetting, {
            headers,
            withCredentials: true,
            responseType: "text"
        });
    }

    updateDefaultMeteringPointSearchSetting(mpSearchKeyword: any): Observable<any> {
        const headers = new HttpHeaders().set("Content-Type", "text/plain");
        return this.http.put(`${environment.backend_api_prefix}/user/settings?identifier=searchSettings`, mpSearchKeyword, {
            headers,
            withCredentials: true,
            responseType: "text"
        });
    }

    isEqual(oldSetting: any, newSetting: any) {
        if (
            oldSetting &&
            oldSetting.dateFormat &&
            newSetting &&
            newSetting.dateFormat &&
            oldSetting.dateFormat.separator === newSetting.dateFormat.separator &&
            oldSetting.dateFormat.format === newSetting.dateFormat.format &&
            oldSetting.timeFormat === newSetting.timeFormat &&
            oldSetting.timeZoneInUse === newSetting.timeZoneInUse &&
            oldSetting.hours === newSetting.hours
        ) {
            return true;
        } else {
            return false;
        }
    }
}
