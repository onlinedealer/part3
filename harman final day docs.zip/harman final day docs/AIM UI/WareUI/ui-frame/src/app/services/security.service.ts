import { catchError, map } from "rxjs/operators";
import { environment } from "../../environments/environment";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable, throwError } from "rxjs";

export interface SecuritySessionResponseOptions {
    url: string;
    rejectUnauthorized: boolean;
    followAllRedirects: boolean;
    json: boolean;
    jar: boolean;
    headers: { [key: string]: string };
    method: string;
    simple: boolean;
    resolveWithFullResponse: boolean;
    transform2xxOnly: boolean;
}

export interface SecuritySessionResponseResponse {
    statusCode: number;
    body: string;
    headers: { [key: string]: string };
    request: any;
}
export interface SecuritySessionResponse {
    name: string;
    statusCode: number;
    message: string;
    error?: string;
    token?: string;
    sessionId?: string;
    options?: SecuritySessionResponseOptions;
    response?: SecuritySessionResponseResponse;
}

@Injectable({
    providedIn: "root"
})
export class SecurityService {
    constructor(private http: HttpClient) {}

    getUserInfo(): Observable<SecuritySessionResponse> {
        return this.http.get<any>(`${environment.security_base_url}/AIMUI/security/getUserInfo`).pipe(
            map((response: SecuritySessionResponse) => this.throwExceptionOrReturnResponse(response)),
            catchError((error: any) => throwError(error))
        );
    }

    updateSession(): Observable<SecuritySessionResponse> {
        return this.http
            .post<any>(`${environment.security_base_url}/AIMUI/security/updateSession`, undefined, {
                headers: new HttpHeaders({
                    Accept: "application/json"
                })
            })
            .pipe(
                map((response: SecuritySessionResponse) => this.throwExceptionOrReturnResponse(response)),
                catchError((error: any) => throwError(error))
            );
    }

    throwExceptionOrReturnResponse(response: SecuritySessionResponse): SecuritySessionResponse {
        if (response.statusCode === 401) {
            throw new Error("Security service response code return 401, unauthorized");
        }

        if (response.statusCode >= 400) {
            throw new Error("Generic exception security http service. Error code " + response.statusCode);
        }
        return response;
    }
}
