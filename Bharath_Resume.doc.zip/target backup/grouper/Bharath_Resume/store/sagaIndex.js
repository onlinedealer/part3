import { fork } from 'redux-saga/effects'
import watchDashboardSaga from './Dashboard/saga'

export default function * () {
  yield * [
    fork(watchDashboardSaga),
  ]
}
