import { Component } from "@angular/core";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { MeteringPointState } from "../../../models/meteringpointstates.model";
import * as MeteringPointsStatesSelectors from "../../../store/selectors/meteringpointstates.selectors";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import { TranslationsService } from "../../../../app/services/translations-service";

@Component({
    selector: "landisgyr-ss-meteringpointstates",
    templateUrl: "./ss-meteringpointstates.component.html",
    styleUrls: ["./ss-meteringpointstates.component.scss"]
})
export class SSMeteringPointStatesComponent {
    refreshDataLoading$: Observable<boolean> = this.store.select(MeteringPointsStatesSelectors.getLoadingData);
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    statesLoaded$: Observable<boolean> = this.store.select(MeteringPointsStatesSelectors.getSelectedMeteringPointStatesLoaded);
    activeStates$: Observable<MeteringPointState[]> = this.store.select(MeteringPointsStatesSelectors.getSelectedMeteringPointActiveStates);
    historyStates$: Observable<MeteringPointState[]> = this.store.select(
        MeteringPointsStatesSelectors.getSelectedMeteringPointHistoryStates
    );

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {}

    getTitle(): string {
        // tslint:disable-next-line: max-line-length
        const translated = $localize`:|Title of Metering point states side view after the name of the metering point@@ssMeteringPointStates.title:Metering point states`;

        return ": " + translated.toUpperCase();
    }
    getActiveStatesTitle(): string {
        // tslint:disable-next-line: max-line-length
        const translated = $localize`:|Title of metering point active states listing@@ssMeteringPointStates.activeStatesTitle:Active states`;
        return translated.toUpperCase();
    }
    getHistoryTitle(): string {
        // tslint:disable-next-line: max-line-length
        const translated = $localize`:|Title of metering point states history listing@@ssMeteringPointStates.statesHistoryTitle:History`;
        return translated.toUpperCase();
    }
}
