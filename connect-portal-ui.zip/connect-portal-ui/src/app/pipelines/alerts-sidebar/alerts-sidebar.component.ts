import { Component, Input, OnInit, ViewChild, OnDestroy, TemplateRef } from '@angular/core';
import { Router } from '@angular/router';
import { SidebarButton } from '@shared/components/sidebar/sidebar-button';
import { TableConfiguration, TableMessageType } from '@shared/components/generic-table/generic-table';
import { Alert } from './Alert';
import { PipelinesMonitoringApiService } from '../shared/pipelines-monitoring-api.service';
import { DatePipe } from '@angular/common';
import { SidebarComponent } from '@shared/components/sidebar/sidebar.component';
import { Observable, Subscription } from 'rxjs';
import { BaseComponent } from '../../core/base.component';
import { ServersApiService } from '../../servers/shared/servers-api.service';
import { map } from 'rxjs/operators';
import { ProjectsApiService } from '../pipeline/shared/projects-api.service';
import { Project } from '../pipeline/shared/project';
import { FeatureFlagService } from '@shared/services/feature-flag.service';

@Component({
  selector: 'p-connect-alerts-sidebar',
  templateUrl: './alerts-sidebar.component.html',
  styleUrls: ['./alerts-sidebar.component.scss'],
  providers: [DatePipe]
})
export class AlertsSidebarComponent extends BaseComponent implements OnInit, OnDestroy {
  @Input() isAlertsVisible: boolean;
  @Input() onCloseRoute = '';

  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;

  cancelButton: SidebarButton = {
    id: 'closeAlertsSidebar',
    text: 'pipelines.ALERTS_SIDEBAR.BUTTONS.CLOSE'
  };
  alertsList: Alert[];
  alertsSubscription: Subscription;
  renderTable = false;
  alertsTableConfiguration: TableConfiguration;
  messageColumnTemplate: TemplateRef<any>;
  lastRefreshedTime: string;
  servers$: Observable<string[]>;
  selectedRuntimeEngine = 'All';
  project: Project;
  projectsFeatureEnabled = false;

  constructor(
    private readonly serversService: ServersApiService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly projectsApiService: ProjectsApiService,
    private readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService,
    public router: Router
  ) {
    super();
  }

  ngOnInit() {
    this.alertsTableConfiguration = this.configureTable();
    this.servers$ = this.serversService.getAll().pipe(map((servers) => ['All'].concat(servers.map((server) => server.name))));
    this.projectsFeatureEnabled = this.featureFlagService.isFeatureEnabled('CDCMultipleProjectsTemp20220421');
  }

  ngOnDestroy() {
    this.alertsSubscription?.unsubscribe();
  }

  getAlertStatusIconClass(alertLevel): string[] {
    if (alertLevel === 'ERROR') {
      return ['png-alert-actionrequired-solid', 'text-danger'];
    } else if (alertLevel === 'WARN') {
      return ['png-alert-attention-solid', 'text-warning'];
    } else if (alertLevel === 'INFO') {
      return ['png-alert-info-solid', 'text-info'];
    }
    return [];
  }

  open(serverName?: string) {
    this.selectedRuntimeEngine = serverName || 'All';

    this.getAlerts();
    this.updateLastRefreshedTime();
    this.getProjectInfo();

    this.sidebarComponent.open();
  }

  onClose() {
    this.sidebarComponent.close();
    if (this.onCloseRoute) {
      this.navigateTo(this.onCloseRoute);
    }
  }

  private configureTable(): TableConfiguration {
    return {
      fields: [
        {
          header: 'pipelines.ALERTS_SIDEBAR.FIELDS.MESSAGE',
          name: 'message',
          isInDeleteModal: true,
          isSearchable: true,
          isKey: true,
          columnStyle: { width: '50%' }
        },
        {
          header: 'pipelines.ALERTS_SIDEBAR.FIELDS.RUNTIME_ENVIRONMENT',
          name: 'host',
          isInDeleteModal: true,
          isSearchable: true
        },
        {
          header: 'pipelines.ALERTS_SIDEBAR.FIELDS.LOGGED',
          name: 'remoteTime',
          isInDeleteModal: true,
          isSearchable: true
        }
      ],
      styleClass: 'grey-bg alerts-table',
      primaryButtonText: 'pipelines.ALERTS_SIDEBAR.BUTTONS.REFRESH',
      primaryButtonStyle: 'png-refresh',
      createButtonClicked: () => {
        this.getAlerts();
        this.updateLastRefreshedTime();
      },
      isLoading: false,
      hideCheckboxColumn: true,
      visibleRows: 50,
      tableMessages: {
        emptyTableMessage: {
          messageType: TableMessageType.INFO,
          messageHead: 'pipelines.ALERTS_SIDEBAR.MESSAGES.NO_ALERTS.HEAD',
          messageCaption: 'pipelines.ALERTS_SIDEBAR.MESSAGES.NO_ALERTS.CAPTION'
        },
        errorTableMessage: {
          messageType: TableMessageType.ALERT,
          messageHead: 'pipelines.ALERTS_SIDEBAR.MESSAGES.NO_ALERTS.HEAD',
          messageCaption: 'pipelines.ALERTS_SIDEBAR.MESSAGES.NO_ALERTS.CAPTION'
        },
        filterTableMessage: {
          messageType: TableMessageType.INFO,
          messageHead: 'pipelines.ALERTS_SIDEBAR.MESSAGES.ERROR.HEAD',
          messageCaption: 'pipelines.ALERTS_SIDEBAR.MESSAGES.ERROR.CAPTION'
        }
      }
    };
  }

  getAlerts() {
    this.alertsSubscription = this.pipelinesMonitoringApiService.getAlerts(this.selectedRuntimeEngine).subscribe({
      next: (alerts: Alert[]) =>
        (this.alertsList = alerts.map((alert: Alert) => ({
          ...alert,
          remoteTime: this.getDateFromEpoch(alert.localTime).toLocaleString()
        }))),
      error: (errorResponse) => this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse)
    });
  }

  private updateLastRefreshedTime() {
    this.lastRefreshedTime = new Date().toLocaleString();
  }

  private getProjectInfo() {
    this.isProcessingRequest = true;
    this.projectsApiService
      .getDefaultProject()
      .subscribe({
        next: (project: Project) => (this.project = project),
        error: (errorResponse) => this.sidebarComponent.parseHttpClientResponseMessage('error', errorResponse)
      })
      .add(() => {
        this.isProcessingRequest = false;
      });
  }
}
