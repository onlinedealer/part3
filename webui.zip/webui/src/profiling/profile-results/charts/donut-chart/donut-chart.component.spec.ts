import { Spies } from 'discovery-test';
import { ProfileResultsTableModel } from 'profiling/profile-results/profile-results-table.model';
import { TreePath } from 'profiling/profile-results/tree-path.model';
import { TreeTableModel } from 'profiling/profile-results/tree-table.model';
import { DonutChartComponent } from './donut-chart.component';

describe('DonutChartComponent', () => {
  let component: DonutChartComponent;

  beforeEach(() => {
    Spies.init();
    component = new DonutChartComponent(Spies.TranslateService);
    component.totalRows = 50000000;
    component.data = {
      labels: [],
      datasets: [
        {
          data: [],
          backgroundColor: ['#39006B', '#8017E1', '#E5007E', '#FAB512'],
          hoverBackgroundColor: ['#39006Bcc', '#8017E1cc', '#E5007Ecc', '#FAB512cc']
        }
      ]
    };
    component.treePath = new TreePath();
    component.treePath.treeData = new TreeTableModel();
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('Initialize ngOnInit with Table View Completeness', () => {
    component.statistics = {
      type: 'CompletenessStatistics',
      completeCount: 47750703,
      nullCount: 0,
      blankCount: 0
    } as any;
    component.treePath.tableView = true;
    component.treePath.treeData.data = new ProfileResultsTableModel();
    component.treePath.treeData.data.totalRows = component.totalRows;
    component.ngOnInit();
    expect(component.data.datasets[0].data[0]).toBe(component.totalRows - component.statistics['completeCount']);
    expect(component.data.datasets[0].data[1]).toBe(component.statistics['completeCount']);
  });

  it('Initialize ngOnInit with Column View Completeness', () => {
    component.statistics = {
      type: 'CompletenessStatistics',
      completeCount: 48502186,
      nullCount: 1497814,
      blankCount: 0
    } as any;
    component.treePath.columnView = true;
    component.treePath.treeData.parent = {};
    component.treePath.treeData.parent.data = new ProfileResultsTableModel();
    component.treePath.treeData.parent.data.totalRows = component.totalRows;
    component.ngOnInit();
    expect(component.data.datasets[0].data[0]).toBe(component.statistics['completeCount']);
    expect(component.data.datasets[0].data[1]).toBe(component.statistics['nullCount']);
    expect(component.data.datasets[0].data[2]).toBe(component.statistics['blankCount']);
  });
});
