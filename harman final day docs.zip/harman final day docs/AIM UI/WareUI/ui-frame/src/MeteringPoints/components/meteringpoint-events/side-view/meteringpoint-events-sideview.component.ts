import { Component, Input, Output, EventEmitter } from "@angular/core";
import { EventVO } from "../../../models/view-objects/event-vo.model";
import { TranslationsService } from "../../../../app/services/translations-service";

@Component({
    selector: "landisgyr-meteringpoint-events-side-view",
    templateUrl: "./meteringpoint-events-sideview.component.html",
    styleUrls: ["./meteringpoint-events-sideview.component.scss"]
})
export class MeteringPointEventsSideViewComponent {
    @Input() selectedEvent!: EventVO;
    @Output() close: EventEmitter<any> = new EventEmitter();

    constructor( public translations: TranslationsService) {}

    closeView() {
        this.close.emit();
    }
}
