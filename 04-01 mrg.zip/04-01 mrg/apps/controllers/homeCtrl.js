(function() {
    'use strict';

    widget.controller("homeCtrl", ['$scope', 'uiRouters', '$state', '$rootScope', 'ajaxFactory', '$uibModal', '$log', homeCtrl]);

    function homeCtrl($scope, uiRouters, $state, $rootScope, ajaxFactory, $uibModal, $log, $timeout) {

        $scope.contacts = ajaxFactory.getData();
        $scope.hideForm = true;
        $scope.widgetName;
        $scope.detailWithData = false;
        $scope.detailWithoutData = false;
        $scope.propertyNumber = 1;
        $scope.editable = true;
        $scope.user = {};
        $scope.hideEditBtn = false;
        $scope.editbtn = false;
        $scope.obj;
        $scope.item;
        $scope.user = [];

        function generateUUID() {
            var d = new Date().getTime();
            var uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
                var r = (d + Math.random() * 16) % 16 | 0;
                d = Math.floor(d / 16);
                return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16);
            });
            return uuid;
        };

        // convert numbers to words
        function convertNumberToWords(amount) {
            var words = new Array();
            words[0] = '';
            words[1] = 'One';
            words[2] = 'Two';
            words[3] = 'Three';
            words[4] = 'Four';
            words[5] = 'Five';
            words[6] = 'Six';
            words[7] = 'Seven';
            words[8] = 'Eight';
            words[9] = 'Nine';
            words[10] = 'Ten';
            words[11] = 'Eleven';
            words[12] = 'Twelve';
            words[13] = 'Thirteen';
            words[14] = 'Fourteen';
            words[15] = 'Fifteen';
            words[16] = 'Sixteen';
            words[17] = 'Seventeen';
            words[18] = 'Eighteen';
            words[19] = 'Nineteen';
            words[20] = 'Twenty';
            words[30] = 'Thirty';
            words[40] = 'Forty';
            words[50] = 'Fifty';
            words[60] = 'Sixty';
            words[70] = 'Seventy';
            words[80] = 'Eighty';
            words[90] = 'Ninety';
            amount = amount.toString();
            var atemp = amount.split(".");
            var number = atemp[0].split(",").join("");
            var n_length = number.length;
            var words_string = "";
            if (n_length <= 9) {
                var n_array = new Array(0, 0, 0, 0, 0, 0, 0, 0, 0);
                var received_n_array = new Array();
                for (var i = 0; i < n_length; i++) {
                    received_n_array[i] = number.substr(i, 1);
                }
                for (var i = 9 - n_length, j = 0; i < 9; i++, j++) {
                    n_array[i] = received_n_array[j];
                }
                for (var i = 0, j = 1; i < 9; i++, j++) {
                    if (i == 0 || i == 2 || i == 4 || i == 7) {
                        if (n_array[i] == 1) {
                            n_array[j] = 10 + parseInt(n_array[j]);
                            n_array[i] = 0;
                        }
                    }
                }
                var value = "";
                for (var i = 0; i < 9; i++) {
                    if (i == 0 || i == 2 || i == 4 || i == 7) {
                        value = n_array[i] * 10;
                    } else {
                        value = n_array[i];
                    }
                    if (value != 0) {
                        words_string += words[value] + " ";
                    }
                    if ((i == 1 && value != 0) || (i == 0 && value != 0 && n_array[i + 1] == 0)) {
                        words_string += "Crores ";
                    }
                    if ((i == 3 && value != 0) || (i == 2 && value != 0 && n_array[i + 1] == 0)) {
                        words_string += "Lakhs ";
                    }
                    if ((i == 5 && value != 0) || (i == 4 && value != 0 && n_array[i + 1] == 0)) {
                        words_string += "Thousand ";
                    }
                    if (i == 6 && value != 0 && (n_array[i + 1] != 0 && n_array[i + 2] != 0)) {
                        words_string += "Hundred and ";
                    } else if (i == 6 && value != 0) {
                        words_string += "Hundred ";
                    }
                }
                words_string = words_string.split("  ").join(" ");
            }
            return words_string;
        };

        // convert word to numbers
        var Small = {
            'zero': 0,
            'one': 1,
            'two': 2,
            'three': 3,
            'four': 4,
            'five': 5,
            'six': 6,
            'seven': 7,
            'eight': 8,
            'nine': 9,
            'ten': 10,
            'eleven': 11,
            'twelve': 12,
            'thirteen': 13,
            'fourteen': 14,
            'fifteen': 15,
            'sixteen': 16,
            'seventeen': 17,
            'eighteen': 18,
            'nineteen': 19,
            'twenty': 20,
            'thirty': 30,
            'forty': 40,
            'fifty': 50,
            'sixty': 60,
            'seventy': 70,
            'eighty': 80,
            'ninety': 90
        };

        var Magnitude = {
            'thousand': 1000,
            'million': 1000000,
            'billion': 1000000000,
            'trillion': 1000000000000,
            'quadrillion': 1000000000000000,
            'quintillion': 1000000000000000000,
            'sextillion': 1000000000000000000000,
            'septillion': 1000000000000000000000000,
            'octillion': 1000000000000000000000000000,
            'nonillion': 1000000000000000000000000000000,
            'decillion': 1000000000000000000000000000000000,
        };

        var a, n, g;

        function text2num(s) {
            a = s.toString().split(/[\s-]+/);
            n = 0;
            g = 0;
            a.forEach(feach);
            return n + g;
        };

        function feach(w) {
            var x = Small[w];
            if (x != null) {
                g = g + x;
            } else if (w == "hundred") {
                g = g * 100;
            } else {
                x = Magnitude[w];
                if (x != null) {
                    n = n + g * x
                    g = 0;
                } else {
                    console.log("Unknown number: " + w);
                }
            }
        };

        if (ajaxFactory.getEditDataToSave() !== undefined) {
            var data = [];
            data = ajaxFactory.getEditDataToSave();
            $scope.user = data;
            $scope.disableSaveBtn = true;
            $scope.disableRegBtn = false;
        };

        $scope.edit = function() {
            $scope.hideEditBtn = true;
            $scope.editbtn = false;
            $scope.editable = false;
            // $scope.obj.value = text2num($scope.obj.value);
        };

        $scope.AddNewData = function() {
            $state.go('add');
        };

        $scope.hideRightForm = function() {
            $scope.hideForm = true;
        };

        $scope.removeRowData = function(item, index) {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: 'myModalContent.html',
                controller: 'ModalInstanceCtrl',
                resolve: {
                    items: function() {
                        return item;
                    },
                    index: function() {
                        return index;
                    }
                }
            });

            modalInstance.result.then(function(selectedItem) {
                $scope.selected = selectedItem;
            }, function() {
                $log.info('Modal dismissed at: ' + new Date());
            });
        };

        $scope.ResetData = function() {
            if ($scope.contacts.length > 0) {
                var modalInstance = $uibModal.open({
                    animation: $scope.animationsEnabled,
                    templateUrl: 'myModalContent1.html',
                    controller: 'ModalInstanceCtrl1',
                    resolve: {
                        items: function() {
                            return $scope.contacts;
                        }
                    }
                });

                modalInstance.result.then(function(selectedItem) {
                    $scope.selected = selectedItem;
                }, function() {
                    $log.info('Modal dismissed at: ' + new Date());
                });
                $state.go('/');
            } else {
                alert("No Data")
            }
        };

        $scope.register = function() {        
            if ($scope.user.widgetName == undefined || $scope.user.value == undefined) {
                alert("Please Enter widgetName and Value");
                $state.go('edit')
            } else {
                var validateName = [];
                for (var i = 0, len = localStorage.length; i < len; ++i) {
                    validateName.push(localStorage.getItem(localStorage.key(i)));
                    var totalD = localStorage.getItem(localStorage.key(i));
                };
                for (var i = 0; i < validateName.length; i++) {
                    validateName[i] = validateName[i].replace(/"/g, "'");
                };
                for (var i = 0; i < validateName.length; i++) {
                };
                var id = generateUUID();
                $scope.editable = false;      
                var tempObj = {};
                var counting = 1;
                $scope.user['id'] = id;
                for (var i = 0; i < $scope.choices.length; i++) {
                    tempObj['key' + counting] =  $scope.choices[i].key;
                    tempObj['value' + counting] =  $scope.choices[i].value;
                    var arr = [];
                    arr.push(tempObj);
                    $scope.user['keyValue'] = arr;
                    counting++;
                };
                var arrayOfKeyValue = [];
                console.log($scope.user.keyValue); 
                console.log($scope.user); 
                localStorage.setItem(id, JSON.stringify($scope.user));
                $state.go('/');
                ajaxFactory.setData($scope.user);
                ajaxFactory.deleteEditDataToSave();
                var temp = [];
                for (var i = 0, len = localStorage.length; i < len; ++i) {
                    temp.push(localStorage.getItem(localStorage.key(i)));
                };

                for (var i = 0; i < temp.length; i++) {
                    temp[i] = temp[i].replace(/"/g, "'");
                };
            }
        };

        $scope.saveEdit = function(obj) {
            $scope.editbtn = false;
            console.log(typeof(obj.value))
            if (obj.widgetName == 0 || obj.value == undefined) {
                alert("Please Enter widgetName, value and value should be number");
            } else {
                $scope.hideEditBtn = false;
                $scope.hideForm = true;
                var allID = [];
                var regex = new RegExp("[a-zA-Z]");
                console.log(regex.test(obj.value))
                if (!regex.test(obj.value)) {
                    $scope.obj.value = convertNumberToWords(obj.value);
                }
                for (var i = 0, len = localStorage.length; i < len; ++i) {
                    allID.push(localStorage.getItem(localStorage.key(i)));
                }
                localStorage.setItem(obj.id, JSON.stringify(obj));
            }
        };

        $scope.rowDetails = function(item) {
            var id = item.id;
            $state.go('edit', {
                id: id
            });
            //$scope.unknowFun(item);
            $scope.storeEditData = item;
            $scope.hideEditBtn = false;
            $scope.editable = true;
            $scope.obj = item;
            // $scope.obj.value = convertNumberToWords(item.value);
            if (typeof($scope.obj.value) == "number") {
                $scope.obj.value = convertNumberToWords(item.value);
            }
            $scope.editbtn = true;
            $scope.hideForm = !$scope.hideForm;
            $scope.widgetName = item.widgetName;
        };

        $scope.saveLocal = function() {
            var id = ajaxFactory.getEditDataToSave().id;
            localStorage.setItem(id, angular.toJson($scope.user));
            $state.go('/');
            ajaxFactory.deleteEditDataToSave();
        };

        $scope.choices = [{ id: 'choice1' }];

        $scope.addNewChoice = function() {
            if ($scope.choices.length > 4) {
                alert("Max properites 5 only");
            } else {
                var newItemNo = $scope.choices.length + 1;
                $scope.choices.push({ 'id': 'choice' + newItemNo });
            }
        };

        $scope.removeChoice = function() {
            var lastItem = $scope.choices.length - 1;
            $scope.choices.splice(lastItem);
        };
        $scope.closeRightPannel = function(){
        alert("sssssssss")            
            $scope.editbtn = false;
                $scope.hideEditBtn = false;
                $scope.hideForm = false;
        }
    }

    widget.controller('ModalInstanceCtrl', function($scope, $modalInstance, ajaxFactory, items, index) {
        $scope.ok = function() {
            localStorage.removeItem(items.id);
            ajaxFactory.deleteData(index);
            $modalInstance.dismiss('cancel');
            $scope.hideForm = true;
        };
        $scope.ResetData = function() {
            $scope.contacts.splice(0, $scope.contacts.length);
            $state.go('/');
            $scope.hideForm = true;
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };
    });

    widget.controller('ModalInstanceCtrl1', function($scope, $modalInstance, ajaxFactory, items) {
        $scope.ok = function() {
            items.splice(0, items.length);
            $modalInstance.dismiss('cancel');
            localStorage.clear();
        };

        $scope.cancel = function() {
            $modalInstance.dismiss('cancel');
        };
    });

})();