import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpEvent, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import 'rxjs/add/operator/do';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/finally';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Subject } from 'rxjs/Subject';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { InterceptorEmitter } from './interceptor-emitter.service';
import * as _ from 'underscore';




@Injectable()
export class HttpInterceptorService {

  counter = 0;
  shallShow = false;
  whiteListedUrl = [];
  constructor(private _subj: InterceptorEmitter) {
  }
  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (location.host.indexOf('localhost') !== -1 || location.host.indexOf('10.245.229.98') !== -1) {
      if (req.url.indexOf('.cvs.com') !== -1 || req.url.indexOf('.json') !== -1) {
        this.whiteListedUrl.push(req.url);
      }
    } else {
      if (req.url.indexOf('.cvs.com') !== -1) {
        this.whiteListedUrl.push(req.url);
      }
    }

    if (_.contains(this.whiteListedUrl, req.url)) {
      this.counter++;
      this._subj.setCounterValue(this.counter);

      return next
          .handle(req)
          .do(event => {
              if (event instanceof HttpResponse) {
                this.counter--;
                this._subj.setCounterValue(this.counter);
              }
          })
          .catch(response => {
            if (response instanceof HttpErrorResponse) {
              this.counter--;
              this._subj.setCounterValue(this.counter);
              return Observable.throw(response);
            }
          });
    }
  }
}
