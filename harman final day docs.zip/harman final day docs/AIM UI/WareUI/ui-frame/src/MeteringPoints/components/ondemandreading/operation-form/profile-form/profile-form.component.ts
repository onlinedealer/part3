import { Component, Input, OnInit, ViewChild, SimpleChanges, OnChanges } from "@angular/core";
import { FormGroup } from "@angular/forms";
import { MatOption } from "@angular/material/core";
import { Metering } from "../../../../models/metering.model";
import { TranslationsService } from "../../../../../app/services/translations-service";
import { map, filter } from "rxjs/operators";
import { Observable } from "rxjs";

@Component({
    selector: "landisgyr-profile-form",
    templateUrl: "./profile-form.component.html",
    styleUrls: ["profile-form.component.scss"]
})
export class ODROperationFormProfileComponent implements OnInit, OnChanges {
    @Input() parent!: FormGroup;
    @Input() show!: boolean;
    @Input() profileMeteringsThatCanBeRead!: Metering[];
    @Input() isDisabled!: boolean;
    @Input() warnMessage!: string;

    @ViewChild("allSelected") private allSelected!: MatOption;
    _textForTrigger$!: Observable<string>;

    ngOnChanges(changes: SimpleChanges) {
        if (changes.profileMeteringsThatCanBeRead && changes.profileMeteringsThatCanBeRead.currentValue) {
            this.parent.patchValue({
                profileGroup: {
                    meterings: [...this.profileMeteringsThatCanBeRead, 0]
                }
            });
        }
    }

    constructor(public translations: TranslationsService) {}

    ngOnInit() {
        this._textForTrigger$ = this.parent.valueChanges.pipe(
            filter(values => !!values.profileGroup),
            map(values => {
                return this.getTextForSelectTrigger(values.profileGroup.meterings, this.profileMeteringsThatCanBeRead);
            })
        );
    }

    togglePerOne() {
        const control = this.parent.get(["profileGroup", "meterings"]);
        if (!control) {
            return false;
        }
        if (this.allSelected.selected) {
            this.allSelected.deselect();
            return false;
        }
        if (control.value.length === this.profileMeteringsThatCanBeRead.length) {
            this.allSelected.select();
        }
    }

    toggleAllSelection() {
        const control = this.parent.get(["profileGroup", "meterings"]);
        if (!control) {
            return false;
        }
        if (this.allSelected.selected) {
            control.patchValue([...this.profileMeteringsThatCanBeRead.map((item: any) => item), 0]);
        } else {
            control.setValue([]);
        }
    }

    getTextForSelectTrigger(meteringsSelected: any[], meterings: Metering[]): string {
        let word = "";
        if (!meteringsSelected || meteringsSelected.length === 0) {
            return word;
        }
        if (meteringsSelected.length === meterings.length + 1) {
            return $localize`:|@@profileForm.all:All`;
        } else if (meteringsSelected.length > 0) {
            word = meteringsSelected[0].name;
        }
        if (meteringsSelected.length !== meterings.length && meteringsSelected.length > 1) {
            word = `${word} (+${meteringsSelected.length - 1} ${
                meteringsSelected.length === 2 ? $localize`:|@@profileForm.other:other` : $localize`:|@@profileForm.others:others`
            })`;
        }
        return word;
    }
}
