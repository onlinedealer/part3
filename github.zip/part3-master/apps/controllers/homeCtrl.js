(function() {
    'use strict';

    FirstApp.controller("homeCtrl", ['$scope', '$ajaxFactory', '$rootScope','fileUpload', homeCtrl]);

    function homeCtrl($scope, $ajaxFactory, $rootScope, fileUpload) {

    	$scope.viewbtn = true;
    	


        $scope.uploadFile = function(){
        var file = $scope.myFile;
        console.log('file is ' );
        console.dir(file);
        var uploadUrl = "/fileUpload";
        fileUpload.uploadFileToUrl(file, uploadUrl);
    };
 
    }


})();
