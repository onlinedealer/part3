/**
 * Inline loaders used to load translations via webpack import.
 * See https://ngneat.github.io/transloco/docs/lazy-load/inline-loaders/ for more info.
 */
export const agentsLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/agents/${lang}.json`);
  return acc;
}, {});

export const dqcoreCatalogLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/dqcore-catalog/${lang}.json`);
  return acc;
}, {});

export const commonLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/${lang}.json`);
  return acc;
}, {});

export const connectionsLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/connections/${lang}.json`);
  return acc;
}, {});

export const dataLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/data/${lang}.json`);
  return acc;
}, {});

export const filtersLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/filters/${lang}.json`);
  return acc;
}, {});

export const finalizeLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/finalize/${lang}.json`);
  return acc;
}, {});

export const homeLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/home/${lang}.json`);
  return acc;
}, {});

export const logReadersLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/logreaders/${lang}.json`);
  return acc;
}, {});

export const metabasesLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/metabases/${lang}.json`);
  return acc;
}, {});

export const pipelinesLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/pipelines/${lang}.json`);
  return acc;
}, {});

export const pngLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/png/${lang}.json`);
  return acc;
}, {});

export const serversLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/servers/${lang}.json`);
  return acc;
}, {});

export const bundlesLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/bundles/${lang}.json`);
  return acc;
}, {});

export const projectsLoader = ['en', 'te'].reduce((acc: any, lang) => {
  acc[lang] = () => import(`../assets/i18n/projects/${lang}.json`);
  return acc;
}, {});
