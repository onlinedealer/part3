import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import BundleComponentItems from '../common/BundleComponentItems/BundleComponentItems'
import * as Constants from '../common/Utils/Constants'
import CircularProgress from '@material-ui/core/CircularProgress'
import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormControl from '@material-ui/core/FormControl'
import FormHelperText from '@material-ui/core/FormHelperText'

const styles = theme => ({
  container: {
    padding: 0,
  },
  formControl: {
    width: '100%',
  },
  field: {
    marginTop: 24,
  },
  itemCount: {
    float: 'right',
  },
  textHead: {
    fontSize: 13,
    fontWeight: 500,
    marginBottom: 16,
  },
  textHead1: {
    fontSize: 13,
    fontWeight: 500,
  },
  textNormal: {
    fontSize: 13,
    fontWeight: 300,
  },
  textSmall: {
    fontSize: 11,
    fontWeight: 300,
    fontStyle: 'italic',
  },
  createButtonStyle: {
    position: 'relative',
    color: '#fff',
    float: 'right',
    background: '#1976d2',
    fontWeight: 300,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  IconButton: {
    marginTop: '11px',
    '&:hover': {
      background: 'transparent',
    },
  },
  displayFlex: {
    display: 'flex',
  },
  chipContainer: {
    maxHeight: '200px',
    overflowY: 'auto',
    marginBottom: 0,
    backgroundColor: '#fff',
  },
  helperText: {
    color: 'red',
    fontSize: 12,
  },
  themeContainer: {
    flexDirection: 'row',
  },
  themeRow: {
    width: '100%',
  },
  indexNumberTop: {
    marginTop: '23px',
    marginRight: '15px',
  },
  tcinMarginRight: {
    marginRight: '14px',
  },
  quantityMarginRight: {
    marginRight: '18px',
  },
  addThemeIcon: {
    color: '#1976d2',
    width: 15,
    paddingRight: 5,
  },
  addThemeButtonStyle: {
    fontSize: 11,
    fontWeight: 'bold',
    color: '#1976d2',
    padding: 0,
    '&:hover': {
      background: 'none',
    },
  },
})

export class CreateBundle extends React.PureComponent {
  constructor (props) {
    super(props)
    this.state = {
      group_name: '',
      tcins: [],
      themesFieldsCount: 1,
      formData: {
        group_type: 'bundle',
        group_name: '',
        item_type: '',
        themes: {
          theme1: '',
        },
        tcins: [],
      },
      errors: {
        group_type: '',
        item_type: '',
        group_name: '',
        themes: '',
        tcins: '',
      },
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.requestType) {
      if (nextProps.requestType === 'ADD') {
        this.props.closeDrawer()
        window.location.replace('group-details/' + nextProps.recentAddedGroup)
      }
    }
  }

  componentWillMount () {
    // logic for TCIN dropdown list
  }

    validateSubmit = () => {
      const formData = { ...this.state.formData }
      const selItem = _.find(this.props.variationItemTypes, { 'item_type_id': formData.item_type })
      const errors = { ...this.state.errors }
      let payload = {}
      let isValid = true
      if (!formData.group_type) {
        errors.group_type = Constants.ERROR_GROUP_TYPE_REQ
        isValid = false
      } else {
        this.props.groupTypes.map((grpType) => {
          if (grpType.name === formData.group_type) {
            payload.group_type_id = grpType.id
            payload.group_type = grpType.name
          }
        })
        errors.group_type = ''
      }
      if (!formData.item_type) {
        errors.item_type = Constants.ERROR_ITEM_TYPE_REQ
        isValid = false
      } else {
        payload.item_type_id = formData.item_type
        payload.item_type = selItem.item_type_name
        errors.item_type = ''
      }

      if (!formData.group_name) {
        errors.group_name = Constants.ERROR_GROUP_NAME_REQ
        isValid = false
      } else {
        payload.group_name = formData.group_name
        errors.item_type = ''
      }

      if (formData.tcins.length < 2) {
        errors.tcins = Constants.ERROR_TCIN_REQ
        isValid = false
      } else {
        let tcinData = []
        let count = 0
        formData.tcins.map((tcin) => {
          count++
          tcinData.push({ tcin, action: 'CREATED', sort_order: count })
        })
        payload.tcin_data = tcinData
        errors.tcins = ''
      }

      if (!formData.themes['theme1']) {
        errors.theme1 = Constants.ERROR_THEME1_REQ
        isValid = false
      } else {
        let themesData = []
        this.props.itemThemes.map((theme) => {
          for (let i = 1; i <= Object.keys(formData.themes).length; i++) {
            if (formData.themes[`theme${i}`].id === theme.id) {
              const fixedThemeObj = _.find(this.props.fixedThemes, (e) => { return e.fixed_theme_id === formData.themes[`theme${i}`].fixed_theme_id })
              themesData.push({ id: theme.id, fixed_theme_id: fixedThemeObj.fixed_theme_id, fixed_theme_name: fixedThemeObj.fixed_theme_name, attribute: theme.name, attribute_type: theme.attribute_type, theme_sort_order: i })
            }
          }
        })
        payload.themes = themesData
        errors.themes = ''
      }

      if (isValid) {
        payload.first_page_variation_request = true
        this.props.addGroup(payload, this.props.auth.memberOf, this.props.auth.lanId)
      } else {
        this.setState({ errors })
      }
    }

    handleChange = (name, value) => {
      const formData = { ...this.state.formData }
      formData[name] = value
      // this.setState({ formData })
    }

    render () {
      const { classes, closeDrawer, loadingBtnStatus } = this.props
      const { formData, errors } = this.state
      let isDisabled = !!((!formData.group_type || !formData.item_type || !formData.group_name || formData.tcins.length <= 1 || !formData.themes['theme1'] || !formData.themes['theme1'].id || !formData.themes['theme1'].fixed_theme_id))
      isDisabled = (loadingBtnStatus.status && loadingBtnStatus.btnName === 'Create Group') ? true : isDisabled

      return (
        <div>
          <Grid container className={classes.container}>
            <Grid item xs={10}>
              <FormControl className={classes.formControl} aria-describedby="name-helper-text">
                <InputLabel htmlFor="name-helper" required>Bundle Master TCIN</InputLabel>
                <Input multiline id="name-helper" onChange={this.handleChange('group_name')} required />
                {(errors.group_name) ? <FormHelperText error className={classes.helperText}>{errors.group_name}</FormHelperText>
                  : <FormHelperText id="name-helper-text" />}
              </FormControl>
            </Grid>
            <Grid item xs={12} className={classes.field}>
              <Grid container className={classes.themeContainer}>
                <Grid item xs={12}>
                  <div className={classes.textHead1}>Component Items </div>
                  {/* <div className={classes.textSmall}>Select upto {Constants.THEME_MAX_COUNT} attributes, minumum of 1</div> */}
                  <div className={classes.textSmall}>Minimum of 1 item must be entered</div>
                </Grid>
                {<BundleComponentItems
                  onHandleChange={this.handleChange}
                  classes={classes}
                />}
              </Grid>
            </Grid>
            <Grid item xs={12} className={classes.field}>
              <Grid container style={{justifyContent: 'space-around'}}>
                <Grid item xs={6} style={{flexBasis: 0}}>
                  <Button color="primary" className={classes.cancelButtonStyle} onClick={closeDrawer}>
                        Cancel
                  </Button>
                </Grid>
                <Grid item xs={6}>
                  <Button color="primary" className={classes.createButtonStyle} onClick={this.validateSubmit} disabled={isDisabled}>
                    { (loadingBtnStatus.status && loadingBtnStatus.btnName === 'Create Group') &&
                      <CircularProgress
                        className={classes.progress}
                        size={25}
                      />
                    }
                    CREATE GROUP
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </div>
      )
    }
}

CreateBundle.propTypes = {
  classes: PropTypes.object.isRequired,
}
export default (withStyles(styles)(CreateBundle))
