import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ClubGenericErrorComponent } from '../../shared/components/club-generic-error/club-generic-error.component';
import { RouteConfigurations } from '../../shared/utility/club-constants.service';
import { Title, Meta } from '@angular/platform-browser';


@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.scss']
})
export class RegistrationComponent implements OnInit {

  // flag to show hide the failure scenarios
  accountCreationFailure = false;

  // This object holds the response from the navigation resolver
  // It contains the logged in status as well as the EC card and club
  // subscription information
  registrationNavInfo = {};

  // This flag holds the value of whether the validateProfile service failed or not
  validateServiceSuccess: Boolean = true;

  /* This flag holds the type of error that validate profile service encounters.
  This is further passed to the generic error message component to show
  the specific error.*/
  errorType: string;

  constructor(
    private _router: Router,
    private route: ActivatedRoute,
    private _title: Title,
    private _meta: Meta
    ) {
      _title.setTitle(RouteConfigurations.clubRegistrationTitle);
      _meta.removeTag("name='description'");      
      _meta.addTag({ name: 'description', content: RouteConfigurations.carepassRegistrationDesc });      
    }

  // This needs be retrieved from URL or service later. Toggle this value
  // to see the header error message
  extracareCardAvailabile = false;

  /* This function is getting a response fromt the registration module. The response determines 
     it will navigate to payment page or stay in the same page */
  onCreateAccountCall(obj) {
    if (obj.status == 'success') {
      this._router.navigate(['/' + RouteConfigurations.clubPaymentBillingDetails]);
    }else {
      this.errorType = 'genericSerice';
      this.validateServiceSuccess = false;
      this.accountCreationFailure = true;
    }
  }

  ngOnInit() {
        // This handles the data from the resolver after the validate profile service is called.
        this.registrationNavInfo  = this.route.snapshot.data.regDataObj;
  }

}
