export class StatisticalAnalysisModel {
  data: number;
  label: string;
  imageUrl: string;
  fieldName: string;
  constructor() {
    this.data = 0;
    this.label = '';
    this.imageUrl = '';
    this.fieldName = '';
  }
}
