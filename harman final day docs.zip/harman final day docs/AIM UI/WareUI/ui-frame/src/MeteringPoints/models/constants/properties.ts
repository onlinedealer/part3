export const properties: any = {
    relayType: "RELAY 1",
    usage: "Mains",
    controlLogic: "false"
};
