/**
 * The central interface for logging.  Writes messages to the console output.
 */
export interface Logger {
  /**
   * Writes a trace message to the log.  Trace messages designate finer-grained informational events than debug.
   * @param msg The message to log
   */
  trace(msg: string | Error): void;

  /**
   * Writes a debugging message to the log.  Debug messages designate fine-grained informational events that are
   * most useful to debug an application.
   * @param msg The message to log
   */
  debug(msg: string | Error): void;

  /**
   * Writes an informational message to the log.  Info messages designate informational messages that highlight the
   * progress of the application at coarse-grained level.
   * @param msg The message to log
   */
  info(msg: string | Error): void;

  /**
   * Writes a warning message to the log.  Warn messages designate potentially harmful situations.
   * @param msg The message to log
   */
  warn(msg: string | Error): void;

  /**
   * Writes an error message to the log.  Error messages designate error events that might still allow the application
   * to continue running.
   * @param msg The message to log
   */
  error(msg: string | Error): void;
}
