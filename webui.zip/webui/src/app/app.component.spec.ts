import { Spies } from 'discovery-test';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;
  beforeEach(() => {
    Spies.init();
    component = new AppComponent(Spies.i18nService, Spies.launchDarklyService, undefined);
  });

  it('should be created', () => {
    expect(component).toBeTruthy();
  });

  it('should initialize translations oninit', () => {
    component.ngOnInit();
  });

  it('should have as title "discovery-cloud"', () => {
    expect(component.title).toEqual('discovery-cloud');
  });

  describe('launchDarkly', () => {
    it('should close before window close', () => {
      component.closeLaunchDarkly();
      expect(Spies.launchDarklyService.close).toHaveBeenCalled();
    });
  });
});
