import { SortMeta } from 'primeng/api';

export interface EntityDataModel {
  /**
   * headers for the primeng table
   */
  headers: Array<{
    isHidden?: boolean;
    fieldName: string;
    displayName: string;
    sort?: boolean;
  }>;

  /**
   * meta key field for primeng table
   */
  keyField?: string;

  /**
   * flag to show/hide table row checkbox
   */
  showCheckBox?: boolean;

  /**
   * flag to show/hide table header checkbox
   */
  showSelectAllCheckBox?: boolean;

  /**
   * flag enables to use primeng tri-state checkbox
   */
  showTriState?: boolean;

  /**
   * primeng input for row hover state
   */
  rowHover?: boolean;

  /**
   * primeng input to enable/disable scrollable feature
   */
  scrollable?: boolean;

  /**
   * primeng input for table scroll height
   */
  scrollHeight?: string;

  /**
   * List of fields with initial sort order
   */
  sortMetaList?: SortMeta[];

  /**
   * primeng input for virtual scroll height
   */
  virtualScroll?: boolean;

  /**
   * primeng input for row height
   */
  virtualRowHeight?: number;

  /**
   * primeng input for number of rows
   */
  noOfRows?: number;

  /**
   * primeng input for enabling/disabling lazy loading feature
   */
  lazy?: boolean;

  /**
   * primeng input for lazy loading data
   */
  lazyCallBack?(): any;
}
