import { ComponentFixture, TestBed } from '@angular/core/testing';
import { LogReaderMessagesFormComponent } from './log-reader-messages-form.component';
import { of, throwError } from 'rxjs';
import { PipelinesMonitoringApiService } from '../../../shared/pipelines-monitoring-api.service';
import { SidebarModule } from 'primeng/sidebar';
import { getTranslocoModule } from '../../../../core/transloco-testing.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { LogReaderLog } from '../../../shared/pipelines-monitoring-status';

describe('LogReaderMessagesFormComponent', () => {
  let component: LogReaderMessagesFormComponent;
  let fixture: ComponentFixture<LogReaderMessagesFormComponent>;
  let pipelinesMonitoringApiService: PipelinesMonitoringApiService;
  const mockData: LogReaderLog[] = [
    {
      timestamp: '2022-04-05 07:45:57.000',
      severity: 'INFORMATION',
      description:
        'journal records read so far - 0 transactions with 0 operations captured so far. 13139 database commits - 13128 updates to restart table - last jrn.time(20220404204844) lag 39433 secs  '
    },
    {
      timestamp: '2022-04-05 07:44:56.000',
      severity: 'INFORMATION',
      description:
        'journal records read so far - 0 transactions with 0 operations captured so far. 13118 database commits - 13107 updates to restart table - last jrn.time(20220404204844) lag 39372 secs  '
    },
    {
      timestamp: '2022-04-05 07:43:55.000',
      severity: 'INFORMATION',
      description:
        'journal records read so far - 0 transactions with 0 operations captured so far. 13098 database commits - 13087 updates to restart table - last jrn.time(20220404204844) lag 39311 secs  '
    }
  ];
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SidebarModule, getTranslocoModule(), HttpClientTestingModule, DropdownModule, FormsModule],
      declarations: [LogReaderMessagesFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    fixture = TestBed.createComponent(LogReaderMessagesFormComponent);
    component = fixture.componentInstance;
    pipelinesMonitoringApiService = TestBed.inject(PipelinesMonitoringApiService);
    spyOn(pipelinesMonitoringApiService, 'getLogs').and.returnValue(of(mockData));
    component.projectId = 'projectId';
    component.logReader = {
      dataConnection: 'conn1',
      name: 'logreader1'
    } as any;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should get logs', () => {
    component.getLogs();
    component.logs$.subscribe((logs) => {
      expect(logs).toEqual(mockData.map((log) => ({ ...log, timestamp: new Date(log.timestamp).toLocaleString() })));
    });
  });

  it('should return the correct styles for each alert type', () => {
    expect(component.getAlertStatusIconClass('ERROR')).toEqual(['png-alert-actionrequired-solid', 'text-danger']);
    expect(component.getAlertStatusIconClass('WARNING')).toEqual(['png-alert-attention-solid', 'text-warning']);
    expect(component.getAlertStatusIconClass('INFORMATION')).toEqual(['png-alert-info-solid', 'text-info']);
    expect(component.getAlertStatusIconClass('SOMETHING_ELSE')).toEqual([]);
  });

  it('should handle http errors', () => {
    const errorSpy = spyOn(component.serviceError, 'emit');
    spyOn(pipelinesMonitoringApiService, 'getLogs').and.returnValue(throwError({ error: { message: 'cannot get logs' } }));
    component.getLogs();
    component.logs$.subscribe(() => {
      expect(errorSpy).toHaveBeenCalled();
    });
  });

  it('should update the last refreshed', () => {
    spyOn(Date.prototype, 'toLocaleString').and.returnValue('2020-04-15');
    component.getLogs();
    expect(component.lastRefreshedTime).toEqual('2020-04-15');
  });

  it('should use proper table messages based on the monitoring status', () => {
    spyOn(pipelinesMonitoringApiService, 'getLogs').and.returnValue(of([]));
    component.replicationStatus = 'OK';
    component.logReaderStatus = 'NOTOK';
    component.getLogs();
    component.logs$.subscribe((logs) => {
      expect(component.logMessagesTableConfiguration.tableMessages.emptyTableMessage).toEqual(component.logReadersNotStartedMessage);
    });
    component.replicationStatus = 'NOTOK';
    component.getLogs();
    component.logs$.subscribe((logs) => {
      expect(component.logMessagesTableConfiguration.tableMessages.emptyTableMessage).toEqual(component.pipelineNotStartedMessage);
    });
  });
});
