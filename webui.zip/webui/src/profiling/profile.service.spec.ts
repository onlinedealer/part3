import { of } from 'rxjs';
import { Mocks, Spies } from 'discovery-test';
import { ProfileService } from './profile.service';

describe('ProfileService', () => {
  let service: ProfileService;
  let profileList;

  beforeEach(() => {
    Spies.init();
    service = new ProfileService(Spies.HttpClient, Spies.AuthenticationService, Spies.HttpUtilService);
    profileList = Mocks.MockProfiles;
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('getProfileList be called', () => {
    service.getProfileList().subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('getRulesList be called', () => {
    service.getRulesList().subscribe();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('deleteProfile be called', () => {
    service.deleteProfile(profileList[0]['id']).subscribe();
    expect(Spies.HttpClient.delete.calls.count()).toBe(1);
  });

  it('runProfile be called', () => {
    service.runProfile(profileList[0]['id']).subscribe();
    expect(Spies.HttpClient.post.calls.count()).toBe(1);
  });

  it('should save profile with new id on saveProfile', () => {
    Spies.ProfileService.saveProfile.and.returnValue(of(profileList));
    service.saveProfile(profileList[0], true, profileList[0]['id']);
  });

  it('should save profile on saveProfile', () => {
    Spies.ProfileService.saveProfile.and.returnValue(of(profileList));
    service.saveProfile(profileList[0], false, profileList[0]['id']);
  });

  it('getProfileList be called', () => {
    Spies.ProfileService.getProfile.and.returnValue(of(profileList[0]));
    service.getProfile(profileList[0]['id']);
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('stopRunProfile be called', () => {
    service.stopRunProfile(profileList[0]['id']).subscribe();
    expect(Spies.HttpClient.post.calls.count()).toBe(1);
  });
});
