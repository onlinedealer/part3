(function () {
    'use strict';

    angular.module('arm').controller('dealCtrl',
                ['$scope', '$state', '$filter', '$ionicModal', '$ionicSideMenuDelegate', 'dealService', 'contactService', 'utility', 'MASTER_TABLE', 'GENERAL_CONFIG', '$cordovaDialogs','homeService','$rootScope', dealCtrl]);

    function dealCtrl($scope, $state, $filter, $ionicModal, $ionicSideMenuDelegate, dealService, contactService, utility, MASTER_TABLE, GENERAL_CONFIG, $cordovaDialogs,homeService,$rootScope) {
        // Deal Stage
        $scope.selDealStages = {
            activeDealStage: "",
            tempDealStage: "",
            dealItemClicked: "",
            previousDealStageID:"",
            previousDealStageName:""
        };

        var lgnUser = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.dealStages = utility.getMultLangMasData(MASTER_TABLE.DelSubStg);
        $scope.currencies = utility.getMultLangMasData(MASTER_TABLE.Curcy);
        $scope.user = {};

        $scope.objFilter = {
            pro: 3,
            search: '',
            selDate: '',
            selCalDate: ''
        };

        //update the final value as per selected datetime control
        $scope.$watch(function (scope) { return scope.objFilter.selCalDate },
              function (newValue, oldValue) {
                  if (newValue == null || newValue == '') return;
                  loadDateFilter(newValue);
                  //$scope.objFilter.selDate = utility.getDateInDisplayFormat(newValue);
              }
        );

        var retainArr = [];
        function loadData() {
            // Fetch the all DeviceObjIds for login user Id's
            $scope.allDeviceObjIdsByLoginUserID = [];
            contactService.sqlGetAllDeviceObjIds().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    $scope.allDeviceObjIdsByLoginUserID.push(result.rows.item(i));
                }
            });
            $scope.dealList = [];
            $scope.overDueCount = 0;
            dealService.sqlSelectDeals().then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var srcObj = result.rows.item(i);
                    $scope.dealList.push(dealService.dealMod().uiObject);
                    $scope.dealStageModelID = utility.dealStageModelIDCheck(result.rows.item(i)['DealStageID']);
                    $scope.dealList[i].Priority = utility.getColorCodeForDeals(result.rows.item(i)['ExpectedDealCloseDate'], $scope.dealStageModelID);
                    if ($scope.dealList[i].Priority == 1) {
                        $scope.overDueCount++;
                    }
                    $scope.dealList[i] = utility.syncModelWithCollection(srcObj, $scope.dealList[i]);
                        // for (var key in $scope.dealList[i]) {
                        //     if($scope.dealList[i].hasOwnProperty(key) && srcObj.hasOwnProperty(key)) {
                        //             //console.log('inside if');
                        //             $scope.dealList[i][key] = srcObj[key];
                        //     }
                        // }
                    $scope.dealList[i].ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate($scope.dealList[i].ExpectedDealCloseDate).toString();
                    $scope.dealList[i].OwnerNameToDisplay = utility.getNameByOrOwner($scope.dealList[i]);
                    $scope.dealList[i].DealStageModelIDToCheck = $scope.dealStageModelID;
                    $scope.dealList[i].DealStageName = utility.dealStageName($scope.dealList[i].DealStageID);


                    // if ($scope.dealList[i].ContactTypeID == 1) {
                    //     $scope.dealList[i].ContactDisplayName = $scope.dealList[i].ContactName;
                    //     //tarLst.ContactName = tarLst.contactName;
                    //     if (typeof $scope.dealList[i].EmployerName != 'undefined')
                    //         $scope.dealList[i].CompanyName = $scope.dealList[i].EmployerName;
                    //     else
                    //     {
                    //         $scope.dealList[i].CompanyName = '';
                    //     }
                    // }
                    // else
                    // {
                    //     $scope.dealList[i].CompanyName = $scope.dealList[i].ContactName;
                    //     if (typeof $scope.dealList[i].RepresentativeName != 'undefined')
                    //         $scope.dealList[i].ContactDisplayName = $scope.dealList[i].RepresentativeName;
                    //     else
                    //     {
                    //         $scope.dealList[i].ContactDisplayName = '';
                    //     }
                    // }

                    //$scope.dealList.push(result.rows.item(i));

                }
                retainArr = angular.copy($scope.dealList);
                loadFilter();
                $scope.actionFilter('R');//refresh
                $scope.childCheck();
            });
            var curDt = new Date();
            loadDateFilter(curDt);
        }

        loadData();

        // Date Functionality

        function loadDateFilter(date) {
            var monthNames = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];

            var day = date.getDate();
            var monthIndex = date.getMonth();
            var year = date.getFullYear();
            $scope.filterDate = day + ' ' + monthNames[monthIndex] + ', ' + year;
            //$scope.search = $scope.filterDate;
            var m = ('0' + (monthIndex + 1)).slice(-2);
            var d = ('0' + (day)).slice(-2);

            $scope.objFilter.selDate = year + '-' + m + '-' + d;

        }

        $scope.nextPreDate = function (type) {
            var dt = new Date($scope.filterDate);
            if (type == 'N') {
                dt.setDate(dt.getDate() + 1);
                loadDateFilter(dt);
            }
            else {
                dt.setDate(dt.getDate() - 1);
                loadDateFilter(dt);
            }
            //$scope.actList = angular.copy(filterDate());
        }

        $scope.filterPro = function (tabchecked) {
            $scope.tabchecked = !$scope.tabchecked;

            if (!$scope.tabchecked) {
                $scope.dealList = angular.copy(retainArr);
                var curDt = new Date();
                loadDateFilter(curDt);
                loadFilter();
                $scope.actionFilter('R');//refresh
            }
            else {
                $scope.objFilter.selDate = '';
                $scope.objFilter.search = '';
                $scope.selectedFilter = {};
                $scope.dealList = utility.getObjData(retainArr, 'Priority', 1);
            }

        }

         // Refresh on pulling the list

        $scope.doRefresh = function (requestType) {
        // GENERAL_CONFIG.DataRetrivalType.Pevious
            dealService.dealList(requestType).then(function (res) {
                ////console.log('Deal List Response is'+JSON.stringify(res));
                syncServerRecords(res,requestType);
            },function (err) {
                //console.log('deal list error'+err);
            });
            //console.log("Refresh for Pull...!!");
            $scope.$broadcast('scroll.refreshComplete');
        };

        // Sync Server Records

        function syncServerRecords(serverResponse,requestType){
            // Add or update contact to SQLight DB
            contactService.syncServerContactFromOtherModule(serverResponse.Contacts, $scope.allDeviceObjIdsByLoginUserID);

            angular.forEach(serverResponse.Deals, function (responseObj) {
                var existedRecord = $filter('filter')($scope.dealList, {DeviceObjID: responseObj.DeviceObjID});
                //if(existedRecord == null || existedRecord == ""){
                if(existedRecord.length == 0){
                    var createNewDealObjModel = dealService.dealMod().uiObject;
                    $scope.dealList.push(createNewDealObjModel);

                    var dealStageModelID = utility.dealStageModelIDCheck(responseObj.DealStageID);
                    createNewDealObjModel.Priority = utility.getColorCodeForDeals(responseObj.ExpectedDealCloseDate, dealStageModelID);
                    if (createNewDealObjModel.Priority == 1) {
                          $scope.overDueCount++;
                    }

                    utility.syncModelWithoutInnerCollection(responseObj,createNewDealObjModel);
                    createNewDealObjModel.ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate(createNewDealObjModel.ExpectedDealCloseDate).toString();
                    createNewDealObjModel.OwnerNameToDisplay = utility.getNameByOrOwner(createNewDealObjModel);
                    createNewDealObjModel.DealStageModelIDToCheck = dealStageModelID;
                    createNewDealObjModel.DealStageName = utility.dealStageName(createNewDealObjModel.DealStageID);
                    responseObj.DealStageName = utility.dealStageName(createNewDealObjModel.DealStageID);
                    if (createNewDealObjModel.ContactTypeID == 1) {
                        createNewDealObjModel.ContactDisplayName = responseObj.ContactName;
                        responseObj.ContactDisplayName = responseObj.ContactName;
                        //tarLst.ContactName = tarLst.contactName;
                        if (typeof responseObj.EmployerName != 'undefined' || responseObj.EmployerName != null){
                            createNewDealObjModel.CompanyName = responseObj.EmployerName;
                            responseObj.CompanyName = responseObj.EmployerName;
                        }else{
                            createNewDealObjModel.CompanyName = '';
                            responseObj.CompanyName = '';
                        }
                    }else{
                        createNewDealObjModel.CompanyName = responseObj.ContactName;
                        responseObj.CompanyName = responseObj.ContactName;
                        if (typeof responseObj.RepresentativeName != 'undefined' || responseObj.RepresentativeName != null){
                            createNewDealObjModel.ContactDisplayName = responseObj.RepresentativeName;
                            responseObj.ContactDisplayName = responseObj.RepresentativeName;
                            createNewDealObjModel.RepresentativeName = responseObj.RepresentativeName;
                        }else{
                            createNewDealObjModel.ContactDisplayName = '';
                            responseObj.ContactDisplayName = '';
                        }
                    }
                    //$scope.dealList.push(createNewDealObjModel);
                    // add the obj in model and SQLight DB
                    dealService.addDealToSql(responseObj).then(function (result) {
                    }, function (error) {  });

                }else{
                    // update the obj in model and SQLight DB
                    var dealStageModelID = utility.dealStageModelIDCheck(responseObj.DealStageID);
                    var existedPriority = existedRecord[0].Priority;
                    existedRecord[0].Priority = utility.getColorCodeForDeals(responseObj.ExpectedDealCloseDate, dealStageModelID);
                    if (existedRecord[0].Priority == 1 && existedPriority != existedRecord[0].Priority) {
                          $scope.overDueCount++;
                    }
                    utility.syncModelWithoutInnerCollection(responseObj,existedRecord[0]);
                    existedRecord[0].ExpectedDealCloseDateToDisplay = utility.getDateInDisplayFormatFromServerDate(existedRecord[0].ExpectedDealCloseDate).toString();
                    existedRecord[0].OwnerNameToDisplay = utility.getNameByOrOwner(existedRecord[0]);
                    existedRecord[0].DealStageModelIDToCheck = dealStageModelID;
                    existedRecord[0].DealStageName = utility.dealStageName(existedRecord[0].DealStageID);
                    responseObj.DealStageName = utility.dealStageName(existedRecord[0].DealStageID);
                    if (existedRecord[0].ContactTypeID == 1) {
                        existedRecord[0].ContactDisplayName = responseObj.ContactName;
                        responseObj.ContactDisplayName = responseObj.ContactName;
                        //tarLst.ContactName = tarLst.contactName;
                        if (typeof responseObj.EmployerName != 'undefined' || responseObj.EmployerName != null){
                            existedRecord[0].CompanyName = responseObj.EmployerName;
                            responseObj.CompanyName = responseObj.EmployerName;
                        }else{
                            existedRecord[0].CompanyName = '';
                            responseObj.CompanyName = '';
                        }
                    }else{
                        existedRecord[0].CompanyName = responseObj.ContactName;
                        responseObj.CompanyName = responseObj.ContactName;
                        if (typeof responseObj.RepresentativeName != 'undefined' || responseObj.RepresentativeName != null){
                            existedRecord[0].ContactDisplayName = responseObj.RepresentativeName;
                            responseObj.ContactDisplayName = responseObj.RepresentativeName;
                            existedRecord[0].RepresentativeName = responseObj.RepresentativeName;
                        }else{
                            existedRecord[0].ContactDisplayName = '';
                            responseObj.ContactDisplayName = '';
                        }
                    }

                    // Assign the sub child model for Deal Document Mapping
                    if(responseObj.DealDocumentMapping.length > 0){
                        existedRecord[0].DealDocumentMapping = responseObj.DealDocumentMapping;
                    }else{
                        existedRecord[0].DealDocumentMapping = [];
                        //contactService.bindCorrespondencesEmptyModel(existedRecord);
                    }
                    // Assign the sub child model for Notes
                    if(responseObj.Notes.length > 0){
                        existedRecord[0].Notes = responseObj.Notes;
                    }else{
                        existedRecord[0].Notes = [];
                    }
                    // Assign the sub child model for Deal Attendees
                    if(responseObj.DealAttendees.length > 0){
                        existedRecord[0].DealAttendees = responseObj.DealAttendees;
                    }else{
                        existedRecord[0].DealAttendees = [];
                    }
                    // Assign the sub child model for Activity Deal Mappings
                    if(responseObj.ActivityDealMappings.length > 0){
                        // utility.syncModelWithoutInnerCollection(resFieldsObj,existedRecord[index]);
                        existedRecord[0].ActivityDealMappings = responseObj.ActivityDealMappings;
                    }else{
                        existedRecord[0].ActivityDealMappings = [];
                    }
                    // Assign the sub child model for Attachments
                    if(responseObj.Attachments.length > 0){
                        existedRecord[0].Attachments = responseObj.Attachments;
                    }else{
                        existedRecord[0].Attachments = [];
                    }

                    // Assign the sub child model for Attachments
                    if(responseObj.Fields.length > 0){
                        if(existedRecord[0].Fields.length > 0){
                            angular.forEach(responseObj.Fields, function (resFieldsObj, index) {
                                var existedField = $filter('filter')(existedRecord.Fields, {FieldName: responseObj.FieldName});
                                if(existedField != null || existedField != ""){
                                    utility.syncModelWithCollection(resFieldsObj,existedField);
                                }
                            });
                        }
                    }else{
                        existedRecord[0].Fields = [];
                        //contactService.bindFieldsEmptyModel(existedRecord);
                    }
                    dealService.updateDealToSql(existedRecord[0]).then(function (result) {
                    }, function (error) {  });
                }
            });
            if(requestType == "Next"){
                $scope.$broadcast('scroll.refreshComplete');
            }else{
                $scope.$broadcast('scroll.infiniteScrollComplete');
            }
            retainArr = angular.copy($scope.dealList);
        }

        $scope.openMenu = function () {
            $ionicSideMenuDelegate.toggleLeft();
        }
        $scope.dealsdetail = function (dealsId, itemClickedIndex) {
            //console.log('item clicked is'+itemClickedIndex);
            for(var i=0;i<$scope.dealList.length;i++){
                if($scope.dealList[i].DeviceObjID == dealsId){
                    dealService.setSelectedDeal($scope.dealList[i]);
                    $state.go('tab.dealDetail', {dealsId: dealsId});
                }
            }
        }
        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };


        // Modal filter
        $ionicModal.fromTemplateUrl('app/views/deal/dealFilter.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modaldealsfilter = modal;
        });
        $scope.openFilter = function () {
            $scope.modaldealsfilter.show();
        };
        $scope.closeModalB = function () {
            $scope.modaldealsfilter.hide();
        };

        /////////////////////////////////////////////////////////// Modal for Deal Stages /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStages.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStages = modal;
        });

        $scope.openDealStagesList = function (val, dealsId) {
            $scope.modelSelected = val;
            $scope.selDealStages.dealItemClicked = "";
            for(var i=0;i<$scope.dealList.length;i++){
                if($scope.dealList[i].DeviceObjID == dealsId){
                    var dealStageModelID = utility.dealStageModelIDCheck($scope.dealList[i].DealStageID);
                    if(!(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close || dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost)){
                        $scope.selDealStages.activeDealStage = $scope.dealList[i].DealStageID;
                        $scope.selDealStages.dealItemClicked = i;
                        $scope.selDealStages.previousDealStageID = $scope.dealList[i].DealStageID;
                        $scope.selDealStages.previousDealStageName = $scope.dealList[i].DealStageName;
                        $scope.modalDealStages.show();
                    }
                }
            }
        };
        $scope.closeDealStagesList = function () {
            $scope.selDealStages.dealItemClicked = "";
            $scope.modalDealStages.hide();
        };

        $scope.actionDealStagesList = function () {
            var dealStageModelID = utility.dealStageModelIDCheck($scope.selDealStages.activeDealStage);
            if(!(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close || dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost)){
                $scope.selDealStages.tempDealStage = $scope.selDealStages.activeDealStage;
                for(var i=0;i<$scope.dealStages.length;i++){
                        if($scope.selDealStages.activeDealStage == $scope.dealStages[i].DealStageID){
                            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.dealStages[i].DealStageID;
                            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.dealStages[i].Name;
                            $scope.dealCloseModel = dealService.dealCloseLostMod().uiObject;
                            $scope.dealCloseModel.DeviceObjID = $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID;
                            $scope.dealCloseModel.DealID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealID;
                            $scope.dealCloseModel.DealStageID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID;
                            $scope.dealCloseModel.DealStageName = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName;
                            $scope.dealCloseModel.ModifiedBy = lgnUser.UserID;
                            var dateStringInUTC = utility.getDateStringInUTC(new Date());
                            $scope.dealCloseModel.ModifiedOn = dateStringInUTC;

                            dealService.sqlDealStageUpdate($scope.dealList[$scope.selDealStages.dealItemClicked]).then(function(){

                                dealService.dealCloseLost($scope.dealCloseModel).then(function(res){
                                        //console.log("Deal Stage Update Result is"+JSON.stringify(res));
                                },function(err){
                                        alert(err);
                                });
                            },function(err){
                             alert(err);
                           });
                            //console.log('Deal Stage ID is'+$scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID);
                            //console.log('Deal Stage Model ID is'+$scope.dealStages[i].DealStageModelID);
                        }
                }
                $scope.modalDealStages.hide();
            }else{
                for(var i=0;i<$scope.dealStages.length;i++){
                        if($scope.selDealStages.activeDealStage == $scope.dealStages[i].DealStageID){
                            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.dealStages[i].DealStageID;
                            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.dealStages[i].Name;
                            //console.log('Deal Stage ID is'+$scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID);
                            //console.log('Deal Stage Model ID is'+$scope.dealStages[i].DealStageModelID);
                        }
                }
                if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Close){
                    $scope.openDealStagesClose('DSC');
                    $scope.modalDealStages.hide();

                }else if(dealStageModelID == GENERAL_CONFIG.DealStageModel.Lost){
                    $scope.openDealStagesLost('DSL');
                    $scope.modalDealStages.hide();
                }
            }
        };

         /////////////////////////////////////////////////////////// Modal for Deal Stages Close /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStagesClose.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesClose = modal;
        });

        $scope.openDealStagesClose = function (val) {
            $scope.modelSelected = val;
            for(var i=0;i<$scope.currencies.length;i++){
                if($scope.currencies[i].CurrencyID == $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealSizeCurrencyID){
                    $scope.user.dealSizeCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.actualDealSize = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealSize;
            $scope.user.actualDealSizeConverted = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealSizeConverted;

            for(var i=0;i<$scope.currencies.length;i++){
                if($scope.currencies[i].CurrencyID == $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealRevenueCurrencyID){
                    $scope.user.dealRevenueCurrencyObject = $scope.currencies[i];
                    break;
                }
            }
            $scope.user.actualDealRevenue = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealRevenue;
            $scope.user.actualDealRevenueConverted = $scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealRevenueConverted;

            
            dealService.sqlGetContactCustomerID($scope.dealList[$scope.selDealStages.dealItemClicked].ContactDeviceObjID).then(function(result){
                for (var i = 0; i < result.rows.length; i++) {
                    if(result.rows.item(i).CustomerID == '0'){
                        $scope.user.actualDealCustomerID == '';
                    }else{
                        $scope.user.actualDealCustomerID = result.rows.item(i).CustomerID;
                    }
                }
            },function(err){
                alert(err);
            });

            $scope.modalDealStagesClose.show();
        };
        $scope.closeDealStagesClose = function () {
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.selDealStages.previousDealStageID;
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.selDealStages.previousDealStageName;
            $scope.modalDealStagesClose.hide();
        };

        $scope.actionDealStagesClose = function () {
            if(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == ''){
                $cordovaDialogs.confirm('Are you sure you do not want to enter client ID ?', 'SalesARM', ['Yes','No'])
                .then(function(buttonIndex) {
                    if(buttonIndex == 1){
                        $scope.closeDealStageConfirm();
                    }
                });
            }else{
                $scope.closeDealStageConfirm();
            }
        };

        $scope.closeDealStageConfirm = function(){
            $scope.dealCloseModel = dealService.dealCloseLostMod().uiObject;
            $scope.dealCloseModel.DeviceObjID = $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID;
            $scope.dealCloseModel.DealID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealID;
            $scope.dealCloseModel.ActualDealCloseDate = utility.getDateInServerFormatFromToday(new Date()).toString();
            $scope.dealCloseModel.ActualDealRevenue = $scope.user.actualDealRevenue;
            $scope.dealCloseModel.ActualDealRevenueConverted = $scope.user.actualDealRevenueConverted;
            $scope.dealCloseModel.ActualDealRevenueCurrencyConvRate = $scope.user.dealRevenueCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealRevenueCurrencyID = $scope.user.dealRevenueCurrencyObject.CurrencyID;
            $scope.dealCloseModel.ActualDealSize = $scope.user.actualDealSize;
            $scope.dealCloseModel.ActualDealSizeConverted = $scope.user.actualDealSizeConverted;
            $scope.dealCloseModel.ActualDealSizeCurrencyConvRate = $scope.user.dealSizeCurrencyObject.ConversionValue;
            $scope.dealCloseModel.ActualDealSizeCurrencyID = $scope.user.dealSizeCurrencyObject.CurrencyID;
            $scope.dealCloseModel.DealStageID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID;
            $scope.dealCloseModel.DealStageName = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName;
            $scope.dealCloseModel.ModifiedBy = lgnUser.UserID;
            var dateStringInUTC = utility.getDateStringInUTC(new Date());
            $scope.dealCloseModel.ModifiedOn = dateStringInUTC;
            if(!(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == '')){
                $scope.dealCloseModel.CustomerID = $scope.user.actualDealCustomerID;
            }
            $scope.dealStageModelID = utility.dealStageModelIDCheck($scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID);
            $scope.dealList[$scope.selDealStages.dealItemClicked].ActualDealSizeConverted = $scope.user.actualDealSizeConverted;
            $scope.dealList[$scope.selDealStages.dealItemClicked].ActualDealRevenueConverted = $scope.user.actualDealRevenueConverted;
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageModelIDToCheck = $scope.dealStageModelID;
            $scope.dealList[$scope.selDealStages.dealItemClicked].Priority = utility.getColorCodeForDeals($scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealCloseDate, $scope.dealStageModelID);


            dealService.dealCloseToSql($scope.dealCloseModel).then(function(result){
                dealService.dealCloseLost($scope.dealCloseModel).then(function(res){
                    if(!(typeof $scope.user.actualDealCustomerID == 'undefined' || $scope.user.actualDealCustomerID == '')){
                        dealService.sqlUpdateContactCustomerID($scope.user.actualDealCustomerID, $scope.dealList[$scope.selDealStages.dealItemClicked].ContactDeviceObjID).then(function(customerRes){
                            //console.log("Deal Close Result is"+JSON.stringify(res));
                        },function(err){
                          alert(err);
                        });
                    }
                },function(err){
                    alert(err);
                });

            },function(err){
                alert(err);
            });


            $scope.modalDealStagesClose.hide();

        };

        /////////////////////////////////////////////////////////// Expected Deal Size Conversion ///////////////////////////////////////////////////////

        $scope.actualDealSizeConversion = function(){
            $scope.user.actualDealSizeConverted = ($scope.user.actualDealSize * $scope.user.dealSizeCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        /////////////////////////////////////////////////////////// Expected Deal Revenue Conversion ///////////////////////////////////////////////////////

        $scope.actualDealRevenueConversion = function(){
            $scope.user.actualDealRevenueConverted = ($scope.user.actualDealRevenue * $scope.user.dealRevenueCurrencyObject.ConversionValue);
        };

        ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

        $scope.removeZero = function(){
            if($scope.user.actualDealSize == 0)
                $scope.user.actualDealSize = '';
            if($scope.user.actualDealRevenue == 0)
                $scope.user.actualDealRevenue = '';
        }

         /////////////////////////////////////////////////////////// Modal for Deal Stages Lost /////////////////////////////////////////////////////////////

         $ionicModal.fromTemplateUrl('app/views/deal/dealStagesLost.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalDealStagesLost = modal;
        });

        $scope.openDealStagesLost = function (val) {
            $scope.modelSelected = val;
            $scope.modalDealStagesLost.show();
        };
        $scope.closeDealStagesLost = function () {
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID = $scope.selDealStages.previousDealStageID;
            $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName = $scope.selDealStages.previousDealStageName;
            $scope.modalDealStagesLost.hide();
        };

        $scope.actionDealStagesLost = function () {
            $scope.dealLostModel = dealService.dealCloseLostMod().uiObject;
            $scope.dealLostModel.DeviceObjID = $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID;
            $scope.dealLostModel.DealID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealID;
            $scope.dealLostModel.DealStageID = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID;
            $scope.dealLostModel.DealStageName = $scope.dealList[$scope.selDealStages.dealItemClicked].DealStageName;
            $scope.dealLostModel.ModifiedBy = lgnUser.UserID;
            var dateStringInUTC = utility.getDateStringInUTC(new Date());
            $scope.dealLostModel.ModifiedOn = dateStringInUTC;

            var dealStageModelID = utility.dealStageModelIDCheck($scope.dealList[$scope.selDealStages.dealItemClicked].DealStageID);
            $scope.dealList[$scope.selDealStages.dealItemClicked].Priority = utility.getColorCodeForDeals($scope.dealList[$scope.selDealStages.dealItemClicked].ExpectedDealCloseDate, dealStageModelID);


            if ($scope.user.notes != '') {
                $scope.dealLostModel.Note = {
                    DeviceObjID: utility.generateUUID(),
                    EntityID: $scope.dealList[$scope.selDealStages.dealItemClicked].DealID,
                    ModuleID: GENERAL_CONFIG.MODULES.Deal,
                    NoteID: 0,
                    ParentDeviceObjID: $scope.dealList[$scope.selDealStages.dealItemClicked].DeviceObjID,
                    Description: $scope.user.notes,
                    CreatorID: lgnUser.UserID,
                    CreatorName: lgnUser.UserName,
                    CreatedOn: utility.getDateStringInUTC(new Date()),
                    CreatedAt: $scope.dealList[$scope.selDealStages.dealItemClicked].CreatedAt,
                    ModifiedBy: null,
                    ModifiedOn: utility.getDateStringInUTC(new Date()),
                    ModifiedAt: $scope.dealList[$scope.selDealStages.dealItemClicked].ModifiedAt
                };

            dealService.dealLostToSql($scope.dealLostModel).then(function(result){
                dealService.dealCloseLost($scope.dealLostModel).then(function(res){
                    //console.log("Deal Lost Result is"+JSON.stringify(res));
                    dealService.dealLostUpdateNotesToSql(res).then(function(result){

                    },function(err){
                        alert(err);
                    });
                },function(err){
                    alert(err);
                });
            },function(err){
                alert(err);
            });

                $scope.modalDealStagesLost.hide();

                //console.log('Notes String'+JSON.stringify($scope.dealModel.Notes));
            }

        }

        //############### LoggedInAs User  functionality START ##############
        $ionicModal.fromTemplateUrl('app/views/common/loggedInAsUserList.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function (modal) {
            $scope.modalLoginAsUsers = modal;
        });

        $scope.loggedInUsers = [];
        var loggedInUserInfo = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.selfLoggedInID = loggedInUserInfo.UserID;

        $scope.selectedUser = function(index,isSelfUser)
        {
             utility.selectedLogginAsUser(index,isSelfUser,$scope.modalLoginAsUsers,$scope.loggedInUsers).then(function(res){
                 loadData();
                 if ($rootScope.isAccessingOtherUserProfile) {
                     homeService.syncServerRecords();
                 }
            });
        }


        $scope.openLogInUserMenu = function () {
            $scope.loggedInUsers = [];
            utility.loadLoggodInAsUsers($scope.loggedInUsers);
            $scope.modalLoginAsUsers.show();

        };
        $scope.closeLogInMenu = function () {
            $scope.modalLoginAsUsers.hide();
            $scope.loggedInUsers = [];
        };
     //############### LoggedInAs User  functionality END ##############

        ///////////////////////// Modal filter start///////////////////////////////
        $scope.finalFilterData = [];
        $scope.FilterOptions = [];
        $scope.filterFlag = true;
        function loadFilter() {
            var retFilterData = utility.getMasterDataByKey(GENERAL_CONFIG.FilterKey.dealFilterData);
            if (typeof retFilterData == 'undefined' || retFilterData == '' || retFilterData == null) {
                $scope.FilterOptions = [
                         {
                             Title: "Owner",
                             FilterData: [
                                 { ID: 1, Text: "Owner by me", Checked: true },
                                 { ID: 2, Text: "Owner by others", Checked: true }
                             ]
                         },
                         {
                             Title: "Tier",
                             FilterData: [
                                 { ID: 1, Text: "Tier 1", Checked: true },
                                 { ID: 2, Text: "Tier 2", Checked: true },
                                 { ID: 3, Text: "Tier 3", Checked: true },
                                 { ID: 4, Text: "Tier 4", Checked: true }
                             ]
                         },
                         {
                             Title: "Status",
                             FilterData: [
                                 { ID: 1, Text: "Overdue", Checked: true },
                                 { ID: 2, Text: "Due", Checked: true },
                                 { ID: 3, Text: "Not Yet Due", Checked: true },
                                 { ID: 4, Text: "Close", Checked: true },
                                 { ID: 5, Text: "Cancel", Checked: true }
                             ]
                         }
                ];
            }
            else {
                $scope.FilterOptions = retFilterData;
            }
        }

        $ionicModal.fromTemplateUrl('app/views/deal/dealFilter.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalactfilter = modal;
        });

        $scope.openFilter = function () {
            $scope.modalactfilter.show();
            loadFilter();

            //var retFilterData = utility.getMasterDataByKey('activityFilterData');
            //if (typeof retFilterData == 'undefined' || retFilterData == '') return;
            //$scope.filterOptions = retFilterData;
        };

        $scope.closeFilter = function () {
            $scope.modalactfilter.hide();
        };

        $scope.actionFilter = function (type) {
            $scope.filterFlag = true;
            $scope.finalFilterData = [];
            var filterList = [];
            var newList = [];
            var filterTierArr = [];
            var filterPriorityArr = [];
            var filterOwnerArr = [];
            angular.forEach($scope.FilterOptions, function (obj) {
                angular.forEach(obj.FilterData, function (item) {
                    if (item.Checked) {
                        var objFilter = [];
                        if (obj.Title == 'Tier') {
                            filterTierArr.push(item.ID);
                        }
                        else if (obj.Title == 'Owner') {
                            switch (item.ID) {
                                case 1:
                                    {
                                        filterOwnerArr.push($rootScope.loggedInUserID);
                                    }
                                    break;
                                case 2:
                                    {
                                        filterOwnerArr.push('!' + $rootScope.loggedInUserID);
                                    }
                                    break;
                                default:
                            }
                        }
                        else if (obj.Title == 'Status') {
                            switch (item.ID) {
                                case 1:
                                    {
                                        filterPriorityArr.push(item.ID);    //overdue                                                                          
                                    }
                                    break;
                                case 2:
                                    {
                                        filterPriorityArr.push(3); //due                                                                       
                                    }
                                    break;
                                case 3:
                                    {
                                        filterPriorityArr.push(2);//not yet due
                                    }
                                    break;
                                case 4:
                                    {
                                        filterPriorityArr.push(4);//close
                                    }
                                    break;
                                case 5:
                                    {
                                        filterPriorityArr.push(5);//cancel
                                    }
                                    break;
                                default:
                            }
                        }
                    }
                });

            });

            var filterFinalData = {};
            if (filterTierArr.length > 0) {
                filterFinalData.ContactTierID = filterTierArr;
                $scope.filterFlag = false;
            }
            if (filterPriorityArr.length > 0) {
                filterFinalData.Priority = filterPriorityArr;
                $scope.filterFlag = false;
            }

            if (filterOwnerArr.length > 0) {
                filterFinalData.OwnerID = filterOwnerArr;
                $scope.filterFlag = false;
            }

            if ($scope.filterFlag && type == 'D') {
                filterTierArr.push(-1);
                filterFinalData.ContactTierID = filterTierArr;
            }


            $scope.selectedFilter = filterFinalData;
            utility.setMasterData(GENERAL_CONFIG.FilterKey.dealFilterData, $scope.FilterOptions);
            if (type == 'R') {
                return;
            }
            $scope.modalactfilter.hide();

        };

        $scope.selectedAll = true;
        $scope.checkAll = function () {
            $scope.selectedAll = !$scope.selectedAll;
            angular.forEach($scope.FilterOptions, function (obj) {
                angular.forEach(obj.FilterData, function (item) {
                    item.Checked = $scope.selectedAll;
                });
            });
        }

        $scope.childCheck = function () {
            angular.forEach($scope.FilterOptions, function (obj) {
                angular.forEach(obj.FilterData, function (item) {
                    if (!item.Checked) {
                        $scope.selectedAll = false;
                    }
                });
            });
        }
        ///////////////////////filter end//////////////////

    };

})();
