import React from 'react'
import _ from 'lodash'
import { withStyles } from '@material-ui/core/styles'
import Table from '@material-ui/core/Table'
import TableBody from '@material-ui/core/TableBody'
import TableCell from '@material-ui/core/TableCell'
import TablePagination from '@material-ui/core/TablePagination'
import TableRow from '@material-ui/core/TableRow'
import ItemsHead from './ItemsHead'
import UpIcon from '@material-ui/icons/KeyboardArrowUp'
import DownIcon from '@material-ui/icons/KeyboardArrowDown'
// import RemoveCircle from '@material-ui/icons/RemoveCircle'
import Checkbox from '@material-ui/core/Checkbox'
import { sortData, getFormatedDate, getStatusStyle, getStatusFormat } from '../common/Utils/CommonUtils'
import IconButton from '@material-ui/core/IconButton'
// import GrouperDialog from '../common/GrouperDialog/GrouperDialog'
import Tooltip from '@material-ui/core/Tooltip'
import NoImage from '../../images/no-image.png'
// import LoadingHOC from '../common/HOC/LoadingHOC'

import Input from '@material-ui/core/Input'
import InputLabel from '@material-ui/core/InputLabel'
import FormControl from '@material-ui/core/FormControl'

const styles = theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing.unit * 3,
  },
  content: {
    marginBottom: 150,
    padding: '0px 24px',
  },
  tableWrapper: {
    overflowX: 'auto',
  },
  iconButton: {
    marginLeft: '10px',
    height: 24,
    width: 24,
    margin: 0,
    color: '#1976d2',
    verticalAlign: 'top',
    display: 'block',
  },
  removeIcon: {
    color: '#1976d2',
    marginLeft: 12,
    cursor: 'pointer',
  },
  alignCenter: {
    textAlign: 'center',
  },
  cellPadding: {
    padding: '0px 5px',
    textAlign: 'left',
  },
  cellPaddingCenter: {
    padding: '0px 5px',
    textAlign: 'center',
  },
  highlightBg: {
    background: '#FEF5F5',
    '&:hover': {
      background: '#FFD9D9 !important',
    },
  },
  saveIconDisabled: {
    color: '#ccc',
  },
  groupStateRFL: {
    backgroundColor: '#85D2ED',
    padding: 5,
    fontSize: 10,
  },
  groupStateRFO: {
    backgroundColor: '#FFF7C0',
    padding: 5,
    fontSize: 10,
  },
  groupStateIn: {
    backgroundColor: '#FCBE86',
    padding: 5,
    fontSize: 10,
  },
  groupStateHis: {
    backgroundColor: '#C0BEC1',
    padding: 5,
    fontSize: 10,
  },
  productImgStyle: {
    width: 46,
    height: 46,
    textAlign: 'center',
    margin: '3px 3px 0px 3px',
  },
  removeBlock: {
    '&:hover': {
      background: 'rgba(0, 0, 0, 0.08)',
    },
  },
  formControl: {
    width: '80%',
  },
})

class GroupItems extends React.Component {
  constructor (props) {
    super(props)
    let themeTcinStateValue = this.props.themeTcinStateValue

    this.state = {
      order: 'asc',
      orderBy: 'sort_order',
      selected: '',
      removeSelected: [],
      selectedItem: undefined,
      drawerOpenStatus: false,
      data: [],
      originalData: [],
      page: 0,
      rowsPerPage: 20,
      rowsPerPageOptions: [20, 50, 100],
      isSelected: '',
      columnData: [],
      themes: [],
      themeTcinStateValue,
    }
  }

  componentWillMount () {
    const { groupDetails, defaultSelected, themeTcinStateValue } = this.props
    this.updateColumnData(groupDetails, defaultSelected, themeTcinStateValue)
  }
  componentWillReceiveProps (nextProps) {
    const { groupDetails, defaultSelected, themeTcinStateValue } = nextProps
    this.updateColumnData(groupDetails, defaultSelected, themeTcinStateValue)
  }

  updateColumnData = (groupDetails, defaultSelected, themeTcinStateValue) => {
    const columnData = [
      { id: 'sort_order', numeric: false, disablePadding: true, label: 'Order' },
      { id: 'tcin', numeric: false, disablePadding: false, label: 'TCINS' },
      { id: 'image', numeric: false, disablePadding: false, label: 'Image' },
      { id: 'product_title', numeric: false, disablePadding: false, label: 'Product Title' },
    ]
    if (groupDetails.themes) {
      let count = 1
      groupDetails.themes.map((option) => {
        columnData.push({ id: option.attribute, numeric: false, disablePadding: false, label: 'Theme' + count + ' ' + option.attribute })
        count++
      })
    }
    if (groupDetails.group_type === 'collection') {
      columnData.push({ id: 'item_type', numeric: false, disablePadding: false, label: 'Item Type' })
      columnData.push({ id: 'relationship_type_code', numeric: false, disablePadding: false, label: 'Relationship Type' })
    }
    columnData.push({ id: 'created_date', numeric: false, disablePadding: false, label: 'Date Added' })
    columnData.push({ id: 'launch_date', numeric: false, disablePadding: false, label: 'Launch Date' })
    columnData.push({ id: 'item_state', numeric: false, disablePadding: false, label: 'Status' })
    columnData.push({ id: 'move', numeric: false, disablePadding: false, label: 'Move' })
    columnData.push({ id: 'remove', numeric: false, disablePadding: false, label: 'Remove' })
    this.setState({ data: groupDetails.items, originalData: groupDetails.items, columnData, themes: groupDetails.themes })
    this.setState({ removeSelected: defaultSelected, themeTcinStateValue })
  }

      handleRequestSort = (event, property) => {
        const orderBy = property
        let order = 'desc'

        if (this.state.orderBy === property && this.state.order === 'desc') {
          order = 'asc'
        }

        const data =
          order === 'desc'
            ? this.state.data.sort((a, b) => (b[orderBy] < a[orderBy] ? -1 : 1))
            : this.state.data.sort((a, b) => (a[orderBy] < b[orderBy] ? -1 : 1))

        this.setState({ data, order, orderBy })
      };

      handleChangePage = (event, page) => {
        this.setState({ page })
      };

      handleChangeRowsPerPage = event => {
        this.setState({ rowsPerPage: event.target.value })
      };

      isSelected = id => this.state.selected === id
      isRemoveSelected = id => this.state.removeSelected.indexOf(id) !== -1;

      moveItemUp = (item) => {
        this.setState({ selected: item.tcin })
        this.props.moveItemUp(item)
      }

      moveItemDown = (item) => {
        this.setState({ selected: item.tcin })
        this.props.moveItemDown(item)
      }

      validateDelete = (event, item) => {
        // this.setState({dialogOpenStatus: true, selectedItem: item})
      };

      deleteConfirm = (status) => {
        if (status) {
          const { groupDetails, auth } = this.props
          const { selectedItem } = this.state
          if (selectedItem && groupDetails && groupDetails.group_id) {
            let tcinData = [{ tcin: selectedItem.tcin, action: 'DELETED' }]
            groupDetails.items.map((data, i) => {
              if (data.tcin !== selectedItem.tcin && data.sort_order > selectedItem.sort_order) {
                tcinData.push({ tcin: data.tcin, sort_order: data.sort_order - 1, action: 'UPDATED' })
              }
            })
            let payload = {
              tcin_data: tcinData,
            }
            payload.description = groupDetails.description
            payload.group_name = groupDetails.group_name
            payload.group_type = groupDetails.group_type
            payload.group_id = groupDetails.group_id
            payload.group_type_id = groupDetails.group_type_id
            payload.status = groupDetails.status
            payload.item_type_id = groupDetails.item_type_id
            payload.item_type = groupDetails.item_type
            payload.themes = groupDetails.themes
            this.props.removeTcins(payload, auth.memberOf, auth.lanId)
          }
          this.setState({dialogOpenStatus: false, selectedItem: undefined, removeSelected: []})
        }
        if (!status) {
          this.setState({ dialogOpenStatus: false, selectedItem: undefined, removeSelected: [] })
        } else {
          setTimeout(() => {
            this.setState({ dialogOpenStatus: false, selectedItem: undefined, removeSelected: [] })
          }, 3000)
        }
      }

      checkErrorTcin (tcin) {
        if (this.props.groupDetailsErrorTcins.indexOf(tcin) !== -1) {
          return 'highlightBg'
        }
        return { background: '#fff' }
      }

      checkErrorTcinText (tcin) {
        if (this.props.groupDetailsErrorTcins.indexOf(tcin) !== -1) {
          const errObj = _.find(this.props.groupDetails.validation_error, (n) => { return n.tcin === tcin })
          return errObj
        }
        return false
      }

      checkProdTitleColor (tcin) {
        if (this.props.groupDetailsErrorTcins.indexOf(tcin) !== -1) {
          return { color: '#ff3838' }
        }
        return { color: '#000' }
      }

      handleRemoveClick = (id) => (event) => {
        const { removeSelected } = this.state
        const selectedIndex = removeSelected.indexOf(id)
        let newSelected = []

        if (selectedIndex === -1) {
          newSelected = newSelected.concat(removeSelected, id)
        } else if (selectedIndex === 0) {
          newSelected = newSelected.concat(removeSelected.slice(1))
        } else if (selectedIndex === removeSelected.length - 1) {
          newSelected = newSelected.concat(removeSelected.slice(0, -1))
        } else if (selectedIndex > 0) {
          newSelected = newSelected.concat(
            removeSelected.slice(0, selectedIndex),
            removeSelected.slice(selectedIndex + 1),
          )
        }

        this.setState({ removeSelected: newSelected })
        this.props.removeSelectedCB(newSelected)
      };

      handleSelectAllClick = (event) => {
        let newAllSelected = []
        if (event.target.checked) {
          newAllSelected = this.props.groupDetails.items.map(n => n.tcin)
          this.setState({ removeSelected: newAllSelected })
          this.props.removeSelectedCB(newAllSelected)
          return
        }
        this.setState({ removeSelected: newAllSelected })
        this.props.removeSelectedCB(newAllSelected)
      }

      updateThemeValue = (opt, tcin) => (event) => {
        const { themeTcinStateValue } = this.state
        let tcinObjArr = []
        themeTcinStateValue.map((tcinObj) => {
          let tempArr = []
          if (parseInt(tcinObj.tcin) === parseInt(tcin)) {
            tcinObj.var_theme_value_list.map((option) => {
              if (parseInt(option.id) === parseInt(opt.id)) {
                option.value = event.target.value
              }
              tempArr.push(option)
            })
            tcinObj.var_theme_value_list = tempArr
          }
          tcinObjArr.push(tcinObj)
        })
        this.setState({ themeTcinStateValue: tcinObjArr })
        this.props.updateThemeValueCB(tcinObjArr)
      }

      getThemesColumns = (themes, obj, classes) => {
        if (themes) {
          return themes.map((option, i) => {
            let themeValueField = ''
            // if (!this.props.editThemeValueStatus && obj.variation_theme_values && obj.variation_theme_values[option.attribute]) {
            if (!this.props.editThemeValueStatus && obj.variation_theme_values) {
              themeValueField = obj.variation_theme_values[option.attribute]
            } else {
              const curTcinRow = _.find(this.props.groupDetails.tcin_data, (e) => { return parseInt(e.tcin) === parseInt(obj.tcin) })
              const curThemeValue = _.find(curTcinRow.var_theme_value_list, (e) => { return parseInt(e.id) === parseInt(option.id) })
              const curValue = (curThemeValue && curThemeValue.value) ? curThemeValue.value : ''
              themeValueField = (<FormControl className={classes.formControl} aria-describedby="name-helper-text">
                <InputLabel htmlFor="mta-value-helper">MTA Display Values</InputLabel>
                <Input id="mta-value-helper" value={curValue} onChange={this.updateThemeValue(option, obj.tcin)} />
              </FormControl>)
            }
            return (
              <TableCell key={i} padding="dense" className={classes.cellPadding}>{themeValueField}</TableCell>
            )
          })
        }
      }

      render () {
        const { classes, groupDetails, groupTcinData } = this.props
        const { order, orderBy, rowsPerPage, rowsPerPageOptions, page, themes, removeSelected } = this.state
        let items = (groupDetails.items) ? groupDetails.items : []
        return (
          <div className={classes.content}>
            <div className={classes.tableWrapper}>
              <TablePagination
                component="div"
                count={items.length}
                rowsPerPage={rowsPerPage}
                rowsPerPageOptions={rowsPerPageOptions}
                page={page}
                backIconButtonProps={{
                  'aria-label': 'Previous Page',
                }}
                nextIconButtonProps={{
                  'aria-label': 'Next Page',
                }}
                onChangePage={this.handleChangePage}
                onChangeRowsPerPage={this.handleChangeRowsPerPage}
              />
              <Table className={classes.table} aria-labelledby="tableTitle">
                <ItemsHead
                  order={order}
                  orderBy={orderBy}
                  onRequestSort={this.handleRequestSort}
                  rowCount={items.length}
                  columnData={this.state.columnData}
                  onSelectAllClick={this.handleSelectAllClick}
                  numSelected={removeSelected.length}
                />
                <TableBody>
                  {items.sort(sortData(order, orderBy))
                    .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                    .map((obj, key) => {
                      const isSelected = this.isSelected(obj.tcin)
                      const isRemoveSelected = this.isRemoveSelected(obj.tcin)
                      const getBgAttr = this.checkErrorTcin(obj.tcin)
                      const getErrorTcinText = this.checkErrorTcinText(obj.tcin)
                      const getProdTitleColor = this.checkProdTitleColor(obj.tcin)
                      let ProductImage = NoImage
                      if ((obj.image_base_url && obj.image_base_url !== null) && (obj.primary_image && obj.primary_image !== null)) {
                        ProductImage = 'https:' + obj.image_base_url + obj.primary_image + '?wid=46&hei=46&qlt=60&fmt=pjpeg'
                      }
                      const tcinObj = _.find(groupTcinData, (e) => { return parseInt(e.tcin) === parseInt(obj.tcin) })
                      return (
                        <TableRow
                          hover
                          aria-checked={isSelected}
                          tabIndex={-1}
                          key={key}
                          selected={isSelected}
                          className={classes[getBgAttr]}
                        >
                          <TableCell padding="dense" className={classes.cellPaddingCenter}>{tcinObj.sort_order}</TableCell>
                          <TableCell padding="dense" className={classes.cellPaddingCenter}>{obj.tcin}</TableCell>
                          <TableCell padding="dense" className={classes.cellPaddingCenter}>
                            <img src={ProductImage} alt="primary" className={classes.productImgStyle} />
                          </TableCell>
                          <TableCell padding="dense" className={classes.cellPadding} style={getProdTitleColor}>
                            {getErrorTcinText ? (
                              <Tooltip title={getErrorTcinText.message} placement="top-start">
                                <span dangerouslySetInnerHTML={{__html: obj.product_title}} />
                              </Tooltip>
                            ) : (
                              <span dangerouslySetInnerHTML={{__html: obj.product_title}} />
                            )}

                          </TableCell>
                          {this.getThemesColumns(themes, obj, classes)}
                          {/* themes.map((option, i) => {
                            return (
                              <TableCell key={i} padding="dense" className={classes.cellPadding}>{obj.variation_theme_values[option.attribute]}</TableCell>
                            )
                          }) */
                          }
                          {groupDetails.group_type === 'collection' &&
                            <TableCell padding="dense" className={classes.cellPaddingCenter}>{obj.item_type}</TableCell>
                          }
                          {groupDetails.group_type === 'collection' &&
                            <TableCell padding="dense" className={classes.cellPaddingCenter}>{obj.relationship_type_code}</TableCell>
                          }
                          <TableCell padding="dense" className={classes.cellPaddingCenter}>{getFormatedDate(obj.created_date)}</TableCell>
                          <TableCell padding="dense" className={classes.cellPaddingCenter}>{getFormatedDate(obj.launch_date)}</TableCell>
                          <TableCell padding="dense" className={classes.cellPaddingCenter}><span className={classes[getStatusStyle(obj.item_state)]}>{getStatusFormat(obj.item_state)}</span></TableCell>
                          <TableCell padding="dense" className={classes.cellPaddingCenter}>
                            {tcinObj.sort_order === 1 ? (
                              <IconButton color="inherit" className={classes.iconButton} component="div"><UpIcon className={classes.saveIconDisabled} /></IconButton>
                            ) : (
                              <IconButton color="inherit" className={classes.iconButton} component="div" onClick={(e) => this.moveItemUp(tcinObj)}><UpIcon className={classes.saveIcon} /></IconButton>
                            )
                            }
                            {tcinObj.sort_order === items.length ? (
                              <IconButton color="inherit" className={classes.iconButton} component="div"><DownIcon className={classes.saveIconDisabled} /></IconButton>
                            ) : (
                              <IconButton color="inherit" className={classes.iconButton} component="div" onClick={(e) => this.moveItemDown(tcinObj)}><DownIcon className={classes.saveIcon} /></IconButton>
                            )}
                          </TableCell>
                          {/* <TableCell padding="dense" className={classes.cellPadding}>
                            <RemoveCircle onClick={(e) => this.validateDelete(e, obj)} className={classes.removeIcon} />
                          </TableCell> */}
                          <TableCell padding="checkbox" className={classes.cellPaddingCenter}>
                            <Checkbox className={classes.removeBlock} checked={isRemoveSelected} color="default" onClick={this.handleRemoveClick(obj.tcin)} />
                          </TableCell>
                        </TableRow>
                      )
                    })}
                </TableBody>
              </Table>
              <TablePagination
                component="div"
                count={items.length}
                rowsPerPage={rowsPerPage}
                rowsPerPageOptions={rowsPerPageOptions}
                page={page}
                backIconButtonProps={{
                  'aria-label': 'Previous Page',
                }}
                nextIconButtonProps={{
                  'aria-label': 'Next Page',
                }}
                onChangePage={this.handleChangePage}
                onChangeRowsPerPage={this.handleChangeRowsPerPage}
              />
              {/* <GrouperDialog
                openStatus={dialogOpenStatus}
                deleteConfirmCallback={this.deleteConfirm}
                title="Delete Item confirmation"
                message={(selectedItem) ? `Are you sure to delete the Item? : ${selectedItem.tcin}` : ''}
              /> */}
            </div>
          </div>
        )
      }
}

export default withStyles(styles)(GroupItems)
