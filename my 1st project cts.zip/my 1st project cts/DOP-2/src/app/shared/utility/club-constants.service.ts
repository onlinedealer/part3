import { Injectable } from '@angular/core';

@Injectable()
export class ClubConstantsService {

  constructor() { }

  // This provides the error message text for profile completion form and services
  getClubCompletionErrorMessages() {
    return {
      'profileCompleteEmailEmpty': 'Enter a valid email address',
      'profileCompleteEmailInvalid': 'Enter a valid email address',
      'profileCompleteZipEmpty': 'Enter a valid ZIP code',
      'profileCompleteZipInvalid': 'Enter a valid ZIP code',
      'profileCompletePasswordEmpty': 'Enter a password',
      'profileCompletePasswordInvalid': 'Enter a valid password',
      'profileCompleteConfPasswordEmpty': 'Confirm your password',
      'profileCompleteConfPasswordInvalid': 'Confirm your password',
      'profileCompleteSecAnsEmpty': 'Enter a security answer',
      'profileCompleteSecAnsInvalid': 'Enter a valid security answer',
      'emailZipMisMatchServiceErrorGt1': 'Your email or ZIP code don\'t match our records. Please try again.',
      'emailZipMisMatchServiceErrorEq1': 'Your email or ZIP code don\'t match our records.' +
                                       'You have [X] more attempt before you\'ll be locked out.',
      'validationLinkExpiredHeader': 'Your link has expired',
      'validationLinkExpired': 'We\'re sorry. Your link has expired.' +
                                'If you need assistance, you can contact CarePass™ Customer Care at 1-833-320-CARE.',
      'accountLockedHeader': 'Let\'s pause for a moment.',
      'accountLocked': 'You\'ve reached the maximum number of attempts.' +
                       'Please try again after 30 minutes, by returning to your activation email and clicking the verification button.'
    };
  }

  // This provides the generic error messages for overall CVS club application
  getCVSClubGenericMessages() {
    return{
      'genericError': 'Something is wrong on our end. We\'re working to fix this issue, please try again.',

      'tryAgainBtnText': 'Try again',
      'headerText': 'We\'re sorry.'
    };
  }

   // This provides the error message text for error message
  getClubCompletionContent() {
    return{
      'profileCompleteWelcomeMessage': 'Unlock all your CarePass™ benefits now.',
      'profileCompletionRegistrationDate': 'You started your CarePass enrollment when you visited a CVS Pharmacy®.' +
          'To unlock all your CarePass benefits and access your new CVS.com® account, verify the information you provided in-store.',
      'profileCompleteEmailSubText': 'The email address you gave at sign up.',
      'profileCompletePasswordSubText': 'Must be at least 8 characters, with at least 1 number and 1 letter.',
      'profileCompletionCreatePasswordText': 'Create a password and provide a security answer.',
      'defaultSecurityCode': '1005',
      'passwordRegexPattern': '(?=.*[\\d])(?=.*[A-Za-z!@#$%^&*])[\\w!@#$%^&*]{8,22}',
      'emailPattern': '^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$',
      'zipPattern': '^\\d{5}$',
      'noOfAttempts': 3,
      'completeEnrolmentHeadline': 'Last step: complete your CVS.com® account.'
    };
  }

  // This provides the error messages for club billing and payment for forms and service
  getBillingPayErrorMessages() {
    return {
      'cvvEmpty': 'Enter a valid CVV',
      'cvvInvalid': 'Enter a valid CVV',
      'agreementEmpty': 'Accepting terms and conditions is required',
      'agreementInvalid': 'Accepting terms and conditions is required',
      'firstNameEmpty': 'Enter a valid first name',
      'firstNameInvalid': 'Enter a valid first name',
      'lastNameEmpty': 'Enter a valid last name',
      'lastNameInvalid': 'Enter a valid last name',
      'address1Empty': 'Enter a valid address',
      'cityEmpty': 'Enter a valid city',
      'cityInvalid': 'Enter a valid city',
      'stateEmpty': 'Select your state',
      'zipCodeEmpty': 'Enter a valid ZIP code',
      'zipCodeInvalid': 'Enter a valid ZIP code',
      'paymentCancellationEmpty': 'Authorizing recurring payments is required',
      'paymentCancellationInvalid': 'Authorizing recurring payments is required',
      'fsaErrorMsg': 'We can\'t accept FSA cards to pay for your CarePass membership. Enter a valid credit card number.',
      'prepaidErrorMsg': 'We can\'t accept prepaid cards to pay for your CarePass membership.',
      'prepaidErrorMsgDtls': 'Enter a valid card number.'
    };
  }

  getBillingPayContent() {
    return{
      'billingPayBillingAddress': 'Billing address',
      'paymentHeader': 'How would you like to pay?',
      'order': {
        'total': 'Order total',
        'subtotal': 'Subtotal:',
        'carepassFreeMonth': 'CarePass free month:',
        'tax': 'Tax:'
      },
      'createSubscription': 'Finish',
      'creditCardTxt': 'Credit card number',
      'cvvTxt': 'CVV',
      'tAndC': 'Terms and conditions',
      'tAndCMsg': 'I acknowledge receipt of the CarePass terms and conditions, which contain further information about the membership as well as cancellation and refund policies.',
      'tAndCLink': 'Read the terms and conditions',
      'paymentCancellationTitle': 'Payment and cancellation',
      'paymentCancellationMsg': 'I authorize recurring charges to my card to pay for my CarePass membership. This will remain in effect until I revoke it.  I may call 1-833-320-CARE Monday-Friday 8 am–11 pm ET, 8:30 am–9 pm ET Saturday-Sunday (except major holidays) to cancel my authorization and my membership no later than 3 days before the renewal date. I understand that I will be notified via email of any changes to this authorization agreement. <br><br>No refunds for monthly memberships after charge is processed.'
    };
  }

  getOrderConfirmationContent() {
    return{
      'orderConfirmationHeader': 'Thanks for joining CarePass™!',
      'orderConfirmationBody': 'Take a look at your CarePass dashboard, review your benefits, and make the most of your membership.',
      'orderConfirmationGetStarted': 'Get started'
    };
  }

  getNavigationUrls(){
    return{
      'clubBenefits':'/join',
      'clubDashboard':'/dashboard',
      'clubRegistration':'/go',
      'clubPaymentBillingDetails':'/payment',
      'profileCompletion':'profileCompletion',
      'clubOrderConfirmation':'clubOrderConfirmation',
      'carepassLookUp':'carepassLookUp'
    }
  }

  /* Gets the static text for carepass look up component */
  getLookUpContent(){
    return{
      'headerText': 'Is CarePass near me?',
      'subHeaderText': 'CarePass is available in some areas. Find out if you\'re close-by.',
      'zipNotFoundHeaderText': 'Thanks for your interest! CarePass is coming soon.',
      'zipNotFoundSubHeaderText1': 'CarePass isn\'t available in your area, not yet anyway. Please check back soon!',
      'zipNotFoundButtonText': 'Start shopping',
      'zipPattern': '^\\d{5}$'
    };
  }
}

export const RouteConfigurations = {
  'clubBenefits': 'join',
  'clubDashboard': 'dashboard',
  'clubRegistration': 'go',
  'clubPaymentBillingDetails': 'payment',
  'profileCompletion': 'profileCompletion',
  'clubOrderConfirmation': 'orderconfirmation',
  'carepassLookUp': 'carepassLookUp',
  'carepassSelfUnenroll': 'cancel',
  'clubBenefitsTitle': 'Join CarePass | CVS Pharmacy',
  'clubDashboardTitle': 'CarePass Dashboard | CVS Pharmacy',
  'clubRegistrationTitle': 'Create Your CarePass Account | CVS Pharmacy',
  'clubPaymentBillingDetailsTitle': 'CarePass Payment | CVS Pharmacy',
  'profileCompletionTitle': 'CarePass Profile Completion | CVS Pharmacy',
  'clubOrderConfirmationTitle': 'CarePass Order Confirmation | CVS Pharmacy',
  'carepassLookUpTitle': 'CarePass Zip Code Lookup | CVS Pharmacy',
  'carepassSelfUnenrollTitle': 'CarePass Cancel | CVS Pharmacy',
  'carepassBenefitsDesc': 'Join CarePass and receive exclusive member benefits that help make it easier to take care of yourself and your family!',
  'carepassLookupDesc': 'Is CarePass available near me? Check to see if CarePass is available in your location.',
  'carepassRegistrationDesc': 'Create your CarePass account today to receive exclusive member benefits.',
  'carepassPaymentDesc': 'Create your CarePass account today to receive exclusive member benefits.',
  'carepassOrderConfirmationDesc': 'We have confirmed your membership with CarePass. Welcome!',
  'carepassDashboardDesc': 'Welcome to CarePass – View your membership information, benefits and rewards now.'
};
