import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Pipeline, TableMapping } from '../shared/pipeline';
import { ColumnHeaders } from './shared/column-header';
import { ColumnMap } from './shared/map-columns';
import { TranslocoService } from '@ngneat/transloco';
import { EventApiService } from './shared/event-api.service';
import { MAPPING_CONST } from './shared/mapping_constants';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { InterceptorSkipHeader } from '@precisely/prism-ng/di-suite';
import * as _ from 'lodash';

@Injectable({
  providedIn: 'root'
})
export class PipelineMappingService {
  createTopicCheckbox: boolean = false;
  createSubjectCheckbox: boolean = false;
  mappingTableGrid;
  mappingNextActionForSidebar: Subject<any> = new Subject<any>();
  openCreateTopicsSubjectsSidebar: Subject<void> = new Subject<void>();
  refreshTableMappingGrid: Subject<void> = new Subject<void>();
  constructor(
    private readonly http: HttpClient,
    private readonly translocoService: TranslocoService,
    private readonly eventApiService: EventApiService,
    private readonly pipelineEntityService: PipelineEntityService
  ) {}

  private readonly baseUrl: string = environment.connectApiBaseURL;
  private readonly catalogUrl: string = environment.catalogApiBaseURL;

  mappingStatus = {
    NA: { icon: MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED, tooltip: '' },
    NEW: { icon: MAPPING_CONST.MAPPING_ICON_ATTENTION, tooltip: '' },
    NEW_BY_SELECTION: { icon: MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION, tooltip: '' },
    MISMATCH: { icon: MAPPING_CONST.MAPPING_ICON_ATTENTION_BLUE, tooltip: '' }
  };

  getColumnHeaders(type: string) {
    return ColumnHeaders[type];
  }

  /**
   * Get mapping for target of each row
   * @param status pipeline projectId
   * @param input input details if any
   * @returns
   */

  getMappingIcon(status: string, input1?: string, input2?: string) {
    if (status === MAPPING_CONST.MAPPING_ICON_NEW || status === MAPPING_CONST.MAPPING_ICON_NEW_BY_SELECTION) {
      this.mappingStatus[status].tooltip = this.translocoService.translate('pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP1', {
        input: input1
      });
    } else if (status === MAPPING_CONST.MAPPING_ICON_NA) {
      this.mappingStatus[status].tooltip = this.translocoService.translate('pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP2', {
        input: input1
      });
    } else {
      this.mappingStatus[status].tooltip = this.translocoService.translate('pipelines.STAGES.MAPPING.TABLE.TOOL_TIPS.TOOL_TIP3', {
        input1: input1,
        input2: input2
      });
    }
    return this.mappingStatus[status];
  }

  /**
   * Get selected tables from data tab
   * @param projectId pipeline projectId
   * @param source Source connection details
   * @param target Target connection details
   * @param mappingData Table Mapping Array Details
   * @returns
   */

  getSelectedTables(projectId: string, source: string, target: string, mappingData): Observable<any[]> {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${projectId}/selected-tables`;
    return this.http.get(endPoint).pipe(
      map((response: any) => {
        return this.processData(response, mappingData, source, target);
      })
    );
  }

  getSubjectsFromCatalog(connectionId: string) {
    const endPoint = `${this.catalogUrl}/api/v1/subjects?connection_id=${connectionId}`;
    return this.http.get(endPoint);
  }

  getSubjects(connectionId: string) {
    const endPoint = `${this.baseUrl}/metadata/subjects?connection_id=${connectionId}`;
    return this.http.get(endPoint);
  }

  getVersions(connectionId, subjectName) {
    const endPoint = `${this.catalogUrl}/api/v1/subject/versions?connection_id=${connectionId}&subject_name=${subjectName}&details=false`;
    return this.http.get(endPoint);
  }
  /**
   * Process the data after getting from the api
   * @param data API response of selected Tables
   * @param mappingData Table Mapping data if already there
   * @param source Source connection details
   * @param target Target connection details
   * @returns
   */
  processData(data: any, mappingData, source: string, target: string) {
    const sourceColumns = this.getColumnHeaders(source);
    const targetColumns = this.getColumnHeaders(target);
    const random = () => crypto.getRandomValues(new Uint32Array(1))[0] / 2 ** 32;
    this.mappingTableGrid = [];
    let previousTableData = [];
    data.forEach((item) => {
      /**
       * if mapping data already present
       * check for duplicates
       */
      if (mappingData.length) {
        previousTableData = mappingData.filter((ele) => {
          if (source === 'SQLSERVER') {
            return ele.key.trim() === item.schemaName + '||' + item.owner + '||' + item.tableName;
          } else {
            return ele.key.trim() === item.schemaName + '||' + item.tableName;
          }
        });
      }
      if (previousTableData.length) {
        // setting the remove icon for duplicate rows
        for (let i = 1; i < previousTableData.length; i++) {
          previousTableData[i]['isDuplicate'] = true;
        }
        this.addDataFromResponse(previousTableData, this.mappingTableGrid, sourceColumns, targetColumns, item, source);
      } else {
        this.addFreshData(this.mappingTableGrid, sourceColumns, targetColumns, item, random, source);
      }
    });
    return this.mappingTableGrid;
  }

  /**
   * Called when there is mapping data present
   * @param prevData Data arr of already present items
   * @param dataArr array with end response
   * @param sourceColumns Source connection details
   * @param targetColumns Target connection details
   * @param item single object from loop
   * @param source Source connection details of connectionType
   * @returns
   */

  addDataFromResponse(prevData, dataArr, sourceColumns, targetColumns, item, source) {
    prevData.forEach((e) => {
      const topic = e.value.split('||')[0];
      const subject = e.value.split('||')[1] ? e.value.split('||')[1] : '';
      const columndata = {
        id: e.id,
        hasCustomColMappings: e.hasCustomColMappings,
        [sourceColumns[0].name]: item.schemaName,
        [sourceColumns[1].name]: source === 'SQLSERVER' ? item.tableName.split('.')[0] : item.tableName + ' ',
        [targetColumns[0].name]: {
          name: topic,
          mappingIcon: '',
          iconTooltip: '',
          class: null
        },
        [targetColumns[1]?.name]: {
          name: subject,
          mappingIcon: '',
          iconTooltip: ''
        },
        isDuplicate: e.isDuplicate,
        schemaVersion: e.schemaVersion ? e.schemaVersion : null
      };
      /*for SQLServer it requires 3 columns database owner and table */
      if (source === 'SQLSERVER') {
        columndata[sourceColumns[2].name] = item.tableName.split('.')[1] + ' ';
      }
      dataArr.push(columndata);
    });
    return dataArr;
  }

  /**
   * Called when there is no mapping data
   * @param dataArr array with end response
   * @param sourceColumns Source connection details
   * @param targetColumns Target connection details
   * @param item single object from loop
   * @param source Source connection details of connectionType
   * @returns
   */

  addFreshData(dataArr, sourceColumns, targetColumns, item, random, source) {
    const columndata = {
      id: 'mapping_' + random().toString(36).substring(2, 8) + random().toString(36).substring(2, 8),
      [sourceColumns[0].name]: item.schemaName,
      [sourceColumns[1].name]: source === 'SQLSERVER' ? item.tableName.split('.')[0] : item.tableName + '',
      [targetColumns[0].name]: {
        name: '',
        mappingIcon: '',
        iconTooltip: '',
        class: null
      },
      [targetColumns[1]?.name]: {
        name: '',
        mappingIcon: '',
        iconTooltip: ''
      }
    };
    /*for SQLServer it requires 3 columns database owner and table */
    if (source === 'SQLSERVER') {
      columndata[sourceColumns[2].name] = item.tableName.split('.')[1];
    }
    dataArr.push(columndata);
  }

  /**
   * Check if button mapping page over panel are disabled
   * @param checkedRows selected row from table mapping grid
   * @returns
   */

  checkIfButtonDisabled(checkedRows) {
    if (checkedRows?.length > 0) {
      return false;
    } else {
      return true;
    }
  }

  /**
   * GetColumnMapping of a table row
   */
  getColumnMappings(pipelineID: string, tableMappingId: string, version?: string): Observable<any> {
    let endPoint = `${this.baseUrl}/cdc/dataflows/${pipelineID}/column-mappings?tableMappingId=${tableMappingId}`;
    if (version) {
      endPoint = endPoint + `&schemaVersion=${version}`;
    }
    return this.http.get(endPoint);
  }

  /**
   * save table mapping on next button click
   * @param pipelineID pipeline id from dataflow
   * @param tableMapping table mapping grid data
   */
  saveTableMapping(pipelineID: string, tableMapping) {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${pipelineID}/table-mappings/save`;
    return this.http.put(endPoint, tableMapping);
  }

  /**
   * save column mappings
   * @param pipelineID pipeline id from dataflow
   * @param tableMapping table mapping grid data
   * @param headers if any
   */

  saveColumnMapping(pipelineID: string, tableMapping: TableMapping, headers?: HttpHeaders) {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${pipelineID}/column-mappings/save`;
    return this.http.put(endPoint, tableMapping);
  }

  resetToDefault(pipelineID: string, checkedItems: ColumnMap[], tableMapping: TableMapping, headers?: HttpHeaders) {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${pipelineID}/column-mappings/reset?tableMappingId=${tableMapping.id}`;
    return this.http.put(endPoint, checkedItems);
  }

  getColumns(pipelineID: string, tableMappingId: string) {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${pipelineID}/column-mappings/source-columns?tableMappingId=${tableMappingId}`;
    return this.http.get(endPoint);
  }

  getChangeColumnMappingDefaults(projectId: string, headers?: HttpHeaders): any {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${projectId}/column-mappings/defaults`;
    return this.http.get(endPoint, { headers });
  }

  saveChangeColumnMappingDefaults(projectId: string, payloadData, headers?: HttpHeaders) {
    let columnType = payloadData.mapColumns === 'Column order' ? 'ORDINAL' : 'NAME';
    const endPoint =
      payloadData.mapColumns === undefined
        ? `${this.baseUrl}/cdc/dataflows/${projectId}/column-mappings/defaults`
        : `${this.baseUrl}/cdc/dataflows/${projectId}/column-mappings/defaults/?columnMappingType=${columnType}`;
    return this.http.put(endPoint, payloadData.payload, { headers });
  }

  bulkChangeColumnMapping(pipelineID: string, changeColumnMappingDTO, headers?: HttpHeaders) {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${pipelineID}/column-mappings/change`;
    return this.http.put(endPoint, changeColumnMappingDTO, { headers });
  }

  bulkResetToDefault(pipelineID, resetField, resetTable, checkedItems) {
    const endPoint = `${this.baseUrl}/cdc/dataflows/${pipelineID}/table-mappings/bulk-reset`;
    const params = {
      isResetColumnMappingSelected: resetField,
      isResetTableTargetSelected: resetTable
    };
    return this.http.put(endPoint, checkedItems, { params });
  }

  /**
   * get topics that don't exist
   * @param tableMapping table mapping grid data
   */

  getNonExistingTopics(tableData: []) {
    let topicsArr = tableData.filter(
      (row: { topic: { mappingIcon: string } }) =>
        row.topic.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
        row.topic.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION ||
        row.topic.mappingIcon === MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED
    );
    // as per DMX-36976 - UI should send unique topics count in totalTopics parameter
    // finding the unique topic values and then sending its length
    topicsArr = _.uniqBy(topicsArr, (item) => item.topic.name);

    return topicsArr.length;
  }

  /**
   * get subjects that don't exist
   * @param tableData table mapping grid data
   */
  getNonExistingSubjects(tableData: []) {
    let subjectsArr = tableData.filter(
      (row: { subject: { mappingIcon: string } }) =>
        row.subject?.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION ||
        row.subject?.mappingIcon === MAPPING_CONST.MAPPING_ICON_ATTENTION_SELECTION ||
        row.subject?.mappingIcon === MAPPING_CONST.MAPPING_ICON_ACTION_REQUIRED
    );
    subjectsArr = _.uniqBy(subjectsArr, (item) => item.subject.name);
    return subjectsArr.length;
  }

  /**
   * get non existing topics and subjects and initiate topic creation
   * @param pipeline pipeline dataflow
   */

  createNonExistingTopicsandSubjects(pipeline) {
    let apiUrl: string;
    const topicsLength = this.getNonExistingTopics(this.mappingTableGrid);
    const subjectLength = this.getNonExistingSubjects(this.mappingTableGrid);
    if (pipeline.createTopic && pipeline.createSubject === false) {
      apiUrl = `subjects-topics?dataflowId=${pipeline.id}&totalTopics=${topicsLength}`;
      if (topicsLength > 0) {
        this.initiateTopicsAndSubjectsCreation(apiUrl, topicsLength, subjectLength);
      } else {
        return true;
      }
    } else if (pipeline.createSubject && pipeline.createTopic === false) {
      apiUrl = `subjects-topics?dataflowId=${pipeline.id}&totalSubjects=${subjectLength}`;
      if (subjectLength > 0) {
        this.initiateTopicsAndSubjectsCreation(apiUrl, topicsLength, subjectLength);
      } else {
        return true;
      }
    } else {
      if (topicsLength > 0 && subjectLength > 0) {
        apiUrl = `subjects-topics?dataflowId=${pipeline.id}&totalTopics=${topicsLength}&totalSubjects=${subjectLength}`;
      } else if (topicsLength > 0) {
        apiUrl = `subjects-topics?dataflowId=${pipeline.id}&totalTopics=${topicsLength}`;
      } else {
        apiUrl = `subjects-topics?dataflowId=${pipeline.id}&totalSubjects=${subjectLength}`;
      }
      if (topicsLength > 0 || subjectLength > 0) {
        this.initiateTopicsAndSubjectsCreation(apiUrl, topicsLength, subjectLength);
      } else {
        return true;
      }
    }
    return false;
  }

  /**
   * get status of topic creation
   * @param dataflowId pipeline dataflowId
   * @param apiUrl dynamic API url
   * @param topicLength non existing topics array length
   * @param subjectLength non exisiting subjects array length
   */

  getStatusOfTopics(dataflowId: string, apiUrl: string, topicLength: number, subjectLength: number) {
    this.eventApiService.getStatusOfTopicsCreation(dataflowId).subscribe({
      next: (response: any) => {
        if (response.status === 'complete') {
          this.initiateTopicsAndSubjectsCreation(apiUrl, topicLength, subjectLength);
        } else {
          this.mappingNextActionForSidebar.next({ topicsLength: topicLength, subjectLength: subjectLength });
        }
      },
      error: () => {
        this.initiateTopicsAndSubjectsCreation(apiUrl, topicLength, subjectLength);
      }
    });
  }

  /**
   * get status of subjects creation
   * @param dataflowId pipeline dataflowId
   * @param apiUrl dynamic API url
   * @param topicLength non existing topics array length
   * @param subjectLength non exisiting subjects array length
   */
  getStatusOfSubjects(dataflowId: string, apiUrl: string, topicLength: number, subjectLength: number) {
    this.eventApiService.getStatusOfSubjectsCreation(dataflowId).subscribe({
      next: (response: any) => {
        if (response.status === 'complete') {
          this.initiateTopicsAndSubjectsCreation(apiUrl, topicLength, subjectLength);
        } else {
          this.mappingNextActionForSidebar.next({ topicLength: topicLength, subjectLength: subjectLength });
        }
      },
      error: () => {
        this.initiateTopicsAndSubjectsCreation(apiUrl, topicLength, subjectLength);
      }
    });
  }
  /**
   * initiate topics and subjects creation on Next click
   * @param apiUrl dynamic API url
   * @param topicLength non existing topics array length
   * @param subjectLength non exisiting subjects array length
   */
  initiateTopicsAndSubjectsCreation(apiUrl: string, topicLength: number, subjectLength: number) {
    this.eventApiService.initiateSubjectAndTopicCreation(apiUrl).subscribe({
      next: () => {
        this.mappingNextActionForSidebar.next({ topicLength: topicLength, subjectLength: subjectLength });
      },
      error: () => {}
    });
  }

  /**
   * Check status of topics or subjects if already provoked
   * @returns
   */

  getStatusOfTopicAndSubjectsCreation() {
    const skipHeader = new HttpHeaders().set(InterceptorSkipHeader, '');

    const pipeline = this.pipelineEntityService.getPipeline();
    this.eventApiService.getStatusOfTopicsCreation(pipeline.id, skipHeader).subscribe({
      next: (response: any) => {
        if (response.status === MAPPING_CONST.PENDING_STATUS || response.status === MAPPING_CONST.INPROGRESS_STATUS) {
          this.openCreateTopicsSubjectsSidebar.next();
        }
      }
    });

    this.eventApiService.getStatusOfSubjectsCreation(pipeline.id, skipHeader).subscribe({
      next: (response: any) => {
        if (response.status === MAPPING_CONST.PENDING_STATUS || response.status === MAPPING_CONST.INPROGRESS_STATUS) {
          this.openCreateTopicsSubjectsSidebar.next();
        }
      }
    });
  }
}
