export type PeriodTypes = "all" | "week" | "month" | "day" | "year";
