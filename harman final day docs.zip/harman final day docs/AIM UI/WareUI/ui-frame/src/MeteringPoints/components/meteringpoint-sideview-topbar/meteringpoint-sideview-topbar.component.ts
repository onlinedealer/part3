import { Component, Input, ChangeDetectionStrategy, Output, EventEmitter } from "@angular/core";
import { MeteringPoint } from "../../models/meteringpoint.model";

@Component({
    selector: "landisgyr-meteringpoint-sideview-topbar",
    templateUrl: "./meteringpoint-sideview-topbar.component.html",
    styleUrls: ["./meteringpoint-sideview-topbar.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringPointSideviewTopBarComponent {
    @Input()
    meteringPoint!: MeteringPoint;

    @Output()
    close = new EventEmitter();

    onClickCloseButton() {
        this.close.emit();
    }
}
