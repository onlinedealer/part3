import { Headers } from '@angular/http';

const isPT = (function () {
    if ('localhost:4200' === window.location.host
    || 'cdcpt.cvs.com' === window.location.host
    || 'm-cdcpt.cvs.com' === window.location.host) {
        return true;
    } else {
        return false;
    }
})();

export const serviceConfigs = {
    'retrieveCheckoutDetails': {
        url: 'https://www-qa1.cvs.com/retail/frontstore/checkout/CheckoutDetails?apiKey=2e77f5eb-016f-44a6-8d73-d5f2e6a01a54&apiSecret=bf2a3c64-16df-4bfe-8fa9-53c24b079ea7&appName=CVS_WEB&channelName=MOBILE&deviceToken=device12345&deviceType=DESKTOP&foobar=1504599751013&lineOfBusiness=RETAIL&operationName=retrieveCheckOutDetails&serviceCORS=True&serviceName=retrieveCheckOutDetails&version=2.0',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
        },
        queryParams: {
            operationName: 'retrieveCheckOutDetails',
            serviceName: 'retrieveCheckOutDetails',
            version: '2.0',
            foobar: new Date().getTime()
        },

    },
    'bccContent': !isPT ? {
        //url: '/assets/jsons/bccContent.json?',
        subdomain: 'minuteClinic/retailWebContent?',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
        },
        queryParams: {
            operationName: 'retailWebContent',
            serviceName: 'webContent',
            contentType: 'BCC',
            version: '1.0'
        }
    } : {
        url: window.location.host.indexOf('localhost') !== -1 ? 'https://cdcpt.cvs.com' : window.location.protocol + '//' + window.location.host,
        subdomain: 'sminuteClinic/retailWebContent?',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
        },
        queryParams: {
            operationName: 'retailWebContent',
            serviceName: 'webContent',
            contentType: 'BCC',
            version: '1.0',
            serviceCORS: 'False',
            deviceID: 'device12345'
        }
    },
    'tieECCard': {
        subdomain: 'extracareservices/tieExtraCareCard?',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json'
        },
        queryParams: {
            serviceName: 'ExtraCareService',
            operationName: 'tieExtraCareCard',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            serviceCORS: 'False'
        }
    },
    'getDigitalProfile': {
        //url: '/assets/jsons/getProfileDetails.json?',
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,
        subdomain: 'proxy/genericService?',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'proxy',
            operationName: 'getDigitalProfile',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'device1234'
        }
    },
    'getEligibleClubSubscriptions': {
        //url: '/assets/jsons/getEligibleClubSubscriptions.json?',
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        subdomain: 'proxy/genericService?',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'proxy',
            operationName: 'getEligibleClubSubscriptions',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'device1234',
            serviceCORS: 'False'
        }
    },
    'calculateTax': {
        //url: '/assets/jsons/calculateTax.json?',
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        subdomain: 'proxy/genericService?',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'proxy',
            operationName: 'calculateTax',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'device12345',
            serviceCORS: 'False'
        }
    },
    'createSubscriptionOrder': {
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        //url: '/assets/jsons/createSubscription.json?',
        subdomain: 'proxy/genericService?',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'proxy',
            operationName: 'createSubscriptionOrder',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'device12345',
            serviceCORS: 'False'
        }
    },
    'authenticateProfile': {
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        subdomain: "retail/onlineProfileMgmt?",
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'OnlineProfileMgmt',
            operationName: 'manageProfileSecureData',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'BLNK',
            serviceCORS: 'False',
            appName: "CVS_WEB",
            channelName: "WEB",
            deviceType: "DESKTOP"
        }
    },
    'getSecurityQuestions':{
        subdomain: "retail/frontstore/domaindata/SecurityQuestions?",     
        method: "GET",        
        headers: {
            'Content-Type': 'application/json',
            Accept: "application/json, text/plain, */*"
        },
        queryParams: {
            serviceName: 'getSecurityQuestions',
            operationName: 'getSecurityQuestions',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'BLNK',
            deviceType: 'DESKTOP',
            serviceCORS:"False"
        }
    },
    'changePasswordAndSecurityQuestion':{
        subdomain: "retail/onlineProfileMgmt?",     
        method: "POST",        
        headers: {
            'Content-Type': 'application/json',
            Accept: "application/json, text/plain, */*"
        },
        queryParams: {
            serviceName: 'OnlineProfileMgmt',
            operationName: 'manageProfileSecureData',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'BLNK',
            deviceType: 'DESKTOP',
            serviceCORS:"False",
            appName: "CVS_WEB",
            channelName: "WEB"
        }
    },
    'validateEnrollmentEmail':{
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        subdomain: "retail/onlineProfileMgmt?",     
        method: "POST",        
        headers: {
            'Content-Type': 'application/json',
            'Accept': "application/json, text/plain, */*"
        },
        queryParams: {
            serviceName: 'OnlineProfileMgmt',
            operationName: 'getProfileSecurityQuestions',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'BLNK',
            deviceType: 'DESKTOP',
            serviceCORS:"False",
            appName: "CVS_WEB",
            channelName: "WEB"
        }
    },
    'getOrder': {
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        //url: '/assets/jsons/getOrder.json?',
        subdomain: 'retail/frontstore/checkout/Order?',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'getOrder',
            operationName: 'getOrder',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'device12345',
            serviceCORS: 'True'
        }
    },
    'carepassLookUp':{
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-qa1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        subdomain: "retail/onlineProfileMgmt?",     
        method: "POST",        
        headers: {
            'Content-Type': 'application/json',
            'Accept': "application/json, text/plain, */*"
        },
        queryParams: {
            serviceName: 'OnlineProfileMgmt',
            operationName: 'manageProfileSecureData',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: 'BLNK',
            deviceType: 'DESKTOP',
            serviceCORS:"False",
            appName: "CVS_WEB",
            channelName: "WEB"
        }
    },
    'carePassCancellation': {
        // url: '/assets/jsons/carePassCancellation.json?',
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        subdomain: 'proxy/genericService?',
        method: 'GET',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'proxy',
            operationName: 'getCarePassCancellationInfo',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: '1223234',
            deviceID: 'device12345',
            serviceCORS: 'False'
        }
    },
    'updateCarePassEnrollment': {
        // url: '/assets/jsons/updateCarePassEnrollment.json?',
        url: window.location.host.indexOf("localhost") !== -1 ? "https://www-it1.cvs.com" : window.location.protocol+"//"+window.location.host,        
        subdomain: 'proxy/genericService?',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        queryParams: {
            serviceName: 'proxy',
            operationName: 'updateCarePassEnrollment',
            version: '1.0',
            lineOfBusiness: 'RETAIL',
            deviceToken: '1223234',
            deviceID: 'device12345',
            serviceCORS: 'False'
        }
    }
};
