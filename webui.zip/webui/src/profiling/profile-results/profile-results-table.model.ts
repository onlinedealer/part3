import { ProfileResultsColumnModel } from './profile-results-column.model';

export class ProfileResultsTableModel {
  name: string;
  totalRows: number;
  columns: ProfileResultsColumnModel[];
  statistics?: any[];
  status: string;
  errorMessage: string;
}
