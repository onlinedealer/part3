import { Component, Input, ChangeDetectionStrategy } from "@angular/core";
import { SummaryTableVO } from "../../models/view-objects/summarytable-vo.model";
import { Observable } from "rxjs";
import { ProfileDataSelectors } from "../../store/selectors";
import { Store } from "@ngrx/store";
import { MeteringPointsFeatureState } from "../../store/reducers";
@Component({
    selector: "landisgyr-meterings-summary",
    templateUrl: "./meterings-summary.component.html",
    styleUrls: ["./meterings-summary.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class MeteringsSummaryComponent {
    @Input()
    summaryData!: SummaryTableVO;
    constructor(private store: Store<MeteringPointsFeatureState>) {}
    meteringsProfileDataWithOnlyValues$: Observable<any> = this.store.select(
        ProfileDataSelectors.getSelectedMeteringsProfileDataWithOnlyValues
    );
}
