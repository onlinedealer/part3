import { TestBed, inject } from '@angular/core/testing';

import { ScrollToStartService } from './scroll-to-start.service';

describe('ScrollToStartService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ScrollToStartService]
    });
  });

  it('should be created', inject([ScrollToStartService], (service: ScrollToStartService) => {
    expect(service).toBeTruthy();
  }));
});
