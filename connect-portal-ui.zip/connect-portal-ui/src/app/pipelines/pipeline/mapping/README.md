# Mapping

The mapping stage of the pipeline includes two types of mapping:

1. Table Mappping: this is used to map the tables to particular topics and subjects
2. Field Mapping (Column Mapping): this is used to map the fields from the source to the target

# Mapping - Default matching of source and target tables

## ROOT FIle

```bash
 #pipeline-mapping.component
```

## Mainly 2 components on this page

### 1. Mapping Overview - The section above the table

### 2. Data table - Mapping Table

## Mapping Overview

```bash
#mapping-overview.component
```

#### This contains the source and target connection details with the cataloged data info. It also contains the few buttons and checkboxes as follows.

#### We are passing all the data to the mapping overview component from pipeline-mapping.component as Input.

1.1 Change Mapping : - To create a user defined pattern as per the source and target tables or select a same target for all selections.
from mapping-overview.component we are using the selector of change-table-mapping.component and passing the required data.

1.2 Reset to default

1.3 Create topic Checkbox - if we check this we can create topic for tables which don't have any target topic available
file - create-topic-subjects

1.4 Create subject Checkbox - if we check this we can create subject for tables which don't have any target subject available.
file create-topic-subjects

## Data table

```bash
#data-table.component
```

#### The above file contains everything about the table on the mapping page.

#### here we are passing the table data from the pipeline-mapping.component.

#### In pipeline-mapping.component we are first setting the data of the mapping overview sections such as the source details target details.

```bash
    this.pipeline = this.pipelineEntityService.getPipeline();
    this.tableMapping = this.pipeline.tableMapping;

    this.sourceDataConnection = this.pipeline.source.dataConnection;
    this.targetDataConnection = this.pipeline.target.dataConnection;
    this.schemaRegistryConnection = this.pipeline.target.dataConnection;
```

After setting all the above data we are calling the below function to make an API call to getSelectedTable data from the data page.

```bash
this.getSelectedTables()
```

After the above function executes we are calling another API to get the cataloged Kafka topics from the below function

```
this.getExistingKafkaTopics();
```

as the above API call executes successfully we are doing 2 things based on the below condition.

```bash
 if (this.isSchemaRegistryThere) {
          this.getSubjects(this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID).value);
        } else {
          this.defaultMapping(this.topics);
        }
```

so if the schemaRegistry connections is selected then we are first calling the this.getSubjects() function that makes an API call to get the cataloged subjects

And if the schemaRegistry connection is not there we directly call the defaultMapping function and then the default mapping takes place

### Default Mapping

In this function it takes two arguments that is topicsArray and subjectsArray and second is optional according to schemaRegistry connection.

we process the data from the selectedTables api call itself we process the data that is fit for the table that is from this function.

```bash
  processData(data: any, mappingData, source: string, target: string) {}
```

we basically have two functions inside this if the data is coming fresh or the data is coming from response and according we are having two functions for this that are

```
  this.addDataFromResponse() -- handles when data is already present in db
and another one is
 this.addFreshData() -- when user comes for the first time on mapping screen

structure for the mapping table data
{
        id: e.id,
        hasCustomColMappings: e.hasCustomColMappings,
        schema: item.schemaName,
        table: item.table
        topic: {
          name: topic,
          mappingIcon: '',
          iconTooltip: '',
          class: null
        },
        subject: {
          name: subject,
          mappingIcon: '',
          iconTooltip: ''
        },
        isDuplicate: e.isDuplicate,
      };

```

so the data that we get from the above function we use it at the defaultMapping function stage mainly to set the data as per target and also adding the target mapping icon accordingly.

The changes done on the data table that are handled by patchpipeline method that forms the mappingDataArr object by formMappingDataArr function

```bash
  formMappingDataArr(mappings) {
    const sourceColumnName = this.fields[1].name;
    const mappingArr = [];
    mappings.map((row) => {
      const objKey =
        this.sourceDataConnection.connectionType === 'SQLSERVER'
          ? row[sourceColumnName] + '||' + row.owner + '.' + row.table.trim()
          : row[sourceColumnName] + '||' + row.table.trim();
      mappingArr.push({
        id: row.id,
        key: objKey,
        value: this.getValueofPayload(row),
        hasCustomColMappings: row.hasCustomColMappings ? true : false,
        type: this.getTypeofTargetforPayload(row),
        schemaVersion: row.schemaVersion ? row.schemaVersion : null
      });
    });
    return mappingArr;
  }
```

### Next Button Click

with the formMappingDataArr function we are generating the tableMapping object that is required by update api call on next button click and we are calling the update API.

## Column Mapping Sidebar

The component interaction between column and table mapping happens in DataTableComponent. The Column Mapping Sidebar itself has 4 child components, namely ColumnMappingTableComponent, ColumnMappingOverviewComponent, BulkColumnMappingSidebarComponent, and ResetDefaultSidebarComponent.
Line 228 of the data-table.component.html has the button which triggers the sidebar opening event. Inside the column-mapping-sidebar.component.ts is the open() method.

```Javascript
open(row){
```

This takes the row information of the particular table as the parameter from the data-table component, and stores this information as rowData variable.

```Javascript
rowData: any
```

Next is a series of API calls that are called, starting with (line 71):

```Javascript
this.saveTableMapping(row);
```

This saves the table mapping information as it currently is, and helps the next two calls.

Nested inside this call, is the sourceColumns API call:

```Javascript
this.getColumnList(row);
```

This populates the variable that is to be shown in the source columns dropdown. Within this API call, the list of columns is then alphabetically sorted after translation:

```Javascript
this.alphabeticalSortColumnList();
```

Next, depending on whether or not the mapping is done to a Kafka database with Schema Registry as well as whether the Kafka has a Subject, the getVersions or getColumnMapping API is called

```Javascript
if (this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID) !== undefined) {
            this.rowTableMapping.type.includes('SUBJECT_DOES_NOT_EXIST') ? this.getColumnMapping() : this.getVersions();
          } else {
            this.getColumnMapping();
          }
        },
```

In either case, getColumnMapping API is called. Further, this calls the defaultMapping function in the table child component which sets the table.

On the click of the Save button, the primaryButtonClicked() function validates the grid with particular conditions, and then calls the saveColumnMapping API.

### Column Mapping Overview

The overview component is responsible for displaying all the relevant information from the source and the target such as topic name and subject name. There is also a dropdown that is conditionally rendered in the case of schema registry. This dropdown is populated from the above mentioned sidebar component and passed as versionsList array.

### Column Mapping Table

In the flow, when defaultMapping() is called from the parent component, the column mapping data is passed as a parameter. This data exists in a particular model as below:

```Javascript
class ColumnMap {
  sourceColumnName?: string;
  sourceColType: string;
  action: string;
  isKey: boolean;
  targetColumnName: string;
  targetColType: string;
  isExpression: boolean;
  state: string;
}
```

#### Default Mapping Function

In the defaultMapping function, the data for Column Mapping is mapped to the displayValues variable. This single variable is constantly being changed depending on the user input. In this function itself, there is an addition of another key called id, which is used in order to create a separate identifier for the checkboxes.

#### Adding and Removal of Fields

At the bottom of the UI, one can find the option to add a field. Towards the right of each field, one can find the option to remove a particular field. These are handled by removing the entire field mapping object itself from the displayValues variable in the following code:

```Javascript
 deleteRow(row): void {
    if (this.displayValues.length === 1) {
      this.errorMessageChange.emit({ message: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.ERROR.DELETE_ERROR' });
    } else if (this.displayValues.length > 1) {
      this.displayValues.splice(this.displayValues.indexOf(row), 1);
      this.displayValues = [...this.displayValues];
      let excessItem = this.checkedItems.find((ci) => ci.id === row.id);
      this.checkedItems.splice(this.checkedItems.indexOf(excessItem), 1);
    }
    this.checkedItemsChange.emit(this.checkedItems);
    this.displayValuesChange.emit(this.displayValues);
    this.updateAllInputFields();
    this.updateHasCustomColumnMappings();
  }
```

#### Save button click

When the save button is clicked, the data is first updated with updateData() function which effectively removes the id from the ColumnMap from each object. After this, it validates the entire grid based on UX parameters and what is required in the API. Post this, it calls the saveColumnMapping API and sends the entire columnMapping grid's variable, displayValues as the payload as part of the tableMapping object.

### Reset To Default

The items which have been checked in the table are emitted to the ResetToDefault component and then sent as payload to the resetDefault API. This returns the reset values of every single column mapping as a response. The response is then set back in the displayValues to reflect the changes.

### Change Mapping

The options which are selected in the dropdowns/autocomplete are then put into an object. This object is emitted from the change mapping sidebar, to the sidebar, and then passed as an input into the table. This object's information is used to transform the selected objects and their target name. This application exists in the following code in the table component:

```applyBulkMapping(bulkMappingObj, checkedItems: any[]) {
    this.applyPattern(bulkMappingObj, checkedItems);
    checkedItems.forEach((item) => {
      if (bulkMappingObj.action === 'IGNORE') {
        this.displayValues.find((element) => element.id === item.id).action = 'Ignore';
      } else if (bulkMappingObj.action === 'COPY') {
        this.displayValues.find((element) => element.id === item.id).action = 'Copy';
      }
      if (bulkMappingObj.case !== 'SOURCE_NAME') {
        this.displayValues.find((element) => element.id === item.id).targetColumnName = this.applyCasing(
          bulkMappingObj.case,
          item.targetColumnName
        );
      }
    });
  }
```

## Column Mapping Sidebar

The component interaction between column and table mapping happens in DataTableComponent. The Column Mapping Sidebar itself has 4 child components, namely ColumnMappingTableComponent, ColumnMappingOverviewComponent, BulkColumnMappingSidebarComponent, and ResetDefaultSidebarComponent.
Line 228 of the data-table.component.html has the button which triggers the sidebar opening event. Inside the column-mapping-sidebar.component.ts is the open() method.

```Javascript
open(row){
```

This takes the row information of the particular table as the parameter from the data-table component, and stores this information as rowData variable.

```Javascript
rowData: any
```

Next is a series of API calls that are called, starting with (line 71):

```Javascript
this.saveTableMapping(row);
```

This saves the table mapping information as it currently is, and helps the next two calls.

Nested inside this call, is the sourceColumns API call:

```Javascript
this.getColumnList(row);
```

This populates the variable that is to be shown in the source columns dropdown. Within this API call, the list of columns is then alphabetically sorted after translation:

```Javascript
this.alphabeticalSortColumnList();
```

Next, depending on whether or not the mapping is done to a Kafka database with Schema Registry as well as whether the Kafka has a Subject, the getVersions or getColumnMapping API is called

```Javascript
if (this.pipeline.target.parameters?.find((ele) => ele.key === MAPPING_CONST.SCHEMA_REGISTRY_ID) !== undefined) {
            this.rowTableMapping.type.includes('SUBJECT_DOES_NOT_EXIST') ? this.getColumnMapping() : this.getVersions();
          } else {
            this.getColumnMapping();
          }
        },
```

In either case, getColumnMapping API is called. Further, this calls the defaultMapping function in the table child component which sets the table.

On the click of the Save button, the primaryButtonClicked() function validates the grid with particular conditions, and then calls the saveColumnMapping API.

### Column Mapping Overview

The overview component is responsible for displaying all the relevant information from the source and the target such as topic name and subject name. There is also a dropdown that is conditionally rendered in the case of schema registry. This dropdown is populated from the above mentioned sidebar component and passed as versionsList array.

### Column Mapping Table

In the flow, when defaultMapping() is called from the parent component, the column mapping data is passed as a parameter. This data exists in a particular model as below:

```Javascript
class ColumnMap {
  sourceColumnName?: string;
  sourceColType: string;
  action: string;
  isKey: boolean;
  targetColumnName: string;
  targetColType: string;
  isExpression: boolean;
  state: string;
}
```

#### Default Mapping Function

In the defaultMapping function, the data for Column Mapping is mapped to the displayValues variable. This single variable is constantly being changed depending on the user input. In this function itself, there is an addition of another key called id, which is used in order to create a separate identifier for the checkboxes.

#### Adding and Removal of Fields

At the bottom of the UI, one can find the option to add a field. Towards the right of each field, one can find the option to remove a particular field. These are handled by removing the entire field mapping object itself from the displayValues variable in the following code:

```Javascript
 deleteRow(row): void {
    if (this.displayValues.length === 1) {
      this.errorMessageChange.emit({ message: 'pipelines.STAGES.MAPPING.COLUMN_MAPPING_SIDEBAR.ERROR.DELETE_ERROR' });
    } else if (this.displayValues.length > 1) {
      this.displayValues.splice(this.displayValues.indexOf(row), 1);
      this.displayValues = [...this.displayValues];
      let excessItem = this.checkedItems.find((ci) => ci.id === row.id);
      this.checkedItems.splice(this.checkedItems.indexOf(excessItem), 1);
    }
    this.checkedItemsChange.emit(this.checkedItems);
    this.displayValuesChange.emit(this.displayValues);
    this.updateAllInputFields();
    this.updateHasCustomColumnMappings();
  }
```

#### Save button click

When the save button is clicked, the data is first updated with updateData() function which effectively removes the id from the ColumnMap from each object. After this, it validates the entire grid based on UX parameters and what is required in the API. Post this, it calls the saveColumnMapping API and sends the entire columnMapping grid's variable, displayValues as the payload as part of the tableMapping object.

### Reset To Default

The items which have been checked in the table are emitted to the ResetToDefault component and then sent as payload to the resetDefault API. This returns the reset values of every single column mapping as a response. The response is then set back in the displayValues to reflect the changes.

### Change Mapping

The options which are selected in the dropdowns/autocomplete are then put into an object. This object is emitted from the change mapping sidebar, to the sidebar, and then passed as an input into the table. This object's information is used to transform the selected objects and their target name. This application exists in the following code in the table component:

```applyBulkMapping(bulkMappingObj, checkedItems: any[]) {
    this.applyPattern(bulkMappingObj, checkedItems);
    checkedItems.forEach((item) => {
      if (bulkMappingObj.action === 'IGNORE') {
        this.displayValues.find((element) => element.id === item.id).action = 'Ignore';
      } else if (bulkMappingObj.action === 'COPY') {
        this.displayValues.find((element) => element.id === item.id).action = 'Copy';
      }
      if (bulkMappingObj.case !== 'SOURCE_NAME') {
        this.displayValues.find((element) => element.id === item.id).targetColumnName = this.applyCasing(
          bulkMappingObj.case,
          item.targetColumnName
        );
      }
    });
  }
```
