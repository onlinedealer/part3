import { EntityFilterComponent } from '../filter/entity-filter.component';

describe('FilterComponent', () => {
  let component: EntityFilterComponent;

  beforeEach(() => {
    component = new EntityFilterComponent();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
