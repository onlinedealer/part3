import { createAction, props } from "@ngrx/store";

export interface SetDateFormatFromDefinedLocalesPayload {
    locale: string;
}
export interface ChangeUiConfigurationSettingsPayload {
    systemLocale: string;
    userLocale?: string;
    dateFormat: { separator: string; format: string };
    timeFormat: string;
    hours: "12" | "24";
    timeZoneInUse?: string;
}

export interface SetUiConfigurationLocalePayload {
    locale: string;
    changeDateFormats: boolean;
}

export interface SetSystemTimeZonePayload {
    timeZoneInUse?: string;
}

export interface UIConfigurationNeedsLocaleRedirection {
    newLocale: string;
}

export const LoadWindowDefinedConfiguration = createAction("[User Date Configuration] Load Configuration From Window Token");
export const LoadWindowDefinedConfigurationFailed = createAction("[User Date Configuration] Window Token Load Failed");
export const LoadWindowDefinedConfigurationSuccess = createAction(
    "[User Date Configuration] Window Token Load Success",
    props<ChangeUiConfigurationSettingsPayload>()
);
export const SetDateFormatsToStoreDefinedInitialValues = createAction(
    "[User Date Configuration] Set Date Formats to Store defined Initial values"
);
export const SetDateFormat = createAction("[User Date Configuration] Set Date Format", props<ChangeUiConfigurationSettingsPayload>());
export const SetDateFormatFromDefinedLocales = createAction(
    "[User Date Configuration] Set Date Format from Locale",
    props<SetDateFormatFromDefinedLocalesPayload>()
);
export const SetDateFormatFromDefinedLocalesSuccess = createAction(
    "[User Date Configuration] Set Date Format from Locale Success",
    props<SetDateFormatFromDefinedLocalesPayload>()
);
export const SetDateFormatFromDefinedLocalesFail = createAction("[User Date Configuration] Set Date Format from Locale Fail");

export const ChangeUiConfigurationSettings = createAction(
    "[User Ui Settings] Settings changed",
    props<ChangeUiConfigurationSettingsPayload>()
);
export const UIConfigurationNeedsWindowReload = createAction("[Configuration] Needs Window reloaded");
export const UIConfigurationNeedsLocaleRedirection = createAction(
    "[Configuration] Needs locale redirection",
    props<UIConfigurationNeedsLocaleRedirection>()
);
export const UIConfigurationNeedsNoActions = createAction("[Configuration] Needs no window updating actions");
export const SetSystemTimeZone = createAction("[System Locale] Set system Time Zone", props<SetSystemTimeZonePayload>());
export const SetUserTimeZone = createAction("[System Locale] Set user Time zone", props<SetSystemTimeZonePayload>());
