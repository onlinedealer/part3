import React from 'react'
import { Helmet } from 'react-helmet'
import { bindActionCreators } from 'redux'
import { withStyles } from '@material-ui/core/styles'
import Notifications from '../Notifications/Notifications'
import { connect } from 'react-redux'
import DrawerComponent from './DrawerComponent'
import Snackbars from '../common/Snackbars/Snackbars'
import { toggleSnackBar } from '../../store/Snackbar/actionCreator'
import { getPayload, getKey } from 'react-oauth-openid'
import GrouperDialog from '../common/GrouperDialog/GrouperDialog'
import { signOut, increaseUserTimeOut } from '../../store/auth'
import OAuthProviderConfig from '../../config/OAuthProviderConfig'

const styles = theme => ({
  header: {
    height: 56,
    [`${theme.breakpoints.up('xs')} and (orientation: landscape)`]: {
      height: 48,
    },
    [theme.breakpoints.up('sm')]: {
      height: 64,
    },
  },
  contentContainer: {
    padding: theme.spacing.unit, // Default <Grid container> spacing is 16. Use 8px padding for bug in material-ui Grid. See https://github.com/callemall/material-ui/issues/7466#issuecomment-316356427
  },
  sideNavFooterList: {
    color: theme.typography.body1.color,
    display: 'flex',
    flexWrap: 'wrap',
    fontSize: theme.typography.caption.fontSize,
    listStyle: 'none',
    margin: 0,
    padding: theme.spacing.unit * 1.5,
    '& li': {
      padding: theme.spacing.unit / 2,
    },
    '& a': {
      color: theme.typography.caption.color,
      textDecoration: 'none',
      transition: theme.transitions.create('color', {duration: theme.transitions.duration.shorter}),
      '&:hover': {
        color: theme.palette.primary[500],
      },
    },
  },
  miniDrawerContent: {
    backgroundColor: '#fff',
    padding: 0,
    position: 'relative',
    // overflowY: 'auto',
  },
  miniDrawerRoot: {
    height: '100vh',
  },
})

export class Layout extends React.Component {
  constructor (props) {
    super(props)
    this.state = {
      dialogOpenStatus: false,
    }
  }
  static defaultProps = {
    layoutActions: {},
    notificationActions: {},
  }

  componentWillMount () {
    if (window.localStorage.length > 0) {
      const idPayload = getPayload('id_token')
      idPayload.accessToken = getKey('access_token')
      let d1 = new Date(idPayload.exp * 1000)
      d1.setHours(d1.getHours() - this.props.userInfo.userTimeOut) // reduce time out in 4 hrs
      // d1.setMinutes(d1.getMinutes() - 479) // reduce time out in 4 hrs
      const curTime = Date.now()
      let d2 = new Date(curTime)
      if (d1.getTime() < d2.getTime()) {
        this.setState({dialogOpenStatus: true})
      }
    }
  }

  userActionCallback = (status) => {
    if (status) {
      this.props.increaseUserTimeOut()
    } else {
      this.props.signOut()
      window.localStorage.removeItem('access_token')
      window.localStorage.removeItem('id_token')
      const myWindow = window.open(OAuthProviderConfig.logoutUrl, 'groupr logout', 'width=200, height=100')
      setTimeout(() => {
        myWindow.close()
        window.location.replace('/')
      }, 3000)
    }
    this.setState({dialogOpenStatus: false})
  }

  render () {
    const { classes } = this.props
    return (
      <div>
        <Helmet
          defaultTitle="Grouper"
          titleTemplate="%s - Grouper"
        />
        <Notifications />
        <Snackbars
          variant={this.props.snackbarMessage.variant}
          message={this.props.snackbarMessage.message}
          openStatus={this.props.snackbarMessage.status}
          autoHide={this.props.snackbarMessage.autoHide}
          toggleSnackBar={this.props.toggleSnackBar}
        />
        <DrawerComponent snackbarMessage={this.props.snackbarMessage}
          classes={{
            root: classes.miniDrawerRoot,
            content: classes.miniDrawerContent }}
          loadingDataStatus={this.props.loadingDataStatus}
        />
        <GrouperDialog
          openStatus={this.state.dialogOpenStatus}
          deleteConfirmCallback={this.userActionCallback}
          title="Session Expiring"
          message="Your session is expiring. Do you wish to keep it alive?"
          disAgreeText="No"
          agreeText="Yes"
        />
      </div>
    )
  }
}
const mapDispatchToProps = dispatch =>
  bindActionCreators({
    toggleSnackBar,
    signOut,
    increaseUserTimeOut,
  }, dispatch)

function mapStateToProps (state) {
  return {
    snackbarMessage: state.getIn(['Snackbar', 'snackbarMessage']).toJS(),
    loadingDataStatus: state.getIn(['Snackbar', 'loadingDataStatus']),
    userInfo: state.get('auth').toJS(),
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(Layout))
