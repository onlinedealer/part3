import React from 'react'
import { shallow } from 'enzyme'
import DashboardToolbar, { DashboardToolbar as DashboardToolbarComponent } from '../DashboardToolbar'

describe('DashboardTable component', () => {
  let wrapper, wrapperBlock
  let grouperList = [{'group_id': 3, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534305000, 'department': {'department_id': 242, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962400000, 'status': 'InActive'},
    {'group_id': 5, 'group_type': 'variation', 'group_name': 'demo2', 'no_of_items': 0, 'last_modified': 1535534306000, 'department': {'department_id': 244, 'department_name': null, 'department_value': '244-null'}, 'launch_date': 1406962800000, 'status': 'Active'}]
  let props = {
    classes: {},
    listItems: grouperList,
    auth: {
      lanId: 'z001jb6',
      memberOf: ['APP-LPP-STG-Mass-Maintain'],
    },
  }
  it('renders', () => {
    wrapper = shallow(
      <DashboardToolbar {...props} />)
    expect(wrapper).toHaveLength(1)
  })

  it('invoking readFilters ', () => {
    props.onFilterRequest = jest.fn()
    wrapperBlock = shallow(
      <DashboardToolbarComponent {...props} />)
    wrapperBlock.instance().readFilters('group_id', '3')
    expect(wrapperBlock.instance().state.selectRef['group_id']).toEqual('3')
    expect(props.onFilterRequest.mock.calls.length).toEqual(1)
    wrapperBlock.instance().readFilters('group_id', '')
    expect(wrapperBlock.instance().state.selectRef['group_id']).toEqual(undefined)
  })
})
