import request = require('request-promise');
import * as handlebars from 'handlebars';
import * as fs from 'fs';
request.debug = false;

const templateSource = fs.readFileSync( './hbs-templates/meteringpoint/meteringpoint-search-template.hbs');
const template: HandlebarsTemplateDelegate = handlebars.compile(templateSource.toString('utf8'));

let cookie = {}

export const getMeteringPoints = function() {

    const xml = template({
      meteringPointName: 'MP%',
      exact: 'false'
    });

    return request.post({
        url: 'http://fijyvvraimbl01.eu.bm.net/AIMDashboard/SvcRepModuleServiceSoapHttpPort',
        rejectUnauthorized: false,
        body: xml,
        json: false,
        headers: {
          'Cookie': cookie,
          'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
          'content-type': 'text/xml; charset=utf-8'
      }    
    })

}

const getSession = function() {

  return request.post({
    url: 'http://fijyvvraimbl01.eu.bm.net/AIMDashboard/j_security_check',
    rejectUnauthorized: false,
    json: false,
    form: {
      'j_username': 'ari',
      'j_password': 'ari'
    }
  }).then((response:any) => {
    console.log('Got response: ' + JSON.stringify(response, null, 4));
  }).catch( (error: any) => {

    cookie = error.response.headers['set-cookie']
    console.log('COOKIE: ' + cookie)

//    console.log('Got error: ' + JSON.stringify(error, null, 4));
  })

}

getSession();


// http://fijyvvraimbl01.eu.bm.net/AIMDashboard/j_security_check

// Set-Cookie: JSESSIONID=a84vYdoeKmRHaH-JZgrhslXYja1iW4xwob50OfDz409BXenYk1rv!2036440345; path=/; HttpOnly

// Cookie: JSESSIONID=a84vYdoeKmRHaH-JZgrhslXYja1iW4xwob50OfDz409BXenYk1rv!2036440345

/*
POST
j_username: ari
j_password: ari

Set-Cookie: JSESSIONID=iUku7i7i5gCE4iB7jVg6F9BvVAWT-w_tFNwpcZBMq4w1zbMz1QQl!2036440345; path=/; HttpOnly

<form id="loginForm" action="j_security_check" method="post">
        <table align="center">
         
          <tr>
            <td>Käyttäjätunnus: </td><td><input id="userName" type="text" size="20" name="j_username" /></td>
          </tr>
          <tr>
            <td>Salasana: </td><td><input type="password" size="20" name="j_password"/></td>
          </tr>
        </table>
        <input type="submit" value="Kirjaudu"/>
      </form>


*/