/**
 * This is the class that is used with different modules. Refactoring required for profiling constant.
 */
export class SharedConstants {
  public static SERVICE_RESPONSE = {
    SUCCESS: 'SUCCESS',
    INPROGRESS: 'INPROGRESS'
  };
  public static STATS = {
    COMPLETENESS: 'CompletenessStatistics',
    UNIQUENESS: 'UniquenessStatistics',
    FREQUENCY: 'FrequencyStatistics',
    STRINGLENGTH: 'StringLengthFrequencyStatistics',
    TEXTPATTERN: 'TextPatternStatistics',
    SCRIPTPATTERN: 'ScriptDistributionStatistics',
    CHARSPACING: 'CharacterSpacingStatistics',
    CHARDATATYPE: 'CharacterDataTypeStatistics',
    SPECIALCHAR: 'SpecialCharacterStatistics',
    CHARCASING: 'CharacterCasingStatistics',
    PERCENTILE: 'PercentileStatistics',
    STRINGLENGTHSTAT: 'StringLengthStatistics',
    NUMERICALMINMAX: 'MinMaxValueStatistics',
    NUMERICALSTAT: 'NumericalStatistics',
    HISTOGRAM: 'HistogramStatistics',
    VALIDITY: 'ValidityStatistics',
    SEMANTIC: 'DetectedSemanticTypeStatistics',
    CONFIDENCE: 'ConfidenceStatistics',
    POPULARITY: 'PopularityStatistics'
  };
  public static SEMANTICSTATS = {
    DATE: 'DATE',
    EMAIL: 'EMAIL',
    CREDITCARD: 'CREDITCARD',
    PHONE: 'PHONE'
  };
  public static navigationModes = {
    prev: 'Previous',
    next: 'Next',
    latest: 'Latest'
  };
  public static SEMANTICSTATSFREQUENCY = {
    DATEFORMAT: 'dateFormatFrequency',
    PHONECOUNTRY: 'phoneCountryFrequency',
    PHONETYPE: 'phoneTypeFrequency',
    PHONEREGION: 'phoneRegionFrequency',
    MULTIPLE_SEMANTIC: 'multipleSemantic',
    MULTIPLE_SEMANTIC_TYPE_INFO: 'multiInfo',
    VALIDITY: 'validity',
    CONFIDENCE: 'confidence',
    CREDITCARD: 'cardTypeFrequency',
    EMAILDOMAIN: 'emailDomainFrequency',
    VINCOUNTRY: 'vinCountryFrequency',
    IBANCOUNTRY: 'ibanCountryFrequency'
  };
  public static STATSGROUPS = {
    CHARACTER_ANALYSIS: 'CHARACTER_ANALYSIS',
    NUMERICAL_ANALYSIS: 'NUMERICAL_ANALYSIS',
    DATE_ANALYSIS: 'DATE_ANALYSIS',
    TABLE_ANALYSIS: 'TABLE_ANALYSIS',
    SEMANTIC_ANALYSIS: 'SEMANTIC_ANALYSIS',
    STRING_ANALYSIS: 'STRING_ANALYSIS'
  };

  public static STATUS = {
    SUCCESS: 'SUCCESS',
    ERROR: 'ERROR',
    INPROGRESS: 'INPROGRESS',
    SUBMITTED: 'SUBMITTED',
    CANCEL_INITIATED: 'CANCEL_INITIATED',
    CANCELLED: 'CANCELLED',
    NEW: 'NEW',
    PROCESSING: 'PROCESSING'
  };
  public static DATA_TYPE = {
    VARIANT: 'VARIANT'
  };
  public static UNSUPPORTED_DATA_TYPE = ['VARIANT', 'UNSUPPORTED'];
  public static FREQUENCYCHARTCOLORS = [
    '#39006B',
    '#8017E1',
    '#E5007E',
    '#FAB512',
    '#FD7E08',
    '#C8CCEE',
    '#D058D0',
    '#565358',
    '#dedae1'
  ];

  public static CHARTFONTSCOLORS = {
    TICKS: '#495057',
    GRID: '#ebedef'
  };

  public static OCCURENCES = {
    DAILY: 'daily',
    WEEKLY: 'weekly'
    //Future scope
    // HOURLY:'hourly',
    // MONTHLY :'MONTHLY'
  };
  public static PROFILING_REGEX = {
    DATE_FORMAT_REGEX:
      // eslint-disable-next-line max-len
      /^(((0[1-9]|[12]\d|3[01])[\\-](Jan|jan|Feb|feb|Mar|mar|Apr|apr|May|may|Jun|jun|Jul|jul|Aug|aug|Sep|sep|Oct|oct|Nov|nov|Dec|dec)[\\-]((19|[2-9]\d)\d{2}))|((0[1-9]|[12]\d|30)[\\-](Jan|jan|Feb|feb|Mar|mar|Apr|apr|May|may|Jun|jun|Jul|jul|Aug|aug|Sep|sep|Oct|oct|Nov|nov|Dec|dec)[\\-]((19|[2-9]\d)\d{2}))|((0[1-9]|1\d|2[0-8])[\\-](Jan|jan|Feb|feb|Mar|mar|Apr|apr|May|may|Jun|jun|Jul|jul|Aug|aug|Sep|sep|Oct|oct|Nov|nov|Dec|dec)[\\-]((19|[2-9]\d)\d{2})\s)|((29)[\\-](Jan|jan|Feb|feb|Mar|mar|Apr|apr|May|may|Jun|jun|Jul|jul|Aug|aug|Sep|sep|Oct|oct|Nov|nov|Dec|dec)[\\-]((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))))$/g,
    TIME_FORMAT_REGEX: /^(00|0[\d]|1[012]):[0-5][\d] ?((a|p)m|(A)m|(a)M|(A|P)M)$/
  };
  public static MERIDIEM_INDICATOR = {
    AM: 'AM',
    PM: 'PM'
  };
  public static PROGRESS_BAR_COLORS = {
    PERCENTAGE: '#6AC400',
    REMAINING: '#dedae1'
  };
  public static MULTISEMANTICINFOTABLE = {
    phoneCountryFrequency: 'phoneCountryFrequency',
    phoneRegionFrequency: 'phoneRegionFrequency',
    phoneTypeFrequency: 'phoneTypeFrequency',
    cardTypeFrequency: 'cardTypeFrequency',
    dateFormatFrequency: 'dateFormatFrequency',
    emailDomainFrequency: 'emailDomainFrequency',
    vinCountryFrequency: 'vinCountryFrequency',
    ibanCountryFrequency: 'ibanCountryFrequency'
  };
  public static NAMEMAXLENGTH: number = 50;
  public static PROFILE_CONFIGURE_STEPS = {
    SOURCE: 'source',
    PROFILE: 'profile',
    FINALIZE: 'finalize'
  };
  public static DATE_DEFAULT_LOCALE = 'en-US';
  public static HISTORY_TABLE_DEFAULT_SORT = {
    HISTORY_SCHEDULER: 'run'
  };
  public static SCHEDULE_STATUS = {
    ENABLED: 'Enabled',
    DISABLED: 'Disabled',
    SUSPENDED: 'Suspended',
    NOT_CONFIGURED: 'Not Configured'
  };

  public static SCHEDULER_SOURCE = {
    PROFILING: 'profiling',
    OBSERVER: 'observer'
  };

  public static connectionConfigureModes = {
    ADD: 'Add',
    COPY: 'Copy',
    EDIT: 'Edit'
  };
  public static connectionConfigureType = {
    DATABRICKS: 'databricks',
    SNOWFLAKE: 'snowflake'
  };
  public static connectionConfigureErrorMsg = {
    ACCOUNT: 'Account is incorrect'
  };

  public static featureFlags = {
    DATABRICK: 'OBSDataBricksConnectionTemp230622',
    SCHEDULER: 'OBSSchedulingTemp240222',
    OBSERVER: 'OBSObservabilityObserversTemp180522',
    ALERT: 'OBSViewAlertsTemp180522',
    EXPORTTOEXCEL: 'OBSExportToExcelTemp220922',
    EMAIL_NOTIFICATION: 'OBSEmailNotificationTemp201022',
    CATALOG: 'OBSDataCatalogTemp201022',
    HACK_DEMO: 'OBSSkoDemoTemp011222'
  };

  public static TRENDS_SOURCE = {
    TOTAL_RECORDS: 'Total Records'
  };

  public static trendsKeys = {
    Complete: 'COMPLETENESS_PERCENTAGE',
    Null: 'NULL_PERCENTAGE',
    'Blank Count': 'BLANK_PERCENTAGE',
    'Incomplete Rows': 'INCOMPLETENESS_PERCENTAGE',
    'Complete Rows': 'COMPLETENESS_PERCENTAGE',
    Unique: 'UNIQUE_PERCENTAGE',
    'Non Unique': 'NON_UNIQUE_PERCENTAGE',
    Distinct: 'CARDINALITY_PERCENTAGE',
    Minimum: 'VALUE_MIN',
    Maximum: 'VALUE_MAX',
    'Standard Deviation': 'VALUE_STDEV',
    Variance: 'VALUE_VARIANCE',
    Average: 'VALUE_MEAN',
    'Min Length': 'TEXT_LENGTH_MIN',
    'Max Length': 'TEXT_LENGTH_MAX',
    'Total Records': 'ROW_COUNT',
    Valid: 'VALID_PERCENTAGE',
    'Not Valid': 'INVALID_PERCENTAGE',
    Confidence: 'CONFIDENCE_PERCENTAGE'
  };

  public static trendDataType = {
    DATE: 'DATE',
    DATETIME: 'DATETIME',
    TIMESTAMP: 'TIMESTAMP',
    TIME: 'TIME'
  };
}
