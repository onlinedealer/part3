import { TableConfiguration, TableField, TableMessage, TableMessageType } from '@shared/components/generic-table/generic-table';

/**
 * Fields to display in the table.
 */
const catalogFields: TableField[] = [
  {
    header: 'connections.MANAGE_CATALOG.COLUMNS.SCHEMA',
    name: 'schema',
    isKey: true,
    isSearchable: true,
    columnStyle: { width: '50%' }
  },
  {
    header: 'connections.MANAGE_CATALOG.COLUMNS.STATUS',
    name: 'status',
    isSearchable: true,
    columnStyle: { width: '15%' }
  },
  {
    header: 'connections.MANAGE_CATALOG.COLUMNS.LAST_COMPLETED',
    name: 'lastCataloged',
    isSearchable: true,
    columnStyle: { width: '35%' }
  }
];

/**
 * Empty table message.
 */
const emptyTableMessage: TableMessage = {
  messageType: TableMessageType.INFO,
  messageHead: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_CONNECTIONS_CONFIGURED.HEAD',
  messageCaption: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_CONNECTIONS_CONFIGURED.CAPTION'
};

/**
 * Sets the table message when filtering the table.
 */
const filterTableMessage: TableMessage = {
  messageType: TableMessageType.INFO,
  messageHead: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_FILTER_RESULTS.HEAD',
  messageCaption: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_FILTER_RESULTS.CAPTION'
};

/**
 * Sets the table messgae when there are errors.
 */
const errorTableMessage: TableMessage = {
  messageType: TableMessageType.ALERT,
  messageHead: 'connections.CONNECTIONS_TABLE.MESSAGES.ERROR.HEAD',
  messageCaption: 'connections.CONNECTIONS_TABLE.MESSAGES.ERROR.CAPTION'
};

/**
 * Table configuration for the catalogs table.
 */
export const manageCatalogTableConfiguration: TableConfiguration = {
  visibleRows: 25,
  isLoading: true,
  styleClass: 'grey-bg',
  fields: catalogFields,
  isFilterShown: false,
  tableMessages: {
    emptyTableMessage: emptyTableMessage,
    filterTableMessage: filterTableMessage,
    errorTableMessage: errorTableMessage
  },
  caption: {
    isFilterShown: true
  }
};
