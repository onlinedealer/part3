import { Component, ViewChild, AfterViewInit, OnDestroy, ViewChildren, QueryList, HostListener } from "@angular/core";
import { filter } from "rxjs/operators";
import { MatTabGroup, MatTabChangeEvent, MatTab } from "@angular/material/tabs";
import { MeteringPointDetails } from "../../models/meteringpoint.model";
import { MeteringPointsActions, MeteringPointsUIActions, RefreshDataActions } from "../../store/actions";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { MeteringPointsSelectors, MeteringPointsUISelectors } from "../../store/selectors";
import { Observable, Subscription } from "rxjs";
import { RouterSelectors, SecuritySelectors } from "../../../app/store/selectors";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../app/services/translations-service";
import { FormControl } from "@angular/forms";

@Component({
    templateUrl: "./meteringpoint-sideview-container.component.html",
    styleUrls: ["./meteringpoint-sideview-container.component.scss"]
})
export class MeteringPointSideviewContainerComponent implements AfterViewInit, OnDestroy {
    meteringPoint$: Observable<MeteringPointDetails | undefined> = this.store.select(
        MeteringPointsSelectors.getSelectedMeteringPointDetails
    );

    selectedTab = new FormControl(0);
    forcedTabChange$ = this.store
        .select(MeteringPointsUISelectors.getSideViewForcedTab)
        .pipe(filter((tabWithTimestamp) => tabWithTimestamp !== undefined));
    forcedTabChangeSubscription!: Subscription;

    @ViewChild("meteringPointTabs", { static: true })
    meteringPointTabs!: MatTabGroup;

    @ViewChildren(MatTab) tabs!: QueryList<MatTab>;

    tabLabels!: { [key: string]: string };
    tabSelectionSub!: Subscription;

    permissionCheckForTabSelection!: Subscription;

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {
        this.tabLabels = {
            Overview: this.translations.getTranslation("Overview"),
            Meterings: this.translations.getTranslation("Meterings"),
            Events: this.translations.getTranslation("Events"),
            Devices: this.translations.getTranslation("Devices"),
            Prepayment: $localize`:|@@meteringpointSideview.prepayment:Prepayment`
        };
    }
    @HostListener("document:keydown", ["$event"]) onKeydownHandler(event: KeyboardEvent) {
        if (event.code === "Escape") {
            this.onCloseClicked();
        }
    }
    ngAfterViewInit() {
        this.permissionCheckForTabSelection = this.store.select(SecuritySelectors.getUAMPermissionsLoaded).subscribe((isLoaded) => {
            if (isLoaded) {
                setTimeout(() => {
                    this.store
                        .select(RouterSelectors.getSegments)
                        .subscribe((routeSegments) => {
                            const tabIndexes = this.tabs.map((tab, index) => ({ textLabel: tab.textLabel, index }));
                            tabIndexes
                                .filter((tab) => routeSegments.includes(tab.textLabel))
                                .forEach((tab) => {
                                    setTimeout(() => this.selectedTab.setValue(tab.index), 500);
                                });
                        })
                        .unsubscribe();
                });
            }
        });

        this.forcedTabChangeSubscription = this.forcedTabChange$.subscribe((forcedTabWithTimestamp) => {
            const tabIndexes = this.tabs.map((tab, index) => ({ textLabel: tab.textLabel, index }));
            tabIndexes
                .filter((tab) => forcedTabWithTimestamp && tab.textLabel === forcedTabWithTimestamp.tab)
                .forEach((tab) => {
                    setTimeout(() => this.selectedTab.setValue(tab.index));
                });
        });

        this.tabSelectionSub = this.meteringPointTabs.selectedTabChange.subscribe((event: MatTabChangeEvent) => {
            this.store.dispatch(MeteringPointsUIActions.SetSideViewTabToURL({ urlSegment: event.tab.textLabel }));
        });
    }

    ngOnDestroy() {
        if (this.tabSelectionSub) {
            this.tabSelectionSub.unsubscribe();
        }
        if (this.forcedTabChangeSubscription) {
            this.forcedTabChangeSubscription.unsubscribe();
        }
        if (this.permissionCheckForTabSelection) {
            this.permissionCheckForTabSelection.unsubscribe();
        }
    }

    onCloseClicked() {
        this.store.dispatch(MeteringPointsActions.DeselectAllMeteringPoints());
    }

    onRefreshComponentData(isRefreshClicked: boolean) {
        if (isRefreshClicked) {
            this.store.dispatch(RefreshDataActions.LoadRefreshData());
        }
    }
}
