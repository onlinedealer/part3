export class SliderModel {
  sliderVisible: boolean;
  rangeValues: Array<number>;
}
