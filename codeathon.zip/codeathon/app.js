  angular.module('underscore', []).factory('_', function() {
       return window._;
   });

   var codeathonApp = angular.module('codeathonapp', ['ngRoute', 'underscore', 'ngIdle', 'ui.bootstrap', 'ngAnimate']);

   (function() {
       'use strict';
       codeathonApp.config(['$routeProvider', 'uiRouters', 'KeepaliveProvider', myConfigFn]);

       function myConfigFn($routeProvider, uiRouters, KeepaliveProvider) {

           KeepaliveProvider.interval(10);

           $routeProvider.
           when(uiRouters.login, {
               templateUrl: uiRouters.directivesHtmlPath + '/login.html',
               controller: 'loginCtrl'
           }).
           when(uiRouters.dashboard, {
               templateUrl: uiRouters.directivesHtmlPath + '/dashboard.html',
               controller: 'dashboardCtrl'
           }).
           when(uiRouters.contests, {
               templateUrl: uiRouters.directivesHtmlPath + '/contests.html'
           }).
           when(uiRouters.users, {
               templateUrl: uiRouters.directivesHtmlPath + '/users.html'
           }).
           when(uiRouters.reports, {
               templateUrl: uiRouters.directivesHtmlPath + '/reports.html'
           }).
           when(uiRouters.help, {
               templateUrl: uiRouters.directivesHtmlPath + '/help.html'
           }).
           when(uiRouters.adminContextList, {
               templateUrl: uiRouters.directivesHtmlPath + '/manageContest-List.html',
               controller:'contestController'
           }).
           when(uiRouters.adminContextCreate, {
               templateUrl: uiRouters.directivesHtmlPath + '/createContest-01.html',
               controller:'contestController'
           }).
           when(uiRouters.adminContextCreateSub, {
               templateUrl: uiRouters.directivesHtmlPath + '/createContest-02.html',
               controller:'contestController'
           }).
           when(uiRouters.adminDomainList, {
               templateUrl: uiRouters.directivesHtmlPath + '/domian_list.html',
               controller: 'domainCtrl'
           }).
           when(uiRouters.adminTechList, {
               templateUrl: uiRouters.directivesHtmlPath + '/technology_list.html',
               controller: 'technologyCtrl'
           }).
           when(uiRouters.manageLocations, {
               templateUrl: uiRouters.directivesHtmlPath + '/locations.html'
           }).
           when(uiRouters.manageHost, {
               templateUrl: uiRouters.directivesHtmlPath + '/host_list.html',
               controller: 'hostCtrl'
           }).
           when(uiRouters.manageRoles, {
               templateUrl: uiRouters.directivesHtmlPath + '/role_list.html',
               controller: 'roleCtrl'
           }).
           when(uiRouters.manageApis, {
               templateUrl: uiRouters.directivesHtmlPath + '/api.html'
           }).           
           when(uiRouters.adminContext, {
               templateUrl: uiRouters.directivesHtmlPath + '/user_answers.html'
           }).
           when(uiRouters.multisites, {
               templateUrl: uiRouters.directivesHtmlPath + '/multisites_list.html',
			    controller: 'multisitesCtrl'
           }).
           otherwise({
               redirectTo: uiRouters.login
           });
       }
       codeathonApp.run(['$rootScope', '$log', '$ajaxFactory', 'uiRouters', myRunFn]);

       function myRunFn($rootScope, $log, $ajaxFactory, uiRouters) {
           $log.debug('app started.');           
       }
   })();
