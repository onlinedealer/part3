export class ProfileListColumnModel {
  name: string;
  type: string;
}
