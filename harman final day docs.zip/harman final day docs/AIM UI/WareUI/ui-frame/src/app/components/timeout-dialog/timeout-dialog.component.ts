import { Component, OnDestroy } from "@angular/core";
import { timer, Subscription } from "rxjs";
import { map } from "rxjs/operators";
import { environment } from "../../../environments/environment";
import { MatDialogRef } from "@angular/material/dialog";
@Component({
    selector: "landisgyr-timeout-dialog",
    templateUrl: "./timeout-dialog.component.html",
    styleUrls: ["./timeout-dialog.component.scss"]
})
export class TimeoutDialogComponent implements OnDestroy {
    TOTAL_TIME_IN_SECONDS = environment.uam_timeout_in_seconds_after_dialog_is_shown_before_session_expiration;

    secondsUntilSigningOut$ = timer(0, 1000).pipe(map(value => this.TOTAL_TIME_IN_SECONDS - value));

    timerSubscription!: Subscription;

    constructor(public dialogRef: MatDialogRef<TimeoutDialogComponent>) {
        this.timerSubscription = this.secondsUntilSigningOut$.subscribe(value => {
            if (value === 0) {
                this.signOut();
            }
        });
    }

    signOut() {
        this.dialogRef.close("signOut");
    }

    continueSession() {
        this.dialogRef.close("continueSession");
    }

    ngOnDestroy() {
        if (this.timerSubscription) {
            this.timerSubscription.unsubscribe();
        }
    }
}
