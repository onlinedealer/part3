import { Component, Output, EventEmitter, ViewEncapsulation, ViewChild, Input } from "@angular/core";
import { FormControl, FormGroup } from "@angular/forms";
import { InputRefDirective } from "../../../Shared/directives/input-ref.directive";

@Component({
    selector: "landisgyr-meteringpoint-events-subcategorybar",
    templateUrl: "./meteringpoint-events-subcategorybar.component.html",
    styleUrls: ["./meteringpoint-events-subcategorybar.component.scss"],
    encapsulation: ViewEncapsulation.None
})
export class MeteringpointEventsSubcategorybarComponent {
    @Output() showCategories: EventEmitter<any> = new EventEmitter();
    @Output() undoClickedForEvents: EventEmitter<boolean> = new EventEmitter();
    @Output() redoClickedForEvents: EventEmitter<boolean> = new EventEmitter();

    @Input() parent!: FormGroup;
    @Input() selectedEventFiltersPlaceholderText!: string;
    @Input() showUndo!: number;
    @Input() showRedo!: number;

    @ViewChild(InputRefDirective) input!: InputRefDirective;

    undoTooltipText = $localize`:|@@eventsView.undoLatestChange:Undo the latest filter change`;
    redoTooltipText = $localize`:|@@eventsView.redoLatestChange:Redo the latest filter change`;

    selected_subcategory = new FormControl();
    updateTime: Date;
    eventsUpdated: string;
    showFilterCategories = false;

    constructor() {
        this.updateTime = new Date();
        this.eventsUpdated = $localize`:|@@eventsSubCategoryBar.eventsUpdated:Events updated` + ": -";
    }
    onIconClick() {
        this.showFilterCategories = !this.showFilterCategories;
    }
    onCloseFilterMenu() {
        this.showFilterCategories = false;
    }
    onOpenFilterMenu(): void {
        if (this.input.focus) {
            this.showFilterCategories = true;
        }
    }
    onUndoClick() {
        this.onCloseFilterMenu();
        this.undoClickedForEvents.emit(true);
    }
    onRedoClick() {
        this.onCloseFilterMenu();
        this.redoClickedForEvents.emit(true);
    }
}
