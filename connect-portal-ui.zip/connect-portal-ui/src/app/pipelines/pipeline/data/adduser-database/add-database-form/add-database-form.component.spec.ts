import { ComponentFixture, TestBed } from '@angular/core/testing';
import { AddDatabaseFormComponent } from './add-database-form.component';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Connection } from 'src/app/connections/shared/connection';

describe('AddDatabaseFormComponent', () => {
  let component: AddDatabaseFormComponent;
  let fixture: ComponentFixture<AddDatabaseFormComponent>;

  const mockedSourceConnection = {
    id: '1',
    connectionType: 'ORACLE'
  } as Connection;

  const mockAddDatabase = {
    dataConnectionId: '1',
    userDataBaseNames: ['AUDSYS', 'DBTESTER'],
    adminUserId: 'sa',
    adminUserPassword: '***'
  };

  const mockDatabase = ['AUDSYS', 'DBTESTER'];

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [FormsModule, ReactiveFormsModule, getTranslocoModule()],
      declarations: [AddDatabaseFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddDatabaseFormComponent);
    component = fixture.componentInstance;
    component.sourceDataConnection = mockedSourceConnection;
    component.selectedDatabase = mockDatabase;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call getDatabaseObject', () => {
    component.addDatabaseForm.get('adminUserId').setValue('sa');
    component.addDatabaseForm.get('password').setValue('***');
    expect(component.getDatabaseObject()).toEqual(mockAddDatabase);
  });
});
