export class Filter {
  schema: string;
  table: string;
  expression: string;
}

export const FilterMetadata = {
  schema: { type: 'string' },
  table: { type: 'string' },
  expression: { type: 'string' }
};
