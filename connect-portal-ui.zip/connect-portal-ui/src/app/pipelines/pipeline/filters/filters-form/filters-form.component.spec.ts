import { HttpClientTestingModule } from '@angular/common/http/testing';
import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DropdownModule } from 'primeng/dropdown';
import { getTranslocoModule } from 'src/app/core/transloco-testing.module';
import { of } from 'rxjs';
import { PipelinesApiService } from '../../shared/pipelines-api.service';
import { FiltersFormComponent } from './filters-form.component';

describe('FiltersFormComponent', () => {
  let component: FiltersFormComponent;
  let fixture: ComponentFixture<FiltersFormComponent>;
  let mockFilterService: PipelinesApiService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ReactiveFormsModule, FormsModule, DropdownModule, getTranslocoModule(), HttpClientTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [FiltersFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FiltersFormComponent);
    component = fixture.componentInstance;
    mockFilterService = TestBed.inject(PipelinesApiService);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should set isDisabled to false', () => {
    const sampleItem = component.filterFormGroup.controls.expression;
    sampleItem.setValue('sampleText');
    expect(component.validateExpressionButton.isDisabled).toBe(false);
  });

  it('should return schema information', () => {
    component.schemasAndTables = [
      {
        key: 'test1',
        value: {
          tableExtractType: '',
          tableAndKeys: [
            { tableName: 'table1', keys: [] },
            { tableName: 'table2', keys: [] }
          ]
        }
      },
      {
        key: 'test2',
        value: {
          tableExtractType: '',
          tableAndKeys: [
            { tableName: 'table1', keys: [] },
            { tableName: 'table1', keys: [] }
          ]
        }
      }
    ];
    expect(component.schemas).toEqual(['test1', 'test2']);
  });

  it('should return table information when schema is found', () => {
    component.schemasAndTables = [
      {
        key: 'test1',
        value: {
          tableExtractType: '',
          tableAndKeys: [
            { tableName: 'table1', keys: [] },
            { tableName: 'table2', keys: [] }
          ]
        }
      },
      {
        key: 'test2',
        value: {
          tableExtractType: '',
          tableAndKeys: [
            { tableName: 'table1', keys: [] },
            { tableName: 'table1', keys: [] }
          ]
        }
      }
    ];
    component.filterFormGroup.patchValue({ schema: 'test1' });
    expect(component.tables).toEqual([
      { tableName: 'table1', keys: [] },
      { tableName: 'table2', keys: [] }
    ]);
  });

  it('should return empty table array when schema is not found', () => {
    component.schemasAndTables = [
      {
        key: 'test1',
        value: {
          tableExtractType: '',
          tableAndKeys: [
            { tableName: 'table1', keys: [] },
            { tableName: 'table2', keys: [] }
          ]
        }
      },
      {
        key: 'test2',
        value: {
          tableExtractType: '',
          tableAndKeys: [
            { tableName: 'table1', keys: [] },
            { tableName: 'table1', keys: [] }
          ]
        }
      }
    ];
    component.filterFormGroup.patchValue({ schema: 'test3' });
    expect(component.tables).toEqual([]);
  });

  it('should be able to successfully validate filter expression', () => {
    spyOn(mockFilterService, 'validateFilter').and.returnValue(of({ status: 'SUCCESS' }));
    component.validate();
    expect(component.filterValidationExpression).toBe('SUCCESS');
  });
});
