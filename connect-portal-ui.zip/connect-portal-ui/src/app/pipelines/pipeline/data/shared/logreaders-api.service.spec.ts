import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { TestBed } from '@angular/core/testing';
import { LogReadersApiService } from './logreaders-api.service';
import { LogReader } from './logreader';

describe('LogReadersApiService', () => {
  let service: LogReadersApiService;
  let httpMock: HttpTestingController;

  const mockLogReader: LogReader = {
    dataConnectionId: 'abc',
    journalName: 'Journal1',
    logReaderId: '1',
    name: 'Journal1_LogReader',
    parameters: []
  } as LogReader;

  const mockNewLogReader: LogReader = {
    dataConnectionId: 'abc',
    journalName: 'Journal1',
    logReaderId: '1',
    name: 'New_Journal1_LogReader',
    parameters: []
  } as LogReader;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientTestingModule]
    });
    service = TestBed.inject(LogReadersApiService);
    httpMock = TestBed.inject(HttpTestingController);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('should create a log reader', () => {
    const expectedRequestMethod = 'POST';
    const projectId = 'abc';
    const connectionId = 'def';
    const expectedEndpointUrl = `/api/v1/logreaders/create?projectId=${projectId}&dataConnectionId=${connectionId}`;
    let returnedData;
    service.createLogReader(connectionId, projectId, mockLogReader).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    expect(req.request.body).toEqual(mockLogReader);
    req.flush(null);
    httpMock.verify();
    expect(returnedData).toBeNull();
  });

  it('should return a log reader', () => {
    const expectedRequestMethod = 'GET';
    const projectId = 'abc';
    const connectionId = 'def';
    const mockApiResponse = [mockLogReader];
    const expectedEndpointUrl = `/api/v1/logreaders/${projectId}/${connectionId}?logReaderName=${mockLogReader.name}`;
    let returnedData;
    service.getLogReader(connectionId, projectId, mockLogReader.name).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(1);
  });

  it('should update a log reader', () => {
    const expectedRequestMethod = 'PUT';
    const projectId = 'abc';
    const connectionId = 'def';
    const expectedEndpointUrl = `/api/v1/logreaders/${projectId}/${connectionId}/update?logReaderName=${mockLogReader.name}`;
    let returnedData;
    service.updateLogReader(connectionId, projectId, mockLogReader).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    expect(req.request.body).toEqual(mockLogReader);
    req.flush(null);
    httpMock.verify();
    expect(returnedData).toBeNull();
  });

  it('should rename a log reader', () => {
    const expectedRequestMethod = 'PUT';
    const projectId = 'abc';
    const connectionId = 'def';
    const expectedEndpointUrl = `/api/v1/logreaders/${projectId}/${connectionId}/rename?logReaderName=${mockLogReader.name}`;
    let returnedData;
    service.renameLogReader(connectionId, projectId, mockLogReader.name, mockNewLogReader.name).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    expect(req.request.body).toEqual(mockNewLogReader.name);
    req.flush(null);
    httpMock.verify();
    expect(returnedData).toBeNull();
  });

  it('should delete a log reader', () => {
    const expectedRequestMethod = 'DELETE';
    const projectId = 'abc';
    const connectionId = 'def';
    const expectedEndpointUrl = `/api/v1/logreaders/${projectId}/${connectionId}/delete?logReaderName=${mockLogReader.name}`;
    let returnedData;
    service.deleteLogReader(connectionId, projectId, mockLogReader.name).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(null);
    httpMock.verify();
    expect(returnedData).toBeNull();
  });

  it('should return all the log readers', () => {
    const expectedRequestMethod = 'GET';
    const projectId = 'abc';
    const connectionId = 'def';
    const mockApiResponse = [mockLogReader, mockNewLogReader];
    const expectedEndpointUrl = `/api/v1/logreaders?projectId=${projectId}&dataConnectionId=${connectionId}`;
    let returnedData;
    service.getLogReaders(connectionId, projectId).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(2);
  });

  it('should return all the data flows used by a log reader', () => {
    const expectedRequestMethod = 'GET';
    const projectId = 'abc';
    const connectionId = 'def';
    const mockApiResponse = ['df1', 'df2', 'df3'];
    const expectedEndpointUrl = `/api/v1/logreaders/${projectId}/${connectionId}/usage?logReaderName=${mockLogReader.name}`;
    let returnedData;
    service.getDataFlows(connectionId, projectId, mockLogReader.name).subscribe((response) => {
      returnedData = response;
    });
    const req = httpMock.expectOne(expectedEndpointUrl);
    expect(req.request.method).toBe(expectedRequestMethod);
    req.flush(mockApiResponse);
    httpMock.verify();
    expect(returnedData.length).toEqual(3);
  });
});
