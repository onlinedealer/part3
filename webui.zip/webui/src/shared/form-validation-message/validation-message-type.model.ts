export enum ValidationMessageTypeModel {
  Error = 'ERROR',
  Warning = 'WARNING',
  Success = 'SUCCESS',
  Info = 'INFO'
}
