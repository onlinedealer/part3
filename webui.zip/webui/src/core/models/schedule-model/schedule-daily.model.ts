import { ScheduleBaseModel } from './schedule-base.model';

export class ScheduleDailyModel extends ScheduleBaseModel {
  constructor(data?) {
    super();
    this.fromDate = data?.fromDate ? data?.fromDate : new Date(this.setFromDate());
    this.runAtTime = data?.runAtTime ? data?.runAtTime : new Date();
  }
}
