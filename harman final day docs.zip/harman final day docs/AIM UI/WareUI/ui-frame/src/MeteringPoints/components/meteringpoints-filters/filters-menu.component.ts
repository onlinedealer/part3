import { Component } from "@angular/core";

class FilterItem {
    name: string;
    selected: boolean;

    constructor(name: string = "Item") {
        this.name = name;
        this.selected = false;
    }

    selectItem() {
        this.selected = true;
    }
    deselectItem() {
        this.selected = false;
    }
}

@Component({
    selector: "landisgyr-filters-menu",
    templateUrl: "./filters-menu.component.html",
    styleUrls: ["./filters-menu.component.scss"]
})
export class FiltersMenuComponent {
    selectedFilterType = "Basic";

    objs1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map(i => new FilterItem("Item " + i));
    objs2 = [11, 12].map(i => new FilterItem("Item " + i));
    objs3 = [13].map(i => new FilterItem("Item " + i));
    objs4 = [14, 15, 16, 17].map(i => new FilterItem("Item " + i));
    objs5 = [18, 19].map(i => new FilterItem("Item " + i));

    filterTypes: any = {
        Basic: {
            name: "Basic",
            categories: [
                {
                    name: "Category 1",
                    items: this.objs1
                },
                {
                    name: "Category 2",
                    items: this.objs2
                },
                {
                    name: "Category 3",
                    items: this.objs3
                }
            ]
        },
        Tags: {
            name: "Tags",
            categories: [
                {
                    name: "Category 1",
                    items: this.objs4
                },
                {
                    name: "Category 2",
                    items: this.objs5
                }
            ]
        }
    };

    getFilterTypes(): string[] {
        return Object.keys(this.filterTypes);
    }

    selectFilterType(type: string) {
        this.selectedFilterType = type;
    }
}
