import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { MetabaseDetailsFormComponent } from './metabase-details-form.component';
import { RouterTestingModule } from '@angular/router/testing';

describe('MetabaseDetailsFormComponent', () => {
  let component: MetabaseDetailsFormComponent;
  let fixture: ComponentFixture<MetabaseDetailsFormComponent>;
  let metabaseName: string = 'defaultMetabase';

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [getTranslocoModule(), RouterTestingModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      declarations: [MetabaseDetailsFormComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MetabaseDetailsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('it should handle form when selectedMetabe is not null', () => {
    const selectedMetabase = {
      name: 'defaultMetabase',
      dataConnection: {
        name: 'defaultConn',
        connectionType: 'default'
      },
      parameters: [{ key: 'REPLICATION_USER_ID', value: 'rep1' }],
      version: '40i'
    };
    component.selectedMetabase = selectedMetabase;
    component.handleForm(component.selectedMetabase);
    expect(component.metabaseDetails).toBeDefined();
  });

  it('it should handle form when selectedMetabe is  null', () => {
    component.handleForm(null);
    expect(component.metabaseDetails).toBeUndefined();
  });

  it('should set the default details', () => {
    const selectedMetabase = {
      name: 'defaultMetabase',
      dataConnection: {
        name: 'defaultConn',
        connectionType: 'default'
      },
      parameters: [{ key: 'REPLICATION_USER_ID', value: 'rep1' }],
      version: '40i'
    };

    component.open(selectedMetabase, metabaseName);
    expect(component.metabaseDetails.length).toBe(4);
    // test the default labels and values
    expect(component.metabaseDetails[0][0].label).toBe('METABASE_NAME');
    expect(component.metabaseDetails[1][0].label).toBe('DATABASE_SERVER');
    expect(component.metabaseDetails[2][0].label).toBe('DATA_CONNECTION');
    expect(component.metabaseDetails[2][1].label).toBe('CONNECTION_TYPE');
    expect(component.metabaseDetails[3][0].label).toBe('REPLICATION_USER_ID');
    expect(component.metabaseDetails[3][1].label).toBe('METABASE_VERSION');
    expect(component.metabaseDetails[0][0].value).toBe('defaultMetabase');
    expect(component.metabaseDetails[1][0].value).toBe('');
    expect(component.metabaseDetails[2][0].value).toBe('defaultConn');
    expect(component.metabaseDetails[2][1].value).toBe('connections.CONNECTION_TYPES.default');
    expect(component.metabaseDetails[3][0].value).toBe('rep1');
    expect(component.metabaseDetails[3][1].value).toBe('40i');
  });

  describe('DB2', () => {
    it('should set DB2 details', () => {
      const selectedMetabase = {
        name: 'rpuser',
        dataConnection: {
          name: 'Newsfeed Data',
          connectionType: 'DB2',
          database: 'DB2.server',
          port: 50000
        },
        parameters: [{ key: 'REPLICATION_USER_ID', value: 'rpuser' }],
        version: '40c'
      };
      component.open(selectedMetabase, metabaseName);
      expect(component.metabaseDetails.length).toBe(4);
      expect(component.metabaseDetails[1][0].value).toBe('DB2.server:50000');
    });
  });

  describe('DB2I', () => {
    const selectedMetabase = {
      name: 'SHAREMB',
      dataConnection: {
        name: 'Newsfeed Data',
        connectionType: 'DB2I',
        database: 'DB2i.server',
        parameters: [
          { key: 'DB2_I_IASP_NAME', value: 'IASPName' },
          { key: 'DB2_I_RDB_NAME', value: 'RDBName' }
        ]
      },
      parameters: [
        { key: 'REPLICATION_USER_ID', value: 'rpuser' },
        { key: 'IN_SYSBAS', value: 'false' }
      ],
      version: '40i'
    };
    it('should set the DB2 for IBM i details when IN_SYSBAS is false', () => {
      selectedMetabase.parameters[1].value = 'false';
      component.open(selectedMetabase, metabaseName);
      expect(component.metabaseDetails.length).toBe(5);
      // test the additional labels and values for IBM i
      expect(component.metabaseDetails[0][0].label).toBe('DB2I.METABASE_LIBRARY');
      expect(component.metabaseDetails[4][0].label).toBe('DB2I.IASP_NAME');
      expect(component.metabaseDetails[4][1].label).toBe('DB2I.RDB_NAME');
      expect(component.metabaseDetails[4][0].value).toBe('IASPName');
      expect(component.metabaseDetails[4][1].value).toBe('RDBName');
      expect(component.metabaseDetails[1][0].value).toBe('DB2i.server');
    });

    it('should set the DB2 for IBM i details when IN_SYSBAS is true', () => {
      selectedMetabase.parameters[1].value = 'true';
      component.open(selectedMetabase, metabaseName);
      expect(component.metabaseDetails.length).toBe(4);
    });
  });

  describe('ORACLE', () => {
    it('should set Oracle details', () => {
      const selectedMetabase = {
        name: 'REP1_RPUSER',
        dataConnection: {
          name: 'Newsfeed Data',
          connectionType: 'ORACLE',
          database: 'Oracle.server',
          port: 1521
        },
        parameters: [
          { key: 'REPLICATION_USER_ID', value: 'REP1_RPUSER' },
          { key: 'TABLESPACE_NAME', value: 'REP1_RPUSER1' },
          { key: 'TABLESPACE_FILE', value: 'rep1_rpuser.dbf' },
          { key: 'TEMP_TABLESPACE_NAME', value: 'REP1_RPUSER1' },
          { key: 'TEMP_TABLESPACE_FILE', value: 'temprep1_rpuser.dbf' }
        ],
        version: '10.2.0.1.0'
      };
      component.open(selectedMetabase, metabaseName);
      expect(component.metabaseDetails.length).toBe(6);
      // test the additional labels and values for Oracle
      expect(component.metabaseDetails[4][0].label).toBe('ORACLE.METABASE_TABLESPACE');
      expect(component.metabaseDetails[4][1].label).toBe('ORACLE.DATA_FILE_NAME');
      expect(component.metabaseDetails[5][0].label).toBe('ORACLE.METABASE_TEMP_TABLESPACE');
      expect(component.metabaseDetails[5][1].label).toBe('ORACLE.TEMP_FILE_NAME');
      expect(component.metabaseDetails[4][0].value).toBe('REP1_RPUSER1');
      expect(component.metabaseDetails[4][1].value).toBe('rep1_rpuser.dbf');
      expect(component.metabaseDetails[5][0].value).toBe('REP1_RPUSER1');
      expect(component.metabaseDetails[5][1].value).toBe('temprep1_rpuser.dbf');
      expect(component.metabaseDetails[1][0].value).toBe('Oracle.server:1521');
    });
  });

  describe('SQLSERVER', () => {
    it('should set SQL Server details', () => {
      const selectedMetabase = {
        name: 'REP1_RPUSER',
        dataConnection: {
          name: 'Newsfeed Data',
          connectionType: 'SQLSERVER',
          database: 'SQLServer.server',
          port: 1433
        },
        parameters: [
          { key: 'REPLICATION_USER_ID', value: 'rpuser' },
          { key: 'MAX_NUM_ROWS', value: '400000' },
          { key: 'DATA_LOGICAL_NAME', value: 'omnirep_data' },
          { key: 'LOG_LOGICAL_NAME', value: 'omnirep_log' }
        ],
        version: '40i'
      };
      component.open(selectedMetabase, metabaseName);
      expect(component.metabaseDetails.length).toBe(6);
      // test the additional labels and values for SQL Server
      expect(component.metabaseDetails[4][0].label).toBe('SQLSERVER.MAX_TRANSACTION_ROWS');
      expect(component.metabaseDetails[5][0].label).toBe('SQLSERVER.DATA_LOGICAL_NAME');
      expect(component.metabaseDetails[5][1].label).toBe('SQLSERVER.LOG_LOGICAL_NAME');
      expect(component.metabaseDetails[4][0].value).toBe('400000');
      expect(component.metabaseDetails[5][0].value).toBe('omnirep_data');
      expect(component.metabaseDetails[5][1].value).toBe('omnirep_log');
      expect(component.metabaseDetails[1][0].value).toBe('SQLServer.server:1433');
    });
  });
});
