import React from 'react'
import PropTypes from 'prop-types'
import classNames from 'classnames'
import Select from 'react-select'
import { withStyles } from '@material-ui/core/styles'
import Typography from '@material-ui/core/Typography'
import NoSsr from '@material-ui/core/NoSsr'
import TextField from '@material-ui/core/TextField'
import Paper from '@material-ui/core/Paper'
import Chip from '@material-ui/core/Chip'
import MenuItem from '@material-ui/core/MenuItem'
import CancelIcon from '@material-ui/icons/Cancel'
import { emphasize } from '@material-ui/core/styles/colorManipulator'
import CircularProgress from '@material-ui/core/CircularProgress'

const styles = theme => ({
  root: {
    flexGrow: 1,
    width: '100%',
    padding: '5px 0px',
  },
  uomRoot: {
    flexGrow: 1,
    width: 200,
    marginTop: 11,
    marginLeft: 5,
    padding: '5px 0px',
  },
  themeRoot: {
    flexGrow: 1,
    width: 'auto',
    padding: '5px 0px',
  },
  input: {
    display: 'flex',
    padding: 0,
  },
  valueContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    flex: 1,
    alignItems: 'center',
    overflow: 'hidden',
  },
  chip: {
    margin: `${theme.spacing.unit / 2}px ${theme.spacing.unit / 4}px`,
  },
  chipFocused: {
    backgroundColor: emphasize(
      theme.palette.type === 'light' ? theme.palette.grey[300] : theme.palette.grey[700],
      0.08,
    ),
  },
  noOptionsMessage: {
    padding: `${theme.spacing.unit}px ${theme.spacing.unit * 2}px`,
  },
  singleValue: {
    fontSize: 16,
  },
  placeholder: {
    position: 'absolute',
    left: 2,
  },
  paper: {
    position: 'absolute',
    zIndex: 1,
    marginTop: theme.spacing.unit,
    left: 0,
    right: 0,
  },
  divider: {
    height: theme.spacing.unit * 2,
  },
  itemTypeProgress: {
    position: 'absolute',
    right: 42,
  },
})

function NoOptionsMessage (props) {
  return (
    <Typography
      color="textSecondary"
      className={props.selectProps.classes.noOptionsMessage}
      {...props.innerProps}
    >
      {props.children}
    </Typography>
  )
}

function inputComponent ({ inputRef, ...props }) {
  return <div ref={inputRef} {...props} />
}

function Control (props) {
  return (
    <TextField
      fullWidth
      InputProps={{
        inputComponent,
        inputProps: {
          className: props.selectProps.classes.input,
          inputRef: props.innerRef,
          children: props.children,
          ...props.innerProps,
        },
      }}
      {...props.selectProps.textFieldProps}
    />
  )
}

function Option (props) {
  return (
    <MenuItem
      buttonRef={props.innerRef}
      selected={props.isFocused}
      component="div"
      style={{
        fontWeight: props.isSelected ? 500 : 400,
      }}
      {...props.innerProps}
    >
      {props.children}
    </MenuItem>
  )
}

function Placeholder (props) {
  return (
    <Typography
      color="textSecondary"
      className={props.selectProps.classes.placeholder}
      {...props.innerProps}
    >
      {props.children}
    </Typography>
  )
}

function SingleValue (props) {
  return (
    <Typography className={props.selectProps.classes.singleValue} {...props.innerProps}>
      {props.children}
    </Typography>
  )
}

function ValueContainer (props) {
  const { classes, options, textFieldProps } = props.selectProps
  return (<div className={classes.valueContainer}>
    {props.children}
    {(textFieldProps.currentAddedValue !== null && options.length === 0 && textFieldProps.columnId === 'itemType') &&
      <CircularProgress
        className={classes.itemTypeProgress}
        size={20}
      />
    }
  </div>)
}

function MultiValue (props) {
  return (
    <Chip
      tabIndex={-1}
      label={props.children}
      className={classNames(props.selectProps.classes.chip, {
        [props.selectProps.classes.chipFocused]: props.isFocused,
      })}
      onDelete={props.removeProps.onClick}
      deleteIcon={<CancelIcon {...props.removeProps} />}
    />
  )
}

function Menu (props) {
  return (
    <Paper square className={props.selectProps.classes.paper} {...props.innerProps}>
      {props.children}
    </Paper>
  )
}

const components = {
  Control,
  Menu,
  MultiValue,
  NoOptionsMessage,
  Option,
  Placeholder,
  SingleValue,
  ValueContainer,
}

export class IntegrationReactSelect extends React.Component {
  state = {
    single: null,
    multi: null,
    labelMsg: '',
    placeholderMsg: '',
  };

  componentWillMount () {
    this.setState({placeholderMsg: this.props.labeledMsg})
    if (this.props.currentValue && !this.props.isMultiOption) {
      const selected = this.props.options.filter((optn) => {
        return optn.value === this.props.currentValue
      })
      if (selected.length > 0) { this.setState({ single: selected[0], labelMsg: this.props.labeledMsg }) }
    } else if (this.props.currentValue && this.props.isMultiOption) {
      const selected = this.props.options.filter((optn) => {
        return this.props.currentValue.indexOf(optn.value) !== -1
      })
      if (selected.length > 0) { this.setState({ multi: selected, labelMsg: this.props.labeledMsg }) }
    } else {
      this.setState({ multi: null, single: null })
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.currentValue && !nextProps.isMultiOption) {
      const selected = nextProps.options.filter((optn) => {
        return optn.value === nextProps.currentValue
      })
      if (selected.length > 0) { this.setState({ single: selected[0], labelMsg: nextProps.labeledMsg }) }
    } else if (nextProps.currentValue && nextProps.isMultiOption) {
      const selected = nextProps.options.filter((optn) => {
        return nextProps.currentValue.indexOf(optn.value) !== -1
      })
      if (selected.length > 0) { this.setState({ multi: selected, labelMsg: nextProps.labeledMsg }) }
    } else {
      this.setState({ multi: null, single: null })
    }
  }

  handleChange = name => changedValue => {
    this.setState({
      [name]: changedValue,
    })
    if (name === 'single' && changedValue && changedValue.value) {
      if (this.props.labeledMsg === 'UOM') {
        this.props.handleSelectChange(this.props.column_id, changedValue.value, 'UOM')
      } else {
        this.props.handleSelectChange(this.props.column_id, changedValue.value)
      }
    } else if (name === 'multi' && changedValue && changedValue.length > 0) {
      let tempStr = []
      changedValue.map((option) => {
        tempStr.push(option.value)
      })
      this.props.handleSelectChange(this.props.column_id, tempStr)
    } else {
      this.props.handleSelectChange(this.props.column_id, '')
    }
  };

  handlekeyDown = evt => {
    let tarVal = evt.target
    setTimeout(() => {
      if (typeof this.props.handlekeyDown === 'function') {
        this.props.handlekeyDown(this.props.column_id, tarVal.value)
      }
    }, 300)
  }

  handleFocus = msg => evt => {
    this.setState({labelMsg: msg, placeholderMsg: ''})
  }
  handleBlur = name => evt => {
    if (this.state[name] === null || this.state[name] === '' || this.state[name].length === 0) {
      this.setState({labelMsg: '', placeholderMsg: this.state.labelMsg})
    }
  }
  render () {
    const { classes, theme, isMultiOption, options, labeledMsg, pageFrom, columnId } = this.props

    const selectStyles = {
      input: base => ({
        ...base,
        color: theme.palette.text.primary,
        '& input': {
          font: 'inherit',
        },
      }),
    }

    const styleRoot = (labeledMsg === 'UOM') ? classes.uomRoot : (pageFrom === 'theme update') ? classes.themeRoot : classes.root
    return (
      <div className={styleRoot}>
        <NoSsr>
          {isMultiOption ? (
            <Select
              classes={classes}
              styles={selectStyles}
              textFieldProps={{
                label: `${this.state.labelMsg}`,
                InputLabelProps: {
                  shrink: true,
                },
                autoFocus: true,
                currentAddedValue: `${this.state.multi}`,
                columnId: `${columnId}`,
              }}
              options={options}
              components={components}
              value={this.state.multi}
              onChange={this.handleChange('multi')}
              onFocus={this.handleFocus(labeledMsg)}
              onBlur={this.handleBlur('multi')}
              placeholder={this.state.placeholderMsg}
              isMulti
            />
          ) : (
            <Select
              classes={classes}
              styles={selectStyles}
              textFieldProps={{
                label: `${this.state.labelMsg}`,
                InputLabelProps: {
                  shrink: true,
                },
                autoFocus: true,
                currentAddedValue: `${this.state.single}`,
                columnId: `${columnId}`,
              }}
              options={options}
              components={components}
              value={this.state.single}
              onChange={this.handleChange('single')}
              onFocus={this.handleFocus(labeledMsg)}
              onBlur={this.handleBlur('single')}
              placeholder={this.state.placeholderMsg}
              onKeyDown={this.handlekeyDown.bind(this)}
            />
          )}
        </NoSsr>
      </div>
    )
  }
}

IntegrationReactSelect.propTypes = {
  classes: PropTypes.object.isRequired,
  theme: PropTypes.object.isRequired,
}

export default withStyles(styles, { withTheme: true })(IntegrationReactSelect)
