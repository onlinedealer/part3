app.controller("globalController", ['$rootScope', '$scope', '$http', '$interval', '$filter', '$window', 'uiGridConstants', '$mdSidenav', 'gridColumnService', 'globalServices',
    function($rootScope, $scope, $http, $interval, $filter, $window, uiGridConstants, $mdSidenav, gridColumnService, globalServices) {

        $scope.timer = 300;
        $scope.countdownTime = 0;
        var timerId;
        $scope.timerData = [{ value: 5, name: "5 min" }, { value: 10, name: "10 min" }, { value: 15, name: "15 min" }]
        $scope.selectedCountDownValue = $scope.timerData[0];

        $rootScope.tableTabs = [{
            title: 'Current Projections',
            url: 'details.tpl.html'
        }, {
            title: 'Historical Projections',
            url: 'history.tpl.html'
        }];
        $scope.currentTableTab = "details.tpl.html";
        $scope.onClickTableTab = function(tab) {
            $scope.currentTableTab = tab.url;
        }

        $scope.isActiveTableTab = function(tabUrl) {
            return tabUrl == $scope.currentTableTab;
        }

        $scope.toggleLeft = buildDelayedToggler('left');
        $scope.isOpenRight = function() {
            return $mdSidenav('left').isOpen();
        };

        /**
         * Supplies a function that will continue to operate until the
         * time is up.
         */
        function debounce(func, wait, context) {
            var timer;
            return function debounced() {
                var context = $scope,
                    args = Array.prototype.slice.call(arguments);
                $timeout.cancel(timer);
                timer = $timeout(function() {
                    timer = undefined;
                    func.apply(context, args);
                }, wait || 10);
            };
        }
        /**
         * Build handler to open/close a SideNav; when animation finishes
         * report completion in console
         */
        function buildDelayedToggler(navID) {
            return debounce(function() {
                // Component lookup should always be available since we are not using `ng-if`
                $mdSidenav(navID)
                    .toggle()
                    .then(function() {
                        $log.debug("toggle " + navID + " is done");
                    });
            }, 200);
        }

        function buildToggler(navID) {
            return function() {
                // Component lookup should always be available since we are not using `ng-if`
                $mdSidenav(navID)
                    .toggle()
                    .then(function() {
                        $log.debug("toggle " + navID + " is done");
                    });
            }
        }

        $scope.close = function() {
            // Component lookup should always be available since we are not using `ng-if`
            $mdSidenav('left').close()
                .then(function() {
                    $log.debug("close LEFT is done");
                });
        };
        $scope.changeCountDownTimer = function(selectedItem) {
            $scope.countdownTime = 0;
            $scope.countdownTimer(true, selectedItem.value, 0);
        }

        $scope.countdownTimer = function(ischanged, minutes, seconds) {
            var endTime, hours, mins, msLeft, time, currentItr;
            var timerList = [];

            function twoDigits(n) {
                return (n <= 9 ? "0" + n : n);
            }

            function updateTimer() {
                msLeft = endTime - (+new Date);
                if (msLeft < 1000) {
                    if (!ischanged) {
                        $window.location.reload();
                    }
                } else {
                    time = new Date(msLeft);
                    hours = time.getUTCHours();
                    mins = time.getUTCMinutes();
                    if (!$scope.$$phase) {
                        $scope.$apply(function() {
                            timerList.splice(timerList.indexOf(timerId), 1);                            
                            $scope.countdownTime = (hours ? hours + ':' + twoDigits(mins) : mins) + ':' + twoDigits(time.getUTCSeconds());
                        });
                    }
                    if (ischanged) {                        
                        for (var i = 0; i < timerList.length; i++) {
                            var id = timerList[i];
                            window.clearTimeout(id);
                        }
                    } else {
                        currentItr = time.getUTCMilliseconds();
                    }
                    timerId = setTimeout(updateTimer, currentItr + 500);
                    timerList.push(timerId);
                }
            }
            endTime = (+new Date) + 1000 * (60 * minutes + seconds) + 500;
            updateTimer();
        };

        $scope.countdownTimer(false, 5, 0);
    }
]);





app.controller("projectionsMainCtrl", ['$rootScope', '$scope', '$timeout', '$filter',
    function($rootScope, $scope, $timeout, $filter) {


    }
]);

app.controller("projectionsDetailCtrl", ['$rootScope', '$scope', '$timeout', '$filter',
    function($rootScope, $scope, $timeout, $filter) {


    }
]);

app.controller("projectionsYearlyCtrl", ['$rootScope', '$scope', '$timeout', '$filter',
    function($rootScope, $scope, $timeout, $filter) {


    }
]);

app.controller("projectionsMonthlyCtrl", ['$rootScope', '$scope', '$timeout', '$filter',
    function($rootScope, $scope, $timeout, $filter) {


    }
]);
