import { Connection } from '../../../shared/connection';

export interface BaseConnectionForm {
  getConnection(isTesting: boolean): Connection;
  createForm(): void;
}
