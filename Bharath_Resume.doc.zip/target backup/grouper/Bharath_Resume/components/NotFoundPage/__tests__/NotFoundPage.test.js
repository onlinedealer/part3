import React from 'react'
import { shallow } from 'enzyme'
import NotFound from '../NotFoundPage'

describe('NotFound Page component', () => {
  let wrapper
  beforeEach(() => {
    wrapper = shallow(<NotFound />)
  })

  const props = {
    headerTitle: 'NotFoundTitle',
  }

  it('renders without title', () => {
    wrapper = shallow(<NotFound />)
    expect(wrapper).toHaveLength(1)
  })

  it('renders with title', () => {
    wrapper = shallow(<NotFound {...props} />)
    expect(wrapper).toHaveLength(1)
  })
})
