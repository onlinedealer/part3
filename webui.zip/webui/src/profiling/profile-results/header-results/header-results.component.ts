import { ResultHeaderModel } from './../header.model';
import { Component, Input } from '@angular/core';

@Component({
  selector: 'discovery-header-results',
  templateUrl: './header-results.component.html',
  styleUrls: ['./header-results.component.css']
})
export class HeaderResultsComponent {
  @Input() headerData: ResultHeaderModel;
}
