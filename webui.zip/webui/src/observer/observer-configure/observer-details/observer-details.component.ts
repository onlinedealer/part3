import { Component, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { LaunchDarklyService } from '@precisely/prism-ng/launch-darkly';
import { NotifyConfig } from 'core/models/notification-config/email-config.model';
import { ScheduleConfigModel } from 'discovery-core';
import { NameValidatorService, ScheduleComponent, SharedConstants } from 'discovery-shared';
import { ObserverConstants } from 'observer/observer-constants';
import { EmailNotifyConfigComponent } from 'shared/email-notify-config/email-notify-config.component';
import { ObserverConfigureModel } from '../observer-configure.model';
@Component({
  selector: 'discovery-observer-details',
  templateUrl: './observer-details.component.html',
  styleUrls: ['./observer-details.component.css']
})
export class ObserverDetailsComponent {
  emailList: string[];
  @ViewChild('observerDetailForm')
  observerDetailForm: NgForm;

  @ViewChild('observeScheduler')
  observeScheduleComponent: ScheduleComponent;
  @ViewChild('emailNotifyConfig')
  emailNotifyConfigCompoent: EmailNotifyConfigComponent;

  @Input() observerDescription: string;
  @Input() notifConfig: NotifyConfig;
  @Output() observerNameChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() observerDescriptionChange: EventEmitter<string> = new EventEmitter<string>();
  @Output() schedulerChange: EventEmitter<ScheduleConfigModel> = new EventEmitter<ScheduleConfigModel>();
  // @Output() emailNotifChange: EventEmitter<NotifyConfig> = new EventEmitter<NotifyConfig>();
  NameValidatorService: typeof NameValidatorService = NameValidatorService;
  observerSampleSize: number;
  observerNotification: string;
  scheduleEnabled: boolean = true;
  readonly minimumSampleSize: number = 1;
  readonly maximumSampleSize: number;
  @Input() observerName: string;
  observerNameError: any = {
    invalidName: false
  };

  get emailNotificationFlag(): boolean {
    return this.launchDarklyService.variation<boolean>(SharedConstants.featureFlags.EMAIL_NOTIFICATION);
  }

  constructor(private launchDarklyService: LaunchDarklyService) {}

  validateobserverName() {
    this.observerName = this.observerName?.trim();
    this.observerNameError.invalidName = false;
    if (this.observerName) {
      const test = NameValidatorService.validateName(this.observerName);
      if (!test || this.observerName.length > ObserverConstants.OBSERVERNAMEMAXLENGTH) {
        this.observerNameError.invalidName = true;
      }
    }
  }
  getSchedulerChange(event) {
    this.schedulerChange.emit(event);
  }
  observerNameChanged() {
    this.observerNameChange.emit(this.observerName?.trim());
  }

  observerDescriptionChanged() {
    this.observerDescriptionChange.emit(this.observerDescription);
  }

  validate(): Set<string> {
    this.validateobserverName();
    const errors: Set<string> = new Set<string>();
    this.observerDetailForm.onSubmit(null);
    if (!this.observerName || this.observerName.length === 0) {
      errors.add('discoveryObserver.observerDetails.missingName');
    } else if (
      !this.NameValidatorService.validateName(this.observerName) ||
      this.observerName.length > ObserverConstants.OBSERVERNAMEMAXLENGTH
    ) {
      errors.add('discoveryObserver.observerDetails.invalidName');
    }
    //remove the first condtion i.e flag if feature flag removed
    if (!this.observeScheduleComponent?.onSubmit()) {
      errors.add('discoveryObserver.scheduleProfile.errorMessages.invalidSchedule');
    }
    if (this.emailNotifyConfigCompoent) {
      this.emailNotifyConfigCompoent.onSubmitForm();
      if (!this.emailNotifyConfigCompoent.isFormValid) {
        errors.add('discoveryObserver.notificationProfile.invalidEmailConfig');
      }
    }

    return errors;
  }

  loadObserverSettings(observerConfigureModel: ObserverConfigureModel, isEdit: boolean) {
    this.observerName = observerConfigureModel.name ? observerConfigureModel.name : '';
    this.observerDescription = observerConfigureModel.description ? observerConfigureModel.description : '';
    if (observerConfigureModel.scheduleConfig) {
      this.observeScheduleComponent?.loadScheduleSettings(observerConfigureModel, isEdit);
    }
  }
}
