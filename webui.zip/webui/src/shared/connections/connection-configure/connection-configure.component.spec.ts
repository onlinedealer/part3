import { Mocks, Spies } from 'discovery-test';
import { ConnectionConfigureComponent } from './connection-configure.component';
import { of, throwError } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { SharedConstants } from 'discovery-shared';

describe('ConnectionConfigureComponent', () => {
  let component: ConnectionConfigureComponent;

  beforeEach(() => {
    Spies.init();
    component = new ConnectionConfigureComponent(Spies.ConnectionService, Spies.TranslateService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('test cancel', () => {
    const spy = spyOn(component.showConnectionSidebarChange, 'emit');
    component.cancelCreate();
    expect(spy.calls.count()).toBe(1);
  });

  it('should check save connection', () => {
    const spy = spyOn(component.refresh, 'emit');
    Spies.ConnectionService.saveConnection.and.returnValue(of('dummy'));
    component.saveConnection();
    expect(component.saveInProgress).toBe(false);
    expect(spy.calls.count()).toBe(1);
  });

  it('test save connection failed at server side', () => {
    Spies.ConnectionService.saveConnection.and.returnValue(throwError(Mocks.MockHTTPErrorResponse));
    component.saveConnection();
    expect(component.saveInProgress).toBe(false);
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });

  it('should check test connection', () => {
    Spies.ConnectionService.testConnectionByObject.and.returnValue(of('dummy'));
    component.testConnection();
    expect(component.testInProgress).toBe(false);
    expect(component.successMessages.length).toBeGreaterThan(0);
  });

  it('should test connection failed at server side', () => {
    Spies.ConnectionService.testConnectionByObject.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[0]));
    component.testConnection();
    expect(component.testInProgress).toBe(false);
    expect(component.failureMessages.length).toBeGreaterThan(0);
  });

  it('should load connection on loadconnectionById', () => {
    Spies.ConnectionService.loadConnectionById.and.returnValue(of(Mocks.MockConnections[0]));
    component.loadConnectionById('1');
    // expect(component.connectionModel.id).toBe('b26627bf-2535-4835-b8b0-0ba9d58358aa');
  });

  it('should check save connection mock', () => {
    const connection = Mocks.MockConnections;
    Spies.ConnectionService.saveConnection.and.returnValue(of(connection[0]));
    component.ngOnInit();
    expect(component.saveConnection).toBeDefined();
    expect(component.failureMessages.length).toBe(0);
  });

  it('should check account incorrect', () => {
    Spies.ConnectionService.testConnectionByObject.and.returnValue(throwError(Mocks.MockHTTPErrorResponse[4]));
    component.testConnection();
    expect(component.isAccountIncorrect).toBe(true);
    expect(component.failureMessages.length).toEqual(2);
  });

  it('should clear messages and load connetion on edit mode', () => {
    component.viewType = SharedConstants.connectionConfigureModes.COPY;
    spyOn(component, 'loadConnectionById');
    Spies.ConnectionService.loadConnectionById.and.returnValue(of(Mocks.MockConnections[0]));
    component.loadData();
    expect(component.loadConnectionById).toHaveBeenCalled();
  });

  it('should check loadconnectionbyid failure', () => {
    const error = new HttpErrorResponse(Mocks.MockHTTPErrorResponse[0]);
    Spies.ConnectionService.getConnectionById.and.returnValue(throwError(error));
    component.loadConnectionById('1');
    expect(component.loadFailureMessages.length).toBeGreaterThan(0);
  });

  it('should check submitConnection save', () => {
    spyOn(component, 'saveConnection');
    component.invalidName = false;
    const mockedDocElement = document.createElement('button');
    mockedDocElement.id = 'connection-save';
    component.submitConnection(mockedDocElement);
    expect(component.invalidName).toBe(false);
  });

  it('should check submitConnection test', () => {
    Spies.ConnectionService.testConnectionByObject.and.returnValue(of('dummy'));
    spyOn(component, 'testConnection').and.callThrough();
    const mockedDocElement = document.createElement('button');
    mockedDocElement.id = 'connection-test';
    component.submitConnection(mockedDocElement);
    expect(component['testConnection']).toHaveBeenCalled();
  });

  it('should test setters', () => {
    component.connectionId = 'test';
    component.showConnectionSidebar = true;
    component.viewType = SharedConstants.connectionConfigureModes.ADD;
    expect(component.connectionId).toBe('test');
    expect(component.showConnectionSidebar).toBe(true);
    expect(component.viewType).toBe(SharedConstants.connectionConfigureModes.ADD);
  });

  it('should clear success message when close', () => {
    const data = { type: 'SUCCESS', message: 'some instantly translated text' };
    Spies.ConnectionService.testConnectionByObject.and.returnValue(of('dummy'));
    spyOn(component, 'testConnection').and.callThrough();
    const mockedDocElement = document.createElement('button');
    mockedDocElement.id = 'connection-test';
    component.submitConnection(mockedDocElement);
    component.closeValidationMessage(data);
    expect(component.successMessages).toEqual([]);
  });
});
