export interface SavedSchema {
  name: string;
  tables: string[];
  id?: string;
}

export interface ScheduledConnectionSchema {
  id: string;
  name?: string;
  type?: string;
  __typename?: string;
  leaf?: boolean;
}

export interface SchemaConnectionRoot {
  id: string;
  hostName: string;
  connections: ScheduledConnectionSchema[];
  type?: string;
  __typename?: string;
}
