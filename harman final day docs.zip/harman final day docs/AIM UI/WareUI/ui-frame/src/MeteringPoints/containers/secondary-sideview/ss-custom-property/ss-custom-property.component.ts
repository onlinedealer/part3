import { Component, Input, EventEmitter, Output, ChangeDetectionStrategy } from "@angular/core";
import { TranslationsService } from "../../../../app/services/translations-service";
import { CustomPropertyVO } from "../../../models/view-objects/custom-property-vo.model";
import { Store } from "@ngrx/store";
import { Observable } from "rxjs";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import * as MeteringPointsSelectors from "../../../store/selectors/meteringpoints.selectors";
import { MeteringPoint } from "../../../models/meteringpoint.model";
import { SortOrder } from "../../../../Shared/models/sort-order.model";
import { MeteringsSelectors } from "../../../store/selectors";

interface ColumnTitles {
    [key: string]: string;
}

@Component({
    selector: "landisgyr-ss-custom-property",
    templateUrl: "./ss-custom-property.component.html",
    styleUrls: ["./ss-custom-property.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSCustomPropertyComponent {
    loading$: Observable<any> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);
    refreshDataLoading$: Observable<boolean> = this.store.select(MeteringPointsSelectors.getLoadingData);
    @Output() sortChangeEvent: EventEmitter<SortOrder> = new EventEmitter();
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);
    customproperties$: Observable<CustomPropertyVO[]> = this.store.select(MeteringPointsSelectors.getMeteringPointsCustomPropertyForTable);

    constructor(public translations: TranslationsService, private store: Store<MeteringPointsFeatureState>) {}
}
