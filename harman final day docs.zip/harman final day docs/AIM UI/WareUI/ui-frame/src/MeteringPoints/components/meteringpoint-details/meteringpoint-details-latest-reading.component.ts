import { Component, Input } from "@angular/core";
import { TranslationsService } from "../../../app/services/translations-service";

@Component({
    selector: "landisgyr-meteringpoint-details-latest-reading",
    templateUrl: "./meteringpoint-details-latest-reading.component.html",
    styleUrls: ["./meteringpoint-details-latest-reading.component.scss"]
})
export class MeteringPointDetailsLatestReadingComponent {
    constructor(public translations: TranslationsService) {}

    @Input() latestReadingDate: any;

    @Input() missingDataForMetering!: boolean;

    @Input() missingMeterConnection!: boolean;

    @Input() missingDataBasedOnLimit!: boolean;

    @Input() haveNoProfileMeterings!: boolean;

    @Input() loading!: boolean;

    getStatusKey(): string {
        if (this.missingMeterConnection) {
            return "MISSING_METERING_CONNECTION";
        } else if (this.latestReadingDate === 0 && this.haveNoProfileMeterings) {
            return "";
        } else if (this.missingDataBasedOnLimit || this.missingDataForMetering) {
            return "MISSING_DATA";
        } else if (this.latestReadingDate !== 0) {
            return "OK";
        } else {
            return "";
        }
    }
}
