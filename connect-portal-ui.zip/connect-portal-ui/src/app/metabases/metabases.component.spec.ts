import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { of } from 'rxjs';
import { getTranslocoModule } from '../core/transloco-testing.module';
import { Project } from '../pipelines/pipeline/shared/project';
import { ProjectsApiService } from '../pipelines/pipeline/shared/projects-api.service';
import { MetabaseSidebarComponent } from './metabase-sidebar/metabase-sidebar.component';
import { MetabasesComponent } from './metabases.component';
import { Metabase } from './shared/metabase.model';
import { MetabasesApiService } from './shared/metabases-api.service';
import { MetabaseDetailsSidebarComponent } from './metabase-details-sidebar/metabase-details-sidebar.component';
import { UpgradeMetabaseSidebarComponent } from './upgrade-metabase-sidebar/upgrade-metabase-sidebar.component';
import { DeleteMetabaseSidebarComponent } from './delete-metabase-sidebar/delete-metabase-sidebar.component';
import { FeatureFlagService } from '@shared/services/feature-flag.service';

describe('MetabasesComponent', () => {
  let component: MetabasesComponent;
  let fixture: ComponentFixture<MetabasesComponent>;
  let projectsApiService: ProjectsApiService;
  let metabasesApiService: MetabasesApiService;
  let mockFeatureFlagService: any;

  @Component({
    selector: 'p-connect-metabase-sidebar',
    template: '',
    providers: [
      {
        provide: MetabaseSidebarComponent,
        useClass: MockMetabaseSidebarComponent
      }
    ]
  })
  class MockMetabaseSidebarComponent {
    setConnection() {}
  }

  @Component({
    selector: 'p-connect-metabase-details-sidebar',
    template: '',
    providers: [
      {
        provide: MetabaseDetailsSidebarComponent,
        useClass: MockMetabaseDetailsSidebarComponent
      }
    ]
  })
  class MockMetabaseDetailsSidebarComponent {
    open(selectedMetabase) {}
  }

  @Component({
    selector: 'p-connect-upgrade-metabase-sidebar',
    template: '',
    providers: [
      {
        provide: UpgradeMetabaseSidebarComponent,
        useClass: MockUpgradeMetabaseSidebarComponent
      }
    ]
  })
  class MockUpgradeMetabaseSidebarComponent {
    open(selectedMetabase) {}
  }

  @Component({
    selector: 'p-connect-delete-metabase-sidebar',
    template: '',
    providers: [
      {
        provide: DeleteMetabaseSidebarComponent,
        useClass: MockDeleteMetabaseSidebarComponent
      }
    ]
  })
  class MockDeleteMetabaseSidebarComponent {
    open(selectedMetabase) {}
  }

  beforeEach(async () => {
    mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

    await TestBed.configureTestingModule({
      imports: [HttpClientTestingModule, getTranslocoModule()],
      declarations: [
        MetabasesComponent,
        MockMetabaseSidebarComponent,
        MockMetabaseDetailsSidebarComponent,
        MockUpgradeMetabaseSidebarComponent,
        MockDeleteMetabaseSidebarComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        {
          provide: MetabaseSidebarComponent,
          useClass: MockMetabaseSidebarComponent
        },
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'connections' } },
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MetabasesComponent);
    projectsApiService = TestBed.inject(ProjectsApiService);
    metabasesApiService = TestBed.inject(MetabasesApiService);
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
    spyOn(metabasesApiService, 'getAll').and.returnValue(of([{} as Metabase]));
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open metabase sidebar to add a new metabase', () => {
    component.tableConfiguration.createButtonClicked();
    expect(component.isMetabaseSidebarVisible).toBe(true);
  });

  it('should handle row action for deleting metabases', () => {
    spyOn(component.deleteMetabaseSidebarComponent, 'open').and.returnValue();
    component.tableConfiguration.rowAction.menuItems
      .find((item) => item.id === 'deleteMenuItem')
      .command({ item: { target: { id: '1' } } });
    expect(component.deleteMetabaseSidebarComponent.open).toHaveBeenCalled();
  });

  it('should handle row action for metabase details', () => {
    spyOn(component.metabaseDetailsSidebarComponent, 'open').and.returnValue();
    component.tableConfiguration.rowAction.menuItems
      .find((item) => item.id === 'metabaseDetailsMenuItem')
      .command({ item: { target: { id: '1' } } });
    expect(component.metabaseDetailsSidebarComponent.open).toHaveBeenCalled();
  });

  it('should handle row action for upgrade metabase', () => {
    spyOn(component.upgradeMetabaseSidebarComponent, 'open').and.returnValue();
    component.tableConfiguration.rowAction.menuItems
      .find((item) => item.id === 'metabaseUpgradeMenuItem')
      .command({ item: { target: { id: '1' } } });
    expect(component.upgradeMetabaseSidebarComponent.open).toHaveBeenCalled();
  });

  it('should display project name in breadcrumbs', () => {
    jasmine.getEnv().allowRespy(true);
    spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd', name: 'Default_Project' } as Project));
    component.getAllMetabases();
    expect(component.breadcrumbs[2].text).toEqual('Default_Project');
  });
});
