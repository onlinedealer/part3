import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { TranslocoModule } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { SharedModule } from '../../../shared/shared.module';
import { PipelineFinalizeComponent } from './pipeline-finalize.component';
import { AccordionModule } from 'primeng/accordion';
import { PipelineFinalizeSummaryComponent } from './pipeline-finalize-summary/pipeline-finalize-summary.component';
import { PipelinesSharedModule } from '../../shared/pipelines-shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [PipelineFinalizeComponent, PipelineFinalizeSummaryComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    TranslocoModule,
    CheckboxModule,
    AccordionModule,
    PipelinesSharedModule
  ]
})
export class PipelineFinalizeModule {}
