import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogReaderMessagesSidebarComponent } from './log-reader-messages-sidebar.component';
import { SidebarModule } from 'primeng/sidebar';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { HttpClientTestingModule } from '@angular/common/http/testing';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { DropdownModule } from 'primeng/dropdown';
import { FormsModule } from '@angular/forms';
import { LogReaderMessagesFormComponent } from './log-reader-messages-form/log-reader-messages-form.component';

describe('LogReaderMessagesSidebarComponent', () => {
  let component: LogReaderMessagesSidebarComponent;
  let fixture: ComponentFixture<LogReaderMessagesSidebarComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [SidebarModule, getTranslocoModule(), HttpClientTestingModule, DropdownModule, FormsModule],
      declarations: [LogReaderMessagesSidebarComponent, LogReaderMessagesFormComponent, SidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogReaderMessagesSidebarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should fetch logs when it is opened', () => {
    const getLogsSpy = spyOn(component.logReaderMessagesFormComponent, 'getLogs');
    component.open('projectId', {
      dataConnection: 'conn1',
      name: 'logreader1'
    } as any);
    expect(getLogsSpy).toHaveBeenCalled();
  });

  it('should handle service error', () => {
    const errorSpy = spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage');
    component.handleServiceError('error');
    expect(errorSpy).toHaveBeenCalled();
  });
});
