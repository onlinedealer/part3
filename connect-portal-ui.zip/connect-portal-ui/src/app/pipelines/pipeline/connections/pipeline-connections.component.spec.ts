import { ComponentFactoryResolver, ComponentRef, NO_ERRORS_SCHEMA, ViewContainerRef } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthModule } from 'angular-auth-oidc-client';
import { FeatureFlagService } from 'src/app/shared/services/feature-flag.service';
import { environment } from '../../../../environments/environment';
import { Connection } from '../../../connections/shared/connection';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { DynamicHostDirective } from '../../../shared/directives/dynamic-host.directive';
import { SharedModule } from '../../../shared/shared.module';
import { Pipeline, TargetConnectionInfo } from '../shared/pipeline';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { PipelineConnectionsComponent } from './pipeline-connections.component';

describe('PipelineConnectionsComponent', () => {
  let component: PipelineConnectionsComponent;
  let fixture: ComponentFixture<PipelineConnectionsComponent>;
  let pipelineEntityService: PipelineEntityService;
  let getPipeline: any;
  let patchPipeline: any;

  const mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);

  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['initiateProgressSteps', 'setActiveStepByRouterLink', 'setIsValid']
  );

  beforeEach(async () => {
    const componentFactoryResolverStub = () => ({
      resolveComponentFactory: (targetComponent) => ({})
    });

    TestBed.overrideComponent(PipelineConnectionsComponent, {
      set: {
        providers: [{ provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService }]
      }
    });

    await TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      imports: [getTranslocoModule(), SharedModule, AuthModule.forRoot({}), RouterTestingModule],
      declarations: [PipelineConnectionsComponent],
      providers: [
        {
          provide: ComponentFactoryResolver,
          useFactory: componentFactoryResolverStub
        },
        FormBuilder,
        { provide: FeatureFlagService, useValue: mockFeatureFlagService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    jasmine.getEnv().allowRespy(true);
    const viewContainerReference = jasmine.createSpyObj<ViewContainerRef>(['createComponent', 'get', 'clear']);
    viewContainerReference.createComponent.and.returnValue({ instance: {} } as ComponentRef<any>);
    fixture = TestBed.createComponent(PipelineConnectionsComponent);
    component = fixture.componentInstance;
    pipelineEntityService = TestBed.inject(PipelineEntityService);
    component.dynamicHost = new DynamicHostDirective(viewContainerReference);
    const pipeline = new Pipeline();
    pipeline.source = {
      dataConnection: new Connection()
    };
    pipeline.dataFlowType = 'SYNCHRONIZE';
    pipeline.target = new TargetConnectionInfo();
    pipeline.target.dataConnection = {};
    pipeline.target.cdcRowMetadatas = [];
    pipeline.target.parameters = [];
    getPipeline = spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    patchPipeline = spyOn(pipelineEntityService, 'patchPipeline');
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  describe('setting the available connections', () => {
    const pipeline = new Pipeline();

    const mockSupportedSources = [
      { connectionType: 'ORACLE', accessMethods: ['JDBC'] },
      { connectionType: 'DB2ZOS', accessMethods: ['JDBC'] },
      { connectionType: 'DB2I', accessMethods: ['JDBC'] },
      { connectionType: 'DB2', accessMethods: ['JDBC'] },
      { connectionType: 'SQLSERVER', accessMethods: ['JDBC'] }
    ];

    const mockSupportedTargets = [
      { connectionType: 'KAFKA', accessMethods: [] },
      { connectionType: 'SCHEMAREGISTRY', accessMethods: [] }
    ];

    beforeEach(() => {
      pipeline.source = {
        dataConnection: new Connection()
      };
      pipeline.target = new TargetConnectionInfo();
      pipeline.target.dataConnection = {};
      pipeline.target.cdcRowMetadatas = [];
      pipeline.target.parameters = [];

      environment.supportedSourceConnectionTypes = [...mockSupportedSources];
      environment.supportedTargetConnectionTypes = [...mockSupportedTargets];

      jasmine.getEnv().allowRespy(true);
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue(pipeline);
    });

    it('should return all supported connections types', () => {
      pipeline.dataFlowType = 'COPY';
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
      component.ngOnInit();
      expect(component.visibleConnectionTypes).toEqual(mockSupportedSources);
    });

    it('should return all connection types except DB2ZOS if the data flow type is SYNCHRONIZE', () => {
      pipeline.dataFlowType = 'SYNCHRONIZE';
      component.ngOnInit();
      expect(component.visibleConnectionTypes).not.toEqual(mockSupportedSources);
      expect(component.visibleConnectionTypes.filter((connection) => connection.connectionType === 'DB2ZOS').length).toBe(0);
    });

    it('doesnt delete all the environment variables willy-nilly when feature flags are off', () => {
      pipeline.dataFlowType = 'REPLICATE';
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(false);

      component.ngOnInit();
      expect(component.visibleConnectionTypes.length).toBe(3);
      component.ngOnInit();
      expect(component.visibleConnectionTypes.length).toBe(3);
      component.ngOnInit();
      expect(component.visibleConnectionTypes.length).toBe(3);
    });
  });

  describe('returning connection target', () => {
    beforeEach(() => {
      const formGroup = component.connectionsForm.get('dataConnections') as FormGroup;
      formGroup.addControl('sourceConnection', new FormControl({ id: '1' }, Validators.required));
      formGroup.addControl('targetConnection', new FormControl({ id: '2' }, Validators.required));

      component.childComponentReference = { instance: {} } as ComponentRef<any>;
    });

    it('should include connection types', () => {
      expect(component.pipelineConnectionsObject.source.dataConnection.id).toBe('1');
      expect(component.pipelineConnectionsObject.target.dataConnection.id).toBe('2');
    });

    it('should call value changes subscripber', fakeAsync(() => {
      const connectionMock = {
        id: 1,
        connectionType: 'KAFKA',
        name: 'testConnection1'
      };

      component.selectTargetConnectionType(connectionMock);
      const dataConnection = component.connectionsForm.controls.dataConnections as FormGroup;
      dataConnection.controls.sourceConnection.setValue({});
      fixture.detectChanges();
      tick();
      fixture.whenStable().then(() => {
        expect(patchPipeline).toHaveBeenCalled();
      });
    }));
  });

  describe('connection list', () => {
    it('should remove SQLSERVER and DB2 connection type if feature flag for them are not enabled', () => {
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(false);
      component.ngOnInit();
      expect(component.visibleConnectionTypes.filter((connection) => connection.connectionType === 'SQLSERVER').length).toBe(0);
      expect(component.visibleConnectionTypes.filter((connection) => connection.connectionType === 'DB2').length).toBe(0);
    });

    it('should remove SCHEMAREGISTRY connection type if feature flag for them are not enabled', () => {
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(false);
      component.ngOnInit();
      expect(component.visibleTargetConnectionTypes.filter((connection) => connection.connectionType === 'SCHEMAREGISTRY').length).toBe(0);
    });
  });

  describe('loadTargetComponent', () => {
    it('makes expected calls', fakeAsync(() => {
      const componentFactoryResolverStub: ComponentFactoryResolver = fixture.debugElement.injector.get(ComponentFactoryResolver);
      spyOn(componentFactoryResolverStub, 'resolveComponentFactory').and.callThrough();

      component.targetConnectionType = 'KAFKA';
      component.ngOnInit();
      component.childComponentReference = { instance: {} } as ComponentRef<any>;

      component.createTargetChildComponent();
      tick();
      expect(componentFactoryResolverStub.resolveComponentFactory).toHaveBeenCalled();
    }));
  });

  describe('selectTargetConnectionType', () => {
    it('makes expected calls', () => {
      const connectionMock = {
        id: 1,
        connectionType: 'KAFKA',
        name: 'testConnection1'
      };
      spyOn(component, 'createTargetChildComponent');
      component.selectTargetConnectionType(connectionMock);
      expect(component.targetConnectionType).toBeDefined();
      expect(component.targetConnectionType).toEqual('KAFKA');
      expect(component.createTargetChildComponent).toHaveBeenCalled();
    });
  });

  it('should set the source connection type', () => {
    component.childComponentReference = { instance: {} } as ComponentRef<any>;
    component.selectSourceConnectionType({
      id: '1',
      connectionType: 'DB2I',
      name: 'testConnection1'
    });
    expect(component.childComponentReference.instance.sourceConnectionType).toBe('DB2I');
  });
});
