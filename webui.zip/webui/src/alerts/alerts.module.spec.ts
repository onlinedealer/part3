import { TestBed } from '@angular/core/testing';
import { AlertsModule } from './alerts.module';
import { Router, UrlTree } from '@angular/router';
import { AlertsFeatureFlagGuard } from '../shared/alerts-feature-flag.guard';

describe('AlertsModule', () => {
  const mockRouter = jasmine.createSpyObj(['navigateByUrl']);
  const mockGuard = jasmine.createSpyObj(['canActivate']);

  beforeEach(() => {
    mockRouter.routerState = {};
    TestBed.configureTestingModule({
      imports: [AlertsModule],
      providers: [
        { provide: AlertsFeatureFlagGuard, useValue: mockGuard },
        { provide: Router, useValue: mockRouter }
      ]
    });
  });

  it('initializes', () => {
    const module = TestBed.inject(AlertsModule);
    expect(module).toBeTruthy();
  });

  it('redirects if guard not passed', () => {
    mockGuard.canActivate.and.returnValue(new UrlTree());
    const module = TestBed.inject(AlertsModule);
    expect(mockRouter.navigateByUrl).toHaveBeenCalled();
  });
});
