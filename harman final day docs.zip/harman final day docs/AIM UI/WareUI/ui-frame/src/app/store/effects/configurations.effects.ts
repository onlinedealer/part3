import { Injectable, Inject, LOCALE_ID } from "@angular/core";
import { Actions, ofType, createEffect } from "@ngrx/effects";
import { map, mergeMap, tap, debounceTime, filter, withLatestFrom } from "rxjs/operators";
import { Store } from "@ngrx/store";
import { State } from "../reducers";

import { environment } from "../../../environments/environment";

import * as ConfigurationsActions from "../actions/configurations.actions";
import { LandisGyrAimConfigurationModel } from "../../../Shared/models/date-configuration.model";
import { UserSettingsService } from "../../services/user-settings.service";
import { LocaleRouterStateService } from "../../../Shared/services/locale-router-state.service";
import { UserSettingsActions } from "../actions";
import { ConfigurationsSelectors, UserSettingsSelectors } from "../selectors";
import { ChangeUiConfigurationSettingsPayload } from "../actions/configurations.actions";

@Injectable()
export class ConfigurationEffects {
    constructor(
        private actions$: Actions,
        private userSettingsService: UserSettingsService,
        private localeRouterService: LocaleRouterStateService,
        private store: Store<State>,
        @Inject(LandisGyrAimConfigurationModel) private config: LandisGyrAimConfigurationModel,
        @Inject(LOCALE_ID) private localeId: string
    ) {}

    loadWindowConfiguration$ = createEffect(() =>
        this.actions$.pipe(
            ofType(ConfigurationsActions.LoadWindowDefinedConfiguration),
            withLatestFrom(this.store.select(UserSettingsSelectors.getUserProfileSettings)),
            mergeMap(([action, userSetting]) => {
                const savedLanguage = userSetting && userSetting.userLocale ? userSetting.userLocale : "";
                const config = {
                    ...(userSetting as ChangeUiConfigurationSettingsPayload)
                };
                if (savedLanguage !== null && savedLanguage !== this.config.systemLocale) {
                    return [
                        ConfigurationsActions.LoadWindowDefinedConfigurationSuccess(config),
                        ConfigurationsActions.UIConfigurationNeedsLocaleRedirection({ newLocale: savedLanguage })
                    ];
                }
                return [ConfigurationsActions.LoadWindowDefinedConfigurationSuccess(config)];
            })
        )
    );

    windowConfigurationSuccess$ = createEffect(() =>
        this.actions$.pipe(
            ofType(ConfigurationsActions.LoadWindowDefinedConfigurationSuccess),
            map((payload) => {
                return ConfigurationsActions.SetDateFormat(payload);
            })
        )
    );

    windowConfigurationFail$ = createEffect(() =>
        this.actions$.pipe(
            ofType(ConfigurationsActions.LoadWindowDefinedConfigurationFailed),
            map(() => {
                return ConfigurationsActions.SetDateFormatsToStoreDefinedInitialValues();
            })
        )
    );

    userSettingsUpdated$ = createEffect(() =>
        this.actions$.pipe(
            ofType(UserSettingsActions.UpdateUserSettingsSuccess),
            withLatestFrom(this.store.select(ConfigurationsSelectors.getUIConfiguration)),
            map(([newSettings, oldSetting]) => {
                return {
                    settings: newSettings.userSettings,
                    savedLocale: oldSetting.userLocale,
                    wasDifferent: this.userSettingsService.isEqual(newSettings.userSettings, oldSetting)
                };
            }),
            map((newSettings) => {
                if (newSettings.settings && newSettings.settings.userLocale !== undefined) {
                    if (newSettings.savedLocale !== null && newSettings.settings.userLocale !== newSettings.savedLocale) {
                        return ConfigurationsActions.UIConfigurationNeedsLocaleRedirection({ newLocale: newSettings.settings.userLocale });
                    } else if (newSettings.savedLocale === null && newSettings.settings.userLocale !== this.config.systemLocale) {
                        return ConfigurationsActions.UIConfigurationNeedsLocaleRedirection({ newLocale: newSettings.settings.userLocale });
                    }
                }
                if (!newSettings.wasDifferent) {
                    return ConfigurationsActions.UIConfigurationNeedsWindowReload();
                }
                return ConfigurationsActions.UIConfigurationNeedsNoActions();
            })
        )
    );
    configurationNeedsWindowReload$ = createEffect(
        () =>
            this.actions$.pipe(
                ofType(ConfigurationsActions.UIConfigurationNeedsWindowReload),
                debounceTime(200),
                tap(() => {
                    this.localeRouterService.navigate({
                        shouldChange: true,
                        newUrl: this.localeRouterService.composeUrlPathForRedirectLocale(this.localeId)
                    });
                })
            ),
        { dispatch: false }
    );

    configurationNeedsLocalRedirection$ = createEffect(
        () =>
            this.actions$.pipe(
                ofType(ConfigurationsActions.UIConfigurationNeedsLocaleRedirection),
                filter((redirectData) => !!redirectData.newLocale),
                withLatestFrom(this.store.select(ConfigurationsSelectors.getUIConfiguration)),
                map(([redirectData, uiConfig]) => {
                    const storedLocale = uiConfig.userLocale ? uiConfig.userLocale : "";
                    const checkData = this.localeRouterService.determinateChangeData(redirectData.newLocale, storedLocale);
                    return checkData;
                }),
                filter((redirectData) => redirectData.shouldChange || !environment.production),
                filter((redirectData) => redirectData.shouldChange),
                debounceTime(1000),
                tap((redirectData) => {
                    this.localeRouterService.navigate({
                        shouldChange: redirectData.shouldChange,
                        newUrl: redirectData.urlRedirect
                    });
                })
            ),
        { dispatch: false }
    );

    // ngrxOnInitEffects() {
    //     // Do init
    //     return ConfigurationsActions.LoadWindowDefinedConfiguration();
    // }
}
