import { Component } from "@angular/core";

@Component({
    selector: "landisgyr-meteringpoints-results-header",
    templateUrl: "./meteringpoints-resultsheader.component.html",
    styleUrls: ["./meteringpoints-resultsheader.component.scss"]
})
export class MeteringpointsResultsHeaderComponent {}
