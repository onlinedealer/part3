import { HttpErrorResponse } from '@angular/common/http';
import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Clipboard } from '@angular/cdk/clipboard';
import { CatalogingErrorSidebarComponent } from './cataloging-error-sidebar.component';
import { MockSidebarComponent } from '@shared/components/sidebar/mock-sidebar.component.spec';

describe('CatalogingErrorSidebarComponent', () => {
  let component: CatalogingErrorSidebarComponent;
  let fixture: ComponentFixture<CatalogingErrorSidebarComponent>;
  let clipboard: Clipboard;
  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CatalogingErrorSidebarComponent, MockSidebarComponent]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CatalogingErrorSidebarComponent);
    component = fixture.componentInstance;
    clipboard = TestBed.inject(Clipboard);
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should call function to open the sidebar component', () => {
    spyOn(component.sidebarComponent, 'open').and.returnValue();
    component.open([{}] as HttpErrorResponse[]);
    expect(component.errorMessage).toBeTruthy();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
    expect(component.displayErrorType).toBe(true);
  });

  it('should call function to close the sidebar component', () => {
    spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.close();
    expect(component.errorMessage.length).toEqual(0);
    expect(component.sidebarComponent.close).toHaveBeenCalled();
    expect(component.displayErrorType).toBe(false);
  });

  it('should call function to open the sidebar component with error that contains inner error message', () => {
    spyOn(component.sidebarComponent, 'open').and.returnValue();
    const error = { status: 2, statusText: 'correct' };
    const httpErrorResponse = new HttpErrorResponse({
      error: error,
      status: 1
    });
    component.open([httpErrorResponse]);
    expect(component.errorMessage[0].status).toEqual(2);
  });
});
