import { AfterViewInit, ChangeDetectorRef, Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../shared/connection';
import { BaseConnectionFormComponent } from '../base-connection-form/base-connection-form.component';
import { Server } from '../../../../servers/shared/server';
import { BaseConnectionForm } from '../base-connection-form/base-connection-form';

/**
 * Connection parmaeters for the schema registry connection
 */
export enum SCHEMA_CONNECTION_PARAMETERS {
  SCHEMA_REGISTRY_TYPE = 'SCHEMA_REGISTRY_TYPE',
  SCHEMA_REGISTRY_CONFIG_FILE_PATH = 'SCHEMA_REGISTRY_CONFIG_FILE_PATH'
}

/**
 * The Schema registry connection child form
 */
@Component({
  selector: 'p-connect-schema-registry-form',
  templateUrl: './schema-registry-form.component.html'
})
export class SchemaRegistryFormComponent
  extends BaseConnectionFormComponent
  implements OnInit, OnDestroy, AfterViewInit, BaseConnectionForm
{
  /**
   * Selected Runtime Server
   */
  @Input() selectedRuntimeServer: Server;

  /**
   * form group
   */
  schemaRegistryFormGroup: FormGroup;

  /**
   * Enable schema registry vendor list dropdown options
   */
  vendorListOptions: { label: string; value: string }[] = [{ label: 'Confluent', value: 'CONFLUENT' }];

  constructor(private readonly controlContainer: ControlContainer, private readonly changeDetectorRef: ChangeDetectorRef) {
    super();
  }

  ngAfterViewInit(): void {
    this.changeDetectorRef.detectChanges();
  }

  ngOnDestroy(): void {
    this.removeChildFormControls(this.schemaRegistryFormGroup);
  }

  ngOnInit(): void {
    this.createForm();
  }

  /**
   * Returns a connection object from the form controls
   * @param isTesting flag for whether we are testing or saving/updating the connection
   */
  getConnection(isTesting: boolean): Connection {
    const connection = {} as Connection;
    connection.database = this.schemaRegistryFormGroup.get('schemaRegistryUrl').value;
    connection.parameters = [
      {
        key: SCHEMA_CONNECTION_PARAMETERS.SCHEMA_REGISTRY_TYPE,
        value: this.schemaRegistryFormGroup.get('schemaRegistryVendor').value
      },
      {
        key: SCHEMA_CONNECTION_PARAMETERS.SCHEMA_REGISTRY_CONFIG_FILE_PATH,
        value: this.schemaRegistryFormGroup.get('schemaRegistryConfig').value
      }
    ];
    return connection;
  }

  /**
   * Responsible for setting the connection form from a passed in connection object
   */
  set connection(connection: Connection) {
    this.schemaRegistryFormGroup.patchValue({
      database: connection.database,
      schemaRegistryVendor: this.getParameterValue(connection.parameters, SCHEMA_CONNECTION_PARAMETERS.SCHEMA_REGISTRY_TYPE),
      schemaRegistryConfig: this.getParameterValue(connection.parameters, SCHEMA_CONNECTION_PARAMETERS.SCHEMA_REGISTRY_CONFIG_FILE_PATH),
      schemaRegistryUrl: connection.database
    });
  }

  createForm(): void {
    this.schemaRegistryFormGroup = this.controlContainer.control as FormGroup;
    this.schemaRegistryFormGroup.addControl('database', new FormControl(false));
    this.schemaRegistryFormGroup.addControl('schemaRegistryVendor', new FormControl('CONFLUENT', Validators.required));
    this.schemaRegistryFormGroup.addControl('schemaRegistryUrl', new FormControl('', Validators.required));
    this.schemaRegistryFormGroup.addControl('schemaRegistryConfig', new FormControl(''));
  }
}
