# SLO Document

_This document describes the SLOs for **Connect SaaS API Service**._

https://sre.google/workbook/implementing-slos/

## Service Overview

The _Connect Portal UI_ is a web application within the DI suite that provides the ability to create replication pipelines to move data between data sources.

The SLO uses a **28 day** rolling window.

## Service Dependencies

The _Connect Portal UI_ depends on below downstream services. Our success and latency objectives are coupled to the specific SLO's advertised by these services. As of the writing of this document:

1. **Authentication Service:**

   1. We must renew internal tokens on each request, which is a per-request tax.
      - Internal-Auth Success 99.9% (_To be clarified_)
      - Internal-Auth Latency 100ms @ 99% (_To be clarified_)

2. **Shared SaaS Agent Service:**
   1. We must query the features service to determine if a request is permitted, which is a per-request tax.
      - Success 99.9% (_To be clarified_)
      - Latency 50ms @ 99% (_To be clarified_)
3. **Connect on-prem Services:**

   1. This includes all the on-premise services that are listed below
      - Connect Gateway
      - Connect Job-Controller
      - CDC

4. **Connect SaaS API Service**

# SLIs and SLOs

<table>
<tr><th>Category</th><th>SLI</th><th>SLO</th><th>API Details</th></tr>

<tr><td colspan=3>HTTP server</td></tr>
<tr>
<td>Success</td>
<td>
The proportion of successful requests, as measured from the load balancer metrics.

Any HTTP status other than 500–599 is considered successful.

<pre>
count of "web" http_requests which
do not have a 5XX status code
divided by
count of all "web" http_requests
</pre>
</td>
<td>90%</td>
<td>
/*
</td>
</tr>

<tr>
<td>Latency</td>
<td>
The proportion of sufficiently fast requests, as measured from the load balancer metrics.

“Sufficiently fast” is defined as < 200 ms, or < 1,000 ms.

<pre>
count of "web" http_requests with
a duration less than or equal to
"0.2" seconds
divided by
count of all "web" http_requests
</pre>

<pre>
count of "web" http_requests with
a duration less than or equal to
"1.0" seconds
divided by
count of all "web" http_requests
</pre>
</td>
<td>90% of requests < 200 ms</td>
</tr>
<tr><td colspan="3">Score pipeline</td></tr>
<tr>
<td>Freshness</td>
<td>The proportion of records read from the monitoring table that were updated recently.

“Recently” is defined as within 1 minute, or within 5 minutes.
Uses metrics from the API and HTTP server:

<pre>
count of all monitoring data_requests for
"api" and "web" with freshness
less than or equal to 1 minute
divided by
count of all data_requests
</pre>

<pre>
count of all monitoring data_requests for
"api" and "web" with freshness
less than or equal to 5 minutes
divided by
count of all data_requests
</pre>
</td>
<td>
90% of reads use data written within the previous 1 minute.

99% of reads use data written within the previous 5 minutes.

</td>
<td>
/api/v1/cdc/monitoring/status
/api/v1/cdc/monitoring/{id}/alerts
/api/v1/monitoring/alerts/import
/api/v1/monitoring/projects/import
</td>
</tr>
<tr>
<td>Correctness</td>
<td>
The proportion of records injected into the monitoring table by a correctness prober that result in the correct data being read from the monitoring table.

A correctness prober injects synthetic data, with known correct outcomes, and exports a success metric:

<pre>
count of all monitoring data_requests which
were correct
divided by
count of all data_requests
</pre>
</td>
<td>99.99999% of records injected by the prober result in the correct output.</td>
<td>
/api/v1/cdc/monitoring/status
/api/v1/cdc/monitoring/{id}/alerts
/api/v1/monitoring/alerts/import
/api/v1/monitoring/projects/import
</td>
</tr>
<tr>
<td>Completeness</td>
<td> N/A, the service does not process any records </td>
<td>N/A</td><td>N/A</td></tr>
</table>

## Rationale

Availability and latency SLIs were based on measurement over the period 2022-04-01 to 2022-04-28. Availability SLOs were rounded down to the nearest 1% and latency SLO timings were rounded up to the nearest 50 ms. All other numbers were picked by the author and the services were verified to be running at or above those levels.

No attempt has yet been made to verify that these numbers correlate strongly with user experience. <sup name="a1">[1](#f1)</sup>

## Error Budget

Each objective has a separate error budget, defined as 100% minus (–) the goal for that objective. For example, if there have been 1,000,000 requests to the API server in the previous four weeks, the API availability error budget is 3% (100% – 97%) of 1,000,000: 30,000 errors.

We will enact the [error budget policy](error-budget.md) when any of our objectives has exhausted its error budget.

## Clarifications and Caveats

- Request metrics are measured at the load balancer. This measurement may fail to accurately measure cases where user requests didn't reach the load balancer.
- We only count HTTP 5XX status messages as error codes; everything else is counted as success.
- The test data used by the correctness prober contains approximately 200 tests, which are injected every 1s. Our error budget is 48 errors every four weeks.

---

<b id="f1">1</b> Even if the numbers in the SLO are not strongly evidence-based, it is necessary to document this so that future readers can understand this fact, and make their decisions appropriately. They may decide that it is worth the investment to collect more evidence. As we advance our Observability strategy, we strongly recommend you instrument and review jaeger traces from your service to observe the service behaviour inside an actual user flow in our system.
