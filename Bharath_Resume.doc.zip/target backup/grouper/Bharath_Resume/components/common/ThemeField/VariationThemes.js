import React from 'react'
import ThemeFieldUpdate from './ThemeFieldUpdate'
import * as Constants from '../Utils/Constants'
import FormHelperText from '@material-ui/core/FormHelperText'

export class VariationThemes extends React.Component {
  constructor (props) {
    super(props)

    let themes = {
      theme1: {
        id: '',
        fixed_theme_id: '',
      },
    }
    if (props.groupDetails) {
      props.groupDetails.themes.map((theme, i) => {
        themes[`theme${i + 1}`] = {
          id: theme.id,
          fixed_theme_id: theme.fixed_theme_id,
        }
      })
    }

    this.state = {
      formData: {
        themes,
      },
      errors: {
        themes: '',
      },
    }
  }

    handleSelectChange = (name, value) => {
      const themeRow = name.split('-')
      const formData = { ...this.state.formData }
      const errors = { ...this.state.errors }
      /* if (name === 'group_type') {
          formData.group_type = value
          errors.group_type = ''
        } else if (name === 'item_type') {
          formData.item_type = value
          errors.item_type = ''
          formData.themes = {
            theme1: '',
          }
          if (value) {
            this.props.getItemThemes(value)
          } else {
            this.props.clearItemThemes()
          }
          this.setState({ themesFieldsCount: 1 })
        } else if (name && name.indexOf('theme') !== -1) { */
      let isError = false
      for (let i = 1; i <= Object.keys(formData.themes).length; i++) {
        // error for themes
        if (value && (`theme${i}` !== themeRow[0]) && (formData.themes[`theme${i}`][themeRow[1]] === value)) {
          if (themeRow[0] === 'theme1') {
            errors.theme1 = Constants.ERROR_THEME_EXIST
          } else {
            errors.themes = Constants.ERROR_THEME_EXIST
          }
          isError = true
        }
      }
      if (!isError || !value) {
        formData.themes[themeRow[0]][themeRow[1]] = value
        errors.themes = ''
        if (value && name === 'theme1') {
          errors.theme1 = ''
        }
      }
      // }
      this.setState({ formData, errors })
      this.props.onHandleChange('themes', formData.themes)
    }

    addThemesField = () => {
      const formData = { ...this.state.formData }
      for (let i = 2; i <= Constants.THEME_MAX_COUNT; i++) {
        if (typeof formData.themes[`theme${i}`] === 'undefined') {
          formData.themes[`theme${i}`] = {
            id: '',
            fixed_theme_id: '',
          }
          this.setState({ formData })
          this.props.onHandleChange('themes', formData.themes)
          break
        }
      }
    }

      /* removeThemesField = (id) => {
        const formData = { ...this.state.formData }
        delete formData.themes[id]
        this.setState({ formData })
      } */
      removeThemesField = (id) => {
        const formData = { ...this.state.formData }
        const errors = { ...this.state.errors }
        const themeLength = Object.keys(formData.themes).length
        if (themeLength === 1) {
          errors.theme1 = Constants.ERROR_THEME_REQ
          this.setState({ errors })
        } else {
          // delete formData.themes[id]
          let newThemeData = {}
          let count = 1
          for (let i = 1; i <= Object.keys(this.state.formData.themes).length; i++) {
            if (`theme${i}` !== id) {
              newThemeData[`theme${count}`] = formData.themes[`theme${i}`]
              count++
            }
          }
          formData.themes = newThemeData
          this.setState({ formData })
          this.props.onHandleChange('themes', formData.themes)
        }
      }

      moveTheme = (pos, id) => {
        const formData = { ...this.state.formData }
        let checkData = formData.themes
        for (let property in formData.themes) {
          let curIndex = parseInt(property.substring(6, 5))
          let tempValue = ''
          let prevIndex = ''
          let nextIndex = ''
          if (formData.themes[property].id === id && pos === 'Up') {
            tempValue = formData.themes[`theme${curIndex}`]
            prevIndex = curIndex - 1
            checkData[`theme${curIndex}`] = formData.themes[`theme${prevIndex}`]
            checkData[`theme${prevIndex}`] = tempValue
            break
          } else if (formData.themes[property].id === id && pos === 'Down') {
            tempValue = formData.themes[`theme${curIndex}`]
            nextIndex = curIndex + 1
            checkData[`theme${curIndex}`] = formData.themes[`theme${nextIndex}`]
            checkData[`theme${nextIndex}`] = tempValue
            break
          }
        }
        formData.themes = checkData
        this.setState({ formData })
        this.props.onHandleChange('themes', formData.themes)
      }

      render () {
        const { classes, itemThemes, fixedThemes } = this.props
        const { formData, errors } = this.state
        let themesRows = []
        let count = 1
        for (let property in formData.themes) {
          let firstNode = false
          let lastNode = false
          // const curTheme = _.find(groupDetails.themes, (n) => { return n.id === formData.themes[property]})
          let isAddRequired = false
          if (property === 'theme1') {
            for (let i = 2; i <= Constants.THEME_MAX_COUNT; i++) {
              if (typeof formData.themes[`theme${i}`] === 'undefined') {
                isAddRequired = true
                break
              }
            }
          }
          // const isRemoveRequired = property !== 'theme1'
          const isRemoveRequired = Object.keys(formData.themes).length !== 1
          const placeholder = (property === 'theme1') ? `Theme*` : `Theme`
          const fixedThemePlaceholder = (property === 'theme1') ? `Fixed theme*` : `Fixed theme`
          if (count === 1 && Object.keys(formData.themes).length === 1) {
            firstNode = true
            lastNode = true
          } else if (count === 1 && Object.keys(formData.themes).length > 1) {
            firstNode = true
          } else if (count > 1 && Object.keys(formData.themes).length === count) {
            lastNode = true
          }

          themesRows.push(
            <ThemeFieldUpdate
              key={property}
              id={property}
              errors={errors}
              curTheme={count}
              firstNode={firstNode}
              lastNode={lastNode}
              value={formData.themes[property].id}
              fixedValue={formData.themes[property].fixed_theme_id}
              placeholder={placeholder}
              handleSelectChange={this.handleSelectChange}
              themes={itemThemes}
              inputType={(isRemoveRequired) ? 2 : 1}
              isAddRequired={isAddRequired}
              isRemoveRequired={isRemoveRequired}
              classes={classes}
              addThemesField={this.addThemesField}
              removeThemesField={this.removeThemesField}
              moveTheme={this.moveTheme}
              fixedThemes={fixedThemes}
              fixedThemePlaceholder={fixedThemePlaceholder}
            />)
          count++
        }
        return (
          <div className={classes.themeRow}>
            {themesRows}
            {(errors.themes) && <FormHelperText error>{errors.themes}</FormHelperText>}
          </div>
        )
      }
}

export default VariationThemes
