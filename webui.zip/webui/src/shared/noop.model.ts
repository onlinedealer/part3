/**
 * No operation function.
 */
export const noop = () => {
  // this is intentional
};
