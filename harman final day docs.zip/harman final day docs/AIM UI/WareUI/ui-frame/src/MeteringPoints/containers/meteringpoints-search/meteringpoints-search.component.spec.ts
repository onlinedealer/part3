import { ComponentFixture, TestBed } from "@angular/core/testing";

import { MeteringpointsSearchContainerComponent } from "./meteringpoints-search.component";

import { DebugElement, NO_ERRORS_SCHEMA } from "@angular/core";
import { MockComponent, MockProvider, ngMocks } from "ng-mocks";
import { MeteringpointsSearchMainInputComponent } from "../../components/meteringpoints-search/main-input/mp-search-main-input.component";
import { MeteringpointsSearchXSFFormComponent } from "../../components/meteringpoints-search/xsf-search-form/mp-search-xsf-form.component";
import { provideMockStore, MockStore } from "@ngrx/store/testing";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { XSFSearchOverlayService } from "../../../Shared/modules/xsf-search-overlay";
import { setInjector } from "../../../app/app-injector";
import { getMainInputValue } from "../../store/selectors/xsf-search.selectors";
import { XSFSearchActions } from "../../store/actions";

describe("MeteringpointsSearchContainerComponent", () => {
    let component: MeteringpointsSearchContainerComponent;
    let fixture: ComponentFixture<MeteringpointsSearchContainerComponent>;
    let element: DebugElement;
    let store: MockStore<MeteringPointsFeatureState>;

    beforeEach(async () => {
        await TestBed.configureTestingModule({
            declarations: [
                MeteringpointsSearchContainerComponent,
                MockComponent(MeteringpointsSearchMainInputComponent),
                MockComponent(MeteringpointsSearchXSFFormComponent),
            ],
            providers: [
                provideMockStore({
                    initialState: {
                        meteringPointsFeature: {}
                    }
                }),
                MockProvider(XSFSearchOverlayService)
            ],
            schemas: [NO_ERRORS_SCHEMA]
        }).compileComponents();
        setInjector(TestBed);
        store = TestBed.inject(MockStore);
    });

    beforeEach(() => {
        fixture = TestBed.createComponent(MeteringpointsSearchContainerComponent);
        component = fixture.componentInstance;
        element = fixture.debugElement;
    });

    afterEach(() => {
        fixture.destroy();
    });

    describe("Main input", () => {
        it("should set main input from store", () => {
            getMainInputValue.setResult("MP123456");
            fixture.detectChanges();
            const mainInput = ngMocks.find(MeteringpointsSearchMainInputComponent);
            expect(mainInput.componentInstance.mainInputValueInStore).toEqual("MP123456");
        });

        it("should dispatch search", () => {
            spyOn(store, "dispatch");
            fixture.detectChanges();

            const mainInput = ngMocks.find(MeteringpointsSearchMainInputComponent);
            mainInput.componentInstance.mainInputValue.emit("MP234567");
            fixture.detectChanges();
            expect(store.dispatch).toHaveBeenCalledTimes(1);
            expect(store.dispatch).toHaveBeenCalledWith(XSFSearchActions.SearchByMainInputField({ value: "MP234567" }));
        });

        it("should clear input", () => {
            spyOn(store, "dispatch");
            getMainInputValue.setResult("MP123456");
            fixture.detectChanges();

            const mainInput = ngMocks.find(MeteringpointsSearchMainInputComponent);
            mainInput.componentInstance.mainInputValue.emit("");
            fixture.detectChanges();
            expect(store.dispatch).toHaveBeenCalledTimes(1);
            expect(store.dispatch).toHaveBeenCalledWith(XSFSearchActions.ClearMainInputFieldValue());
        });
    });
});
