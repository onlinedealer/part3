import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslocoService } from '@ngneat/transloco';
import { SecondaryNavItemsService } from 'discovery-shared';
import { ObserverListModel } from 'observer/observer-listing/observer-list.model';
import { ObserverService } from 'observer/observer.service';
import { MenuItem } from 'primeng/api';

@Component({
  selector: 'discovery-observer-detail-view',
  templateUrl: './observer-detail-view.component.html',
  styleUrls: ['./observer-detail-view.component.scss']
})
export class ObserverDetailViewComponent implements OnInit {
  observerName: string;
  observerId: string;
  profileId: string;
  runId: string;
  selectedTabIndex: number = 0;
  /**
   * menu items for secondary navigation left sliding menu
   */
  navItems: MenuItem[];

  constructor(
    private translocoService: TranslocoService,
    public activatedRoute: ActivatedRoute,
    public router: Router,
    private navItemsService: SecondaryNavItemsService,
    private observerService: ObserverService
  ) {}

  ngOnInit(): void {
    this.observerName = this.activatedRoute.snapshot.paramMap.get('observerName');
    this.observerId = this.activatedRoute.snapshot.paramMap.get('observerId');
    this.navItems = this.navItemsService?.getNavItems();
    this.runId = this.activatedRoute.snapshot.queryParams.runId;
    //on profile tab and page refresh we will loose profileId variable as profileId is part of Url as param in that case so added below if case
    // on alert page profile id will be in query param and on profile tab profile id will be as param in URL
    this.profileId = this.activatedRoute.snapshot.queryParams.profileId
      ? this.activatedRoute.snapshot.queryParams.profileId
      : this.activatedRoute.firstChild.snapshot.params.profileId;
    this.routeBasedSelectTabs();
    this.getLastRunData();
  }

  routeBasedSelectTabs() {
    this.selectedTabIndex = this.activatedRoute.children[0].snapshot.data.tabIndex;
  }

  getLastRunData() {
    if (this.observerId && this.selectedTabIndex === 1 && !this.runId) {
      this.observerService.getObserver(this.observerId).subscribe({
        next: (response: ObserverListModel) => {
          if (response?.lastProfileRunDetails) {
            this.runId = response?.lastProfileRunDetails?.runId;
            this.router.navigate([`profile/${this.profileId}`], {
              queryParams: {
                runId: this.runId
              },
              relativeTo: this.activatedRoute
            });
          }
        }
      });
    }
  }

  onChange(event) {
    this.selectedTabIndex = event.index;
    if (this.selectedTabIndex === 1) {
      if (!this.runId) {
        this.getLastRunData();
      } else {
        this.router.navigate([`profile/${this.profileId}`], {
          queryParams: {
            runId: this.runId
          },
          relativeTo: this.activatedRoute
        });
      }
    } else {
      this.router.navigate(['alerts'], {
        queryParams: {
          profileId: this.profileId,
          runId: this.runId
        },
        relativeTo: this.activatedRoute
      });
    }
  }

  onEditClick() {
    this.router.navigateByUrl('/data-observability/observers/edit/' + this.observerId);
  }
}
