(function () {
    'use strict';

    angular.module('arm').controller('contactListCtrl', ['$scope', '$state', '$filter', '$ionicLoading', 'contactService', 'utility', '$ionicScrollDelegate', '$timeout', '$q', '$ionicPopover', '$ionicModal', '$ionicSideMenuDelegate', 'activityService', 'GENERAL_CONFIG', 'MASTER_TABLE', 'homeService', '$rootScope', contactController]);

    function contactController($scope, $state, $filter, $ionicLoading, contactService, utility, $ionicScrollDelegate, $timeout, $q, $ionicPopover, $ionicModal, $ionicSideMenuDelegate, activityService, GENERAL_CONFIG, MASTER_TABLE, homeService, $rootScope) {
        // page title
        $scope.title= "Contacts";
        $scope.objFilter = {search: ''};
        $scope.selectedTier =  {ContactTierID:[1]};
        /*$scope.FilterOptions = [
                         {
                             Title: "Client Type",
                             FilterData: [
                                 { ID: 1, Text: "Leads", Checked: true },
                                 { ID: 2, Text: "Clients", Checked: true }
                             ]
                         },
                         {
                             Title: "Tier",
                             FilterData: [
                                 { ID: 1, Text: "Tier 1", Checked: true },
                                 { ID: 2, Text: "Tier 2", Checked: true },
                                 { ID: 3, Text: "Tier 3", Checked: true },
                                 { ID: 4, Text: "Tier 4", Checked: true }
                             ]
                         },
                         {
                             Title: "Status",
                             FilterData: [
                                 { ID: 1, Text: "Overdue", Checked: true },
                                 { ID: 2, Text: "Due", Checked: true },
                                 { ID: 3, Text: "Not Yet Due", Checked: true },
                                 { ID: 4, Text: "Done", Checked: true }
                             ]
                         }
                ];*/

        //===============================Code Added by NiTiN========================================
         $scope.$on( "$ionicView.beforeEnter", function() {
             if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("deviceready", onDeviceReady, false);
             }
            loadData();
         });

         function loadData(){
            busyCursorStart();
            $scope.showContacts = true; $scope.showCompany = false;
            $scope.IndividualContactList = []; $scope.CompanyContactList = []; $scope.RepresentativesContactList = [];
            $scope.contactTypeInd = contactService.constants().contactType.Individual;
            $scope.contactTypeCom = contactService.constants().contactType.Company;
            $scope.isIndividualFetchRunning = true;
            $scope.isCompanyFetchRunning = true;

            contactService.sqlContGetAll($scope.contactTypeInd, false).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var individualObjList = contactService.models().contactModel;
                    individualObjList = utility.syncModelWithCollection(result.rows.item(i),individualObjList);
                    individualObjList.Priority = utility.getColorCodeForContact(individualObjList.NextContactedDate);
                    $scope.IndividualContactList.push(individualObjList);
                }
                $scope.isIndividualFetchRunning = false;
                hideLoader();
            });
            contactService.sqlContGetAll($scope.contactTypeCom, false).then(function (result) {
                for (var i = 0; i < result.rows.length; i++) {
                    var companyObjList = contactService.models().contactModel;
                    companyObjList = utility.syncModelWithCollection(result.rows.item(i),companyObjList);
                    utility.sqlGetAllRepresentativeDetails(companyObjList).then(function (result) {
                        var companyObj = result[0];
                        for (var j = 0; j < result[1].rows.length; j++) {
                            var repObjList = contactService.models().contactModel;
                            repObjList = utility.syncModelWithCollection(result[1].rows.item(j),repObjList);
                            repObjList.Priority = utility.getColorCodeForContact(repObjList.NextContactedDate);
                            companyObj.Representatives.push(repObjList);
                        }
                    });
                    $scope.CompanyContactList.push(companyObjList);
                  }
                  $scope.isCompanyFetchRunning = false;
                  hideLoader();
            });
         }
       
        function hideLoader()
        {
            if ($scope.isIndividualFetchRunning == false && $scope.isCompanyFetchRunning == false) {
              busyCursorEnd();
            }
        }
        $scope.searchfooterfocus = function () {
            angular.element(document.querySelector('body')).addClass('footer-tab-hide');
        }

        $scope.searchfooterblurred = function () {
            angular.element(document.querySelector('body')).removeClass('footer-tab-hide');
        }

        //===============================Code Added by NiTiN========================================
        $scope.contactTypeInfo = contactService.constants().contactType;
        $scope.contactShow = function(type) {
      		if(type=="Individual"){
                $scope.showContacts = true;
                $scope.showCompany = false;
            }else if(type=="Company"){
                $scope.showContacts = false;
                $scope.showCompany = true;
            }
      	};
        $scope.toggleGroup = function(group) {
            group.show = !group.show;
        };
        $scope.isGroupShown = function(group) {
            return group.show;
        };
        $scope.getNameValue = function(item) {
            return utility.getNameByOrOwner(item);
      	};
      	function busyCursorStart() {
            $ionicLoading.show({
                template: 'Loading...'
            });
        };

        function busyCursorEnd() {
            $ionicLoading.hide();
        };
        $scope.displayEmployerName = function(item) {
            var employerName = "";
            if(item.IsRepresentative== false){
                employerName = item.EmployerName;
            }else{
                employerName = item.CompanyName;
            }
            return employerName;
        };
        $scope.openMenu = function () {
            $ionicSideMenuDelegate.toggleLeft();
        }

        $scope.doRefresh = function (requestType) {
            busyCursorStart();
            contactService.getContactList(requestType).then(function (res) {
                syncServerRecords(res,requestType);
            },
            function (err) {
                 $scope.errorMessage = err;
                 busyCursorEnd();
            });
        };
        function syncServerRecords(serverResponse,requestType){
            $scope.contactType = contactService.constants().contactType;
            $scope.contactRelationTypes = contactService.constants().relationTypes;
            var totalRecordLength = serverResponse.length;
            var saveRecord = 0;
            if(saveRecord == totalRecordLength){
                if(requestType == "Next"){
                    $scope.$broadcast('scroll.refreshComplete');
                }
                loadData();
                busyCursorEnd();
             }
            angular.forEach(serverResponse, function (responseObj) {
                 // This condition for the Individual Contact List
                 if(responseObj.ContactTypeID == $scope.contactType.Individual){
                    var existedRecord = $filter('filter')($scope.IndividualContactList, {DeviceObjID: responseObj.DeviceObjID});
                    if(existedRecord.length == 0){
                        var createNewContactObjModel = contactService.models().contactModel;
                        utility.syncModelWithoutInnerCollection(responseObj,createNewContactObjModel);
                        if(createNewContactObjModel.IsRepresentative == false){
                            createNewContactObjModel.Priority = utility.getColorCodeForContact(createNewContactObjModel.NextContactedDate);
                            $scope.IndividualContactList.push(createNewContactObjModel);
                            // add the obj in model and SQLight DB
                            contactService.addContactToSql(responseObj,null).then(function (result) {
                            }, function (error) {  });
                        }else{
                            var relMappingArray = responseObj.ContactRelationshipMappings;
                            var relatedRelationArr = $filter('filter')(relMappingArray, {ContactRelationshipTypeID: $scope.contactRelationTypes.RepresentativeOf});
                            angular.forEach(relatedRelationArr, function(relationMap){
                                var existingCompany = $filter('filter')($scope.CompanyContactList, {DeviceObjID: relationMap.RelationshipWithContactDeviceObjID});
                                if(existingCompany.length > 0){
                                    var existingCompanyRep = $filter('filter')(existingCompany[0].Representatives, {DeviceObjID: responseObj.DeviceObjID});
                                    if(existingCompanyRep.length == 0){
                                        createNewContactObjModel.Priority = utility.getColorCodeForContact(createNewContactObjModel.NextContactedDate);
                                        existingCompany[0].Representatives.push(createNewContactObjModel);
                                        // add the obj in model and SQLight DB
                                        contactService.addContactToSql(responseObj,null).then(function (result) {
                                        }, function (error) {  });
                                    }else{
                                        utility.syncModelWithCollection(createNewContactObjModel,existingCompanyRep[0]);
                                        updateIndividualContact(existingCompanyRep[0],responseObj);
                                    }
                                }else{
                                    // add the obj in model and SQLight DB
                                    contactService.addContactToSql(responseObj,null).then(function (result) {
                                    }, function (error) {  });
                                }
                            });
                        }
                    }else{
                        // update the obj in model and SQLight DB
                        utility.syncModelWithoutInnerCollection(responseObj,existedRecord[0]);
                        updateIndividualContact(existedRecord[0],responseObj);
                    }
                 }else{
                     // This condition for the Company Contact List
                    var existedRecord = $filter('filter')($scope.CompanyContactList, {DeviceObjID: responseObj.DeviceObjID});
                    //if(existedRecord == null || existedRecord == ""){
                     if(existedRecord.length == 0){
                        var createNewContactObjModel = contactService.models().contactModel;
                        utility.syncModelWithoutInnerCollection(responseObj,createNewContactObjModel);

                        if(createNewContactObjModel.IsEmployer == false){
                             setTimeout(function(){
                                utility.sqlGetAllRepresentativeDetails(createNewContactObjModel).then(function (result) {
                                     var companyObj = result[0];
                                     for (var j = 0; j < result[1].rows.length; j++) {
                                         var repObjList = contactService.models().contactModel;
                                         repObjList = utility.syncModelWithCollection(result[1].rows.item(j),repObjList);
                                         repObjList.Priority = utility.getColorCodeForContact(repObjList.NextContactedDate);
                                         var existingCompanyRep2 = $filter('filter')(companyObj.Representatives, {DeviceObjID: repObjList.DeviceObjID});
                                         if(existingCompanyRep2.length == 0)
                                            companyObj.Representatives.push(repObjList);
                                     }
                                });
                             }, 1);

                             $scope.CompanyContactList.push(createNewContactObjModel);
                        }
                        // add the obj in model and SQLight DB
                        contactService.addContactToSql(null,responseObj).then(function (result) {
                        }, function (error) {  });

                    }else{
                        // update the obj in model and SQLight DB
                        utility.syncModelWithoutInnerCollection(responseObj,existedRecord[0]);
                        // Assign the sub child model for communication
                        if(responseObj.Communications.length > 0){
                            existedRecord[0].Communications = responseObj.Communications;
                        }else{
                            existedRecord[0].Communications = [];
                            contactService.bindCommunicationEmptyModel(existedRecord[0]);
                        }
                        // Assign the sub child model for correspondences
                        if(responseObj.Correspondences.length > 0){
                            existedRecord[0].Correspondences = responseObj.Correspondences;
                        }else{
                            existedRecord[0].Correspondences = [];
                            contactService.bindCorrespondencesEmptyModel(existedRecord[0]);
                        }
                        // Assign the sub child model for Contact Relationship Mappings
                        if(responseObj.ContactRelationshipMappings.length > 0){
                            existedRecord[0].ContactRelationshipMappings = responseObj.ContactRelationshipMappings;
                        }else{
                            existedRecord[0].ContactRelationshipMappings = [];
                        }
                        // Assign the sub child model for Contact User Mappings
                        if(responseObj.ContactUserMappings.length > 0){
                            existedRecord[0].ContactUserMappings = responseObj.ContactUserMappings;
                        }else{
                            existedRecord[0].ContactUserMappings = [];
                        }
                        // Assign the sub child model for Attachments
                        if(responseObj.Attachments.length > 0){
                            existedRecord[0].Attachments = responseObj.Attachments;
                        }else{
                            existedRecord[0].Attachments = [];
                        }
                         // Assign the sub child model for Notes
                        if(responseObj.Notes.length > 0){
                            existedRecord[0].Notes = responseObj.Notes;
                        }else{
                            existedRecord[0].Notes = [];
                        }
                        // Assign the sub child model for Dynamic Fields
                        if(responseObj.Fields.length > 0){
                            if(existedRecord[0].Fields.length > 0){
                                angular.forEach(responseObj.Fields, function (resFieldsObj, index) {
                                    var existedField = $filter('filter')(existedRecord[0].Fields, {FieldName: responseObj.FieldName});
                                    if(existedField != null || existedField != ""){
                                        utility.syncModelWithCollection(resFieldsObj,existedField);
                                    }
                                });
                            }
                        }else{
                            existedRecord[0].Fields = [];
                            contactService.bindFieldsEmptyModel(existedRecord[0]);
                        }
                        contactService.updateContactToSql(null,existedRecord[0]).then(function (result) {
                        }, function (error) {  });
                    }
                 }
                 saveRecord++;
                 if(saveRecord == totalRecordLength){
                    if(requestType == "Next"){
                        $scope.$broadcast('scroll.refreshComplete');
                    }
                    loadData();
                    busyCursorEnd();
                 }
            });
        };

        function updateIndividualContact(existedRecord,responseObj){
            // Assign the sub child model for communication
            if(responseObj.Communications.length > 0){
                existedRecord.Communications = responseObj.Communications;
            }else{
                existedRecord.Communications = [];
                contactService.bindCommunicationEmptyModel(existedRecord);
            }
            // Assign the sub child model for correspondences
            if(responseObj.Correspondences.length > 0){
                existedRecord.Correspondences = responseObj.Correspondences;
            }else{
                existedRecord.Correspondences = [];
                contactService.bindCorrespondencesEmptyModel(existedRecord);
            }
            // Assign the sub child model for Contact Relationship Mappings
            if(responseObj.ContactRelationshipMappings.length > 0){
                existedRecord.ContactRelationshipMappings = responseObj.ContactRelationshipMappings;
            }else{
                existedRecord.ContactRelationshipMappings = [];
            }
            // Assign the sub child model for Contact User Mappings
            if(responseObj.ContactUserMappings.length > 0){
                // utility.syncModelWithoutInnerCollection(resFieldsObj,existedRecord[0][index]);
                existedRecord.ContactUserMappings = responseObj.ContactUserMappings;
            }else{
                existedRecord.ContactUserMappings = [];
            }
            // Assign the sub child model for Attachments
            if(responseObj.Attachments.length > 0){
                existedRecord.Attachments = responseObj.Attachments;
            }else{
                existedRecord.Attachments = [];
            }
            // Assign the sub child model for Notes
            if(responseObj.Notes.length > 0){
                existedRecord.Notes = responseObj.Notes;
            }else{
                existedRecord.Notes = [];
            }
            // Assign the sub child model for Attachments
            if(responseObj.Fields.length > 0){
                if(existedRecord.Fields.length > 0){
                    angular.forEach(responseObj.Fields, function (resFieldsObj, index) {
                        var existedField = $filter('filter')(existedRecord.Fields, {FieldName: responseObj.FieldName});
                        if(existedField != null || existedField != ""){
                            utility.syncModelWithCollection(resFieldsObj,existedField);
                        }
                    });
                }
            }else{
                existedRecord.Fields = [];
                contactService.bindFieldsEmptyModel(existedRecord);
            }
            contactService.updateContactToSql(existedRecord,null).then(function (result) {
            }, function (error) {  });
        }
        // details page
        $scope.contactDetails = function (contactObj,objType,repCompany) {
            //debugger
            contactService.setSelectedContactType(objType);
            if($scope.contactTypeInfo.Individual == objType){
                contactService.setSelectedIndividualContact(contactObj);
                if(contactObj.IsRepresentative==false){
                    contactService.sqlGetCompanyData(contactObj.EmployerDeviceObjID).then(function (result) {
                        for (var i = 0; i < result.rows.length; i++) {
                            var companyObjdata = contactService.models().contactModel;
                            companyObjdata = utility.syncModelWithCollection(result.rows.item(i),companyObjdata);
                            contactService.setSelectedCompanyContact(companyObjdata);
                        }
                        if(result.rows.length==0){
                            contactService.setSelectedCompanyContact(null);
                        }
                    });
                }else{
                    contactService.setSelectedCompanyContact(repCompany);
                }
                if(contactObj.IsRepresentative==false)
                    $state.go('tab.contactDetails');
                else    $state.go('tab.repreContactDetails');

            }else{
                contactService.setSelectedCompanyContact(contactObj);
                if(contactObj.Representatives.length==0){
                    contactService.setSelectedIndividualContact(null);
                }else{
                    contactService.getAllSubArrayDataToModel(contactObj.Representatives[0],false);
                    contactService.setSelectedIndividualContact(contactObj.Representatives[0]);
                }
                $state.go('tab.contactDetails');
            }
        }

        // Modal add button
        $ionicModal.fromTemplateUrl('app/views/layout/moremenu.html', {
            scope: $scope,
            animation: 'slide-in-left'
        }).then(function (modal) {
            $scope.modalAdd = modal;
        });
        $scope.fnaddBtn = function () {
            $scope.modalAdd.show();
        };
        $scope.closeModal = function () {
            $scope.modalAdd.hide();
        };

        $scope.selActTypeIndx = -1;
        $scope.selActTypeParentIndx = -1;
          // toggle button
        $scope.fnclickToggle = function (index, parIndx) {
            $scope.selActTypeIndx = index;
            $scope.selActTypeParentIndx = parIndx;
        };
        $scope.fnswitchToggle = function ($index) {
            $scope.selActTypeIndx = -1;
            $scope.selActTypeParentIndx = -1;
        };

        // Modal filter
        $ionicModal.fromTemplateUrl('app/views/contact/contactFilter.html', {
            scope: $scope,
            animation: 'slide-in-up'
        }).then(function (modal) {
            $scope.modalcntfilter = modal;
        });
        $scope.openFilter = function () {
            $scope.modalcntfilter.show();
        };
        $scope.closeModalB = function () {
            $scope.modalcntfilter.hide();
        };
        $scope.openContactsGraph = function () {
            $state.go("tab.contactGraph");
            //alert("calling contactGraph")
        };

           //////////////////CALL/SMS/EMAIL//////////////////
        function onDeviceReady() {
            // Register the event listener
            if (window.cordova && ionic.Platform.isAndroid()) {
                document.addEventListener("resume", onEndCallKeyDown, false);
            }
        }

        $scope.count = 0;
        $scope.devID = 0;
        $scope.startDt;
        function onEndCallKeyDown() {
            if ($scope.count >= 1) return;
            if ($scope.type != 'Call') return;
            $scope.count++;
            var endDt = new Date();
            checkTime($scope.startDt, endDt);
        }

        function checkTime(startDt, endDt) {
            var dif = endDt.getTime() - startDt.getTime();
            var difDt = dif / 1000;
            var finalDifDate = Math.abs(difDt);
            if (finalDifDate >= 15) {
                $scope.openHappend('D', $scope.devID, $scope.type);
            }
        }

        $scope.openActType = function (type, conDevId,model,cmpModel) {
            activityService.sqlGetCommnications(conDevId).then(function (result) {
                var comArr = contactService.getAllComData(result);
                $scope.phone = comArr.mobilePhone;
                $scope.email = comArr.email;
                if (typeof $scope.phone == 'undefined') {
                    $scope.phone = '';
                }
                if (typeof $scope.email == 'undefined') {
                    $scope.email = '';
                }
                if (model.IsRepresentative == false) {
                    contactService.setSelectedIndividualContact(model);
                    contactService.setSelectWhathappened(contactService.constants().contactType.Individual);
                }
                else {
                    contactService.setSelectedCompanyContact(cmpModel);
                    contactService.setSelectedIndividualContact(model);
                    contactService.setSelectWhathappened(contactService.constants().contactType.Company);
                }
                if (type == 1) {
                    $scope.callNumber(conDevId);
                }
                else if (type == 3) {//sms
                    $scope.openSMS(conDevId);
                }
                else if (type == 4) {//email
                    $scope.openEmail(conDevId);
                }
            });
        }

        $scope.openHappend = function (val, devId, actType) {
            activityService.setActStatus('C');
            $state.go('tab.activityHappen', { devObjId: devId, actStatgeType: val, screenType: GENERAL_CONFIG.ScreenType.ContactList, actType: actType });
        };

        $scope.openSMS = function (conDevId) {
            $scope.count = 0;
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }
            var message = '';//'hello text';
            //console.log("going to send " + message + " to " + number);

            //simple validation for now
            //if (number === '' || message === '') return;

            var msg = {
                phoneNumber: number,
                textMessage: message
            };
            //CONFIGURATION
            var options = {
                replaceLineBreaks: false, // true to replace \n by a new line, false by default
                android: {
                    intent: 'INTENT'  // send SMS with the native android SMS messaging
                    //intent: '' // send SMS without open any other app
                }
            };

            var success = function (res) {
                var s = res;
                $scope.type = 'SMS';
                $scope.openHappend('D', conDevId, 'SMS');
                //if(s == 'ok')
                //alert('Message sent successfully');
            };

            var error = function (e) { console.log('Message Failed:' + e); };
            sms.send(number, message, options, success, error);
        }

        $scope.openEmail = function (conDevId) {
            $scope.count = 0;
            $scope.type = 'EMAIL';
            cordova.plugins.email.open({
                to: $scope.email,
                cc: '',
                bcc: [''],
                subject: 'Greetings',
                body: 'test mail'
            });
            $scope.openHappend('D', conDevId, 'Email');
        }

        $scope.callNumber = function (conDevId) {
            var number = $scope.phone;
            if (number == '' || typeof number == 'undefined' || angular.isNumber(number)) {
                alert("Phone number is not configured for this contact.");
                return true;
            }

            window.plugins.CallNumber.callNumber(function () {
                if (window.cordova && ionic.Platform.isAndroid()) {
                    $scope.startDt = new Date();
                    $scope.type = 'Call';
                    $scope.devID = conDevId;
                    $scope.count = 0;
                }
                else {
                    $scope.openHappend('D', conDevId, 'Call');
                }
            }, function () {
                console.log("eroor");
                //error logic goes here
            }, number)
        };
        /////////////////CALL/SMS/EMAIL////////END///////////////////////

        //############### LoggedInAs User  functionality START ##############
        $ionicModal.fromTemplateUrl('app/views/common/loggedInAsUserList.html', {
            scope: $scope,
            animation: 'slide-in-right'
        }).then(function (modal) {
            $scope.modalLoginAsUsers = modal;
        });

        $scope.loggedInUsers = [];
        var loggedInUserInfo = utility.getMasterDataByKey(MASTER_TABLE.LoggedInUserInfo);
        $scope.selfLoggedInID = loggedInUserInfo.UserID;

        $scope.selectedUser = function(index,isSelfUser)
        {
             utility.selectedLogginAsUser(index,isSelfUser,$scope.modalLoginAsUsers,$scope.loggedInUsers).then(function(res){
                 loadData();
                 if ($rootScope.isAccessingOtherUserProfile) {
                     homeService.syncServerRecords();
                 }

            });
        }


        $scope.openLogInUserMenu = function () {
            $scope.loggedInUsers = [];
            utility.loadLoggodInAsUsers($scope.loggedInUsers);
            $scope.modalLoginAsUsers.show();

        };
        $scope.closeLogInMenu = function () {
            $scope.modalLoginAsUsers.hide();
            $scope.loggedInUsers = [];
        };
     //############### LoggedInAs User  functionality END ##############

    };

})();
