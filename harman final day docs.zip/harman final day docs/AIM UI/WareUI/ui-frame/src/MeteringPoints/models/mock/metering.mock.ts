import { Metering } from "../metering.model";

export const metering: Metering = {
    loadedFrom: null,
    loadedUntil: null,
    measuredAttribute: {
        measuredAttributeId: 1,
        name: "",
        identifier: "",
        description: "",
        measuredQuantity: {
            measuredQuantityId: 1,
            name: "",
            identifier: "",
            description: ""
        }
    },
    meteringId: 333,
    measuredUnit: {
        baseUnit: {
            baseUnitId: 1,
            factor: 1,
            measuredUnitId: 1,
            name: ""
        },
        baseUnitId: 1,
        ediQualifier: "",
        factor: 1,
        measuredUnitId: 1,
        name: ""
    },
    productComponent: {
        id: 1,
        name: ""
    },
    meteringPointId: 123,
    name: "",
    obis: "",
    obisA: 0,
    obisB: 0,
    obisC: 0,
    obisD: 0,
    obisE: 0,
    powerDimension: "",
    type: "profile",
    validFrom: 123123123,
    validUntil: 12345566
};

export const meterings: Metering[] = [metering];
