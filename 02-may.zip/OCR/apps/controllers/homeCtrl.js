(function() {
    'use strict';

    fileuploader.controller("homeCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$location', homeCtrl]);

    function homeCtrl($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $location) {
        $scope.viewbtn = true;
        $scope.DataSource = [];
        $rootScope.dropdownselect1 = "";
        $scope.checkboxall = "";

        $scope.fetchdropdown = ""; 
        $scope.contestTypeValue = "";
        $scope.selectedId = "";

        $scope.uploadFile = function() {

        var file = $scope.myFile;
        var uploadUrl = 'http://10.3.48.137:8080/ocr/rest/v0/service/upload/pdf/file/';
        fileUpload.uploadFileToUrl(file, uploadUrl);
            
        };


        $scope.getSelectedValue = function(id) {
                    $rootScope.selectedId = id;
                }

        $scope.open = function(checkeditem) {
            $location.url(uiRouters.dashboard);
            //console.log(checkeditem)             
            //console.log($scope.contestTypeValue)   

            $rootScope.globalId = checkeditem;
            console.log($rootScope.globalId)
        };

        $scope.process = function(DataSource){
            /*var item = [];
            angular.forEach(DataSource, function (value, key) {
                if (DataSource[key].selected == DataSource[key]._id) {
                    item.push(DataSource[key].selected);
                }
            });


            console.log(item)
            //console.log(DataSource[key].selected) 
            }); */
             var data = $rootScope.selectedId;
             console.log(data)

             var url = "http://localhost:8090/ocr/rest/v1/service/process/files/" + data + "/";
            
           var promise = $ajaxFactory.getDataFromServer(url, 'POST', {});

            promise.then(function(d) {
                $rootScope.processData = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });

        
            
        }

        $scope.fetchDataSource = function() {

            //var url = "/get/list/of/data/for/" + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/table.json', 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.DataSource = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });
        }
        $scope.fetchDataSource();


        $scope.fetchdropdownData = function() {

            //var url = "/get/list/of/data/for/" + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/template.json', 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.testdropdown = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });
        }
        $scope.fetchdropdownData();

    }
})();