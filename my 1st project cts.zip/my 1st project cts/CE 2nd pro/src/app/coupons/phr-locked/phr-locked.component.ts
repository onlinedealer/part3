import { Component, OnInit, Input } from '@angular/core';
import { ImagePaths } from '../../constants/image-paths';
import { UtilityService } from '../../services/utility.service';


@Component({
  selector: 'app-phr-locked',
  templateUrl: './phr-locked.component.html',
  styleUrls: ['./phr-locked.component.scss']
})
export class PhrLockedComponent implements OnInit {

  imagesPaths:Object = ImagePaths;

  constructor(public utilityService:UtilityService) { }
  
  ngOnInit() {
  }

}
