import { Mocks, Spies } from 'discovery-test';
import { AlertService } from './alert.service';
import { of } from 'rxjs';

describe('AlertService', () => {
  let service: AlertService;
  let jobId: string;

  beforeEach(() => {
    Spies.init();
    service = new AlertService(
      Spies.HttpClient,
      Spies.AuthenticationService,
      Spies.HttpUtilService,
      Spies.ServerSentEventsService
    );
    jobId = '634fec397b23970c9d3df673';
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });

  it('can get list of alerts', () => {
    service.getAlerts();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('can get list of alerts with non-alerts', () => {
    service.getAlerts(true);
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('can get alert detail', () => {
    service.getAlertDetail('12345');
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });
  it('can get count of alerts', () => {
    service.getAlertsCount();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('can get total count of alerts', () => {
    service.getTotalAlertsCount();
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('can submit request for report generation', () => {
    let requestData = {
      alertId: '6346a7c658a3e73fa616350c',
      fromDate: null,
      toDate: '2022-10-12T11:40:54.010Z'
    };
    service.reportGenerationRequest(requestData);
  });

  it('can get report downloaded', () => {
    service.getExcel(jobId);
    expect(Spies.HttpClient.get.calls.count()).toBe(1);
  });

  it('can check progress and download report', () => {
    Spies.ServerSentEventsService.getServerSentEvent.and.returnValue(of(Mocks.MockReportStatusResponse[0]));
    service.getExcelStatus(jobId, 'test');
  });
});
