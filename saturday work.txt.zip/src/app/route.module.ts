import { NgModule } from '@angular/core';
 import { Routes, RouterModule } from '@angular/router';
 import { UserComponent } from './components/user/user.component';
 import { RegComponent } from './components/registration/reg.component';
import { CanDeactivateGuard } from './can-deactivate.guard';
import { CanActivateGuard } from './can-activate.guard';

 const routes: Routes = [
   { path: 'login', component: UserComponent, canActivate: [CanActivateGuard] },
   { path: 'reg', component: RegComponent, canActivate: [CanActivateGuard] },
   { path: '**', redirectTo: 'login' }
 ]; 
 
 @NgModule({
   imports: [RouterModule.forRoot(routes)],
   exports: [RouterModule],
 })
 export class AppRoutingModule {}
  