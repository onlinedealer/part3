import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed, tick } from '@angular/core/testing';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { Observable, of, throwError } from 'rxjs';
import { AppResources } from '../../app-resources-config';
import { getTranslocoModule } from '../../core/transloco-testing.module';
import { MockSidebarComponent } from '../../shared/components/sidebar/mock-sidebar.component.spec';
import { ResourcePermissionService } from '../../shared/services/resource-permission.service';
import { Project } from '../pipeline/shared/project';
import { ProjectCommitResponse } from '../pipeline/shared/project-commit-response';
import { ProjectsApiService } from '../pipeline/shared/projects-api.service';
import { PipelinesMonitoringApiService } from '../shared/pipelines-monitoring-api.service';
import { ValidateConfigurationSidebarComponent } from '../shared/validate-configuration-sidebar/validate-configuration-sidebar.component';
import { ApplyConfigurationSidebarComponent } from './apply-configuration-sidebar.component';
import { DeployConfigurationFormComponent } from '../shared/deploy-configuration-form/deploy-configuration-form.component';

describe('ApplyConfigurationSidebarComponent', () => {
  let component: ApplyConfigurationSidebarComponent;
  let fixture: ComponentFixture<ApplyConfigurationSidebarComponent>;
  let projectsApiService: ProjectsApiService;
  let pipelinesMonitoringApiService: PipelinesMonitoringApiService;
  let resourcePermissionService: ResourcePermissionService;
  const project = {
    id: 'test',
    projectType: 'abc',
    name: 'Default_Project',
    description: 'project_description'
  } as Project;
  let mockFeatureFlagService: any;

  @Component({
    selector: 'p-connect-deploy-configuration-form',
    template: '',
    providers: [
      {
        provide: DeployConfigurationFormComponent,
        useClass: MockDeployConfigurationFormComponent
      }
    ]
  })
  class MockDeployConfigurationFormComponent {
    open() {}
  }
  @Component({
    selector: 'p-connect-validate-configuration-sidebar',
    template: '',
    providers: [
      {
        provide: ValidateConfigurationSidebarComponent,
        useClass: MockValidateConfigurationSidebarComponent
      }
    ]
  })
  class MockValidateConfigurationSidebarComponent {
    open() {}
    openCommitValidationAsync() {}
  }

  beforeEach(async () => {
    mockFeatureFlagService = jasmine.createSpyObj('FeatureFlagService', ['isFeatureEnabled', 'isFeatureDisabled']);
    await TestBed.configureTestingModule({
      declarations: [
        ApplyConfigurationSidebarComponent,
        MockSidebarComponent,
        MockValidateConfigurationSidebarComponent,
        MockDeployConfigurationFormComponent
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      imports: [getTranslocoModule(), HttpClientTestingModule, FormsModule, ReactiveFormsModule],
      providers: [{ provide: FeatureFlagService, useValue: mockFeatureFlagService }]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ApplyConfigurationSidebarComponent);
    component = fixture.componentInstance;
    projectsApiService = TestBed.inject(ProjectsApiService);
    pipelinesMonitoringApiService = TestBed.inject(PipelinesMonitoringApiService);
    resourcePermissionService = TestBed.inject(ResourcePermissionService);
    resourcePermissionService.setRoles(['Designer', 'Operator']);
    resourcePermissionService.setResources(AppResources);
    resourcePermissionService.updateUserResources();
    fixture.detectChanges();
    component.deployConfigurationFormComponent = { open: () => {} } as DeployConfigurationFormComponent;
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should open the sidebar', () => {
    spyOn(component.sidebarComponent, 'open').and.returnValue();
    let deploySpy = spyOn(component.deployConfigurationFormComponent, 'open').and.returnValue();
    const pipelines: any = [
      {
        id: '1',
        name: 'pipeline',
        dataFlowType: 'type',
        description: 'description',
        properties: [],
        filters: [],
        source: {
          dataConnection: { name: 'source', connectionType: 'ORACLE' },
          selectedTables: [{ key: 'schema1', value: { tableExtractType: '', tableNames: ['test1', 'test2'], tableNamesMap: {} } }]
        },
        target: { dataConnection: { name: 'target', connectionType: 'KAFKA' }, cdcRowMetadatas: [], parameters: [] },
        overallStatus: 'OK'
      }
    ];
    component.open(pipelines, project);
    expect(component.deployConfigurationFormComponent.open).toHaveBeenCalled();
    expect(component.sidebarComponent.open).toHaveBeenCalled();
    expect(component.projectName).toBe(project.name);
    expect(component.projectDescription).toBe(project.description);
    spyOn(resourcePermissionService, 'hasResourcePermission').and.returnValue(false);
    deploySpy.calls.reset();
    component.open(pipelines, project);
    expect(component.deployConfigurationFormComponent.open).not.toHaveBeenCalled();
  });

  describe('primary button', () => {
    beforeEach(() => {
      jasmine.getEnv().allowRespy(true);
      component.applyConfigurationFormGroup.addControl('stageChanges', new FormControl(true));
      component.applyConfigurationFormGroup.addControl('startPipeline', new FormControl(false));
      const deployForm = component.applyConfigurationFormGroup.get('deployChangesFormGroup') as FormGroup;
      deployForm.addControl('backlogEmpty', new FormControl(1));
      deployForm.addControl('tableCaptureDisabled', new FormControl(1));
      deployForm.addControl('replicationStopped', new FormControl(1));
      deployForm.addControl('forceDeploy', new FormControl(true));
      deployForm.addControl('makeChangesActive', new FormControl(true));
    });

    it('should commit successful with feature flag enabled for incremmental commit', fakeAsync(() => {
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
      component.ngAfterViewInit();
      component.applyConfigurationFormGroup.addControl('setStage', new FormControl('INCREMENTAL_COMMIT'));
      spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
      spyOn(projectsApiService, 'commit').and.returnValue(of({ isCommited: true } as ProjectCommitResponse));
      component.primaryButtonClicked();
      tick();
      expect(projectsApiService.commit).toHaveBeenCalledWith('abcd', false, 'INCREMENTAL_COMMIT');
    }));

    it('should go with the async commit flow', () => {
      spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
      spyOn(mockFeatureFlagService, 'isFeatureEnabled').and.returnValue(true);
      spyOn(projectsApiService, 'commit').and.returnValue(of({ isCommited: true } as ProjectCommitResponse));
      spyOn(component.validateConfigurationSidebarComponent, 'openCommitValidationAsync').and.callFake(() => {
        ('');
      });
      component.primaryButtonClicked();
      expect(component.validateConfigurationSidebarComponent.openCommitValidationAsync).toHaveBeenCalled();
    });

    it('should return error from primaryButtonClicked event', fakeAsync(() => {
      spyOn(projectsApiService, 'getDefaultProject').and.returnValue(throwError('error'));
      spyOn(projectsApiService, 'commit').and.returnValue(of({ isCommited: true } as ProjectCommitResponse));
      component.primaryButtonClicked();
      tick();
      expect(projectsApiService.commit).not.toHaveBeenCalled();
    }));

    it('should disable if stage connections and make changes are not checked', fakeAsync(() => {
      component.ngAfterViewInit();
      component.applyConfigurationFormGroup.patchValue({ stageChanges: false });
      component.applyConfigurationFormGroup.controls.deployChangesFormGroup.patchValue({ makeChangesActive: false });
      fixture.detectChanges();
      fixture.whenStable().then(() => {
        expect(component.primaryButton.isDisabled).toBe(true);
      });
    }));

    it('should close sidebar when commit is successful', fakeAsync(() => {
      spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
      spyOn(projectsApiService, 'commit').and.returnValue(of({ isCommited: true } as ProjectCommitResponse));
      spyOn(component.sidebarComponent, 'close').and.returnValue();
      component.applyConfigurationFormGroup.controls.deployChangesFormGroup.disable();
      component.primaryButtonClicked();
      tick();
      expect(component.sidebarComponent.close).toHaveBeenCalled();
    }));

    it('should call deploy when makeChanges is active', fakeAsync(() => {
      spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
      spyOn(projectsApiService, 'commit').and.returnValue(of({ isCommited: true } as ProjectCommitResponse));
      spyOn(pipelinesMonitoringApiService, 'deploy').and.returnValue(of(Observable));
      spyOn(component.sidebarComponent, 'close').and.returnValue();
      component.applyConfigurationFormGroup.patchValue({ startPipeline: true });
      component.primaryButtonClicked();
      tick();
      expect(pipelinesMonitoringApiService.deploy).toHaveBeenCalled();
    }));

    it('should open validation error sidebar if not committed', fakeAsync(() => {
      spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
      spyOn(projectsApiService, 'commit').and.returnValue(of({ isCommited: false } as ProjectCommitResponse));
      spyOn(component.validateConfigurationSidebarComponent, 'open').and.returnValue();
      component.primaryButtonClicked();
      tick();
      expect(component.validateConfigurationSidebarComponent.open).toHaveBeenCalled();
    }));

    // Disabling the test case as it is failing after setting role permission
    xit('should handle error when calling commit', fakeAsync(() => {
      spyOn(projectsApiService, 'getDefaultProject').and.returnValue(of({ id: 'abcd' } as Project));
      spyOn(projectsApiService, 'commit').and.returnValue(throwError({}));
      spyOn(component.sidebarComponent, 'parseHttpClientResponseMessage').and.returnValue();
      component.open([], project);
      component.primaryButtonClicked();
      // tick();
      expect(component.sidebarComponent.parseHttpClientResponseMessage).toHaveBeenCalled();
    }));
  });

  it('should close the sidebar', () => {
    spyOn(component.sidebarComponent, 'close').and.returnValue();
    component.cancelButtonClicked();
    expect(component.sidebarComponent.close).toHaveBeenCalled();
  });

  describe('checking for db2z connection type', () => {
    it('should default to false', () => {
      component.open([{ name: 'test' }], project);
      expect(component.containsDB2ZOSSources).toBe(false);
    });

    it('should return true if the pipeline with a db2z connection has not been deleted', () => {
      component.open([{ name: 'test', source: { dataConnection: { connectionType: 'DB2ZOS' } } }], project);
      expect(component.containsDB2ZOSSources).toBe(true);
    });

    it('should return true if the pipeline with a db2z connection has been deleted', () => {
      component.open(
        [
          {
            name: 'test',
            runtimeServers: [
              {
                dataConnections: [
                  {
                    connectionType: 'DB2ZOS'
                  }
                ]
              }
            ]
          }
        ],
        project
      );
      expect(component.containsDB2ZOSSources).toBe(true);
    });
  });
});
