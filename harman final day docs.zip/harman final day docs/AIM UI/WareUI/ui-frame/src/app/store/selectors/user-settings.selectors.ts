import { createSelector } from "@ngrx/store";

import * as fromRoot from "../reducers";
import * as fromUserSettings from "../reducers/user-settings.reducer";

export const getUserSettings = createSelector(fromRoot.getUserSettingsState, (userSettingsState: fromUserSettings.UserSettingsState) => ({
    ...userSettingsState,
    loaded: undefined
}));

export const isLoaded = createSelector(
    fromRoot.getUserSettingsState,
    (userSettingsState: fromUserSettings.UserSettingsState) => userSettingsState.loaded
);

export const getUserProfileSettings = createSelector(fromRoot.getUserSettingsState, (userSettings: fromUserSettings.UserSettingsState) => {
    return userSettings.userProfileSetting ? userSettings.userProfileSetting : {};
});

export const getSearchSettings = createSelector(
    fromRoot.getUserSettingsState,
    isLoaded,
    (userSettings: fromUserSettings.UserSettingsState, settingsLoaded: boolean) => {
        if (settingsLoaded === false) {
            return undefined;
        }

        return userSettings.searchSettings ? userSettings.searchSettings : {};
    }
);
export const getUserSettingFailed = createSelector(
    fromRoot.getUserSettingsState,
    (userSettingState: fromUserSettings.UserSettingsState) => {
        if (userSettingState.getUserSettingErrorState && userSettingState.getUserSettingErrorState.errorCode) {
            return userSettingState.getUserSettingErrorState.errorCode;
        }
    }
);
export const getUserSettingUpdateFailed = createSelector(
    fromRoot.getUserSettingsState,
    (userSettingState: fromUserSettings.UserSettingsState) => {
        if (userSettingState.updateUserSettingErrorState && userSettingState.updateUserSettingErrorState.errorCode) {
            return userSettingState.updateUserSettingErrorState.errorCode;
        }
    }
);
export const isUserSettingFailed = createSelector(fromRoot.getUserSettingsState, (userSettingState: fromUserSettings.UserSettingsState) => {
    return userSettingState.userSettingFailed;
});
export const userSettingFailedErrorCode = createSelector(
    getUserSettingFailed,
    getUserSettingUpdateFailed,
    isUserSettingFailed,
    (getUserErrorCode, updateUserErrorCode, isFailed) => {
        if (getUserErrorCode) {
            return getUserErrorCode.toString();
        } else if (updateUserErrorCode) {
            return updateUserErrorCode.toString();
        } else if (isFailed) {
            return "SESSION_EXPIRED";
        } else {
            return "";
        }
    }
);
