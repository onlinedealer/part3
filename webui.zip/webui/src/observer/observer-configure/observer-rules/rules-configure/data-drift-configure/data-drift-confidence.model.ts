import { WarningAlertModel } from '../warning-alert.model';

export class DatadriftConfidenceModel {
  numericData: string[];
  textualData: string[];
  detailDrift: string[];
  uniqueValueCount: boolean;
  warningAlerts: WarningAlertModel;

  constructor() {
    this.detailDrift = [];
    this.numericData = [];
    this.textualData = [];
    this.uniqueValueCount = true;
    this.warningAlerts = new WarningAlertModel();
  }
}
