import { Component, Input, ChangeDetectionStrategy } from "@angular/core";
import { Metering } from "../../../models/metering.model";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { MeteringsActions } from "../../../store/actions";
import { MeteringRegisterSelectors, MeteringsSelectors, ProfileDataSelectors } from "../../../store/selectors";
import { MeteringVO } from "../../../models/view-objects/metering-vo.model";
import { Observable } from "rxjs";
import { Store } from "@ngrx/store";

@Component({
    selector: "landisgyr-ss-metering-toolbar-select",
    templateUrl: "./ss-metering-toolbar-select.component.html",
    styleUrls: ["./ss-metering-toolbar-select.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSMeteringToolbarSelectComponent {
    @Input()
    metering!: Metering | undefined;

    allMeterings$: Observable<MeteringVO[]> = this.store.select(MeteringRegisterSelectors.getSelectedMeteringPointMeteringsVOsWithStates);
    meteringsLoading$ = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);
    isProfileDataEdited$: Observable<boolean> = this.store.select(ProfileDataSelectors.getIsProfileDataEdited);

    constructor(private store: Store<MeteringPointsFeatureState>) {}

    changeMetering(metering: MeteringVO) {
        this.store.dispatch(
            MeteringsActions.ChangeMetering({
                meteringPointId: metering.meteringPointId,
                meteringId: metering.id,
                meteringType: metering.type // should it be metering.meteringType?
            })
        );
    }

    isEqual(meteringOption: MeteringVO, selectedMetering: Metering) {
        return (
            meteringOption &&
            selectedMetering &&
            meteringOption.id === selectedMetering.meteringId &&
            meteringOption.type === selectedMetering.type
        );
    }
}
