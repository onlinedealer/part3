(function() {
    'use strict';

    fileuploader.controller("homeCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$location', '$route', '$window', '$timeout', '$http', '$uibModal', 'ngTableParams', homeCtrl]);

    function homeCtrl($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $location, $route, $window, $timeout, $http, $uibModal, ngTableParams) {

        $scope.viewbtn = true;
        $scope.DataSource = [];
        $scope.checkboxall = "";
        $scope.fetchdropdown = "";
        $scope.contestTypeValue = "";
        $scope.selectedId = "";
        $scope.processingBind = "";
        $scope.GridDataSource = [];
        $scope.buttonName = "";



        $scope.buttonFun = function() {

            var data = $scope.GridDataSource;
            for (var i = 0; i < data.length; i++) {
                var obj = json[i];

                if (obj.status == 'Pending') {
                    $scope.buttonName = "Process";

                } else {
                    $scope.buttonName = "View";
                }
            }
        };

        $scope.buttonFun();

        $scope.fileuploadPopUp = function() {
            var modalInstance = $uibModal.open({
                animation: $scope.animationsEnabled,
                templateUrl: uiRouters.directivesHtmlPath + '/filePopUp.html',
                controller: 'ModalInstanceController',
            });
        };

        // catching template on dropdown list
        $scope.changedValue = function(item) {
            $rootScope.dropdownSelect = item.templateName;
        };
        // catching ID on selected radio button
        $scope.getSelectedValue = function(id) {
            $rootScope.selectedId = id;
        };
        // function for navigate to next page depends on selected dropdonw and radio button
        $scope.open = function(tableDat) {
            var checkeditem = tableDat.tiffId;
            var textOrPdf = tableDat.fileName;
            $rootScope.templateapplied = tableDat.template;
            $rootScope.textPdf = textOrPdf;
            $location.url(uiRouters.dashboard);
            $rootScope.globalId = checkeditem;
        };
        // function for "process Document"-- this calls to one service
        $scope.process = function(tableData) {
            //tableData.status = "Processing";
            //var dropselec = $scope.templateName;
                
               

                var DataSource = tableData.tiffId;
                var statusInfo = tableData.status;
                //$scope.processingBind = "Processing";
                var selectedTemplate = $rootScope.dropdownSelect;
                var selectedId = $rootScope.selectedId;
                var url = "/ocr/rest/v1/service/process/files/" + DataSource + "/template" + "/" + selectedTemplate;
                var promise = $ajaxFactory.getDataFromServer(url, 'POST', {});
                promise.then(function(d) {
                    $rootScope.processData = d;
                    $window.location.reload();


                });
                promise.catch(function(d) {
                    console.log('catch block executed', d);
                    return d;
                });
            
        };



        // self calling function to display gird table contains the fileName, status, dropdown..etc
        $scope.fetchDataTable = function() {
            //var url = "/ocr/rest/v1/service/get/all/documentqueuedetails";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/table.json', 'GET', {});
            //var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
            promise.then(function(d) {
                $scope.GridDataSource = d;
                $scope.templatesTable = new ngTableParams({
                    page: 1,
                    count: 5
                }, {
                    total: $scope.GridDataSource.length,
                    getData: function($defer, params) {
                        $scope.data = $scope.GridDataSource.slice((params.page() - 1) * params.count(), params.page() * params.count());
                        $defer.resolve($scope.data);
                    }
                });
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
        };

        $scope.fetchDataTable();

        // function for to display the dropdown
        $scope.fetchdropdownData = function() {
            //var url = "/ocr/rest/v1/service//get/all/template";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/template.json', 'GET', {});
            //var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});
            promise.then(function(d) {
                $scope.dropdownList = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
        };

        $scope.fetchdropdownData();
    }


    fileuploader.controller('ModalInstanceController', ['$scope', '$ajaxFactory', '$rootScope', 'fileUpload', 'uiRouters', '$uibModalInstance', '$route', '$location', '$window', '$timeout', '$http', ModalInstanceController]);

    function ModalInstanceController($scope, $ajaxFactory, $rootScope, fileUpload, uiRouters, $uibModalInstance, $route, $location, $window, $timeout, $http) {

        $scope.errorShow = false;
        $scope.cancel = function() {
            $uibModalInstance.dismiss('cancel');
        };
        $scope.uploadFile = function() {
            if ($scope.myFile) {
                var file = $scope.myFile;
                var filename = file.name;
                var valid = /(\.jpg|\.jpeg|\.png|\.pdf|\.PDF|\.PNG|\.TIFF|\.tiff|\.JPEG|\.JPG)$/i;
                if (!valid.exec(filename)) {
                    alert("upload valid file, like .pdf, .png, .tiff, .jpg")
                } else {

                    console.log(file)
                    console.log(filename)
                    var uploadUrl = 'http://localhost:8080/ocr/rest/v1/service/upload/pdf/file/';
                    var fd = new FormData();
                    fd.append('file', file);
                    $http.post(uploadUrl, fd, {
                            transformRequest: angular.identity,
                            headers: {
                                'Content-Type': undefined
                            }
                        })
                        .success(function(d) {
                            $scope.uploadResponse = d;
                            $rootScope.fetchDataTable();
                        })
                        .error(function(data, status, headers, config) {

                        });

                    $timeout(callAtTimeout, 3000);

                    function callAtTimeout() {
                        $window.location.reload();
                    }
                }

            } else {
                alert("First Select the file and click upload")
            }

        };




    }
})();
