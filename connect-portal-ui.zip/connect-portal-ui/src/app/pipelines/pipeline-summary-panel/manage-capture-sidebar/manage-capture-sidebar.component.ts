import { Component, ViewChild, Output, EventEmitter } from '@angular/core';
import { first } from 'rxjs/operators';
import { BaseComponent } from '../../../core/base.component';
import { SidebarButton } from '../../../shared/components/sidebar/sidebar-button';
import { SidebarCheckbox } from '../../../shared/components/sidebar/sidebar-checkbox';
import { SidebarComponent } from '../../../shared/components/sidebar/sidebar.component';
import { ManageCaptureFormComponent } from './manage-capture-form/manage-capture-form.component';
import { PipelinesMonitoringApiService } from '../../shared/pipelines-monitoring-api.service';

@Component({
  selector: 'p-connect-manage-capture-sidebar',
  templateUrl: './manage-capture-sidebar.component.html'
})
export class ManageCaptureSidebarComponent extends BaseComponent {
  /**
   * Reference to the SidebarComponent child component
   */
  @ViewChild(SidebarComponent) sidebarComponent: SidebarComponent;
  @ViewChild(ManageCaptureFormComponent) manageCaptureFormComponent: ManageCaptureFormComponent;
  @Output() displayAlertsEvent = new EventEmitter();

  isDisplayAlertsEnabled = true;

  cancelButton: SidebarButton = {
    id: 'manageCaptureCancelButton',
    text: 'common.BUTTONS.CANCEL'
  };

  secondaryButton: SidebarButton = {
    isHidden: true
  };

  primaryButton: SidebarButton = {
    id: 'manageCaptureSaveButton',
    text: 'pipelines.SHARED.MANAGE_CAPTURE.BUTTONS.MAKE_CHANGES'
  };

  displayAlertsCheckbox: SidebarCheckbox = {
    id: 'manageCaptureDisplayAlertsCheckbox',
    text: 'pipelines.SHARED.MANAGE_CAPTURE.LABELS.DISPLAY_ALERTS',
    model: this.isDisplayAlertsEnabled,
    onChangeCheckBox: (event) => {
      this.isDisplayAlertsEnabled = event.checked;
    },
    isHidden: false
  };

  projectId = '';
  pipelineName = '';
  dataConnectionName = '';

  constructor(public readonly pipelinesMonitoringApiService: PipelinesMonitoringApiService) {
    super();
  }

  open(selectedPipeline: any, projectName?: string) {
    this.projectId = selectedPipeline.projectId;
    this.pipelineName = selectedPipeline.name;
    this.isDisplayAlertsEnabled = true;
    this.displayAlertsCheckbox.model = this.isDisplayAlertsEnabled;
    this.primaryButton.isDisabled = true;
    this.dataConnectionName = selectedPipeline.tableMappings[0].source.name;
    this.manageCaptureFormComponent.open(selectedPipeline, projectName);
    this.sidebarComponent.open();
  }

  cancelSidebarButtonClicked(): void {
    this.sidebarComponent.close();
  }

  primaryButtonClicked(): void {
    this.enableCapture();
    this.disableCapture();
    if (this.isDisplayAlertsEnabled) {
      this.displayAlertsEvent.emit();
    }
    this.sidebarComponent.close();
  }

  enableCapture(): void {
    const tables = this.manageCaptureFormComponent.tablesEnabled;
    if (tables.length) {
      this.isProcessingRequest = true;
      this.pipelinesMonitoringApiService
        .enableTableCapture(this.projectId, this.pipelineName, tables, this.dataConnectionName)
        .pipe(first())
        .subscribe({
          error: (errorResponse) => {
            this.parseHttpClientResponseMessage('error', errorResponse);
          }
        })
        .add(() => {
          this.isProcessingRequest = false;
        });
    }
  }

  disableCapture(): void {
    const tables = this.manageCaptureFormComponent.tablesDisabled;
    if (tables.length) {
      this.isProcessingRequest = true;
      this.pipelinesMonitoringApiService
        .disableTableCapture(this.projectId, this.pipelineName, tables, this.dataConnectionName)
        .pipe(first())
        .subscribe({
          error: (errorResponse) => {
            this.parseHttpClientResponseMessage('error', errorResponse);
          }
        })
        .add(() => {
          this.isProcessingRequest = false;
        });
    }
  }

  pendingChanges(areTherePendingChanges): void {
    this.primaryButton.isDisabled = !areTherePendingChanges;
  }
}
