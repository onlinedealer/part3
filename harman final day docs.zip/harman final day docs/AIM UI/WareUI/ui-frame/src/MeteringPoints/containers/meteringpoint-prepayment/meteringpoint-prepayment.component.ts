import { Component, OnInit, AfterViewInit } from "@angular/core";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { PrepaymentActions, PrepaymentChartActions, SecondarySideviewActions } from "../../store/actions";
import { ProfileData } from "../../models/profiledata.model";
import { Store } from "@ngrx/store";
import { Observable, BehaviorSubject } from "rxjs";
import * as fromPrepayment from "../../../MeteringPoints/store/selectors/prepayment.selectors";
import {
    MeteringPointsSelectors,
    MeterConnectionsWithConfigurationsSelectors,
    RegistersSelectors,
    PrepaymentChartSelectors,
    MeteringsSelectors,
    MeteringPointsUISelectors
} from "../../store/selectors";
import { MeteringPoint } from "../../models/meteringpoint.model";
import { MeterConnectionVO } from "../../models/view-objects/meterconnection-vo.model";
import { map } from "rxjs/operators";
import { DateFormatService } from "../../../Shared/services/date-format.service";
import { RouterSelectors } from "../../../app/store/selectors";
import { TranslationsService } from "../../../app/services/translations-service";
import { SortOrder } from "../../../Shared/models/sort-order.model";
import { LocalStorageKeys, LocalStorageService } from "../../../app/services/local-storage.service";

@Component({
    selector: "landisgyr-meteringpoint-prepayment",
    templateUrl: "./meteringpoint-prepayment.component.html",
    styleUrls: ["./meteringpoint-prepayment.component.scss"]
})
export class MeteringpointPrepaymentComponent implements OnInit, AfterViewInit {
    meteringIds = [];

    resizeEvent = new BehaviorSubject(false);
    resizeEvent$ = this.resizeEvent.asObservable();
    columnsData: any;

    changed = false;
    tableViewName!: string;

    infoMessage: string = $localize`:|@@prepayment.noPrepaymentDataMessage:No available credit metering found for the metering point.`;

    prepaymentLoading$: Observable<boolean> = this.store.select(MeteringsSelectors.getSelectedMeteringPointMeteringsLoading);

    // Prepayment customer info
    prepaymentCustomerInfoData$: Observable<any> = this.store.select(fromPrepayment.getPrepaymentCustomerDetailsForTable);

    prepaymentCreditAvailable$: Observable<ProfileData[]> = this.store.select(fromPrepayment.getSelectedPrepaymentCreditAvailableArray);

    meteringId$: Observable<any> = this.store.select(fromPrepayment.getMeteringIDFromProfileMeteringForPrepayment);

    meteringPointId$: Observable<any> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointId);

    // Tabular view data
    meteringPoint$: Observable<MeteringPoint | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointEntity);

    profileDataLoading$: Observable<boolean> = this.store.select(fromPrepayment.getLoadingData);

    profileDataForPrepayment$: Observable<any> = this.store.select(fromPrepayment.getSelectedMeteringsProfileDataForTable).pipe(
        map((profileData) => {
            return profileData.map((data) => {
                return {
                    ...data,
                    readingTime: this.formatService.toLocaleString(data.readingTime)
                };
            });
        })
    );

    sideViewExpanded$: Observable<boolean> = this.store.select(MeteringPointsUISelectors.getMeteringPointsSideviewExpanded);

    // Export data
    selectedTimeRange$ = this.store.select(fromPrepayment.getPrepaymentDateRangeForExport);

    meteringDataForExport$: Observable<any> = this.store.select(fromPrepayment.getPrepaymentMeasuredUnitValForExport);

    devices$: Observable<MeterConnectionVO[]> = this.store.select(
        MeterConnectionsWithConfigurationsSelectors.getSelectedMeteringPointMeterConnectionsEntitiesForTable
    );

    deviceMeterRegisters$: Observable<{ [id: number]: number[] }> = this.store.select(RegistersSelectors.getDeviceMeterRegisterIds);

    prepaymentDataToExport$: Observable<any> = this.store.select(fromPrepayment.getPrepaymentDataForExport);

    // View
    activeView$: Observable<any> = this.store.select(fromPrepayment.getPrepaymentDateRange);

    // Chart data
    chartLoading$ = this.store.select(PrepaymentChartSelectors.getChartDataLoading);

    chartDataGrouping$ = this.store.select(PrepaymentChartSelectors.getSelectedChartDataGrouping);

    chartDataAvailableGroupingOptions$ = this.store.select(PrepaymentChartSelectors.getAvailableChartDataGroupingOptions);

    chartData$ = this.store.select(PrepaymentChartSelectors.getSelectedMeteringsProfileAdditional);

    chartScale$ = this.store.select(PrepaymentChartSelectors.getChartScales);

    viewName$ = this.store.select(PrepaymentChartSelectors.isPrepaymentView);

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private formatService: DateFormatService,
        public translations: TranslationsService,
        private localStorage: LocalStorageService
    ) {}

    ngOnInit() {
        this.meteringPointId$.forEach((meteringpointid) => {
            this.meteringId$.forEach((meteringid) => {
                this.meteringIds = meteringid;
                if (meteringid) {
                    this.store.dispatch(PrepaymentActions.LoadCreditAvailableForPrepaymentData({ meteringPointId: meteringpointid }));
                    this.store.dispatch(PrepaymentActions.LoadPrepaymentDataFromProfileMetering());
                }
            });
        });

        this.localStorage.changedColumnInfo.subscribe((data) => {
            if (data.key === LocalStorageKeys.prepaymentTable || data.key === LocalStorageKeys.prepaymentTableCollapsed) {
                this.changed = true;
                this.columnsData = data.value;
            }
        });
        if (!this.changed) {
            this.sideViewExpanded$.subscribe((ele) => {
                if (ele && this.localStorage.getColumnConfiguration(LocalStorageKeys.prepaymentTable)) {
                    this.tableViewName = LocalStorageKeys.prepaymentTable;
                    this.columnsData = this.localStorage.getColumnConfiguration(LocalStorageKeys.prepaymentTable);
                } else if (ele && !this.localStorage.getColumnConfiguration(LocalStorageKeys.prepaymentTable)) {
                    this.tableViewName = LocalStorageKeys.prepaymentTable;
                    this.store.select(MeteringPointsUISelectors.getPrepaymentConfigInitial).subscribe((data) => {
                        this.columnsData = data;
                    });
                } else if (!ele && this.localStorage.getColumnConfiguration(LocalStorageKeys.prepaymentTableCollapsed)) {
                    this.tableViewName = LocalStorageKeys.prepaymentTableCollapsed;
                    this.columnsData = this.localStorage.getColumnConfiguration(LocalStorageKeys.prepaymentTableCollapsed);
                } else if (!ele && !this.localStorage.getColumnConfiguration(LocalStorageKeys.prepaymentTableCollapsed)) {
                    this.tableViewName = LocalStorageKeys.prepaymentTableCollapsed;
                    this.store.select(MeteringPointsUISelectors.getPrepaymentCollapsedColumnConfigInitial).subscribe((data) => {
                        this.columnsData = data;
                    });
                }
            });
        }
    }

    ngAfterViewInit() {
        setTimeout(() => this.checkURLForActiveView());
    }

    onViewResize() {
        this.resizeEvent.next(!this.resizeEvent.value);
    }

    setActiveView(viewName: string) {
        this.store.dispatch(PrepaymentActions.SetPrepaymentActiveView({ view: viewName }));
    }

    onGroupingSelectionToggleChange(dataGrouping: "day" | "week" | "month" | "year" | "all") {
        this.store.dispatch(PrepaymentChartActions.SelectChartDataGrouping({ dataGrouping: dataGrouping }));
    }

    onTableSortOrderChange(sortChange: SortOrder) {
        this.store.dispatch(PrepaymentActions.SetPrepaymentsDataTableSorting({ sortChange: sortChange }));
    }

    openTokenLogSecondarySideview() {
        this.store.dispatch(SecondarySideviewActions.openPrepaymentTokenLogSecondarySideview());
    }

    checkURLForActiveView() {
        this.store
            .select(RouterSelectors.getSegmentsWithParams)
            .subscribe((segmentsWithParams) => {
                const activeView = segmentsWithParams.segments[segmentsWithParams.segments.length - 1];
                if (activeView === "table" || activeView === "chart") {
                    this.store.dispatch(PrepaymentActions.SetPrepaymentActiveView({ view: activeView }));
                }
            })
            .unsubscribe();
    }
}
