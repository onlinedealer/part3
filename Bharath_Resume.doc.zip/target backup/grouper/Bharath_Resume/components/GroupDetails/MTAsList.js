import React from 'react'
import _ from 'lodash'
import { withStyles } from '@material-ui/core/styles'
import PropTypes from 'prop-types'
import Grid from '@material-ui/core/Grid'
// import LoadingHOC from '../common/HOC/LoadingHOC'

const styles = theme => ({
  root: {
    width: '100%',
    padding: '0px 10px',
  },
  reqColumn: {
    fontSize: 14,
  },
  optColumn: {
    fontSize: 14,
    paddingLeft: 10,
  },
  headerInfoBlock: {
    fontSize: 13,
    marginBottom: 5,
    borderBottom: '1px solid #ccc',
    paddingBottom: 5,
  },
  headerInfoRow: {
    padding: 2,
    fontSize: 12,
    lineHeight: 2,
  },
  headerInfoAttr: {
    fontWeight: 500,
  },
})

export class MTAsList extends React.Component {
  render () {
    const { classes, groupDetails, collectionMTAs } = this.props
    const HeaderInfo = (props) => {
      return (
        <Grid item xs={12} className={classes.headerInfoRow}>
          <Grid container>
            <Grid item xs={5} className={classes.headerInfoAttr}>
              {props.attr}
            </Grid>
            <Grid item xs={7}>
              {props.value}
            </Grid>
          </Grid>
        </Grid>
      )
    }

    if (collectionMTAs.length === 0) {
      return null
    }
    const cutOff = Math.floor(collectionMTAs.optional_collection_mta_info.length / 2)
    return (
      <Grid container className={classes.root}>
        {collectionMTAs.required_collection_mta_info.length > 0 &&
        <Grid item xs={4} className={classes.reqColumn}>
          <Grid container>
            <Grid item xs={12} className={classes.headerInfoBlock}>
                            Required
            </Grid>
            {collectionMTAs.required_collection_mta_info.map((option) => {
              const curValueObj = _.find(groupDetails.collection_themes, (n) => { return n.id === option.id })
              let tempArr = []
              if (curValueObj) {
                curValueObj.values.map((opt) => {
                  tempArr.push(opt.name)
                })
                return (<HeaderInfo attr={option.name} value={tempArr.toString()} />)
              }
            })}
          </Grid>
        </Grid>
        }
        {collectionMTAs.optional_collection_mta_info.length > 0 &&
        <Grid item xs={8} className={classes.optColumn}>
          <Grid container>
            <Grid item xs={12} className={classes.headerInfoBlock}>
                            Optional
            </Grid>
            <Grid item xs={12}>
              <Grid container>
                <Grid item xs={6}>
                  {collectionMTAs.optional_collection_mta_info.map((option, key) => {
                    if (cutOff < key) {
                      const curValueObj = _.find(groupDetails.collection_themes, (n) => { return n.id === option.id })
                      let tempArr = []
                      if (curValueObj) {
                        curValueObj.values.map((opt) => {
                          tempArr.push(opt.name)
                        })
                      }
                      return (<HeaderInfo attr={option.name} value={tempArr.toString()} />)
                    }
                  })}
                </Grid>
                <Grid item xs={6}>
                  {collectionMTAs.optional_collection_mta_info.map((option, key) => {
                    if (cutOff >= key) {
                      const curValueObj = _.find(groupDetails.collection_themes, (n) => { return n.id === option.id })
                      let tempArr = []
                      if (curValueObj) {
                        curValueObj.values.map((opt) => {
                          tempArr.push(opt.name)
                        })
                      }
                      return (<HeaderInfo attr={option.name} value={tempArr.toString()} />)
                    }
                  })}
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
        }
      </Grid>
    )
  }
}

MTAsList.propTypes = {
  classes: PropTypes.object.isRequired,
}

// export default LoadingHOC(['collectionMTAs'])(withStyles(styles)(MTAsList))
export default withStyles(styles)(MTAsList)
