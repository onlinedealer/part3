import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, fakeAsync, TestBed } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { DropdownModule } from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { ProgressIndicatorStateService } from '../../../shared/components/progress-indicator/progress-indicator-state.service';
import { PipelineEntityService } from '../shared/pipeline-entity.service';
import { PipelineGeneralComponent } from './pipeline-general.component';

describe('PipelineGeneralComponent', () => {
  let component: PipelineGeneralComponent;
  let fixture: ComponentFixture<PipelineGeneralComponent>;
  const mockProgressIndicatorStateService = jasmine.createSpyObj<Partial<ProgressIndicatorStateService>>(
    'mockProgressIndicatorStateService',
    ['setIsValid']
  );
  let pipelineEntityService: PipelineEntityService;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PipelineGeneralComponent],
      imports: [getTranslocoModule(), FormsModule, ReactiveFormsModule, RadioButtonModule, DropdownModule],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'pipelines' } },
        { provide: ProgressIndicatorStateService, useValue: mockProgressIndicatorStateService }
      ]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PipelineGeneralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    pipelineEntityService = TestBed.inject(PipelineEntityService);
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should display copy options', () => {
    component.generalForm.patchValue({ type: 'COPY' });
    expect(component.displayCopyOptions()).toBe(true);
  });

  it('should display replicate options', () => {
    component.generalForm.patchValue({ type: 'REPLICATE' });
    expect(component.displayReplicationOptions()).toBe(true);
  });

  it('should update pipeline entity when form values change', fakeAsync(() => {
    spyOn(pipelineEntityService, 'patchPipeline').and.stub();

    // Check that initial setting of form is handled correctly
    component.generalForm.patchValue({
      name: 'name',
      description: 'description',
      dataFlowType: 'SYNCHRONIZE',
      transactionErrorMode: 'IGNORE_DELETE_CONTINUE',
      errorMode: 'TERMINATE_RUN',
      sourceIsolationLevel: 'READ_COMMITTED',
      sourceLocking: 'INDIVIDUAL_TABLE',
      sourceTableRetrievalOrder: 'ANY_ORDER'
    });

    expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith(
      jasmine.objectContaining({
        name: 'name',
        description: 'description',
        dataFlowType: 'SYNCHRONIZE',
        properties: [
          ...component.possibleKeys,
          { key: 'REPLICATION_TRANSACTION_ERROR_MODE', value: 'IGNORE_DELETE_CONTINUE' },
          { key: 'COPY_ERROR_MODE', value: 'TERMINATE_RUN' },
          { key: 'COPY_SOURCE_ISOLATION_LEVEL', value: 'READ_COMMITTED' },
          { key: 'COPY_SOURCE_LOCKING', value: 'INDIVIDUAL_TABLE' },
          { key: 'COPY_SOURCE_TABLE_RETRIEVE_ORDER', value: 'ANY_ORDER' }
        ]
      })
    );

    // Check that form value changes are handled correctly
    component.generalForm.patchValue({
      name: 'new name',
      description: 'new description',
      dataFlowType: 'COPY',
      transactionErrorMode: 'SHUT_DOWN_APPLY',
      errorMode: 'NEXT_TABLE',
      sourceIsolationLevel: 'SERIALIZABLE',
      sourceLocking: 'ALL_TABLES',
      sourceTableRetrievalOrder: 'MAPPING_ORDER'
    });

    expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith(
      jasmine.objectContaining({
        name: 'new name',
        description: 'new description',
        dataFlowType: 'COPY',
        properties: [
          ...component.possibleKeys,
          { key: 'COPY_ERROR_MODE', value: 'NEXT_TABLE' },
          { key: 'COPY_SOURCE_ISOLATION_LEVEL', value: 'SERIALIZABLE' },
          { key: 'COPY_SOURCE_LOCKING', value: 'ALL_TABLES' },
          { key: 'COPY_SOURCE_TABLE_RETRIEVE_ORDER', value: 'MAPPING_ORDER' }
        ]
      })
    );
  }));

  it('updates replication pipes without copy properties', () => {
    spyOn(pipelineEntityService, 'patchPipeline').and.stub();

    // Check that initial setting of form is handled correctly
    component.generalForm.patchValue({
      name: 'new name',
      description: 'new description',
      dataFlowType: 'REPLICATE',
      transactionErrorMode: 'IGNORE_DELETE_CONTINUE'
    });

    expect(pipelineEntityService.patchPipeline).toHaveBeenCalledWith(
      jasmine.objectContaining({
        name: 'new name',
        description: 'new description',
        dataFlowType: 'REPLICATE',
        properties: [...component.possibleKeys, { key: 'REPLICATION_TRANSACTION_ERROR_MODE', value: 'IGNORE_DELETE_CONTINUE' }]
      })
    );
  });

  describe('loading a pipeline', () => {
    it('should set form field values', () => {
      spyOn(pipelineEntityService, 'getPipeline').and.returnValue({
        name: 'name',
        description: 'description',
        dataFlowType: 'SYNCHRONIZE',
        properties: [
          { key: 'REPLICATION_TRANSACTION_ERROR_MODE', value: 'SHUT_DOWN_APPLY' },
          { key: 'COPY_ERROR_MODE', value: 'NEXT_TABLE' },
          { key: 'COPY_SOURCE_ISOLATION_LEVEL', value: 'SERIALIZABLE' },
          { key: 'COPY_SOURCE_LOCKING', value: 'ALL_TABLES' },
          { key: 'COPY_SOURCE_TABLE_RETRIEVE_ORDER', value: 'MAPPING_ORDER' }
        ],
        filters: []
      });

      component.ngOnInit();

      expect(component.generalForm.value).toEqual({
        name: 'name',
        description: 'description',
        dataFlowType: 'SYNCHRONIZE',
        transactionErrorMode: 'SHUT_DOWN_APPLY',
        errorMode: 'NEXT_TABLE',
        sourceIsolationLevel: 'SERIALIZABLE',
        sourceLocking: 'ALL_TABLES',
        sourceTableRetrievalOrder: 'MAPPING_ORDER'
      });
    });
  });
});
