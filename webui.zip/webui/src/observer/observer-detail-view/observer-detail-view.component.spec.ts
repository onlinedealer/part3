import { ComponentFixture, TestBed } from '@angular/core/testing';
import { ActivatedRoute } from '@angular/router';
import { SecondaryNavItemsService, SharedModule } from 'discovery-shared';
import { Spies } from 'discovery-test';

import { CommonModule } from '@angular/common';
import { RouterTestingModule } from '@angular/router/testing';
import { TranslocoModule } from '@ngneat/transloco';
import { TranslocoLocaleModule } from '@ngneat/transloco-locale';
import { SecondaryNavModule } from '@precisely/prism-ng/secondary-nav';
import { ObserverService } from 'observer/observer.service';
import { ObserverDetailViewComponent } from './observer-detail-view.component';

describe('ObserverDetailViewComponent', () => {
  let component: ObserverDetailViewComponent;
  let fixture: ComponentFixture<ObserverDetailViewComponent>;
  let mockSecNav = jasmine.createSpyObj('SecondaryNavItemsService', ['getNavItems']);
  let mockObserverService;

  beforeEach(async () => {
    Spies.init();
    await TestBed.configureTestingModule({
      declarations: [ObserverDetailViewComponent],
      imports: [
        CommonModule,
        TranslocoModule,
        TranslocoLocaleModule.forRoot(),
        SecondaryNavModule,
        RouterTestingModule,
        SharedModule
      ],
      providers: [
        { provide: ObserverService, useValue: Spies.ObserverService },
        {
          provide: ActivatedRoute,
          useValue: {
            snapshot: {
              paramMap: {
                get: (key: string) => {
                  switch (key) {
                    case 'observerName':
                      return 'weeklytest';
                    case 'observerId':
                      return '62d908bc0e48481a1fef9f5c';
                  }
                }
              },
              queryParams: {
                runId: '8a8a2d72854d42d101854da7faba0b83',
                profileId: '8a8a8254827c631a01827c6a936000cd'
              }
            },
            children: [{ snapshot: { data: { tabIndex: 0 } } }]
          }
        },
        { provide: SecondaryNavItemsService, useValue: mockSecNav }
      ]
    }).compileComponents();
    mockSecNav.getNavItems.and.returnValue([]);
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ObserverDetailViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should change tab on click header', () => {
    let event = { index: 1 };
    component.onChange(event);
    expect(component.selectedTabIndex).toEqual(1);
  });

  it('should change tab on click header', () => {
    let event = { index: 0 };
    component.onChange(event);
    expect(component.selectedTabIndex).toEqual(0);
  });

  it('should call edit button click', () => {
    component.onEditClick();
  });

  it('get runID details from observer on reload if not available', () => {
    component.runId = undefined;
    component.selectedTabIndex = 1;
    component.observerId = '62f0bf1f8df29877aab81c25';
    component.getLastRunData();
    expect(component.runId).toBe('8a8a04cd855cb2b701855d1c00c402f6');
  });
});
