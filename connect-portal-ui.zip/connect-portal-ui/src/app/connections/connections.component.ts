import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { BreadcrumbItem } from '@shared/components/breadcrumb/breadcrumb-item';
import { DeleteSidebarConfiguration } from '@shared/components/delete-sidebar/delete-sidebar-configuration';
import { TableConfiguration, TableField, TableMessage, TableMessageType } from '@shared/components/generic-table/generic-table';
import { FeatureFlagService } from '@shared/services/feature-flag.service';
import { ResourcePermissionService } from '@shared/services/resource-permission.service';
import { MenuItem } from 'primeng/api';
import { forkJoin, of, Subject } from 'rxjs';
import { catchError, map, mergeMap } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { AgentsApiService } from '../agents/shared/agents-api.service';
import { BaseComponent } from '../core/base.component';
import { CatalogApiService } from './catalogs/shared/catalog-api.service';
import { CatalogStatusSummary } from './catalogs/shared/catalog-status-summary';
import { ConnectionSidebarComponent } from './connection-sidebar/connection-sidebar.component';
import { Connection } from './shared/connection';
import { ConnectionsApiService } from './shared/connections-api.service';

/**
 * Component used to manage connections.
 */
@Component({
  selector: 'p-connect-connections',
  templateUrl: './connections.component.html',
  styleUrls: ['./connections.component.scss']
})
export class ConnectionsComponent extends BaseComponent implements OnInit, OnDestroy {
  @ViewChild(ConnectionSidebarComponent) connectionSidebarComponent: ConnectionSidebarComponent;

  /**
   * Bread crumb items
   */
  breadcrumbs: BreadcrumbItem[] = [
    { text: 'common.BREADCRUMBS.APP_ROOT', isActive: true },
    { text: 'common.BREADCRUMBS.CONNECTIONS', isActive: true }
  ];

  /**
   * List of fields that are displayed in the table.
   */
  fields: TableField[] = [
    {
      header: 'connections.CONNECTIONS_TABLE.COLUMNS.NAME',
      name: 'name',
      isInDeleteModal: true,
      isSearchable: true,
      columnStyle: { width: '20rem', minWidth: '20rem' }
    },
    {
      header: 'connections.CONNECTIONS_TABLE.COLUMNS.CONNECTION_TYPE',
      name: 'connectionTypeFriendlyName',
      isInDeleteModal: true,
      isSearchable: true
    },
    {
      header: 'connections.CONNECTIONS_TABLE.COLUMNS.CATALOGED',
      isSearchable: true,
      isInDeleteModal: true,
      name: 'catalogStatus'
    },
    {
      isHidden: true,
      header: 'connections.CONNECTIONS_TABLE.COLUMNS.ACCESS_METHOD',
      isSearchable: true,
      isInDeleteModal: true,
      name: 'accessMethod'
    },
    { header: 'connections.CONNECTIONS_TABLE.COLUMNS.DATABASE', isSearchable: true, isInDeleteModal: true, name: 'database' },
    { header: 'connections.CONNECTIONS_TABLE.COLUMNS.SERVER', isSearchable: true, name: 'accessFromServer.name' },
    { header: 'connections.CONNECTIONS_TABLE.COLUMNS.DESCRIPTION', isSearchable: true, name: 'description' },
    { header: 'connections.CONNECTIONS_TABLE.COLUMNS.AGENT', isSearchable: true, name: 'agentName' }
  ];

  /**
   * Table message for when there are no connections
   */
  emptyTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_CONNECTIONS_CONFIGURED.HEAD',
    messageCaption: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_CONNECTIONS_CONFIGURED.CAPTION'
  };

  /**
   * Table message for when there are no connections matching the search criteria
   */
  filterTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_FILTER_RESULTS.HEAD',
    messageCaption: 'connections.CONNECTIONS_TABLE.MESSAGES.NO_FILTER_RESULTS.CAPTION'
  };

  /**
   * Table message for when there is an error retrieving connections
   */
  errorTableMessage: TableMessage = {
    messageType: TableMessageType.ALERT,
    messageHead: 'connections.CONNECTIONS_TABLE.MESSAGES.ERROR.HEAD',
    messageCaption: 'connections.CONNECTIONS_TABLE.MESSAGES.ERROR.CAPTION'
  };

  toolbarMenuItems: MenuItem[] = [
    {
      id: 'deleteSelected',
      label: 'connections.CONNECTIONS_TABLE.BUTTONS.DELETE',
      command: () => {
        this.deleteSidebarConfiguration.targetItemsTableData = this.selectedConnections;
        this.deleteSidebarConfiguration.isSidebarVisible = true;
      },
      disabled: true,
      visible: this.resourcePermissionService.hasResourcePermission('CONNECTION.DELETE')
    }
  ];

  /**
   * Global actions for the table
   */
  actionDropdownMenuItems: MenuItem[] = [
    {
      id: 'manageCatalogMenuItem',
      label: 'connections.CONNECTIONS_TABLE.BUTTONS.MANAGE_CATALOG',
      command: (event) => {
        this.manageCatalogTargetConnection = event.item.target;
        this.isManageCatalogSidebarVisible = true;
      },
      visible: this.resourcePermissionService.hasResourcePermission('CONNECTION.MANAGE_CATALOG')
    },
    { separator: true },
    {
      id: 'editMenuItem',
      label: 'common.BUTTONS.EDIT',
      command: (event) => {
        this.isConnectionSidebarVisible = true;
        this.connectionSidebarComponent.openConnection(event.item.target.id);
      },
      visible: this.resourcePermissionService.hasResourcePermission('CONNECTION.EDIT')
    },
    {
      id: 'deleteMenuItem',
      label: 'connections.CONNECTIONS_TABLE.BUTTONS.DELETE',
      command: (event) => {
        this.deleteSidebarConfiguration.targetItemsTableData = [event.item.target];
        this.deleteSidebarConfiguration.isSidebarVisible = true;
      },
      visible: this.resourcePermissionService.hasResourcePermission('CONNECTION.DELETE')
    }
  ];

  /**
   * Connections table configuration
   */
  tableConfiguration: TableConfiguration = {
    isLoading: false,
    visibleRows: 25,
    fields: this.fields,
    isFilterShown: true,
    styleClass: 'connections-table',
    rowAction: {
      fieldIndex: 0,
      menuItems: this.actionDropdownMenuItems
    },
    tableToolbar: {
      style: { width: '23rem', height: '60px' },
      menuItems: this.toolbarMenuItems
    },
    tableMessages: {
      emptyTableMessage: this.emptyTableMessage,
      filterTableMessage: this.filterTableMessage,
      errorTableMessage: this.errorTableMessage
    },
    primaryButtonText: this.resourcePermissionService.hasResourcePermission('CONNECTION.ADD')
      ? 'connections.CONNECTIONS_TABLE.BUTTONS.ADD'
      : undefined,
    createButtonClicked: () => {
      this.connectionSidebarComponent.openConnection(null);
      this.isConnectionSidebarVisible = true;
    },
    rowSelectionChangedEvent: (checkedItems: Connection[]) => {
      this.selectedConnections = checkedItems;
    },
    menuItemDisabled: (menuItem: MenuItem, row: any) => {
      if (menuItem.id === 'deleteSelected') {
        return !this.selectedConnections || this.selectedConnections.length === 0;
      }
      return false;
    }
  };

  /**
   * Delete completion event handler
   */
  deleteCompleted: Subject<any> = new Subject<any>();

  /**
   * Delete sidebar configuration
   */
  deleteSidebarConfiguration: DeleteSidebarConfiguration = {
    isSidebarVisible: false,
    targetItemsTableData: [],
    targetItemsFieldList: this.fields.filter((field) => !field.isHidden),
    sidebarTitle: 'connections.DELETE_CONNECTION_DIALOG.HEADING',
    bodyText: 'connections.DELETE_CONNECTION_DIALOG.MESSAGE',
    deleteButtonText: 'connections.DELETE_CONNECTION_DIALOG.BUTTONS.DELETE',
    deleteFailedText: 'connections.DELETE_CONNECTION_DIALOG.ERRORS.DELETE_FAILED_MESSAGE',
    hideConfirmationColumn: true,
    deleteCompletedEvent: this.deleteCompleted.asObservable(),
    deleteButtonClicked: ($event) => {
      this.onDeleteButtonClicked($event as Connection[]);
    }
  };

  refreshCatalogDataTimeout: NodeJS.Timeout;

  isConnectionSidebarVisible = false;
  isManageCatalogSidebarVisible = false;

  supportedConnectionTypes: string[] = [];

  manageCatalogTargetConnection: Connection;
  selectedConnections: Connection[];
  connections = [];

  /** @internal */
  constructor(
    private readonly connectionsApiService: ConnectionsApiService,
    private readonly catalogApiService: CatalogApiService,
    private readonly resourcePermissionService: ResourcePermissionService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly agentsService: AgentsApiService
  ) {
    super();
  }

  /** @internal */
  ngOnInit(): void {
    this.getConnectionsData();
    this.updateAutoRefreshTimeout();
    this.setConnectionTypeOptions();
  }

  ngOnDestroy(): void {
    clearInterval(this.refreshCatalogDataTimeout);
  }

  /**
   * Event handler for the saved connection event on the connection sidebar
   * @param event
   */
  onConnectionSavedEvent(event) {
    this.getConnectionsData();
  }

  /**
   * Deletes connections and refreshes the table
   * @param connections - connections to be deleted
   */
  private onDeleteButtonClicked(connections: Connection[]): void {
    const connectionIds = connections.map((connection) => connection.id);
    this.connectionsApiService
      .delete(connectionIds)
      .pipe(
        mergeMap((deletedConnection) =>
          this.catalogApiService.deleteCatalogs(connectionIds).pipe(
            map(() => deletedConnection),
            catchError(() => of(deletedConnection))
          )
        )
      )
      .subscribe({
        next: (response) => {
          this.getConnectionsData();
          this.deleteCompleted.next(response);
        },
        error: (error) => {
          this.deleteCompleted.next(error);
        }
      });
  }

  /**
   * Get the data for the table.
   * Joins together information from the connections, agents, and cataloged status for display.
   */
  private getConnectionsData(): void {
    this.tableConfiguration.isLoading = true;

    forkJoin({
      connectionsList: this.connectionsApiService.getAll().pipe(
        mergeMap((connections) =>
          this.catalogApiService.statusSummary(connections.map((connection) => connection.id)).pipe(
            map((status: CatalogStatusSummary[]) => ({ connections, status })),
            catchError(() => of({ connections, status: [] }))
          )
        )
      ),
      agentsList: this.agentsService.getAll()
    })
      .pipe(
        map((data) => {
          return data.connectionsList.connections.map((connection) => ({
            ...connection,
            connectionTypeFriendlyName: `connections.CONNECTION_TYPES.${connection.connectionType}`,
            agentName: data.agentsList.find((agent) => agent.agentId === connection.accessFromServer.agentId)?.agentName || '-',
            catalogStatus: data.connectionsList.status.find((status) => status.connectionId === connection.id)
          }));
        })
      )
      .subscribe((data) => {
        this.connections = data;
      })
      .add(() => {
        this.tableConfiguration.isLoading = false;
      });
  }

  /**
   * Sets the connection type options for the connection sidebar
   */
  private setConnectionTypeOptions(): void {
    const supportedConnectionTypes = environment.supportedSourceConnectionTypes.concat(environment.supportedTargetConnectionTypes);
    this.supportedConnectionTypes = supportedConnectionTypes.map((supportedConnection) => {
      return supportedConnection.connectionType;
    });

    if (!this.featureFlagService.isFeatureDisabled('SL')) {
      this.supportedConnectionTypes.push('CDC');
    }
    if (!this.featureFlagService.isFeatureEnabled('CDCEnableDB2LUWTemp20220407')) {
      this.supportedConnectionTypes.splice(this.supportedConnectionTypes.indexOf('DB2'), 1);
    }
    if (!this.featureFlagService.isFeatureEnabled('CDCEnableSQLTemp20220407')) {
      this.supportedConnectionTypes.splice(this.supportedConnectionTypes.indexOf('SQLSERVER'), 1);
    }
    if (!this.featureFlagService.isFeatureEnabled('CDCKafkaSchemaRegistryTemp20220628')) {
      this.supportedConnectionTypes.splice(this.supportedConnectionTypes.indexOf('SCHEMAREGISTRY'), 1);
    }
  }

  private updateAutoRefreshTimeout(): void {
    this.refreshCatalogDataTimeout = setInterval(() => {
      this.getConnectionsData();
    }, 30000);
  }
}
