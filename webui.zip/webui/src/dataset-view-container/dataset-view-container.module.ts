import { NgModule } from '@angular/core';
import { DatasetViewContainerComponent } from './dataset-view-container.component';
import { DatasetViewContainerRoutingModule } from './dataset-view-container-routing.module';
import { DatasetViewModule } from 'dqcore-catalog';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { SharedModule } from 'discovery-shared';
import { catalogLoader, datasetViewLoader, sharedLoader } from 'core/i18n-loaders';

@NgModule({
  declarations: [DatasetViewContainerComponent],
  imports: [SharedModule, DatasetViewContainerRoutingModule, DatasetViewModule],
  providers: [
    {
      provide: TRANSLOCO_SCOPE,
      useValue: [
        { scope: 'discoveryDatasetView', loader: datasetViewLoader },
        { scope: 'discoveryShared', loader: sharedLoader },
        { scope: 'catalog', loader: catalogLoader }
      ]
    }
  ]
})
export class DatasetViewContainerModule {}
