import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class NameValidatorService {
  /**
   *
   */
  private static readonly nameRegex: string = '^[^ -@[-`{-~][^!-,./:-@[-^{-~`]*$';

  /**
   *
   * @param name
   */
  static validateName(name: string): boolean {
    return !name || new RegExp(this.nameRegex).test(name);
  }
}
