import { promptToSignIn, signOut } from '../../store/auth'
import axios from 'axios'
import { connect } from 'react-redux'
import React from 'react'
import { showNotification } from '../../store/notification/actionCreator'

/*

Interceptor adds useful handlers to axios requests and responses.

If the user has an accessToken, it is used as the value for the
Authorization header. This applies to all requests to .target.com and
.tgt domains. You can disable this per request by passing in this config:
{headers: {Authorization: false}}

If an axios response is an error, it is handled based on the error code:
- 401: prompt the user to sign in
- 403: notify the user that they don't have permission to do that
- Other: show the axios error message to the user

When the component unmounts, the interceptors are removed.

*/
export class Interceptor extends React.Component {
  static state = {
    authInterceptor: undefined,
    errorInterceptor: undefined,
  }

  componentDidMount () {
    this.addAuthInterceptor()
    this.addErrorInterceptor()
  }

  componentWillUnmount () {
    this.removeAuthInterceptor()
    this.removeErrorInterceptor()
  }

  addAuthInterceptor = () => {
    const authInterceptor = axios.interceptors.request.use(config => {
      if (!config.headers.hasOwnProperty('Authorization')) {
        if (this.props.accessToken && this.isTargetDomain(config.url)) {
          config.headers.Authorization = this.props.accessToken
        }
      } else if (!config.headers.Authorization) {
        delete config.headers.Authorization
      }
      return config
    }, error => {
      return Promise.reject(error)
    })
    this.setState({authInterceptor})
  }

  removeAuthInterceptor = () => {
    axios.interceptors.request.eject(this.state.authInterceptor)
    this.setState({authInterceptor: undefined})
  }

  addErrorInterceptor = () => {
    const errorInterceptor = axios.interceptors.response.use(response => {
      return response
    }, error => {
      if (error.response) {
        const code = error.response.status
        if (code === 401) {
          this.props.promptToSignIn()
        } else {
          let message = 'Something went wrong.'
          if (code === 403) {
            message = 'You’re not authorized to do that.'
          } else if (error.message) {
            message = error.message
          }
          this.props.showNotification(true, message)
        }
      }
      return Promise.reject(error)
    })
    this.setState({errorInterceptor})
  }

  removeErrorInterceptor = () => {
    axios.interceptors.request.eject(this.state.errorInterceptor)
    this.setState({errorInterceptor: undefined})
  }

  // hostname ends with .target.com or .tgt
  isTargetDomain = url => {
    return /^([^/]+:)?\/{2,3}[^/]+?(\.target\.com|\.tgt)(:|\/|$)/i.test(url)
  }

  render () { return null }
}

const mapStateToProps = ({auth}) => ({
  accessToken: auth.accessToken,
})

const mapDispatchToProps = {
  promptToSignIn,
  showNotification,
  signOut,
}

export default connect(mapStateToProps, mapDispatchToProps)(Interceptor)
