(function() {
    'use strict';

    fileuploader.controller("dashboardCtrl", ['$scope', '$ajaxFactory', '$rootScope', 'uiRouters', dashboardCtrl]);

    function dashboardCtrl($scope, $ajaxFactory, $rootScope, uiRouters) {

        $scope.dropdownselect1 = $rootScope.dropdownselect;

        $scope.textoutput = "";
        $scope.uploadpreview = "";

        $scope.selectedTemplate = $rootScope.dropdownSelect;
        var dropdrop = $rootScope.selectedId;
        console.log(dropdrop)

        // Function to Preview the uploaded file
        $scope.fetchpreviewData = function() {

            var id = $rootScope.globalId;
            var url = "http://10.3.48.137:8090/ocr/rest/v1/service/get/tiffimage/tiff/file/5729cf10e01a2730b996a4ee";
            //var url = "http://localhost:8090/ocr/rest/v1/service/get/tiffimage/tiff/file/" + id;
            console.log(url)

            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            promise.then(function(d) {
                $scope.uploadpreview = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);

            });

        }
        $scope.fetchpreviewData();

        // function to display the out as the text in textarea
        $scope.fetchoutputData = function() {

            var id = $rootScope.globalId;

            var url = "http://localhost:8090/ocr/rest/v1/service/get/text/tiff/file/" + id;
            console.log(url)

            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            promise.then(function(d) {
                $scope.textoutput = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);

            });

        }
        $scope.fetchoutputData();


        /*// Function for dropdown
      $scope.fetchdropdownData = function() {

            //var url = "/get/list/of/data/for/" + "/";
            var promise = $ajaxFactory.getDataFromServer(uiRouters.filepath + '/template.json', 'GET', {});
           // var promise = $ajaxFactory.getDataFromServer(uiRouters.urlpath + url, 'GET', {});

            promise.then(function(d) {
                $scope.testdropdown = d;
            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);
               
            });

        }
    $scope.fetchdropdownData();*/


        $scope.exportdoc = function() {
            var id = $rootScope.globalId;

            var url = "http://localhost:8090/ocr/rest/v1/service/get/text/tiff/file/" + id;
            console.log(url)

            var promise = $ajaxFactory.getDataFromServer(url, 'GET', {});

            promise.then(function(d) {

            });
            promise.catch(function(d) {
                console.log('catch block executed', d);
                return d;
            });
            promise.finally(function(d) {
                console.log('finally block executed', d);

            });


        }



        var data = [
            ["", "Ford", "Volvo", "Toyota", "Honda", "Volvo", "Toyota", "Honda"],
            ["2016", 10, 11, 12, 13],
            ["2017", 20, 11, 14, 13],
            ["2018", 30, 15, 12, 13]
        ];

        var container = document.getElementById('example1grid');
        var hot = new Handsontable(container, {
            data: data,
            rowHeaders: true,
            colHeaders: true
        });


    }


})();