import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ControlContainer, FormControl, FormGroup, Validators } from '@angular/forms';
import { Connection } from '../../../../connections/shared/connection';
import { Metabase } from '../../../shared/metabase.model';

export enum DB2_METABASE_PARAMETERS {
  REPLICATION_USER_ID = 'REPLICATION_USER_ID',
  REPLICATION_USER_PASSWORD = 'REPLICATION_USER_PASSWORD'
}

/**
 * Partial form for creating metabases for DB2 data connections
 */
@Component({
  selector: 'p-connect-db2-metabase-form',
  templateUrl: './db2-metabase-form.component.html'
})
export class DB2MetabaseFormComponent implements OnInit, OnDestroy {
  db2MetabaseForm: FormGroup;

  /**
   * Data connection that applies to this form
   */
  @Input() dataConnection: Connection;

  constructor(private readonly controlContainer: ControlContainer) {}

  ngOnInit() {
    this.configureForm();
    if (this.dataConnection) {
      this.db2MetabaseForm.get('databaseServer').setValue(`${this.dataConnection.database}:${this.dataConnection.port}`);
    }
  }

  ngOnDestroy() {
    this.removeForm();
  }

  /**
   * Removes form and any form specific translations or validation
   */
  private removeForm(): void {
    if (this.db2MetabaseForm) {
      this.db2MetabaseForm.clearValidators();
      this.db2MetabaseForm.updateValueAndValidity();

      Object.keys(this.db2MetabaseForm.controls).forEach((key) => {
        if (key !== 'dataConnection') {
          this.db2MetabaseForm.removeControl(key);
        }
      });
    }
  }

  get metabase(): Metabase {
    return {
      name: this.db2MetabaseForm.get('metabaseName').value.toUpperCase(),
      adminUserId: this.db2MetabaseForm.get('userID').value,
      adminUserPassword: this.db2MetabaseForm.get('password').value,
      dataConnection: {
        id: (this.db2MetabaseForm.get('dataConnection').value as Connection).id,
        accessFromServer: (this.db2MetabaseForm.get('dataConnection').value as Connection).accessFromServer
      },
      parameters: [
        {
          key: DB2_METABASE_PARAMETERS.REPLICATION_USER_ID,
          value: this.db2MetabaseForm.get('replicationUserID').value
        },
        {
          key: DB2_METABASE_PARAMETERS.REPLICATION_USER_PASSWORD,
          value: this.db2MetabaseForm.get('replicationPassword').value
        }
      ]
    } as Metabase;
  }

  /**
   * setup the form for the DB2 metabase
   */
  private configureForm(): void {
    this.db2MetabaseForm = this.controlContainer.control as FormGroup;
    this.db2MetabaseForm.addControl('databaseServer', new FormControl({ value: '', disabled: true }));
    this.db2MetabaseForm.addControl('userID', new FormControl('', Validators.required));
    this.db2MetabaseForm.addControl('password', new FormControl('', Validators.required));
    this.db2MetabaseForm.addControl('replicationUserID', new FormControl('', Validators.required));
    this.db2MetabaseForm.addControl('replicationPassword', new FormControl('', Validators.required));
    this.db2MetabaseForm.addControl('metabaseName', new FormControl('RPUSER'));
  }
}
