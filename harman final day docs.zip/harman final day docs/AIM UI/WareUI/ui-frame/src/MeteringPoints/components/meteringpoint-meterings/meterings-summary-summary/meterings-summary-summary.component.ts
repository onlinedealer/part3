import { Component, OnInit, Input } from "@angular/core";
import { ExportCsvService } from "../../../services/summaryview-export-csv-service";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { Observable, Subscription } from "rxjs";
import { ProfileDataSelectors } from "../../../store/selectors";
import { Store } from "@ngrx/store";
import { SummaryTableVO } from "../../../models/view-objects/summarytable-vo.model";
import { TranslationsService } from "../../../../app/services/translations-service";

@Component({
    selector: "landisgyr-meterings-summary-summary",
    templateUrl: "./meterings-summary-summary.component.html",
    styleUrls: ["./meterings-summary-summary.component.scss"]
})
export class MeteringsSummarySummaryComponent implements OnInit {
    maximumValue = 0;
    minimumValue = 0;
    valuesSummed!: number;
    summaryViewSubscription!: Subscription;
    exportCsvData: any;
    summaryViewTableHeader: any;
    summaryViewHeader: any;
    summaryViewValues: any;
    noDataToExport = false;
    profileMeteringsTableForSummary$: Observable<SummaryTableVO> = this.store.select(
        ProfileDataSelectors.getSelectedProfileDataForSummaryView
    );
    @Input() meteringsProfileDataWithOnlyValues!: any;
    constructor(
        public translations: TranslationsService,
        private store: Store<MeteringPointsFeatureState>,
        private exportCsvService: ExportCsvService
    ) {}
    ngOnInit(): void {
        this.transformForPeriodSummary(this.meteringsProfileDataWithOnlyValues);
    }
    transformForPeriodSummary(data: number[]) {
        if (data === undefined || data.length === 0) {
            this.maximumValue = 0;
            this.minimumValue = 0;
            this.valuesSummed = 0;
        } else {
            this.maximumValue = Math.max(...data);
            this.minimumValue = Math.min(...data);
            this.valuesSummed = data.reduce((a, b) => a + b, 0);
            this.valuesSummed = Math.round(this.valuesSummed * 100) / 100;
        }
    }

    exportToCsv() {
        this.summaryViewSubscription = this.profileMeteringsTableForSummary$.subscribe(data => {
            this.exportCsvData = data;
            let countOfUndefinedValues = 0;
            let timeLabelCount = 0;
            const rowArray: string[] = [];
            const summaryViewHeader: any[] = [];
            for (let i = 0; i < this.exportCsvData.dates.length; i++) {
                this.summaryViewTableHeader = this.exportCsvData.dates[i].dateMonth;
                summaryViewHeader.push(this.summaryViewTableHeader);
            }
            for (let j = 0; j < this.exportCsvData.rows.length; j++) {
                rowArray[j] = this.exportCsvData.rows[j].label;
                for (let k = 0; k < this.exportCsvData.rows[j].values.length; k++) {
                    const row = this.exportCsvData.rows[j].values[k].value === undefined ? " " : this.exportCsvData.rows[j].values[k].value;
                    rowArray[j] += "," + row;
                    countOfUndefinedValues++;
                }
                timeLabelCount++;
            }
            countOfUndefinedValues = countOfUndefinedValues - timeLabelCount;
            this.summaryViewHeader = summaryViewHeader;
            this.summaryViewValues = rowArray;
            let counts = 0;
            this.summaryViewValues.forEach(function(ele: any) {
                const splitData = ele.split(",");
                splitData.forEach(function(realCount: any) {
                    if (realCount === " ") {
                        counts++;
                    }
                });
                counts--;
            });
            if (counts === countOfUndefinedValues) {
                this.noDataToExport = true;
            } else {
                this.noDataToExport = false;
                return this.exportCsvService.downloadFile(this.summaryViewHeader, this.summaryViewValues, "SummaryView");
            }
        });
        this.summaryViewSubscription.unsubscribe();
    }
}
