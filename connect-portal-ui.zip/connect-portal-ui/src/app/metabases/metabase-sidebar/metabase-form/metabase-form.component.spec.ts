import { HttpClientTestingModule } from '@angular/common/http/testing';
import { Component, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { ComponentFixture, TestBed, waitForAsync } from '@angular/core/testing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TRANSLOCO_SCOPE } from '@ngneat/transloco';
import { CheckboxModule } from 'primeng/checkbox';
import { DropdownModule } from 'primeng/dropdown';
import { RadioButtonModule } from 'primeng/radiobutton';
import { of } from 'rxjs';
import { Connection } from '../../../connections/shared/connection';
import { ConnectionsApiService } from '../../../connections/shared/connections-api.service';

import { getTranslocoModule } from '../../../core/transloco-testing.module';
import { ServerSidebarComponent } from '../../../servers/server-sidebar/server-sidebar.component';
import { DynamicHostDirective } from '../../../shared/directives/dynamic-host.directive';
import { DB2IMetabaseFormComponent } from './db2i-metabase-form/db2i-metabase-form.component';

import { MetabaseFormComponent } from './metabase-form.component';
import { OracleMetabaseFormComponent } from './oracle-metabase-form/oracle-metabase-form.component';

describe('MetabaseFormComponent', () => {
  let component: MetabaseFormComponent;
  let fixture: ComponentFixture<MetabaseFormComponent>;
  let connectionService: ConnectionsApiService;

  const mockConnections = [
    { id: '1', name: 'ORACLE', connectionType: 'ORACLE', accessMethod: 'JDBC', parameters: [] } as Connection,
    {
      id: '2',
      name: 'DB2I',
      connectionType: 'DB2I',
      accessMethod: 'JDBC',
      parameters: [{ key: 'DB2_I_ENABLE_IASP', value: 'YES' }]
    } as Connection,
    { id: '3', name: 'DB2ZOS', connectionType: 'DB2ZOS', accessMethod: 'JDBC', parameters: [] } as Connection
  ];
  @Component({
    selector: 'p-connect-metabase-sidebar',
    template: ''
  })
  class MockServerSideBarComponent {}

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [
        FormsModule,
        ReactiveFormsModule,
        DropdownModule,
        CheckboxModule,
        RadioButtonModule,
        HttpClientTestingModule,
        getTranslocoModule()
      ],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
      providers: [
        { provide: TRANSLOCO_SCOPE, useValue: { scope: 'metabases' } },
        { provide: ServerSidebarComponent, useValue: MockServerSideBarComponent }
      ],
      declarations: [MetabaseFormComponent, OracleMetabaseFormComponent, DB2IMetabaseFormComponent, DynamicHostDirective]
    }).compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MetabaseFormComponent);
    component = fixture.componentInstance;
    connectionService = TestBed.inject(ConnectionsApiService);
    spyOn(connectionService, 'getAll').and.returnValue(of(mockConnections));
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should load metabases list and disable the data connection field', waitForAsync(() => {
    component.selectedDataConnection = mockConnections[0];
    component.ngOnInit();
    fixture.whenStable().then(() => {
      expect(component.selectedConnection.value.id).toBe('1');
      expect(component.metabaseFormGroup.get('dataConnection').disabled).toBe(true);
    });
  }));

  it('should load new metabase form when connection type changes', waitForAsync(() => {
    fixture.whenStable().then(() => {
      component.metabaseFormGroup.patchValue({
        dataConnection: mockConnections[1]
      });
      fixture.detectChanges();
      expect(component.selectedConnection.value.id).toBe('2');
      expect(component.childComponentReference).toBeDefined();
    });
  }));

  it('should not load new metabase form if connection type is null', waitForAsync(() => {
    const oldSelection = component.selectedConnection;
    fixture.whenStable().then(() => {
      component.metabaseFormGroup.patchValue({
        dataConnection: null
      });
      fixture.detectChanges();
      expect(component.selectedConnection).toEqual(oldSelection);
    });
  }));

  it('should return metabase from child component', waitForAsync(() => {
    component.selectedDataConnection = mockConnections[0];
    component.ngOnInit();
    fixture.detectChanges();
    fixture.whenStable().then(() => {
      expect(component.childComponentReference).toBeDefined();
      expect(component.metabase).toBeDefined();
    });
  }));

  it('should expect dataConnections property to populate connection dropdown w/ list of created connections', () => {
    component.ngOnInit();
    expect(component.dataConnections.length).toBe(2);
  });
});
