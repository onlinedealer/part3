import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ProfileService } from '../../profile.service';
import { ProfilingRuleTreeNodeModel } from './profiling-rule-tree-node.model';
import { ToastrService } from 'ngx-toastr';
import { HttpErrorResponse } from '@angular/common/http';
import { ProfilingRuleTreeNodeType } from './profiling-rule-tree-node-type.enum';
import { ProfileConfigureModel } from '../profile-configure.model';
import { ProfilingRuleOptionType } from './profiling-rule-option-type.enum';
import { ProfileRuleModel } from 'profiling/profile-rule.model';
import { TranslocoService } from '@ngneat/transloco';

@Component({
  selector: 'discovery-profiling-rules',
  templateUrl: './profiling-rules.component.html',
  styleUrls: ['./profiling-rules.component.css']
})
export class ProfilingRulesComponent implements OnInit {
  /**
   *
   */
  @Output() selectedRulesListChange: EventEmitter<Map<string, Map<string, any>>> = new EventEmitter<
    Map<string, Map<string, any>>
  >();
  ruleTreeNodes: ProfilingRuleTreeNodeModel[];

  /**
   *
   */
  loadInProgress: boolean;
  ProfilingRuleOptionType = ProfilingRuleOptionType;
  showRuleSettingsSideBar: boolean = false;
  ruleModelForConfiguration = new ProfileRuleModel();

  private profileConfigureModel: ProfileConfigureModel;
  /**
   *
   * @param profileService
   * @param ngbModal
   * @param toastrService
   * @param translateService
   */
  constructor(
    private profileService: ProfileService,
    private ngbModal: NgbModal,
    private toastrService: ToastrService,
    private translocoService: TranslocoService
  ) {}

  /**
   *
   */
  ngOnInit(): void {
    this.loadInProgress = true;
    this.profileService.getRulesList().subscribe(
      (response) => {
        this.loadInProgress = false;
        this.ruleTreeNodes = [];
        for (const [index, profileRule] of response.entries()) {
          this.ruleTreeNodes.push(new ProfilingRuleTreeNodeModel(profileRule, index));
        }
        if (this.profileConfigureModel !== undefined) {
          this.updateRuleSelection();
        }
        this.updateSelectedRulesList();
      },
      (httpErrorResponse: HttpErrorResponse) => {
        this.loadInProgress = false;
        this.toastrService.error(
          this.translocoService.translate('discoveryProfiling.profilingRules.fetchRulesListFailed', {
            serverMessage:
              httpErrorResponse && httpErrorResponse.error && httpErrorResponse.error.message
                ? httpErrorResponse.error.message
                : ''
          })
        );
      }
    );
  }

  configureRule(ruleTreeNode: ProfilingRuleTreeNodeModel) {
    this.showRuleSettingsSideBar = true;
    this.ruleModelForConfiguration = ruleTreeNode.data;
  }

  ruleModelForConfigurationChanged(configuredRuleModel: ProfileRuleModel) {
    this.updateSelectedRulesList();
  }

  /**
   *
   * @param treeNode
   * @param level
   */
  nodeClicked(treeNode: ProfilingRuleTreeNodeModel, level: number) {
    if (treeNode.data.selected === false) {
      treeNode.data.selected = null;
    } else if (treeNode.data.selected === null) {
      treeNode.data.selected = true;
    }
    ProfilingRulesComponent.updateChildrenSelection(treeNode);
    ProfilingRulesComponent.updateParentSelection(treeNode);
    this.updateSelectedRulesList();
  }

  loadProfileSettings(profileConfigureModel: ProfileConfigureModel) {
    this.profileConfigureModel = profileConfigureModel;
    if (this.ruleTreeNodes && !this.loadInProgress) {
      this.updateRuleSelection();
    }
  }

  /**
   *
   */

  /*ruleSettingsClicked() {
    this.ngbModal.open(RuleConfigurationComponent, { backdrop: 'static', size: 'xl' });
  }
  */

  private updateSelectedRulesList() {
    const selectedRulesList = new Map<string, Map<string, any>>();
    for (const ruleTreeNode of this.ruleTreeNodes) {
      this.getSelectedRulesList(ruleTreeNode, selectedRulesList);
    }
    this.selectedRulesListChange.emit(selectedRulesList);
  }

  private getSelectedRulesList(
    ruleTreeNode: ProfilingRuleTreeNodeModel,
    selectedRulesList: Map<string, Map<string, any>>
  ) {
    //If ruleTreeNode is not selected at all then return.
    if (ruleTreeNode.data.selected === null) {
      return;
    }

    //If a ruleTreeNode has selected=true or selected=false(in case of partial list of children selected) then collect the selected IDs
    if (ruleTreeNode.data.nodeType === ProfilingRuleTreeNodeType.RULE_CATEGORY) {
      for (const childRuleTreeNode of ruleTreeNode.children) {
        this.getSelectedRulesList(childRuleTreeNode, selectedRulesList);
      }
    } else {
      const options = new Map<string, any>();

      if (ruleTreeNode.data.nodeType === ProfilingRuleTreeNodeType.RULE_WITH_SUBCATEGORY_OPTIONS) {
        const selectedSubcategories = ruleTreeNode.children
          .filter((childNode) => childNode.data.selected)
          .map((childNode) => childNode.data.id);
        options.set(ruleTreeNode.data.ruleConfigurationOptions[0].id, selectedSubcategories);
      } else {
        if (ruleTreeNode.data.ruleConfigurationOptions) {
          for (const ruleConfigurationOption of ruleTreeNode.data.ruleConfigurationOptions) {
            if (ruleConfigurationOption.configuredOptionValue !== undefined) {
              options.set(ruleConfigurationOption.id, ruleConfigurationOption.configuredOptionValue);
            } else if (ruleConfigurationOption.defaultOptionValue) {
              options.set(ruleConfigurationOption.id, ruleConfigurationOption.defaultOptionValue);
            }
          }
        }
      }

      selectedRulesList.set(ruleTreeNode.data.id, options);
    }
  }

  private updateRuleSelection() {
    this.ruleTreeNodes.forEach((node) => this.updateRuleSettings(node));
  }

  private updateRuleSettings(node: ProfilingRuleTreeNodeModel) {
    if (node.data.nodeType === ProfilingRuleTreeNodeType.RULE_CATEGORY) {
      for (const childRuleTreeNode of node.children) {
        this.updateRuleSettings(childRuleTreeNode);
      }
    } else {
      const ruleOptions = this.profileConfigureModel.rules[node.data.id];

      if (ruleOptions !== undefined) {
        node.data.selected = true;
        if (node.data.nodeType === ProfilingRuleTreeNodeType.RULE_WITH_SUBCATEGORY_OPTIONS) {
          const selectedSubcategories = ruleOptions[node.data.ruleConfigurationOptions[0].id];
          node.children.forEach((child) => {
            if (selectedSubcategories.indexOf(child.data.id) >= 0) {
              child.data.selected = true;
            } else {
              node.data.selected = false;
            }
          });
        } else {
          if (node.data.ruleConfigurationOptions) {
            for (const option of node.data.ruleConfigurationOptions) {
              option.configuredOptionValue = ruleOptions[option.id].toString();
            }
          }
        }
      }
    }
    ProfilingRulesComponent.updateParentSelection(node);
  }

  /**
   *
   * @param treeNode
   */
  private static updateChildrenSelection(treeNode: ProfilingRuleTreeNodeModel) {
    if (treeNode.children) {
      for (const childTreeNode of treeNode.children) {
        childTreeNode.data.selected = treeNode.data.selected;
        ProfilingRulesComponent.updateChildrenSelection(childTreeNode);
      }
    }
  }

  /**
   *
   * @param treeNode
   */
  private static updateParentSelection(treeNode: ProfilingRuleTreeNodeModel) {
    if (treeNode.parent) {
      let hasSelectedChildNode: boolean = false;
      let hasUnselectedChildNode: boolean = false;
      let hasPartiallySelectedChildNode: boolean = false;

      for (const childTreeNode of treeNode.parent.children) {
        if (childTreeNode.data.selected === false) {
          hasPartiallySelectedChildNode = true;
          break;
        } else if (childTreeNode.data.selected) {
          hasSelectedChildNode = true;
        } else if (childTreeNode.data.selected === null) {
          hasUnselectedChildNode = true;
        }

        if (hasSelectedChildNode && hasUnselectedChildNode) {
          break;
        }
      }

      treeNode.parent.data.selected =
        hasPartiallySelectedChildNode || (hasSelectedChildNode && hasUnselectedChildNode)
          ? false
          : hasSelectedChildNode && !hasUnselectedChildNode
          ? true
          : null;

      ProfilingRulesComponent.updateParentSelection(treeNode.parent);
    }
  }
}
