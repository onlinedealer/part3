import React from 'react'
import _ from 'lodash'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { withStyles } from '@material-ui/core/styles'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import VariationThemes from '../common/ThemeField/VariationThemes'
import * as Constants from '../common/Utils/Constants'
import { getGrouperTypes, getItemTypes, getItemThemes, clearItemThemes, addGroup, clearActionTypes, clearErrorTcins, getVariationItemTypes, getFixedThemes, VariationItemTypeOfFirstTcin } from '../../store/Dashboard/actionCreator'
import { toggleSnackBar } from '../../store/Snackbar/actionCreator'
import CircularProgress from '@material-ui/core/CircularProgress'
import CreateCommonFields from './CreateCommonFields'

const styles = theme => ({
  container: {
    padding: 0,
  },
  formControl: {
    width: '100%',
  },
  field: {
    marginTop: 24,
  },
  itemCount: {
    float: 'right',
  },
  textHead: {
    fontSize: 13,
    fontWeight: 500,
    marginBottom: 16,
  },
  textHead1: {
    fontSize: 13,
    fontWeight: 500,
  },
  textNormal: {
    fontSize: 13,
    fontWeight: 300,
  },
  textSmall: {
    fontSize: 11,
    fontWeight: 300,
    fontStyle: 'italic',
  },
  createButtonStyle: {
    position: 'relative',
    color: '#fff',
    float: 'right',
    background: '#1976d2',
    fontWeight: 300,
    '&:hover': {
      color: '#fff',
      background: '#125ca5',
    },
    '&:disabled': {
      backgroundColor: 'rgba(0, 0, 0, 0.12)',
    },
  },
  progress: {
    position: 'absolute',
    textAlign: 'center',
    color: '#FF9100',
  },
  cancelButtonStyle: {
    background: '#fff',
    color: '#666',
    float: 'right',
    fontWeight: 300,
    '&:hover': {
      background: '#d6d6d6',
      color: '#666',
    },
  },
  IconButton: {
    width: '100%',
    height: '100%',
    '&:hover': {
      background: 'transparent',
    },
  },
  displayFlex: {
    display: 'flex',
  },
  chipContainer: {
    maxHeight: '200px',
    overflowY: 'auto',
    marginBottom: 0,
    backgroundColor: '#fff',
  },
  helperText: {
    color: 'red',
    fontSize: 12,
  },
  themeContainer: {
    flexDirection: 'row',
  },
  themeRow: {
    width: '100%',
  },
})

export class CreateVariation extends React.PureComponent {
  constructor (props) {
    super(props)
    this.state = {
      group_name: '',
      tcins: [],
      themesFieldsCount: 1,
      formData: {
        group_type: 'variation',
        group_name: '',
        item_type: '',
        themes: {
          theme1: '',
        },
        tcins: [],
      },
      errors: {
        group_type: '',
        item_type: '',
        group_name: '',
        themes: '',
        tcins: '',
      },
    }
  }

  componentWillReceiveProps (nextProps) {
    if (nextProps.requestType) {
      if (nextProps.requestType === 'ADD') {
        this.props.closeDrawer()
        window.location.replace('group-details/' + nextProps.recentAddedGroup)
      }
    }
  }

  componentWillMount () {
    if (this.props.variationItemTypes.length === 0) {
      this.props.getVariationItemTypes()
    }
    if (this.props.fixedThemes.length === 0) {
      this.props.getFixedThemes()
    }
  }

    validateSubmit = () => {
      const formData = { ...this.state.formData }
      const selItem = _.find(this.props.variationItemTypes, { 'item_type_id': formData.item_type })
      const errors = { ...this.state.errors }
      let payload = {}
      let isValid = true
      if (!formData.group_type) {
        errors.group_type = Constants.ERROR_GROUP_TYPE_REQ
        isValid = false
      } else {
        this.props.groupTypes.map((grpType) => {
          if (grpType.name === formData.group_type) {
            payload.group_type_id = grpType.id
            payload.group_type = grpType.name
          }
        })
        errors.group_type = ''
      }
      if (!formData.item_type) {
        errors.item_type = Constants.ERROR_ITEM_TYPE_REQ
        isValid = false
      } else {
        payload.item_type_id = formData.item_type
        payload.item_type = selItem.item_type_name
        errors.item_type = ''
      }

      if (!formData.group_name) {
        errors.group_name = Constants.ERROR_GROUP_NAME_REQ
        isValid = false
      } else {
        payload.group_name = formData.group_name
        errors.item_type = ''
      }

      if (formData.tcins.length < 2) {
        errors.tcins = Constants.ERROR_TCIN_REQ
        isValid = false
      } else {
        let tcinData = []
        let count = 0
        formData.tcins.map((tcin) => {
          count++
          tcinData.push({ tcin, action: 'CREATED', sort_order: count })
        })
        payload.tcin_data = tcinData
        errors.tcins = ''
      }

      if (!formData.themes['theme1']) {
        errors.theme1 = Constants.ERROR_THEME1_REQ
        isValid = false
      } else {
        let themesData = []
        this.props.itemThemes.map((theme) => {
          for (let i = 1; i <= Object.keys(formData.themes).length; i++) {
            if (formData.themes[`theme${i}`].id === theme.id) {
              const fixedThemeObj = _.find(this.props.fixedThemes, (e) => { return e.fixed_theme_id === formData.themes[`theme${i}`].fixed_theme_id })
              themesData.push({ id: theme.id, fixed_theme_id: fixedThemeObj.fixed_theme_id, fixed_theme_name: fixedThemeObj.fixed_theme_name, attribute: theme.name, attribute_type: theme.attribute_type, theme_sort_order: i })
            }
          }
        })
        payload.themes = themesData
        errors.themes = ''
      }

      if (isValid) {
        payload.first_page_variation_request = true
        this.props.addGroup(payload, this.props.auth.memberOf, this.props.auth.lanId)
      } else {
        this.setState({ errors })
      }
    }

    handleChange = (name, value) => {
      const formData = { ...this.state.formData }
      formData[name] = value
      this.setState({ formData })
    }

    render () {
      const { classes, closeDrawer, itemThemes, loadingBtnStatus, fixedThemes } = this.props
      const { formData } = this.state
      let isDisabled = !!((!formData.group_type || !formData.item_type || !formData.group_name || formData.tcins.length <= 1 || !formData.themes['theme1'] || !formData.themes['theme1'].id || !formData.themes['theme1'].fixed_theme_id))
      isDisabled = (loadingBtnStatus.status && loadingBtnStatus.btnName === 'Create Group') ? true : isDisabled

      return (
        <div>
          <Grid container className={classes.container}>
            <CreateCommonFields
              groupType="variation"
              onHandleChange={this.handleChange}
              itemTypes={this.props.variationItemTypes}
              getItemTypes={this.props.getItemTypes}
              getItemThemes={this.props.getItemThemes}
              clearItemThemes={this.props.clearItemThemes}
              clearErrorTcins={this.props.clearErrorTcins}
              toggleSnackBar={this.props.toggleSnackBar}
              errorTcins={this.props.errorTcins}
              VariationItemTypeOfFirstTcin={this.props.VariationItemTypeOfFirstTcin}
              itemTypeOfFirstTcin={this.props.itemTypeOfFirstTcin.resp}
            />
            <Grid item xs={12} className={classes.field}>
              <Grid container className={classes.themeContainer}>
                <Grid item xs={12}>
                  <div className={classes.textHead1}>Themes </div>
                  {/* <div className={classes.textSmall}>Select upto {Constants.THEME_MAX_COUNT} attributes, minumum of 1</div> */}
                  <div className={classes.textSmall}>Minimum of one theme must be entered.</div>
                </Grid>
                <VariationThemes
                  itemThemes={itemThemes}
                  fixedThemes={fixedThemes}
                  onHandleChange={this.handleChange}
                  classes={classes}
                />
              </Grid>
            </Grid>
            <Grid item xs={12} className={classes.field}>
              <Grid container style={{justifyContent: 'space-around'}}>
                <Grid item xs={6} style={{flexBasis: 0}}>
                  <Button color="primary" className={classes.cancelButtonStyle} onClick={closeDrawer}>
                        Cancel
                  </Button>
                </Grid>
                <Grid item xs={6}>
                  <Button color="primary" className={classes.createButtonStyle} onClick={this.validateSubmit} disabled={isDisabled}>
                    { (loadingBtnStatus.status && loadingBtnStatus.btnName === 'Create Group') &&
                      <CircularProgress
                        className={classes.progress}
                        size={25}
                      />
                    }
                    CREATE GROUP
                  </Button>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </div>
      )
    }
}

CreateVariation.propTypes = {
  classes: PropTypes.object.isRequired,
}

const mapDispatchToProps = dispatch =>
  bindActionCreators({
    getGrouperTypes,
    getItemTypes,
    getItemThemes,
    clearItemThemes,
    clearActionTypes,
    addGroup,
    toggleSnackBar,
    clearErrorTcins,
    getVariationItemTypes,
    getFixedThemes,
    VariationItemTypeOfFirstTcin,
  }, dispatch)

const mapStateToProps = state => ({
  auth: state.get('auth').toJS(),
  groupTypes: state.getIn(['grouperDashboard', 'groupTypes']).toJS(),
  itemTypes: state.getIn(['grouperDashboard', 'itemTypes']).toJS(),
  itemThemes: state.getIn(['grouperDashboard', 'itemThemes']).toJS(),
  requestType: state.getIn(['grouperDashboard', 'requestType']),
  recentAddedGroup: state.getIn(['grouperDashboard', 'recentAddedGroup']),
  errorTcins: state.getIn(['grouperDashboard', 'errorTcins']).toJS(),
  variationItemTypes: state.getIn(['grouperDashboard', 'variationItemTypes']).toJS(),
  itemTypeOfFirstTcin: state.getIn(['grouperDashboard', 'itemTypeOfFirstTcin']).toJS(),
  fixedThemes: state.getIn(['grouperDashboard', 'fixedThemes']).toJS(),
})

export default connect(mapStateToProps, mapDispatchToProps)(withStyles(styles)(CreateVariation))
