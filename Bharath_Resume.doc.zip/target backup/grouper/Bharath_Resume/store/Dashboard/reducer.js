import { fromJS } from 'immutable'
import {
  GET_GROUPER_LIST,
  GET_GROUPER_LIST_SUCCESS,
  GET_GROUP_TYPES_SUCCESS,
  GET_ITEM_TYPES_SUCCESS,
  GET_ITEM_THEMES,
  GET_ITEM_THEMES_SUCCESS,
  GET_GROUP_TYPES,
  GET_ITEM_TYPES,
  CLEAR_ITEM_THEMES,
  ADD_GROUP,
  ADD_GROUP_SUCCESS,
  CLEAR_GROUP_ACTION_TYPE,
  SET_ERROR_TCINS,
  CLEAR_ERROR_TCINS,
  GET_COLLECTION_ITEM_TYPES_SUCCESS,
  GET_COLLECTION_MTAS_SUCCESS,
  GET_VARIATION_ITEM_TYPES_SUCCESS,
  GET_FIXED_THEMES_SUCCESS,
  SET_VARIATION_PAGE1_DATA,
  UPDATE_VARIATION_GROUP_NAME_REQUEST,
  CLEAR_VARIATION_PAGE1_DATA,
  UPDATE_GROUP_LIST_REQUEST_PARAMS,
  GET_STATUS_LIST_SUCCESS,
  ITEM_TYPE_OF_FIRST_TCIN,
} from './actionType'

export const initialState = fromJS({
  grouperList: [],
  groupTypes: [],
  itemTypes: [],
  itemThemes: [],
  snackbarMessage: {},
  requestType: '',
  errorTcins: [],
  recentAddedGroup: '',
  recentAddedInfo: {},
  collectionItemTypes: [],
  collectionMTAs: [],
  variationItemTypes: [],
  fixedThemes: [],
  variationPage1Data: {},
  groupListRequestParams: {
    group_id: 0,
    pagination_filter: {
      page: 0,
      order: 'id',
      limit: 20,
      direction: 'DESC',
      is_count_needed: true,
    },
  },
  statusList: [],
  itemTypeOfFirstTcin: [],
})

export default function grouperReducer (state = initialState, action) {
  switch (action.type) {
    case GET_GROUPER_LIST:
      return state
        .set('grouperList', fromJS([]))
        .set('snackbarMessage', fromJS({}))
        .set('requestType', fromJS(''))
        .set('errorTcins', fromJS([]))

    case GET_GROUPER_LIST_SUCCESS:
      /* const mockData = [{
        group_id: 345683,
        group_type: 'Variation',
        group_name: 'Gentle Company Diapers677',
        dept: '234-Baby Care',
        no_of_items: 64,
        last_modified: 'July 3 2018',
        launch_date: 'Sep 20 2018',
        delete_status: 'yes',
      },{
        group_id: 345685,
        group_type: 'Variation',
        group_name: 'Gentle Company Diapers677',
        dept: '234-Baby Care',
        no_of_items: 64,
        last_modified: 'July 3 2018',
        launch_date: 'Sep 20 2018',
        delete_status: 'yes',
      },{
        group_id: 345688,
        group_type: 'Variation',
        group_name: 'Gentle Company Diapers677',
        dept: '234-Baby Care',
        no_of_items: 64,
        last_modified: 'July 3 2018',
        launch_date: 'Sep 20 2018',
        delete_status: 'yes',
      }]
      action.data = mockData */
      return state
        .set('grouperList', fromJS(action.data))

    case GET_GROUP_TYPES:
      return state
        .set('groupTypes', fromJS([]))
        .set('snackbarMessage', fromJS({}))
        .set('requestType', fromJS(''))
        .set('recentAddedGroup', fromJS(''))
        .set('recentAddedInfo', fromJS([]))
        .set('errorTcins', fromJS([]))

    case GET_GROUP_TYPES_SUCCESS:
      /* const mockGroupTypes = [{"id":1,"name":"variation","status":true},{"id":2,"name":"collection","status":true}]
      action.payload = mockGroupTypes */
      return state
        .set('groupTypes', fromJS(action.payload))

    case GET_ITEM_TYPES:
      return state
        .set('itemTypes', fromJS([]))
        .set('snackbarMessage', fromJS({}))
        .set('requestType', fromJS(''))
        .set('recentAddedGroup', fromJS(''))
        .set('recentAddedInfo', fromJS([]))
        .set('errorTcins', fromJS([]))

    case GET_ITEM_TYPES_SUCCESS:
      return state
        .set('itemTypes', fromJS(action.payload))

    case GET_ITEM_THEMES:
      return state
        .set('itemThemes', fromJS([]))
        .set('snackbarMessage', fromJS({}))
        .set('requestType', fromJS(''))
        .set('recentAddedGroup', fromJS(''))
        .set('recentAddedInfo', fromJS([]))
        .set('errorTcins', fromJS([]))

    case GET_ITEM_THEMES_SUCCESS:
      return state
        .set('itemThemes', fromJS(action.payload))

    case CLEAR_ITEM_THEMES:
      return state
        .set('itemThemes', fromJS([]))

    case ADD_GROUP:
      return state
        .set('requestType', fromJS(''))
        .set('recentAddedGroup', fromJS(''))
        .set('recentAddedInfo', fromJS([]))
        .set('errorTcins', fromJS([]))

    case ADD_GROUP_SUCCESS:
      return state
        .set('requestType', fromJS('ADD'))
        .set('recentAddedGroup', fromJS(action.payload.recentAddedGroupID))
        .set('recentAddedInfo', fromJS(action.payload.recentAddedInfo))
        .set('errorTcins', fromJS([]))

    case CLEAR_GROUP_ACTION_TYPE:
      return state
        .set('requestType', fromJS(''))
        .set('recentAddedGroup', fromJS(''))
        .set('recentAddedInfo', fromJS([]))
        .set('errorTcins', fromJS([]))

    case SET_ERROR_TCINS:
      return state
        .set('errorTcins', fromJS(action.errorTcins))

    case CLEAR_ERROR_TCINS:
      return state
        .set('errorTcins', fromJS([]))

    case GET_COLLECTION_ITEM_TYPES_SUCCESS:
      return state
        .set('collectionItemTypes', fromJS(action.payload))

    case GET_COLLECTION_MTAS_SUCCESS:
      return state
        .set('collectionMTAs', fromJS(action.payload))

    case GET_VARIATION_ITEM_TYPES_SUCCESS:
      return state
        .set('variationItemTypes', fromJS(action.payload))

    case GET_FIXED_THEMES_SUCCESS:
      return state
        .set('fixedThemes', fromJS(action.payload))

    case SET_VARIATION_PAGE1_DATA:
      return state
        .set('variationPage1Data', fromJS(action.payload))

    case UPDATE_VARIATION_GROUP_NAME_REQUEST:
      return state
        .setIn(['variationPage1Data', 'group_name'], action.groupName)

    case CLEAR_VARIATION_PAGE1_DATA:
      return state
        .set('variationPage1Data', fromJS({}))

    case UPDATE_GROUP_LIST_REQUEST_PARAMS:
      return state
        .set('groupListRequestParams', fromJS(action.payload))

    case GET_STATUS_LIST_SUCCESS:
      return state
        .set('statusList', fromJS(action.payload))

    case ITEM_TYPE_OF_FIRST_TCIN:
      return state
        .set('itemTypeOfFirstTcin', fromJS(action))

    default:
      return state
  }
}
