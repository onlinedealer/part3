import { Component, Input, OnInit, OnDestroy, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { NotifyConfig } from 'core/models/notification-config/email-config.model';
import { AuthenticationService } from 'discovery-shared';
import { Chips } from 'primeng/chips';
import { Subject, takeUntil } from 'rxjs';
const EMAIL_REGEXP = /^[A-Z0-9_!#$%&'*+=?`{|}~^-]+(?:\.[A-Z0-9_!#$%&'*+=?`{|}~^-]+)*@[A-Z0-9-]+(?:\.[A-Z0-9-]+)*$/i;

@Component({
  selector: 'discovery-email-notify-config',
  templateUrl: './email-notify-config.component.html',
  styleUrls: ['./email-notify-config.component.scss']
})
export class EmailNotifyConfigComponent implements OnInit, OnDestroy {
  @Input() allowEmail: boolean = false;
  formSubmitted: boolean = false;
  get notifConfig() {
    return this._notifConfig;
  }
  @Input() set notifConfig(value: NotifyConfig) {
    this.createAndInitializeForm();
    const recipientsList = value?.notifications[0]?.recipients || [];
    const enabled = value?.notifications[0].enabled;
    this.emailConfigForm.get('emailNotifyEnabled').setValue(enabled);
    if (recipientsList.length) {
      this.emailConfigForm.get('recipients').setValue([...recipientsList]);
    } else {
      // Add Logged in user email
      const email = this.authService.getEmail();
      if (enabled && email) {
        this.emailConfigForm.get('recipients').setValue([email]);
      } else {
        this.emailConfigForm.get('recipients').reset();
      }
    }
    this._notifConfig = value;
  }
  componentDestroyed$: Subject<boolean> = new Subject();
  emailConfigForm: FormGroup;
  emailSeparator: string = ',';
  allowDuplicateEmail: boolean = false;
  maxEmailLimit: number = 25;
  invalidEmailPool: string[] = [];
  @ViewChild('emailTokenizer')
  emailChipsComponent: Chips;
  private _notifConfig: NotifyConfig;

  /**
   * Configuration can be considered valid of notification is disabled, therefore no min and max limit on email recipient
   * If notification is enabled then min and max validation should be allowed.
   */
  get isFormValid() {
    const recipients: string[] = this.emailConfigForm.get('recipients').value || [];
    const emailNotifyEnabled: boolean = this.emailConfigForm.get('emailNotifyEnabled').value;
    const listsize = recipients.length;
    if (emailNotifyEnabled) {
      return (
        this.emailConfigForm.valid && listsize > 0 && listsize <= this.maxEmailLimit && !this.invalidEmailPool.length
      );
    } else if (this.invalidEmailPool.length || listsize > this.maxEmailLimit) {
      // Case when notif config is disabled and user input any invalid email or more than max limit(25)
      return false;
    } else {
      return true;
    }
  }
  /**
   * Check for Required Validation only
   */
  get hasRecipientError() {
    return this.emailConfigForm.get('recipients').errors;
  }

  /**
   * Check for Maximum limit for email validation. Should work even if notification is disabled
   */
  get maxRecipientLimit() {
    return this.emailConfigForm.get('recipients').value?.length > this.maxEmailLimit;
  }
  /**
   * Returnd Joined list of invalid email string to display in HTML
   */
  get invalidEmailList(): string {
    return this.invalidEmailPool.length ? this.invalidEmailPool.join(', ') : '';
  }

  constructor(private fb: FormBuilder, private authService: AuthenticationService) {}

  ngOnInit(): void {
    this.createAndInitializeForm();
  }

  /**
   * Only Creates form if not created already.
   *
   */
  createAndInitializeForm() {
    if (!this.emailConfigForm) {
      this.emailConfigForm = this.createForm();
      this.subscribeToggleSwitchChanges();
    }
  }

  /**
   *
   * Creates Email Config form and return FormGroup
   */
  createForm(): FormGroup {
    return this.fb.group({
      recipients: [],
      emailNotifyEnabled: []
    });
  }

  /**
   * Subscribe to enable and disable notification and Update the validation
   */
  subscribeToggleSwitchChanges() {
    this.emailConfigForm
      .get('emailNotifyEnabled')
      .valueChanges.pipe(takeUntil(this.componentDestroyed$))
      .subscribe((value) => {
        this.updateValidation(value);
      });
  }

  /**
   *
   * Update required recipient validation
   */
  updateValidation(value: boolean) {
    if (value) {
      this.emailConfigForm.get('recipients').setValidators([Validators.required]);
      this.emailConfigForm.get('recipients').updateValueAndValidity();
    } else {
      this.emailConfigForm.get('recipients').clearValidators();
      this.emailConfigForm.get('recipients').updateValueAndValidity();
    }
  }

  /**
   *
   * Callback method when email string is removed
   */
  onRemoveEmail() {
    this.setInvalidEmailList();
  }

  /**
   *
   * Call back method when email is added via input or copy paste
   */
  onAddEmail() {
    this.setInvalidEmailList();
    const recipients = this.emailConfigForm.get('recipients').value.map((email) => email.toLowerCase().trim());
    const uniqueEmailsList = recipients.filter((email: string, index) => recipients.indexOf(email) === index);
    this.emailConfigForm.get('recipients').setValue(uniqueEmailsList);
  }

  /**
   *
   * set and returns Invalid email list as an array
   */
  setInvalidEmailList(): string[] {
    const recipients: string[] = this.emailConfigForm.get('recipients').value;
    this.invalidEmailPool = [];
    if (recipients?.length) {
      this.invalidEmailPool = recipients
        .map((email: string) => email.toLowerCase().trim())
        .filter((email: string) => !this.validateEmail(email));
    }
    return this.invalidEmailPool;
  }

  /**
   *
   * @param email
   * @returns boolean after validating email
   */
  validateEmail(email: string) {
    if (!EMAIL_REGEXP.test(email)) {
      return false;
    }
    return true;
  }

  /**
   * Called on Form Submit(externally as well)
   */
  onSubmitForm() {
    this.formSubmitted = true;
    const controls = this.emailConfigForm.controls;
    for (const i in this.emailConfigForm.controls) {
      controls[i].markAsDirty();
      controls[i].updateValueAndValidity();
    }

    if (this.isFormValid) {
      const emails = this.emailConfigForm.value.recipients || [];
      const enabled = this.emailConfigForm.value.emailNotifyEnabled;
      this.notifConfig.notifications[0].recipients = emails.map((email: string) => email.trim());
      this.notifConfig.notifications[0].enabled = enabled;
    }
  }

  /**
   * Unsubscribe or destroy all subscriptions
   */
  ngOnDestroy() {
    this.componentDestroyed$.next(true);
    this.componentDestroyed$.complete();
  }
}
