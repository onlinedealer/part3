import { ActivatedRoute } from "@angular/router";
import { Component, OnInit, Output, EventEmitter, OnDestroy } from "@angular/core";
import { map } from "rxjs/operators";
import { MeteringPointsActions } from "../../store/actions";
import { MeteringPointSearchResultVO } from "../../models/view-objects/meteringpoint-searchresult-vo.model";
import { MeteringPointsFeatureState } from "../../store/reducers";
import { MeteringPointsSelectors, XSFSearchSelectors, MeteringPointsUISelectors } from "../../store/selectors";
import { Observable, Subscription } from "rxjs";
import { Router } from "@angular/router";
import { SecondarySideviewService } from "../../../Shared/services/secondary-sideview.service";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../app/services/translations-service";
import { getWindowHeight } from "../../../app/store/selectors/ui.selectors";
import { State } from "../../../app/store/reducers";
import * as _ from "lodash";
import { ExportDataColHeaderService } from "../../../MeteringPoints/services/export-data-col-header.service";
import { ExportTableDataService } from "../../../MeteringPoints/services/export-data.service";
import { LocalStorageKeys, LocalStorageService } from "../../../app/services/local-storage.service";
import { ExportDialogComponent } from "../../components/export-dialog/export-dialog.component";
import { MatDialog } from "@angular/material/dialog";
@Component({
    selector: "landisgyr-meteringpoints-results",
    templateUrl: "./meteringpoints-results-container.component.html",
    styleUrls: ["./meteringpoints-results-container.component.scss"]
})
export class MeteringpointsResultsContainerComponent implements OnInit, OnDestroy {
    @Output() meteringPointsAmount: EventEmitter<any> = new EventEmitter();
    @Output() selectedMeteringPointsAmount: EventEmitter<any> = new EventEmitter();
    meteringPoints!: MeteringPointSearchResultVO[];
    selectedMeteringPointId$: Observable<number | undefined> = this.store.select(MeteringPointsSelectors.getSelectedMeteringPointId);
    checkedMeteringPointIds!: number[];
    windowHeightSub$: Observable<any> = this.storeRouter.select(getWindowHeight);
    searching$: Observable<boolean> = this.store.select(XSFSearchSelectors.isSearching);
    searched$: Observable<boolean> = this.store.select(XSFSearchSelectors.isSearched);
    searchedOrSearching$: Observable<boolean> = this.store.select(XSFSearchSelectors.isSearchedOrSeaching);
    searchedAndNotSearching$: Observable<boolean> = this.store.select(XSFSearchSelectors.isSearchedAndNotSearching);
    notSearchedAndNotSearching$: Observable<boolean> = this.store.select(XSFSearchSelectors.isNotSearchingAndNotSearched);
    searchFailed$: Observable<boolean> = this.store.select(XSFSearchSelectors.isSearchFailed);
    searchFailureMessage$: Observable<any> = this.store.select(XSFSearchSelectors.getSearchFailureMessage).pipe(
        map((failureMessage) => {
            return `${this.infoMessageFailedSearch} ${failureMessage}`;
        })
    );
    searchOrderBy$: Observable<any> = this.store.select(XSFSearchSelectors.getXSFSearchOrderBy);
    sideViewVisible$: Observable<boolean> = this.store.select(MeteringPointsUISelectors.getMeteringPointsSideviewVisible);

    checkedMeteringPointIdsSub!: Subscription;
    meteringPointsSub!: Subscription;
    sideviewSubscription!: Subscription;

    resultsTableColumnsToDisplay = 6;

    changed = false;
    mpDetailsColConfig: any;

    infoMessage1 = $localize`:|@@meteringpointsResults.noMatchForCriteria:No matches found`;
    infoMessage2 = $localize`:|@@meteringpointsResults.startBySearching:Start by searching for metering points`;
    infoMessageFailedSearch = $localize`:|@@meteringpointsResults.searchFailed:Metering point search failed`;

    selectAllCheckbox!: boolean;

    constructor(
        private store: Store<MeteringPointsFeatureState>,
        private storeRouter: Store<State>,
        private dialog: MatDialog,
        private exportDataColHeaderService: ExportDataColHeaderService,
        public exportTableDataService: ExportTableDataService,
        private localStorage: LocalStorageService
    ) {
        this.sideviewSubscription = this.store
            .select(MeteringPointsUISelectors.getMeteringPointsSideviewVisible)
            .subscribe((sideViewVisible) =>
                sideViewVisible ? (this.resultsTableColumnsToDisplay = 2) : (this.resultsTableColumnsToDisplay = 7)
            );
    }
    ngOnInit() {
        this.checkedMeteringPointIdsSub = this.store.select(MeteringPointsSelectors.getMeteringPointsChecked).subscribe((ids) => {
            this.checkedMeteringPointIds = ids;
        });
        this.meteringPointsSub = this.store.select(MeteringPointsSelectors.getMeteringPointsSearchResultsForTable).subscribe((results) => {
            this.meteringPoints = results;
            this.meteringPointsAmount.emit(results.length);
        });

        this.localStorage.changedColumnInfo.subscribe((data) => {
            if (data.key === LocalStorageKeys.mpSearchTable) {
                this.changed = true;
                this.mpDetailsColConfig = data.value;
            }
        });
        if (!this.changed) {
            if (this.localStorage.getColumnConfiguration(LocalStorageKeys.mpSearchTable)) {
                this.mpDetailsColConfig = this.localStorage.getColumnConfiguration(LocalStorageKeys.mpSearchTable);
            } else {
                this.store.select(MeteringPointsUISelectors.getMPDetailsColumnConfigInitial).subscribe((data) => {
                    this.mpDetailsColConfig = data;
                });
            }
        }
    }

    ngOnDestroy() {
        if (this.sideviewSubscription) {
            this.sideviewSubscription.unsubscribe();
        }

        if (this.checkedMeteringPointIdsSub) {
            this.checkedMeteringPointIdsSub.unsubscribe();
        }

        if (this.meteringPointsSub) {
            this.meteringPointsSub.unsubscribe();
        }
    }

    /*
        Clicking on an item from search result list either selects or deselects the item
        and this information goes to the store.

        NOTE: At the moment saving selection to store happens in meteringpoint-sideview-container.component
    */
    onSelectItem(payload: { [key: string]: MeteringPointSearchResultVO }) {
        const item: MeteringPointSearchResultVO = payload.item;
        //        this.secondarySideviewService.removeLatestSideview();
        if (item) {
            this.store.dispatch(MeteringPointsActions.SelectMeteringPoint({ meteringPointId: item.id }));
        }
    }

    onAllMeteringPointCheck(): void {
        if (this.selectAllCheckbox) {
            this.selectAllCheckbox = false;
            this.store.dispatch(MeteringPointsActions.UncheckAllMeteringPoints());
        } else {
            this.selectAllCheckbox = true;
            this.store.dispatch(
                MeteringPointsActions.CheckMeteringPoints({
                    meteringPointIds: this.meteringPoints.map((meteringPoint) => meteringPoint.id)
                })
            );
        }
        this.selectedMeteringPointsAmount.emit(this.checkedMeteringPointIds.length);
    }
    onCheckCheckbox(meteringPointId: number) {
        if (this.checkedMeteringPointIds.includes(meteringPointId)) {
            this.store.dispatch(MeteringPointsActions.UncheckMeteringPoint({ meteringPointId }));
        } else {
            this.store.dispatch(MeteringPointsActions.CheckMeteringPoint({ meteringPointId }));
        }
        this.selectedMeteringPointsAmount.emit(this.checkedMeteringPointIds.length);
    }

    onDeselectItem(payload: any) {
        const item: MeteringPointSearchResultVO = payload.item;
        this.store.dispatch(MeteringPointsActions.DeselectMeteringPoint({ meteringPointId: item.id }));
    }

    onMeteringPointExportDataClick() {
        const exportData: any[] = _.cloneDeep(this.exportTableDataService.getMeteringPointSearchResult());
        exportData.forEach((item) => {
            item.meteringPointStates = _.map(item.meteringPointStates, "identifier").join(", ");
        });
        const data = {
            fileName: "metering_points",
            results: exportData,
            header: this.exportDataColHeaderService.meteringPointSearchResultsHeader,
            includePageRange: true,
            includeTimeRange: false
        };
        this.dialog.open(ExportDialogComponent, {
            width: "850px",
            maxWidth: "8500px",
            height: "600px",
            maxHeight: "600px",
            disableClose: true,
            data: {
                fileName: data.fileName,
                results: [], // As will get the data on click of export button, by directly calling the api
                header: data.header,
                includePageRange: data.includePageRange,
                includeTimeRange: data.includeTimeRange
            }
        });
    }
}
