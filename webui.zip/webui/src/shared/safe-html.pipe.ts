import { Pipe, PipeTransform } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';

@Pipe({
  name: 'safeHtml'
})
export class SafeHtmlPipe implements PipeTransform {
  /**
   *
   * @param domSanitizer
   */
  constructor(private domSanitizer: DomSanitizer) {}

  /**
   *
   * @param value
   */
  transform(value: string) {
    return this.domSanitizer.bypassSecurityTrustHtml(value);
  }
}
