import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { ConnectionModel } from '../connection.model';
import { SnowflakeConnectionOptionsModel } from './snowflake-connection-options.model';
import { NgForm } from '@angular/forms';
import { TranslocoService } from '@ngneat/transloco';
import { NameValidatorService } from '../../name-validator.service';
import { SharedConstants } from '../../shared.constant';

@Component({
  selector: 'discovery-snowflake-connection',
  templateUrl: './snowflake-connection.component.html',
  styleUrls: ['./snowflake-connection.component.css']
})
export class SnowflakeConnectionConfigureComponent implements OnInit {
  /**
   *
   */
  @ViewChild('snowflakeForm') snowflakeForm: NgForm;
  @ViewChild('connectionNameRef') connectionNameRef: ElementRef;

  @Output() setFieldData: EventEmitter<{ key: string; value: string }> = new EventEmitter<{
    key: string;
    value: string;
  }>();
  @Output() setFormValid: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() connectionNameInvalidError: EventEmitter<boolean> = new EventEmitter<boolean>();

  connectionNameError: any = {
    invalidName: false
  };

  get viewType(): string {
    return this._viewType;
  }

  @Input()
  set viewType(val: string) {
    this._viewType = val;
  }

  get clickedButtonType(): string {
    return this._clickButtonType;
  }

  @Input()
  set clickedButtonType(val: string) {
    this._clickButtonType = val;
    if (val === 'connection-save') {
      this.connectionNameRef.nativeElement.required = true;
    }
    if (val === 'connection-test' || val === null) {
      this.connectionNameRef.nativeElement.required = false;
    }
  }

  get connectionModel(): ConnectionModel {
    return this._connectionModel;
  }

  get resetFormSnow(): boolean {
    return this._resetFormSnow;
  }

  @Input()
  set resetFormSnow(val: boolean) {
    this._resetFormSnow = val;
    if (this._resetFormSnow) {
      this.closeForm();
    }
  }

  @Input()
  set connectionModel(val: ConnectionModel) {
    this._connectionModel = val;
    if (this._connectionModel && this._connectionModel.name) {
      this.validateConnectionName();
    }
  }

  /**
   *
   * @param value
   */
  set account(value: string) {
    this.setOption(SnowflakeConnectionOptionsModel.account, value);
  }

  get account(): string {
    return this.getOption(SnowflakeConnectionOptionsModel.account);
  }

  /**
   *
   */
  get schema(): string {
    return this.getOption(SnowflakeConnectionOptionsModel.schema);
  }

  /**
   *
   * @param value
   */
  set schema(value: string) {
    this.setOption(SnowflakeConnectionOptionsModel.schema, value);
  }

  /**
   *
   */
  get database(): string {
    return this.getOption(SnowflakeConnectionOptionsModel.db);
  }

  /**
   *
   * @param value
   */
  set database(value: string) {
    this.setOption(SnowflakeConnectionOptionsModel.db, value);
  }

  /**
   *
   */
  get warehouse(): string {
    return this.getOption(SnowflakeConnectionOptionsModel.warehouse);
  }

  /**
   *
   * @param value
   */
  set warehouse(value: string) {
    this.setOption(SnowflakeConnectionOptionsModel.warehouse, value);
  }

  /**
   *
   */
  get role(): string {
    return this.getOption(SnowflakeConnectionOptionsModel.role);
  }

  /**
   *
   * @param value
   */
  set role(value: string) {
    this.setOption(SnowflakeConnectionOptionsModel.role, value);
  }

  /**
   *
   */
  get password(): string {
    return this.getOption(SnowflakeConnectionOptionsModel.password);
  }

  /**
   *
   * @param value
   */
  set password(value: string) {
    this.setOption(SnowflakeConnectionOptionsModel.password, value);
  }

  /**
   *
   */
  get userName(): string {
    return this.getOption(SnowflakeConnectionOptionsModel.user);
  }

  /**
   *
   * @param value
   */
  set userName(value: string) {
    this.setOption(SnowflakeConnectionOptionsModel.user, value);
  }

  /**
   * create, edit or copy mode
   */
  private _viewType: string;

  /**
   * Connection details
   */
  private _connectionModel: ConnectionModel;

  /**
   * clicked button type
   */

  private _clickButtonType: string;

  /**
   * sidebar toggle
   */
  private _resetFormSnow: boolean;

  /**
   *
   * @param translocoService
   */
  constructor(private translocoService: TranslocoService) {}

  /**
   *
   */
  ngOnInit(): void {
    if (this.connectionModel && this.connectionModel.resourceConnectionType === '') {
      this.connectionModel.resourceConnectionType = SharedConstants.connectionConfigureType.SNOWFLAKE;
    }
  }

  /**
   *
   */
  validateConnectionName() {
    this.connectionModel.name = this.connectionModel.name?.trim();
    this.connectionNameError.invalidName = false;
    if (this.connectionModel.name) {
      const test = NameValidatorService.validateName(this.connectionModel.name);
      if (!test || this.connectionModel.name.length > SharedConstants.NAMEMAXLENGTH) {
        this.connectionNameError.invalidName = true;
      }
    }
    this.connectionNameInvalidError.emit(this.connectionNameError.invalidName);
  }

  closeForm() {
    if (this.snowflakeForm) {
      this.clickedButtonType = null;
      this.snowflakeForm.resetForm({});
      this.setFormValid.emit(false);
      this.connectionNameError.invalidName = false;
    }
  }

  /**
   *
   * @param key
   */
  public getOption(key: string): string {
    if (this.connectionModel.options) {
      for (const option of this.connectionModel.options) {
        if (option.name === key) {
          return option.value;
        }
      }
    }
  }

  /**
   *
   * @param key
   * @param value
   */
  private setOption(key: string, value: string): void {
    this.setFieldData.emit({ key: key, value: value });
    this.setFormValid.emit(this.snowflakeForm.valid);
  }
}
