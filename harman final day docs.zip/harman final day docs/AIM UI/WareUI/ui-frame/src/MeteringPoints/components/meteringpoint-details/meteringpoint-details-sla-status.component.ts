import { Component } from "@angular/core";

@Component({
    selector: "landisgyr-meteringpoint-details-sla-status",
    templateUrl: "./meteringpoint-details-sla-status.component.html",
    styleUrls: ["./meteringpoint-details-sla-status.component.scss"]
})
export class MeteringPointDetailsSLAStatusComponent {}
