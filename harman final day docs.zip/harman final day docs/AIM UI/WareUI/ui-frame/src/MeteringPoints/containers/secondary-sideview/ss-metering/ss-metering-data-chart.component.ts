import { Component, ChangeDetectionStrategy, Input } from "@angular/core";
import { Metering } from "../../../models/metering.model";
import { MeteringDataChartActions } from "../../../store/actions";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { MeteringsSelectors, MeteringDataChartSelectors, MeteringPointsUISelectors } from "../../../store/selectors";
import { Store } from "@ngrx/store";
import { TranslationsService } from "../../../../app/services/translations-service";

@Component({
    selector: "landisgyr-ss-metering-data-chart",
    templateUrl: "./ss-metering-data-chart.component.html",
    styleUrls: ["./ss-metering-data-chart.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class SSMeteringDataChartComponent {
    @Input()
    metering!: Metering | undefined;

    sideviewExpanded$ = this.store.select(MeteringPointsUISelectors.getMeteringPointsSideviewExpanded);

    chartDataGrouping$ = this.store.select(MeteringDataChartSelectors.getSelectedChartDataGrouping);
    chartDataAvailableGroupingOptions$ = this.store.select(MeteringDataChartSelectors.getAvailableChartDataGroupingOptions);

    selectedMeteringPointOtherMeterings$ = this.store.select(MeteringsSelectors.getSelectedMeteringPointOtherSameTypeMeterings);
    selectedMeteringPointsChartDataSelectedMeterings$ = this.store.select(
        MeteringDataChartSelectors.getSelectedMeteringPointsChartDataSelectedMeterings
    );

    chartScales$ = this.store.select(MeteringDataChartSelectors.getChartScales);
    chartUnits$ = this.store.select(MeteringDataChartSelectors.getChartUnitsInUse);
    chartData$ = this.store.select(MeteringDataChartSelectors.getAllSelectedMeteringsProfile);

    //    profileDataForChart$: Observable<any> = this.store.select(ChartSelectors.selectedMeteringProfile);

    constructor(private store: Store<MeteringPointsFeatureState>, public translations: TranslationsService) {}

    onChartDataGroupingSelection(dataGrouping: "year" | "month" | "week" | "day" | "all") {
        this.store.dispatch(MeteringDataChartActions.SelectChartDataGrouping({ dataGrouping }));
    }

    onChangeMeteringSelection(meteringSelection: { meteringPointId: number; meteringId: number; meteringType: string; selected: boolean }) {
        this.store.dispatch(MeteringDataChartActions.ChangeMeteringPointsChartDataMeteringSelection(meteringSelection));
    }
}
