import { Component, OnChanges, SimpleChanges } from "@angular/core";
import { MeteringPointsFeatureState } from "../../../store/reducers";
import { OdrTypeTranslations } from "../../../translations/odr-type.translations";
import { OnDemandReadingReadingEntryComponent } from "../reading-entry/odr-reading-entry.component";
import { OnDemandReadingStatus } from "../../../models/ondemandreading.model";
import { Store } from "@ngrx/store";

@Component({
    selector: "landisgyr-odr-reading-entry-result-scheduled-reading",
    templateUrl: "./odr-reading-entry-result-scheduled-reading.component.html",
    styleUrls: ["./odr-reading-entry-result-scheduled-reading.component.scss"]
})
export class OdrReadingEntryResultScheduledReadingComponent extends OnDemandReadingReadingEntryComponent implements OnChanges {
    useTime!: Date;
    wasSuccess!: boolean;
    resultLinkAvailable!: boolean;
    constructor(translations: OdrTypeTranslations, store: Store<MeteringPointsFeatureState>) {
        super(translations, store);
    }

    ngOnChanges(changes: SimpleChanges) {
        super.ngOnChanges(changes);
        this.wasSuccess = this.onDemandReadingRequest.status !== OnDemandReadingStatus.Failed;
        this.resultLinkAvailable = !!(
            this.onDemandReadingRequest &&
            this.onDemandReadingRequest.results &&
            this.onDemandReadingRequest.results.length > 0
        );
    }
}
