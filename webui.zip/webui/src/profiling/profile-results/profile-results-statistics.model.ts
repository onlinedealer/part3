export class ProfileResultsstatisticsModel {
  type: string;
  totalRows: number;
  nullCount: number;
  blankCount: number;
}
