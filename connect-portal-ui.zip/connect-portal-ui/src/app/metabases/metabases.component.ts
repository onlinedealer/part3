import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { Subject } from 'rxjs';
import { BaseComponent } from '../core/base.component';
import { BreadcrumbItem } from '../shared/components/breadcrumb/breadcrumb-item';
import { TableConfiguration, TableField, TableMessage, TableMessageType } from '../shared/components/generic-table/generic-table';
import { Metabase } from './shared/metabase.model';
import { MetabaseSidebarComponent } from './metabase-sidebar/metabase-sidebar.component';
import { MetabasesApiService } from './shared/metabases-api.service';
import { mergeMap, tap } from 'rxjs/operators';
import { ProjectsApiService } from '../pipelines/pipeline/shared/projects-api.service';
import { MetabaseDetailsSidebarComponent } from './metabase-details-sidebar/metabase-details-sidebar.component';
import { UpgradeMetabaseSidebarComponent } from './upgrade-metabase-sidebar/upgrade-metabase-sidebar.component';
import { DeleteMetabaseSidebarComponent } from './delete-metabase-sidebar/delete-metabase-sidebar.component';
import { FeatureFlagService } from '@shared/services/feature-flag.service';

/**
 * Component for managing metabases.
 */
@Component({
  selector: 'p-connect-metabases',
  templateUrl: './metabases.component.html',
  styleUrls: ['./metabases.component.scss']
})
export class MetabasesComponent extends BaseComponent implements OnInit {
  @ViewChild(MetabaseSidebarComponent) metabaseSidebarComponent: MetabaseSidebarComponent;

  /**
   * Reference to the MetabaseDetailsSidebarComponent child component
   */
  @ViewChild(MetabaseDetailsSidebarComponent) metabaseDetailsSidebarComponent: MetabaseDetailsSidebarComponent;

  /**
   * Reference to the UpgradeMetabaseSidebarComponent child component
   */
  @ViewChild(UpgradeMetabaseSidebarComponent) upgradeMetabaseSidebarComponent: UpgradeMetabaseSidebarComponent;
  @ViewChild(DeleteMetabaseSidebarComponent) deleteMetabaseSidebarComponent: DeleteMetabaseSidebarComponent;

  /**
   * BreadCrumb items
   */
  breadcrumbs: BreadcrumbItem[] = [
    { text: 'common.BREADCRUMBS.APP_ROOT', isActive: true },
    {
      text: 'common.BREADCRUMBS.PROJECTS',
      isActive: true,
      isHidden: this.featureFlagService.isFeatureDisabled('CDCMultipleProjectsTemp20220421')
    },
    {
      text: '',
      isActive: true,
      isHidden: this.featureFlagService.isFeatureDisabled('CDCMultipleProjectsTemp20220421')
    },
    { text: 'common.BREADCRUMBS.METABASES', isActive: true }
  ];

  /**
   * Table configuration
   */
  fields: TableField[] = [
    {
      header: 'metabases.METABASES_TABLE.COLUMNS.NAME',
      name: 'name',
      isInDeleteModal: true,
      isSearchable: true,
      columnStyle: { width: '14rem', minWidth: '14rem' },
      isKey: true
    },
    { header: 'metabases.METABASES_TABLE.COLUMNS.DATABASE_SERVER', name: 'dataConnection.database', isInDeleteModal: true },
    { header: 'metabases.METABASES_TABLE.COLUMNS.DATA_CONNECTION', name: 'dataConnection.name', isInDeleteModal: true, isSearchable: true },
    { header: 'metabases.METABASES_TABLE.COLUMNS.REPLICATION_USER', name: 'replicationUser', isSearchable: true },
    { header: 'metabases.METABASES_TABLE.COLUMNS.VERSION', name: 'version' }
  ];

  /**
   * Empty table message
   */
  emptyTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'metabases.METABASES_TABLE.MESSAGES.NO_METABASES_CONFIGURED.HEAD',
    messageCaption: 'metabases.METABASES_TABLE.MESSAGES.NO_METABASES_CONFIGURED.CAPTION'
  };

  /**
   * Empty table message when a filter is applied
   */
  filterTableMessage: TableMessage = {
    messageType: TableMessageType.INFO,
    messageHead: 'metabases.METABASES_TABLE.MESSAGES.NO_FILTER_RESULTS.HEAD',
    messageCaption: 'metabases.METABASES_TABLE.MESSAGES.NO_FILTER_RESULTS.CAPTION'
  };

  /**
   * Error table message
   */
  errorTableMessage: TableMessage = {
    messageType: TableMessageType.ALERT,
    messageHead: 'metabases.METABASES_TABLE.MESSAGES.ERROR.HEAD',
    messageCaption: 'metabases.METABASES_TABLE.MESSAGES.ERROR.CAPTION'
  };

  /**
   * Table configuration
   */
  tableConfiguration: TableConfiguration = {
    isLoading: false,
    visibleRows: 25,
    fields: this.fields,
    styleClass: 'metabases-table',
    isFilterShown: true,
    rowAction: {
      fieldIndex: 0,
      menuItems: [
        {
          id: 'metabaseDetailsMenuItem',
          label: 'metabases.METABASES_TABLE.BUTTONS.DETAILS',
          command: (event) => {
            this.selectedMetabaseRowItem = event.item.target;
            this.metabaseDetailsSidebarComponent.open(this.selectedMetabaseRowItem);
          }
        },
        {
          separator: true
        },
        {
          id: 'metabaseUpgradeMenuItem',
          label: 'metabases.METABASES_TABLE.BUTTONS.UPGRADE',
          command: (event) => {
            this.selectedMetabaseRowItem = event.item.target;
            this.upgradeMetabaseSidebarComponent.open(this.selectedMetabaseRowItem);
          }
        },
        {
          id: 'deleteMenuItem',
          label: 'metabases.METABASES_TABLE.BUTTONS.DELETE',
          command: (event) => {
            this.selectedMetabaseRowItem = event.item.target;
            this.deleteMetabaseSidebarComponent.open(this.selectedMetabaseRowItem);
          }
        }
      ]
    },
    tableMessages: {
      emptyTableMessage: this.emptyTableMessage,
      filterTableMessage: this.filterTableMessage,
      errorTableMessage: this.errorTableMessage
    },
    primaryButtonText: 'metabases.METABASES_TABLE.BUTTONS.ADD',
    createButtonClicked: () => {
      this.isMetabaseSidebarVisible = true;
    },
    hideCheckboxColumn: true
  };

  isMetabaseSidebarVisible = false;
  deleteCompleted: Subject<any> = new Subject<any>();
  selectedMetabases: Metabase[];
  metabases: Metabase[];

  selectedMetabaseRowItem: Metabase;
  showDeleteMetabaseDialog = false;

  /** @internal  */
  constructor(
    private readonly metabasesApiService: MetabasesApiService,
    private readonly projectsApiService: ProjectsApiService,
    private readonly featureFlagService: FeatureFlagService,
    private readonly changeDetectorRef: ChangeDetectorRef
  ) {
    super();
  }

  /** @internal  */
  ngOnInit(): void {
    this.getAllMetabases();
  }

  /**
   * Get all metabases
   */
  getAllMetabases(): void {
    this.tableConfiguration.isLoading = true;

    this.projectsApiService
      .getDefaultProject()
      .pipe(
        tap((project) => (this.breadcrumbs[2].text = project.name)),
        mergeMap((project) => {
          this.metabasesApiService.serviceURL = `projects/${project.id}/metabases`;
          return this.metabasesApiService.getAll();
        })
      )
      .subscribe({
        next: (metabases) => {
          let data = metabases.map((metabase: Metabase) => {
            return {
              ...metabase
            };
          });

          this.metabases = data;
        }
      })
      .add(() => {
        this.tableConfiguration.isLoading = false;
        this.changeDetectorRef.markForCheck();
      });
  }
}
