import { NgModule } from '@angular/core';
import { HomeComponent } from './home.component';
import { HomeRoutingModule } from './home-routing.module';
import { SharedModule } from 'discovery-shared';
import { TranslocoModule } from '@ngneat/transloco';

@NgModule({
  imports: [SharedModule, HomeRoutingModule, TranslocoModule],
  declarations: [HomeComponent],
  exports: []
})
export class HomeModule {}
