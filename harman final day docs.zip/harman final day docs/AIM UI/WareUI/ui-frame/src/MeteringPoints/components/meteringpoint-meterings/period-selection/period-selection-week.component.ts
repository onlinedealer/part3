import {
    Component,
    ChangeDetectionStrategy,
    Input,
    ViewChild,
    ElementRef,
    EventEmitter,
    Output,
    OnDestroy,
    SimpleChanges,
    OnChanges,
    LOCALE_ID,
    Inject,
    Optional
} from "@angular/core";
import { debounceTime, filter } from "rxjs/operators";
import { FormControl } from "@angular/forms";
import { Subscription, Observable } from "rxjs";
import * as moment from "moment";
import { MatAutocomplete, AUTOCOMPLETE_OPTION_HEIGHT, AUTOCOMPLETE_PANEL_HEIGHT } from "@angular/material/autocomplete";
import { _countGroupLabelsBeforeOption, _getOptionScrollPosition } from "@angular/material/core";
moment.locale("fi");
const NUMBER_OF_YEARS_FOR_SELECTION = 6;

interface YearWeekValues {
    year: number;
    values: { view: string; year: number; week: number }[];
}

@Component({
    selector: "landisgyr-period-selection-week",
    templateUrl: "./period-selection-week.component.html",
    styleUrls: ["./period-selection.component.scss"],
    changeDetection: ChangeDetectionStrategy.OnPush
})
export class PeriodSelectionWeekComponent implements OnChanges, OnDestroy {
    static newScrollPosition: number;
    static scrollToItemMetering: number;
    static scrollToItemPrepayment: number;
    static scrollToItemTokenlog: number;
    @ViewChild("weekInput", { static: true }) input!: ElementRef<HTMLInputElement>;
    @ViewChild("weekInputDropdown", { static: true }) inputDropdown!: MatAutocomplete;

    @Input()
    disabled = false;
    @Input()
    tab!: string;

    @Input()
    from!: number;

    @Input()
    until!: number;

    @Output()
    timePeriodChange = new EventEmitter<{ from: number; until: number }>();

    weekOptions: any[] = this.getWeekOptions();
    weekOptionsTemp: any[] = this.weekOptions;
    weekInputControl = new FormControl({ value: "", disabled: this.disabled });
    selectedWeek!: number;
    selectedYear!: number;
    scrollToItem!: number;
    optionHeight = AUTOCOMPLETE_OPTION_HEIGHT;
    panelHeight = AUTOCOMPLETE_PANEL_HEIGHT;
    fromYear = false;
    constructor(@Optional() @Inject(LOCALE_ID) private localeId: string) {
        this.localeId = localeId;
    }
    private weekInputValueChanges$: Observable<any> = this.weekInputControl.valueChanges.pipe(
        debounceTime(200),
        filter((value) => value && value.view && value.year && value.week)
    );

    private weekInputChangeSubscription: Subscription = this.weekInputValueChanges$.subscribe((value) => {
        const weekMoment = moment(`${value.year}-W${value.week > 9 ? value.week : `0${value.week}`}`);
        const from = weekMoment.locale(this.localeId).startOf("week").valueOf();
        const until = weekMoment.locale(this.localeId).endOf("week").valueOf();

        if (from !== this.from || until !== this.until) {
            this.timePeriodChange.emit({
                from,
                until
            });
        }
    });

    ngOnChanges(changes: SimpleChanges) {
        if (this.inputDropdown) {
            this.getScrollPosition();
        }
        if (this.from && this.until) {
            const endMoment = moment(this.until);
            const fromMoment = moment(this.from);
            const nowMoment = moment();
            let year;

            const momentToUse = endMoment.isBefore(nowMoment) ? endMoment : nowMoment;
            const week = momentToUse.week();
            if (fromMoment.year() === endMoment.year()) {
                year = momentToUse.locale(this.localeId).year();
            } else {
                if (week > 52) {
                    year = fromMoment.isoWeekYear();
                } else {
                    year = fromMoment.locale(this.localeId).weekYear();
                }
            }
            const view = `${week}-${year}`;
            this.selectedWeek = week;
            this.selectedYear = year;
            this.weekInputControl.setValue({
                view,
                week,
                year
            });
        }
        if (changes.disabled && changes.disabled.currentValue === false && changes.from && changes.from.previousValue === undefined) {
            this.fromYear = true;
        }

        if (this.disabled) {
            this.weekInputControl.disable();
        } else {
            this.weekInputControl.enable();
        }
    }

    getSelectedValueAsFormattedForTextInput(value: any): string {
        return value.view;
    }
    getScrollPositionByIndex(index: number) {
        return index * this.optionHeight;
    }
    resetInput() {
        this.input.nativeElement.blur();
        this.onInputArrowDownClick();
        this.weekOptions = this.getWeekOptions();
        this.weekInputControl.setValue({
            year: 0,
            week: 0,
            view: ""
        });

        if (this.fromYear) {
            const index = this.getIndexForScroll(this.input.nativeElement.value);
            const asc = this.getScrollPositionByIndex(index);
            PeriodSelectionWeekComponent.newScrollPosition = this.getScrollNumber(index, asc);
            PeriodSelectionWeekComponent.scrollToItemMetering = PeriodSelectionWeekComponent.newScrollPosition;
            this.setScrollPosition();
        }
    }
    onOutFocus() {
        if (!this.weekInputControl.value.view) {
            this.weekInputControl.setValue({
                year: this.selectedYear,
                week: this.selectedWeek,
                view: `${this.selectedWeek}-${this.selectedYear}`
            });
        }
    }
    trackByFn(index: number) {
        return index;
    }
    selected(event: any, selectedItem: any) {
        if (event.source.selected) {
            const index = this.getIndexForScroll(selectedItem.view);
            PeriodSelectionWeekComponent.newScrollPosition = this.getScrollNumber(index, this.inputDropdown._getScrollTop());
            this.setScrollPosition();
            this.scrollToItem = PeriodSelectionWeekComponent.newScrollPosition;
        }
    }
    getIndexForScroll(selectedItemValue: string) {
        let index = 0;
        if (this.inputDropdown.options) {
            const list = this.inputDropdown.options;
            list.forEach((element, i) => {
                if (selectedItemValue === element.value.view) {
                    index = i;
                }
            });
        }
        return index;
    }
    getScrollNumber(index: number, scrollPosition: number) {
        let scrollNumber = 0;
        if (this.inputDropdown.options && this.inputDropdown.optionGroups) {
            const labelCount = _countGroupLabelsBeforeOption(index, this.inputDropdown.options, this.inputDropdown.optionGroups);
            if (index === 0 && labelCount === 1) {
                this.inputDropdown._setScrollTop(0);
                scrollNumber = 0;
            } else {
                if (scrollPosition) {
                    scrollNumber = _getOptionScrollPosition(index + labelCount, this.optionHeight, scrollPosition, this.panelHeight);
                }
            }
            return scrollNumber;
        } else {
            if (scrollPosition) {
                scrollNumber = scrollPosition;
            }
            return scrollNumber;
        }
    }
    setScrollPosition() {
        if (this.tab === "metering") {
            PeriodSelectionWeekComponent.scrollToItemMetering = PeriodSelectionWeekComponent.newScrollPosition;
            this.inputDropdown._setScrollTop(PeriodSelectionWeekComponent.scrollToItemMetering);
        }
        if (this.tab === "prepayment") {
            PeriodSelectionWeekComponent.scrollToItemPrepayment = PeriodSelectionWeekComponent.newScrollPosition;
            this.inputDropdown._setScrollTop(PeriodSelectionWeekComponent.scrollToItemPrepayment);
        }
        if (this.tab === "tokenlog") {
            PeriodSelectionWeekComponent.scrollToItemTokenlog = PeriodSelectionWeekComponent.newScrollPosition;
            this.inputDropdown._setScrollTop(PeriodSelectionWeekComponent.scrollToItemTokenlog);
        }
    }
    getScrollPosition() {
        if (this.tab === "metering") {
            this.inputDropdown._setScrollTop(PeriodSelectionWeekComponent.scrollToItemMetering);
        }
        if (this.tab === "prepayment") {
            this.inputDropdown._setScrollTop(PeriodSelectionWeekComponent.scrollToItemPrepayment);
        }
        if (this.tab === "tokenlog") {
            this.inputDropdown._setScrollTop(PeriodSelectionWeekComponent.scrollToItemTokenlog);
        }
    }
    filterData() {
        const searchText = this.input.nativeElement.value;
        setTimeout(() => {
            this.input.nativeElement.focus();
        });
        this.weekOptions = this.weekOptionsTemp
            .map((years) => ({ year: years.year, values: this.filterWeeks(years.values, searchText) }))
            .filter((weekList) => weekList.values.length > 0);
    }
    filterWeeks(years: any[], searchText: string) {
        const filteredDataArray: { view: string; year: number; month: number }[] = years;
        const filteredWeek: { view: string; year: number; month: number }[] = [];
        filteredDataArray.forEach((element: any) => {
            if (element.view.startsWith(searchText)) {
                filteredWeek.push(element);
            } else {
                return undefined;
            }
        });
        return filteredWeek;
    }
    onArrowClickBackward(): void {
        const value = this.weekInputControl.value;
        const firstDayDateofTheSelectedWeek = moment(`${value.year}-W${value.week > 9 ? value.week : `0${value.week}-1`}`);
        const previousWeekFirstDay = firstDayDateofTheSelectedWeek.subtract(1, "week");
        const previousWeek = previousWeekFirstDay.week();
        const previousWeeksYear = previousWeekFirstDay.weekYear();
        this.weekInputControl.setValue({
            year: previousWeeksYear,
            week: previousWeek,
            view: `${previousWeek}-${previousWeeksYear}`
        });
    }

    onArrowClickForward(): void {
        const value = this.weekInputControl.value;
        const firstDayDateofTheSelectedWeek = moment(`${value.year}-W${value.week > 9 ? value.week : `0${value.week}-1`}`);
        const nextweekFirstDay = firstDayDateofTheSelectedWeek.add(1, "week");
        const nextWeek = nextweekFirstDay.week();
        const nextWeeksYear = nextweekFirstDay.weekYear();
        const nowMoment = moment();
        if (firstDayDateofTheSelectedWeek.isSameOrBefore(nowMoment)) {
            this.weekInputControl.setValue({
                year: nextWeeksYear,
                week: nextWeek,
                view: `${nextWeek}-${nextWeeksYear}`
            });
        }
    }

    onInputEnterKey() {
        this.input.nativeElement.blur();
    }

    onInputArrowDownClick() {
        setTimeout(() => {
            this.input.nativeElement.focus();
            setTimeout(() => {
                this.getScrollPosition();
            });
        });
    }

    getWeekOptions(): YearWeekValues[] {
        let year = moment();
        const years = [{ year: year.year(), values: this.getValuesForYear(year.year(), year.week()) }];

        for (let i = 1; i < NUMBER_OF_YEARS_FOR_SELECTION; i++) {
            year = year.subtract(1, "y");
            /* using isoWeeksInYear in below line, such that that year which has 53
             weeks is stable and not changing based on locale changes. added in GAIM-27285 */
            years.push({ year: year.year(), values: this.getValuesForYear(year.year(), year.isoWeeksInYear()) });
        }

        return years;
    }

    private getValuesForYear(year: number, numberOfWeeks: number): { view: string; year: number; week: number }[] {
        const weeks = [];

        for (let i = numberOfWeeks; i > 0; i--) {
            weeks.push({
                view: `${i}-${year}`,
                year: year,
                week: i
            });
        }

        return weeks;
    }

    ngOnDestroy() {
        this.weekInputChangeSubscription.unsubscribe();
    }
}
