import { Injector } from "@angular/core";

let injector: Injector;

/**
 * Set application injector.
 *
 * @param appInjector application injector
 */
export function setInjector(appInjector: Injector) {
    // Injector is set only once from application,
    // no need to allow updating of it
    if (!injector) {
        injector = appInjector;
    }
}

/**
 * Get application injector.
 */
export function getInjector(): Injector {
    return injector;
}
