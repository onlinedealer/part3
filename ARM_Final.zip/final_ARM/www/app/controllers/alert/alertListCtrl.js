(function () {
    'use strict';

    angular.module('arm').controller('alertListCtrl',
                ['$scope', '$state', '$filter', '$ionicModal', '$ionicSideMenuDelegate', alertListCtrl]);

    function alertListCtrl($scope, $state, $filter, $ionicModal, $ionicSideMenuDelegate) {

        $scope.closeAlertList = function () {
            $state.go('tab.home');
        }


    };

})();
