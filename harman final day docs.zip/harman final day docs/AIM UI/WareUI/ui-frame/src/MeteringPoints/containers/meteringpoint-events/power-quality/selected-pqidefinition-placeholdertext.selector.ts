import { createSelector } from "@ngrx/store";
import { getSelectedPqiDefinitionIDs, getPqiTreeTypes } from "../../../store/selectors/event.definitions.selector";
import { TodoItemNode } from "../../../store/reducers/event-definitions.reducer";
import { flatten } from "lodash";

const checkEventTypeForSelectedDefinitions = (eventType: TodoItemNode, selectedDefinitions: number[]) => {
    const selectedDefinitionsOfThisEventClass = eventType.children.filter((eventDefinition: TodoItemNode) =>
        selectedDefinitions.includes(eventDefinition.id)
    );
    return {
        allChildrenSelected: selectedDefinitionsOfThisEventClass.length === eventType.children.length,
        selectedChildren: selectedDefinitionsOfThisEventClass,
        item: eventType.item,
        id: eventType.clsId
    };
};

const getPlaceHolderTextBase = (eventTypesWithFullChildrenSelections: any[], eventClassesWithFullChildrenSelections: any[]) => {
    if (eventTypesWithFullChildrenSelections.length > 0) {
        return eventTypesWithFullChildrenSelections[0];
    } else if (eventClassesWithFullChildrenSelections.length > 0) {
        return eventClassesWithFullChildrenSelections[0];
    }
};

const getPlaceHolderPlusCounter = (selectedId: number, eventTypes: any[]) => {
    let counter = 0;

    eventTypes
        .filter((eventType) => eventType.id !== selectedId)
        .forEach((eventType) => {
            if (eventType.allChildrenSelected) {
                counter = counter + 1;
            } else {
                eventType.selectedChildren
                    .filter((eventClass: any) => eventClass.id !== selectedId)
                    .forEach((eventClass: any) => {
                        if (eventClass) {
                            counter = counter + 1;
                        } else {
                            counter =
                                counter +
                                eventClass.selectedChildren.filter((eventDefinition: any) => eventDefinition.id !== selectedId).length;
                        }
                    });
            }
        });

    return counter;
};

export const getSelectedPqiDefinitionPlaceholderText = createSelector(
    getPqiTreeTypes,
    getSelectedPqiDefinitionIDs,
    (eventTypes, selectedDefinitions) => {
        if (eventTypes[0]) {
            const selectedTypes = eventTypes[0].children
                .map((eventType, index) => checkEventTypeForSelectedDefinitions(eventType, selectedDefinitions))
                .filter((eventTypeResponse) => eventTypeResponse.allChildrenSelected || eventTypeResponse.selectedChildren.length > 0);

            const eventTypeWithFullChildrenSelections = selectedTypes.filter((eventType) => eventType.allChildrenSelected);
            const eventDefinitionSelections = flatten(selectedTypes.map((eventType) => eventType.selectedChildren));
            const placeHolderTextBase = getPlaceHolderTextBase(eventTypeWithFullChildrenSelections, eventDefinitionSelections);
            const placeHolderPlusCounter = placeHolderTextBase ? getPlaceHolderPlusCounter(placeHolderTextBase.id, selectedTypes) : 0;
            let placeHolderText = placeHolderTextBase ? placeHolderTextBase.item : "";

            if (placeHolderPlusCounter > 0) {
                placeHolderText = placeHolderText + " ( + " + placeHolderPlusCounter + " " + $localize`:|@@profileForm.others:others` + ")";
            }
            if (eventTypes[0].children.length === eventTypeWithFullChildrenSelections.length) {
                placeHolderText = $localize`:|@@meteringpointPqi.all:All`;
            }
            return placeHolderText;
        } else {
            return [];
        }
    }
);
