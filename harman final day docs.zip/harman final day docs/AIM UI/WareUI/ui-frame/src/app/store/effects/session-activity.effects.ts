import { Injectable } from "@angular/core";
import { Actions, createEffect, ofType } from "@ngrx/effects";
import { tap, map, throttleTime } from "rxjs/operators";
import { SessionActivityService } from "../../services/session-activity.service";
import { SecurityActions, RouterActions } from "../actions";
import { SessionExpirationService } from "../../services/session-expiration.service";

@Injectable()
export class SessionActivityEffects {
    constructor(
        private storeActions$: Actions,
        private sessionActivityService: SessionActivityService,
        private sessionExpirationService: SessionExpirationService
    ) {}

    storeSessionActivityTimestamp$ = createEffect(
        () =>
            this.storeActions$.pipe(
                throttleTime(500),
                tap(() => this.sessionActivityService.storeActionOccurred()),
                map(() => RouterActions.NoOperation())
            ),
        { dispatch: false }
    );

    showSessionExpiratingDialog$ = createEffect(
        () =>
            this.storeActions$.pipe(
                ofType(SecurityActions.ShowTimeoutDialog),
                tap(() => this.sessionExpirationService.showSessionExpiratingDialog())
            ),
        { dispatch: false }
    );

    closeSessionExpiratingDialog$ = createEffect(
        () =>
            this.storeActions$.pipe(
                ofType(SecurityActions.ClosedTimeoutDialog),
                tap(() => this.sessionExpirationService.closeDialogIfOpen())
            ),
        { dispatch: false }
    );
}
