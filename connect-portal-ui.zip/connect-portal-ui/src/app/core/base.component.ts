import { HttpErrorResponse } from '@angular/common/http';
import { Component } from '@angular/core';
import { Router, NavigationExtras } from '@angular/router';

/**
 * Base component for all components used in the connect-ui app
 */
@Component({
  selector: 'p-connect-base',
  template: ''
})
export class BaseComponent {
  isProcessingRequest: boolean;
  message: string;
  messageParameter: string;
  messageType: string;
  httpErrorResponse: HttpErrorResponse;
  fieldValueHoverText = '';

  constructor(public router?: Router) {}

  /**
   * Navigate to specific route
   * @param targetRoute - route to be navigated
   * @param extras - options that modify the Router navigation strategy
   */
  navigateTo(targetRoute: string, extras?: NavigationExtras) {
    this.router.navigate([`/data-integration/${targetRoute}`], extras);
  }

  /**
   * Returns a date object from a java epoch date
   * @param dateEpoch the java epoch to convert
   * @returns date object
   */
  getDateFromEpoch(dateEpoch) {
    return new Date(dateEpoch * 1000);
  }

  parseHttpClientResponseMessage(messageType: string, apiResponse: any) {
    this.messageType = messageType;

    if (apiResponse.messageParameter) {
      this.messageParameter = apiResponse.messageParameter;
    }

    if (messageType === 'error' && apiResponse.error) {
      this.message = apiResponse.error.message || apiResponse.error.error;
    } else {
      this.message = apiResponse.message;
    }

    this.httpErrorResponse = apiResponse;
  }

  displayTooltipOnOverflow(element): string {
    return element.offsetWidth < element.scrollWidth ? element.innerText : '';
  }

  getStatusIconStyleClassList(status: string): string[] {
    switch (status) {
      case 'UP':
        return ['png-alert-ok-solid', 'text-success'];
      case 'DOWN':
        return ['png-alert-attention-solid', 'text-warning'];
      case 'PARTIAL':
        return ['png-alert-partial', 'text-danger'];
      case 'STOPPED':
        return ['png-alert-stopped-solid', 'text-danger'];
      case 'IN_PROGRESS':
        return ['png-refresh', 'text-warning'];
      case 'STOPPING':
        return ['png-refresh', 'text-success'];
      case 'STARTING':
        return ['png-refresh', 'text-success'];
      case 'ERROR':
      case 'ACTION_REQUIRED':
        return ['png-alert-actionrequired-solid', 'text-danger'];
      case 'OK':
        return [];
      case 'DISABLED':
        return ['png-disabled', 'text-muted'];
      case 'ENABLED':
        return ['png-alert-open', 'text-success'];
      case 'UNKNOWN':
        return ['png-alert-unknown-solid', 'text-warning'];
      case 'ATTENTION':
        return ['png-alert-attention-solid', 'text-warning'];
      case 'COMPLETED':
        return ['png-check', 'text-success'];
      // temporarily using this icon until we get the correct one
      case 'QUEUED':
        return ['png-signin', 'text-success'];
      case 'IGNORED':
        return ['png-alert-stopped-solid', 'text-muted'];
    }
  }

  getOverallStatusStyleClass(status: string): string {
    const commonStyles = 'align-bottom png-icon-sm';

    switch (status) {
      case 'ACTION_REQUIRED':
        return commonStyles + ' png-alert-actionrequired-solid text-danger';
      case 'STOPPED':
        return commonStyles + ' png-alert-stopped-solid text-danger';
      case 'IN_PROGRESS':
        return commonStyles + ' png-refresh text-warning';
      case 'UNKNOWN':
        return commonStyles + ' png-alert-unknown-solid text-warning';
      case 'ATTENTION':
        return commonStyles + ' png-alert-attention-solid text-warning';
      case 'ATTENTION_SELECTION':
        return commonStyles + ' png-alert-attention-solid text-warning';
      case 'ATTENTION_BLUE':
        return commonStyles + ' png-alert-attention-solid text-info';
      case 'STOPPING':
        return commonStyles + ' png-refresh text-success';
      case 'STARTING':
        return commonStyles + ' png-refresh text-success';
      case 'OK':
        return commonStyles + ' png-alert-open text-success';
      case 'COMPLETED':
        return commonStyles + ' png-check text-success';
      case 'PARTIAL':
        return commonStyles + ' png-alert-partial text-danger';
      case 'IGNORED':
        return commonStyles + ' png-alert-stopped-solid text-muted';
    }
  }

  fieldValueMouseOver(e) {
    this.fieldValueHoverText = e.target.offsetWidth < e.target.scrollWidth ? e.target.innerText : '';
  }

  fieldValueMouseOut(e) {
    this.fieldValueHoverText = '';
  }

  /**
   * Returns a value from a parameter array if an item is found, if not returns an empty string
   */
  getParameterValue(parameters: { key?: string; value?: string }[], key: string): string {
    const found = parameters.find((parameter) => parameter.key === key);
    return found && found.value ? found.value : '';
  }
}
