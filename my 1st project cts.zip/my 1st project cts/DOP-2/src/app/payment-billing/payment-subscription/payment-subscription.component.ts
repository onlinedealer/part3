import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { HttpResponse, HttpParams } from '@angular/common/http';
import { AjaxUtilityService } from '../../shared/utility/ajax-utility.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { SubscriptionModel } from '../../shared/models/subscription-model';
import { ActiveModelService } from '../../shared/models/active-model.service';
import * as _ from 'underscore';
import { UtilityService } from '../../shared/utility/utility.service';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-payment-subscription',
  templateUrl: './payment-subscription.component.html',
  styleUrls: ['./payment-subscription.component.scss']
})
export class PaymentSubscriptionComponent implements OnInit {

  @Output() changeTaxSubscription: EventEmitter<boolean> = new EventEmitter<boolean>();
  @Output() serviceError: EventEmitter<boolean> = new EventEmitter<boolean>();
  public subscriptionDetailsForm: any;
  monthlySubscription = true;
  subscriptions = [];
  selectedSubscription: any;
  subscriptionArr = [];
  businessContentPayment: any;

  constructor(
    private _ajaxUtility: AjaxUtilityService,
    private _fb: FormBuilder,
    private _route: ActivatedRoute,
    public _activeModel: ActiveModelService,
    public _utility: UtilityService,
    private _sanitizer: DomSanitizer
  ) { }

  getUnit(type) {
    return 'MONTHLY' === type ? 'month' : 'year';
  }

  chooseSubscription(value) {
  }


  ngOnInit() {
    this._route.data
    .subscribe(
      (data: { subscription: any }) => {
        let response;
        if (data.hasOwnProperty('subscription') && data.subscription.hasOwnProperty('getEligibleClubSubscriptionsResponse')) {
          response = data['subscription']['getEligibleClubSubscriptionsResponse'];
          if ('0000' === response.status.statusCode) {
            this.fetchPaymentContent(this._utility.getUserAgent().indexOf('_MOBILE') !== -1 ? '30438' : '30439');
            if (response.hasOwnProperty('subscriptions')) {
              response['subscriptions'].forEach((subscription) => {
                this.subscriptionArr.push(new SubscriptionModel(subscription));
              });
              this._activeModel.setSubscription(this.subscriptionArr);
            }
          } else {
            this.serviceError.emit(true);
          }
        } else {
          this.serviceError.emit(true);
        }
      },
      (err) => {
        this.serviceError.emit(true);
      }
    );

    /*
    let monthlySubscriptionIndex = 0;
    _.map(this._activeModel.getSubscription(), function(subscription, index) {
      if (subscription.displayPriority === '0') {
        monthlySubscriptionIndex = index;
      }
    });
    */

    this.subscriptionDetailsForm = this._fb.group({
      subscriptionRadio: [0, [Validators.required]]
    });
  }

  /**
   * @method fetchPageContent - method to make BCC service call
   * @param contentId - BCC content id
   */

  fetchPaymentContent(contentId) {
    this._ajaxUtility.sendRequest('bccContent', {}, new HttpParams().set('contentId', contentId)).subscribe(
      (data: HttpResponse<any>) => {
        let response;
        if (data.hasOwnProperty('response')) {
          response = data['response'];
          if ('0000' === response.header.statusCode) {
            this.changeTaxSubscription.emit(true);
            this.businessContentPayment = JSON.parse(this._utility.getDecrypted(response.details.slotContent));
            this.subscriptions = this.businessContentPayment.subscriptions;
            this.selectedSubscription = this.subscriptions[0];
          }
        }
      },
      (err) => {
        console.error(err);
      }
    );
  }

  subscriptionChange() {
    // this.selectedSubscription = this.subscriptions[this.subscriptionDetailsForm.get('subscriptionRadio').value]
    this.selectedSubscription = this.subscriptions[this.subscriptionDetailsForm.get('subscriptionRadio').value];
    this.changeTaxSubscription.emit(true);
  }
}
