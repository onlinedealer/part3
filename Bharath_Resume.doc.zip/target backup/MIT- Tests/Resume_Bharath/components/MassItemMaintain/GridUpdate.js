import React from 'react'
import _ from 'lodash'
import { object } from 'prop-types'
import { withStyles } from '@material-ui/core/styles'
import Paper from '@material-ui/core/Paper'
import Grid from '@material-ui/core/Grid'
import Button from '@material-ui/core/Button'
import TextField from '@material-ui/core/TextField'
import Checkbox from '@material-ui/core/Checkbox'
import MitAutoSuggest from '../common/MitAutoSuggest/MitAutoSuggest'

const styles = theme => ({
  root: {
    flexGrow: 1,
    fontSize: 14,
  },
  paper: {
    padding: theme.spacing.unit * 2,
    textAlign: 'center',
    color: theme.palette.text.secondary,
    margin: 10,
    minHeight: 225,
  },
  boxPadding: {
    padding: 40,
  },
  button: {
    margin: 10,
  },
  input: {
    display: 'none',
  },
  textField: {
    marginRight: theme.spacing.unit,
    width: 250,
  },
  textLeft: {
    textAlign: 'left',
  },
  gridBorder: {
    borderRight: '1px solid #ebebeb',
    marginRight: 10,
  },
  popoverPosition: {
    top: 70,
    left: 1200,
  },
  typography: {
    padding: 10,
    backgroundColor: '#f34a21',
    color: '#fff',
    width: 300,
  },
  floatRight: {
    float: 'right',
  },
  errorBlock: {
    height: 90,
    overflow: 'auto',
  },
  WebkitScrollbarTrack: {
    background: '#000',
  },
  confirmMsg: {
    color: 'green',
  },
  textInput: {
    padding: 8,
  },
  textIndent: {
    paddingLeft: 7,
  },
  gridHeadText: {
    fontSize: 22,
    marginBottom: 0,
    fontWeight: 400,
    marginTop: 0,
  },
  gridDesc: {
    margin: 10,
    fontSize: 12,
  },
  applyBtn: {
    margin: 10,
    float: 'right',
    color: '#000',
    backgroundColor: '#ffe08a',
    fontSize: 13,
    '&:hover': {
      backgroundColor: '#ffe08a',
    },
  },
  clearBtn: {
    margin: 10,
    float: 'right',
  },
  formControl: {
    margin: theme.spacing.unit,
    minWidth: 220,
    border: '1px solid #666',
    padding: '0px 2px',
    borderRadius: 5,
    width: 240,
  },
  casepackOptTop: {
    marginTop: 15,
  },
  checkboxMargin: {
    margin: -5,
  },
})

export class GridUpdate extends React.Component {
  static propTypes = {
    classes: object,
  };

  state = {
    newValue: '',
    errorStatus: false,
    fieldError: '',
    selectFiled: '',
    selectRefValue: 'All',
    selectRef: {},
    globalFields: [],
    globalFilters: [],
    errorMsgPopover: false,
    dispField: '',
    isPrimary: false,
  }

  componentWillMount () {
    const globalFields = _.groupBy(this.props.columnInfo, function (obj) {
      return obj.editable
    }).true
    const globalFilters = _.groupBy(this.props.columnInfo, function (obj) {
      return obj.filterable
    }).true
    const selectFiled = globalFields !== undefined ? globalFields[0].column_id : ''
    let selectRef = {}
    const dispField = 'Enter ' + globalFields[0].column_name.toLowerCase()
    this.setState({ globalFields, globalFilters, selectFiled, selectRef, dispField })
  }

  updateToAll = event => {
    if (this.state.newValue !== '') {
      this.props.updateCallBack(this.state.newValue)
      this.setState({ errorStatus: false, fieldError: '' })
    } else {
      this.setState({ errorStatus: true, fieldError: 'please enter value' })
    }
  }

  handleChange = newValue => event => {
    if (event.target.value !== '') {
      this.setState({ errorStatus: false, fieldError: '' })
    }
    this.setState({ [newValue]: event.target.value })
  }

  handleRefChange = (fieldId, value) => {
    const selectRef = this.state.selectRef
    selectRef[fieldId] = value.split(' - ')[0]
    this.setState({ selectRef })
    this.props.setFilterCallBack(selectRef)
  }

  resetData = (event) => {
    this.setState({ newValue: '', selectRef: {}, isPrimary: false })
    this.state.globalFilters.map((obj, key) => {
      const refValue = 'child' + key
      this.refs[refValue].resetForm()
    })
    this.props.setFilterCallBack({})
  }

  handleClickOpen = () => {
    this.setState({ errorMsgPopover: true })
  }

  handleClose = () => {
    this.setState({ errorMsgPopover: false })
  }

  convertCase = (str) => {
    str = str.replace('_', ' ')
    var lower = String(str).toLowerCase()
    return lower.replace(/(^| )(\w)/g, function (x) {
      return x.toUpperCase()
    })
  }

  changePrimary = (event) => {
    const selectRef = this.state.selectRef
    this.setState({ isPrimary: event.target.checked })
    selectRef['primary_case_pack'] = event.target.checked
    this.props.setFilterCallBack(selectRef)
  }

  cancelUpdate = (event) => {
    this.props.cancelUpdateCallBack()
  }

  saveItems = (event) => {
    this.props.saveItemsCallBack()
  }

  render () {
    const { classes } = this.props

    const buttonDisplayText = this.props.commonFields.maintenance_type === 'cost' ? 'Apply To Table' : 'Filter'
    const inputProps = {
      className: classes.textInput,
    }

    const InputLabelProps = {
      className: classes.textIndent,
    }

    const itemsCount = _.uniqBy(this.props.listItems, 'tcin').length

    return (
      <div className={classes.root}>
        <Grid container>
          <Grid item xs={4}>
            <Paper className={classes.paper}>
              <Grid container>
                <Grid item xs={12}>
                  <h3 className={classes.gridHeadText}>{this.props.commonFields.jira_id} Cost Maintenance</h3>
                </Grid>
                <Grid item xs={12} className={classes.gridDesc}>
                  {this.props.gridText.grid_text_left.split('\n').map((item, key) => {
                    return <div key={key}><span dangerouslySetInnerHTML={{__html: item}} /><br /></div>
                  })}
                </Grid>
                <Grid item xs={12} className={classes.gridDesc}>
                  <h3 className={classes.gridHeadText}>{itemsCount} Items</h3>
                </Grid>
                <Grid item xs={12} className={classes.gridDesc}>
                  <Button className={classes.button} onClick={this.cancelUpdate}>
                  Cancel
                  </Button>
                  <Button variant="raised" color="primary" className={classes.button} onClick={this.saveItems}>
                  Save Changes
                  </Button>
                </Grid>
              </Grid>
            </Paper>
          </Grid>
          <Grid item xs={8}>
            <Paper className={classes.paper}>
              <Grid container>
                <Grid item xs={12} className={classes.gridDesc}>
                  {this.props.gridText.grid_text_right.split('\n').map((item, key) => {
                    return <div key={key}><span dangerouslySetInnerHTML={{__html: item}} /><br /></div>
                  })}
                </Grid>
                <Grid item xs={12} className={classes.gridDesc}>
                  <Grid container>
                    {this.state.globalFilters.map((obj, key) => {
                      const refValue = 'child' + key
                      const filterName = obj.filter_name.toLowerCase()
                      let groupList = _.groupBy(
                        this.props.listItems,
                        obj.column_id
                      )
                      return (
                        <Grid item xs={4} key={key}>
                          <MitAutoSuggest
                            groupList={groupList}
                            getSuggestionCallback={this.handleRefChange.bind(this)}
                            column_id={obj.column_id}
                            column_name={obj.column_name}
                            filter_name={filterName}
                            concatWith={obj.concat_with}
                            clearField="No"
                            id="loadLovs"
                            ref={refValue}
                          />
                        </Grid>
                      )
                    })}
                    { this.props.commonFields.maintenance_type === 'cost' &&
                    <span>
                      <Grid item xs={4}>
                        <TextField
                          id="required"
                          label={this.state.dispField}
                          className={classes.formControl}
                          value={this.state.newValue}
                          onChange={this.handleChange('newValue')}
                          margin="normal"
                          type="number"
                          helperText={this.state.fieldError}
                          error={this.state.errorStatus}
                          inputProps={inputProps}
                          InputLabelProps={InputLabelProps}
                        />
                      </Grid>
                    </span>
                    }
                    { this.props.commonFields.maintenance_type === 'casepacks' &&
                    <Grid item xs={4} className={classes.casepackOptTop}>
                      <Checkbox checked={this.state.isPrimary} className={classes.checkboxMargin} onChange={this.changePrimary} />Show only Primary casepacks
                    </Grid>
                    }
                  </Grid>
                </Grid>
                <Grid item xs={12} className={classes.gridDesc}>
                  <Button
                    variant="raised"
                    color="primary"
                    className={classes.applyBtn}
                    onClick={this.updateToAll}
                  >
                    {buttonDisplayText}
                  </Button>
                  <Button
                    variant=""
                    className={classes.clearBtn}
                    onClick={this.resetData}
                  >
                      Clear All
                  </Button>

                </Grid>
              </Grid>
            </Paper>
          </Grid>
        </Grid>
      </div>
    )
  }
}

export default (withStyles(styles)(GridUpdate))
