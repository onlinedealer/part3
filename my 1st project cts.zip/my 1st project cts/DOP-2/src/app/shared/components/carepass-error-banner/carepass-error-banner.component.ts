import { ViewChild, Component, OnInit, Input, Renderer, } from '@angular/core';

@Component({
  selector: 'app-carepass-error-banner',
  templateUrl: './carepass-error-banner.component.html',
  styleUrls: ['./carepass-error-banner.component.scss']
})
export class CarepassErrorBannerComponent implements OnInit {

  @Input() errorMessage: any;
  @Input() errorMsgDetails: any;
  @Input() id: any;
  @ViewChild('target') target: any;
  

  constructor(private _renderer: Renderer) { }

  ngOnInit() {
  }

  scrollToErr(evt) {
    window.scrollTo(0, this.target.nativeElement.offsetTop);
  }

}
